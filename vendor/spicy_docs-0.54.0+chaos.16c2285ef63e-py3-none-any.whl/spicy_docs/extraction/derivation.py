"""The body-text derivation's own version: what a host keys a re-read of extracted text on.

``BODY_TEXT_DERIVATION_VERSION`` names the rules that turn a retained rendition into ``BodyText``: the modules
``extraction.body_text`` imports, directly or through one another, inside the ``extraction`` and ``reading`` packages
(the PDF reader, ``gpo_normalize``, the markup and XML readers). Their imports from elsewhere in SpicyDocs are
``transport`` byte bounds and credential checks, which never change a text, so they are not followed. The version
moves when what those modules produce can change, and only then, so a host's re-read key does not move on a comment,
a rename or an unrelated reader, and does not depend on where SpicyDocs keeps its files. Until round 5 the host
digested both directories whole, which a moved directory silently turned into the digest of nothing.

:func:`derivation_code_digest` is the digest of the code behind the version, its module set found from the import
statements themselves (function-level imports included), so a new import widens it without a list to update.
``tests/test_body_text_derivation.py`` pins the version and the digest together: a change to any of these modules
fails there until its author moves the version (the output can change) or re-pins the digest as output-neutral, in the
same commit. PyMuPDF's own release is not in it; a host keys on that separately.
"""

from __future__ import annotations

import ast
import hashlib
from importlib.resources import files
from importlib.resources.abc import Traversable

#: Moves when the body text a rendition derives to can change; see the module docstring.
BODY_TEXT_DERIVATION_VERSION = "001"
#: The module whose output the version names.
DERIVATION_ROOT = "spicy_docs.extraction.body_text"
#: The packages its derivation lives in; an import leaving them is not followed.
DERIVATION_PACKAGES: tuple[str, ...] = ("spicy_docs.extraction", "spicy_docs.reading")


def _source(module: str) -> Traversable | None:
    """The installed source file of ``module``, without importing it; None for a name that is not a module."""
    parts = module.split(".")
    node = files(parts[0])
    for part in parts[1:-1]:
        node = node.joinpath(part)
    leaf = node.joinpath(parts[-1])
    if leaf.is_dir() and leaf.joinpath("__init__.py").is_file():
        return leaf.joinpath("__init__.py")
    candidate = node.joinpath(f"{parts[-1]}.py")
    return candidate if candidate.is_file() else None


def _inside(module: str) -> bool:
    return any(module == package or module.startswith(package + ".") for package in DERIVATION_PACKAGES)


def _imported(module: str, source: Traversable) -> set[str]:
    """Every module inside :data:`DERIVATION_PACKAGES` that ``module``'s import statements name, anywhere in it."""
    package = module if source.name == "__init__.py" else module.rsplit(".", 1)[0]
    found: set[str] = set()
    for node in ast.walk(ast.parse(source.read_text(encoding="utf-8"))):
        if isinstance(node, ast.Import):
            found |= {alias.name for alias in node.names}
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                base = package.split(".")[: len(package.split(".")) - node.level + 1]
                origin = ".".join([*base, *([node.module] if node.module else [])])
            else:
                origin = node.module or ""
            found.add(origin)
            found |= {f"{origin}.{alias.name}" for alias in node.names}
    return {name for name in found if _inside(name) and _source(name) is not None}


def derivation_modules() -> tuple[str, ...]:
    """The modules the derivation reads: :data:`DERIVATION_ROOT` and its import closure inside the packages."""
    seen: set[str] = set()
    pending = [DERIVATION_ROOT]
    while pending:
        module = pending.pop()
        if module in seen:
            continue
        source = _source(module)
        if source is None:
            raise RuntimeError(f"{module} has no source file, so the body-text derivation cannot be digested")
        seen.add(module)
        pending.extend(_imported(module, source) - seen)
    return tuple(sorted(seen))


def derivation_code_digest() -> str:
    """``sha256:`` over each module of :func:`derivation_modules`, by module name then the digest of its bytes.

    Read through the installed package, so a checkout and a built wheel of the same source agree.
    """
    hasher = hashlib.sha256()
    for module in derivation_modules():
        source = _source(module)
        assert source is not None  # derivation_modules refused a module with no source
        hasher.update(module.encode() + b"\0" + hashlib.sha256(source.read_bytes()).digest())
    return "sha256:" + hasher.hexdigest()


__all__ = [
    "BODY_TEXT_DERIVATION_VERSION",
    "DERIVATION_PACKAGES",
    "DERIVATION_ROOT",
    "derivation_code_digest",
    "derivation_modules",
]
