"""Legislative stage and signing date from a bill's retained actions.

The progress ladder keeps its existing keys. Failed passage and veto are
separate outcomes, not positions on that ladder. The latest classified action
wins, except that enactment is terminal, a veto remains until enactment is
recorded, and once a chamber has passed the bill no introduction or committee
step moves it back (a vitiated passage is undone). Full source text, matched
rule, and action location stay inspectable.

The unitedstates/congress action tests supplied independent veto, failed-vote,
and resolution cases; see docs/sources/bill-stage.md for source pins and the
bounded BILLSTATUS comparison. Only narrowly qualified publisher codes override
prose: the executive E30000 code occurs on both signatures and vetoes.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace
from types import MappingProxyType

DEFAULT_STAGE = "introduced"
LAW_STAGE = "law"

HOUSE, SENATE = "House", "Senate"
ORIGIN_CHAMBERS_BY_NAME: frozenset[str] = frozenset({HOUSE, SENATE})
#: The chamber a measure originates in, read from its type. BILLSTATUS ``originChamber`` agrees on every one of the
#: 173,278 bills of the 108th-119th Congresses in the live bill-family generation (``fd1bb730...``, 2026-10-03).
ORIGIN_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {
        **dict.fromkeys(("hr", "hres", "hjres", "hconres"), HOUSE),
        **dict.fromkeys(("s", "sres", "sjres", "sconres"), SENATE),
    }
)
#: The chamber whose system entered an action, by the publisher's ``sourceSystem/name``. The Senate states only its
#: name (no code); the Library of Congress system names no chamber.
SOURCE_SYSTEM_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {"Senate": SENATE, "House floor actions": HOUSE, "House committee actions": HOUSE}
)
#: A matcher whose text names no chamber, so the system that entered the action says where it happened: every one of
#: the 1,936 House "Held at the desk." actions names neither chamber, and 101 of the Senate's name both.
SOURCE_SYSTEM = "source system"


@dataclass(frozen=True, slots=True)
class Stage:
    """One rung, with the display strings that travel with the vocabulary."""

    key: str
    label: str
    short: str


STAGES: tuple[Stage, ...] = (
    Stage("introduced", "Introduced", "Intro"),
    Stage("committee", "In committee", "Cmte"),
    # Owner decision, round 5 (2026-10-03): a placement on the bill's own chamber's calendar is a rung of its own, and so
    # is passage by both chambers, which `passed_chamber` and `other_chamber` used to stand for.
    Stage("calendared", "On calendar", "Cal"),
    Stage("passed_chamber", "Passed chamber", "Pass"),
    Stage("other_chamber", "Other chamber", "Other"),
    Stage("passed_both", "Passed both chambers", "Both"),
    Stage("conference", "Conference", "Conf"),
    Stage("presented", "Presented to President", "Pres"),
    Stage("law", "Became law", "Law"),
)
STAGE_KEYS: tuple[str, ...] = tuple(stage.key for stage in STAGES)
# These have no numerical progress value: a failed vote may later pass, and a
# veto may be overridden. Callers can display their labels beside the ladder.
OUTCOME_STAGES: tuple[Stage, ...] = (
    Stage("failed", "Passage failed", "Failed"),
    Stage("vetoed", "Vetoed", "Veto"),
)
_OUTCOME_KEYS = frozenset(stage.key for stage in OUTCOME_STAGES)


@dataclass(frozen=True, slots=True)
class StageRule:
    """Lowercase substrings; the first rule with any hit wins.

    ``chambers`` scopes a rule to the chamber an action happens in: each matcher's chamber (``HOUSE``, ``SENATE``, or
    ``SOURCE_SYSTEM`` where the text names none), and a matcher fires only where that chamber is known and is not the
    bill's origin -- or, with ``own_chamber``, only where it is known and is the bill's origin. A matcher skipped for
    its chamber passes the text on to the next matcher and rule.
    """

    stage: str
    matchers: tuple[str, ...]
    chambers: Mapping[str, str] | None = None
    own_chamber: bool = False


# Order is load-bearing and each comment says why, as the original did.
STAGE_RULES: tuple[StageRule, ...] = (
    # An enactment statement is checked at the start of the action below;
    # mentioning another public law or ordering a public print is not enactment.
    StageRule(
        "law",
        (
            "became public law",
            "became private law",
            "became law without",
            "signed by president",
            "approved by president",
        ),
    ),
    StageRule(
        "presented",
        ("presented to president", "sent to the president", "transmitted to president"),
    ),
    StageRule(
        "conference",
        (
            "conference report",
            "conference committee",
            "resolving differences",
            "requests a conference",
            "sent to conference",
            "appointed conferees",
            "returned to house from senate with amendment",
            "returned to senate from house with amendment",
            "house insisted on its amendment",
            "senate insisted on its amendment",
        ),
    ),
    StageRule(
        "passed_chamber",
        (
            "engrossed",
            "enrolled",
            "passed house",
            "passed senate",
            "passed/agreed to",
            "on passage passed",
            "on passage agreed",
            "agreed to in house",
            "agreed to in senate",
            "passed by recorded vote",
            "passed by voice vote",
        ),
    ),
    # A measure is received only by the chamber it did not originate in, so receipt is the other chamber whatever the
    # bill.
    StageRule("other_chamber", ("received in the senate", "received in the house")),
    # Calendars, the desk, motions to proceed and cloture exist in the chamber of origin too; there they classify
    # nothing and the earlier rung stands (a reported bill reads `committee`). 659 of the 119th's 1,453
    # `other_chamber` bills read it from their own chamber before this scope (round 4, 2026-10-03). The bare
    # "calendar" keeps its place ahead of the House calendars it already caught, so published matcher spellings
    # do not move; the named ones only add a chamber where no source system names one.
    StageRule(
        "other_chamber",
        (
            "placed on calendar",
            "placed on the union calendar",
            "placed on senate legislative calendar",
            "calendar",
            "placed on the house calendar",
            "discharge calendar",
            "held at the desk",
            "motion to proceed",
            "cloture",
        ),
        chambers=MappingProxyType(
            {
                "placed on calendar": SOURCE_SYSTEM,
                "placed on the union calendar": HOUSE,
                "placed on senate legislative calendar": SENATE,
                "calendar": SOURCE_SYSTEM,
                "placed on the house calendar": HOUSE,
                "discharge calendar": HOUSE,
                "held at the desk": SOURCE_SYSTEM,
                "motion to proceed": SENATE,
                "cloture": SENATE,
            }
        ),
    ),
    # The same three named calendars in the bill's own chamber: a reported bill awaiting the floor, or one placed there
    # unreported (Senate Rule XIV, a discharge). Owner decision, round 5; the bare "calendar", "placed on calendar" and
    # the Discharge Calendar stay out, since in the own chamber they also name a return or a discharge motion.
    StageRule(
        "calendared",
        ("placed on the union calendar", "placed on senate legislative calendar", "placed on the house calendar"),
        chambers=MappingProxyType(
            {
                "placed on the union calendar": HOUSE,
                "placed on senate legislative calendar": SENATE,
                "placed on the house calendar": HOUSE,
            }
        ),
        own_chamber=True,
    ),
    # Before "introduced": "reported" can appear alongside "introduced" and is
    # the more advanced stage.
    StageRule("committee", ("reported", "ordered to be reported", "markup", "referred")),
    StageRule("introduced", ("introduced",)),
)


@dataclass(frozen=True, slots=True)
class StageFinding:
    """``rule`` and ``matcher`` are ``None`` when no rule fired and the default stood."""

    stage: str
    rule: str | None
    matcher: str | None
    source_text: str | None
    action_index: int | None
    action_date: str | None


def stage_index(stage: str) -> int:
    """Position in **display** order; -1 for a stage outside the vocabulary.

    This is where the rung is drawn, not how far the bill has got -- do not
    compare two stages with it.
    """
    return STAGE_KEYS.index(stage) if stage in STAGE_KEYS else -1


def stage_progress(stage: str) -> float:
    """Fraction of the **display** ladder drawn, 0.0 at ``introduced`` and 1.0 at ``law``.

    A declared change from the original, whose ``stageProgress`` returned
    ``-1 / 6`` for an unknown stage: a stage outside the vocabulary raises
    ``ValueError`` here.
    """
    index = stage_index(stage)
    if index < 0:
        raise ValueError(f"unknown stage {stage!r}")
    return index / (len(STAGES) - 1)


def _field(record: object, *names: str) -> object:
    """Read the first of ``names`` a mapping holds or an object carries."""
    if isinstance(record, Mapping):
        for name in names:
            if name in record:
                return record[name]
        return None
    for name in names:
        value = getattr(record, name, None)
        if value is not None:
            return value
    return None


def _action_text(action: object) -> str | None:
    """A ``BillAction``'s ``text``, or a published ``bill_actions`` row's ``action_text``."""
    if action is None or isinstance(action, str):
        return action
    value = _field(action, "text", "action_text")
    return value if isinstance(value, str) else None


def _action_date(action: object) -> str | None:
    if action is None or isinstance(action, str):
        return None
    value = _field(action, "action_date", "actionDate")
    return value if isinstance(value, str) else None


_VETO_PREFIXES = ("vetoed by president", "pocket vetoed by president")
# Match the vote being decided, not a procedural motion or a quoted bill.
_PASSAGE_VOTE = re.compile(
    r"^(?:on passage\b|on motion to suspend the rules and (?:pass|agree to)\b|"
    r"on (?:agreeing to|adoption of) (?:the )?(?:resolution|concurrent resolution)\b)",
    re.IGNORECASE,
)
_VOTE_FAILED = re.compile(r"\b(?:failed|rejected|not agreed to)\b", re.IGNORECASE)
_VOTE_PASSED = re.compile(r"\b(?:passed|agreed to)\b", re.IGNORECASE)
# A motion's result is the motion's, not the measure's: "Motion to proceed to consideration of measure agreed to in
# Senate", "Motion to table the motion to reconsider the vote by which S.J. Res. 49 failed of passage ... agreed to".
# 516 actions of the 108th-119th read passage this way (bill family ``fd1bb730...``, 2026-10-03), 46 bills' stage.
_PROCEDURAL_MOTION = re.compile(r"^(?:\w+ )?motion\b|^point of order\b")
# "Disagreed to in Senate by Yea-Nay Vote. 47 - 48." is the measure failing, which the Library of Congress codes 18000
# beside it; the substring "agreed to in senate" read it as passage (8 bills of the 108th-119th). A conference report
# "disagreed to in House" is the report's, not the measure's, and stays with the conference rule.
_DISAGREED = re.compile(r"(?:^|\bwas )disagreed to in (?:the )?(?:house|senate)\b")


# The bare "calendar" matcher reads a placement on some calendar, not a span of calendar days, a calendar year or a
# nomination's calendar number, all of which action text states (House special rules: "through the calendar day of
# ..."; a Senate sequential referral "for 30 calendar days"). Since the chamber scope, such text no longer moves a
# measured stage on its own (119-s-1602's referral also says "placed on the calendar", in its own chamber); the
# pattern keeps the matcher's meaning honest for whatever text comes next.
_MATCHER_PATTERNS: Mapping[str, re.Pattern[str]] = MappingProxyType(
    {
        "calendar": re.compile(r"calendar(?! (?:days?|years?|numbers?)\b)"),
        "agreed to in house": re.compile(r"(?<!dis)agreed to in house"),
        "agreed to in senate": re.compile(r"(?<!dis)agreed to in senate"),
    }
)


def _found(matcher: str, lowered: str) -> bool:
    pattern = _MATCHER_PATTERNS.get(matcher)
    return matcher in lowered if pattern is None else pattern.search(lowered) is not None


def _scope_holds(rule: StageRule, matcher: str, origin_chamber: str | None, source_chamber: str | None) -> bool:
    """Whether a chamber-scoped matcher's action happened in the chamber its rule asks for -- the one the bill did not
    originate in, or with ``own_chamber`` the one it did -- as far as known; both sides must be known."""
    assert rule.chambers is not None
    chamber = rule.chambers[matcher]
    where = source_chamber if chamber == SOURCE_SYSTEM else chamber
    if where is None or origin_chamber is None:
        return False
    return (where == origin_chamber) if rule.own_chamber else (where != origin_chamber)


def infer_stage_from_text(
    text: str | None, *, origin_chamber: str | None = None, source_chamber: str | None = None
) -> StageFinding:
    """Classify an action or version description, retaining explicit non-progress outcomes.

    ``origin_chamber`` is the bill's (``HOUSE``/``SENATE``) and ``source_chamber`` the chamber whose system entered the
    action; a chamber-scoped matcher (see ``StageRule.chambers``) fires only where both sides are known and differ, so
    text read with neither -- a version description, a committee print's phrase -- reads no calendar or floor step as
    the other chamber.
    """
    if not text:
        return StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    lowered = text.lower().strip()
    for prefix in _VETO_PREFIXES:
        if lowered.startswith(prefix):
            return StageFinding("vetoed", "vetoed", prefix, text, None, None)
    passage_vote = _PASSAGE_VOTE.search(lowered)
    failed = (
        lowered.startswith("failed of passage")
        or (passage_vote and _VOTE_FAILED.search(lowered))
        or _DISAGREED.search(lowered)
    )
    if failed:
        stage = "vetoed" if "veto" in lowered or "objections of the president" in lowered else "failed"
        return StageFinding(stage, "failed_passage", "failed passage vote", text, None, None)
    if passage_vote and _VOTE_PASSED.search(lowered):
        return StageFinding("passed_chamber", "passed_chamber", "successful passage vote", text, None, None)
    # These actions describe a rule or a procedural question, not passage of
    # this bill. Upstream distinguishes vote-aux actions for the same reason.
    if lowered.startswith(("rule ", "on motion to recommit", "on motion to commit")):
        return StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    procedural = _PROCEDURAL_MOTION.match(lowered) is not None
    for rule in STAGE_RULES:
        if procedural and rule.stage == "passed_chamber":
            continue
        for matcher in rule.matchers:
            if not _found(matcher, lowered) or (rule.stage == "law" and not lowered.startswith(matcher)):
                continue
            if rule.chambers is not None and not _scope_holds(rule, matcher, origin_chamber, source_chamber):
                continue
            return StageFinding(rule.stage, rule.stage, matcher, text, None, None)
    return StageFinding(DEFAULT_STAGE, None, None, text, None, None)


# The passage and presentation rows of ``bill_actions.BILLSTATUS_ACTION_CODES``
# (passed/agreed to in House or Senate; presented to President).
_QUALIFIED_ACTION_CODES = {
    "8000": "passed_chamber",
    "17000": "passed_chamber",
    "28000": "presented",
    "E20000": "presented",
}


def infer_stage_from_action(action: object, *, bill_type: str | None = None) -> StageFinding:
    """Read qualified BILLSTATUS codes, then the action's complete text.

    The GPO guide warns that action codes were reused. E30000 is deliberately
    absent here: real veto and signature records both carry it. Failed/veto
    text wins over a contradictory passage code. Unknown codes fall back to
    text and do not manufacture a known event. ``bill_type`` (``hr``, ``sres``...)
    names the chamber of origin and the action's ``source_system_name`` the
    chamber it happened in; without them no calendar or floor step reads as
    the other chamber.
    """
    system = _field(action, "source_system_name")
    finding = infer_stage_from_text(
        _action_text(action),
        origin_chamber=ORIGIN_CHAMBERS.get(bill_type) if isinstance(bill_type, str) else None,
        source_chamber=SOURCE_SYSTEM_CHAMBERS.get(system) if isinstance(system, str) else None,
    )
    code = _field(action, "action_code", "actionCode")
    if _is_became_law(action):
        matcher = code or _field(action, "action_type", "type")
        return replace(finding, stage=LAW_STAGE, rule="became_law_code", matcher=str(matcher))
    if finding.stage in _OUTCOME_KEYS:
        return finding
    stage = _QUALIFIED_ACTION_CODES.get(code) if isinstance(code, str) else None
    return finding if stage is None else replace(finding, stage=stage, rule="action_code", matcher=code)


#: Once a bill has passed a chamber, an introduction or committee step -- the other chamber's referral or report, a
#: star print -- no longer moves the stage back.
_BEFORE_PASSAGE = frozenset({DEFAULT_STAGE, "committee", "calendared"})
_PASSED_RUNGS = frozenset(STAGE_KEYS[STAGE_KEYS.index("passed_chamber") :])
#: The Library of Congress's own statement that a chamber passed the measure (``bill_actions.BILLSTATUS_ACTION_CODES``
#: ``passed_house``/``passed_senate``), with that chamber.
_PASSAGE_CODE_CHAMBERS: Mapping[str, str] = MappingProxyType({"8000": HOUSE, "17000": SENATE})
#: A text passage reading that names its chamber, for a list whose actions name no system (bare strings).
_TEXT_PASSAGE_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {"passed house": HOUSE, "agreed to in house": HOUSE, "passed senate": SENATE, "agreed to in senate": SENATE}
)
#: The rungs a bill passed by both chambers outranks; a later rung (conference, presented, law) or an outcome stands.
_BELOW_PASSED_BOTH = frozenset({"passed_chamber", "other_chamber"})
#: The Senate's statement that an earlier passage no longer stands: "Senate vitiated previous passage." on 30 bills of
#: the 108th-119th (2026-10-03), after which the bill is passed again, returned to the calendar, postponed or
#: re-referred. No other wording of it, and no House one for a measure's passage, occurs there.
_VITIATED_PASSAGE = re.compile(r"\bvitiated previous passage\b", re.IGNORECASE)


def _action_chamber(action: object) -> str | None:
    system = _field(action, "source_system_name")
    return SOURCE_SYSTEM_CHAMBERS.get(system) if isinstance(system, str) else None


def infer_stage(actions: Iterable[object], *, newest_first: bool = False, bill_type: str | None = None) -> StageFinding:
    """Return the stage of the latest action any rule classifies, held once the bill has passed a chamber.

    ``actions`` holds ``BillAction`` records, mappings shaped like published
    action rows, or bare action-text strings, and text is read whole; a
    mapping carries the action's ``source_system_name`` as the published row
    does. ``bill_type`` is the measure's own type, read for the chamber of
    origin (``ORIGIN_CHAMBERS``). "Latest"
    is the later ``actionDate``, then the later place in the list; an undated
    action never outranks a dated one. A BILLSTATUS list runs newest first, so
    its caller passes ``newest_first=True`` and a day's first classified action
    is that day's latest. The list's order, not ``actionTime``, orders one
    day's actions: the publisher's order already follows the stated times and
    places the untimed Library of Congress actions among them, where the time
    alone would put a timed House vote after the untimed Senate receipt that
    followed it. Measured on the live ``bill_actions`` generation
    (``c28ed5b1…``, 930,779 actions, 2026-09-28): no adjacent pair runs
    forward in date, and none of 106,013 same-day timed pairs runs forward in
    time (receipt ``unitedstates-reuse-20260928/release-0.51.0/stage-replay/``).
    An action no rule classifies leaves the stage alone, enactment is terminal,
    and a veto remains until enactment is recorded.

    The stage never moves back once the bill has passed a chamber: a later
    ``introduced`` or ``committee`` reading (the other chamber's referral or
    report, a star print, an introduction phrase on the passing action) no
    longer outranks the passage or a later rung. Where the list carries
    publisher codes (any BILLSTATUS action does), only the Library of
    Congress's passage code (8000/17000) holds the stage, and text alone moves
    it as before; where it carries none, a passage read from text holds it. A
    "vitiated previous passage" voids that chamber's earlier passage, so a
    bill whose passage was vitiated and then re-referred reads ``committee``.

    ``passed_both`` is the bill's state, never one action's: where both
    chambers' passages stand (by code on a coded list, by text otherwise) and
    the latest reading is ``passed_chamber`` or ``other_chamber``, the stage is
    ``passed_both``, read from the passage that completed it.
    """
    findings: list[tuple[tuple[str, int], StageFinding, str | None]] = []
    vitiations: list[tuple[tuple[str, int], str | None]] = []
    coded = False
    for position, action in enumerate(actions):
        date = _action_date(action)
        key = (date or "", -position if newest_first else position)
        code = _field(action, "action_code", "actionCode")
        coded |= isinstance(code, str) and bool(code)
        text = _action_text(action)
        if text and _VITIATED_PASSAGE.search(text):
            vitiations.append((key, _action_chamber(action)))
        finding = infer_stage_from_action(action, bill_type=bill_type)
        if finding.rule is None:
            continue
        chamber = _PASSAGE_CODE_CHAMBERS.get(finding.matcher) if finding.rule == "action_code" else None
        chamber = chamber or _action_chamber(action) or _TEXT_PASSAGE_CHAMBERS.get(finding.matcher or "")
        findings.append((key, replace(finding, action_index=position, action_date=date), chamber))

    def stands(key: tuple[str, int], finding: StageFinding, chamber: str | None) -> bool:
        return finding.stage != "passed_chamber" or not any(
            key < vitiated and where in (None, chamber) for vitiated, where in vitiations
        )

    standing = [(key, finding, chamber) for key, finding, chamber in findings if stands(key, finding, chamber)]
    holds = (
        any(f.rule == "action_code" and f.matcher in _PASSAGE_CODE_CHAMBERS for _, f, _ in standing)
        if coded
        else any(f.stage in _PASSED_RUNGS for _, f, _ in standing)
    )
    # Each chamber's first standing passage: by the Library of Congress's code on a coded list, as for the hold, and by
    # a text passage the chamber's system entered (or the text names) on an uncoded one.
    first_passage: dict[str, tuple[tuple[str, int], StageFinding]] = {}
    for key, finding, chamber in sorted(standing, key=lambda item: item[0]):
        coded_passage = finding.rule == "action_code" and finding.matcher in _PASSAGE_CODE_CHAMBERS
        if chamber is not None and (coded_passage if coded else finding.stage == "passed_chamber"):
            first_passage.setdefault(chamber, (key, finding))
    candidates = [(key, f) for key, f, _ in standing if not holds or f.stage not in _BEFORE_PASSAGE]
    chosen = (
        max(((key, f) for key, f, _ in standing if f.stage == LAW_STAGE), default=None, key=lambda item: item[0])
        or max(((key, f) for key, f, _ in standing if f.stage == "vetoed"), default=None, key=lambda item: item[0])
        or max(candidates, default=None, key=lambda item: item[0])
    )
    if chosen is None:
        return StageFinding(DEFAULT_STAGE, None, None, None, None, None)
    if chosen[1].stage in _BELOW_PASSED_BOTH and len(first_passage) == len(ORIGIN_CHAMBERS_BY_NAME):
        # Both chambers have passed it: the stage is that state, read from the passage that completed it.
        _, completing = max(first_passage.values(), key=lambda item: item[0])
        return replace(completing, stage="passed_both", rule="passed_both")
    return chosen[1]


# The publisher's own identifiers for "became public law": ``36000`` is the
# Library of Congress code (``type`` "BecameLaw") and ``E40000`` the executive
# code carrying the same event; both appear on the same bill with the same
# date. ``type`` is checked too so a future code spelling still resolves.
BECAME_PUBLIC_LAW_ACTION_CODES = frozenset({"36000", "E40000"})
BECAME_PUBLIC_LAW_ACTION_TYPE = "BecameLaw"
PUBLIC_LAW_TYPE_TERM = "public"

SIGNED_DATE_RULES: tuple[str, ...] = (
    "public_law_and_became_law_action",
    "public_law_without_became_law_action",
    "no_public_law",
)


@dataclass(frozen=True, slots=True)
class SignedDateFinding:
    """``signed_date`` is ``None`` unless the coded action supplied one."""

    signed_date: str | None
    public_law_number: str | None
    rule: str
    action_index: int | None
    action_code: str | None


def _public_law_number(laws: object) -> str | None:
    if not isinstance(laws, Iterable) or isinstance(laws, str | Mapping):
        return None
    for entry in laws:
        law_type = _field(entry, "type")
        number = _field(entry, "number")
        if isinstance(law_type, str) and PUBLIC_LAW_TYPE_TERM in law_type.lower() and isinstance(number, str):
            return number
    return None


def _is_became_law(action: object) -> bool:
    code = _field(action, "action_code", "actionCode")
    if isinstance(code, str) and code in BECAME_PUBLIC_LAW_ACTION_CODES:
        return True
    action_type = _field(action, "action_type", "type")
    return isinstance(action_type, str) and action_type == BECAME_PUBLIC_LAW_ACTION_TYPE


def signed_date(status: object) -> SignedDateFinding:
    """Derive the signing date from the ``laws`` entry and the coded became-law action.

    ``status`` is a ``BillStatus`` -- which reads ``<laws>`` and each action's
    code -- or a mapping shaped like a published bill row carrying ``actions``
    and ``laws``. A public law entry without a coded action keeps the law
    number and reports ``public_law_without_became_law_action`` rather than
    falling back to a keyword scan of prose: measured zero on the 118th
    Congress's ``hr``/``s`` bulk zips, but an absent action is not a promise no
    future one will lack the code.
    """
    number = _public_law_number(_field(status, "laws"))
    if number is None:
        return SignedDateFinding(None, None, "no_public_law", None, None)
    actions = _field(status, "actions")
    if isinstance(actions, Iterable) and not isinstance(actions, str | Mapping):
        for position, action in enumerate(actions):
            if not _is_became_law(action):
                continue
            date = _field(action, "action_date", "actionDate")
            code = _field(action, "action_code", "actionCode")
            return SignedDateFinding(
                date if isinstance(date, str) else None,
                number,
                "public_law_and_became_law_action",
                position,
                code if isinstance(code, str) else None,
            )
    return SignedDateFinding(None, number, "public_law_without_became_law_action", None, None)


__all__ = [
    "BECAME_PUBLIC_LAW_ACTION_CODES",
    "BECAME_PUBLIC_LAW_ACTION_TYPE",
    "DEFAULT_STAGE",
    "HOUSE",
    "LAW_STAGE",
    "ORIGIN_CHAMBERS",
    "OUTCOME_STAGES",
    "SENATE",
    "SIGNED_DATE_RULES",
    "SOURCE_SYSTEM",
    "SOURCE_SYSTEM_CHAMBERS",
    "STAGES",
    "STAGE_KEYS",
    "STAGE_RULES",
    "SignedDateFinding",
    "Stage",
    "StageFinding",
    "StageRule",
    "infer_stage",
    "infer_stage_from_action",
    "infer_stage_from_text",
    "signed_date",
    "stage_index",
    "stage_progress",
]
