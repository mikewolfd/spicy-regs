"""The ``gao_decisions`` table: every legal decision page GAO's own Month in Review and Annual Index list.

Shaped from ``sources.gao.month_in_review``'s listed decisions and numbered others (a Contract Appeals Board docket,
a ``P`` number); a page GAO lists with no number is left out. The outcome is read by
``interpretation.gao_decisions`` and passed in, as a bill's stage is, so this module stays a leaf. Until round 5 the
host shaped these rows itself and called the release date ``decision_date``; it is ``released_date`` here because it
is when GAO released the decision, not when GAO decided it (B-424477: decided 2026-08-07, released 2026-08-28).
"""

from __future__ import annotations

import json

from spicy_docs.schemas.tables import Row, table_contract, text

#: GAO's site, which a listing's links are relative to.
GAO_SITE = "https://www.gao.gov"
#: The route that supplies every row: GAO's own Month in Review and Annual Index.
SOURCE = "gao_listing"

GAO_DECISIONS = table_contract(
    "gao_decisions",
    grain=(
        "One row per legal decision page GAO's own Month in Review or Annual Index lists with a number: every "
        "B-numbered decision and every docket- or P-numbered other. Federal Agency Major Rule Reports, B-numbered "
        "from April 2017, are products, not rows here."
    ),
    identity=("decision_number", "url"),
    version_column=None,
    columns={
        "decision_number": (
            "The decision's number as GAO's listing spells it, suffixes and all (`B-424129.2`, "
            "`B-423916.2,B-423916.3`, `B-235577.2-O.M.`, a docket `2020-02`). With `url`, the key."
        ),
        "b_numbers_json": (
            "JSON array of the B-numbers in `decision_number`, split on commas and semicolons; a fragment GAO cut "
            "mid-number is left out. `[]` for a docket- or P-numbered decision."
        ),
        "decision_type": (
            "GAO's label for the decision: `Bid Protest Decision`, `Appropriations Decision`, "
            "`Legal Other Decision` and the like."
        ),
        "title": (
            "The decision's heading as GAO's listing states it: the protester or the question decided. GAO "
            "double-escapes some headings, so a few keep `&mdash;`, `&#151;` or `&amp;` literally."
        ),
        "released_date": (
            "The listing's Publicly Released date (its Published date where it states no release), as an ISO date: "
            "when GAO released the decision, not when it decided it (B-424477: decided 2026-08-07, released "
            "2026-08-28). A count by fiscal year counts releases."
        ),
        "topics_json": "JSON array of GAO's headings the decision was listed under, in listed order.",
        "url": (
            "The decision's gao.gov page, as the listing links it (percent-encoded where GAO encodes it). With "
            "`decision_number`, the key."
        ),
        "listing_page": "The first Month in Review or Annual Index page that listed the decision, as requested.",
        "source": "The route that supplied the row: `gao_listing` (GAO's own Month in Review and Annual Index).",
        "decision_status": (
            "GAO's outcome sentence for the decision as its listing states it, word for word with HTML whitespace "
            "collapsed (`We deny the protest.`); NULL where the listing states none."
        ),
        "outcome": (
            "The outcome decision_status states, read by a closed table of GAO's exact sentences: `sustained`, "
            "`sustained_in_part`, `denied`, `dismissed`, `denied_in_part_dismissed_in_part`, or `request` where the "
            "sentence decides only a request (reconsideration, costs, reimbursement, dismissal); a sentence deciding "
            "the protest and a request reads the protest's outcome. "
            "NULL where no sentence is stated or the table does not read it (an advisory opinion, an appropriations "
            "opinion, a wording GAO wrote after the table was made): never a guess."
        ),
        "outcome_rule": (
            "The table that read outcome, `gao-decision-outcome/002`; NULL where outcome is NULL. A row read under an "
            "earlier table names that table."
        ),
    },
)


def shape_gao_decision(decision: object, *, outcome: object) -> Row:
    """One ``gao_decisions`` row for a listed decision or numbered other and its outcome finding.

    ``decision`` is a ``GaoListedDecision`` or ``GaoListedOther`` (an other states no B-numbers), and ``outcome`` the
    ``DecisionOutcome`` ``interpretation.gao_decisions.decision_outcome`` read from its status, both by attribute.
    """
    return {
        "decision_number": text(decision.product_number),
        "b_numbers_json": json.dumps(list(getattr(decision, "decision_numbers", ())), ensure_ascii=False),
        "decision_type": text(decision.label),
        "title": text(decision.heading),
        "released_date": text(decision.released or decision.published),
        "topics_json": json.dumps(list(decision.topics), ensure_ascii=False),
        "url": GAO_SITE + decision.link,
        "listing_page": text(decision.listing_page),
        "source": SOURCE,
        "decision_status": text(decision.status),
        "outcome": text(outcome.outcome),
        "outcome_rule": text(outcome.rule),
    }


__all__ = ["GAO_DECISIONS", "GAO_SITE", "SOURCE", "shape_gao_decision"]
