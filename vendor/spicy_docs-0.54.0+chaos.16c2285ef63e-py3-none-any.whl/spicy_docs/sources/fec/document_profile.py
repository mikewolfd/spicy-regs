"""Retained PDF page text and API response observations, without a traversal-completeness claim."""

from dataclasses import replace
from hashlib import sha256

from spicy_docs.extraction.pypdf import PdfPageError, PypdfReader
from spicy_docs.reading.pdf_bytes import check_pdf_bytes
from spicy_docs.releases.profile import SourceNativeBlobPage
from spicy_docs.sources.fec.delimited import selected_stream
from spicy_docs.sources.fec.metadata import api_page, parse_api, split_record
from spicy_docs.sources.fec.retained import decimal_strings
from spicy_docs.sources.fec.row_profile import (
    FEC_POSITIONAL_ROWS_PROFILE,
    MAX_PAGE_BYTES,
    positional_row_scope,
    row_pages,
)

MAX_DOCUMENT_BYTES = 256 * 1024**2
MAX_TEXT_BYTES = 128 * 1024


def document_scope(capture, *, format, backend_version=None, api_mode=None, member=None, max_records_per_page=1000):
    """Pin one original, selected member and explicit reader; partial API responses remain observations."""
    base = positional_row_scope(capture, format="fec", encoding="utf-8", member=member)
    if format == "pdf":
        if not isinstance(backend_version, str) or not 1 <= len(backend_version) <= 64 or not backend_version.strip():
            raise ValueError("PDF observations require an exact pypdf version")
        if api_mode is not None:
            raise ValueError("PDF observations have no API pagination mode")
    elif format == "api-json":
        if backend_version is not None or api_mode not in {"page", "keyset", "list", "legal", "docs", "raw"}:
            raise ValueError("API observations require an explicit response mode and no PDF backend")
    else:
        raise ValueError("select PDF or API JSON observations")
    if type(max_records_per_page) is not int or not 1 <= max_records_per_page <= 1000:
        raise ValueError("document page record bound is invalid")
    if base["capture"]["byteSize"] > MAX_DOCUMENT_BYTES:
        raise ValueError("document original exceeds its byte bound")
    return {
        "capture": base["capture"],
        "format": format,
        "backend_version": backend_version,
        "api_mode": api_mode,
        "member": base["member"],
        "max_records_per_page": max_records_per_page,
    }


def _scope(value):
    if not isinstance(value, dict) or set(value) != {
        "capture",
        "format",
        "backend_version",
        "api_mode",
        "member",
        "max_records_per_page",
    }:
        raise ValueError("document scope fields differ")
    return document_scope(**value)


def iter_retained_documents(scope, *, blob_source):
    """Hand the existing publisher exact original bytes, never an unpinned extraction sidecar."""
    capture = _scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0,
        0,
        "fec-rows://page/0",
        capture["responseSha256"],
        capture["byteSize"],
        blob_source,
        "application/zip" if capture["representation"] == "zip" else "application/octet-stream",
    )


def _pdf_records(raw, *, digest, backend_version):
    check_pdf_bytes(raw, error_type=ValueError, label="FEC PDF original")
    with PypdfReader(expected_backend_version=backend_version, max_input_bytes=MAX_DOCUMENT_BYTES).open(
        raw
    ) as document:
        source = {"sha256": digest, "backend": "pypdf", "backend_version": document.backend_version}
        yield {
            "kind": "pdf-document",
            "source": source,
            "page_count": document.page_count,
            "visual_completeness": "unqualified",
        }
        for number in range(1, document.page_count + 1):
            body = {
                "source_sha256": digest,
                "page": number,
                "backend": "pypdf",
                "backend_version": document.backend_version,
                "visual_completeness": "unqualified",
            }
            try:
                text = document.read_page(number)
                if text is not None and len(text.encode()) > MAX_TEXT_BYTES:
                    raise PdfPageError(number, "PDF page text exceeds the selected output byte bound")
                body.update(status="native-text-observation", text=text, native_empty=text is None or not text.strip())
            except PdfPageError as error:
                body.update(
                    status="native-extraction-refused",
                    text=None,
                    error_type=type(error).__name__,
                    reason=str(error)[:1000],
                )
            yield {"kind": "pdf-page", "source": {**source, "page": number}, "embedded_bodies": [body]}


def _api_records(raw, *, digest, url, mode):
    value = parse_api(raw)
    try:
        rows, _changes, _context = ([], None, {}) if mode == "raw" else api_page(value, url=url, mode=mode)
        shape_refusal = None
    except ValueError as error:
        rows, shape_refusal = [], str(error)
    source = {"sha256": digest, "response_mode": mode}
    # Preserve every top-level field in addition to row observations. This is a
    # single captured response, so counts/next-page controls are observed values.
    for key, native in value.items():
        yield {
            "kind": "api-response-field",
            "source": source,
            "field": key,
            "value": decimal_strings(native),
            "query_completeness": "not-asserted",
        }
    if shape_refusal is not None:
        yield {
            "kind": "api-response-shape-refusal",
            "source": source,
            "reason": shape_refusal,
            "query_completeness": "not-asserted",
        }
    for pointer, row in rows:
        parsed = split_record(row, source_pointer=pointer)
        bodies = []
        for body in parsed["embedded_bodies"]:
            native = value
            for part in body["source_pointer"].split("/")[1:]:
                key = part.replace("~1", "/").replace("~0", "~")
                native = native[int(key)] if isinstance(native, list) else native[key]
            bodies.append({**body, "text": native, "source_sha256": digest, "status": "source-embedded-text"})
        yield {
            "kind": "api-record-observation",
            "source": {**source, "pointer": pointer},
            "metadata": decimal_strings(parsed["metadata"]),
            "assets": parsed["assets"],
            "embedded_bodies": bodies,
            "query_completeness": "not-asserted",
        }


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = _scope(query_scope)
    capture = scope["capture"]
    expected_media = "application/zip" if capture["representation"] == "zip" else "application/octet-stream"
    if (request_key, evidence_ref, byte_size, media_type) != (
        "fec-rows://page/0",
        capture["responseSha256"],
        capture["byteSize"],
        expected_media,
    ):
        raise ValueError("document original differs from its selected capture")
    original = bytearray()
    while len(original) <= capture["byteSize"]:
        chunk = stream.read(min(1024**2, capture["byteSize"] + 1 - len(original)))
        if not chunk:
            break
        original.extend(chunk)
    original = bytes(original)
    if len(original) != capture["byteSize"] or "sha256:" + sha256(original).hexdigest() != capture["responseSha256"]:
        raise ValueError("document original bytes differ from their selected pin")
    from io import BytesIO

    with selected_stream(
        BytesIO(original), capture=capture, member=scope["member"], max_members=10000, max_decoded_bytes=512 * 1024**2
    ) as (decoded, member, digest):
        raw = decoded.read(MAX_DOCUMENT_BYTES + 1)
        if len(raw) > MAX_DOCUMENT_BYTES:
            raise ValueError("decoded document exceeds its byte bound")
        records = (
            _pdf_records(raw, digest=digest, backend_version=scope["backend_version"])
            if scope["format"] == "pdf"
            else _api_records(raw, digest=digest, url=capture["requestUrl"], mode=scope["api_mode"])
        )
        yield from row_pages(
            records, evidence_ref=evidence_ref, member=member, max_records_per_page=scope["max_records_per_page"]
        )


FEC_DOCUMENT_PROFILE = replace(
    FEC_POSITIONAL_ROWS_PROFILE,
    name="Retained FEC document and API observations",
    source_system_id="urn:spicy-docs:source:fec-document-originals",
    acquisition_policy_id="urn:spicy-docs:acquisition:fec-document-observations",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "One pinned PDF or API response; query traversal completeness is never inferred.",
            "PDF embedded text, empty text and page decoding refusal remain distinct; visual and OCR completeness are unqualified.",
            "The exact backend version is selected for PDF text. Original decoding or byte-integrity failure refuses the selection.",
            "API decimal values remain exact decimal strings; bodies and attachment pointers preserve original JSON coordinates.",
        ],
    },
    validate_query_scope=_scope,
    parse_file_stream=_parse_file,
)

__all__ = ["FEC_DOCUMENT_PROFILE", "document_scope", "iter_retained_documents"]
