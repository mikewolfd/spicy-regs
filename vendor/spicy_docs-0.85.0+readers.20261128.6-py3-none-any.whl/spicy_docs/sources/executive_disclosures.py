"""Publicly posted OGE Form 278e acquisition, native cover reader and ruled multi-part Excel parser.

Route A acquires explicitly selected zero-attestation PDFs from allowlisted official
White House archive hosts. Route B is an opt-in seam for publicly posted OGE Executive
Pay Level I/II direct PDF attachments, disabled by default unless the caller passes
``accepted_terms=True``; Form 201, agency requests, CAPTCHA bypasses and paid proxies
are always refused. Deterministic layout parsing reuses PyMuPDF's table reader
(``spicy-docs[pdf]``) with zero OCR or downstream financial interpretation.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING
from urllib.parse import unquote, urlsplit

from spicy_docs.reading.pdf_bytes import check_pdf_bytes
from spicy_docs.transport.captured import attach_capture, attached_capture
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_final_url,
    check_request_count,
    check_timing,
    limit_byte_bound,
)

if TYPE_CHECKING:
    import httpx

    from spicy_docs.transport.captured import CapturedBodyResponse

PARSER_REVISION = "oge-278e-excel-multi/1"
MAX_BYTES = 64 * 1024**2
MAX_PAGES = 512
DEFAULT_MAX_REQUESTS = 1
MAX_REQUESTS_CAP = 128
DEFAULT_MIN_REQUEST_INTERVAL_SECONDS = 0.5
DEFAULT_USER_AGENT = "spicy-docs-public-executive-disclosures/1.0"

ROUTE_A_HOSTS = frozenset(
    {
        "bidenwhitehouse.archives.gov",
        "trumpwhitehouse.archives.gov",
        "whitehouse.gov",
        "www.whitehouse.gov",
    }
)
ROUTE_B_HOSTS = frozenset(
    {
        "extapps2.oge.gov",
        "oge.gov",
        "www.oge.gov",
    }
)

SECTION = "Part 6: Other Assets and Income"
HEADER = ("#", "Description", "EIF", "Value", "Income Type", "Income Amount")
FIELDS = ("row_number_raw", "description_raw", "eif_raw", "value_raw", "income_type_raw", "income_amount_raw")

ASSET_INCOME_HEADER = HEADER
PART7_HEADER = ("#", "Description", "Type", "Date", "Amount")
PART7_FIELDS = ("row_number_raw", "description_raw", "transaction_type_raw", "transaction_date_raw", "amount_raw")

DEFAULT_SECTIONS = ("part2", "part5", "part6", "part7")
REPORT_TYPES = ("Annual", "New Entrant", "Nominee", "Termination", "Candidate")
COVER_REPORT_TYPES = (
    "Annual",
    "New Entrant",
    "Nominee",
    "Termination",
    "Candidate",
    "Amendment",
    "Periodic Transaction",
)
SUPPORTED_EXCEL_REVISIONS = ("Updated July 2020", "Updated Nov. 2021")

_ROW_LABEL_RE = re.compile(r"[1-9][0-9]*(?:\.[0-9]+)?\.?")
_ENDNOTE_RE = re.compile(r"^Endnote(?:\s+for\b|\s*:|\s+#|\s+lines?\b)", re.IGNORECASE)
_AMENDMENT_RE = re.compile(r"\b(amendment|amended|correction to part)\b", re.IGNORECASE)
_FORM278T_RE = re.compile(r"\bOGE\s+Form\s+278-T\b", re.IGNORECASE)
_INTERIOR_REVISION_RE = re.compile(r"OGE Form 278e\s*\(([^)\n]+)\)(?:\s*\(Expires\s+[^)\n]+\))?")
_COVER_REVISION_RE = re.compile(r"OGE Form 278e\s*\([^)\n]+\)(?:\s*\(Expires\s+[^)\n]+\))?")
_DIGITAL_SIG_DATE_RE = re.compile(r"Digitally signed by[\s\S]{0,160}?Date:\s*([0-9]{4})\.([0-9]{2})\.([0-9]{2})")
_ROUTE_A_PATH_RE = re.compile(
    r"/wp-content/uploads/[0-9]{4}/[0-9]{2}/(?:[A-Za-z0-9_.-]|%[0-9A-Fa-f]{2})+\.[Pp][Dd][Ff]"
)
_ROUTE_B_EXTAPPS_PATH_RE = re.compile(
    r"/201/Presiden\.nsf/(?:[A-Za-z0-9_.+-]|%[0-9A-Fa-f]{2})+/[0-9A-Fa-f]{32}/\$FILE/(?:[A-Za-z0-9_.+-]|%[0-9A-Fa-f]{2})+\.[Pp][Dd][Ff]",
    re.IGNORECASE,
)
_ROUTE_B_OGE_PATH_RE = re.compile(
    r"/web/oge\.nsf/(?:[A-Za-z0-9_.+-]|%[0-9A-Fa-f]{2})+/[0-9A-Fa-f]{32}/\$FILE/(?:[A-Za-z0-9_.+-]|%[0-9A-Fa-f]{2})+\.[Pp][Dd][Ff]",
    re.IGNORECASE,
)
_ENCODED_TRAVERSAL_RE = re.compile(r"%25|%2[ef]|%5c", re.IGNORECASE)
_FORBIDDEN_URL_TOKENS = (
    "201 request",
    "form201",
    "form-201",
    "form_201",
    "openform",
    "createdocument",
    "agencyrequest",
    "requestform",
    "captcha",
)
_FORBIDDEN_NON_FILENAME_TOKENS = ("login", "signin")
_CAPTCHA_BODY_RE = re.compile(
    r"(?:g-recaptcha|h-captcha|cf-turnstile|turnstile|recaptcha|hcaptcha|verify you are human|are you a robot|"
    r"checking your browser|just a moment|cloudflare|attention required|bot protection|challenge-platform)",
    re.IGNORECASE,
)
_FORM201_BODY_RE = re.compile(
    r"(?:oge\s+form\s+201|form\s+201\b|201\s+request|request\s+an\s+individual['’]?s\s+financial\s+disclosure|"
    r"unlawful\s+use\s+prohibition|ethics\s+in\s+government\s+act\s+prohibits|i\s+agree\s+to\s+the\s+terms)",
    re.IGNORECASE,
)
_LOGIN_BODY_RE = re.compile(
    r"(?:<input[^>]+type=[\"']?password[\"']?|\bsign\s+in\b|\blog\s+in\b|authentication\s+required|"
    r"access\s+denied|unauthorized\s+access)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class SectionSpec:
    """Qualified ruled section definition for Excel-exported OGE Form 278e."""

    code: str
    short_name: str
    heading: str
    kind: str  # "asset_income" | "transaction"
    header: tuple[str, ...]
    fields: tuple[str, ...]


SECTION_SPECS: dict[str, SectionSpec] = {
    "part2": SectionSpec(
        code="part2",
        short_name="Part 2",
        heading="Part 2: Filer's Employment Assets & Income and Retirement Accounts",
        kind="asset_income",
        header=ASSET_INCOME_HEADER,
        fields=FIELDS,
    ),
    "part5": SectionSpec(
        code="part5",
        short_name="Part 5",
        heading="Part 5: Spouse's Employment Assets & Income and Retirement Accounts",
        kind="asset_income",
        header=ASSET_INCOME_HEADER,
        fields=FIELDS,
    ),
    "part6": SectionSpec(
        code="part6",
        short_name="Part 6",
        heading="Part 6: Other Assets and Income",
        kind="asset_income",
        header=ASSET_INCOME_HEADER,
        fields=FIELDS,
    ),
    "part7": SectionSpec(
        code="part7",
        short_name="Part 7",
        heading="Part 7: Transactions",
        kind="transaction",
        header=PART7_HEADER,
        fields=PART7_FIELDS,
    ),
}


@dataclass(frozen=True)
class LayoutProfile:
    """Registered deterministic OGE PDF layout profile and review status."""

    name: str
    form_type: str
    supported: bool
    parser_revision: str | None
    description: str


LAYOUT_PROFILES: dict[str, LayoutProfile] = {
    "excel_278e": LayoutProfile(
        name="excel_278e",
        form_type="278e",
        supported=True,
        parser_revision=PARSER_REVISION,
        description=(
            "Ruled Excel-exported OGE Form 278e (Updated July 2020 and Updated Nov. 2021) "
            "Parts 2, 5, 6, and 7 with native cover verification and continuation-page support."
        ),
    ),
    "integrity_278e": LayoutProfile(
        name="integrity_278e",
        form_type="278e",
        supported=False,
        parser_revision=None,
        description=(
            "OGE Integrity-exported Form 278e layout; unsupported until real retained samples "
            "are acquired and visually reviewed."
        ),
    ),
    "integrity_278t": LayoutProfile(
        name="integrity_278t",
        form_type="278-T",
        supported=False,
        parser_revision=None,
        description=(
            "OGE Integrity-exported Form 278-T periodic transaction layout; unsupported until real "
            "retained samples are acquired and visually reviewed."
        ),
    ),
}


class ExecutiveDisclosureError(ValueError):
    """The selected response does not prove the requested filing or section."""


class UnsupportedDisclosure(ExecutiveDisclosureError):
    """The format, section, layout profile or amendment needs separate qualification."""


class DisclosureUnavailable(ExecutiveDisclosureError):
    """HTTP absence at this locator, never proof that the report does not exist."""

    def __init__(self, capture: CapturedBodyResponse):
        super().__init__(f"public filing locator answered HTTP {capture.status_code}")
        self.capture = capture


def get_layout_profile(name: str) -> LayoutProfile:
    """Return a registered OGE layout profile or refuse unknown profile names."""
    profile = LAYOUT_PROFILES.get(name)
    if profile is None:
        raise UnsupportedDisclosure(f"unknown OGE layout profile {name!r}")
    return profile


def _decode_url_fixed_point(value: str, *, error_message: str, max_rounds: int = 5) -> str:
    """Iteratively percent-decode ``value`` to a fixed point; refuse non-converging multi-encoding."""
    current = value
    for _ in range(max_rounds):
        decoded = unquote(current)
        if decoded == current:
            return decoded
        current = decoded
    raise ExecutiveDisclosureError(error_message)


def _check_no_traversal(path: str, error_message: str) -> None:
    if ".." in path or _ENCODED_TRAVERSAL_RE.search(path) or "\\" in path:
        raise ExecutiveDisclosureError(error_message)
    decoded = _decode_url_fixed_point(path, error_message=error_message)
    if ".." in decoded or "\\" in decoded:
        raise ExecutiveDisclosureError(error_message)


def public_archive_url(url: str) -> str:
    """Allow Route A zero-attestation official archived White House PDFs; refuse all other routes."""
    if not isinstance(url, str) or not url:
        raise ExecutiveDisclosureError("only explicit publicly posted archived White House PDFs are qualified")
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or parsed.netloc not in ROUTE_A_HOSTS
        or parsed.query
        or parsed.fragment
        or not _ROUTE_A_PATH_RE.fullmatch(parsed.path)
    ):
        raise ExecutiveDisclosureError("only explicit publicly posted archived White House PDFs are qualified")
    _check_no_traversal(parsed.path, "only explicit publicly posted archived White House PDFs are qualified")
    return url


def public_filing_url(url: str) -> str:
    """Backward-compatible Route A validator; never reach Form 201 or an attestation route."""
    return public_archive_url(url)


def oge_public_level12_url(url: str) -> str:
    """Validate Route B direct PDF postings on OGE Level I/II hosts; always hard-refuse Form 201."""
    if not isinstance(url, str) or not url:
        raise ExecutiveDisclosureError("only explicit publicly posted OGE Level I/II PDF attachments are qualified")
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc not in ROUTE_B_HOSTS or parsed.query or parsed.fragment:
        raise ExecutiveDisclosureError(
            "Route B allows only HTTPS OGE Level I/II direct PDF attachments without query strings or Form 201 routes"
        )
    _check_no_traversal(
        parsed.path,
        "Route B allows only HTTPS OGE Level I/II direct PDF attachments without path traversal",
    )
    decoded_url_lower = _decode_url_fixed_point(
        url,
        error_message="Route B allows only HTTPS OGE Level I/II direct PDF attachments without multi-encoding",
    ).lower()
    if any(token in decoded_url_lower for token in _FORBIDDEN_URL_TOKENS):
        raise ExecutiveDisclosureError(
            "Form 201, agency requests, login and attestation endpoints are always refused; "
            "Form 201 remains a human access step"
        )
    decoded_path_lower = _decode_url_fixed_point(
        parsed.path,
        error_message="Route B allows only HTTPS OGE Level I/II direct PDF attachments without multi-encoding",
    ).lower()
    prefix_before_file = decoded_path_lower.split("/$file/", 1)[0]
    if any(token in prefix_before_file for token in _FORBIDDEN_NON_FILENAME_TOKENS):
        raise ExecutiveDisclosureError(
            "Form 201, agency requests, login and attestation endpoints are always refused; "
            "Form 201 remains a human access step"
        )
    if parsed.netloc == "extapps2.oge.gov":
        if not _ROUTE_B_EXTAPPS_PATH_RE.fullmatch(parsed.path):
            raise ExecutiveDisclosureError(
                "Route B extapps2.oge.gov URL must target a direct /201/Presiden.nsf/.../$FILE/*.pdf attachment"
            )
    elif not _ROUTE_B_OGE_PATH_RE.fullmatch(parsed.path):
        raise ExecutiveDisclosureError(
            "Route B oge.gov URL must target a direct /web/oge.nsf/.../$FILE/*.pdf attachment"
        )
    return url


def classify_filing_url(url: str) -> tuple[str, str]:
    """Classify a candidate URL as ``route_a`` (zero-attestation WH) or ``route_b`` (OGE Level I/II)."""
    if not isinstance(url, str) or not url:
        raise ExecutiveDisclosureError("only explicit publicly posted executive disclosure PDFs are qualified")
    parsed = urlsplit(url)
    if parsed.netloc in ROUTE_B_HOSTS:
        return "route_b", oge_public_level12_url(url)
    return "route_a", public_archive_url(url)


def _check_non_pdf_challenge(body: bytes, *, route: str) -> None:
    """Refuse HTML, CAPTCHA, Form 201, login, or bot-challenge payloads with explicit diagnostics."""
    if body.startswith(b"%PDF-"):
        return
    sample = body[:65536].decode("utf-8", errors="ignore")
    if _CAPTCHA_BODY_RE.search(sample):
        raise ExecutiveDisclosureError(
            f"public OGE filing ({route}) returned a CAPTCHA or bot-challenge page; automated bypass is refused"
        )
    if _FORM201_BODY_RE.search(sample):
        raise ExecutiveDisclosureError(
            f"public OGE filing ({route}) returned a Form 201 or terms-attestation page; "
            "Form 201 remains a human access step"
        )
    if _LOGIN_BODY_RE.search(sample):
        raise ExecutiveDisclosureError(
            f"public OGE filing ({route}) returned a login or access-denied wall; access refused"
        )
    stripped = sample.lstrip()
    if stripped.startswith(("<html", "<!doctype", "<HTML", "<!DOCTYPE", "<head", "<body")):
        raise ExecutiveDisclosureError(f"public OGE filing ({route}) returned an HTML document instead of a PDF")


class ExecutiveDisclosureAcquirer(SourceAcquirer):
    """Acquire bounded public executive-disclosure PDFs with zero Form 201, CAPTCHA bypass or paid proxy.

    Route A (allowlisted official White House archives) requires no attestation.
    Route B (OGE Level I/II direct PDF attachments) is disabled by default and requires
    ``accepted_terms=True`` acknowledging 5 U.S.C. § 13107 unlawful-use restrictions.
    """

    def __init__(
        self,
        *,
        max_requests: int = DEFAULT_MAX_REQUESTS,
        timeout_seconds: float = 30.0,
        min_request_interval_seconds: float = DEFAULT_MIN_REQUEST_INTERVAL_SECONDS,
        max_bytes: int = MAX_BYTES,
        user_agent: str = DEFAULT_USER_AGENT,
        accepted_terms: bool = False,
        transport: httpx.BaseTransport | None = None,
    ):
        check_request_count(max_requests)
        if max_requests > MAX_REQUESTS_CAP:
            raise ExecutiveDisclosureError(f"max_requests must be at most {MAX_REQUESTS_CAP}")
        check_timing(timeout_seconds, min_request_interval_seconds)
        bounded_bytes = limit_byte_bound(
            max_bytes,
            name="max_bytes",
            cap=MAX_BYTES,
            error_type=ExecutiveDisclosureError,
        )
        if not isinstance(accepted_terms, bool):
            raise ExecutiveDisclosureError("accepted_terms must be a boolean")
        if not isinstance(user_agent, str) or not user_agent.strip() or any(ch in user_agent for ch in "\r\n"):
            raise ExecutiveDisclosureError("explicit single-line User-Agent is required")
        self._max_bytes = bounded_bytes
        self._accepted_terms = accepted_terms
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=timeout_seconds,
            min_request_interval_seconds=min_request_interval_seconds,
            user_agent=user_agent.strip(),
            label="public executive filing",
            error_type=ExecutiveDisclosureError,
            context_key="executive_disclosure_acquisition",
            transport=transport,
            keyless=True,
        )

    @property
    def accepted_terms(self) -> bool:
        return self._accepted_terms

    def _fetch_pdf(self, url: str, *, route: str) -> CapturedBodyResponse:
        parse_called = False

        def parse(capture: CapturedBodyResponse, _limit: int) -> str:
            nonlocal parse_called
            parse_called = True
            check_final_url(
                capture.resolved_url,
                url,
                error_type=ExecutiveDisclosureError,
                message="public filing response left its selected URL",
            )
            _check_non_pdf_challenge(capture.body, route=route)
            return check_pdf_bytes(capture.body, error_type=ExecutiveDisclosureError, label="public OGE filing")

        try:
            _, capture = self.capture_validated(
                url,
                media_types=("application/pdf", "application/octet-stream"),
                parse=parse,
                max_bytes=self._max_bytes,
                unavailable=DisclosureUnavailable,
                context={"operation": "public-posted-pdf", "route": route, "url": url},
                reset_budget=False,
                max_attempts=1,
            )
        except ExecutiveDisclosureError as error:
            if isinstance(error, DisclosureUnavailable) or parse_called:
                raise
            captured = attached_capture(error)
            if captured is not None and captured.status_code == 200:
                try:
                    _check_non_pdf_challenge(captured.body, route=route)
                except ExecutiveDisclosureError as specific:
                    attach_capture(specific, captured)
                    for attr in ("refused_response", self.context_key):
                        if attr in error.__dict__:
                            specific.__dict__[attr] = error.__dict__[attr]
                    raise specific from error
            raise
        return capture

    def acquire_pdf(self, url: str) -> CapturedBodyResponse:
        """Acquire a Route A PDF, or a Route B OGE Level I/II PDF when ``accepted_terms=True``."""
        route, validated = classify_filing_url(url)
        if route == "route_b" and self._accepted_terms is not True:
            raise ExecutiveDisclosureError(
                "Route B OGE Level I/II public collection is disabled by default; "
                "explicit accepted_terms=True acknowledging 5 U.S.C. § 13107 use restrictions is required"
            )
        return self._fetch_pdf(validated, route=route)

    def acquire_oge_level12_pdf(self, url: str) -> CapturedBodyResponse:
        """Acquire a validated Route B OGE Level I/II direct PDF attachment; requires ``accepted_terms=True``."""
        validated = oge_public_level12_url(url)
        if self._accepted_terms is not True:
            raise ExecutiveDisclosureError(
                "Route B OGE Level I/II public collection is disabled by default; "
                "explicit accepted_terms=True acknowledging 5 U.S.C. § 13107 use restrictions is required"
            )
        return self._fetch_pdf(validated, route="route_b")


@dataclass(frozen=True)
class CoverMetadata:
    """Deterministic native Form 278e cover observation, or explicit partial/unreadable status."""

    status: str  # "readable" | "partial" | "unreadable"
    reason: str | None
    cover_page: int
    filer_last: str | None
    filer_first: str | None
    filer_mi: str | None
    filer_name: str | None
    position_raw: str | None
    agency_raw: str | None
    report_type: str | None
    report_year: int | None
    report_period_raw: str | None
    appointment_or_termination_date_raw: str | None
    form_revision: str | None
    oge_digital_sig_date: str | None
    cover_fields: tuple[dict[str, str], ...]


@dataclass(frozen=True)
class ExecutiveDisclosureResult:
    """Deterministic multi-part Excel Form 278e reading preserving exact rows, transactions, and endnotes.

    On asset/income rows (Parts 2, 5, 6), ``income_amount_raw`` is always the canonical
    coalesced verbatim string across all revisions (both statutory bands and exact dollar
    amounts), whereas ``income_exact_raw`` records ONLY the split column-6 cell present on
    ``Updated Nov. 2021`` forms (on ``Updated July 2020`` single-column layouts, exact
    amounts appear in ``income_amount_raw`` with ``income_exact_raw == ""``). Downstream
    normalizers must therefore classify both bands and exact amounts from ``income_amount_raw``
    (or classify both ``income_amount_raw`` and ``income_exact_raw``).
    """

    source_sha256: str
    parser_revision: str
    backend_version: str
    layout_profile: str
    form_revision: str | None
    cover: CoverMetadata
    pages: tuple[dict, ...]
    rows: tuple[dict, ...]
    transactions: tuple[dict, ...]
    endnotes: tuple[dict, ...]

    @property
    def populated_rows(self) -> tuple[dict, ...]:
        return tuple(row for row in self.rows if not row["blank_slot"])

    @property
    def populated_transactions(self) -> tuple[dict, ...]:
        return tuple(row for row in self.transactions if not row["blank_slot"])


@dataclass(frozen=True)
class Part6Result:
    source_sha256: str
    parser_revision: str
    backend_version: str
    pages: tuple[dict, ...]
    rows: tuple[dict, ...]


def _name_spacing(value: str) -> str:
    """Ignore surrounding/repeated Unicode whitespace only; keep spelling, case and punctuation."""
    return " ".join(value.split())


def _has_cid_corruption(text: str) -> bool:
    """Detect CID-corrupted/unmapped font text layers (e.g. control-char bursts like Harris-2021 p1)."""
    if not text:
        return False
    control_count = sum(1 for ch in text if (ord(ch) < 32 and ch not in "\t\n\r") or ch == "\ufffd")
    return control_count >= 10 or (control_count / len(text)) >= 0.02


def _extract_digital_sig_date(text: str) -> str | None:
    match = _DIGITAL_SIG_DATE_RE.search(text)
    if match is None:
        return None
    return f"{match[1]}-{match[2]}-{match[3]}"


def _extract_cover_fields_from_tables(page) -> tuple[dict[str, str | None], str | None, list[dict[str, str]]]:
    """Read Report Type/Year/Date table and Filer's Information table on the cover page."""
    meta: dict[str, str | None] = {
        "report_type": None,
        "report_year_raw": None,
        "appointment_date_raw": None,
        "filer_last": None,
        "filer_first": None,
        "filer_mi": None,
        "filer_name": None,
        "position_raw": None,
        "agency_raw": None,
    }
    identity_labels = ("Last Name", "First Name", "MI")
    identity_matches: list[dict] = []
    identity_error: str | None = None

    for table in page.find_tables().tables:
        cells = table.extract()
        for row in cells:
            if not row or not isinstance(row[0], str):
                continue
            label = _name_spacing(row[0])
            value = next((cell for cell in row[1:] if isinstance(cell, str) and cell.strip()), None)
            if value is None and len(row) >= 2 and isinstance(row[1], str):
                value = row[1]
            if label == "Report Type:" and isinstance(value, str) and _name_spacing(value):
                meta["report_type"] = _name_spacing(value)
            elif label == "Year (Annual Report only):" and isinstance(value, str) and _name_spacing(value):
                meta["report_year_raw"] = _name_spacing(value)
            elif label == "Date of Appointment/Termination:" and isinstance(value, str) and _name_spacing(value):
                meta["appointment_date_raw"] = _name_spacing(value)

        for index, row in enumerate(cells[:-1]):
            normalized = [_name_spacing(cell) if isinstance(cell, str) else None for cell in row]
            if not all(label in normalized for label in identity_labels):
                continue
            if any(normalized.count(label) != 1 for label in identity_labels):
                identity_error = "ambiguous_cover_filer_identity"
                continue
            values = cells[index + 1]
            fields: list[dict[str, str]] = []
            missing_value = False
            for column, label in enumerate(normalized):
                if label not in identity_labels:
                    continue
                if column >= len(values) or not isinstance(values[column], str):
                    missing_value = True
                    break
                fields.append({"label_raw": row[column], "value_raw": values[column]})
            if missing_value:
                identity_error = "missing_cover_filer_identity_value"
                continue
            by_label = {_name_spacing(field["label_raw"]): field["value_raw"] for field in fields}
            if not all(_name_spacing(by_label[label]) for label in ("First Name", "Last Name")):
                identity_error = "empty_cover_filer_identity_value"
                continue
            position_raw = None
            agency_raw = None
            if normalized.count("Position") == 1:
                pos_col = normalized.index("Position")
                if pos_col < len(values) and isinstance(values[pos_col], str):
                    position_raw = _name_spacing(values[pos_col])
            if normalized.count("Agency") == 1:
                agency_col = normalized.index("Agency")
                if agency_col < len(values) and isinstance(values[agency_col], str):
                    agency_raw = _name_spacing(values[agency_col])
            identity_matches.append(
                {
                    "fields": fields,
                    "filer_last": _name_spacing(by_label["Last Name"]),
                    "filer_first": _name_spacing(by_label["First Name"]),
                    "filer_mi": _name_spacing(by_label["MI"]),
                    "filer_name": " ".join(
                        _name_spacing(by_label[label])
                        for label in ("First Name", "MI", "Last Name")
                        if _name_spacing(by_label[label])
                    ),
                    "position_raw": position_raw,
                    "agency_raw": agency_raw,
                }
            )

    if len(identity_matches) > 1:
        return meta, "ambiguous_cover_filer_identity", []
    if len(identity_matches) == 1:
        matched = identity_matches[0]
        meta["filer_last"] = matched["filer_last"]
        meta["filer_first"] = matched["filer_first"]
        meta["filer_mi"] = matched["filer_mi"]
        meta["filer_name"] = matched["filer_name"]
        meta["position_raw"] = matched["position_raw"]
        meta["agency_raw"] = matched["agency_raw"]
        return meta, None, matched["fields"]
    return meta, identity_error or "missing_cover_filer_identity", []


def _extract_cover_from_document(document, texts: list[str], *, cover_page: int = 1) -> CoverMetadata:
    """Extract deterministic native cover metadata without guessing on CID-corrupted or image covers."""
    if type(cover_page) is not int or not 1 <= cover_page <= len(document):
        raise ExecutiveDisclosureError("cover_page must be a valid one-based page number within the PDF")
    page = document[cover_page - 1]
    text = texts[cover_page - 1]
    if _FORM278T_RE.search(text):
        raise UnsupportedDisclosure(
            "OGE Form 278-T requires separate layout qualification (integrity_278t unsupported)"
        )
    sig_date = _extract_digital_sig_date(text)

    if _has_cid_corruption(text):
        return CoverMetadata(
            status="unreadable",
            reason="cid_corrupted_cover_text",
            cover_page=cover_page,
            filer_last=None,
            filer_first=None,
            filer_mi=None,
            filer_name=None,
            position_raw=None,
            agency_raw=None,
            report_type=None,
            report_year=None,
            report_period_raw=None,
            appointment_or_termination_date_raw=None,
            form_revision=None,
            oge_digital_sig_date=sig_date,
            cover_fields=(),
        )

    cover_flat = " ".join(text.split())
    rev_match = _COVER_REVISION_RE.search(text)
    form_revision = _name_spacing(rev_match[0]) if rev_match else None

    meta, identity_error, fields = _extract_cover_fields_from_tables(page)

    if meta["report_type"] is None:
        rt_pattern = "|".join(re.escape(rt) for rt in COVER_REPORT_TYPES)
        rt_match = re.search(rf"Report Type:\s*({rt_pattern})\b", cover_flat)
        if rt_match:
            meta["report_type"] = _name_spacing(rt_match[1])

    if meta["report_year_raw"] is None:
        year_match = re.search(r"Year \(Annual Report only\):\s*([0-9]{4})\b", cover_flat)
        if year_match:
            meta["report_year_raw"] = year_match[1]

    if meta["appointment_date_raw"] is None:
        appt_match = re.search(
            r"Date of Appointment/Termination:\s*([A-Za-z0-9,./ -]{4,40}?)(?=\s+(?:Executive Branch|Filer's Information|Last Name)\b|$)",
            cover_flat,
        )
        if appt_match and appt_match[1].strip():
            meta["appointment_date_raw"] = _name_spacing(appt_match[1])

    report_year: int | None = None
    if meta["report_year_raw"] is not None and re.fullmatch(r"[0-9]{4}", meta["report_year_raw"]):
        report_year = int(meta["report_year_raw"])

    report_period_raw = meta["report_year_raw"] or meta["appointment_date_raw"]
    report_type = meta["report_type"]

    has_any_cover_signal = any(
        (
            meta["filer_name"] is not None,
            report_type is not None,
            report_year is not None,
            form_revision is not None,
            "Report Type:" in cover_flat,
            "Filer's Information" in cover_flat,
            "OGE Form 278e" in cover_flat,
        )
    )
    if not has_any_cover_signal:
        return CoverMetadata(
            status="unreadable",
            reason="image_only_or_missing_cover_text",
            cover_page=cover_page,
            filer_last=None,
            filer_first=None,
            filer_mi=None,
            filer_name=None,
            position_raw=None,
            agency_raw=None,
            report_type=None,
            report_year=None,
            report_period_raw=None,
            appointment_or_termination_date_raw=None,
            form_revision=None,
            oge_digital_sig_date=sig_date,
            cover_fields=(),
        )

    partial_reason: str | None = None
    if identity_error is not None:
        partial_reason = identity_error
    elif report_type is None:
        partial_reason = "missing_report_type"
    elif report_type not in COVER_REPORT_TYPES:
        partial_reason = "unrecognized_report_type"
    elif report_type == "Annual" and report_year is None:
        partial_reason = "missing_annual_report_year"

    status = "readable" if partial_reason is None else "partial"
    return CoverMetadata(
        status=status,
        reason=partial_reason,
        cover_page=cover_page,
        filer_last=meta["filer_last"],
        filer_first=meta["filer_first"],
        filer_mi=meta["filer_mi"],
        filer_name=meta["filer_name"],
        position_raw=meta["position_raw"],
        agency_raw=meta["agency_raw"],
        report_type=report_type,
        report_year=report_year,
        report_period_raw=report_period_raw,
        appointment_or_termination_date_raw=meta["appointment_date_raw"],
        form_revision=form_revision,
        oge_digital_sig_date=sig_date,
        cover_fields=tuple(fields),
    )


def read_form278e_cover(body: bytes, *, cover_page: int = 1) -> CoverMetadata:
    """Deterministically read native OGE Form 278e cover metadata; never run OCR or guess fields.

    Returns ``CoverMetadata`` with ``status == "readable"`` when native cover text and labeled
    identity cells are clean, ``"partial"`` when cover text is present but required fields are
    missing or ambiguous, and ``"unreadable"`` when the cover page is CID-corrupted or image-only
    so callers may supply a reviewed ``cover_override`` or keep the filing lookup-only.
    """
    if not isinstance(body, bytes) or not body or len(body) > MAX_BYTES:
        raise ExecutiveDisclosureError("filing must be nonempty PDF bytes within the selected byte bound")
    check_pdf_bytes(body, error_type=ExecutiveDisclosureError, label="public OGE filing")
    import pymupdf

    with pymupdf.open(stream=body, filetype="pdf") as document:
        if document.is_encrypted or not 1 <= len(document) <= MAX_PAGES:
            raise UnsupportedDisclosure("encrypted or over-budget filing")
        if type(cover_page) is not int or not 1 <= cover_page <= len(document):
            raise ExecutiveDisclosureError("cover_page must be a valid one-based page number within the PDF")
        texts = [page.get_text() if idx == cover_page - 1 else "" for idx, page in enumerate(document)]
        return _extract_cover_from_document(document, texts, cover_page=cover_page)


def _section_filer_identity(table, cells: list, header: int, page: int, *, section_short: str) -> dict:
    """Read the value immediately below the native Filer's Name label in the qualified table."""
    labels = [
        index
        for index, row in enumerate(cells[:header])
        if row and isinstance(row[0], str) and _name_spacing(row[0]) == "Filer's Name"
    ]
    if len(labels) != 1 or labels[0] + 1 >= header:
        raise ExecutiveDisclosureError(f"{section_short} Filer's Name field is missing or ambiguous")
    index = labels[0]
    value = cells[index + 1][0]
    if not isinstance(value, str) or not _name_spacing(value):
        raise ExecutiveDisclosureError(f"{section_short} Filer's Name value is missing or empty")
    return {
        "page": page,
        "label_raw": cells[index][0],
        "value_raw": value,
        "label_bbox": table.rows[index].cells[0],
        "value_bbox": table.rows[index + 1].cells[0],
    }


def _match_section_header(cells: list, spec: SectionSpec) -> int | None:
    """Find the single exact column header row for ``spec`` and verify the section title precedes it."""
    headers = []
    for index, row in enumerate(cells):
        if spec.kind == "asset_income":
            if len(row) in (6, 7) and tuple(row[:6]) == spec.header and (len(row) == 6 or row[6] in (None, "")):
                headers.append(index)
        else:
            if len(row) == 5 and tuple(row) == spec.header:
                headers.append(index)
    if not headers:
        return None
    if len(headers) != 1:
        raise UnsupportedDisclosure(f"ambiguous {spec.short_name} table header")
    header_index = headers[0]
    has_title = any(
        row and isinstance(row[0], str) and _name_spacing(row[0]) == spec.heading for row in cells[:header_index]
    )
    if not has_title:
        return None
    return header_index


def _is_endnote_row(raw: list) -> bool:
    """True when a table row is a full-width in-table Endnote banner (e.g. Part 2 / Part 5 endnotes)."""
    if not raw or not isinstance(raw[0], str):
        return False
    if not _ENDNOTE_RE.match(raw[0].strip()):
        return False
    return all(cell is None or cell == "" for cell in raw[1:])


def _parse_interior_revision(text: str) -> tuple[str | None, str | None]:
    """Return ``(full_banner, revision_tag)`` when an OGE Form 278e revision banner is present."""
    match = _INTERIOR_REVISION_RE.search(text)
    if match is None:
        return None, None
    return _name_spacing(match[0]), _name_spacing(match[1])


def _validate_sections(sections: Sequence[str]) -> tuple[SectionSpec, ...]:
    if not isinstance(sections, Sequence) or isinstance(sections, (str, bytes)) or not sections:
        raise UnsupportedDisclosure("select at least one qualified Form 278e section (part2, part5, part6, part7)")
    seen: set[str] = set()
    specs: list[SectionSpec] = []
    for code in sections:
        if not isinstance(code, str) or code not in SECTION_SPECS:
            raise UnsupportedDisclosure(
                f"unsupported Form 278e section {code!r}; qualified excel_278e sections are part2, part5, part6, part7"
            )
        if code in seen:
            raise ExecutiveDisclosureError(f"duplicate section {code!r} in selection")
        seen.add(code)
        specs.append(SECTION_SPECS[code])
    return tuple(specs)


def _validate_cover_for_reading(
    cover: CoverMetadata,
    *,
    report_year: int | None,
    report_types: tuple[str, ...],
    is_override: bool,
    page_count: int,
) -> dict:
    """Validate native cover or reviewed cover_override and build cover provenance dict."""
    if not is_override:
        if cover.status == "unreadable":
            raise UnsupportedDisclosure(
                f"scanned_or_unreadable_text_layer_ocr_paused: readable Form 278e cover required "
                f"({cover.reason}); OCR is disabled"
            )
        if cover.status == "partial":
            if cover.reason in {
                "missing_cover_filer_identity",
                "ambiguous_cover_filer_identity",
                "missing_cover_filer_identity_value",
                "empty_cover_filer_identity_value",
            }:
                raise ExecutiveDisclosureError(f"cover filer identity labels are missing or ambiguous ({cover.reason})")
            if cover.reason == "missing_annual_report_year":
                raise ExecutiveDisclosureError("native report year is missing on annual Form 278e cover")
            raise UnsupportedDisclosure(f"incomplete Form 278e cover metadata ({cover.reason})")
    else:
        if not isinstance(cover, CoverMetadata):
            raise ExecutiveDisclosureError("cover_override must be a CoverMetadata instance")
        if cover.status != "readable":
            raise ExecutiveDisclosureError(f"cover_override requires status='readable' (got {cover.status!r})")
        if type(cover.cover_page) is not int or not 1 <= cover.cover_page <= page_count:
            raise ExecutiveDisclosureError(f"cover_override cover_page must be an integer between 1 and {page_count}")
        if not isinstance(cover.filer_name, str) or not _name_spacing(cover.filer_name):
            raise ExecutiveDisclosureError("cover_override requires a nonempty filer_name")
        if not isinstance(cover.report_type, str) or not _name_spacing(cover.report_type):
            raise ExecutiveDisclosureError("cover_override requires a nonempty report_type")

    if cover.report_type == "Amendment":
        raise UnsupportedDisclosure("amendment requires explicit source review and reconciliation before facts")
    if cover.report_type not in report_types:
        raise UnsupportedDisclosure(
            f"Form 278e report type {cover.report_type!r} is unsupported for this selection; "
            f"allowed report types: {', '.join(report_types)}"
        )
    if cover.report_type == "Annual":
        if type(cover.report_year) is not int:
            raise ExecutiveDisclosureError("native report year is required for Annual Form 278e reports")
        if report_year is not None and cover.report_year != report_year:
            raise ExecutiveDisclosureError("native report year differs from selection; filename year is not a period")
    elif report_year is not None and cover.report_year is not None and cover.report_year != report_year:
        raise ExecutiveDisclosureError("native report year differs from selection; filename year is not a period")

    return {
        "page": cover.cover_page,
        "source": "override" if is_override else "native_cover",
        "fields": list(cover.cover_fields),
        "name": _name_spacing(cover.filer_name or ""),
        "report_type": cover.report_type,
        "report_year": cover.report_year,
    }


def _parse_asset_income_rows(
    table,
    page_rows: list,
    *,
    header: int,
    number: int,
    spec: SectionSpec,
) -> tuple[list[dict], list[dict]]:
    """Parse Part 2 / Part 5 / Part 6 rows, coalescing 7-column Income Amount and extracting Endnotes.

    ``income_amount_raw`` receives the coalesced verbatim amount from col 5 or col 6.
    ``income_exact_raw`` captures ONLY the split col-6 cell present on ``Updated Nov. 2021``
    forms; on ``Updated July 2020`` forms where exact amounts sit directly in col 5,
    ``income_amount_raw`` holds the exact dollar string and ``income_exact_raw`` is ``""``.
    """
    parsed_rows: list[dict] = []
    endnotes: list[dict] = []
    seen_labels: set[str] = set()
    slot_index = 0

    for offset, raw in enumerate(page_rows, header + 1):
        if _is_endnote_row(raw):
            endnotes.append(
                {
                    "section": spec.heading,
                    "section_code": spec.code,
                    "page": number,
                    "source_locator": f"#page={number}",
                    "table_row_index": offset,
                    "text_raw": raw[0],
                    "bbox_json": json.dumps(table.rows[offset].cells[0]),
                    "raw_cells_json": json.dumps(raw, ensure_ascii=False),
                }
            )
            continue

        if len(raw) not in (6, 7):
            raise UnsupportedDisclosure(f"unclassified {spec.short_name} columns")
        if any(not isinstance(cell, str) for cell in raw[:6]):
            raise UnsupportedDisclosure(f"merged or missing {spec.short_name} cells require review")
        if len(raw) == 7 and raw[6] is not None and not isinstance(raw[6], str):
            raise UnsupportedDisclosure(f"unclassified {spec.short_name} seventh column")

        band_raw = raw[5]
        exact_col_raw = raw[6] if len(raw) == 7 and raw[6] is not None else ""
        if band_raw.strip() and exact_col_raw.strip():
            raise UnsupportedDisclosure(
                f"ambiguous split {spec.short_name} Income Amount: both band and exact sub-columns are populated"
            )
        income_amount_raw = exact_col_raw if exact_col_raw.strip() else band_raw
        data_cells = (raw[1], raw[2], raw[3], raw[4], income_amount_raw)
        is_blank = all(cell == "" for cell in data_cells)

        row_label_raw = raw[0]
        if row_label_raw == "":
            if not is_blank:
                raise UnsupportedDisclosure(f"populated {spec.short_name} row is missing a row label")
            slot_index += 1
            row_key = f"{spec.code}:p{number}:slot{slot_index}"
        else:
            if not _ROW_LABEL_RE.fullmatch(row_label_raw.strip()):
                raise UnsupportedDisclosure(f"unrecognized {spec.short_name} row label")
            normalized_label = row_label_raw.strip().rstrip(".")
            if normalized_label in seen_labels:
                raise UnsupportedDisclosure(f"duplicate {spec.short_name} row labels on page {number} require review")
            seen_labels.add(normalized_label)
            slot_index += 1
            row_key = f"{spec.code}:p{number}:{normalized_label}"

        parsed_rows.append(
            {
                "section": spec.heading,
                "section_code": spec.code,
                "page": number,
                "slot_index": slot_index,
                "row_key": row_key,
                "row_number_raw": row_label_raw,
                "description_raw": raw[1],
                "eif_raw": raw[2],
                "value_raw": raw[3],
                "income_type_raw": raw[4],
                "income_amount_raw": income_amount_raw,
                "income_exact_raw": exact_col_raw,
                "source_locator": f"#page={number}",
                "blank_slot": is_blank,
                "raw_cells_json": json.dumps(raw, ensure_ascii=False),
                "cell_boxes_json": json.dumps(table.rows[offset].cells),
            }
        )
    return parsed_rows, endnotes


def _parse_transaction_rows(
    table,
    page_rows: list,
    *,
    header: int,
    number: int,
    spec: SectionSpec,
) -> tuple[list[dict], list[dict]]:
    """Parse 5-column Part 7 transaction rows with page-scoped row identity."""
    parsed_rows: list[dict] = []
    endnotes: list[dict] = []
    seen_labels: set[str] = set()
    slot_index = 0

    for offset, raw in enumerate(page_rows, header + 1):
        if _is_endnote_row(raw):
            endnotes.append(
                {
                    "section": spec.heading,
                    "section_code": spec.code,
                    "page": number,
                    "source_locator": f"#page={number}",
                    "table_row_index": offset,
                    "text_raw": raw[0],
                    "bbox_json": json.dumps(table.rows[offset].cells[0]),
                    "raw_cells_json": json.dumps(raw, ensure_ascii=False),
                }
            )
            continue

        if len(raw) != 5:
            raise UnsupportedDisclosure(f"unclassified {spec.short_name} columns")
        if any(not isinstance(cell, str) for cell in raw):
            raise UnsupportedDisclosure(f"merged or missing {spec.short_name} cells require review")

        data_cells = (raw[1], raw[2], raw[3], raw[4])
        is_blank = all(cell == "" for cell in data_cells)
        row_label_raw = raw[0]
        if row_label_raw == "":
            if not is_blank:
                raise UnsupportedDisclosure(f"populated {spec.short_name} row is missing a row label")
            slot_index += 1
            row_key = f"{spec.code}:p{number}:slot{slot_index}"
        else:
            if not _ROW_LABEL_RE.fullmatch(row_label_raw.strip()):
                raise UnsupportedDisclosure(f"unrecognized {spec.short_name} row label")
            normalized_label = row_label_raw.strip().rstrip(".")
            if normalized_label in seen_labels:
                raise UnsupportedDisclosure(f"duplicate {spec.short_name} row labels on page {number} require review")
            seen_labels.add(normalized_label)
            slot_index += 1
            row_key = f"{spec.code}:p{number}:{normalized_label}"

        parsed_rows.append(
            {
                "section": spec.heading,
                "section_code": spec.code,
                "page": number,
                "slot_index": slot_index,
                "row_key": row_key,
                "row_number_raw": row_label_raw,
                "description_raw": raw[1],
                "transaction_type_raw": raw[2],
                "transaction_date_raw": raw[3],
                "amount_raw": raw[4],
                "source_locator": f"#page={number}",
                "blank_slot": is_blank,
                "raw_cells_json": json.dumps(raw, ensure_ascii=False),
                "cell_boxes_json": json.dumps(table.rows[offset].cells),
            }
        )
    return parsed_rows, endnotes


def read_excel_278e(
    body: bytes,
    *,
    filer_name: str,
    report_year: int | None = None,
    sections: Sequence[str] = DEFAULT_SECTIONS,
    report_types: Sequence[str] = REPORT_TYPES,
    cover_override: CoverMetadata | None = None,
    layout_profile: str = "excel_278e",
    require_all_sections: bool = False,
) -> ExecutiveDisclosureResult:
    """Read ruled Excel-exported OGE Form 278e Parts 2, 5, 6, and 7 with zero OCR.

    Supports ``Updated July 2020`` and ``Updated Nov. 2021`` revisions, tolerates
    legitimate section continuation pages that omit the repeated revision header,
    coalesces Part 2's 7-column split Income Amount into ``income_amount_raw`` (with
    ``income_exact_raw`` capturing only the split col-6 cell on Nov. 2021 forms while
    July 2020 exact amounts live in ``income_amount_raw`` with ``income_exact_raw == ""``),
    extracts in-table Endnote rows, and assigns page-scoped row keys for Part 7.
    Unreviewed layouts (``integrity_278e``, ``integrity_278t``), Form 278-T,
    amendments, CID-corrupted or scanned pages, and identity mismatches fail closed.
    """
    profile = get_layout_profile(layout_profile)
    if not profile.supported:
        raise UnsupportedDisclosure(
            f"layout profile {profile.name!r} is unsupported pending retained originals and raw visual review"
        )
    specs = _validate_sections(sections)
    if not isinstance(body, bytes) or not body or len(body) > MAX_BYTES:
        raise ExecutiveDisclosureError("filing must be nonempty PDF bytes within the selected byte bound")
    if not isinstance(filer_name, str) or not filer_name.strip():
        raise ExecutiveDisclosureError("select an explicit filer name")
    if report_year is not None and type(report_year) is not int:
        raise ExecutiveDisclosureError("report_year must be an integer when provided")
    allowed_report_types = tuple(report_types)
    if not allowed_report_types or not all(isinstance(rt, str) and rt.strip() for rt in allowed_report_types):
        raise ExecutiveDisclosureError("report_types must be a nonempty sequence of report type names")

    check_pdf_bytes(body, error_type=ExecutiveDisclosureError, label="public OGE filing")
    import pymupdf

    rows: list[dict] = []
    transactions: list[dict] = []
    pages: list[dict] = []
    all_endnotes: list[dict] = []
    section_revisions: dict[str, str] = {}
    document_revision: str | None = None
    matched_section_codes: set[str] = set()

    with pymupdf.open(stream=body, filetype="pdf") as document:
        if document.is_encrypted or not 1 <= len(document) <= MAX_PAGES:
            raise UnsupportedDisclosure("encrypted or over-budget filing")

        texts = [page.get_text() for page in document]

        if any(_FORM278T_RE.search(text) for text in texts):
            raise UnsupportedDisclosure(
                "OGE Form 278-T requires separate layout qualification (integrity_278t unsupported)"
            )
        if any(_AMENDMENT_RE.search(text) for text in texts):
            raise UnsupportedDisclosure("amendment requires explicit source review and reconciliation before facts")

        for page_index, text in enumerate(texts, 1):
            if _has_cid_corruption(text):
                raise UnsupportedDisclosure(
                    f"scanned_or_unreadable_text_layer_ocr_paused: CID-corrupted text layer on page {page_index}; "
                    "OCR is disabled"
                )

        if cover_override is None:
            cover = _extract_cover_from_document(document, texts, cover_page=1)
            cover_identity = _validate_cover_for_reading(
                cover,
                report_year=report_year,
                report_types=allowed_report_types,
                is_override=False,
                page_count=len(document),
            )
            cover_page_number = cover.cover_page
        else:
            cover = cover_override
            cover_identity = _validate_cover_for_reading(
                cover,
                report_year=report_year,
                report_types=allowed_report_types,
                is_override=True,
                page_count=len(document),
            )
            cover_page_number = cover.cover_page

        for number, (page, text) in enumerate(zip(document, texts, strict=True), 1):
            if number != cover_page_number and len(page.get_images()) > 0 and len(text.strip()) < 100:
                raise UnsupportedDisclosure(
                    f"scanned_or_unreadable_text_layer_ocr_paused: image-only page {number} requires OCR which is disabled"
                )

            candidate_specs = [spec for spec in specs if spec.heading in text]
            if not candidate_specs:
                continue
            if len(candidate_specs) != 1:
                raise UnsupportedDisclosure(f"page {number} contains multiple section headings; ambiguous page layout")
            spec = candidate_specs[0]

            banner, rev_tag = _parse_interior_revision(text)
            if banner is not None:
                if rev_tag not in SUPPORTED_EXCEL_REVISIONS:
                    raise UnsupportedDisclosure(
                        f"{spec.short_name} form revision {rev_tag!r} differs from supported excel_278e revisions"
                    )
                if document_revision is not None and document_revision != rev_tag:
                    raise UnsupportedDisclosure(
                        f"mixed OGE Form 278e revisions within one filing ({document_revision!r} vs {rev_tag!r})"
                    )
                document_revision = rev_tag
                section_revisions[spec.code] = banner
                page_revision = banner
                revision_inherited = False
            else:
                if spec.code not in section_revisions:
                    raise UnsupportedDisclosure(
                        f"{spec.short_name} page {number} omits OGE Form 278e revision banner without a prior "
                        "qualified section page"
                    )
                if "Note: This is a public form." not in text and "Page Number" not in text:
                    raise UnsupportedDisclosure(
                        f"{spec.short_name} continuation page {number} is missing OGE public-form markers"
                    )
                page_revision = section_revisions[spec.code]
                revision_inherited = True

            found = page.find_tables().tables
            matches = []
            for table in found:
                cells = table.extract()
                header_index = _match_section_header(cells, spec)
                if header_index is not None:
                    matches.append((table, cells, header_index))
            if len(matches) != 1:
                raise UnsupportedDisclosure(f"complete ruled {spec.short_name} table required; no inferred columns")

            table, cells, header = matches[0]
            section_identity = _section_filer_identity(table, cells, header, number, section_short=spec.short_name)
            native_name = _name_spacing(section_identity["value_raw"])
            if native_name != cover_identity["name"]:
                raise ExecutiveDisclosureError(
                    f"cover/{spec.short_name} filer identity differs: cover name={cover_identity['name']!r}; "
                    f"native Filer's Name={section_identity['value_raw']!r}"
                )
            if native_name != _name_spacing(filer_name):
                raise ExecutiveDisclosureError(
                    f"{spec.short_name} filer identity differs from selection: declared={filer_name!r}; "
                    f"native Filer's Name={section_identity['value_raw']!r}"
                )

            identity_json = json.dumps(
                {
                    "section": section_identity,
                    "cover": {
                        "page": cover_identity["page"],
                        "fields": cover_identity["fields"],
                        "name": cover_identity["name"],
                        "source": cover_identity["source"],
                    },
                    "comparison_rule": "whitespace-only; cover order First Name MI Last Name",
                },
                ensure_ascii=False,
            )

            page_rows = cells[header + 1 :]
            if not page_rows:
                raise UnsupportedDisclosure(f"{spec.short_name} table has no source slots")

            if spec.kind == "asset_income":
                parsed, page_endnotes = _parse_asset_income_rows(
                    table,
                    page_rows,
                    header=header,
                    number=number,
                    spec=spec,
                )
                rows.extend(parsed)
            else:
                parsed, page_endnotes = _parse_transaction_rows(
                    table,
                    page_rows,
                    header=header,
                    number=number,
                    spec=spec,
                )
                transactions.extend(parsed)

            if not parsed:
                raise UnsupportedDisclosure(f"{spec.short_name} table on page {number} has no source slots")

            all_endnotes.extend(page_endnotes)
            matched_section_codes.add(spec.code)
            blank_count = sum(row["blank_slot"] for row in parsed)
            pages.append(
                {
                    "page": number,
                    "section": spec.heading,
                    "section_code": spec.code,
                    "layout_profile": profile.name,
                    "form_revision": page_revision,
                    "revision_inherited": revision_inherited,
                    "page_text": text,
                    "filer_identity_json": identity_json,
                    "source_locator": f"#page={number}",
                    "table_bbox_json": json.dumps(table.bbox),
                    "source_slot_count": len(parsed),
                    "populated_slot_count": len(parsed) - blank_count,
                    "blank_slot_count": blank_count,
                    "endnotes": tuple(page_endnotes),
                    "endnotes_json": json.dumps(page_endnotes, ensure_ascii=False),
                }
            )

        if not pages:
            if len(specs) == 1:
                raise UnsupportedDisclosure(
                    f"no readable qualified {specs[0].short_name}; absence is not an empty disclosure"
                )
            raise UnsupportedDisclosure("no readable qualified Form 278e sections; absence is not an empty disclosure")
        if require_all_sections:
            missing = [spec.code for spec in specs if spec.code not in matched_section_codes]
            if missing:
                raise UnsupportedDisclosure(f"required Form 278e sections absent: {', '.join(missing)}")

    return ExecutiveDisclosureResult(
        source_sha256="sha256:" + hashlib.sha256(body).hexdigest(),
        parser_revision=PARSER_REVISION,
        backend_version=pymupdf.VersionBind,
        layout_profile=profile.name,
        form_revision=document_revision,
        cover=cover,
        pages=tuple(pages),
        rows=tuple(rows),
        transactions=tuple(transactions),
        endnotes=tuple(all_endnotes),
    )


def read_part6(body: bytes, *, filer_name: str, report_year: int, section: str = SECTION) -> Part6Result:
    """Backward-compatible wrapper reading Annual Form 278e Part 6 via ``read_excel_278e``."""
    if section != SECTION:
        raise UnsupportedDisclosure("only Form 278e Part 6 is qualified; other sections and 278-T are unsupported")
    if not isinstance(filer_name, str) or not filer_name.strip() or type(report_year) is not int:
        raise ExecutiveDisclosureError("select an explicit filer name and native annual report year")
    result = read_excel_278e(
        body,
        filer_name=filer_name,
        report_year=report_year,
        sections=("part6",),
        report_types=("Annual",),
    )
    # Preserve baseline filing-wide Part 6 label uniqueness for legacy callers keying
    # fact_id without page; multi-part callers use read_excel_278e() with page-scoped row_key.
    labels = [row["row_number_raw"].strip().rstrip(".") for row in result.rows if row["row_number_raw"].strip()]
    if len(labels) != len(set(labels)):
        raise UnsupportedDisclosure("duplicate Part 6 row labels require review")
    legacy_pages = tuple(
        {
            "page": page["page"],
            "page_text": page["page_text"],
            "filer_identity_json": page["filer_identity_json"],
            "source_locator": page["source_locator"],
            "table_bbox_json": page["table_bbox_json"],
            "source_slot_count": page["source_slot_count"],
        }
        for page in result.pages
    )
    legacy_rows = tuple(
        {
            "row_number_raw": row["row_number_raw"],
            "description_raw": row["description_raw"],
            "eif_raw": row["eif_raw"],
            "value_raw": row["value_raw"],
            "income_type_raw": row["income_type_raw"],
            "income_amount_raw": row["income_amount_raw"],
            "page": row["page"],
            "source_locator": row["source_locator"],
            "blank_slot": row["blank_slot"],
            "raw_cells_json": row["raw_cells_json"],
            "cell_boxes_json": row["cell_boxes_json"],
        }
        for row in result.rows
    )
    return Part6Result(
        result.source_sha256,
        result.parser_revision,
        result.backend_version,
        legacy_pages,
        legacy_rows,
    )
