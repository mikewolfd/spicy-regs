"""GAO's Congressional Review Act listing, Reports on Major Rules: its major-rule reports from FY2001 on, and before.

GAO lists the reports it makes under 5 U.S.C. 801(a)(2)(A) at ``/legal/congressional-review-act/reports-on-major-
rules`` ("Your search results will include any reports on major rules GAO has issued"). Probed 2026-09-29
(``corpora/fork-execution-2026-09-21/gao-cra-major-rules/EXPLORE.md``), it is one Drupal view of six teasers a page,
newest release first, paged by an infinite-scroll pager: ``?page=%2CN`` (the view's pager is element 1), a "Load
More" link on every page but the last, no total and no last-page link. A page past the end answers 200 with no view
at all, so only a page with teasers and no "Load More" ends the listing. Each teaser states the product link, the
title (GAO's heading, ``Agency: Rule``), the product number and GAO's issue date ("Published"); nothing else.

It is the one current GAO listing that reaches back before 2009: GAO-numbered reports from November 2000 on
(``GAO-01-...R``), and of the OGC-numbered ones before that only OGC-99-12; ``major_rule_old_index`` reads those
from the index GAO kept then, and its reports join the same merge. Its tail also lists GAO products that are not
major-rule reports, and two legal opinions, so the number decides what a listed page is (:data:`KINDS`). A report the
Month in Review lists too is one product, its row first: :func:`merge_with_month_in_review` states the precedence.

``www.gao.gov`` refuses plain clients, so pages come through Zyte, walked by ``listing.py``: one worker, one request
every 420 seconds (``robots.txt``'s ``Crawl-delay``), under a hard Zyte budget, resuming from its receipts.
``robots.txt`` disallows the CRA rules database's query URLs but not this listing.
"""

from __future__ import annotations

import argparse
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, replace
from html.parser import HTMLParser
from pathlib import Path
from typing import Final
from urllib.parse import unquote

from spicy_docs.reading.markup import HTML_VOID_TAGS, decode_html_page, feed_html
from spicy_docs.sources.gao.listing import (
    DEFAULT_MAX_PAGE_BYTES,
    MAX_PAGE_BYTES,
    GaoListingMovedError,
    GaoListingSourceError,
    RetainedListingPage,
    add_read_arguments,
    add_walk_arguments,
    listing_date,
    listing_text,
    read_retained_pages,
    spelled,
    walk_command,
    write_items,
)
from spicy_docs.sources.gao.month_in_review import MAJOR_RULE_REPORT, GaoListedProduct
from spicy_docs.sources.gao.native import TRAILING_DUPLICATE_PATH, GaoProductSourceError, gao_product_id, names_page

LISTING_URL: Final = "https://www.gao.gov/legal/congressional-review-act/reports-on-major-rules"
_PATH: Final = "/legal/congressional-review-act/reports-on-major-rules"
#: The walk's receipt key for the one scope this listing has.
SCOPE_KEY: Final = "reports-on-major-rules"
#: The last page was index 364 on 2026-09-29 and 2026-10-04 (2,189 teasers); a deeper pager is refused, not walked.
DEFAULT_MAX_LAST_PAGE_INDEX: Final = 999
_TITLE: Final = "Reports on Major Rules | U.S. GAO"
_LABEL: Final = "GAO major-rule listing page"
#: The listing's own view; its search form's ``action`` echoes the query the page answered.
_VIEW_CLASS: Final = "view--products--block-17"
_FORM_ID: Final = "major-rules-search-auto-form"
#: The page's own node, which wraps the view. GAO's theme printed it as a ``div`` on 2026-09-29 and as an ``article``
#: by 2026-10-03 (the decision pages captured that day, and this listing on 2026-10-04); as an ``article`` it is the
#: page, not a teaser, and any other ``article`` outside the view still refuses.
_PAGE_NODE: Final = frozenset({"node--type-page", "node--view-mode-full"})
_FIELD_CLASSES: Final = {
    "field--name-field-product-number": "number",
    "field--name-field-issue-date": "published",
}
#: A listed page's kind, from its number: the listing names no label, and its tail holds GAO products that are not
#: major-rule reports, so the number decides, as in the Month in Review.
#: ``report``: a number GAO gave major-rule reports, ``GAO-`` (November 2000 to February 2017) or ``OGC-``, the
#: General Counsel's, whose office writes them (before then). A product, on this listing's word.
REPORT: Final = "report"
#: ``b-numbered``: a major-rule report from April 2017 by the Month in Review's label, which decides, or a legal
#: decision (B-286338 and B-287557, 2000-2001 opinions on whether an action is a rule). Not a product on this listing's word.
B_NUMBERED: Final = "b-numbered"
#: ``other``: another division's number (``AIMD-``, ``GGD-``) or none, a GAO product this listing shows that is no
#: major-rule report (reviews of federally chartered corporations' audits, a report about major rules). An ordinary
#: product when numbered (owner ruling 2026-10-04), with no label; a page with no number stays apart.
OTHER: Final = "other"
KINDS: Final = (REPORT, B_NUMBERED, OTHER)
_REPORT_PREFIXES: Final = ("GAO-", "OGC-")


@dataclass(frozen=True, slots=True)
class GaoMajorRuleListing:
    """The listing's one scope, every page of it."""

    @property
    def key(self) -> str:
        return SCOPE_KEY

    def page_url(self, page_index: int) -> str:
        """The first page is the bare URL; later pages are its "Load More" link, ``?page=%2CN``."""
        return LISTING_URL if page_index == 0 else f"{LISTING_URL}?page=%2C{page_index}"

    def parse_page(
        self,
        body: bytes,
        *,
        page_index: int,
        max_bytes: int,
        max_last_page_index: int,
        expected_last_page_index: int | None,
        expected_page_size: int | None,
    ) -> GaoMajorRulePage:
        return parse_major_rule_page(
            body,
            page_index=page_index,
            max_bytes=max_bytes,
            max_last_page_index=max_last_page_index,
            expected_last_page_index=expected_last_page_index,
            expected_page_size=expected_page_size,
        )


LISTING: Final = GaoMajorRuleListing()


def _scope_of(key: str) -> GaoMajorRuleListing:
    if key != SCOPE_KEY:
        raise GaoListingSourceError(f"receipts name scope {key!r}, not the major-rule listing's {SCOPE_KEY!r}")
    return LISTING


@dataclass(frozen=True, slots=True)
class GaoMajorRuleEntry:
    """One teaser as GAO spelled it, keyed on the product page it links."""

    position: int
    product_id: str
    product_number: str | None
    link: str
    title: str
    published: str | None


@dataclass(frozen=True, slots=True)
class GaoMajorRulePage:
    page_index: int
    #: This page's index when it is the last; None while its "Load More" says another page follows.
    last_page_index: int | None
    entries: tuple[GaoMajorRuleEntry, ...]


class _MajorRuleHtml(HTMLParser):
    """The head's title and canonical link, the search form's action, and inside the view, teasers and the pager."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.titles: list[list[str]] = []
        self.canonicals: list[str] = []
        self.actions: list[str] = []
        self.views = 0
        self.pagers = 0
        self.next_links: list[str] = []
        self.teasers: list[dict] = []
        self._head = self._main = 0
        self._title: list[str] | None = None
        #: Open ``div``s inside the view, the view's own included; 0 outside it.
        self._view_divs = 0
        self._in_pager = False
        self._teaser: dict | None = None
        #: Open elements inside the current teaser, each with the role its text takes, if any.
        self._stack: list[tuple[str, str | None]] = []

    @property
    def unclosed(self) -> bool:
        return self._title is not None or self._teaser is not None or self._in_pager or self._view_divs > 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").split())
        if tag == "head":
            self._head += 1
        elif tag == "title" and self._head:
            self._title = []
        elif tag == "link" and (attributes.get("rel") or "").casefold() == "canonical":
            self.canonicals.append(attributes.get("href") or "")
        elif tag == "form" and attributes.get("id") == _FORM_ID:
            self.actions.append(attributes.get("action") or "")
        elif tag == "main":
            self._main += 1
        if not self._main or tag in HTML_VOID_TAGS:
            return
        if self._teaser is not None:
            self._teaser_start(tag, attributes, classes)
        elif tag == "article":
            if not self._view_divs:
                if _PAGE_NODE <= classes:
                    return
                raise GaoListingSourceError(f"{_LABEL} lists a teaser outside the listing's view")
            if not {"node--type-product", "node--view-mode-teaser-title"} <= classes:
                raise GaoListingSourceError(f"{_LABEL} lists a teaser that is not a product")
            self._teaser = {"fields": {}, "links": []}
        elif tag == "div" and (self._view_divs or _VIEW_CLASS in classes):
            if not self._view_divs:
                self.views += 1
            self._view_divs += 1
        elif tag == "ul" and self._view_divs and "js-pager__items" in classes:
            self.pagers += 1
            self._in_pager = True
        elif tag == "a" and self._in_pager and attributes.get("rel") == "next":
            self.next_links.append(attributes.get("href") or "")

    def _teaser_start(self, tag: str, attributes: dict[str, str | None], classes: set[str]) -> None:
        if tag == "article":
            raise GaoListingSourceError(f"{_LABEL} nests one teaser inside another")
        assert self._teaser is not None
        roles = {role for _, role in self._stack}
        role = None
        if tag == "a" and "product-teaser-title-link" in classes:
            self._teaser["links"].append(attributes.get("href") or "")
        elif tag == "header":
            role = "header"
        elif tag == "p" and "header" in roles:
            role = "title"
        elif tag == "div":
            # GAO wraps the issue date in a second div of the same class; the outer one holds the text.
            role = next((name for css, name in _FIELD_CLASSES.items() if css in classes and name not in roles), None)
        if role is not None and role != "header":
            if role in self._teaser["fields"]:
                raise GaoListingSourceError(f"{_LABEL} teaser repeats its {role}")
            self._teaser["fields"][role] = []
        self._stack.append((tag, role))

    def handle_endtag(self, tag: str) -> None:
        if tag == "head" and self._head:
            self._head -= 1
        elif tag == "title" and self._title is not None:
            self.titles.append(self._title)
            self._title = None
        elif tag == "main" and self._main:
            self._main -= 1
        if self._teaser is not None:
            if tag == "article":
                self.teasers.append(self._teaser)
                self._teaser, self._stack = None, []
                return
            for index in range(len(self._stack) - 1, -1, -1):
                if self._stack[index][0] == tag:
                    del self._stack[index:]
                    break
        elif tag == "ul" and self._in_pager:
            self._in_pager = False
        elif tag == "div" and self._view_divs:
            self._view_divs -= 1

    def handle_data(self, data: str) -> None:
        if self._title is not None:
            self._title.append(data)
        if self._teaser is not None:
            role = next((role for _, role in reversed(self._stack) if role in ("title", "number", "published")), None)
            if role is not None:
                self._teaser["fields"][role].append(data)


def _entry(position: int, teaser: dict) -> GaoMajorRuleEntry:
    """One teaser: a product page link, a title, and the number and issue date GAO states, if any."""
    fields, links = teaser["fields"], teaser["links"]
    title = spelled(fields.get("title"), "title", label=_LABEL)
    if not title:
        raise GaoListingSourceError(f"{_LABEL} teaser {position} lacks a title")
    if len(links) != 1 or not links[0].startswith("/products/"):
        raise GaoListingSourceError(f"{_LABEL} teaser {position} does not link one product page")
    link = links[0]
    slug = unquote(link.removeprefix("/products/"))
    try:
        gao_product_id(slug)
    except GaoProductSourceError as error:
        raise GaoListingSourceError(f"{_LABEL} teaser {position} names no product id") from error
    number = listing_text(fields.get("number"), "number", label=_LABEL) or None
    # A report number's page is the number lowercased (GAO-01-364R, OGC-99-12, AIMD-00-159R); a B-number's link
    # need only agree with it token for token, as the Month in Review's decisions do.
    if number is not None and not names_page(slug, number, exact=not number.startswith("B-")):
        raise GaoListingSourceError(f"{_LABEL} teaser {position} links a page other than its product number")
    published = listing_date(fields.get("published"), "published", "Published:", label=_LABEL)
    return GaoMajorRuleEntry(position, slug, number, link, title, published)


def parse_major_rule_page(
    body: bytes,
    *,
    page_index: int,
    max_bytes: int = DEFAULT_MAX_PAGE_BYTES,
    max_last_page_index: int = DEFAULT_MAX_LAST_PAGE_INDEX,
    expected_last_page_index: int | None = None,
    expected_page_size: int | None = None,
) -> GaoMajorRulePage:
    """One page, refused unless it is the listing's page ``page_index`` and agrees with the pages already read.

    The page is its own when its search form echoes the query requested. ``expected_page_size`` is the first page's
    teaser count: a page with a "Load More" must hold exactly that many and the last page no more.
    ``expected_last_page_index`` comes from the retained walk on re-read: a page before it must say another follows
    and the page at it must not. A page that differs means the listing changed shape while it was read.
    """
    if isinstance(page_index, bool) or not isinstance(page_index, int) or page_index < 0:
        raise GaoListingSourceError("page_index must be a nonnegative integer")
    text = decode_html_page(body, max_bytes, label=_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoListingSourceError)
    reader = _MajorRuleHtml()
    feed_html(reader, text, label=_LABEL, error_type=GaoListingSourceError)
    if reader.unclosed:
        raise GaoListingSourceError(f"{_LABEL} markup is incomplete")
    if [listing_text(parts, "title", label=_LABEL) for parts in reader.titles] != [_TITLE]:
        raise GaoListingSourceError(f"{_LABEL} is not titled {_TITLE!r}")
    if reader.canonicals != [LISTING_URL]:
        raise GaoListingSourceError(f"{_LABEL} does not name {LISTING_URL} as its canonical URL")
    requested = LISTING.page_url(page_index).removeprefix("https://www.gao.gov")
    if reader.actions != [requested]:
        raise GaoListingSourceError(f"{_LABEL} answers another query than page {page_index}'s")
    if reader.views > 1:
        raise GaoListingSourceError(f"{_LABEL} holds more than one listing view")
    entries = tuple(_entry(position, teaser) for position, teaser in enumerate(reader.teasers))
    if not entries:
        # Past the end GAO answers 200 with no view at all: nothing on the page says the listing ends there.
        raise GaoListingSourceError(f"{_LABEL} lists no teaser")
    if reader.pagers > 1:
        raise GaoListingSourceError(f"{_LABEL} has more than one pager")
    if reader.pagers and reader.next_links != [f"?page=%2C{page_index + 1}"]:
        raise GaoListingSourceError(f"{_LABEL} pager does not link page {page_index + 1} next")
    more = bool(reader.pagers)
    if page_index + more > max_last_page_index:
        raise GaoListingSourceError(f"{_LABEL} pager runs past page index {max_last_page_index}")
    if expected_last_page_index is not None and more != (page_index < expected_last_page_index):
        raise GaoListingMovedError(
            f"{_LABEL} {page_index} {'links' if more else 'ends without'} a next page, where the walk ended at "
            f"{expected_last_page_index}; the listing moved"
        )
    if expected_page_size is not None and (
        len(entries) > expected_page_size or (more and len(entries) != expected_page_size)
    ):
        raise GaoListingMovedError(
            f"{_LABEL} {page_index} holds {len(entries)} teasers where the first page held {expected_page_size}"
        )
    return GaoMajorRulePage(page_index, None if more else page_index, entries)


@dataclass(frozen=True, slots=True)
class GaoMajorRuleReport:
    """One listed product page, once, with the pages that listed it."""

    product_id: str
    product_number: str | None
    title: str
    published: str | None
    pages: tuple[int, ...]
    #: The listing that states it: this one, or GAO's old index of the 1996-2000 reports (``major_rule_old_index``).
    scope: str = SCOPE_KEY

    @property
    def kind(self) -> str:
        """What the number says this listed page is; see :data:`KINDS`."""
        number = (self.product_number or "").upper()
        if number.startswith(_REPORT_PREFIXES):
            return REPORT
        return B_NUMBERED if number.startswith("B-") else OTHER


@dataclass(frozen=True, slots=True)
class GaoMajorRuleRun:
    """The verified pages of a complete walk, and the reports they list; nothing when the walk is unfinished."""

    pages: tuple[RetainedListingPage, ...]
    reports: tuple[GaoMajorRuleReport, ...]
    #: Teasers read twice: the listing shifted down while it was walked, a new report entering at the top.
    repeats: int
    complete: bool


def _fixed(entry: GaoMajorRuleEntry) -> tuple:
    return (entry.product_id, entry.product_number, entry.title, entry.published)


def collect_major_rule_reports(pages: Iterable[GaoMajorRulePage]) -> tuple[tuple[GaoMajorRuleReport, ...], int]:
    """Each product page once, in listed order, and how many teasers were repeats.

    A walk that takes hours sees GAO add reports at the top, which pushes every later teaser down a place, so the
    last teaser of one page can be read again first on the next: the same page with the same fields is one report,
    counted as a repeat. The same page listed with differing fields refuses. A page listed with Drupal's ``-N``
    suffix as well is one report, on the base page, when every other field agrees, as in the Month in Review.
    """
    found: dict[str, tuple[GaoMajorRuleEntry, list[int]]] = {}
    repeats = 0
    for page in pages:
        for entry in page.entries:
            held = found.setdefault(entry.product_id, (entry, []))
            if held[1]:
                if _fixed(held[0]) != _fixed(entry):
                    raise GaoListingSourceError(
                        f"GAO major-rule listing states {entry.product_number or entry.link} with differing fields"
                    )
                repeats += 1
            if page.page_index not in held[1]:
                held[1].append(page.page_index)
    for key in list(found):
        suffix = TRAILING_DUPLICATE_PATH.search(key)
        base = key[: suffix.start()] if suffix else None
        if base in found and _fixed(found[base][0])[1:] == _fixed(found[key][0])[1:]:
            _, indexes = found.pop(key)
            found[base][1].extend(index for index in indexes if index not in found[base][1])
    reports = tuple(
        GaoMajorRuleReport(entry.product_id, entry.product_number, entry.title, entry.published, tuple(indexes))
        for entry, indexes in found.values()
    )
    return reports, repeats


def read_major_rule_run(
    receipts: Path,
    store: Path,
    *,
    max_page_bytes: int = MAX_PAGE_BYTES,
    max_last_page_index: int = DEFAULT_MAX_LAST_PAGE_INDEX,
) -> GaoMajorRuleRun:
    """Re-read a walk: each page's digest re-checked and the page re-parsed; reports only once every page is retained."""
    retained = read_retained_pages(
        receipts, store, scope_of=_scope_of, max_page_bytes=max_page_bytes, max_last_page_index=max_last_page_index
    )
    reports, repeats = collect_major_rule_reports(page.page for page in retained.pages)  # type: ignore[misc]
    return GaoMajorRuleRun(retained.pages, reports, repeats, SCOPE_KEY in retained.complete_scopes)


#: How the Month in Review ends a heading it cut, at about 200 characters; this listing states the heading whole.
_CUT: Final = "..."


def _number_once(product_id: str, first: str | None, second: str | None) -> None:
    if first != second:
        raise GaoListingSourceError(f"GAO's listings number {product_id} {first} and {second}")


def merge_with_month_in_review(
    listed: Sequence[GaoListedProduct], reports: Sequence[GaoMajorRuleReport]
) -> tuple[GaoListedProduct, ...]:
    """GAO's products once each: the Month in Review's, then the major-rule reports only these listings state.

    ``reports`` are this listing's, and after them the old index's (``major_rule_old_index``) where a host reads
    it. A page two of them state (OGC-99-12) is one report, the first's, carrying both scopes; their numbers must
    agree.

    Precedence. A report the Month in Review lists too is its row, which states the label, the release date and the
    topics these listings lack. A listing adds only what that row lacks: the whole heading where the Month in
    Review cut it, and GAO's issue date where the row has none (the Month in Review states only a major-rule report's
    release date). Its scope key joins the row's scopes. The two must agree on the product number, or it refuses.

    A report only these listings state becomes a product when its number makes it one (:data:`REPORT`), labelled
    :data:`MAJOR_RULE_REPORT`, titled as listed and dated by its issue date. A numbered :data:`OTHER` page (the
    AIMD- and GGD- products of 1995-2000 in the listing's tail) becomes an ordinary product the same way but with no
    label, since the listing names none and it is no major-rule report (owner ruling 2026-10-04); its title is the
    heading as listed. A B-numbered page, or one with no number, adds nothing: the Month in Review's label decides a
    B-number, and a page with no number has none to key.
    """
    by_id: dict[str, tuple[GaoMajorRuleReport, tuple[str, ...]]] = {}
    for report in reports:
        first, scopes = by_id.setdefault(report.product_id, (report, ()))
        _number_once(report.product_id, first.product_number, report.product_number)
        by_id[report.product_id] = (first, tuple(dict.fromkeys((*scopes, report.scope))))
    merged: list[GaoListedProduct] = []
    for product in listed:
        if product.product_id not in by_id:
            merged.append(product)
            continue
        report, scopes = by_id[product.product_id]
        _number_once(product.product_id, product.product_number, report.product_number)
        heading, stem = product.heading, product.heading.removesuffix(_CUT)
        if heading.endswith(_CUT) and len(report.title) > len(stem) and report.title.startswith(stem):
            heading = report.title
        merged.append(
            replace(
                product,
                heading=heading,
                published=product.published or report.published,
                scopes=(*product.scopes, *scopes),
            )
        )
    seen = {product.product_id for product in listed}
    merged.extend(
        GaoListedProduct(
            report.product_id,
            report.product_number,
            MAJOR_RULE_REPORT if report.kind == REPORT else None,
            report.title,
            report.published,
            None,
            (),
            scopes,
        )
        for report, scopes in by_id.values()
        if report.kind != B_NUMBERED and report.product_number and report.product_id not in seen
    )
    return tuple(merged)


def _read(args: argparse.Namespace) -> int:
    run = read_major_rule_run(args.receipts, args.store)
    kinds = {kind: sum(report.kind == kind for report in run.reports) for kind in KINDS}
    write_items(
        ((report.kind, report) for report in run.reports),
        {"pages": len(run.pages), **kinds, "repeats": run.repeats, "complete": run.complete},
        args.output,
    )
    return 0


def parser() -> argparse.ArgumentParser:
    """The command's arguments; its defaults are the polite walk, one request every 420 seconds."""
    parser = argparse.ArgumentParser(description="Walk or read GAO's Congressional Review Act Reports on Major Rules")
    commands = parser.add_subparsers(dest="command", required=True)
    add_walk_arguments(commands.add_parser("walk", help="Capture every listing page through Zyte, resuming"))
    add_read_arguments(commands.add_parser("read", help="Verify retained pages offline and print reports as JSONL"))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.command == "read":
        return _read(args)
    return walk_command(args, lambda: [LISTING], max_last_page_index=DEFAULT_MAX_LAST_PAGE_INDEX)


__all__ = [
    "B_NUMBERED",
    "DEFAULT_MAX_LAST_PAGE_INDEX",
    "KINDS",
    "LISTING",
    "LISTING_URL",
    "OTHER",
    "REPORT",
    "SCOPE_KEY",
    "GaoMajorRuleEntry",
    "GaoMajorRuleListing",
    "GaoMajorRulePage",
    "GaoMajorRuleReport",
    "GaoMajorRuleRun",
    "collect_major_rule_reports",
    "main",
    "merge_with_month_in_review",
    "parse_major_rule_page",
    "parser",
    "read_major_rule_run",
]


if __name__ == "__main__":
    raise SystemExit(main())
