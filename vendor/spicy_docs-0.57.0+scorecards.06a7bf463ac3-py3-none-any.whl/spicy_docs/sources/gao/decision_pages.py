"""The whole B-number list and the decision date a GAO decision page states, read from its caption.

GAO's listing names a decision's numbers in a field it sometimes cuts (``month_in_review.decision_numbers``). The
decision's own page prints the decision under "View Decision" (``js-endpoint-view-decision``) with a caption::

    Decision / Matter of: <parties> / File: B-424477; B-424477.2 / Date: August 7, 2026

"File:" lists every number the decision decides and "Date:" is the day GAO decided it, which the listing never states
(it states when GAO released the decision). Pages come from the product-page acquirer (``sources.gao.native``):
GAO refuses plain clients. The page must be the one asked for (its canonical link is the product's page); a page
whose decision text carries no caption -- a letter, a report, a decision GAO posts only as a PDF -- states neither
line and reads as None, never as an empty list. A caption that is there and does not read, or a File list missing a
number the listing named, refuses rather than guessing.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date
from html.parser import HTMLParser
from typing import Final

from spicy_docs.reading.markup import HTML_VOID_TAGS, decode_html_page, feed_html
from spicy_docs.sources.gao.month_in_review import MONTHS, stated_b_numbers
from spicy_docs.sources.gao.native import MAX_PAGE_BYTES, gao_product_id, gao_product_url

#: The block GAO prints a decision's text in, by class.
DECISION_BLOCK_CLASS: Final = "js-endpoint-view-decision"
#: Elements that end a line of the decision text.
_LINE_TAGS: Final = frozenset({"blockquote", "br", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "p", "td", "tr"})
_CAPTION: Final = re.compile(r"Matter of\s*:", re.IGNORECASE)
_FILE: Final = re.compile(r"File\s*:\s*(.*)", re.IGNORECASE)
_DATE: Final = re.compile(r"Date\s*:\s*(.*)", re.IGNORECASE)
#: The digest heading ends the caption; nothing after it is read.
_DIGEST: Final = re.compile(r"DIGEST\b")
#: How GAO's typists spell a B-number in a File line, respelled to the one form (each seen on a captured page,
#: 2026-10-03): a hyphen typed as U+2011 or its kin (``B\u2011419956.189``, CIO-SP4), a space for the hyphen or after it
#: (``B 414175.15``, ``B- 418012.2``), no hyphen before a six-digit number (``B422503``), a full stop between two
#: numbers (``B-412940.29. B-412940.30``) and a footnote mark after one (``B-406428[1]``). Nothing else is respelled:
#: ``B0408232.4`` and a number without its ``B-`` stay unread.
_DASHES: Final = str.maketrans(dict.fromkeys("\u2010\u2011\u2012\u2013\u2212", "-"))
_B_PREFIX: Final = re.compile(r"\bB\s*-?\s*(?=\d{6}(?!\d))")
_STOP_BETWEEN: Final = re.compile(r"\.\s+(?=B-)")
_FOOTNOTE: Final = re.compile(r"\[\d+\]")
#: GAO's "July 3, 2018", typed as "July 3,2018", "June10, 2026", "April 9. 2014", "Sept. 1, 2021" or with text run on
#: after the year.
_DAY: Final = re.compile(r"([A-Z][a-z]+)\.?\s*(\d{1,2})\s*[,.]\s*(\d{4})(?!\d)")
_MONTHS: Final = {
    **{name: number for number, name in enumerate(MONTHS, 1)},
    **{name[:3]: number for number, name in enumerate(MONTHS, 1)},
    "Sept": 9,
}
_LABEL: Final = "GAO decision page"


class GaoDecisionPageError(ValueError):
    """A decision page that cannot establish the decision's numbers and date; ``reason`` names which check failed."""

    def __init__(self, reason: str, message: str) -> None:
        super().__init__(f"{_LABEL}: {message}")
        self.reason = reason


@dataclass(frozen=True, slots=True)
class GaoDecisionCaption:
    """What a decision page's caption states: every B-number on its File line, and the day GAO decided it."""

    product_id: str
    numbers: tuple[str, ...]
    decided_date: str


class _DecisionText(HTMLParser):
    """The page's canonical links, and the decision block's text, one entry per line and one per paragraph.

    A paragraph is the lines a lone ``<br>`` divides, joined by a space: GAO's typists break a sentence with one
    (gao-02-578r: "this is our report on<br>a major rule promulgated by"), and end a paragraph with a block element
    or two ``<br>``s around an empty line.
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.canonicals: list[str] = []
        self.blocks = 0
        self.lines: list[str] = []
        self.paragraphs: list[str] = []
        self._depth = 0
        self._parts: list[str] = []
        #: The last line ended at a ``<br>``, with no empty line since: the next line continues its paragraph.
        self._joins = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == "link" and (attributes.get("rel") or "").casefold() == "canonical":
            self.canonicals.append(attributes.get("href") or "")
        if self._depth:
            if tag in _LINE_TAGS:
                self._end_line(tag)
            if tag == "div":
                self._depth += 1
        elif tag == "div" and DECISION_BLOCK_CLASS in (attributes.get("class") or "").split():
            self.blocks += 1
            self._depth = 1

    def handle_endtag(self, tag: str) -> None:
        if not self._depth or tag in HTML_VOID_TAGS:
            return
        if tag in _LINE_TAGS:
            self._end_line(tag)
        if tag == "div":
            self._depth -= 1

    def handle_data(self, data: str) -> None:
        if self._depth:
            self._parts.append(data)

    def _end_line(self, tag: str) -> None:
        line = " ".join("".join(self._parts).split())
        self._parts = []
        if not line:
            self._joins = False
            return
        self.lines.append(line)
        if self._joins and self.paragraphs:
            self.paragraphs[-1] += " " + line
        else:
            self.paragraphs.append(line)
        self._joins = tag == "br"


def _caption(lines: list[str]) -> tuple[str, str] | None:
    """The File and Date lines' values after the first "Matter of:" line, before the digest; None without a caption."""
    start = next((index for index, line in enumerate(lines) if _CAPTION.match(line)), None)
    if start is None:
        return None
    file: list[str] | None = None
    date = None
    running = False
    for line in lines[start + 1 :]:
        if _DIGEST.match(line):
            break
        if file is None:
            if match := _FILE.match(line):
                file, running = [match[1]], True
        elif match := _DATE.match(line):
            date = match[1]
            break
        elif running and _B_PREFIX.match(line.translate(_DASHES)):
            # A long list runs on below its label (B-421254.6; B-421254.7; B-421254.8 on the next line).
            file.append(line)
        else:
            # Anything else ends the list; a protective-order notice can stand between it and its date.
            running = False
    if file is None:
        raise GaoDecisionPageError("no-file-line", "the caption states no File line")
    if date is None:
        raise GaoDecisionPageError("no-date-line", "the caption states no Date line after its File line")
    return " ".join(file), date


def _numbers(file: str) -> tuple[str, ...]:
    respelled = _STOP_BETWEEN.sub("; ", _B_PREFIX.sub("B-", _FOOTNOTE.sub("", file.translate(_DASHES))))
    numbers, others = stated_b_numbers(respelled)
    if others or not numbers:
        raise GaoDecisionPageError("unreadable-file-line", f"File {file!r} states something other than B-numbers")
    return numbers


def _decided(value: str) -> str:
    match = _DAY.match(value)
    month = _MONTHS.get(match[1]) if match else None
    try:
        if match is None or month is None:
            raise ValueError(value)
        return date(int(match[3]), month, int(match[2])).isoformat()
    except ValueError as error:
        raise GaoDecisionPageError("unreadable-date", f"Date {value!r} is not GAO's 'Month D, YYYY'") from error


def _decision_text(body: bytes, product_id: str) -> _DecisionText | None:
    """The parsed decision block, None where the page prints none; refuses another page's or two blocks."""
    text = decode_html_page(body, MAX_PAGE_BYTES, label=_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoDecisionPageError)
    page = _DecisionText()
    feed_html(page, text, label=_LABEL, error_type=GaoDecisionPageError)
    if page.canonicals != [gao_product_url(product_id)]:
        raise GaoDecisionPageError("not-this-page", f"the page's canonical link is not {gao_product_url(product_id)}")
    if page.blocks > 1:
        raise GaoDecisionPageError("two-decision-blocks", "the page prints more than one decision block")
    return page if page.blocks else None


def decision_paragraphs(body: bytes, *, product_id: str) -> tuple[str, ...] | None:
    """The page's View Decision text, one entry per paragraph, whitespace collapsed; None where it prints no block.

    The major-rule letter reader (``major_rule_letters``) reads its letter from these. Refuses a page whose canonical
    link is another page's (``not-this-page``) or that prints two blocks (``two-decision-blocks``).
    """
    page = _decision_text(body, gao_product_id(product_id))
    return None if page is None else tuple(page.paragraphs)


def read_decision_caption(body: bytes, *, product_id: str, listed: Iterable[str] = ()) -> GaoDecisionCaption | None:
    """The numbers and date the page's decision caption states, or None where its decision text has no caption.

    ``listed`` is what the listing kept of the decision's numbers; a File list lacking any of them refuses, since the
    page would then not be the whole list. Refusals carry a ``reason``: ``not-this-page`` (the canonical link is
    another page's), ``two-decision-blocks``, ``no-file-line``, ``no-date-line``, ``unreadable-file-line`` (a part
    that is no B-number), ``unreadable-date`` and ``file-lacks-listed-number``.
    """
    product_id = gao_product_id(product_id)
    page = _decision_text(body, product_id)
    stated = None if page is None else _caption(page.lines)
    if stated is None:
        return None
    file, day = stated
    numbers = _numbers(file)
    missing = [number for number in listed if number not in numbers]
    if missing:
        raise GaoDecisionPageError("file-lacks-listed-number", f"File lacks {missing} that the listing names")
    return GaoDecisionCaption(product_id, numbers, _decided(day))


__all__ = [
    "DECISION_BLOCK_CLASS",
    "GaoDecisionCaption",
    "GaoDecisionPageError",
    "decision_paragraphs",
    "read_decision_caption",
]
