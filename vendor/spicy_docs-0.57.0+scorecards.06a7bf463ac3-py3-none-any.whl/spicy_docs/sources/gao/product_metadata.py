"""What a GAO product page states of itself (heading, number, day, Full Report link), outside the raw profile."""

from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser
from io import BytesIO
from urllib.parse import urljoin, urlsplit
from zipfile import ZipFile

from spicy_docs.sources.gao.native import (
    PUBLICATION_BLOCK_ID,
    gao_product_id,
    gao_product_url,
    names_page,
    parse_gao_product_page_response,
    publication_date,
)

#: The rule a host records beside what this module read: the page heading, the publication block's date
#: (:func:`spicy_docs.sources.gao.native.publication_date`) and the Full Report link.  ``/2`` (2026-10-03) reads the
#: unlabeled block date GAO's Bid Protest Annual Reports print and a page that states no topic; every value read
#: under ``/1`` reads the same.  ``/3`` (2026-10-05) reads that date beside the number that names the page
#: (``native.names_page``), not only beside the id in capitals: a day where ``/2`` stated none
#: (:func:`read_product_heading`) or the release refused the page. No day, heading or link ``/2`` read changes.
PRODUCT_PAGE_METADATA_RULE = "gao-qualified-page-heading-publication-block/3"

#: The label the product page gives its report PDF inside the full-reports group. All 47 product pages retained on
#: 2026-08-22 (``_salvage-2026-08-28/spicysearch-output/gao-native-import-2026-08-22/pages/``) and the retained
#: gao-17-317 page label exactly one link so, each ``/assets/{product-id}.pdf``; the group's other labels are
#: ``Highlights Page``, ``Accessible PDF`` and ``View Full Report Online``.
FULL_REPORT_LABEL = "Full Report"


#: The hosts a Full Report link may name. The page links its own host; the file host serves the same asset paths.
_REPORT_LINK_HOSTS = frozenset({"www.gao.gov", "files.gao.gov"})


@dataclass(frozen=True)
class GaoTargetMetadata:
    """``pdf_url`` is the path of the page's own Full Report link, on ``files.gao.gov``.

    The page links ``www.gao.gov/assets/...``, which refuses plain clients; the file host serves the same asset path
    keyless (``docs/sources/gao-files.md``). So the value is fetchable, and for a product with an online report it
    equals ``files.GaoReportIndex.pdf_url``. It is the page's path, not one built from the product id: on all 47
    retained pages the two agree, and a page linking another path keeps its own.
    """

    product_id: str
    title: str
    product_url: str
    pdf_url: str
    published_date: str | None


@dataclass(frozen=True, slots=True)
class GaoProductHeading:
    """What a product page states of itself: its number and heading as printed, and the day its block states."""

    product_id: str
    product_number: str
    title: str
    published_date: str | None


class _PageMetadata(HTMLParser):
    """Read only the page's canonical link, the product heading, its publication block and its full-reports links."""

    def __init__(self):
        super().__init__()
        self.in_title = False
        self.in_dates = False
        self.in_number = False
        self.in_reports = False
        self.in_label = False
        self.canonicals: list[str] = []
        self.titles: list[list[str]] = []
        self.dates: list[str] = []
        #: The publication block's ``<strong>`` elements: the product number, once.
        self.numbers: list[list[str]] = []
        #: ``[href, label parts]`` for each link in the full-reports group, in page order.
        self.report_links: list[tuple[str, list[str]]] = []
        self._link: tuple[str, list[str]] | None = None

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = (attributes.get("class") or "").split()
        if tag == "link" and (attributes.get("rel") or "").casefold() == "canonical":
            self.canonicals.append(attributes.get("href") or "")
        if tag == "h1":
            self.in_title = True
            self.titles.append([])
        if tag == "section" and attributes.get("id") == PUBLICATION_BLOCK_ID:
            self.in_dates = True
        if self.in_dates and tag == "strong":
            self.in_number = True
            self.numbers.append([])
        if tag == "section" and "full-reports-group" in classes:
            self.in_reports = True
        if self.in_reports and tag == "a" and attributes.get("href"):
            self._link = (attributes["href"], [])
            self.report_links.append(self._link)
        if self._link is not None and tag == "div" and "field--name-field-link-label" in classes:
            self.in_label = True

    def handle_endtag(self, tag):
        if tag == "h1":
            self.in_title = False
        if tag == "strong":
            self.in_number = False
        if tag == "section":
            self.in_dates = self.in_number = False
            self.in_reports = False
        if tag == "div":
            self.in_label = False
        if tag == "a":
            self._link = None

    def handle_data(self, data):
        if self.in_title:
            self.titles[-1].append(data)
        if self.in_dates:
            self.dates.append(data)
        if self.in_number:
            self.numbers[-1].append(data)
        if self.in_label and self._link is not None:
            self._link[1].append(data)


def product_page_metadata(raw: bytes, product_id: str) -> GaoTargetMetadata:
    """Replay the provider-qualified product page, retaining its exact title and explicit date only."""
    from spicy_docs.sources.gao.files import REPORT_FILE_ROOT

    if len(raw) > 10 * 1024 * 1024:
        raise ValueError("GAO retained page ZIP exceeds its byte bound")
    parsed = parse_gao_product_page_response(raw)
    if parsed["_productId"] != product_id:
        raise ValueError("Retained GAO page names a different product")
    with ZipFile(BytesIO(raw)) as archive:
        body = archive.read("product.html")
    fields = _read_page(body)
    title = _heading(fields)
    day = publication_date("".join(fields.dates), product_id)
    product_url = parsed["results"][0]["canonicalUrl"]
    return GaoTargetMetadata(product_id, title, product_url, REPORT_FILE_ROOT + _full_report(fields, product_url), day)


def read_product_heading(body: bytes, *, product_id: str) -> GaoProductHeading:
    """The number, heading and day a product page's own HTML states, once the page is shown to be the product's.

    For a page captured outside a release's evidence ZIP (``major_rule_old_index`` reads each early report's so). The
    page's canonical link must be the product's page, and its publication block must state one number, in
    ``<strong>``, that names the page as a listing's number names its link (``native.names_page``): all 2,175
    major-rule report pages captured on 2026-10-04 print the block so, the number then the day. The heading is the
    page's one ``<h1>``, which on every one of those pages is the title GAO's listing prints for it. The day is
    ``native.publication_date``'s, read beside that same number, None where the block states none.
    """
    product_id = gao_product_id(product_id)
    fields = _read_page(body)
    if fields.canonicals != [gao_product_url(product_id)]:
        raise ValueError(f"GAO product page's canonical link is not {gao_product_url(product_id)}")
    numbers = [" ".join("".join(parts).split()) for parts in fields.numbers]
    if len(numbers) != 1 or not names_page(product_id, numbers[0], exact=not numbers[0].startswith("B-")):
        raise ValueError(f"GAO product page {product_id} states {numbers} as its number")
    return GaoProductHeading(
        product_id, numbers[0], _heading(fields), publication_date("".join(fields.dates), product_id)
    )


def full_report_path(body: bytes, product_url: str) -> str:
    """The asset path of the one link a product page's full-reports group labels Full Report (``/assets/...pdf``).

    For a page that prints its report only as that PDF: the major-rule letter reader reads such a report's letter
    from it (``major_rule_letters.read_pdf_letter``). Refuses a page linking none, or two different files.
    """
    return _full_report(_read_page(body), product_url)


def _heading(fields: _PageMetadata) -> str:
    if len(fields.titles) != 1 or not (title := " ".join("".join(fields.titles[0]).split())):
        raise ValueError("GAO product page must state exactly one nonempty heading")
    return title


def _read_page(body: bytes) -> _PageMetadata:
    fields = _PageMetadata()
    fields.feed(body.decode("utf-8"))
    fields.close()
    return fields


def _full_report(fields: _PageMetadata, product_url: str) -> str:
    paths = {
        _asset_path(product_url, href)
        for href, label in fields.report_links
        if " ".join("".join(label).split()) == FULL_REPORT_LABEL
    }
    if len(paths) != 1:
        raise ValueError(f"GAO product page must link exactly one {FULL_REPORT_LABEL} PDF, not {len(paths)}")
    return paths.pop()


def _asset_path(product_url: str, href: str) -> str:
    """The asset path a Full Report link names, resolved against the page.

    Links are compared by this path, so one PDF linked relatively and absolutely, on either host, is one link. A
    fragment (``#page=2``) addresses a place in the file, not another file, and is dropped; a query can ask the
    server for something else and refuses, as does another host or a path outside ``/assets/``.
    """
    link = urlsplit(urljoin(product_url, href))
    if link.hostname not in _REPORT_LINK_HOSTS or link.query or not link.path.startswith("/assets/"):
        raise ValueError("GAO Full Report link is not an asset path on gao.gov")
    return link.path
