"""GAO's major-rule reports of 1996 to November 2000: its own old index, from the Internet Archive, and their pages.

GAO's General Counsel numbered the Congressional Review Act's first reports ``OGC-``; no current GAO listing states
them (``major_rule_reports``: "Reports on Major Rules" lists one, OGC-99-12). GAO listed them itself at
``www.gao.gov/decisions/majrule/majrule.htm`` until 2006, and the Internet Archive keeps that page. The owner ruled on
2026-10-04 to read every one (``docs/decisions.md``): the Archive's capture of 2000-12-15 is the list, and GAO's
product page for each, which it still serves at ``/products/ogc-YY-N``, states the report as GAO states it now.

**The index** is one capture, so it is pinned: :data:`INDEX_URL` names the capture's own bytes (``id_``) and
:data:`INDEX_SHA256` their digest, checked when it is fetched and again on every re-read. The Archive answers a
timestamp it lacks with a redirect to its nearest capture, which the shared client refuses. It is one HTML 3.2
``<ul>``, an ``<li>`` a report: a link to the letter as HTML, one to its PDF, then ``Title, OGC-YY-N, Month D,
YYYY``. GAO's page was not tidy, and the reader says what it does with each untidy line:

- a report's own files are ``ogYYNNN.htm`` and ``.pdf``, and that name spells its number (``og96009`` is OGC-96-9).
  An entry is a report when its links are such a pair; the number it states must be the one they spell, and no two
  entries may link one report's files;
- two entries state no date (OGC-99-12, OGC-99-29): the date is None, never guessed;
- a line whose links are not a report's own files but which states an ``OGC-`` number or a letter's B-file number
  is a stray repeat: GAO's generator ran over misnamed copies and an editor's backup (``og015.htm``, ``d013.htm``,
  ``#d01200r2.htm#``, ``og00041.htm~``). It must repeat a report: one of the same date whose title the stray's
  begins and, where it states an ``OGC-`` number, of that number; otherwise it refuses;
- a line stating a ``GAO-`` number is one of GAO's later numbering ("Reports on Major Rules" lists those) and is
  counted, not read;
- GAO's older pages print an entry's number before its title as well, in bold; a title drops it.

**The pages** come through Zyte, since ``www.gao.gov`` refuses plain clients, one scope a report so the shared walk
(``listing.walk_listing``) retains, resumes and re-reads them as it does a listing's pages. A page must be the
report's own (``product_metadata.read_product_heading``) and state the index's number. A report's title is the page's
heading and its issue date the day the page's publication block states, the two fields "Reports on Major Rules"
prints for the reports it lists; the index's date fills only a page that states none. The letter each page prints is
``major_rule_letters``' to read.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import TYPE_CHECKING, Final

from spicy_docs.reading.markup import decode_html_page, feed_html
from spicy_docs.sources.gao.listing import (
    DEFAULT_MAX_PAGE_BYTES,
    MAX_PAGE_BYTES,
    MAX_TEXT,
    GaoListingAcquirer,
    GaoListingBudget,
    GaoListingSourceError,
    RetainedListingPage,
    add_read_arguments,
    add_walk_arguments,
    listing_text,
    read_retained_pages,
    walk_command,
    walk_listing,
    write_items,
)
from spicy_docs.sources.gao.major_rule_reports import GaoMajorRuleReport
from spicy_docs.sources.gao.native import gao_product_url
from spicy_docs.sources.gao.product_metadata import GaoProductHeading, read_product_heading

if TYPE_CHECKING:
    import httpx

#: The capture's own bytes: ``id_`` asks the Archive for what GAO served, with nothing of the Archive's added.
INDEX_URL: Final = "https://web.archive.org/web/20001215164700id_/http://www.gao.gov:80/decisions/majrule/majrule.htm"
#: The capture's digest (86,664 bytes; the page says "last revised Fri Dec 15 13:23:01 2000"). A capture does not
#: change, so other bytes at this address are another document and refuse.
INDEX_SHA256: Final = "sha256:d565b8f4946ea346b09e0843aa8013f36dc578023d9da6839057b97d8c82f01a"
#: The index's receipt key, and the scope a report's row carries: it names the document that lists the report.
SCOPE_KEY: Final = "majrule-index-2000-12-15"
#: Every scope here is one page; the shared walk's bound on a scope's last page must be positive.
_LAST_PAGE_BOUND: Final = 1
_LABEL: Final = "GAO old major-rule index"
_PAGE_LABEL: Final = "GAO product page"
#: A report's own file, whose name spells its number.
_OWN_FILE: Final = re.compile(r"og(\d\d)(\d{3})\.(htm|pdf)")
#: ``Title, NUMBER, Month D, YYYY``, read from the right: a title holds commas, and two entries end at the comma.
_STATED: Final = re.compile(
    r"(?P<title>.+),\s*(?P<number>(?:OGC|GAO|B)-[0-9][0-9A-Za-z.-]*),\s*(?P<date>(?:[A-Z][a-z]+ \d{1,2}, \d{4})?)"
)
#: A report's page id, its number lowercased (``ogc-96-9``).
_PAGE_ID: Final = re.compile(r"ogc-\d\d-[1-9]\d*")


@dataclass(frozen=True, slots=True)
class GaoOldIndexEntry:
    """One report as the index lists it: its number, which its files spell too, and the title and date GAO typed."""

    position: int
    product_id: str
    product_number: str
    title: str
    #: The entry's date as ``YYYY-MM-DD``; None on the two entries that state none.
    issued: str | None
    html_file: str
    pdf_file: str


@dataclass(frozen=True, slots=True)
class GaoOldIndexPage:
    """The index's one page: its reports once each, in listed order, and the lines it read past."""

    page_index: int
    last_page_index: int | None
    entries: tuple[GaoOldIndexEntry, ...]
    #: Lines repeating a report under links that are not its own files.
    strays: int
    #: Lines stating a ``GAO-`` number, GAO's later numbering.
    later_numbered: int


@dataclass(frozen=True, slots=True)
class GaoOldReportPage:
    """One report's product page, read."""

    page_index: int
    last_page_index: int | None
    entries: tuple[GaoProductHeading, ...]


class _IndexHtml(HTMLParser):
    """Each ``<li>`` of the page's lists: its links in order and its text. HTML 3.2 closes no ``<li>``."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.items: list[tuple[list[str], list[str]]] = []
        self._lists = 0
        self._open = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "ul":
            self._lists += 1
            self._open = False
        elif tag == "li" and self._lists:
            self.items.append(([], []))
            self._open = True
        elif tag == "a" and self._open:
            self.items[-1][0].append(dict(attrs).get("href") or "")

    def handle_endtag(self, tag: str) -> None:
        if tag == "ul" and self._lists:
            self._lists -= 1
            self._open = False

    def handle_data(self, data: str) -> None:
        if self._open:
            self.items[-1][1].append(data)


def _issued(value: str, position: int) -> str | None:
    if not value:
        return None
    try:
        return datetime.strptime(value, "%B %d, %Y").replace(tzinfo=UTC).date().isoformat()
    except ValueError as error:
        raise GaoListingSourceError(f"{_LABEL} entry {position} states a date that is no calendar day") from error


def _own_number(links: list[str], position: int) -> str | None:
    """The number a report's own pair of files spells; None for links that are not such files."""
    html, pdf = (_OWN_FILE.fullmatch(link) for link in links)
    if html is None and pdf is None:
        return None
    if html is None or pdf is None or (html[3], pdf[3]) != ("htm", "pdf") or html.group(1, 2) != pdf.group(1, 2):
        raise GaoListingSourceError(f"{_LABEL} entry {position} links {links}, not one report's HTML and PDF")
    return f"OGC-{html[1]}-{int(html[2])}"


def parse_old_index(body: bytes, *, max_bytes: int = MAX_PAGE_BYTES) -> GaoOldIndexPage:
    """The reports an index page lists, by the module's rules; any line they do not cover refuses.

    The capture that is the list is pinned by :class:`GaoOldIndex`; the rules stand apart from the pin so each can
    be shown to refuse a changed line. O(page): one pass, and each stray is compared with its date's reports only.
    """
    text = decode_html_page(body, max_bytes, label=_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoListingSourceError)
    reader = _IndexHtml()
    feed_html(reader, text, label=_LABEL, error_type=GaoListingSourceError)
    reports: dict[str, GaoOldIndexEntry] = {}
    strays: list[tuple[int, str, str, str | None]] = []
    later = 0
    for position, (links, parts) in enumerate(reader.items):
        stated = _STATED.fullmatch(listing_text(parts, "entry", label=_LABEL))
        if stated is None or len(links) != 2:
            raise GaoListingSourceError(f"{_LABEL} entry {position} is not two links and 'Title, number, date'")
        number, issued = stated["number"], _issued(stated["date"], position)
        title = stated["title"].removeprefix(number).strip()
        own = _own_number(links, position)
        if number.startswith("GAO-") and own is None:
            later += 1
        elif own is None:
            strays.append((position, number, title, issued))
        elif number != own:
            raise GaoListingSourceError(f"{_LABEL} entry {position} states {number} for {own}'s files")
        elif own in reports:
            raise GaoListingSourceError(f"{_LABEL} lists {own}'s files twice")
        else:
            reports[own] = GaoOldIndexEntry(position, own.lower(), own, title, issued, links[0], links[1])
    if not reports:
        raise GaoListingSourceError(f"{_LABEL} lists no report")
    by_date: dict[str | None, list[GaoOldIndexEntry]] = {}
    for entry in reports.values():
        by_date.setdefault(entry.issued, []).append(entry)
    for position, number, title, issued in strays:
        # A B-number is the letter's file number, which no entry states of a report: the date and title find it.
        if not any(
            report.title.startswith(title) and (number == report.product_number or number.startswith("B-"))
            for report in by_date.get(issued, ())
        ):
            raise GaoListingSourceError(f"{_LABEL} entry {position} states {number} and repeats no listed report")
    return GaoOldIndexPage(0, 0, tuple(reports.values()), len(strays), later)


@dataclass(frozen=True, slots=True)
class GaoOldIndex:
    """The index as a scope of one page: the pinned capture."""

    @property
    def key(self) -> str:
        return SCOPE_KEY

    def page_url(self, page_index: int) -> str:
        return INDEX_URL

    def parse_page(self, body: bytes, *, page_index: int, max_bytes: int, **_listing: object) -> GaoOldIndexPage:
        if page_index != 0:
            raise GaoListingSourceError(f"{_LABEL} is one page")
        if "sha256:" + hashlib.sha256(body).hexdigest() != INDEX_SHA256:
            raise GaoListingSourceError(f"{_LABEL} is not the capture of 2000-12-15: its digest is not {INDEX_SHA256}")
        return parse_old_index(body, max_bytes=max_bytes)


INDEX: Final = GaoOldIndex()


@dataclass(frozen=True, slots=True)
class GaoOldReport:
    """One report's product page as a scope of one page, keyed on the page's id (``ogc-96-9``)."""

    product_id: str

    def __post_init__(self) -> None:
        if not isinstance(self.product_id, str) or _PAGE_ID.fullmatch(self.product_id) is None:
            raise GaoListingSourceError(
                f"receipts name scope {self.product_id!r}, neither {SCOPE_KEY!r} nor an OGC report's page"
            )

    @property
    def key(self) -> str:
        return self.product_id

    def page_url(self, page_index: int) -> str:
        return gao_product_url(self.product_id)

    def parse_page(self, body: bytes, *, page_index: int, max_bytes: int, **_listing: object) -> GaoOldReportPage:
        if page_index != 0:
            raise GaoListingSourceError("a GAO product page is one page")
        decode_html_page(body, max_bytes, label=_PAGE_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoListingSourceError)
        heading = read_product_heading(body, product_id=self.product_id)
        # The shared rule lets a page id carry Drupal's ``-N`` suffix (``ogc-96`` for ``ogc-96-9``); a report's has none.
        if heading.product_number != self.product_id.upper():
            raise GaoListingSourceError(
                f"{_PAGE_LABEL} {self.product_id} states {heading.product_number}, not {self.product_id.upper()}"
            )
        if len(heading.title) > MAX_TEXT:
            raise GaoListingSourceError(f"{_PAGE_LABEL} {self.product_id} heading exceeds its length bound")
        return GaoOldReportPage(0, 0, (heading,))


def _scope_of(key: str) -> GaoOldIndex | GaoOldReport:
    return INDEX if key == SCOPE_KEY else GaoOldReport(key)


@dataclass(frozen=True, slots=True)
class GaoOldIndexRun:
    """A walk re-read and verified; its pages and reports only once the index and every report's page are retained."""

    #: The index's capture, then each report's product page in listed order (``pages[1:]`` pairs with ``reports``).
    pages: tuple[RetainedListingPage, ...]
    #: The index's entries, in listed order; empty until the index is retained.
    entries: tuple[GaoOldIndexEntry, ...]
    reports: tuple[GaoMajorRuleReport, ...]
    #: Reports whose page is not retained yet.
    missing: tuple[str, ...]
    complete: bool


def read_old_index_run(receipts: Path, store: Path, *, max_page_bytes: int = MAX_PAGE_BYTES) -> GaoOldIndexRun:
    """Re-read a walk: every digest re-checked, the index re-parsed against its pin and each page against its report.

    A report is the index's word that the page is a major-rule report, and the page's own number, heading and day;
    its page states the index's number, since the page's scope is that number's page and admits no other. The
    index's date stands only where the page states no day. Reports are returned only once the index and every
    report's page are retained; a retained page the index does not list refuses.
    """
    retained = read_retained_pages(
        receipts, store, scope_of=_scope_of, max_page_bytes=max_page_bytes, max_last_page_index=_LAST_PAGE_BOUND
    )
    by_url = {page.capture.requested_url: page for page in retained.pages}
    index = by_url.pop(INDEX_URL, None)
    if index is None:
        return GaoOldIndexRun((), (), (), (), False)
    entries: tuple[GaoOldIndexEntry, ...] = index.page.entries  # type: ignore[assignment]
    pages = [by_url.pop(gao_product_url(entry.product_id), None) for entry in entries]
    if by_url:
        raise GaoListingSourceError(f"the walk retains pages the index does not list: {sorted(by_url)[:5]}")
    missing = tuple(entry.product_number for entry, page in zip(entries, pages, strict=True) if page is None)
    if missing:
        return GaoOldIndexRun((), entries, (), missing, False)
    headings: list[GaoProductHeading] = [page.page.entries[0] for page in pages]  # type: ignore[union-attr,misc]
    reports = tuple(
        GaoMajorRuleReport(
            entry.product_id,
            heading.product_number,
            heading.title,
            heading.published_date or entry.issued,
            (0,),
            SCOPE_KEY,
        )
        for entry, heading in zip(entries, headings, strict=True)
    )
    return GaoOldIndexRun((index, *pages), entries, reports, (), True)  # type: ignore[arg-type]


def walk_old_index(
    *,
    store: Path,
    receipts: Path,
    max_page_bytes: int = DEFAULT_MAX_PAGE_BYTES,
    timeout_seconds: float = 180.0,
    transport: httpx.BaseTransport | None = None,
) -> int:
    """Retain the index from the Archive, keyless: one request the first time, none once it is retained.

    The shared walk writes its receipt and bytes beside the report pages'; 0 when the index is retained, else 1
    with the failure recorded. ``transport`` replaces the direct one, for a test.
    """
    import httpx

    from spicy_docs.transport.zyte import ZyteBudget

    budget = GaoListingBudget(
        max_page_bytes=max_page_bytes,
        timeout_seconds=timeout_seconds,
        min_request_interval_seconds=0,
        max_last_page_index=_LAST_PAGE_BOUND,
    )
    return walk_listing(
        [INDEX],
        acquirers=lambda: GaoListingAcquirer(budget=budget, transport=transport or httpx.HTTPTransport()),
        store=store,
        receipts=receipts,
        # The walk's request ceiling, not a Zyte spend: this request goes straight to the Archive.
        zyte_budget=ZyteBudget(1),
        spacing_seconds=0,
    )


def _report_scopes(args: argparse.Namespace) -> list[GaoOldReport]:
    run = read_old_index_run(args.receipts, args.store, max_page_bytes=args.max_page_bytes)
    if not run.entries:
        raise GaoListingSourceError(f"{_LABEL} is not retained; the report pages wait for it")
    return [GaoOldReport(entry.product_id) for entry in run.entries]


def _read(args: argparse.Namespace) -> int:
    run = read_old_index_run(args.receipts, args.store)
    write_items(
        ((report.kind, report) for report in run.reports),
        {
            "pages": len(run.pages),
            "listed": len(run.entries),
            "reports": len(run.reports),
            "missing": len(run.missing),
            "complete": run.complete,
        },
        args.output,
    )
    return 0


def parser() -> argparse.ArgumentParser:
    """The command's arguments; its defaults are the polite walk, one request every 420 seconds."""
    parser = argparse.ArgumentParser(description="Walk or read GAO's 1996-2000 major-rule reports from its old index")
    commands = parser.add_subparsers(dest="command", required=True)
    add_walk_arguments(
        commands.add_parser("walk", help="Retain the archived index, then each report's page through Zyte, resuming")
    )
    add_read_arguments(commands.add_parser("read", help="Verify a retained walk offline and print reports as JSONL"))
    return parser


def main(argv: Sequence[str] | None = None, *, archive: httpx.BaseTransport | None = None) -> int:
    """Run the command; ``archive`` replaces the direct transport the index is fetched through, for a test."""
    args = parser().parse_args(argv)
    if args.command == "read":
        return _read(args)
    try:
        stopped = walk_old_index(
            store=args.store,
            receipts=args.receipts,
            max_page_bytes=args.max_page_bytes,
            timeout_seconds=args.timeout_seconds,
            transport=archive,
        )
    except (ValueError, OSError) as error:
        print(error, file=sys.stderr)
        return 1
    return stopped or walk_command(args, lambda: _report_scopes(args), max_last_page_index=_LAST_PAGE_BOUND)


__all__ = [
    "INDEX",
    "INDEX_SHA256",
    "INDEX_URL",
    "SCOPE_KEY",
    "GaoOldIndex",
    "GaoOldIndexEntry",
    "GaoOldIndexPage",
    "GaoOldIndexRun",
    "GaoOldReport",
    "GaoOldReportPage",
    "main",
    "parse_old_index",
    "parser",
    "read_old_index_run",
    "walk_old_index",
]


if __name__ == "__main__":
    raise SystemExit(main())
