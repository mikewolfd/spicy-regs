"""Who a GAO report is addressed to, read from its PDF's front matter: requester type, committees and members.

A product page states none of the three (``product_details``); the report's PDF does, in up to three places
(owner decision 2026-10-05; measurement in ``corpora/gao-requesters-2026-10-05/``)::

    Report to the Ranking Member,            <- the cover's statement (page 1)
    Committee on Ways and Means,
    House of Representatives

    441 G St. N.W.                           <- the letter's head: GAO's address, the date, then the addressees
    Washington, DC 20548
    January 27, 2015
    The Honorable Sander Levin
    Ranking Member
    Committee on Ways and Means
    House of Representatives

A letter to many names them once, collectively (``Congressional Requesters``, ``Congressional Committees``,
``Congressional Addressees``), and lists them after its signature under a heading (``List of Requesters``,
``List of Committees``, ``Congressional Addressees``), pages into the file. A report in GAO's 2023 page design has
no letter head and prints the same blocks where its letter ends. The reader takes the first of those it finds:

- **an addressee block** is one or more ``The Honorable <name>`` lines, each with the role printed after it (on its
  line after a comma, or on the next line), then the bodies they are addressed at (a subcommittee, its committee) and
  the chamber. Two members of one committee share its lines, and a seat not yet filled is its role alone
  (gao-21-223r, January 2021: ``Chair`` / ``Ranking Member`` / ``Committee on Small Business and Entrepreneurship``).
  A long list prints a member and the chamber on one line (gao-26-109087: ``The Honorable Becca Balint, House of
  Representatives``). A run of blocks is Congress's when one states a chamber and each committee has its chamber,
  and is read whole or not at all: where a line in it is not one the reader knows, the type is still stated and the
  lists are ``unread``;
- **members**, each once, in the PDF's order: ``<name>, <role>`` as printed (``Betty McCollum, Ranking Member``),
  or ``<name> (Senate)`` for a member addressed by chamber alone;
- **committees**, each once, in the PDF's order: ``<committee> (House)`` or ``(Senate)``, the committee's name as
  printed (``Committee on Veterans’ Affairs``, ``Special Committee on Aging``, ``Energy and Commerce Committee``).
  A subcommittee's block gives its committee, and the subcommittee itself only where the block names no committee.
  A commission or a caucus is no committee and stays in the evidence.

A letter whose head names no addressee (gao-20-16 prints only ``Dear Mr. Graves:``) leaves the cover's statement:
its committee is read where the name reads, and no member. A run of blocks that states no chamber is taken for an
addressee outside Congress, since an agency's head chairs a commission too.

These are the spellings ``gao_reports`` already holds, copied from the CetiAlphaFive/gao R package, so a row this
reader fills compares with one the package filled. Nothing here is taken from that package's code: the rule is
written from the PDFs, and the package's values are only what it was measured against.

**The requester type** is the package's word for what the front matter states, in this order:

- ``testimony``: the cover says ``Testimony`` (``Testimony Before the Subcommittee on ...``) or ``Statement for the
  Record``. Its committees and members are not read: the package states none for a testimony;
- ``cg_initiated``: the cover says ``By the Comptroller General of the United States``, or the letter is on the
  Comptroller General's own letterhead and addressed outside Congress (the Priority Open Recommendations letters);
- ``correspondence``: the number the PDF states ends in ``R`` (``GAO-15-601R``), GAO's own mark for a letter until
  it stopped giving one in fiscal year 2022, whoever the letter is addressed to;
- ``congressional_request``: any addressee in Congress, collective or named.

So the type reads the addressee, not why GAO did the work, as the package's does: a mandated report GAO addresses
to ``Congressional Committees`` is ``congressional_request`` in both (gao-23-106042's letter says a committee report
"included a provision for us to report"). **``statutory_mandate`` is never read.** The package gives it to some
reports addressed to ``Congressional Addressees`` and ``congressional_request`` or ``cg_initiated`` to others, and
neither the cover nor the reason the letter states tells them apart (gao-22-104093's letter says "own initiative"
and is the package's ``statutory_mandate``; gao-21-367's states the CARES Act's provision and is its
``congressional_request``); ``docs/decisions.md`` has the counts.

The text is the PDF's own (``extraction.api.NativeText``), not the GPO-normalized derivation ``rendition_text`` gives:
that one folds curly quotes, and a name is published as GAO printed it (``Robert C. “Bobby” Scott``). The PDF must
state the product's number in its first pages, or it is another report's and refuses (gao-21-336's file is
GAO-21-322). A front matter in which no addressee is read, or one outside Congress is, refuses, with the check
that failed on the error's ``reason``; nothing is guessed.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Final

from spicy_docs.sources.gao.listing import names_page
from spicy_docs.sources.gao.native import gao_product_id

#: The rule a host records beside the values it fills from this reader.
REPORT_REQUESTERS_RULE: Final = "gao-report-front-matter-requesters/1"
#: The values this reader gives the published column, as the R package named them. It holds two more this reader
#: never gives: ``statutory_mandate`` (module docstring) and ``legal_decision``, which is ``gao_decisions``'.
TESTIMONY: Final = "testimony"
CG_INITIATED: Final = "cg_initiated"
CORRESPONDENCE: Final = "correspondence"
CONGRESSIONAL_REQUEST: Final = "congressional_request"
REQUESTER_TYPES: Final = (CONGRESSIONAL_REQUEST, TESTIMONY, CORRESPONDENCE, CG_INITIATED)
#: Where the committees and members were read: the letter's head (``named``); the list a collective letter gives after
#: its signature, or the blocks a report without a letter head prints where its letter ends (``listed``); the cover's
#: statement alone, which names a committee and no member (``cover``); nowhere in the pages given, the letter naming
#: its addressees only collectively (``collective``); in blocks that hold a line the reader does not know
#: (``unread``); or not read for this type (``not-read``). Under ``collective`` and ``unread`` the committees and
#: members are unknown, not none.
NAMED: Final = "named"
LISTED: Final = "listed"
COVER: Final = "cover"
COLLECTIVE: Final = "collective"
UNREAD: Final = "unread"
NOT_READ: Final = "not-read"
#: Why a front matter is refused; :class:`GaoReportRequesterError` carries one as ``reason``.
REFUSALS: Final = ("no-text", "not-this-report", "no-addressee-read", "addressee-not-congressional")

#: Pages the number and the letter's head are looked for in; the cover's statement is on the first, and a list may
#: be on any (page 256 of gao-16-375sp's 298). Of the 80 development PDFs every one states its number on page 1 and
#: none starts its letter after page 11, behind its contents and abbreviations.
_NUMBER_PAGES: Final = 3
_HEAD_PAGES: Final = 30
#: Zero-width and soft-hyphen characters: format, not prose.
_FORMAT: Final = re.compile("[\u00ad\u200b-\u200d\u2060\ufeff]")
_NUMBER: Final = re.compile(r"\b[A-Z]{2,5}-\d{2}-\d+[A-Z]{0,2}\b")
#: GAO's mark for a letter, the whole of a number's suffix: ``GAO-20-287PR`` is a priority-recommendations letter.
_LETTER_NUMBER: Final = re.compile(r"\dR")
_MONTHS: Final = "January|February|March|April|May|June|July|August|September|October|November|December"
_DATE: Final = re.compile(rf"(?:{_MONTHS})(?: \d{{1,2}},)? \d{{4}}")
_COLLECTIVE: Final = re.compile(r"Congressional (?:Requesters?|Committees?|Addressees?)")
#: A word that makes a cover's named addressee Congress's.
_CONGRESS: Final = re.compile(
    r"\b(?:Congressional|Congress|Subcommittees?|Committees?|Senate|House of Representatives|Senators?|Caucus)\b"
)
#: A committee and its chamber in a cover's statement (``Committee on Finance, U.S. Senate``).
_COVER_BODY: Final = (
    r"{kind} on [^;]+?),? "
    r"(?P<chamber>U\.S\. Senate|United States Senate|(?:U\.S\. |United States )?House of Representatives)"
)
_COVER_COMMITTEE: Final = re.compile(
    "(?P<body>(?:(?:Permanent Select|Select|Special|Joint) )?" + _COVER_BODY.format(kind="Committee")
)
_COVER_SUBCOMMITTEE: Final = re.compile("(?P<body>" + _COVER_BODY.format(kind="Subcommittee"))
#: What a cover's committee name cannot hold: a second body, or the role of a second addressee.
_NOT_A_NAME: Final = re.compile(r"ommittee\b.*ommittee\b|\b(?:Chair|Ranking|Member)")
_TESTIMONY: Final = re.compile(r"Testimony(?: [Bb]efore\b.*)?|Statement for the Record\b.*")
_REPORT_TO: Final = re.compile(r"(?:\S+ )?Report to\b.*")
_BY_THE_CG: Final = re.compile(r"By the Comptroller General of the United States")
#: Where a cover's statement stops: the date, the number, GAO's name, a revision note.
_COVER_END: Final = re.compile(
    rf"(?:{_MONTHS})\b|[A-Z]{{2,5}}-\d{{2}}-\d|United States Government|For Release|Revised\b|Accessible\b"
)
_CHAMBER_END: Final = re.compile(r"(?:Senate|House of Representatives)$")
_MAX_COVER_LINES: Final = 8

_LETTERHEAD: Final = re.compile(r"441 G St")
_CG_LETTERHEAD: Final = re.compile(r"Comptroller General\b")
#: Lines between GAO's address and the addressee, after the address's own second line: the Comptroller General's
#: name, the date, a heading, a title printed first (gao-17-730r prints two lines of it).
_MAX_HEAD_LINES: Final = 6
_HONORABLE: Final = "The Honorable "
#: A role as a letter prints it under, or after, a member's name.
_ROLE: Final = re.compile(
    r"(?:Acting |Interim )?(?:"
    r"(?:Co-|Vice[ -])?Chair(?:man|woman|person)?(?: Emeritus)?"
    r"|Ranking (?:Minority )?Member"
    r"|(?:Majority|Minority|Republican|Democratic) (?:Leader|Whip)"
    r"|Speaker(?: of the House(?: of Representatives)?)?"
    r"|President [Pp]ro [Tt]empore(?: of the Senate)?"
    r")"
)
#: A chamber as a block's last line spells it, a longer spelling before the one it ends with.
_CHAMBERS: Final = {
    "United States House of Representatives": "House",
    "U.S. House of Representatives": "House",
    "House of Representatives": "House",
    "United States Senate": "Senate",
    "U.S. Senate": "Senate",
}
#: What a body is, wherever its name puts the word (``Committee on Finance``, ``Energy and Commerce Committee``).
_BODY_KIND: Final = re.compile(r"\b(?:Subcommittee|Committee|Commission|Caucus)\b")
#: A body's name where a line starts with it: at most four capitalized words, then what it is.
_BODY: Final = re.compile(r"(?:[A-Z][\w.’'-]* ){0,4}(?:Subcommittee|Committee|Commission|Caucus)\b")
#: Where a second body starts inside a line: the text layer gives gao-20-534's wrapped subcommittee as
#: ``Related Agencies Committee on Appropriations``. Never inside a name: ``Special Committee on Aging`` is one body.
_BODY_START: Final = re.compile(
    r"(?<=\s)(?<!Permanent )(?<!Select )(?<!Special )(?<!Joint )"
    r"(?=(?:Permanent |Select )?Subcommittee on |(?:Permanent Select |Select |Special |Joint )?Committee on )"
)
#: Lines a block's bodies may take, a wrapped name's included.
_MAX_BODY_LINES: Final = 6
#: The heading over a list, at a line's end (``Appendix I: List of Congressional Addressees``, ``Congressional
#: Committees``; gao-26-108439 prints ``List of Addresses``), and over its next page (gao-21-367: ``List of Addressees
#: Continued``).
_LIST_HEADING: Final = re.compile(
    r"\b(?:List of (?:Congressional )?\w+|Congressional (?:Requesters|Committees|Addressees))"
    r"(?: \(?[Cc]ontinued\)?)?$"
)
_PAGE_MARK: Final = re.compile(r"Page \w+\b")
#: Lines a page may hold after a list's blocks and before the page ends: the 2023 design's margin headings, which the
#: text layer gives last (gao-26-107779 has four).
_MAX_MARGIN_LINES: Final = 8
#: Lines after a run in which another block means the run was cut by a line the reader does not know: gao-18-472
#: lists ``Resident Commissioner Jenniffer González-Colón`` without ``The Honorable``, nine members before its end.
_MAX_CUT_LINES: Final = 4
_CONGRESS_RUN: Final = "congress"
_OUTSIDE_RUN: Final = "outside"
_UNREADABLE_RUN: Final = "unreadable"


class GaoReportRequesterError(ValueError):
    """A front matter that cannot establish its report's requesters; ``reason`` is one of :data:`REFUSALS`."""

    def __init__(self, reason: str, message: str) -> None:
        super().__init__(f"GAO report front matter: {message}")
        self.reason = reason


@dataclass(frozen=True, slots=True)
class RequesterEvidence:
    """One statement the values were read from: what it is, its one-based PDF page and its lines as printed."""

    kind: str
    page: int
    text: str


@dataclass(frozen=True, slots=True)
class GaoReportRequesters:
    """What one report's front matter states; under ``COLLECTIVE`` and ``UNREAD`` the empty lists are unknown."""

    product_id: str
    requester_type: str
    committees: tuple[str, ...]
    members: tuple[str, ...]
    addressees: str
    evidence: tuple[RequesterEvidence, ...]
    rule: str = REPORT_REQUESTERS_RULE


@dataclass(frozen=True, slots=True)
class _Line:
    page: int
    text: str


@dataclass(frozen=True, slots=True)
class _Block:
    """One addressee block: its members as ``(name, role)``, the bodies under them and the chamber.

    A name is None for a role printed alone; ``bodies`` is None where a line between the members and the chamber
    names no body the reader knows.
    """

    honorees: tuple[tuple[str | None, str | None], ...]
    bodies: tuple[str, ...] | None
    chamber: str | None


@dataclass(frozen=True, slots=True)
class _Run:
    """Consecutive addressee blocks, ``lines[start:end]``, and whether they are Congress's."""

    start: int
    end: int
    blocks: tuple[_Block, ...]
    state: str


@dataclass(frozen=True, slots=True)
class _Head:
    """A letter's head, ``lines[start:end]``: whether it is the Comptroller General's, and its addressee."""

    start: int
    end: int
    comptroller: bool
    collective: _Line | None
    run: _Run | None


def _lines(pages: Sequence[str]) -> list[_Line]:
    """Each printed line with its page, whitespace collapsed, blank lines dropped."""
    return [
        _Line(number, text)
        for number, page in enumerate(pages, 1)
        for raw in _FORMAT.sub("", page).split("\n")
        if (text := " ".join(raw.split()))
    ]


def _evidence(kind: str, lines: Sequence[_Line]) -> RequesterEvidence:
    return RequesterEvidence(kind, lines[0].page, "\n".join(line.text for line in lines))


def _stated_number(lines: Sequence[_Line], product_id: str) -> tuple[str, _Line]:
    """The number the first pages print that names this product's page, with the line printing it."""
    seen: dict[str, None] = {}
    for line in lines:
        if line.page > _NUMBER_PAGES:
            break
        for number in _NUMBER.findall(line.text):
            if names_page(product_id, number, exact=True):
                return number, line
            seen.setdefault(number)
    raise GaoReportRequesterError(
        "not-this-report", f"the first pages state {list(seen) or 'no number'}, not {product_id}'s"
    )


def _cover(lines: Sequence[_Line]) -> tuple[str, list[_Line]] | None:
    """The first page's statement of what the product is: ``(kind, lines)``, kind testimony, comptroller or report."""
    first = [line for line in lines if line.page == 1]
    for at, line in enumerate(first):
        if _TESTIMONY.fullmatch(line.text):
            return TESTIMONY, _statement(first, at)
        if _REPORT_TO.fullmatch(line.text):
            return "report", _statement(first, at)
    for at in range(len(first)):
        # GAO wraps the phrase on a cover (gao-17-313sp: "By the Comptroller General of the / United States").
        if _BY_THE_CG.match(" ".join(part.text for part in first[at : at + 3])):
            return CG_INITIATED, first[at : at + 2]
    return None


def _statement(first: Sequence[_Line], at: int) -> list[_Line]:
    """A cover statement's lines: to its chamber, or to the date, number or name that follows it."""
    taken = [first[at]]
    if _COLLECTIVE.search(first[at].text):
        return taken
    for line in first[at + 1 : at + _MAX_COVER_LINES]:
        if _CHAMBER_END.search(taken[-1].text) or _COVER_END.match(line.text):
            break
        taken.append(line)
    return taken


def _cover_committees(statement: str) -> tuple[str, ...]:
    """The committees a cover's statement names, spelled as a block's are; none where a name does not read."""
    found = list(_COVER_COMMITTEE.finditer(statement)) or list(_COVER_SUBCOMMITTEE.finditer(statement))
    if any(_NOT_A_NAME.search(match["body"]) for match in found):
        return ()
    chambers = {"Senate": "Senate", "House of Representatives": "House"}
    return tuple(
        dict.fromkeys(f"{match['body']} ({chambers[_CHAMBER_END.search(match['chamber'])[0]]})" for match in found)
    )


def _starts_block(text: str) -> bool:
    return text.startswith(_HONORABLE) or _ROLE.fullmatch(text) is not None


def _honoree(text: str) -> tuple[str | None, str | None, str | None]:
    """A block's first kind of line as ``(name, role, chamber)``: a role alone, or ``The Honorable`` and a name.

    The line may print the member's role, or the chamber, after the name's last comma.
    """
    if not text.startswith(_HONORABLE):
        return None, text, None
    name = text.removeprefix(_HONORABLE)
    head, comma, tail = name.rpartition(", ")
    if comma and _ROLE.fullmatch(tail):
        return head, tail, None
    if comma and tail in _CHAMBERS:
        return head, None, _CHAMBERS[tail]
    return name, None, None


def _bodies(between: Sequence[str]) -> tuple[str, ...] | None:
    """The bodies the lines between a block's members and its chamber name; None where the first names none.

    A line that names a body starts one, and so does ``Committee on`` or ``Subcommittee on`` inside a line; any other
    line is the wrapped end of the body before it.
    """
    bodies: list[str] = []
    for text in between:
        for at, part in enumerate(_BODY_START.split(text)):
            if at or _BODY_KIND.search(part):
                bodies.append(part.strip(" ,"))
            elif bodies:
                bodies[-1] = f"{bodies[-1]} {part}"
            else:
                return None
    return tuple(bodies)


def _chamber(lines: Sequence[_Line], index: int, first: int) -> tuple[str, str] | None:
    """The chamber ``lines[index]`` states, with what the line prints before it.

    The chamber has its own line but where a wrapped body's last words share it (gao-18-371sp: ``Committee on
    Homeland Security and Governmental`` / ``Affairs United States Senate``); a line of prose that ends with a
    chamber's name is none.
    """
    text = lines[index].text.lstrip("|")  # gao-26-108061 prints "|House of Representatives"
    for spelling, chamber in _CHAMBERS.items():
        if text == spelling:
            return "", chamber
        if text.endswith(f" {spelling}"):
            before = text.removesuffix(spelling).rstrip(" ,")
            if _BODY.match(before) or (index > first and _BODY_KIND.search(lines[index - 1].text)):
                return before, chamber
    return None


def _block(lines: Sequence[_Line], at: int) -> tuple[_Block, int]:
    """The addressee block starting at ``lines[at]``, and the index after it."""
    honorees: list[tuple[str | None, str | None]] = []
    while at < len(lines) and _starts_block(lines[at].text):
        name, role, chamber = _honoree(lines[at].text)
        width = 1
        if role is None and chamber is None and at + 1 < len(lines):
            # The chamber wrapped: gao-26-109087 prints ``..., Jr., House of`` / ``Representatives``.
            wrapped = _honoree(f"{lines[at].text} {lines[at + 1].text}")
            if wrapped[2] is not None:
                (name, role, chamber), width = wrapped, 2
        if chamber is not None and honorees:
            return _Block(tuple(honorees), (), None), at  # members still waiting for their chamber are not its
        if chamber is not None:
            return _Block(((name, None),), (), chamber), at + width  # a member and the chamber on one line
        at += 1
        if role is None and at < len(lines) and _ROLE.fullmatch(lines[at].text):
            role = lines[at].text
            at += 1
        honorees.append((name, role))
    # The bodies end at the chamber, or at the next block; without either, only lines that start as a body are theirs.
    for stop in range(at, min(at + _MAX_BODY_LINES + 1, len(lines))):
        ended = None if _starts_block(lines[stop].text) else _chamber(lines, stop, at)
        if ended is not None or _starts_block(lines[stop].text):
            between = [line.text for line in lines[at:stop]] + ([ended[0]] if ended and ended[0] else [])
            return _Block(tuple(honorees), _bodies(between), ended and ended[1]), stop + (ended is not None)
    stop = at
    while stop < len(lines) and stop < at + _MAX_BODY_LINES and _BODY.match(lines[stop].text):
        stop += 1
    return _Block(tuple(honorees), tuple(line.text for line in lines[at:stop]), None), stop


def _congress(block: _Block) -> bool:
    """Whether a block in a run that states a chamber reads as Congress's: every committee with its chamber."""
    if block.bodies is None:
        return False
    if block.chamber is not None:
        return True
    return bool(block.bodies) and not any(_BODY_KIND.search(body)[0].endswith("ommittee") for body in block.bodies)


def _page_line(text: str, number: str) -> bool:
    """A page's own header or footer line: its page mark, or the line stating the report's number."""
    return _PAGE_MARK.fullmatch(text) is not None or number in text


def _run(lines: Sequence[_Line], at: int, number: str) -> _Run:
    """The run of addressee blocks starting at ``lines[at]``.

    Between two blocks only a page's own lines may stand: its header and footer, a list's heading, and at a page's
    end the margin headings GAO's 2023 design prints beside the blocks, which the text layer gives after them
    (gao-24-106214 and gao-26-107779, whose lists run on to the next page).
    """
    start, blocks = at, []
    while at < len(lines) and _starts_block(lines[at].text):
        block, at = _block(lines, at)
        blocks.append(block)
        after = _past_page_lines(lines, at, number)
        if not (after < len(lines) and _starts_block(lines[after].text)):
            turn = at
            while turn < len(lines) and lines[turn].page == lines[at - 1].page:
                turn += 1
            if turn - at <= _MAX_MARGIN_LINES:
                after = _past_page_lines(lines, turn, number)
        if after < len(lines) and _starts_block(lines[after].text):
            at = after
    cut = any(
        line.page == lines[at - 1].page and line.text.startswith(_HONORABLE) for line in lines[at : at + _MAX_CUT_LINES]
    )
    if not any(block.chamber for block in blocks):
        state = _OUTSIDE_RUN
    elif not cut and all(_congress(block) for block in blocks):
        state = _CONGRESS_RUN
    else:
        state = _UNREADABLE_RUN
    return _Run(start, at, tuple(blocks), state)


def _past_page_lines(lines: Sequence[_Line], at: int, number: str) -> int:
    while at < len(lines) and (_page_line(lines[at].text, number) or _LIST_HEADING.search(lines[at].text)):
        at += 1
    return at


def _head(lines: Sequence[_Line], number: str) -> _Head | None:
    """The first letter head in the front pages: GAO's street address, then an addressee or a date within a few lines.

    The address alone is no head: a report's last page prints it over the copyright notice (gao-25-107981).
    """
    for at, line in enumerate(lines):
        if line.page > _HEAD_PAGES:
            return None
        if not _LETTERHEAD.match(line.text):
            continue
        # The Comptroller General's name stands under the address, or over it (gao-15-341r).
        start = at - 2 if any(_CG_LETTERHEAD.match(part.text) for part in lines[max(at - 2, 0) : at]) else at
        # On the address's own page: the next page's letter is not this address's.
        window = [
            index
            for index in range(at + 1, min(at + 2 + _MAX_HEAD_LINES, len(lines)))
            if lines[index].page == line.page
        ]
        for index in window:
            comptroller = any(_CG_LETTERHEAD.match(part.text) for part in lines[start:index])
            if _COLLECTIVE.fullmatch(lines[index].text.rstrip(",:")):
                return _Head(start, index + 1, comptroller, lines[index], None)
            if _starts_block(lines[index].text):
                run = _run(lines, index, number)
                return _Head(start, run.end, comptroller, None, run)
        dated = [index for index in window if _DATE.fullmatch(lines[index].text)]
        if dated:
            return _Head(start, dated[0] + 1, False, None, None)
    return None


def _heading(lines: Sequence[_Line], at: int, number: str) -> int | None:
    """Where the list heading over ``lines[at]`` starts: the one or two lines before it on its page, less page lines."""
    back = at - 1
    while back >= 0 and lines[back].page == lines[at].page and _page_line(lines[back].text, number):
        back -= 1
    for first in (back, back - 1):
        if first < 0 or lines[first].page != lines[at].page:
            return None
        if _LIST_HEADING.search(" ".join(line.text for line in lines[first : back + 1])):
            return first
    return None


def _listed(lines: Sequence[_Line], begin: int, number: str, *, headed: bool) -> tuple[_Run, int] | None:
    """The first run of blocks from ``lines[begin]`` on that states a chamber, with the index its evidence starts at.

    ``headed`` takes only a run standing under a list heading, which is how a letter with a head lists the
    addressees it named collectively; without it the first run serves, for a report that has no letter head. The run
    may be one the reader cannot read whole.
    """
    at = begin
    while at < len(lines):
        if not _starts_block(lines[at].text):
            at += 1
            continue
        run = _run(lines, at, number)
        heading = _heading(lines, at, number)
        if run.state != _OUTSIDE_RUN and (heading is not None or not headed):
            return run, at if heading is None else heading
        at = max(run.end, at + 1)
    return None


def _values(blocks: Sequence[_Block]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """The committees and members a run of blocks states, in its order, each once."""
    committees: dict[str, None] = {}
    members: dict[str, None] = {}
    for block in blocks:
        chamber = "" if block.chamber is None else f" ({block.chamber})"
        for name, role in block.honorees:
            if name is not None:
                members.setdefault(f"{name}, {role}" if role else f"{name}{chamber}")
        kinds = [(_BODY_KIND.search(body)[0], body) for body in block.bodies or ()]
        named = [body for kind, body in kinds if kind == "Committee"] or [
            body for kind, body in kinds if kind == "Subcommittee"
        ]
        for body in named:
            committees.setdefault(f"{body}{chamber}")
    return tuple(committees), tuple(members)


def read_requesters(pages: Sequence[str], *, product_id: str) -> GaoReportRequesters:
    """The requester type, committees and members a report's page texts state; ``pages`` is one string a PDF page.

    A prefix of the pages serves: where the letter names its addressees collectively and the pages given hold no
    list, the result is ``COLLECTIVE`` with both lists empty. Refuses (``GaoReportRequesterError.reason``) pages
    without text (``no-text``), another report's (``not-this-report``) and a front matter in which no addressee is
    read (``no-addressee-read``) or one outside Congress is (``addressee-not-congressional``). Addressee blocks that
    hold a line the reader does not know give the type with ``UNREAD`` lists. O(L) in the lines given, but for a
    text that prints ``The Honorable`` again and again outside its addressee blocks.
    """
    product_id = gao_product_id(product_id)
    lines = _lines(pages)
    if not lines:
        raise GaoReportRequesterError("no-text", "the pages given hold no text")
    number, numbered = _stated_number(lines, product_id)
    evidence = [_evidence("number", [numbered])]

    def result(kind: str, committees=(), members=(), addressees: str = NOT_READ) -> GaoReportRequesters:
        return GaoReportRequesters(product_id, kind, committees, members, addressees, tuple(evidence))

    cover = _cover(lines)
    if cover is not None:
        evidence.append(_evidence("cover", cover[1]))
    if cover is not None and cover[0] in (TESTIMONY, CG_INITIATED):
        return result(cover[0])
    statement = "" if cover is None else " ".join(line.text for line in cover[1])
    letter = _LETTER_NUMBER.search(number) is not None
    kind = CORRESPONDENCE if letter else CONGRESSIONAL_REQUEST
    head = _head(lines, number)
    run = None if head is None else head.run
    if run is not None and run.state == _OUTSIDE_RUN:
        evidence.append(_evidence("letter", lines[head.start : head.end]))
        if letter or head.comptroller:
            return result(CORRESPONDENCE if letter else CG_INITIATED)
        raise GaoReportRequesterError(
            "addressee-not-congressional", f"the letter is addressed to {lines[run.start].text!r}"
        )
    if run is not None:
        evidence.append(_evidence("letter", lines[run.start : run.end]))
        if run.state != _CONGRESS_RUN:
            return result(kind, addressees=UNREAD)
        return result(kind, *_values(run.blocks), NAMED)
    collective = statement if _COLLECTIVE.search(statement) else ""
    if head is not None and head.collective is not None:
        collective = head.collective.text
        evidence.append(_evidence("letter", [head.collective]))
    if not collective and not _CONGRESS.search(statement):
        if letter:
            return result(CORRESPONDENCE)
        if cover is None:
            raise GaoReportRequesterError(
                "no-addressee-read", "no cover statement and no addressee the reader knows in a letter's head"
            )
        raise GaoReportRequesterError("addressee-not-congressional", f"the cover states {statement!r}")
    found = _listed(lines, 0 if head is None else head.end, number, headed=head is not None)
    if found is not None:
        evidence.append(_evidence("list", lines[found[1] : found[0].end]))
        if found[0].state != _CONGRESS_RUN:
            return result(kind, addressees=UNREAD)
        return result(kind, *_values(found[0].blocks), LISTED)
    if collective:
        return result(kind, addressees=COLLECTIVE)
    return result(kind, _cover_committees(statement), (), COVER)


def read_pdf_requesters(body: bytes, *, product_id: str, extractor=None) -> GaoReportRequesters:
    """The requesters a report's PDF states, its page texts read by the PDF's own text layer (``NativeText``).

    ``extractor`` replaces the default ``DocumentExtractor(NativeText())``, for a test or another byte bound; a PDF
    over the extractor's bound, encrypted or unreadable raises as the extractor raises.
    """
    if extractor is None:
        from spicy_docs.extraction.api import DocumentExtractor, NativeText

        extractor = DocumentExtractor(NativeText())
    pages = [result.text for result in extractor.extract(body, media_type="application/pdf")]
    return read_requesters(pages, product_id=product_id)


__all__ = [
    "CG_INITIATED",
    "COLLECTIVE",
    "CONGRESSIONAL_REQUEST",
    "CORRESPONDENCE",
    "COVER",
    "LISTED",
    "NAMED",
    "NOT_READ",
    "REFUSALS",
    "REPORT_REQUESTERS_RULE",
    "REQUESTER_TYPES",
    "TESTIMONY",
    "UNREAD",
    "GaoReportRequesterError",
    "GaoReportRequesters",
    "RequesterEvidence",
    "read_pdf_requesters",
    "read_requesters",
]
