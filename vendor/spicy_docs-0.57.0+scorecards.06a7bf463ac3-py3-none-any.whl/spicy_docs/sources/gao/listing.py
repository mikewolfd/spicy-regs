"""What GAO's listing readers share: teaser text and keys, a paced resumable Zyte walk, and its offline re-read.

Two GAO listings are read page by page: the Month in Review and Annual Index (``month_in_review.py``) and the
Congressional Review Act's Reports on Major Rules (``major_rule_reports.py``). Each defines its scope, its page
parser and its entries; this module owns the rest. The old index of the 1996-2000 major-rule reports
(``major_rule_old_index.py``) walks through it too, its index and each report's page a scope of one page.
``www.gao.gov`` asks every agent for a 420-second
``Crawl-delay`` in ``robots.txt``, so the walk's default is one worker, one request every 420 seconds, under a hard
Zyte budget, resuming from its own receipts. The owner's rulings on access are in ``docs/decisions.md``.

A scope's pager states either its last page (the Month in Review) or only that another page follows (the major-rule
listing's "Load More"); the walk reads a scope page by page either way, and a scope is finished only once its last
page is retained.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import threading
from collections import deque
from collections.abc import Callable, Iterable, Sequence
from contextlib import nullcontext
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Final, Protocol
from uuid import uuid4

from spicy_docs.reading.markup import joined_text
from spicy_docs.sources.gao.native import names_page
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_byte_bound, check_timing, utc_now

if TYPE_CHECKING:
    import httpx

    from spicy_docs.transport.zyte import ZyteBudget, ZyteProxyRecord

#: ``robots.txt`` asks every agent for this ``Crawl-delay`` (read 2026-09-28); it is the walk's default spacing.
CRAWL_DELAY_SECONDS: Final = 420.0
#: Pages measured 45-92 KB on 2026-09-28 and 2026-09-29.
DEFAULT_MAX_PAGE_BYTES: Final = 4 * 1024 * 1024
MAX_PAGE_BYTES: Final = 16 * 1024 * 1024
#: The Month in Review's deepest pager seen was 2009's, last page index 87; a deeper one is refused rather than walked.
DEFAULT_MAX_LAST_PAGE_INDEX: Final = 199
#: Workers a walk may run. The 2026-09-28 backfill stalled at six (requests hanging to the 180 s timeout) and
#: finished at three with a 60 s timeout.
MAX_CONCURRENCY: Final = 8
#: The longest pause between failures in a row; the pause doubles from the backoff up to this.
MAX_BACKOFF_SECONDS: Final = 900.0
#: A scope whose listing moves while it is read is restarted from its first page this many times, then stopped.
MAX_SCOPE_RESTARTS: Final = 1
MAX_TEXT: Final = 4_000
#: HTML's own whitespace. A non-breaking space is text GAO wrote, and the feed's titles keep it.
_HTML_WHITESPACE = re.compile(r"[\t\n\f\r ]+")


class GaoListingSourceError(ValueError):
    """A listing page cannot establish the products GAO listed for its scope."""


class GaoListingMovedError(GaoListingSourceError):
    """A page disagrees with its scope's first page on the last page or the page size: the listing moved."""


class GaoListingUnavailableError(GaoListingSourceError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"GAO listing answered HTTP {capture.status_code}")
        self.capture = capture


class ListingPage(Protocol):
    """One parsed page: its index, the last page its pager states (None while another page follows), its teasers."""

    @property
    def page_index(self) -> int: ...
    @property
    def last_page_index(self) -> int | None: ...
    @property
    def entries(self) -> Sequence[object]: ...


class ListingScope(Protocol):
    """What the walk needs of a scope: a receipt key, each page's URL, and a parser that checks a page is its own."""

    @property
    def key(self) -> str: ...
    def page_url(self, page_index: int) -> str: ...
    def parse_page(
        self,
        body: bytes,
        *,
        page_index: int,
        max_bytes: int,
        max_last_page_index: int,
        expected_last_page_index: int | None,
        expected_page_size: int | None,
    ) -> ListingPage: ...


def listing_text(parts: list[str] | None, name: str, *, label: str) -> str:
    """A field's text with every run of whitespace one space."""
    return joined_text(parts or [], label=f"{label} {name}", bound=MAX_TEXT, error_type=GaoListingSourceError)


def spelled(parts: list[str] | None, name: str, *, label: str) -> str:
    """Text as GAO wrote it: references decoded, runs of HTML whitespace one space, non-breaking spaces kept."""
    value = _HTML_WHITESPACE.sub(" ", "".join(parts or [])).strip("\t\n\f\r ")
    if len(value) > MAX_TEXT:
        raise GaoListingSourceError(f"{label} {name} exceeds its length bound")
    return value


def listing_date(parts: list[str] | None, name: str, prefix: str, *, label: str) -> str | None:
    """GAO's ``Published: Jul 14, 2026.`` as ``2026-07-14``; an absent field stays None, an unreadable one refuses."""
    if parts is None:
        return None
    value = listing_text(parts, name, label=label)
    if not value.startswith(prefix):
        raise GaoListingSourceError(f"{label} {name} date does not begin {prefix!r}")
    try:
        return (
            datetime.strptime(value.removeprefix(prefix).strip().rstrip("."), "%b %d, %Y")
            .replace(tzinfo=UTC)
            .date()
            .isoformat()
        )
    except ValueError as error:
        raise GaoListingSourceError(f"{label} {name} date is not GAO's 'Mon DD, YYYY'") from error


@dataclass(frozen=True, slots=True)
class GaoListingBudget:
    """Bounds for one page's capture; the total Zyte spend is the transport's ``ZyteBudget``."""

    max_page_bytes: int = DEFAULT_MAX_PAGE_BYTES
    timeout_seconds: float = 180.0
    min_request_interval_seconds: float = CRAWL_DELAY_SECONDS
    max_last_page_index: int = DEFAULT_MAX_LAST_PAGE_INDEX

    def __post_init__(self) -> None:
        check_byte_bound(self.max_page_bytes, "max_page_bytes", MAX_PAGE_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)
        check_byte_bound(self.max_last_page_index, "max_last_page_index", 10_000)


class GaoListingAcquirer(SourceAcquirer):
    """One page per operation, one attempt each, paced; the transport is Zyte's, injected by the caller."""

    def __init__(
        self,
        *,
        budget: GaoListingBudget,
        transport: httpx.BaseTransport,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, GaoListingBudget):
            raise TypeError("budget must be a GaoListingBudget")
        self.budget = budget
        super().__init__(
            max_requests=1,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-gao-listing/1.0",
            label="GAO listing",
            error_type=GaoListingSourceError,
            context_key="gao_listing_acquisition",
            transport=transport,
            clock=clock,
        )

    def acquire_page(
        self,
        scope: ListingScope,
        page_index: int,
        *,
        expected_last_page_index: int | None = None,
        expected_page_size: int | None = None,
    ) -> tuple[ListingPage, CapturedBodyResponse]:
        url = scope.page_url(page_index)

        def parse(response: CapturedBodyResponse, limit: int) -> ListingPage:
            if response.status_code != 200:
                raise GaoListingSourceError(f"GAO listing answered HTTP {response.status_code}")
            return scope.parse_page(
                response.body,
                page_index=page_index,
                max_bytes=limit,
                max_last_page_index=self.budget.max_last_page_index,
                expected_last_page_index=expected_last_page_index,
                expected_page_size=expected_page_size,
            )

        return self.capture_validated(
            url,
            media_types=("text/html",),
            parse=parse,
            max_bytes=self.budget.max_page_bytes,
            unavailable=GaoListingUnavailableError,
            context={"operation": "listing-page", "scope": scope.key, "page_index": page_index, "url": url},
        )


@dataclass
class _Progress:
    last: int | None = None
    size: int | None = None
    rows: dict[int, dict] = field(default_factory=dict)
    #: Times the scope's listing moved and it was restarted from page 0.
    restarts: int = 0
    #: The first page not yet known to be retained; pages are retained in order, so it only moves forward.
    cursor: int = 0

    def add(self, row: dict) -> None:
        """One retained page; a row with no last page is an open pager's, saying only that another page follows."""
        last, index = row["last_page_index"], row["page_index"]
        if last is not None:
            if self.last is not None and last != self.last:
                raise GaoListingSourceError(f"receipts disagree on scope {row['scope']}'s last page")
            self.last = last
        if index == 0:
            self.size = row["entries"]
        self.rows[index] = row

    def next_page(self) -> int | None:
        while self.cursor in self.rows:
            self.cursor += 1
        if self.last is None:
            # Nothing read yet, or every page read so far said another follows.
            return self.cursor if self.cursor == 0 or self.cursor - 1 in self.rows else None
        return self.cursor if self.cursor <= self.last else None

    @property
    def stopped(self) -> bool:
        """Moved more often than a restart allows: walk it no more until someone looks at it."""
        return self.restarts > MAX_SCOPE_RESTARTS


def _read_receipts(receipts: Path) -> tuple[dict[str, _Progress], datetime | None]:
    """Each scope's retained pages, a later row for a page superseding an earlier one, and the last contact.

    A scope a walk was asked for is present even before any of its pages is retained, so it reads as unfinished.
    A ``moved`` row drops the scope's pages so far and counts a restart.
    """
    progress: dict[str, _Progress] = {}
    contact: datetime | None = None
    if not receipts.exists():
        return progress, None
    for line in receipts.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        stamp = row.get("observed_at") or row.get("attempted_at")
        if stamp:
            instant = datetime.fromisoformat(stamp)
            contact = instant if contact is None else max(contact, instant)
        if row.get("kind") == "started":
            for key in row.get("scopes", ()):
                progress.setdefault(key, _Progress())
        elif row.get("kind") == "page":
            progress.setdefault(row["scope"], _Progress()).add(row)
        elif row.get("kind") == "moved":
            progress[row["scope"]] = _Progress(restarts=progress.get(row["scope"], _Progress()).restarts + 1)
    return progress, contact


def _iso(instant: datetime) -> str:
    return instant.astimezone(UTC).isoformat().replace("+00:00", "Z")


@dataclass
class _Walk:
    """What the workers of one walk share, read and written only under ``lock``."""

    lock: threading.Lock
    halt: threading.Event
    queue: deque[ListingScope]
    #: The receipts' last recorded contact: every worker's first request waits out the spacing from it.
    contact: datetime | None
    begun: int = 0
    failed: int = 0
    consecutive_failures: int = 0
    pause_until: datetime | None = None
    stop: str | None = None


def walk_listing(
    scopes: Sequence[ListingScope],
    *,
    acquirers: Callable[[], GaoListingAcquirer],
    store: Path,
    receipts: Path,
    zyte_budget: ZyteBudget,
    proxy_record: Callable[[str], ZyteProxyRecord | None] = lambda _url: None,
    credential: str = "",
    concurrency: int = 1,
    spacing_seconds: float = CRAWL_DELAY_SECONDS,
    failure_backoff_seconds: float = CRAWL_DELAY_SECONDS,
    max_consecutive_failures: int = 1,
    clock: Callable[[], datetime] = utc_now,
    sleep: Callable[[float], None] | None = None,
) -> int:
    """Walk each scope's pages in order, resuming from ``receipts``; 0 when done or stopped at budget, else 1.

    Every page's exact bytes go to ``store`` and one row to ``receipts`` (appended). A retained page is never
    fetched again, and a scope named twice is walked once. Up to ``concurrency`` workers (no more than the scopes,
    at most :data:`MAX_CONCURRENCY`) each take whole scopes in turn with their own acquirer from ``acquirers``, so a
    scope is still read page by page against its first page. A failure is recorded and stops its scope, which the
    next run retries; the other scopes' pages are kept. Each failure pauses every worker for
    ``failure_backoff_seconds``, doubling with each failure in a row up to :data:`MAX_BACKOFF_SECONDS`, and
    ``max_consecutive_failures`` in a row stop the walk. A listing that moves mid-scope writes a ``moved`` row and
    restarts the scope from page 0, once; moving again stops it, named, and this and every later run over it exit 1
    until someone looks. The Zyte budget is an exact ceiling: a request is counted before it starts. Each worker
    spaces its own request starts by ``spacing_seconds``, its first from the last contact the receipts record, so
    stopping and resuming never shortens the spacing; this is the only pacing, so a caller's acquirers carry none.
    The default, one worker 420 seconds apart stopping at the first failure, is the site's stated crawl delay. On an
    interrupt the workers are stopped and joined and a ``stopped`` row is written before it propagates.
    """
    from rulespec_artifacts import LocalBlobWriter

    from spicy_docs.reading.refusals import retain_refused_response
    from spicy_docs.transport.credentials import scrub_credential

    if isinstance(concurrency, bool) or not isinstance(concurrency, int) or not 1 <= concurrency <= MAX_CONCURRENCY:
        raise ValueError(f"concurrency must be an integer from 1 to {MAX_CONCURRENCY}")
    if (
        isinstance(max_consecutive_failures, bool)
        or not isinstance(max_consecutive_failures, int)
        or max_consecutive_failures < 1
    ):
        raise ValueError("max_consecutive_failures must be a positive integer")
    check_timing(1, spacing_seconds)
    check_timing(1, failure_backoff_seconds)
    scopes = list(dict.fromkeys(scopes))
    progress, contact = _read_receipts(receipts)
    writer = LocalBlobWriter(store)
    run_id = str(uuid4())
    spent_before = zyte_budget.spent
    shared = _Walk(threading.Lock(), threading.Event(), deque(scopes), contact)
    pause = sleep if sleep is not None else shared.halt.wait
    with receipts.open("a", encoding="utf-8") as sink:

        def emit(kind: str, **value: object) -> None:
            """Append one row; callers hold ``shared.lock``, so rows from different workers never interleave."""
            sink.write(
                scrub_credential(json.dumps({"kind": kind, "run_id": run_id, **value}, ensure_ascii=False), credential)
                + "\n"
            )
            sink.flush()

        def begin() -> datetime | None:
            """Reserve one request under the budget, or stop the walk; returns the pause to wait out, if any."""
            with shared.lock:
                if shared.stop is None and spent_before + shared.begun >= zyte_budget.max_requests:
                    shared.stop = "Zyte request budget reached; run again to resume"
                if shared.stop is not None:
                    raise _Stopped
                shared.begun += 1
                return shared.pause_until

        def refusal(
            scope: ListingScope, page_index: int, attempted: datetime, error: Exception, max_bytes: int
        ) -> dict:
            detail: dict[str, object] = {
                "scope": scope.key,
                "page_index": page_index,
                "attempted_at": _iso(attempted),
                "error_type": type(error).__name__,
                # Scrub before truncating, or a credential's prefix could survive.
                "error": scrub_credential(str(error), credential)[:1000],
                "zyte_requests": zyte_budget.spent,
            }
            refused = retain_refused_response(error, store=store, max_bytes=max_bytes, credential=credential)
            if refused is not None:
                detail["refused_evidence"] = refused
            return detail

        def failed(detail: dict) -> None:
            """Record a failure; the caller holds the lock."""
            emit("failed", **detail)
            shared.failed += 1
            shared.consecutive_failures += 1
            backoff = min(failure_backoff_seconds * 2 ** (shared.consecutive_failures - 1), MAX_BACKOFF_SECONDS)
            shared.pause_until = clock() + timedelta(seconds=backoff)
            if shared.consecutive_failures >= max_consecutive_failures:
                shared.stop = f"{shared.consecutive_failures} consecutive failures; run again to retry"

        def walk_scope(acquirer: GaoListingAcquirer, scope: ListingScope, last: datetime | None) -> datetime | None:
            """One scope, page after page; returns this worker's last request start."""
            with shared.lock:
                state = progress.setdefault(scope.key, _Progress())
            if state.stopped:
                return last
            while (page_index := state.next_page()) is not None:
                until = begin()
                waits = [spacing_seconds - (clock() - last).total_seconds()] if last is not None else []
                if until is not None:
                    waits.append((until - clock()).total_seconds())
                if (wait := max(waits, default=0)) > 0:
                    pause(wait)
                    if shared.halt.is_set():
                        raise _Stopped
                last = clock()
                try:
                    page, capture = acquirer.acquire_page(
                        scope, page_index, expected_last_page_index=state.last, expected_page_size=state.size
                    )
                    with shared.lock:
                        stored = writer.put(
                            [capture.body], max_bytes=acquirer.budget.max_page_bytes, expected_digest=capture.sha256
                        )
                except Exception as error:  # noqa: BLE001 - recorded with its evidence, then retried on resume
                    with shared.lock:
                        detail = refusal(scope, page_index, last, error, acquirer.budget.max_page_bytes)
                        if isinstance(error, GaoListingMovedError):
                            # Every move is a ``moved`` row, so a later run counts it too; past the allowance the
                            # scope stops here and in every later run, named, until someone looks at it.
                            emit("moved", **detail)
                            state = progress[scope.key] = _Progress(restarts=state.restarts + 1)
                            if not state.stopped:
                                continue
                        failed(detail)
                    return last
                record = proxy_record(capture.requested_url)
                row = {
                    "scope": scope.key,
                    "page_index": page_index,
                    "last_page_index": page.last_page_index,
                    "entries": len(page.entries),
                    "request_url": capture.requested_url,
                    "resolved_url": capture.resolved_url,
                    "status": capture.status_code,
                    "content_type": capture.content_type,
                    "observed_at": capture.observed_at,
                    "bytes": capture.byte_size,
                    "sha256": capture.sha256,
                    "blob_path": stored.object_key,
                    "proxied_client": None if record is None else record.proxied_client,
                    "proxy_mode": None if record is None else record.mode,
                    "zyte_request_id": None if record is None else record.zyte_request_id,
                }
                with shared.lock:
                    emit("page", **row)
                    state.add({**row, "kind": "page"})
                    shared.consecutive_failures = 0
            return last

        def worker() -> None:
            try:
                with acquirers() as acquirer:
                    last = shared.contact
                    while True:
                        with shared.lock:
                            if shared.stop is not None or not shared.queue:
                                return
                            scope = shared.queue.popleft()
                        last = walk_scope(acquirer, scope, last)
            except _Stopped:
                return
            except Exception as error:  # noqa: BLE001 - a worker that cannot run stops the walk, recorded
                with shared.lock:
                    shared.failed += 1
                    shared.stop = f"a worker could not run: {type(error).__name__}"
                    emit(
                        "failed", error_type=type(error).__name__, error=scrub_credential(str(error), credential)[:1000]
                    )

        def unfinished() -> list[str]:
            return [scope.key for scope in scopes if progress.get(scope.key, _Progress()).next_page() is not None]

        with shared.lock:
            emit(
                "started",
                scopes=[scope.key for scope in scopes],
                max_zyte_requests=zyte_budget.max_requests,
                spacing_seconds=spacing_seconds,
                concurrency=concurrency,
            )
        workers = [
            threading.Thread(target=worker, name=f"gao-listing-{index}")
            for index in range(min(concurrency, len(scopes)))
        ]
        try:
            for thread in workers:
                thread.start()
            for thread in workers:
                thread.join()
        except BaseException:
            with shared.lock:
                shared.stop = "interrupted; run again to resume" + (f" (after: {shared.stop})" if shared.stop else "")
            shared.halt.set()
            for thread in workers:
                if thread.is_alive():
                    thread.join()
            with shared.lock:
                emit("stopped", reason=shared.stop, unfinished=unfinished(), zyte_requests=zyte_budget.spent)
            raise
        left = unfinished()
        with shared.lock:
            if not left:
                emit("complete", scopes=[scope.key for scope in scopes], zyte_requests=zyte_budget.spent)
            else:
                moved = [key for key in left if progress.get(key, _Progress()).stopped]
                reason = shared.stop or "a scope stopped at a failure; run again to retry it"
                if moved:
                    reason = f"{reason}; listing moved while read, stopped until checked: {', '.join(moved)}"
                emit("stopped", reason=reason, unfinished=left, zyte_requests=zyte_budget.spent)
    return 1 if shared.failed or any(progress.get(key, _Progress()).stopped for key in left) else 0


class _Stopped(Exception):
    """The walk has stopped; a worker starts no further request."""


@dataclass(frozen=True, slots=True)
class RetainedListingPage:
    page: ListingPage
    capture: CapturedBodyResponse
    blob_path: str
    zyte_request_id: str | None


@dataclass(frozen=True, slots=True)
class RetainedPages:
    """The verified pages of every complete scope, in scope and page order, and which scopes are unfinished."""

    pages: tuple[RetainedListingPage, ...]
    complete_scopes: tuple[str, ...]
    incomplete_scopes: tuple[str, ...]


def read_retained_pages(
    receipts: Path,
    store: Path,
    *,
    scope_of: Callable[[str], ListingScope],
    max_page_bytes: int,
    max_last_page_index: int,
) -> RetainedPages:
    """Re-read a walk's retained pages: each digest re-checked, each page re-parsed against its scope's first page.

    Only a scope whose every page is retained counts; the others are named in ``incomplete_scopes`` and read
    nothing. Bytes come from ``store`` and must equal what ``receipts`` recorded.
    """
    from rulespec_artifacts import LocalBlobSource

    progress, _ = _read_receipts(receipts)
    source = LocalBlobSource(store)
    pages: list[RetainedListingPage] = []
    complete, incomplete = [], []
    for key, state in progress.items():
        last = state.last
        if state.next_page() is not None or last is None:  # a scope with no page yet has no last page either
            incomplete.append(key)
            continue
        scope = scope_of(key)
        for index in range(last + 1):
            row = state.rows[index]
            with source.open(row["sha256"]) as stream:
                body = stream.read(max_page_bytes + 1)
            capture = CapturedBodyResponse(
                requested_url=row["request_url"],
                resolved_url=row["resolved_url"],
                status_code=row["status"],
                content_type=row["content_type"],
                observed_at=row["observed_at"],
                body=body,
            )
            if capture.sha256 != row["sha256"] or capture.byte_size != row["bytes"]:
                raise GaoListingSourceError(f"retained page {key}/{index} differs from its receipt")
            if capture.requested_url != scope.page_url(index):
                raise GaoListingSourceError(f"retained page {key}/{index} was requested at another URL")
            page = scope.parse_page(
                body,
                page_index=index,
                max_bytes=max_page_bytes,
                max_last_page_index=max_last_page_index,
                expected_last_page_index=last,
                expected_page_size=state.size,
            )
            pages.append(RetainedListingPage(page, capture, row["blob_path"], row.get("zyte_request_id")))
        complete.append(key)
    return RetainedPages(tuple(pages), tuple(complete), tuple(incomplete))


def add_walk_arguments(walk: argparse.ArgumentParser) -> None:
    """The walk's run flags; their defaults are the polite walk, one worker 420 seconds apart."""
    walk.add_argument("--store", type=Path, required=True, help="Content-addressed page store")
    walk.add_argument("--receipts", type=Path, required=True, help="JSONL receipts, appended; the resume state")
    walk.add_argument("--max-zyte-requests", type=int, required=True, help="Hard ceiling on Zyte calls this run")
    walk.add_argument(
        "--delay-seconds", type=float, default=CRAWL_DELAY_SECONDS, help="Seconds between one worker's requests"
    )
    walk.add_argument(
        "--concurrency",
        type=int,
        default=1,
        help=f"Workers, each walking whole scopes in turn (at most {MAX_CONCURRENCY})",
    )
    walk.add_argument(
        "--failure-backoff-seconds",
        type=float,
        default=CRAWL_DELAY_SECONDS,
        help="Pause every worker this long after a failure, doubling for each failure in a row",
    )
    walk.add_argument(
        "--max-consecutive-failures", type=int, default=1, help="Failures in a row that stop the whole walk"
    )
    walk.add_argument("--timeout-seconds", type=float, default=180.0)
    walk.add_argument("--max-page-bytes", type=int, default=DEFAULT_MAX_PAGE_BYTES)


def add_read_arguments(read: argparse.ArgumentParser) -> None:
    read.add_argument("--store", type=Path, required=True)
    read.add_argument("--receipts", type=Path, required=True)
    read.add_argument("--output", type=Path, help="Create a new JSONL file; defaults to stdout")


def walk_command(
    args: argparse.Namespace, scopes: Callable[[], Sequence[ListingScope]], *, max_last_page_index: int
) -> int:
    """Run a walk from the command's flags through Zyte, the token read from ``ZYTE_TOKEN`` only."""
    from spicy_docs.sources.zyte import HTTP_RESPONSE_BODY, ZyteHttpFetcher, require_zyte_token_from_environment
    from spicy_docs.transport.credentials import scrub_credential
    from spicy_docs.transport.zyte import ZyteBudget, ZyteTransport

    token = ""
    try:
        chosen = scopes()
        # The walk spaces requests itself, from the receipts' last contact across runs; the acquirer adds none.
        budget = GaoListingBudget(
            max_page_bytes=args.max_page_bytes,
            timeout_seconds=args.timeout_seconds,
            min_request_interval_seconds=0,
            max_last_page_index=max_last_page_index,
        )
        token = require_zyte_token_from_environment()
        zyte_budget = ZyteBudget(args.max_zyte_requests)
        transport = ZyteTransport(
            ZyteHttpFetcher(token=token),
            max_bytes=budget.max_page_bytes,
            timeout_seconds=budget.timeout_seconds,
            mode=HTTP_RESPONSE_BODY,
            budget=zyte_budget,
        )
        return walk_listing(
            chosen,
            acquirers=lambda: GaoListingAcquirer(budget=budget, transport=transport),
            store=args.store,
            receipts=args.receipts,
            zyte_budget=zyte_budget,
            proxy_record=transport.record_for,
            credential=token,
            concurrency=args.concurrency,
            spacing_seconds=args.delay_seconds,
            failure_backoff_seconds=args.failure_backoff_seconds,
            max_consecutive_failures=args.max_consecutive_failures,
        )
    except (ValueError, OSError) as error:
        print(scrub_credential(str(error), token), file=sys.stderr)
        return 1


def write_items(items: Iterable[tuple[str, object]], summary: dict, output: Path | None) -> None:
    """Each ``(kind, dataclass)`` as one JSONL row to ``output`` (created) or stdout; the summary to stderr."""
    with output.open("x", encoding="utf-8") if output else nullcontext(sys.stdout) as out:
        for kind, item in items:
            value = {name: getattr(item, name) for name in item.__dataclass_fields__}  # type: ignore[attr-defined]
            out.write(json.dumps({"kind": kind, **value}, ensure_ascii=False) + "\n")
    print(json.dumps(summary), file=sys.stderr)


__all__ = [
    "CRAWL_DELAY_SECONDS",
    "DEFAULT_MAX_LAST_PAGE_INDEX",
    "DEFAULT_MAX_PAGE_BYTES",
    "MAX_BACKOFF_SECONDS",
    "MAX_CONCURRENCY",
    "MAX_PAGE_BYTES",
    "MAX_SCOPE_RESTARTS",
    "GaoListingAcquirer",
    "GaoListingBudget",
    "GaoListingMovedError",
    "GaoListingSourceError",
    "GaoListingUnavailableError",
    "ListingPage",
    "ListingScope",
    "RetainedListingPage",
    "RetainedPages",
    "add_read_arguments",
    "add_walk_arguments",
    "listing_date",
    "listing_text",
    "names_page",
    "read_retained_pages",
    "spelled",
    "walk_command",
    "walk_listing",
    "write_items",
]
