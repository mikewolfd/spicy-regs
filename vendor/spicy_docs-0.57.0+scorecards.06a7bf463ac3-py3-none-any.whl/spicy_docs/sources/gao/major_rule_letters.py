"""What a GAO major-rule report's letter states in prose: the agency, the RINs and the Federal Register citations.

GAO's listing (``major_rule_reports``) states none of the three; each report's letter does, in its opening paragraph
(owner ruling 2026-10-04, measurement in ``corpora/fork-execution-2026-09-21/gao-cra-major-rules/letters-2026-10-04/``)::

    Pursuant to section 801(a)(2)(A) of title 5, United States Code, this is our report on a major rule promulgated
    by the Environmental Protection Agency (EPA), entitled "..." (RIN: 2040-AB75). We received the rule on January
    17, 2001. It was published in the Federal Register as a final rule on January 22, 2001. 66 Fed. Reg. 6976.

The letter comes from the report's product page, which prints it under "View Decision" (the block
``decision_pages.decision_paragraphs`` reads, a lone ``<br>`` continuing a paragraph), or, where the page prints none,
from the report's PDF through the shared PDF text derivation (``extraction.body_text.rendition_text``), one paragraph
per blank-line block. Format characters GAO's markup leaves in the prose (a zero-width joiner inside ``91 Fed. Reg.
1043``, b-338079) are removed first. Only the opening is read: from "Pursuant to section 801(a)(2)(A)", which the
letter states once, to the end of its paragraph, and the paragraph after it for the publication sentence alone
(OGC-99-12, 1998, states it there). Where the page's markup ends that paragraph before its sentence ends, the
opening runs on (:data:`_MAX_RUN_ON`): OGC-99-44's breaks it twice (``this is our report</p> <p>on a major rule ...
We received the rule </p> <p>on April 21, 1999.``), OGC-97-39's after a semicolon, b-335463's between the title's
closing quotation mark and ``(RIN: 2060-AV45)``:

- **agency**: the words between "promulgated by" (or "issued by", OGC-98-65) and "entitled" (or "titled"), as
  printed, whitespace collapsed and a leading "the" dropped, abbreviations kept (``Department of Transportation
  (DOT), Federal Aviation Administration``). Where the letter ends its sentence after the agency (``Fish and
  Wildlife Service. The rule is entitled``) the agency ends there; words holding a colon (``the following
  agencies: ...``), or a sentence end the reader does not know, are ``unreadable``;
- **RINs**: every RIN the shared ``rin`` citation rule reads inside the parenthesis that holds the opening's first
  ``RIN`` or ``RINs`` label (``(RIN: 2040-AB75)``, ``(Docket No. R-1316 and RIN: 3804-AA94)``), folded as that rule
  folds it (``1545–BP21`` is ``1545-BP21``); a ``ZRIN`` is no RIN;
- **Federal Register citations**: the first citation the shared ``federal_register_cite`` rule reads after
  "published in the Federal Register", in that paragraph, or alone in the paragraph after it (gao-09-211r); keyed
  ``{volume}-{page}``.

**A report on several rules** (owner ruling 2026-10-04, "Hold every rule's values"; survey and hand check in
``corpora/fork-execution-2026-09-21/gao-cra-major-rules/all-rules-2026-10-04/``). Seventeen of the 2,452 letters
captured report on more than one rule, or on a rule and its notice, all of 1996-1999. They state them in three ways;
both lists keep the letter's order, each value once:

- *together*: ``They were published in the Federal Register as final rules on August 20, 1996. 61 Fed. Reg. 42979 and
  61 Fed. Reg. 42970.`` Where the publication statement says several ``were published``, the citations joined to its
  first by "and" or a semicolon are read too. A page alone takes the volume before it (OGC-98-69: ``63 Fed. Reg. 40630
  and 40632``). A comma joins nothing: ``88 Fed. Reg. 12,345, 12,350`` cites a page inside one document;
- *one after another*: ``One is entitled "..." (RIN: 1018-AE14). ... 62 Fed. Reg. 50660. On September 26, 1997, we
  received the rule entitled "..." (RIN: 1018-AE14). This latter rule was published ... 62 Fed. Reg 51298.`` Where
  the letter counts its rules (:func:`_rule_count`: ``two major rules``, or two titles after ``major rules``), every
  citation in the opening after the publication statement is a rule's, and so is every RIN in a later parenthesis
  holding a ``RIN`` label;
- *in a list*: an opening that ends with a colon runs on through the titles listed under it (OGC-99-38's four rules,
  each ``--"Title" (RIN: ...). ... It was published ... 64 Fed. Reg. 14308.``; :data:`_MAX_LIST`). gao-16-610r lists
  the seven documents of its one rule so, and the paragraph after the list cites all seven, joined by semicolons.

The letter's own count is the gate because a second citation is otherwise not a second rule: of the twelve listed
reports whose opening prints two, each second one is a correction, a delay of the effective date, an earlier rule or
the page an effective-date sentence cites (b-329577: ``A correction which does not affect our report was published
... 82 Fed. Reg. 51,773``). A letter that cites more than it counts keeps the publication statement's citations
alone. RINs and citations are listed, not paired: see ``docs/decisions.md`` for what the letters allow.

Each value keeps where it was read: the letter text, its digest, and the value's character span (and PDF page). A
field the letter does not state in that form is empty with a status saying why, never a guess: a docket where the
RIN would be (``FCC 07-109``) is ``not-stated``; a ``RIN`` label with nothing the shared rule reads (GAO's typo
``7100-AF 45``) is ``unreadable``; "will not be published in the Federal Register" is ``not-published``. A page that
is not the product's refuses, and so does a letter whose heading states another report's number (b-330560's page
printed B-330546's letter on 2026-10-04) or a PDF that does not state the listed number.
"""

from __future__ import annotations

import bisect
import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Final

from spicy_docs.interpretation.citations import CitationFinding, find_citations, page_starts
from spicy_docs.schemas.tables import digest
from spicy_docs.sources.gao.decision_pages import GaoDecisionPageError, decision_paragraphs
from spicy_docs.sources.gao.native import gao_product_id

#: The rule a host records beside the values it keeps from this reader. ``/2`` (2026-10-04, the reports of 1996-2000)
#: reads an opening the page's markup cut and more of GAO's wordings, and ends an agency at its sentence's end. Over
#: the 2,175 listed reports' letters it reads what ``/1`` read, but for two: b-335463's RIN, which ``/1`` left
#: ``not-stated``, and gao-16-610r's agency, which ``/1`` read with ``consisting of seven documents`` after it.
#: ``/3`` (2026-10-04) reads every rule a report is on: a letter's further citations and RINs, where ``/2`` read the
#: first rule's. The citation was one value and is a list; a report on one rule reads as it did.
LETTER_RULE: Final = "gao-major-rule-letter/3"
#: Where a letter's text came from: the product page's View Decision block, or the report's PDF.
PAGE_LETTER: Final = "product-page"
PDF_LETTER: Final = "report-pdf"
#: A field's status: ``stated``, or why it holds no value. ``no-opening`` (no paragraph begins "Pursuant to section
#: 801(a)(2)(A)") and ``two-openings`` apply to every field.
STATED: Final = "stated"
STATUSES: Final = (
    STATED,
    "no-opening",
    "two-openings",
    "no-agency-clause",
    "not-stated",
    "unreadable",
    "no-publication-statement",
    "not-published",
    "no-citation",
)

_OPENING: Final = re.compile(r"Pursuant\s+to\s+section\s+801\s*\(a\)\s*\(2\)\s*\(A\)")
#: The opening's own words, as GAO varies them: a footnote mark (``report[1]``, ``rule[1]``), ``four major rules``
#: (OGC-99-38), ``major final rules`` and ``major interim rules`` (OGC-98-69), an aside (``a major rule (hereinafter
#: "announcement")``), ``promulgated jointly by`` and ``issued by`` (OGC-98-65). The agency ends where the clause
#: does: before "entitled", before a full stop and ``The rule is entitled`` or ``One is entitled`` (the Fish and
#: Wildlife Service's letters of 1996 and 1997), or before ``consisting of seven documents entitled`` (gao-16-610r).
_AGENCY: Final = re.compile(
    r"report(?:\s*\[\d+\])?\s+on\s+(?:a\s+|two\s+|three\s+|four\s+)?major\s+(?:final\s+|interim\s+)?rules?"
    r"(?:\s*\[\d+\])?(?:\s*\([^()]*\))?\s+(?:promulgated|issued)\s+(?:jointly\s+)?by\s+(?:the\s+)?(?P<agency>.+?)"
    r"(?:\.\s+(?:The\s+rules?\s+(?:is|are)|One\s+is)\s+|\s+consisting\s+of\s+\w+\s+documents\s+|[\s,;]+)"
    r"(?:en)?titled\b",
    re.DOTALL,
)
#: A sentence ending inside the agency's words: a full stop after a lower-case letter or a parenthesis, then a
#: capital. ``U.S. Customs`` is none.
_SENTENCE_END: Final = re.compile(r"[a-z)]\.\s+[A-Z]")
#: Paragraphs a cut opening may run on through; OGC-99-44's sentence takes two more.
_MAX_RUN_ON: Final = 3
#: A title listed under an opening that ends with a colon: a quotation mark, after a dash or two (OGC-99-38:
#: ``--"Endangered and Threatened Species; ...``). gao-16-610r lists its seven documents' titles so, in six paragraphs.
_LIST_ITEM: Final = re.compile(r"[-–—]{0,2}\s*[\"“]")
#: Titles a list may hold; a longer one is read no further.
_MAX_LIST: Final = 12
_COUNTS: Final = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
#: The letter's count of its rules: a number word before ``major rules``.
_COUNTED: Final = re.compile(
    rf"report(?:\s*\[\d+\])?\s+on\s+(?P<count>{'|'.join(_COUNTS)})\s+major\s+(?:final\s+|interim\s+)?rules\b"
)
#: Two rules named without a number: ``report on major rules promulgated by ..., entitled "A" and "B"`` (OGC-97-44),
#: an aside after a title allowed (OGC-98-40: ``"A" (Registration Form rule) and "B"``).
_TWO_TITLES: Final = re.compile(
    r"report(?:\s*\[\d+\])?\s+on\s+major\s+(?:final\s+|interim\s+)?rules\b[^\"“”]*?\b(?:en)?titled,?:?\s*"
    r"[\"“][^\"“”]+[\"”]\s*(?:\([^()]*\)\s*)?and\s+[\"“][^\"“”]+[\"”]"
)
_RIN_LABEL: Final = re.compile(r"(?<![A-Za-z])(?<![Zz][-–‑])RIN[Ss]?\b")
#: A slash between a RIN and the next ``RIN`` label (OGC-97-20: ``(RIN: 3235-AG42/RIN: 3235-AG77)``). The shared rule
#: refuses a RIN inside a slash token, so it is given the space the slash stands for.
_SLASH_BEFORE_LABEL: Final = re.compile(r"/(?=\s*RINs?\b)")
_PUBLISHED: Final = re.compile(r"published\s+in\s+the\s+Federal\s*Register")
#: A publication statement about several rules or documents: ``They were published``, ``The rules were published``.
_WERE_PUBLISHED: Final = re.compile(r"\bwere\s+(?:\w+\s+)?published\b")
#: What joins a further citation to the one before it: "and" or a semicolon, never a comma alone.
_JOIN: Final = re.compile(r"\s*(?:;|,?\s*and\b)\s*")
#: A page alone, joined to a citation whose volume it takes; a sentence end or another join must follow it.
_PAGE_ALONE: Final = re.compile(r"(?P<page>\d{1,3},\d{3}|\d{1,6})(?=\s*(?:[.;]|,?\s*and\b|$))")
#: Citations one publication statement may join; gao-16-610r joins seven.
_MAX_JOINED: Final = 12
#: Numbers a letter's heading states (its B-file number, a GAO- or OGC- report number).
_NUMBERS: Final = re.compile(r"\b(?:B-\d{6}(?:\.\d+)?|(?:GAO|OGC)-\d{2}-\d+R?)\b")
#: Zero-width and soft-hyphen characters: format, not prose.
_FORMAT: Final = re.compile("[\u00ad\u200b-\u200d\u2060\ufeff]")
_NEGATION: Final = re.compile(r"\b(?:not|never)\b")
#: A PDF paragraph ends at a blank line.
_PDF_BREAK: Final = re.compile(r"\n[ \t]*\n\s*")
_LABEL: Final = "GAO major-rule letter"


class GaoMajorRuleLetterError(ValueError):
    """A page or PDF that cannot be this report's letter; ``reason`` names which check failed."""

    def __init__(self, reason: str, message: str) -> None:
        super().__init__(f"{_LABEL}: {message}")
        self.reason = reason


@dataclass(frozen=True, slots=True)
class LetterValue:
    """One value and where the letter states it: ``text[start:end]`` of the letter is ``printed``."""

    value: str
    printed: str
    start: int
    end: int
    #: The one-based PDF page the value starts on; None for the product page's letter, which states no pages.
    page: int | None


@dataclass(frozen=True, slots=True)
class LetterField:
    """A field's values, empty unless ``status`` is ``stated``."""

    status: str
    values: tuple[LetterValue, ...] = ()

    @property
    def value(self) -> str | None:
        """The first value: the agency, or the first rule's citation; None when the letter states none."""
        return self.values[0].value if self.values else None


@dataclass(frozen=True, slots=True)
class GaoMajorRuleLetter:
    """What one letter states, with the text the spans index and that text's digest."""

    product_id: str
    source: str
    text: str
    text_sha256: str
    agency: LetterField
    rins: LetterField
    federal_register: LetterField
    rule: str = LETTER_RULE


def _paragraphs(text: str, source: str) -> list[tuple[int, int]]:
    """Each paragraph's span: a line of the page's letter, or a blank-line block of the PDF's text."""
    breaks = re.finditer(r"\n", text) if source == PAGE_LETTER else _PDF_BREAK.finditer(text)
    spans, start = [], 0
    for found in breaks:
        spans.append((start, found.start()))
        start = found.end()
    spans.append((start, len(text)))
    return [(begin, end) for begin, end in spans if text[begin:end].strip()]


def _cut(text: str, paragraph: tuple[int, int]) -> bool:
    """Whether a paragraph stops before its sentence does: at a word, a semicolon, or a title's closing quotation mark.

    A sentence GAO left without its full stop ends in a digit (``69 Fed. Reg. 33474``, ``January 1, 2021``) or a
    footnote mark, and is whole; a quotation that ends a sentence holds its full stop (``2018-07.”``).
    """
    tail = text[paragraph[0] : paragraph[1]].rstrip()[-2:]
    return tail[-1:].isalpha() or tail[-1:] == ";" or (tail[-1:] == "”" and tail[:-1] != ".")


def _value(value: str, start: int, end: int, text: str, starts: Sequence[int] | None) -> LetterValue:
    page = None if starts is None else bisect.bisect_right(starts, start)
    return LetterValue(value, text[start:end], start, end, page)


def _agency(text: str, opening: tuple[int, int], starts: Sequence[int] | None) -> LetterField:
    found = _AGENCY.search(text, *opening)
    if found is None:
        return LetterField("no-agency-clause")
    if ":" in found["agency"] or _SENTENCE_END.search(found["agency"]):
        return LetterField("unreadable")
    start, end = found.span("agency")
    return LetterField(STATED, (_value(" ".join(found["agency"].split()), start, end, text, starts),))


def _enclosing(text: str, at: int, begin: int, end: int) -> tuple[int, int] | None:
    """The span of the parenthesis around offset ``at``, within ``begin``..``end``; None if ``at`` is outside one."""
    depth = 0
    for index in range(at - 1, begin - 1, -1):
        if text[index] == ")":
            depth += 1
        elif text[index] == "(":
            if depth == 0:
                break
            depth -= 1
    else:
        return None
    opened, depth = index, 0
    for index in range(at, end):
        if text[index] == "(":
            depth += 1
        elif text[index] == ")":
            if depth == 0:
                return opened, index + 1
            depth -= 1
    return None


def _rule_count(text: str, opening: tuple[int, int]) -> int | None:
    """How many rules the letter says its report is on, where it counts more than one; None otherwise.

    ``two major rules`` and ``four major rules`` count themselves, and ``major rules ..., entitled "A" and "B"`` names
    two. ``Major rules`` alone counts none: seventeen letters so name the rules one Federal Register document holds
    (the three departments' joint rules, the SEC's "final rules"), and cite one citation.
    """
    counted = _COUNTED.search(text, *opening)
    if counted is not None:
        return _COUNTS[counted["count"]]
    return 2 if _TWO_TITLES.search(text, *opening) else None


def _once(values: list[LetterValue]) -> tuple[LetterValue, ...]:
    """Each value once, where the letter first states it, in the letter's order."""
    first: dict[str, LetterValue] = {}
    for value in values:
        first.setdefault(value.value, value)
    return tuple(first.values())


def _rins(
    text: str,
    opening: tuple[int, int],
    findings: Sequence[CitationFinding],
    starts: Sequence[int] | None,
    count: int | None,
) -> LetterField:
    """The RINs in the parenthesis holding the opening's first label; in a counted letter, in every later one too."""
    label = _RIN_LABEL.search(text, *opening)
    if label is None:
        return LetterField("not-stated")
    around = _enclosing(text, label.start(), *opening)
    if around is None:
        return LetterField("unreadable")
    rins = [finding for finding in findings if finding.kind == "rin"]
    values = [
        _value(finding.target_key, finding.span_start, finding.span_end, text, starts)
        for finding in rins
        if label.start() < finding.span_start and finding.span_end <= around[1]
    ]
    if not values:
        return LetterField("unreadable")
    if count is None:
        return LetterField(STATED, tuple(values))
    for later in _RIN_LABEL.finditer(text, around[1], opening[1]):
        inside = _enclosing(text, later.start(), around[1], opening[1])
        if inside is not None:
            values += [
                _value(finding.target_key, finding.span_start, finding.span_end, text, starts)
                for finding in rins
                if later.start() < finding.span_start and finding.span_end <= inside[1]
            ]
    return LetterField(STATED, _once(values))


def _joined(
    text: str, first: CitationFinding, cites: Sequence[CitationFinding], end: int, starts: Sequence[int] | None
) -> list[LetterValue]:
    """The citations joined to ``first`` by "and" or a semicolon, before ``end``: whole ones, or pages of its volume."""
    by_start = {cite.span_start: cite for cite in cites}
    values: list[LetterValue] = []
    volume, at = first.target_key.split("-")[0], first.span_end
    while len(values) < _MAX_JOINED and (join := _JOIN.match(text, at, end)) is not None:
        whole = by_start.get(join.end())
        if whole is not None and whole.span_end <= end:
            values.append(_value(whole.target_key, whole.span_start, whole.span_end, text, starts))
            volume, at = whole.target_key.split("-")[0], whole.span_end
            continue
        alone = _PAGE_ALONE.match(text, join.end(), end)
        page = 0 if alone is None else int(alone["page"].replace(",", ""))
        if not page:
            break
        values.append(_value(f"{volume}-{page}", alone.start(), alone.end(), text, starts))
        at = alone.end()
    return values


def _federal_register(
    text: str,
    windows: Sequence[tuple[int, int]],
    findings: Sequence[CitationFinding],
    starts: Sequence[int] | None,
    count: int | None,
) -> LetterField:
    """The citations of the rules the report is on: the publication statement's, and a counted letter's later ones.

    ``windows`` are the opening and the paragraphs after it; "published in the Federal Register" is looked for in
    the first two, and a citation the phrase's paragraph lacks may stand alone in the next. The statement's first
    citation is the first value. Where the statement says several ``were published``, the citations joined to it
    follow. Where the letter counts its rules (``count``), every later citation in the phrase's window follows too,
    unless that makes more citations than rules: the letter then cites something that is no rule of its report, and
    which one the reader cannot tell.
    """
    cites = [finding for finding in findings if finding.kind == "federal_register_cite"]
    for at, (begin, end) in enumerate(windows[:2]):
        phrase = _PUBLISHED.search(text, begin, end)
        if phrase is None:
            continue
        stop = text.rfind(". ", begin, phrase.start())
        sentence = begin if stop < 0 else stop + 2
        if _NEGATION.search(text, sentence, phrase.start()):
            return LetterField("not-published")
        cite = next((c for c in cites if phrase.end() <= c.span_start and c.span_end <= end), None)
        if cite is None and at + 1 < len(windows):
            after = windows[at + 1]
            alone = [c for c in cites if after[0] <= c.span_start and c.span_end <= after[1]]
            if len(alone) == 1 and not text[after[0] : after[1]].replace(alone[0].matched_text, "").strip(" .\t"):
                cite = alone[0]
        if cite is None:
            return LetterField("no-citation")
        values = [_value(cite.target_key, cite.span_start, cite.span_end, text, starts)]
        if _WERE_PUBLISHED.search(text, sentence, cite.span_start):
            values += _joined(text, cite, cites, end, starts)
        if count is not None:
            every = _once(
                values
                + [
                    _value(c.target_key, c.span_start, c.span_end, text, starts)
                    for c in cites
                    if cite.span_end <= c.span_start and c.span_end <= end
                ]
            )
            if len(every) <= count:
                return LetterField(STATED, every)
        return LetterField(STATED, _once(values))
    return LetterField("no-publication-statement")


def read_letter_text(
    text: str, *, product_id: str, product_number: str, source: str, pages: Sequence[str] | None = None
) -> GaoMajorRuleLetter:
    """The three fields one letter's text states; ``pages`` is a PDF's per-page split of ``text``, proved, not trusted.

    ``product_number`` is the number GAO's listing states. Where the heading before the opening states numbers of
    its kind (a B-number for a B-numbered report, a GAO- or OGC- number otherwise) and not it, the letter is another
    report's and refuses (``not-this-letter``); a GAO-numbered letter's B-file number is not its product number and
    is not compared. O(T) in the letter's length: one pass of the shared citation rules, then the opening's spans.
    """
    product_id = gao_product_id(product_id)
    if source not in (PAGE_LETTER, PDF_LETTER):
        raise ValueError(f"source must be {PAGE_LETTER!r} or {PDF_LETTER!r}")
    text = _FORMAT.sub("", text)
    pages = None if pages is None else [_FORMAT.sub("", page) for page in pages]
    # One character for one, so the findings' spans index ``text`` itself.
    findings = find_citations(
        _SLASH_BEFORE_LABEL.sub(" ", text),
        pages=None if pages is None else [_SLASH_BEFORE_LABEL.sub(" ", page) for page in pages],
        kinds=("federal_register_cite", "rin"),
    )
    starts = None if pages is None else page_starts(pages)
    openings = list(_OPENING.finditer(text))
    if len(openings) != 1:
        none = LetterField("no-opening" if not openings else "two-openings")
        return GaoMajorRuleLetter(product_id, source, text, digest(text), none, none, none)
    kind = product_number.startswith("B-")
    stated = {number for number in _NUMBERS.findall(text, 0, openings[0].start()) if number.startswith("B-") == kind}
    if stated and product_number not in stated:
        raise GaoMajorRuleLetterError(
            "not-this-letter", f"the letter's heading states {sorted(stated)}, not {product_number}"
        )
    paragraphs = _paragraphs(text, source)
    index = next(at for at, (_, end) in enumerate(paragraphs) if openings[0].start() < end)
    # Only a page's markup cuts a paragraph; a PDF's blocks are the text derivation's.
    limit = min(index + _MAX_RUN_ON, len(paragraphs) - 1) if source == PAGE_LETTER else index
    while index < limit and _cut(text, paragraphs[index]):
        index += 1
    if source == PAGE_LETTER and text[: paragraphs[index][1]].rstrip().endswith(":"):
        # The opening introduces a list of titles, and runs on through it.
        limit = min(index + _MAX_LIST, len(paragraphs) - 1)
        while index < limit and _LIST_ITEM.match(text, paragraphs[index + 1][0]):
            index += 1
    opening = (openings[0].start(), paragraphs[index][1])
    count = _rule_count(text, opening)
    return GaoMajorRuleLetter(
        product_id,
        source,
        text,
        digest(text),
        _agency(text, opening, starts),
        _rins(text, opening, findings, starts, count),
        _federal_register(text, [opening, *paragraphs[index + 1 : index + 3]], findings, starts, count),
    )


def read_page_letter(body: bytes, *, product_id: str, product_number: str) -> GaoMajorRuleLetter | None:
    """The letter a product page prints under View Decision; None where the page prints no such block.

    Refuses (``reason``) a page that is not the product's (``not-this-page``), prints two blocks
    (``two-decision-blocks``) or prints another report's letter (``not-this-letter``). A page without the block
    states its letter only in its Full Report PDF (``product_metadata.full_report_path``).
    """
    try:
        paragraphs = decision_paragraphs(body, product_id=product_id)
    except GaoDecisionPageError as error:
        raise GaoMajorRuleLetterError(error.reason, str(error)) from error
    if not paragraphs:
        return None
    return read_letter_text(
        "\n".join(paragraphs), product_id=product_id, product_number=product_number, source=PAGE_LETTER
    )


def read_pdf_letter(body: bytes, *, product_id: str, product_number: str, extractor=None) -> GaoMajorRuleLetter:
    """The letter in a report's PDF, its text derived by the shared PDF branch (``rendition_text``).

    ``product_number`` is the number GAO's listing states (``B-336972``); a PDF whose text does not state it is
    another report's and refuses (``not-this-letter``). ``extractor`` replaces the default native-text extraction.
    """
    from spicy_docs.extraction.body_text import rendition_text

    derived = rendition_text(body, rendition="pdf", extractor=extractor)
    if not product_number or product_number not in derived.text:
        raise GaoMajorRuleLetterError("not-this-letter", f"the PDF's text does not state {product_number!r}")
    return read_letter_text(
        derived.text, product_id=product_id, product_number=product_number, source=PDF_LETTER, pages=derived.pages
    )


__all__ = [
    "LETTER_RULE",
    "PAGE_LETTER",
    "PDF_LETTER",
    "STATED",
    "STATUSES",
    "GaoMajorRuleLetter",
    "GaoMajorRuleLetterError",
    "LetterField",
    "LetterValue",
    "read_letter_text",
    "read_page_letter",
    "read_pdf_letter",
]
