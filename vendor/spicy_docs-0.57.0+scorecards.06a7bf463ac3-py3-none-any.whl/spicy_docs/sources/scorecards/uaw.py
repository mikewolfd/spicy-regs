"""UAW's complete named 2019 Senate voting record and linked item narratives.

Reviewed PDF observations stay private; publisher names, blanks, score values
and agreement glyphs remain literal. Other advertised editions are separate scopes.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "uaw-senate-2019-qualified-pdf/2"
INDEX_URL = "https://uaw.org/legislative-scorecards/"
PAGE_URL = "https://uaw.org/legislative-scorecards/senate-2019/"
PDF_URL = "https://uaw.org/wp-content/uploads/2023/12/senate-vote-record-2019.pdf"
HOSTS = ("uaw.org",)
SOURCE_SHA256 = "b0a2d565f9a6d38ee02d9aba22d165323762947cfc13c014fe68be16456593c7"
QUALIFIED_SHA256 = "c488d02b63e6253f7933feb61afca4788ed9070a1668cd43f89e6043f83849c7"
PAGE_MEMBERS = {1: 18, 2: 20, 3: 20, 4: 20, 5: 20, 6: 2}
TITLE = "2019 SENATE VOTING RECORD"
VALUE_NAME = "Percentage Agreement with UAW Position"
POSITIONS = ["NO"] * 7 + ["YES", "NO"]
EDITION = ScorecardEdition(
    "uaw", "2019-senate-original-pdf", PAGE_URL, TITLE, year="2019", chamber="Senate", is_current=False
)


@dataclass(frozen=True, slots=True)
class UAWReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _page_facts(document):
    if document.url != PAGE_URL:
        raise ScorecardSourceError("UAW's selected Senate source page changed location")
    parsed = soup(document)
    heading = parsed.select_one("#full_slider_1 .avia-caption-title")
    chamber = parsed.select_one("#full_slider_1 .avia-caption-content")
    section = parsed.select_one("#av_section_2 .avia_textblock")
    links = parsed.select("#av_section_2 a[aria-label='SENATE VOTE RECORD']")
    if (
        heading is None
        or heading.get_text(" ", strip=True) != "KEY VOTES IN 2019"
        or chamber is None
        or chamber.get_text(" ", strip=True) != "US SENATE"
        or section is None
        or len(links) != 1
        or links[0].get("href") != PDF_URL
    ):
        raise ScorecardSourceError("UAW source page lacks its selected year, chamber or original PDF link")
    paragraphs = section.find_all("p", recursive=False)
    records = []
    for ordinal, paragraph in enumerate(paragraphs, 1):
        headings = paragraph.find_all("strong", recursive=False)
        if len(headings) != 1:
            raise ScorecardSourceError("UAW item narrative lacks its single explicit ordinal heading")
        title = headings[0].get_text(" ", strip=True)
        match = re.fullmatch(r"([1-9])\. (.+)", title)
        text = paragraph.get_text(" ", strip=True)
        if match is None or match[1] != str(ordinal) or len(text) <= len(title):
            raise ScorecardSourceError("UAW item narrative ordinals or complete paragraphs changed")
        records.append({"ordinal_text": match[1], "heading_text": title, "paragraph_text": text})
    if len(records) != 9 or any(tag.name != "p" for tag in section.find_all(recursive=False)):
        raise ScorecardSourceError("UAW's complete named Senate item narratives changed shape")
    return records


def list_scorecards(context: ScorecardContext):
    document = context.read(PAGE_URL, stage="scorecards:uaw:listing", hosts=HOSTS)
    _page_facts(document)
    return (EDITION,)


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=PDF_URL,
        source_sha256=SOURCE_SHA256,
        message="UAW's named 2019 Senate PDF changed; source requalification required",
    )


def _facts(data):
    """Reconcile all reviewed pages, printed states, member cells and item ordinals."""
    try:
        if (
            data["format_version"] != "uaw-senate-2019-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 6
            or len(data["members"]) != 100
            or data["positions"] != [POSITIONS] * 6
            or [p["physical_page"] for p in data["context_pages"]] != list(range(1, 7))
            or any(not isinstance(p["native_authored_text"], str) for p in data["context_pages"])
            or [i["ordinal_text"] for i in data["items"]] != list(map(str, range(1, 10)))
            or any(not isinstance(i["title_text"], str) or not i["title_text"] for i in data["items"])
        ):
            raise ValueError
        counts, states, identities, vacancies = Counter(), Counter(), set(), 0
        previous = 0
        for entry in data["members"]:
            page, r = entry["physical_page"], entry["record"]
            if (
                page not in PAGE_MEMBERS
                or page < previous
                or entry["row_ordinal"] != counts[page] + 1
                or set(r) != {"state_text", "member_name_text", "value_text", "result_cells"}
                or not isinstance(r["state_text"], str)
                or re.fullmatch(r"[A-Z]{2}", r["state_text"]) is None
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or len(r["result_cells"]) != 9
                or any(v not in {"+", "–", "X", "I", None} for v in r["result_cells"])
                or (r["state_text"], r["member_name_text"]) in identities
            ):
                raise ValueError
            if r["member_name_text"] == "Vacant":
                vacancies += 1
                if r["state_text"] != "GA" or r["value_text"] is not None or r["result_cells"] != [None] * 9:
                    raise ValueError
                raw = "Vacant"
            else:
                if r["value_text"] not in set(map(str, range(101))) or None in r["result_cells"]:
                    raise ValueError
                raw = " ".join([r["member_name_text"], *r["result_cells"], r["value_text"]])
            if " ".join(entry["raw_authored_line"].split()) != raw:
                raise ValueError
            counts[page] += 1
            states[r["state_text"]] += 1
            identities.add((r["state_text"], r["member_name_text"]))
            previous = page
        headings = data["state_headings"]
        if (
            dict(counts) != PAGE_MEMBERS
            or vacancies != 1
            or len(states) != 50
            or any(count != 2 for count in states.values())
            or len(headings) != 50
            or Counter(h["state_text"] for h in headings) != {state: 1 for state in states}
            or any(h["physical_page"] not in PAGE_MEMBERS for h in headings)
        ):
            raise ValueError
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        raise ScorecardSourceError("UAW observations do not establish the complete qualified source shape") from None
    return data


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION:
        raise ScorecardSourceError("UAW reader supports only the named 2019 Senate PDF and linked narratives")
    page = context.read(PAGE_URL, stage="scorecards:uaw:items", hosts=HOSTS)
    narratives = _page_facts(page)
    source = context.read(PDF_URL, stage="scorecards:uaw:pdf", hosts=HOSTS)
    _source(source)
    repeated_page = context.read(PAGE_URL, stage="scorecards:uaw:items-reread", hosts=HOSTS)
    if _page_facts(repeated_page) != narratives:
        raise ScorecardSourceError("UAW item narratives changed during acquisition")
    repeated = context.read(PDF_URL, stage="scorecards:uaw:pdf-reread", hosts=HOSTS)
    _source(repeated)
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("UAW PDF requires retained independently qualified semantic observations")
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="scorecards:uaw:qualified-observations",
    )
    try:
        data = _facts(json.loads(qualified_observations))
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ScorecardSourceError("UAW qualified observations are not readable source facts") from None
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="United Automobile, Aerospace and Agricultural Implement Workers of America",
        parser_version=parser_version,
        rendition_rule="Complete named original 2019 Senate voting record PDF and its linked publisher narratives",
        homepage="https://uaw.org/",
    )
    groups = ("members", "ratings", "item-results", "items", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, *groups, role="corroboration")
    bundle.use(page, "item-narratives", "source-page-period")
    bundle.use(repeated_page, "item-narratives", "source-page-period", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX_URL
    loc = lambda p, field: f"pdf:page={p};observation={observation};{field}"
    bundle.tables["scorecards"][0].update(
        edition_label_text=TITLE,
        timespan_text="2019",
        methodology_url=source.url,
        periods_json=json.dumps(
            [
                {
                    "occurrence_id": "0",
                    "period_text": TITLE,
                    "kind": "explicit",
                    "year_text": "2019",
                    "source_path": loc(1, "/title"),
                }
            ]
        ),
    )
    prefix = data["context_pages"][0]["native_authored_text"].split("1 Allison", 1)[0]
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(1, "/legend-and-header"),
        methodology_id="legend",
        chamber_text="Senate",
        methodology_text=json.dumps(
            {"native_legend_text": prefix, "value_heading_text": VALUE_NAME, "publisher_positions": POSITIONS},
            ensure_ascii=False,
        ),
        methodology_url=source.url,
        disclosure_status="Literal agreement, nonvoting and eligibility glyph legend; no disclosed score formula or weights",
    )
    bundle.add(
        "scorecard_metrics",
        source,
        loc(1, "/value-heading"),
        metric_id="agreement",
        name=VALUE_NAME,
        chamber_text="Senate",
        value_unit_text="Percentage",
        is_primary=None,
    )
    for item, narrative in zip(data["items"], narratives, strict=True):
        ordinal = item["ordinal_text"]
        path = loc(1, "/items/" + ordinal)
        target = POSITIONS[int(ordinal) - 1]
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=ordinal,
            publisher_item_id=ordinal,
            item_kind_text="SENATE VOTES",
            title=item["title_text"],
            chamber_text="Senate",
            publisher_position_text=target,
            position_basis="explicit",
            position_source_path=loc(1, "/publisher-positions/" + ordinal),
            references_json="[]",
        )
        bundle.add(
            "scorecard_methodologies",
            page,
            f"/#av_section_2/.avia_textblock/p[{ordinal}]",
            methodology_id=key("item", ordinal),
            chamber_text="Senate",
            methodology_text=json.dumps(narrative, ensure_ascii=False),
            methodology_url=page.url,
            disclosure_status="Complete original numbered publisher heading and explanatory paragraph; distinct from the PDF title",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id="agreement",
            item_id=ordinal,
            participation_id="source-column",
            methodology_id=key("item", ordinal),
            publisher_position_text=target,
            position_basis="explicit",
            counts_toward_metric="true",
        )
    for index, entry in enumerate(data["members"]):
        r = entry["record"]
        identity = key("Senate", r["state_text"], r["member_name_text"])
        path = loc(entry["physical_page"], f"/members/{index}/record")
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=r["member_name_text"],
            state=r["state_text"],
            chamber_text="Senate",
            period_text="2019",
            notes_text=json.dumps(
                {"native_grid_fields": r, "raw_authored_line": entry["raw_authored_line"]}, ensure_ascii=False
            ),
        )
        if r["value_text"] is not None:
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/value_text",
                metric_id="agreement",
                publisher_member_key=identity,
                value_text=r["value_text"],
                value_number=r["value_text"],
            )
        for ordinal, value in enumerate(r["result_cells"], 1):
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + f"/result_cells/{ordinal - 1}",
                item_id=str(ordinal),
                metric_id="agreement",
                participation_id="source-column",
                publisher_member_key=identity,
                result_id="source-cell",
                result_text=value,
            )
    return bundle.finish(
        "Exact reviewed original PDF and private observations, complete stable PDF reread, all six pages and numbered "
        "narratives reconciled; every source context, blank vacancy cell, printed state and score retained. "
        "No official identity, vote direction, roll-call number, weighting or score reproduction inferred.",
        declared={"key_votes": "9"},
    )
