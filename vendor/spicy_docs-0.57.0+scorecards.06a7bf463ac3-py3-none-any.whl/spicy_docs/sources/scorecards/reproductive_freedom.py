"""Reproductive Freedom for All's named original annual federal PDF scorecards."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from math import isfinite
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "reproductive-freedom-named-original-annual-pdf/2"
HOSTS = ("reproductivefreedomforall.org",)
INDEX = "https://reproductivefreedomforall.org/resources/congressional-records-downloadable-pdf/"
# Measured full printed populations, including replacement and vacant source rows.
SPECS: dict[str, dict[str, Any]] = {
    "2025": {
        "source": {
            "url": "https://reproductivefreedomforall.org/wp-content/uploads/2026/06/RFFA_2025-CongRecordOnChoice_Senate-Grids_Proof-6.pdf",
            "sha256": "7bd6812afda798851dd8cef291a7ac73fdb600c9688b73b1f4032c351a5a7642",
            "page_count": 20,
        },
        "qualified_sha256": "d4a7b2a758af045f22041d3e320f0b607748803ae141d14a986eab373ecf2b8f",
        "title": "2025 CONGRESSIONAL RECORD ON REPRODUCTIVE FREEDOM",
        "publisher": "REPRODUCTIVE FREEDOM FOR ALL",
        "congress": "119TH CONGRESS",
        "session": "1ST SESSION",
        "member_counts": {"Senate": 100, "House": 441},
        "members_by_page": {
            "8": 26,
            "9": 26,
            "10": 26,
            "11": 22,
            "12": 27,
            "13": 63,
            "14": 63,
            "15": 55,
            "16": 55,
            "17": 62,
            "18": 60,
            "19": 56,
        },
        "item_ids": {"House": [str(i) for i in range(1, 5)], "Senate": [str(i) for i in range(1, 33)]},
        "glyph_counts": {"-": 2544, "A": 86, "+": 2297, "I": 13, "N/A": 18, "P": 2, "source-blank": 4},
        "vacant_members": [
            ["House", "NEW JERSEY", "11", "VACANT"],
            ["House", "TEXAS", "18", "VACANT (Sylvester Turner dec. 3/5)"],
        ],
        "ambiguous_party_names": [
            "SHEILA CHERFILUS-McCORMICK",
            "APRIL McCLAIN DELANEY",
            "BETTY McCOLLUM",
            "JENNIFER McCLELLAN",
        ],
    },
    "2024": {
        "source": {
            "url": "https://reproductivefreedomforall.org/wp-content/uploads/2025/05/2024-Congressional-Record-on-Reproductive-Freedom.pdf",
            "sha256": "14d107a1b6c798e2dad35250fcf0b8861bdeaa4c87781c67c1e0c9e2b85f51f1",
            "page_count": 16,
        },
        "member_counts": {"Senate": 101, "House": 438},
        "members_by_page": {
            "6": 52,
            "7": 49,
            "9": 64,
            "10": 62,
            "11": 56,
            "12": 56,
            "13": 61,
            "14": 55,
            "15": 63,
            "16": 21,
        },
        "item_ids": {"House": ["1", "2", "3", "4", "5"], "Senate": ["1", "2", "3", "4", "5"]},
        "glyph_counts": {"-": 1283, "A": 103, "+": 1272, "I": 34, "L": 3},
        "qualified_sha256": "b7e7da090603bc6418c4a46dc8310f49954715a971affac752c4f5e64302deb4",
        "title": "2024 CONGRESSIONAL RECORD ON REPRODUCTIVE FREEDOM",
        "publisher": "REPRODUCTIVE FREEDOM FOR ALL",
        "congress": "118TH CONGRESS",
        "session": "2ND SESSION",
        "vacant_members": [],
        "ambiguous_party_names": [
            "SHEILA CHERFILUS-McCORMICK",
            "BETTY McCOLLUM",
            "ANN McLANE KUSTER",
            "JENNIFER McCLELLAN",
            "SUZAN DelBENE",
        ],
        "text_matrix_party_names": ["Kyrsten Sinema", "Angus King", "Bernie Sanders"],
        "text_matrix_observation": {
            "file": "original-font-matrices-2024.json",
            "sha256": "6cc7da6c8a93099f14353cd6f011563d286ab676dabaa23c3060575343db899e",
        },
    },
}


def _spec(identifier):
    try:
        return SPECS[identifier]
    except (KeyError, TypeError) as error:
        raise ScorecardSourceError(
            "Reproductive Freedom for All edition is not a reviewed original rendition"
        ) from error


def _edition(identifier):
    spec = _spec(identifier)
    return ScorecardEdition(
        "reproductive_freedom",
        identifier,
        spec["source"]["url"],
        spec["title"],
        year=identifier,
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    require_reviewed_pdf(
        document,
        source_url=spec["source"]["url"],
        source_sha256=spec["source"]["sha256"],
        message="Reproductive Freedom for All PDF differs from its reviewed original edition",
        trailer_window=1024,
    )


def _evidence(entry, spec):
    if (
        not isinstance(entry["physical_pages"], list)
        or not entry["physical_pages"]
        or any(type(p) is not int or not 1 <= p <= spec["source"]["page_count"] for p in entry["physical_pages"])
        or entry["schema_version"]
        not in {
            "rffa-pdf-semantic-facts/1",
            "rffa-pdf-semantic-correction/2",
            "rffa-pdf-semantic-correction/3",
        }
        or not isinstance(entry["outcome_file"], str)
        or not entry["outcome_file"]
        or not re.fullmatch(r"[0-9a-f]{64}", entry["outcome_sha256"])
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("Reproductive Freedom for All facts differ from the reviewed observation pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "rffa-qualified-original-pdf/1"
            or data["edition_key"] != identifier
            or data["source"] != spec["source"]
            or data["member_counts"] != spec["member_counts"]
            or data["members_by_page"] != spec["members_by_page"]
            or data["item_ids"] != spec["item_ids"]
            or data["glyph_counts"] != spec["glyph_counts"]
            or data["uncertainties"]
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["title_text"] != spec["title"]
            or front["publisher_name_text"] != spec["publisher"]
            or front["year_text"] != identifier
            or front["congress_text"] != spec["congress"]
            or front["session_text"] != spec["session"]
            or not {"+", "-", "P", "A", "I", "L", "n/a", "dec", "res"} <= set(front["legend"])
            or any(not isinstance(v, str) or not v for v in front["legend"].values())
            or front["party_legend"]
            != [
                {"party_text": "DEMOCRATS", "presentation_text": "All capitals"},
                {"party_text": "Republicans", "presentation_text": "Initial capitals"},
                {"party_text": "Independents", "presentation_text": "Italics"},
            ]
            or not front["score_methodology_text"]
        ):
            raise ValueError
        items, item_counts = set(), Counter()
        for entry in data["items"]:
            _evidence(entry["evidence"], spec)
            r = entry["record"]
            chamber, item = r["chamber_text"], r["item_number_text"]
            if (
                chamber not in spec["item_ids"]
                or item not in spec["item_ids"][chamber]
                or (chamber, item) in items
                or any(
                    not isinstance(r[f], str) or not r[f]
                    for f in [
                        "title_text",
                        "date_text",
                        "publisher_position_text",
                        "source_native_text",
                    ]
                )
                or (
                    r["action_label_text"] is not None
                    and (not isinstance(r["action_label_text"], str) or not r["action_label_text"])
                )
                or not re.fullmatch(r"\d+/\d+/\d+", r["date_text"])
                or any(not isinstance(c, str) or not c for c in r["bill_citations"] + r["amendment_citations"])
            ):
                raise ValueError
            items.add((chamber, item))
            item_counts[chamber] += 1
        if dict(item_counts) != {c: len(ids) for c, ids in spec["item_ids"].items()}:
            raise ValueError
        identities, counts, pages, glyphs, vacant, ambiguous = set(), Counter(), Counter(), Counter(), [], []
        matrix_parties = []
        for entry in data["members"]:
            _evidence(entry["evidence"], spec)
            for correction in entry["corrective_evidence"]:
                _evidence(correction, spec)
            r = entry["record"]
            chamber = r["chamber_text"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or not re.fullmatch(r"[A-Z ]+", r["state_text"])
                or not r["member_name_text"]
                or r["party_text"] not in {"DEMOCRATS", "Republicans", "Independents", None}
                or (chamber == "House" and not re.fullmatch(r"\d+|AL", r["district_text"]))
                or (chamber == "Senate" and r["district_text"] is not None)
                or (r["value_text"] is not None and not re.fullmatch(r"\d+|N/A|NA|n/a", r["value_text"]))
                or len(entry["evidence"]["physical_pages"]) != 1
                or [v["item_number_text"] for v in r["item_results"]] != spec["item_ids"][chamber]
                or any(
                    v["result_text"] not in (set(spec["glyph_counts"]) - {"source-blank"}) | {None}
                    for v in r["item_results"]
                )
                or not isinstance(entry["native_name_fonts"], list)
                or not entry["native_name_fonts"]
                or any(not isinstance(v, str) or not v for v in entry["native_name_fonts"])
            ):
                raise ValueError
            designation = entry["source_designation_text"]
            style = entry["party_style_observation"]
            if designation is not None:
                if (
                    designation != "VACANT"
                    or not r["member_name_text"].startswith("VACANT")
                    or r["party_text"] is not None
                ):
                    raise ValueError
                vacant.append(list(identity))
            elif r["member_name_text"].startswith("VACANT"):
                raise ValueError
            if style is not None:
                if (
                    r["party_text"] is not None
                    or style["source_name_text"] != r["member_name_text"]
                    or not style["disposition"]
                ):
                    raise ValueError
                ambiguous.append(r["member_name_text"])
            if r["party_text"] is None and designation is None and style is None:
                raise ValueError
            matrix = entry.get("native_text_matrix_style_observation")
            if matrix is not None:
                tm = matrix["text_matrix"]
                expected_matrix = spec["text_matrix_observation"]
                if (
                    r["party_text"] != "Independents"
                    or matrix["presentation_text"] != "Italics"
                    or matrix["source_text"] != r["member_name_text"]
                    or type(matrix["physical_page"]) is not int
                    or matrix["physical_page"] != entry["evidence"]["physical_pages"][0]
                    or matrix["source_sha256"] != spec["source"]["sha256"]
                    or matrix["observation_file"] != expected_matrix["file"]
                    or matrix["observation_sha256"] != expected_matrix["sha256"]
                    or not isinstance(tm, list)
                    or len(tm) != 6
                    or any(type(v) not in {int, float} or not isfinite(v) for v in tm)
                    or tm[0] <= 0
                    or tm[3] <= 0
                    or tm[1] != 0
                    or tm[2] == 0
                ):
                    raise ValueError
                matrix_parties.append(r["member_name_text"])
            identities.add(identity)
            counts[chamber] += 1
            pages[str(entry["evidence"]["physical_pages"][0])] += 1
            glyphs.update("source-blank" if v["result_text"] is None else v["result_text"] for v in r["item_results"])
        if (
            dict(counts) != spec["member_counts"]
            or dict(pages) != spec["members_by_page"]
            or dict(glyphs) != spec["glyph_counts"]
            or vacant != spec["vacant_members"]
            or ambiguous != spec["ambiguous_party_names"]
            or matrix_parties != spec.get("text_matrix_party_names", [])
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "Reproductive Freedom for All facts do not establish the full original rendition"
        ) from error


@dataclass(frozen=True, slots=True)
class ReproductiveFreedomPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError(
                "Reproductive Freedom for All observations require a reviewed named edition"
            ) from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("Reproductive Freedom for All PDF redistribution rights are not established")
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(
            context.read(spec["source"]["url"], stage=f"reproductive_freedom:{self.edition_key}:list", hosts=HOSTS),
            spec,
        )
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError(
                "Reproductive Freedom for All reader requires its exact configured named edition"
            )
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != _edition(edition.edition_id):
        raise ScorecardSourceError("Reproductive Freedom for All requires its exact reviewed named edition")
    if context.evidence_policy == "full":
        raise ScorecardSourceError("Reproductive Freedom for All PDF redistribution rights are not established")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Reproductive Freedom for All requires reviewed facts and private observation retention"
        )
    data = _qualified(qualified_observations, edition.edition_id, spec)
    primary = context.read(spec["source"]["url"], stage=f"reproductive_freedom:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(primary, spec)
    observation = retain_qualified(
        primary,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source"]["sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"reproductive_freedom:{edition.edition_id}:qualified-observations",
    )

    def location(entry, pointer):
        return f"pdf:pages={','.join(str(p) for p in entry['evidence']['physical_pages'])};observation={observation};{pointer}/record"

    front = data["front"]["record"]
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name=front["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="complete named annual original PDF; every printed member, score and action cell including vacant NULLs and replacements; original identifiers, font legend, source ambiguities and stable reread",
        homepage="https://reproductivefreedomforall.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        timespan_text=front["year_text"], session_text=front["session_text"], methodology_url=primary.url
    )
    front_path = location(data["front"], "/front")
    for chamber in spec["item_ids"]:
        method = key(chamber, "annual-methodology")
        bundle.add(
            "scorecard_methodologies",
            primary,
            front_path,
            methodology_id=method,
            chamber_text=chamber,
            methodology_url=primary.url,
            disclosure_status="partial",
            methodology_text=json_column(front),
        )
        bundle.add(
            "scorecard_metrics",
            primary,
            front_path,
            metric_id=key(chamber, "score"),
            name="%",
            value_unit_text="%",
            chamber_text=chamber,
            period_text=front["year_text"],
            methodology_id=method,
        )
    for i, entry in enumerate(data["items"]):
        r = entry["record"]
        chamber, item = r["chamber_text"], key(r["chamber_text"], r["item_number_text"])
        path = location(entry, f"/items/{i}")
        references = [
            {
                "occurrence_id": f"{kind}:{j}",
                "kind": kind,
                "citation_text": citation,
                kind + "_citation_text": citation,
                "chamber_text": chamber,
                "source_path": path + f"/{kind}_citations/{j}",
            }
            for kind in ["bill", "amendment"]
            for j, citation in enumerate(r[kind + "_citations"])
        ]
        method = key(chamber, "item", r["item_number_text"])
        bundle.add(
            "scorecard_methodologies",
            primary,
            path,
            methodology_id=method,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(
                {k: v for k, v in r.items() if k not in {"source_native_text", "source_model_item"}}
            ),
        )
        bundle.add(
            "scorecard_items",
            primary,
            path,
            item_id=item,
            publisher_item_id=r["item_number_text"],
            item_kind_text="Vote",
            title=r["title_text"],
            item_date_text=r["date_text"],
            chamber_text=chamber,
            congress_text=front["congress_text"],
            session_text=front["session_text"],
            bill_citation_text=next(iter(r["bill_citations"]), None),
            amendment_citation_text=next(iter(r["amendment_citations"]), None),
            references_json=json_column(references),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            primary,
            path,
            metric_id=key(chamber, "score"),
            item_id=item,
            participation_id="printed-action-column",
            methodology_id=method,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
        )
    for i, entry in enumerate(data["members"]):
        r = entry["record"]
        chamber = r["chamber_text"]
        path = location(entry, f"/members/{i}")
        member = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text=front["year_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "original_value_text": r["value_text"],
                    "native_name_fonts": entry["native_name_fonts"],
                    "party_style_observation": entry["party_style_observation"],
                    "source_designation_text": entry["source_designation_text"],
                    **(
                        {"native_text_matrix_style_observation": entry["native_text_matrix_style_observation"]}
                        if entry.get("native_text_matrix_style_observation") is not None
                        else {}
                    ),
                    "source_scope": "printed original member observations including replacement and vacant rows",
                }
            ),
        )
        value = "N/A" if r["value_text"] in {"NA", "n/a"} else r["value_text"]
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + "/value_text",
            publisher_member_key=member,
            metric_id=key(chamber, "score"),
            value_text=value,
            value_number=decimal_text(value),
            value_status_text=value if value == "N/A" else None,
        )
        for j, cell in enumerate(r["item_results"]):
            bundle.add(
                "scorecard_member_item_results",
                primary,
                path + f"/item_results/{j}",
                result_id="printed-cell",
                publisher_member_key=member,
                item_id=key(chamber, cell["item_number_text"]),
                metric_id=key(chamber, "score"),
                participation_id="printed-action-column",
                result_text=cell["result_text"],
                reason_text=front["legend"].get(cell["result_text"]),
            )
    repeated = context.read(
        spec["source"]["url"], stage=f"reproductive_freedom:{edition.edition_id}:pdf:reread", hosts=HOSTS
    )
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete original annual printed edition, all source member/rating/action cells including blank vacancy rows; every source item and short preferred position; original PDF reread identically",
        declared={
            "members_by_chamber": spec["member_counts"],
            "members_by_page": spec["members_by_page"],
            "item_ids_by_chamber": spec["item_ids"],
            "glyph_counts": spec["glyph_counts"],
            "vacant_source_rows": spec["vacant_members"],
            "ambiguous_party_source_names": spec["ambiguous_party_names"],
            "source_counts_basis": "complete original printed grids including replacements and vacant source rows; source comparison symbols are not official yea/nay actions",
        },
    )
