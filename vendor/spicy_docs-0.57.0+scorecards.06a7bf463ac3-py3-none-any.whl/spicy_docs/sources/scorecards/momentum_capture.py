"""Anonymous capture for the observed IPAA and BIPAC tenants, using the shared HTTP bounds.

Authentication responses never reach the evidence callback. No account login,
arbitrary tenant, redirect, discovery walk or scoring formula is supported.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime

from spicy_docs.sources.scorecards.common import ScorecardSourceError
from spicy_docs.transport.credentials import CredentialRefusedError

TENANTS = {
    "ipaa": ("ipaa1", "https://ipaagrassroots.org"),
    "bipac": ("bipac", "https://bipac.org"),
}


class MomentumCapture:
    """A context fetcher; callers retain source bodies under their chosen policy.

    ``auth_event`` receives safe request metadata only. Tests inject an HTTPX
    transport into the existing bounded client. Each request, including auth,
    consumes one shared budget, and requests start at least 1.05 seconds apart.
    """

    def __init__(self, publisher_id, *, auth_event, max_requests=12, transport=None):
        from spicy_docs.transport.capture import BoundedHttpCapture

        if publisher_id not in TENANTS or type(max_requests) is not int or not 1 <= max_requests <= 20:
            raise ScorecardSourceError("Momentum capture needs a reviewed tenant and a bounded request limit")
        self.tenant, self.origin = TENANTS[publisher_id]
        self.auth_event = auth_event
        self._token = None
        api = "https://admin.mplatform.io/api/v1/" + self.tenant + "/"
        self._api_urls = (
            {
                api + "vr/bills?withDetail=true",
                *(api + "vr/chamber-roster?chamber=" + chamber + "&stateCode=US" for chamber in ("FH", "FS")),
            }
            if publisher_id == "ipaa"
            else {api + "vr/bills?withDetail=true", api + "pages/site-pages"}
        )
        self._public_urls = {
            self.origin + "/_next/static/chunks/204gm1ur7_-nj.js",
            *(
                {"https://www.ipaa.org/", self.origin + "/voting-records"}
                if publisher_id == "ipaa"
                else {self.origin + "/home"}
            ),
        }
        self._http = BoundedHttpCapture(
            max_requests=max_requests,
            timeout_seconds=35,
            min_request_interval_seconds=1.05,
            user_agent="Mozilla/5.0 SpicyDocs bounded source capture",
            error_type=ScorecardSourceError,
            transport=transport,
            clock=lambda: datetime.now(UTC),
        )

    def close(self):
        self._token = None
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _authenticate(self):
        url = self.origin + "/api/auth/token"
        response = self._http.capture(
            url,
            max_bytes=1024 * 1024,
            method="POST",
            content=json.dumps({"site": self.tenant}, separators=(",", ":")).encode(),
            request_headers={"Content-Type": "application/json"},
            max_attempts=1,
        )
        self.auth_event(
            {
                "url": url,
                "method": "POST",
                "site": self.tenant,
                "http_status": response.status_code,
                "observed_at": response.observed_at,
                "body_retention": "omitted: credential response",
            }
        )
        if response.resolved_url != url or response.status_code != 200 or response.content_type != "application/json":
            raise ScorecardSourceError("Momentum anonymous authentication route or response changed")
        try:
            data = json.loads(response.body)
            token = data["access_token"]
        except (ValueError, KeyError, TypeError):
            raise ScorecardSourceError("Momentum anonymous authentication shape changed") from None
        if not isinstance(token, str) or len(token) < 8 or any(c.isspace() for c in token):
            raise ScorecardSourceError("Momentum anonymous authentication token shape changed")
        self._token = token

    def __call__(self, url):
        if url not in self._api_urls | self._public_urls:
            raise ScorecardSourceError("Momentum capture URL is outside the selected tenant's reviewed routes")
        try:
            if url in self._api_urls and self._token is None:
                self._authenticate()
            headers = (
                {"Authorization": "Bearer " + self._token, "Accept": "application/json"}
                if url in self._api_urls
                else None
            )
            response = self._http.capture(url, max_bytes=16 * 1024**2, request_headers=headers, max_attempts=1)
            if self._token and (
                self._token.encode() in response.body
                or self._token in response.resolved_url
                or self._token in response.requested_url
            ):
                raise ScorecardSourceError("Momentum response echoed a credential; body retention refused")
            return response
        except CredentialRefusedError:
            raise CredentialRefusedError("Momentum access refused; stop and preserve prior rows") from None
        except Exception:  # noqa: BLE001 - arbitrary transport exceptions can contain the token
            # Never propagate token-bearing response objects, URLs or exception chains.
            raise ScorecardSourceError("Momentum capture failed; preserve prior rows") from None
