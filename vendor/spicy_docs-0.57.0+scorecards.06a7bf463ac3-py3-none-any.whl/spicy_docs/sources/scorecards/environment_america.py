"""Environment America's named original 2009 congressional grids and source context."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "environment-america-2009-qualified-original-pdf/1"
NAME = "Environment America"
INDEX = "https://environmentamerica.org/resources/environment-america-2009-congressional-scorecard/"
PDF = "https://publicinterestnetwork.org/wp-content/uploads/2011/12/Env-America-Scorecard.pdf"
HOSTS = ("environmentamerica.org", "publicinterestnetwork.org")
SOURCE_SHA256 = "65aa527cdd2f4c4edea1238caada4baf3f598cb4872859010ffb2d18b95a5b62"
QUALIFIED_SHA256 = "9349e3041b6322708e5b7b2ed674e396db69d5dc06886b4e6a07389b8f2be097"
MEMBERS = {"Senate": 100, "House": 435}
ITEMS = {"Senate": 7, "House": 15}
PAGE_MEMBERS = {13: 31, 14: 35, 15: 34, 20: 39, **{page: 44 for page in range(21, 30)}}
GLYPHS = {"+": 4261, "-": 2123, "NA": 631, "A": 198, "*": 11, "P": 1}
COHORT_COUNTS = {
    "environmental-champions": {"Senate": 40, "House": 144},
    "natural-disasters": {"Senate": 26, "House": 17},
}
STATE_ROWS = 50
PDF_PERIOD = "May 2007 and September 2009"
HTML_PERIOD = "April 2008 and September 2009"
CONTEXT_IDS = {
    "cover",
    "publication-and-publisher",
    "pdf-overview-period",
    "overview-award-count-prose",
    "source-summary-charts",
    "environmental-champions",
    "natural-disasters",
    "state-averages",
    "senate-selected-key-votes",
    "house-selected-key-votes",
    "grid-legend-13",
    "grid-legend-20",
    *("printed-item-page-footer-" + str(page) for page in (11, 12, 16, 17, 18, 19)),
    *("printed-grid-page-footer-" + str(page) for page in PAGE_MEMBERS),
}
EDITION = ScorecardEdition(
    "environment_america",
    "2009-original-report-pdf",
    PDF,
    "Environment America Congressional Scorecard 2009",
    year="2009",
    chamber="both",
    is_current=False,
)


def list_scorecards(context: ScorecardContext):
    return (EDITION,)


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _index(document):
    if document.url != INDEX or not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Environment America original guide custody or complete HTML boundary changed")
    html = soup(document)
    heading, published, content = html.select("h1"), html.select("time"), html.select("div.wysiwyg")
    links = html.select('a[href="' + PDF + '"]')
    if len(heading) != 1 or _text(heading[0]) != "Environment America 2009 Congressional Scorecard" or len(links) != 1:
        raise ScorecardSourceError("Environment America named original guide or source-owned PDF link changed")
    if len(published) != 1 or published[0].get("datetime") != "2009-12-30" or len(content) != 1:
        raise ScorecardSourceError("Environment America original publication and narrative context changed")
    if HTML_PERIOD not in _text(content[0]):
        raise ScorecardSourceError("Environment America original HTML period statement changed")
    return {
        "title_text": _text(heading[0]),
        "published_date_text": published[0]["datetime"],
        "published_label_text": _text(published[0]),
        "pdf_link": {"href": links[0]["href"], "text": _text(links[0])},
        "narrative": {"text": _text(content[0]), "html": str(content[0]), "source_path": "div.wysiwyg"},
    }


def _asset(body):
    try:
        data = json.loads(body)
        if (
            data["schema_version"] != "environment-america-2009-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["page_count"] != 30
        ):
            raise ValueError
        members, items, contexts = data["members"], data["items"], data["contexts"]
        if (
            Counter(r["chamber_text"] for r in members) != MEMBERS
            or Counter(r["page"] for r in members) != PAGE_MEMBERS
        ):
            raise ValueError
        if Counter(r["chamber_text"] for r in items) != ITEMS:
            raise ValueError
        if len(contexts) != len(CONTEXT_IDS) or {r["context_id"] for r in contexts} != CONTEXT_IDS:
            raise ValueError
        if any(not isinstance(r["text"], str) or not r["text"] or not r["source_path"] for r in contexts):
            raise ValueError
        identities = set()
        for chamber in MEMBERS:
            chamber_items = [r for r in items if r["chamber_text"] == chamber]
            if [r["publisher_item_id"] for r in chamber_items] != [str(n) for n in range(1, ITEMS[chamber] + 1)]:
                raise ValueError
            for row in chamber_items:
                if (
                    not row["title_text"]
                    or not row["authored_paragraph_text"]
                    or row["publisher_position_text"] not in {"Yes", "No"}
                    or not re.fullmatch(r"\d+", row["roll_number_text"])
                    or not re.fullmatch(r"\d+/\d+/\d+", row["item_date_text"])
                    or row["preferred_statement_text"] not in row["authored_paragraph_text"]
                    or not row["references"]
                    or not row["physical_pages"]
                    or row["physical_pages"][0] != row["page"]
                ):
                    raise ValueError
        for page, count in PAGE_MEMBERS.items():
            rows = [r for r in members if r["page"] == page]
            if [r["source_ordinal"] for r in rows] != list(range(1, count + 1)):
                raise ValueError
        for row in members:
            chamber = row["chamber_text"]
            identity = (chamber, row["state_text"], row["district_text"], row["member_name_text"])
            if (
                identity in identities
                or not row["member_name_text"]
                or not re.fullmatch(r"[A-Z]{2}", row["state_text"])
            ):
                raise ValueError
            identities.add(identity)
            if (chamber == "Senate" and row["district_text"] is not None) or (
                chamber == "House" and not re.fullmatch(r"\d+", row["district_text"] or "")
            ):
                raise ValueError
            if not re.fullmatch(r"\d+%|NA|\*", row["score_text"]):
                raise ValueError
            results = row["item_results"]
            if [r["item_number_text"] for r in results] != [str(n) for n in range(1, ITEMS[chamber] + 1)]:
                raise ValueError
        if Counter(v["result_text"] for r in members for v in r["item_results"]) != GLYPHS:
            raise ValueError
        context = {r["context_id"]: r for r in contexts}
        for name, counts in COHORT_COUNTS.items():
            entries = context[name]["entries"]
            if (
                Counter(r["chamber_text"] for r in entries) != counts
                or context[name]["source_declared_counts"] != counts
            ):
                raise ValueError
            if any(not r["member_name_text"] or not r["state_text"] or not r["source_path"] for r in entries):
                raise ValueError
        if len(context["state-averages"]["entries"]) != STATE_ROWS:
            raise ValueError
        if [r["code_text"] for r in data["legend"]] != ["+", "—", "A", "P", "N/A"] or any(
            not r["meaning_text"] for r in data["legend"]
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError):
        raise ScorecardSourceError("Environment America qualified complete source fact shape changed") from None


@dataclass(frozen=True)
class EnvironmentAmericaPDFReader:
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)
    parser_version: ClassVar[str] = parser_version

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        if edition != EDITION:
            raise ScorecardSourceError("Environment America edition is outside the qualified named source scope")
        guide = context.read(INDEX, stage="scorecards:environment_america:guide", hosts=HOSTS)
        facts = _index(guide)
        document = context.read(PDF, stage="scorecards:environment_america:original-pdf", hosts=HOSTS)
        require_reviewed_pdf(
            document,
            source_url=PDF,
            source_sha256=SOURCE_SHA256,
            message="Environment America reviewed original PDF changed or incomplete",
        )
        observation = retain_qualified(
            document,
            self.qualified_observations,
            self.retain_observations,
            source_sha256=SOURCE_SHA256,
            observations_sha256=QUALIFIED_SHA256,
            stage="scorecards:environment_america:qualified-2009",
        )
        data = _asset(self.qualified_observations)
        located = lambda path: path + ";observation=" + observation
        context_rows = {r["context_id"]: r for r in data["contexts"]}
        periods = [
            {
                "occurrence_id": "pdf-overview-period",
                "period_text": PDF_PERIOD,
                "kind": "explicit",
                "source_path": located(context_rows["pdf-overview-period"]["source_path"]),
            },
            {
                "occurrence_id": "html-narrative-period",
                "period_text": HTML_PERIOD,
                "kind": "explicit",
                "source_path": "capture:" + guide.capture_id + "#div.wysiwyg",
            },
        ]
        bundle = Bundle(
            edition,
            context,
            document,
            publisher_name=NAME,
            parser_version=parser_version,
            rendition_rule="Named original complete2009PDF member grids and source-listed key votes; named cohorts/state aggregates remain source context without identity joins or states as members; literal conflicting HTML/PDF periods and source summaries",
            homepage="https://environmentamerica.org/",
        )
        bundle.use(document, "member-grids", "key-items", "pdf-source-context")
        bundle.use(guide, "original-guide-authority", "html-source-context")
        bundle.tables["scorecard_publishers"][0].update(
            scorecard_index_url=INDEX, source_path=located("pdf:page=2;publication-and-publisher")
        )
        bundle.tables["scorecards"][0].update(
            edition_label_text="2009",
            timespan_text=PDF_PERIOD,
            periods_json=json_column(periods),
            methodology_url=PDF,
            source_path=located("pdf:page=1;cover"),
        )
        for row in data["contexts"]:
            # Ancillary named cohorts and state-average tables are original
            # observations, not resolved member identities or derived ratings.
            text = json_column(row) if "entries" in row else row["text"]
            bundle.add(
                "scorecard_methodologies",
                document,
                located(row["source_path"]),
                methodology_id=row["context_id"],
                methodology_text=text,
                disclosure_status="literal source context; no inferred cohort/grid join or score reproduction",
            )
        bundle.add(
            "scorecard_methodologies",
            guide,
            "div.wysiwyg",
            methodology_id="original-html-context",
            methodology_text=json_column(facts),
            disclosure_status="literal original guide date, narrative and source-owned PDF link; period conflict retained",
        )
        for chamber in MEMBERS:
            page = min(r["page"] for r in data["members"] if r["chamber_text"] == chamber)
            bundle.add(
                "scorecard_metrics",
                document,
                located(f"pdf:page={page};{chamber};header=Score"),
                metric_id=key(chamber, "score"),
                name="Score",
                value_unit_text="%",
                chamber_text=chamber,
                methodology_id=chamber.lower() + "-selected-key-votes",
                period_text=PDF_PERIOD,
                periods_json=json_column(periods),
            )
        for row in data["items"]:
            item_id = key(row["chamber_text"], row["publisher_item_id"])
            path = located(row["source_path"])
            method_id = key("item", item_id)
            bundle.add(
                "scorecard_methodologies",
                document,
                path,
                methodology_id=method_id,
                chamber_text=row["chamber_text"],
                methodology_text=json_column(
                    {
                        "authored_paragraph_text": row["authored_paragraph_text"],
                        "physical_pages": row["physical_pages"],
                        "preferred_statement_text": row["preferred_statement_text"],
                    }
                ),
                disclosure_status="complete native item paragraph and header; literal discrepancies preserved",
            )
            bundle.add(
                "scorecard_items",
                document,
                path,
                item_id=item_id,
                publisher_item_id=row["publisher_item_id"],
                item_kind_text="key environmental votes",
                title=row["title_text"],
                item_date_text=row["item_date_text"],
                chamber_text=row["chamber_text"],
                roll_number_text=row["roll_number_text"],
                bill_citation_text=row["bill_citation_text"],
                references_json=json_column(
                    [{**r, "source_path": located(r["source_path"])} for r in row["references"]]
                ),
                publisher_position_text=row["publisher_position_text"],
                position_basis="explicit",
                position_source_path=path + ";native-Pro-Environment-header",
            )
            bundle.add(
                "scorecard_metric_items",
                document,
                path,
                metric_id=key(row["chamber_text"], "score"),
                item_id=item_id,
                participation_id="printed-key-vote-column",
                methodology_id=method_id,
                publisher_position_text=row["publisher_position_text"],
                position_basis="explicit",
                counts_toward_metric="true",
            )
        meanings = {r["code_text"]: r["meaning_text"] for r in data["legend"]}
        for row in data["members"]:
            chamber = row["chamber_text"]
            member_key = key(
                chamber,
                row["state_text"],
                *([row["district_text"]] if row["district_text"] else []),
                row["member_name_text"],
            )
            path = located(f"pdf:page={row['page']};native-member={row['source_ordinal']}")
            bundle.add(
                "scorecard_members",
                document,
                path,
                publisher_member_key=member_key,
                member_name=row["member_name_text"],
                chamber_text=chamber,
                state=row["state_text"],
                district=row["district_text"],
                identifiers_json="[]",
                period_text=PDF_PERIOD,
                notes_text=json_column({"native_name_line": row["raw_name_line"]}),
            )
            value = "N/A" if row["score_text"] == "NA" else row["score_text"]
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + ";cell=Score",
                metric_id=key(chamber, "score"),
                publisher_member_key=member_key,
                value_text=value,
                value_number=decimal_text(value),
                notes_text=json_column({"native_value_text": row["score_text"]})
                if value != row["score_text"]
                else None,
            )
            for cell in row["item_results"]:
                raw = cell["result_text"]
                value = "N/A" if raw == "NA" else raw
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    path + ";cell=" + cell["item_number_text"],
                    item_id=key(chamber, cell["item_number_text"]),
                    result_id="native-cell",
                    publisher_member_key=member_key,
                    result_text=value,
                    reason_text=meanings.get("—" if raw == "-" else value),
                )
        repeated_guide = context.read(INDEX, stage="scorecards:environment_america:guide-reread", hosts=HOSTS)
        if _index(repeated_guide) != facts:
            raise ScorecardSourceError("Environment America original guide context changed during reread")
        bundle.use(repeated_guide, "original-guide-authority", "html-source-context", role="corroboration")
        repeated_pdf = context.read(PDF, stage="scorecards:environment_america:original-pdf-reread", hosts=HOSTS)
        require_reviewed_pdf(
            repeated_pdf,
            source_url=PDF,
            source_sha256=SOURCE_SHA256,
            message="Environment America reviewed original PDF changed or incomplete",
        )
        bundle.use(repeated_pdf, "member-grids", "key-items", "pdf-source-context", role="corroboration")
        return bundle.finish(
            "Exact complete reviewed original2009PDF; every native member/score/item cell and full source key-item paragraph reconciled; native cohorts/state averages and conflicting observations retained as context; private observations and identical original PDF/guide rereads"
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Environment America named PDF reader requires qualified private facts and retention"
        )
    return EnvironmentAmericaPDFReader(qualified_observations, retain_observations).acquire_scorecard(edition, context)
