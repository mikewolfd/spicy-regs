"""Drum Major Institute's original 2007 percent/grade and thumbs comparison PDF."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "drum-major-2007-qualified-visible-pdf/1"
ORIGINAL_URL = "http://www.drummajorinstitute.org/pdfs/2007_scorecard_layout_final%20(2).pdf"
SOURCE_URL = "https://web.archive.org/web/20110726005753id_/" + ORIGINAL_URL
SOURCE_SHA256 = "2a312adf9377049ff49b024d4742e73e946d3467e3ab52ec11c4ae8c6c930a35"
QUALIFIED_SHA256 = "12f42492bbf7aeaadf217c6c2ce9fa08c3c4f0e580c2a7673f665918f2daf6ab"
TITLE = "TheMiddleClass.org 2007 Congressional Scorecard"
EDITION = ScorecardEdition(
    "drum_major", "2007-original-pdf", SOURCE_URL, TITLE, year="2007", chamber="both", is_current=False
)
PAGE_LAYOUT = tuple(
    (n, n - 2, "Senate" if n <= 24 else "House", 32 if n == 24 else 27 if n == 37 else 34) for n in range(22, 38)
)
# The source grid and overview order differ. These are exact original citation
# occurrence links, not title similarity or outside legislative identities.
NARRATIVE_LINKS = {"Senate": (16, 17, 10, 14, 12, 11, 13, 20, 15, 19), "House": (17, 8, 14, 18, 12, 11, 20, 15, 19, 9)}
GLYPHS = frozenset(("👍", "👎", "–", ""))


@dataclass(frozen=True, slots=True)
class DrumMajor2007Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URL,
        source_sha256=SOURCE_SHA256,
        message="DMI 2007 original PDF differs from its reviewed complete visible rendition",
    )


def list_scorecards(context):
    source = context.read(SOURCE_URL, stage="scorecards:drum_major:2007:named-edition", hosts=("web.archive.org",))
    _source(source)
    return [EDITION]


def _facts(body):
    try:
        data = json.loads(body)
        assert set(data) == {
            "format_version",
            "source_sha256",
            "physical_page_count",
            "title_text",
            "year_text",
            "publisher_name_text",
            "pages",
            "items",
            "method",
            "narratives",
            "source_contexts",
            "visible_source_rule",
            "observation_differences",
            "grid_observation_review",
        }
        assert data["format_version"] == "drum-major-2007-qualified-visible-source-facts/1"
        assert data["source_sha256"] == SOURCE_SHA256 and data["physical_page_count"] == 40
        assert data["title_text"] == TITLE and data["year_text"] == "2007"
        assert data["publisher_name_text"] == "Drum Major Institute for Public Policy"
        assert len(data["pages"]) == len(PAGE_LAYOUT)
        for page, (number, printed, chamber, count) in zip(data["pages"], PAGE_LAYOUT, strict=True):
            assert (page["physical_page"], page["printed_page"], page["chamber_text"]) == (number, printed, chamber)
            assert page["score_column_heading_text"] == "SCORE" and page["grade_column_heading_text"] == "GRADE"
            assert page["issue_area_heading_text"] == "Issue Area"
            assert page["native_range_heading"].strip() and page["native_grid_context_spans"]
            assert len(page["items"]) == 10 and len(page["members"]) == count
            for item in page["items"]:
                assert all(
                    isinstance(item[f], str) and item[f].strip()
                    for f in ("title_text", "citation_text", "issue_area_text")
                )
                assert item["preferred_position_text"] in ("YES", "NO")
                assert item["native_preferred_position_encoded_text"].upper() == item["preferred_position_text"]
            for ordinal, member in enumerate(page["members"], 1):
                assert member["ordinal"] == ordinal and len(member["result_glyph_texts"]) == 10
                assert all(v in GLYPHS for v in member["result_glyph_texts"])
                assert member["party_text"] in ("D", "R", "I") and re.fullmatch(r"[A-Z]{2}", member["state_text"])
                assert isinstance(member["member_name_text"], str) and member["member_name_text"].strip()
                assert re.fullmatch(r"[0-9]+%", member["score_text"]) or member["score_text"] in ("INC", "INC.", "")
                assert member["grade_text"] in ("A+", "A", "B", "C", "D", "F", "INC", "INC.", "")
                assert member["native_member_cell_text"].strip()
                assert len(member["native_cells"]) == 14 and all(
                    isinstance(c["authored_text"], str) for c in member["native_cells"]
                )
        assert Counter(p["chamber_text"] for p in data["pages"] for _ in p["members"]) == Counter(
            {"Senate": 100, "House": 435}
        )
        assert [(n["printed_page"], n["physical_page"]) for n in data["narratives"]] == [
            (p - 2, p) for p in range(8, 21)
        ]
        for narrative in data["narratives"]:
            assert (
                narrative["native_spans"] and narrative["native_event_spans"] and narrative["native_assessment_spans"]
            )
            assert narrative["title_spans"] and narrative["citation_spans"] and narrative["position_spans"]
            assert all(
                isinstance(s["native_text"], str) and isinstance(s["display_text"], str)
                for s in narrative["native_spans"]
            )
            assert narrative["title_text"].strip() and narrative["citation_text"].strip()
            assert re.fullmatch(r"The Middle Class (Supports|Opposes)[.:]?", narrative["publisher_position_label_text"])
        assert [c["physical_page"] for c in data["source_contexts"]] == [n for n in range(1, 41) if not 22 <= n <= 37]
        assert all(
            c["native_spans"] and all(isinstance(s["display_text"], str) for s in c["native_spans"])
            for c in data["source_contexts"]
        )
        method = data["method"]
        assert len(method["native_methodology_paragraphs"]) == 4 and all(
            p["native_text"].strip() and p["display_text"].strip() and p["source_spans"]
            for p in method["native_methodology_paragraphs"]
        )
        assert [r["grade_text"] for r in method["grade_legend"]] == ["A+", "A", "B", "C", "D", "F"]
        assert (
            len(method["item_headers"]) == 20
            and len(method["aggregate_item_ratings"]) == 60
            and len(method["aggregate_grade_distributions"]) == 30
        )
        assert [(i["chamber_text"], i["ordinal"], i["narrative_physical_page"]) for i in data["items"]] == [
            (chamber, n, p) for chamber, pages in NARRATIVE_LINKS.items() for n, p in enumerate(pages, 1)
        ]
        for item in data["items"]:
            page = next(p for p in data["pages"] if p["chamber_text"] == item["chamber_text"])
            assert item["first_grid_header"] == page["items"][item["ordinal"] - 1]
            narrative = next(n for n in data["narratives"] if n["physical_page"] == item["narrative_physical_page"])
            assert item["narrative_printed_page"] == narrative["printed_page"]
            assert (
                item["narrative_title_text"] == narrative["title_text"]
                and item["narrative_citation_text"] == narrative["citation_text"]
            )
            assert narrative["citation_text"] == item["first_grid_header"]["citation_text"]
            assert item["overview_header"] in method["item_headers"]
            assert item["overview_header"]["citation_text"].strip("[] ") == narrative["citation_text"]
        assert data["visible_source_rule"]["glyph_display"] == {
            "source_font": "Wingdings",
            "C": "👍",
            "D": "👎",
            "basis": "Original rendered legend and glyph occurrences; publisher comparison rather than official action",
        }
        assert all(
            isinstance(v, str) and v.strip() for k, v in data["visible_source_rule"].items() if k != "glyph_display"
        )
        assert data["grid_observation_review"] and isinstance(data["observation_differences"], list)
        return data
    except (AssertionError, KeyError, TypeError, ValueError, StopIteration):
        raise ScorecardSourceError(
            "DMI 2007 qualified observations omit or alter the reviewed visible source shape"
        ) from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("Unknown DMI 2007 named edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("DMI 2007 requires pinned private source observations and retention")
    source = context.read(SOURCE_URL, stage="scorecards:drum_major:2007:original", hosts=("web.archive.org",))
    _source(source)
    repeated = context.read(SOURCE_URL, stage="scorecards:drum_major:2007:original-reread", hosts=("web.archive.org",))
    _source(repeated)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="scorecards:drum_major:2007:qualified-visible-source-facts",
    )
    data = _facts(qualified_observations)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=data["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="Complete archived DMI 2007 visible member grids, literal percent/grade columns, publisher thumbs and all native item explanations/method/context; exact native glyphs prevail over refused model readings",
        homepage="http://www.drummajorinstitute.org/",
    )
    groups = ("members", "ratings", "items", "item-results", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")

    def loc(page, path):
        return f"pdf:page={page};observation={observation}{path}"

    def dump(value):
        return json.dumps(value, ensure_ascii=False)

    card = bundle.tables["scorecards"][0]
    card["methodology_url"] = source.url
    card["periods_json"] = dump(
        [
            {
                "occurrence_id": "source-year",
                "kind": "explicit",
                "period_text": data["year_text"],
                "year_text": data["year_text"],
                "source_path": loc(1, "/title"),
            }
        ]
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(21, "/how-this-works"),
        methodology_id="how-this-works",
        methodology_text=dump(
            {
                "native_methodology": data["method"],
                "source_visible_rule": data["visible_source_rule"],
                "original_publisher_url": ORIGINAL_URL,
                "archive_replay_url": SOURCE_URL,
            }
        ),
        methodology_url=source.url,
        disclosure_status="Explicit original missed-vote method, distinct perfect-score grade and chamber/party assessments; no score reproduction",
    )
    for ctx in data["source_contexts"]:
        number = ctx["physical_page"]
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(number, "/native-source-context"),
            methodology_id=f"source-context:{number}",
            methodology_text=dump(ctx),
            methodology_url=source.url,
            disclosure_status="Complete original native explanatory, expert, background, continuation and publisher attribution spans; image-only artwork remains private",
        )
    for page in data["pages"]:
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(page["physical_page"], "/native-grid-context"),
            methodology_id=f"grid-context:{page['physical_page']}",
            chamber_text=page["chamber_text"],
            methodology_text=dump(
                {
                    "physical_page": page["physical_page"],
                    "printed_page": page["printed_page"],
                    "native_grid_context_spans": page["native_grid_context_spans"],
                }
            ),
            methodology_url=source.url,
            disclosure_status="Original repeated header, comparison legend, source range and footer spans",
        )
    for chamber in ("Senate", "House"):
        page = next(p for p in data["pages"] if p["chamber_text"] == chamber)
        for column in ("score", "grade"):
            bundle.add(
                "scorecard_metrics",
                source,
                loc(page["physical_page"], "/" + column + "_column_heading_text"),
                metric_id=key(chamber, column),
                methodology_id="how-this-works",
                name=page[column + "_column_heading_text"],
                chamber_text=chamber,
                period_text=data["year_text"],
                value_unit_text="%" if column == "score" else None,
                is_primary=None,
            )
    for item in data["items"]:
        chamber, ordinal = item["chamber_text"], item["ordinal"]
        identity = key(chamber, str(ordinal))
        pages = [p for p in data["pages"] if p["chamber_text"] == chamber]
        path = loc(pages[0]["physical_page"], f"/items/{ordinal - 1}")
        head = item["first_grid_header"]
        narrative = next(n for n in data["narratives"] if n["physical_page"] == item["narrative_physical_page"])
        refs = [
            {
                "occurrence_id": f"grid:{p['printed_page']}",
                "kind": "amendment" if p["items"][ordinal - 1]["citation_text"].startswith("S.AMDT.") else "bill",
                "citation_text": p["items"][ordinal - 1]["citation_text"],
                "source_path": loc(p["physical_page"], f"/items/{ordinal - 1}/citation_text"),
            }
            for p in pages
        ]
        refs.extend(
            [
                {
                    "occurrence_id": "overview",
                    "kind": "publisher-citation",
                    "citation_text": item["overview_header"]["citation_text"],
                    "source_path": loc(
                        21,
                        f"/item_headers/{item['overview_header']['chamber_text']}/{item['overview_header']['ordinal']}",
                    ),
                },
                {
                    "occurrence_id": "narrative",
                    "kind": "publisher-citation",
                    "citation_text": narrative["citation_text"],
                    "source_path": loc(narrative["physical_page"], "/citation_spans"),
                },
            ]
        )
        citation = head["citation_text"]
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=identity,
            publisher_item_id=str(ordinal),
            item_kind_text="how did the " + chamber.lower() + " vote?",
            title=head["title_text"],
            chamber_text=chamber,
            bill_citation_text=None if citation.startswith("S.AMDT.") else citation,
            amendment_citation_text=citation if citation.startswith("S.AMDT.") else None,
            references_json=dump(refs),
            publisher_position_text=head["preferred_position_text"],
            position_basis="explicit",
            position_source_path=path + "/preferred_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "score"),
            item_id=identity,
            participation_id="source-column",
            methodology_id="how-this-works",
            publisher_position_text=head["preferred_position_text"],
            position_basis="explicit",
            counts_toward_metric="true",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(narrative["physical_page"], "/native-spans"),
            methodology_id="item:" + identity,
            chamber_text=chamber,
            methodology_text=dump(
                {
                    "original_narrative": narrative,
                    "overview_header": item["overview_header"],
                    "grid_header_occurrences": [
                        {
                            "physical_page": p["physical_page"],
                            "printed_page": p["printed_page"],
                            "native_range_heading": p["native_range_heading"],
                            "header": p["items"][ordinal - 1],
                        }
                        for p in pages
                    ],
                }
            ),
            methodology_url=source.url,
            disclosure_status="Complete original explanation, expert context, source event and chamber-assessment spans, issue labels and repeated title/citation spellings; no inferred roll or single action date",
        )
    for page in data["pages"]:
        chamber, number = page["chamber_text"], page["physical_page"]
        for member in page["members"]:
            ordinal = member["ordinal"]
            identity = key(chamber, f"printed-page={page['printed_page']}", f"row={ordinal}")
            path = loc(number, f"/members/{ordinal - 1}")
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=identity,
                member_name=member["member_name_text"],
                state=member["state_text"],
                party=member["party_text"],
                chamber_text=chamber,
                period_text=data["year_text"],
                notes_text=dump(
                    {
                        "native_member_cell_text": member["native_member_cell_text"],
                        "native_cells": member["native_cells"],
                        "native_range_heading": page["native_range_heading"],
                    }
                ),
            )
            for column in ("score", "grade"):
                value = member[column + "_text"]
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    path + "/" + column + "_text",
                    metric_id=key(chamber, column),
                    publisher_member_key=identity,
                    value_text=value,
                    value_number=value[:-1] if column == "score" and re.fullmatch(r"[0-9]+%", value) else None,
                    value_status_text=value if value in ("INC", "INC.") else None,
                )
            for n, glyph in enumerate(member["result_glyph_texts"], 1):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + f"/result_glyph_texts/{n - 1}",
                    result_id="source-cell",
                    item_id=key(chamber, str(n)),
                    publisher_member_key=identity,
                    result_text=glyph,
                )
    return bundle.finish(
        "The exact complete original PDF and stable original reread match reviewed source facts. All original printed members, ordered Wingdings comparison glyphs, percent SCORE and separate GRADE values, repeated headers and complete native method/narrative/context spans reconcile with independent raw paint/text enumeration and original image review. Refused model thumb readings remain private; no publisher scores are reproduced.",
        declared={"source_printed_senate_pages": "20–22", "source_printed_house_pages": "23–35"},
    )
