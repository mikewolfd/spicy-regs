"""Bread for the World's complete publisher PDF as of July 2014.

The source combines missing votes and nonmembership in one NA glyph. Keep that
source meaning together; this reader does not invent official member actions.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "bread-world-113-july-2014-qualified-pdf/1"
URL = "https://www.bread.org/sites/default/files/downloads/congressional-scorecard-booklet-2014-lores.pdf"
HOSTS = ("www.bread.org",)
SOURCE_SHA256 = "5858fa2532f3189fe5f8597c5f0eb19fd510103cde7d8e4fbc116a2e8cfb9d3d"
QUALIFIED_SHA256 = "4041b3a39015116cbde1b8acdfe85a77a9189b790bd7e50dfed73631e196d71a"
EDITION = ScorecardEdition(
    "bread_world",
    "113-as-of-july-2014-pdf",
    URL,
    "Congressional Scorecard",
    congress="113",
    year="2014",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    3: 34,
    4: 34,
    5: 32,
    7: 25,
    8: 35,
    9: 35,
    10: 35,
    11: 35,
    12: 35,
    13: 35,
    14: 35,
    15: 35,
    16: 35,
    17: 35,
    18: 35,
    19: 29,
}
ITEM_PAGES = {"Senate": {1: (1, 2), 2: tuple(range(3, 11))}, "House": {6: tuple(range(1, 12)), 7: (12, 13)}}
PERIOD = "from January 2013 to July 2014"
LEGEND = "+ Voted for the Bread position\n– Voted against the Bread position\nNA not a member or did not vote"
SCALE = (
    "A score of 100% means that the member of Congress voted with all of Bread for the World’s positions. "
    "A vote of 0% means that the member voted with none of Bread for the World’s positions."
)


@dataclass(frozen=True, slots=True)
class BreadWorldReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=URL,
        source_sha256=SOURCE_SHA256,
        message="Bread's qualified July 2014 PDF changed; source requalification required",
    )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:bread_world:listing", hosts=HOSTS)
    _source(source)
    return (EDITION,)


def _facts(data):
    """Refuse incomplete members, result grids, item ordinals or source context."""
    try:
        if (
            data["format_version"] != "bread-world-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 20
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
            or len(data["items"]) != 23
            or [c["physical_page"] for c in data["context_pages"]] != [1, 2, 6, 7, 20]
            or any(not isinstance(c["native_text"], str) or not c["native_text"] for c in data["context_pages"])
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            page, record = entry["physical_page"], entry["record"]
            chamber = "Senate" if page in (3, 4, 5) else "House"
            fields = {"member_name_text", "state_text", "district_text", "party_text", "score_text", "results"}
            item_count = 10 if chamber == "Senate" else 13
            if (
                page not in counts
                or page < previous
                or entry["chamber_text"] != chamber
                or set(record) != fields
                or not isinstance(record["member_name_text"], str)
                or not record["member_name_text"]
                or re.fullmatch(r"[A-Z]{2}", record["state_text"]) is None
                or record["party_text"] not in {"D", "R", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or (chamber == "House" and re.fullmatch(r"\d{2}|AL", record["district_text"] or "") is None)
                or re.fullmatch(r"\d{1,3}%", record["score_text"]) is None
                or int(record["score_text"][:-1]) > 100
                or set(record["results"]) != {str(i) for i in range(1, item_count + 1)}
                or any(v not in {"+", "-", "NA"} for v in record["results"].values())
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if identity in identities or entry["row_ordinal"] != counts[page] + 1:
                raise ValueError
            region = record["state_text"] + ("-" + record["district_text"] if record["district_text"] else "")
            raw = (
                f"{region} {record['member_name_text']} ({record['party_text']}) "
                + " ".join(record["results"][str(i)] for i in range(1, item_count + 1))
                + " "
                + record["score_text"]
            )
            if entry["raw_authored_line"] != raw:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        if counts != PAGE_MEMBERS:
            raise ValueError
        expected = [
            (chamber, page, n) for chamber, pages in ITEM_PAGES.items() for page, nums in pages.items() for n in nums
        ]
        actual = []
        for entry in data["items"]:
            record = entry["record"]
            actual.append((entry["chamber_text"], entry["physical_page"], record["ordinal"]))
            if (
                any(
                    not isinstance(record[f], str) or not record[f]
                    for f in (
                        "title_text",
                        "native_chart_header_text",
                        "native_paragraph_text",
                        "source_narrative_title_text",
                        "publisher_position_text",
                        "outcome_text",
                    )
                )
                or re.fullmatch(
                    r"Bread for the World (?:supported|opposed) (?:this|the) [^.]+\.", record["publisher_position_text"]
                )
                is None
                or not record["bill_citations"]
                or any(not isinstance(v, str) or not v for v in record["bill_citations"])
                or any(re.fullmatch(r"#\d+", v) is None for v in record["amendment_citations"])
            ):
                raise ValueError
        if actual != expected:
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError, AttributeError):
        raise ScorecardSourceError("Bread semantic facts fail the complete qualified source shape") from None


def acquire_scorecard(edition, context: ScorecardContext, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Bread's named July 2014 edition needs reviewed private observations")
    source = context.read(URL, stage="scorecards:bread_world:pdf", hosts=HOSTS)
    _source(source)
    repeated = context.read(URL, stage="scorecards:bread_world:pdf:reread", hosts=HOSTS)
    _source(repeated)
    if source.body != repeated.body:
        raise ScorecardSourceError("Bread PDF changed during the complete source reread")
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="bread_world:qualified-113-july-2014",
    )
    try:
        data = _facts(json.loads(qualified_observations))
    except (ValueError, UnicodeError):
        raise ScorecardSourceError("Bread private observations are not qualified JSON") from None
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Bread for the World",
        parser_version=parser_version,
        rendition_rule="Complete original PDF as of July 2014; current web scorecard and later revisions outside this rendition",
        homepage="https://www.bread.org/",
    )
    bundle.use(source, "members", "ratings", "item-results", "items", "methodology")
    bundle.use(repeated, "members", "ratings", "item-results", "items", "methodology", role="corroboration")
    loc = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    edition_row = bundle.tables["scorecards"][0]
    edition_row.update(
        edition_label_text="How the 113th Congress Voted\nAs of July 2014",
        timespan_text=PERIOD,
        published_at_text="July 2014",
        methodology_url=source.url,
        periods_json=json.dumps(
            [
                {
                    "occurrence_id": "0",
                    "period_text": "113th Congress",
                    "kind": "explicit",
                    "congress_text": "113",
                    "source_path": loc(1, "/period"),
                },
                {
                    "occurrence_id": "1",
                    "period_text": PERIOD,
                    "kind": "explicit",
                    "source_path": loc(1, "/introduction"),
                },
                {
                    "occurrence_id": "2",
                    "period_text": "As of July 2014",
                    "kind": "explicit",
                    "year_text": "2014",
                    "source_path": loc(1, "/title"),
                },
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(1, "/legend-and-introduction"),
        methodology_id="source-method",
        methodology_text=LEGEND + "\n" + SCALE + "\n" + "\n".join(c["native_text"] for c in data["context_pages"]),
        methodology_url=source.url,
        disclosure_status="Source legend, positions, score bounds and report period; no official-action conversion or score reproduction",
    )
    for chamber, page in (("Senate", 3), ("House", 7)):
        bundle.add(
            "scorecard_metrics",
            source,
            loc(page, "/score-column"),
            metric_id=key(chamber, "score"),
            methodology_id="source-method",
            name="Score",
            chamber_text=chamber,
            period_text=PERIOD,
            value_unit_text="percent",
            scale_text=SCALE,
            is_primary="true",
        )
    for i, entry in enumerate(data["items"]):
        record, chamber = entry["record"], entry["chamber_text"]
        item_id = key(chamber, str(record["ordinal"]))
        methodology_id = key("item", chamber, str(record["ordinal"]))
        path = loc(entry["physical_page"], f"/items/{i}/record")
        references = []
        for kind, citations in (("bill", record["bill_citations"]), ("amendment", record["amendment_citations"])):
            for ordinal, citation in enumerate(citations):
                references.append(
                    {
                        "occurrence_id": str(len(references)),
                        "citation_text": citation,
                        "kind": kind,
                        kind + "_citation_text": citation,
                        "source_path": path + f"/{kind}_citations/{ordinal}",
                    }
                )
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item_id,
            publisher_item_id=str(record["ordinal"]),
            item_kind_text="Votes",
            title=record["title_text"],
            chamber_text=chamber,
            congress_text="113",
            bill_citation_text=record["bill_citations"][0],
            amendment_citation_text=record["amendment_citations"][0] if record["amendment_citations"] else None,
            references_json=json.dumps(references, ensure_ascii=False),
            publisher_position_text=record["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id=methodology_id,
            chamber_text=chamber,
            methodology_text=json.dumps(
                {
                    f: record[f]
                    for f in (
                        "native_chart_header_text",
                        "native_paragraph_text",
                        "source_narrative_title_text",
                        "outcome_text",
                    )
                },
                ensure_ascii=False,
            ),
            methodology_url=source.url,
            disclosure_status="Literal source item description, chart heading and outcome",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "score"),
            item_id=item_id,
            participation_id="published-chart",
            publisher_position_text=record["publisher_position_text"],
            position_basis="explicit",
            methodology_id=methodology_id,
        )
    for i, entry in enumerate(data["members"]):
        record, chamber, page = entry["record"], entry["chamber_text"], entry["physical_page"]
        identity = key(
            chamber, record["state_text"], record["district_text"] or "no-district", record["member_name_text"]
        )
        path = loc(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=json.dumps({"raw_authored_line": entry["raw_authored_line"]}, ensure_ascii=False),
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            path + "/score_text",
            metric_id=key(chamber, "score"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "score"),
                participation_id="published-chart",
                publisher_member_key=identity,
                result_id="source-glyph",
                result_text="N/A" if value == "NA" else value,
                reason_text="not a member or did not vote" if value == "NA" else None,
            )
    return bundle.finish(
        "Exact publisher PDF and private observations pins; stable complete PDF reread; every reviewed member page, "
        "all publisher item ordinals, scores, source paragraphs and result cells reconcile. Native NA normalizes to N/A "
        "with its original combined meaning retained; no official roll numbers, member actions or reproduced scores inferred."
    )
