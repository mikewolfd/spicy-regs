"""SMART-TD's named committee assessment; source cohort, not a complete committee roll."""

import json
import re

from bs4 import Comment, Tag

from .common import Bundle, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "smart-td-2023-thud-committee-html/2"
SOURCE_URL = "https://www.smart-union.org/house-budget-votes-place-amtrak-in-the-crosshairs/"
TITLE = "House budget votes place Amtrak in the crosshairs"
HOSTS = ("www.smart-union.org",)
EDITION = ScorecardEdition(
    "smart_transportation", "2023-house-thud-committee", SOURCE_URL, TITLE, chamber="House", is_current=False
)
ARTICLE_PATH = "css:#post-74708"
COLUMN_PATH = ARTICLE_PATH + " .entry-content .wp-block-column:first-child"
FIGURE_PATH = ARTICLE_PATH + " figure.wp-block-table"
COHORT_ASSESSMENT = "These members of the House Appropriations Committee voted against Amtrak and the interests of SMART railroad members."
MEMBER_SYNTAX = re.compile(
    r"(?P<name>(?:Mr\.|Ms\.|Mrs\.|Dr\.) .+?) (?P<party>[A-Z])-(?P<spacing>\s*)(?P<state>[^\d]+?) (?P<district>\d{2})(?P<trailing>\s*)"
)


def list_scorecards(context):
    """Only this reviewed original article is selected; no archive-wide claim."""
    return (EDITION,)


def _one(nodes, message):
    if len(nodes) != 1:
        raise ScorecardSourceError(message)
    return nodes[0]


def _children(node):
    """Keep this article's authored text out of ignored wrapper whitespace."""
    children = []
    for child in node.contents:
        if isinstance(child, Tag):
            children.append(child)
        elif not isinstance(child, Comment) and str(child).strip():
            raise ScorecardSourceError("SMART committee has unconsumed authored text")
    return children


def _named_children(node, names):
    children = _children(node)
    if [child.name for child in children] != names:
        raise ScorecardSourceError("SMART committee has unconsumed authored content")
    return children


def _decoration(node):
    # The original train image has no caption or alternative text. Only this
    # known decorative block is outside the assessment; a new image or label
    # needs review instead of disappearing from acquired facts.
    figure = _named_children(node, ["figure"])[0]
    image = _named_children(figure, ["img"])[0]
    if (
        set(node.attrs) != {"class"}
        or figure.attrs != {"class": ["alignright", "size-full", "is-resized"]}
        or _children(image)
        or image.get("alt") != ""
        or image.get("class") != ["wp-image-44489"]
        or image.get("src")
        != "https://www.smart-union.org/wp-content/uploads/2018/07/Amtrak-Southwest-Chief-@-flagstaff-az.jpg"
        or set(image.attrs) - {"alt", "class", "decoding", "fetchpriority", "height", "sizes", "src", "srcset", "width"}
    ):
        raise ScorecardSourceError("SMART committee decorative image contains unconsumed content")


def _navigation(node):
    # Previous/next post titles are explicitly navigation, not assessment notes.
    # Validate their whole known tree rather than excluding arbitrary divs.
    nav = _named_children(node, ["nav"])[0]
    inner = _named_children(nav, ["div"])[0]
    if (
        set(node.attrs) != {"class"}
        or set(nav.attrs) != {"aria-label", "class", "role"}
        or nav.get("aria-label") != "Post"
        or nav.get("role") != "navigation"
        or "pagination-single" not in nav.get("class", [])
        or inner.attrs != {"class": ["pagination-single-inner"]}
    ):
        raise ScorecardSourceError("SMART committee post navigation contains unconsumed content")
    for link, direction, label in zip(
        _named_children(inner, ["a", "a"]), ("previous", "next"), ("< Previous", "Next >"), strict=True
    ):
        marker, title = _named_children(link, ["span", "span"])
        title_inner = _named_children(title, ["span"])[0]
        if (
            set(link.attrs) != {"class", "href"}
            or direction + "-post" not in link.get("class", [])
            or not str(link.get("href", "")).startswith("https://www.smart-union.org/")
            or set(marker.attrs) != {"aria-hidden", "class"}
            or marker.get("aria-hidden") != "true"
            or marker.find() is not None
            or marker.get_text() != label
            or title.attrs != {"class": ["title", "screen-reader-text"]}
            or title_inner.attrs != {"class": ["title-inner"]}
            or title_inner.find() is not None
            or not title_inner.get_text().strip()
        ):
            raise ScorecardSourceError("SMART committee post navigation contains unconsumed content")


def _authored_column(column, figure):
    ignored = set()
    for child in _children(column):
        if child.name == "p":
            continue  # Every paragraph's complete text is retained below.
        if child is figure:
            _named_children(child, ["table", "figcaption"])
            continue
        classes = child.get("class")
        if child.name == "div" and classes in (["wp-block-image"], ["hidden", "lg:block"]):
            kind = "image" if classes == ["wp-block-image"] else "navigation"
            if kind in ignored:
                raise ScorecardSourceError("SMART committee repeats an unconsumed decorative or navigation block")
            ignored.add(kind)
            (_decoration if kind == "image" else _navigation)(child)
            continue
        raise ScorecardSourceError("SMART committee has unconsumed authored column content")


def _facts(document):
    if document.url != SOURCE_URL:
        raise ScorecardSourceError("SMART committee source resolved to a different original article")
    if document.response.content_type.split(";", 1)[0].strip().lower() != "text/html":
        raise ScorecardSourceError("SMART committee source is not original HTML")
    try:
        raw = document.body.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ScorecardSourceError("SMART committee original is not UTF-8") from error
    if not re.search(r"</body>\s*</html>(?:\s*<!--.*?-->)*\s*$", raw, re.DOTALL | re.IGNORECASE):
        raise ScorecardSourceError("SMART committee source does not reach HTML EOF")
    # Check this publisher's observed authored grammar before BeautifulSoup can
    # repair a cut or mismatched table into a plausible complete roster.
    raw_tables = re.findall(r"<table>.*?</table>", raw, re.DOTALL)
    cell = r"<td><strong>[^<>]+</strong></td>"
    if len(raw_tables) != 1 or not re.fullmatch(
        r"<table><tbody>(?:<tr>" + cell + cell + r"</tr>){17}</tbody></table>", raw_tables[0]
    ):
        raise ScorecardSourceError("SMART committee authored table is incomplete or its grammar changed")
    html = soup(document)
    if _one(html.select('link[rel="canonical"]'), "SMART committee canonical link changed").get("href") != SOURCE_URL:
        raise ScorecardSourceError("SMART committee canonical link selects a different article")
    if html.title is None or html.title.get_text() != TITLE + " - SMART Union":
        raise ScorecardSourceError("SMART committee original title changed")
    article = _one(html.select("article#post-74708"), "SMART committee article is absent or repeated")
    if _one(article.select("h1.entry-title"), "SMART committee article heading changed").get_text() != TITLE:
        raise ScorecardSourceError("SMART committee article heading selects a different original")
    published = _one(article.select(":scope > p.font-light"), "SMART committee publication label is absent").get_text()
    if published != "July 24, 2023":
        raise ScorecardSourceError("SMART committee publication label selects a different period")
    metadata = {}
    for name in ("published_time", "modified_time"):
        node = _one(html.select(f'meta[property="article:{name}"]'), "SMART committee publication metadata changed")
        value = node.get("content")
        if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00", value):
            raise ScorecardSourceError("SMART committee publication metadata is incomplete")
        metadata[name] = value
    if not metadata["published_time"].startswith("2023-07-24T"):
        raise ScorecardSourceError("SMART committee original publication metadata contradicts its label")
    content = _one(article.select(".entry-content"), "SMART committee content is absent or repeated")
    column = _one(
        [node for node in content.select(".wp-block-column") if node.select("table")],
        "SMART committee member column changed",
    )
    paragraphs = [node.get_text() for node in column.find_all("p", recursive=False)]
    if len(paragraphs) != 12 or any(not text.strip() for text in paragraphs):
        raise ScorecardSourceError("SMART committee explanatory paragraphs are incomplete")
    # These statements establish the assessment's meaning. All paragraph text is
    # retained below; fiscal-year references are not a fabricated score period.
    if not paragraphs[0].startswith("While Infrastructure Investment and Jobs Act (IIJA)") or not all(
        phrase in paragraphs[index]
        for index, phrase in (
            (0, "U.S. House Appropriations Transportation, Housing and Urban Development"),
            (1, "proposed 2024 budget spending bill"),
            (6, "SMART-TD is not in the business of endorsing one political party or the other."),
            (7, "voice vote"),
            (8, "Tuesday, July 18th, the full House Appropriations Committee took a vote on the THUD budget"),
            (9, "SMART-TD’s National Legislative Department"),
            (9, "an accurate scorecard of the Appropriations vote"),
            (11, "With intervention from our SMART-TD membership"),
        )
    ):
        raise ScorecardSourceError("SMART committee assessment or source selection changed")
    tally = re.findall(r"breakdown of the (\d+)-(\d+) vote", paragraphs[9])
    if tally != [("34", "27")]:
        raise ScorecardSourceError("SMART committee source-reported vote tally changed")
    figure = _one(column.select("figure.wp-block-table"), "SMART committee table is absent or repeated")
    _authored_column(column, figure)
    caption = _one(figure.select("figcaption"), "SMART committee cohort assessment is absent").get_text()
    if caption != COHORT_ASSESSMENT:
        raise ScorecardSourceError("SMART committee table assessment changed")
    table = _one(figure.select("table"), "SMART committee table count changed")
    if len(content.select("table")) != 1 or table.select("thead, th, tfoot"):
        raise ScorecardSourceError("SMART committee table shape changed")
    tbody = _one(table.select(":scope > tbody"), "SMART committee authored table body changed")
    rows = tbody.find_all("tr", recursive=False)
    if len(rows) != 17 or len(table.select("tr")) != len(rows):
        raise ScorecardSourceError("SMART committee authored member rows are incomplete")
    members = []
    for row_number, row in enumerate(rows, 1):
        cells = row.find_all("td", recursive=False)
        if len(cells) != 2 or len(row.select("td")) != 2:
            raise ScorecardSourceError("SMART committee member row no longer has two source cells")
        for column_number, cell in enumerate(cells, 1):
            strong = _one(cell.select(":scope > strong"), "SMART committee member syntax changed")
            text = strong.get_text()
            match = MEMBER_SYNTAX.fullmatch(text)
            if match is None or cell.get_text() != text or strong.find() is not None or cell.attrs:
                raise ScorecardSourceError("SMART committee member cell is incomplete or introduces unreviewed data")
            members.append(
                {
                    "row": row_number,
                    "column": column_number,
                    "native_text": text,
                    "name": match["name"],
                    "party": match["party"],
                    "state": match["state"],
                    "district": match["district"],
                }
            )
    if (
        len(table.select("td")) != len(members)
        or len(members) != 34
        or len({member["native_text"] for member in members}) != 34
    ):
        raise ScorecardSourceError("SMART committee source cohort is incomplete or repeats a cell")
    return {
        "title": TITLE,
        "published_label": published,
        "metadata": metadata,
        "paragraphs": paragraphs,
        "tally": "34-27",
        "caption": caption,
        "members": members,
    }


def acquire_scorecard(edition, context):
    if edition != EDITION:
        raise ScorecardSourceError("SMART committee reader only supports its named original article")
    source = context.read(SOURCE_URL, stage="scorecards:smart-td:committee", hosts=HOSTS)
    facts = _facts(source)
    repeated = context.read(SOURCE_URL, stage="scorecards:smart-td:committee-repeat", hosts=HOSTS)
    if _facts(repeated) != facts:
        raise ScorecardSourceError("SMART committee native fields changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="SMART-TD",
        parser_version=parser_version,
        rendition_rule="Named original SMART-TD article: only the complete published 34-member assessed cohort; other committee members and annual ratings are outside this rendition",
        homepage="https://www.smart-union.org/",
    )
    groups = ("members", "items", "item-results", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")
    card = bundle.tables["scorecards"][0]
    card.update(
        publisher_edition_key="74708",
        edition_label_text=facts["title"],
        published_at_text=facts["published_label"],
        updated_at_text=facts["metadata"]["modified_time"],
        source_path=ARTICLE_PATH,
    )
    bundle.tables["scorecard_publishers"][0].update(
        abbreviation="SMART-TD", source_path=COLUMN_PATH + " > p:nth-of-type(10)"
    )
    for ordinal, paragraph in enumerate(facts["paragraphs"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            COLUMN_PATH + f" > p:nth-of-type({ordinal + 1})",
            methodology_id=key("paragraph", str(ordinal)),
            methodology_text=paragraph,
            methodology_url=source.url,
        )
    bundle.add(
        "scorecard_methodologies",
        source,
        'css:meta[property^="article:"]',
        methodology_id="publication-metadata",
        methodology_text=json.dumps(facts["metadata"], ensure_ascii=False),
        methodology_url=source.url,
    )
    caption_path = FIGURE_PATH + " > figcaption"
    bundle.add(
        "scorecard_methodologies",
        source,
        caption_path,
        methodology_id="cohort-assessment",
        methodology_text=facts["caption"],
        methodology_url=source.url,
    )
    item_id = "committee-assessment"
    bundle.add(
        "scorecard_items",
        source,
        COLUMN_PATH,
        item_id=item_id,
        item_kind_text="Appropriations vote",
        title="THUD budget",
        item_date_text="Tuesday, July 18th",
        chamber_text="House",
        references_json="[]",
    )
    for member in facts["members"]:
        identity = key("row", str(member["row"]), "column", str(member["column"]))
        path = (
            FIGURE_PATH
            + f" > table > tbody > tr:nth-child({member['row']}) > td:nth-child({member['column']}) > strong"
        )
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=member["name"],
            state=member["state"],
            district=member["district"],
            party=member["party"],
            chamber_text="House",
            identifiers_json="[]",
            notes_text=json.dumps({"native_member_cell": member["native_text"]}, ensure_ascii=False),
        )
        bundle.add(
            "scorecard_member_item_results",
            source,
            caption_path,
            publisher_member_key=identity,
            item_id=item_id,
            result_id="collective-assessment",
            result_text=facts["caption"],
        )
    return bundle.finish(
        "Original HTML reaches EOF; the reviewed 17×2 authored member table and its collective caption are complete; every selected paragraph, publication field and native member cell agrees with a fresh reread. Only the publisher's assessed cohort is included; no aggregate rating, official identity or omitted committee action is invented.",
        declared={"reported_committee_vote_tally_text": facts["tally"]},
    )
