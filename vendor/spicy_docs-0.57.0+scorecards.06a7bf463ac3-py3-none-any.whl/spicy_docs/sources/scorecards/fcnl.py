"""FCNL's publisher-selected public action sheets, without invented aggregate ratings."""

import json
import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import quorum_public
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    _invalid_json_constant,
    _unique_json_fields,
    key,
)

parser_version = "fcnl-selected-public-quorum-actions/1"
INDEX = "https://www.fcnl.org/congress"
HOSTS = ("www.fcnl.org", "fcnl.quorum.us")
PUBLISHER = "Friends Committee on National Legislation"
ORGANIZATION_ID = 1685
EDITION = ScorecardEdition(
    "fcnl",
    "2026-war-powers-current-roster",
    INDEX,
    "Advocacy Teams 2026 Campaign Policy Tracker",
    year="2026",
    chamber="both",
)
HISTORICAL = ScorecardEdition(
    "fcnl",
    "118-votes-current-roster",
    INDEX,
    "Senate Votes: 118th Congress / House Votes: 118th Congress",
    congress="118",
    chamber="both",
    is_current=False,
)
# Page, sheet and slug identities are the original publisher's selections.
SELECTIONS = {
    EDITION.edition_id: (
        ("Senate", 11668, "/at-2026-tracker/", 157431, "NhDVdXjeEeQBmhXgPdbP", "AT Senate War Powers Tracker"),
        ("House", 11668, "/at-2026-tracker/", 157436, "JqfYAgLYzSclDjrzUnFk", "AT House War Powers Tracker"),
    ),
    HISTORICAL.edition_id: (
        ("Senate", 1924, "/senatevotes/", 80658, "TFtijIQLGIeOIWdLHfIg", "Senate Votes: 118th Congress"),
        ("House", 1866, "/housevotes/", 80655, "SNrlQnBJpWtyMUbpFrrQ", "House Votes: 118th Congress"),
    ),
}
LABELS = {
    "voting_record": {1: "Yea", 2: "Nay", 4: "Missed"},
    "stance_record": {1: "Support", 2: "Oppose", 6: "Missed", 8: "Delegate"},
    "sponsorship_record": {1: "Primary Sponsor", 2: "Original Cosponsor"},
}
BILL = re.compile(r"(?<!\w)(?:H\.?\s*Con\.?\s*Res\.?|H\.?\s*R\.?|S\.?\s*J\.?\s*Res\.?|S\.?)\s*\d+(?!\w)")
CONGRESS = re.compile(r"\((\d+)(?:th|st|nd|rd)\)")


def _embedded(document, name):
    try:
        text = document.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("FCNL publisher page is not UTF-8") from None
    pattern = r"window\." + name + r'\s*=\s*JSON.parse\(("(?:[^"\\]|\\.)*")\)'
    matches = re.findall(pattern, text)
    if len(matches) != 1:
        raise ScorecardSourceError("FCNL publisher configuration is missing or repeats its literal assignment")
    try:
        encoded = json.loads(matches[0])
        return json.loads(
            encoded, object_pairs_hook=_unique_json_fields, parse_constant=_invalid_json_constant, parse_float=str
        )
    except (ValueError, UnicodeError):
        raise ScorecardSourceError("FCNL publisher JSON string is incomplete or nonliteral") from None


def _index(document, edition):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("FCNL publisher page does not reach HTML EOF")
    organization, pages = _embedded(document, "organization"), _embedded(document, "pages")
    if (
        not isinstance(organization, dict)
        or organization.get("id") != ORGANIZATION_ID
        or organization.get("name") != PUBLISHER
        or not isinstance(pages, list)
        or any(not isinstance(p, dict) or type(p.get("id")) is not int for p in pages)
        or len({p["id"] for p in pages}) != len(pages)
    ):
        raise ScorecardSourceError("FCNL publisher identity or page population changed")
    selected = {}
    for chamber, page_id, path, sheet_id, slug, _ in SELECTIONS[edition.edition_id]:
        page = next((p for p in pages if p["id"] == page_id), None)
        if (
            page is None
            or page.get("archived") is not False
            or page.get("requires_login") is not False
            or page.get("can_access") is not True
            or page.get("path") != path
            or page.get("action_center") != 1311
            or not isinstance(page.get("widgets"), list)
            or any(not isinstance(w, dict) or not isinstance(w.get("props"), dict) for w in page["widgets"])
            or page.get("custom_javascript") != ""
            or page.get("custom_css") != ""
        ):
            raise ScorecardSourceError("FCNL selected page identity, visibility or execution shape changed")
        if page["name"] != (EDITION.title if edition == EDITION else chamber + " Votes"):
            raise ScorecardSourceError("FCNL selected page period or chamber label changed")
        sheets = [w.get("props", {}).get("sheet") for w in page["widgets"] if w.get("widgetType") == 14]
        expected = [
            {"id": s, "public_slug": token}
            for _, pid, _, s, token, _ in SELECTIONS[edition.edition_id]
            if pid == page_id
        ]
        if sheets != expected:
            raise ScorecardSourceError("FCNL selected page no longer declares exactly its reviewed sheet set")
        if any(w.get("widgetType") not in {4, 14} or not isinstance(w.get("props"), dict) for w in page["widgets"]):
            raise ScorecardSourceError("FCNL selected page introduced an unreviewed widget shape")
        selected[chamber] = (page, f"window.pages[{pages.index(page)}]")
    return organization, selected


def list_scorecards(context: ScorecardContext):
    document = context.read(INDEX, stage="fcnl:publisher:list", hosts=HOSTS)
    for edition in (EDITION, HISTORICAL):
        _index(document, edition)
    return EDITION, HISTORICAL


def _review(sheet, selection):
    chamber, _, _, sheet_id, _, name = selection
    data = sheet.data
    if (sheet.json_document.response.content_type or "").split(";", 1)[0].lower() != "application/json" or (
        sheet.csv_document.response.content_type or ""
    ).split(";", 1)[0].lower() != "text/csv":
        raise ScorecardSourceError("FCNL original public JSON/CSV media types changed")
    if data["id"] != sheet_id or data["name"] != name or data.get("organization") != "/api/organization/1685/":
        raise ScorecardSourceError("FCNL sheet ownership, title or native identity changed")
    contexts = [c for c in sheet.columns if c.get("column_type") in {"field", "district"}]
    items = [c for c in sheet.columns if c.get("column_type") in LABELS]
    if (
        len(contexts) != 1
        or not items
        or len(contexts) + len(items) != len(sheet.columns)
        or any(c["should_hide_column_on_public"] for c in sheet.columns)
        or not data.get("show_datum_column")
        or not isinstance(data["rows"].get("filters"), list)
    ):
        raise ScorecardSourceError("FCNL complete displayed context/action column or roster filter shape changed")
    field = contexts[0]
    if chamber == "Senate":
        valid = field["column_type"] == "field" and field.get("field") == "most_recent_state__abbrev"
        valid = valid and field["name"] in {"State", "State Abbreviation"}
    else:
        valid = field["column_type"] == "district" and field["name"] == "District"
    if not valid:
        raise ScorecardSourceError("FCNL displayed State/District source syntax changed")
    return field, items


def _member(member, sheet, row, chamber, field, visible):
    display = re.search(r"\(([A-Za-z]+)-([A-Z]{2})(?:-([0-9]+))?\)$", member["name"])
    if display is None or (chamber == "Senate") != (display[3] is None):
        raise ScorecardSourceError("FCNL literal display-party/state/district context changed")
    value = row[visible[field["id"]]]
    cache = field["data"].get(str(member["id"]))
    if value != cache:
        raise ScorecardSourceError("FCNL native context cache differs from its displayed CSV field")
    if chamber == "Senate":
        if not re.fullmatch(r"[A-Z]{2}", value):
            raise ScorecardSourceError("FCNL displayed state syntax changed")
        state, district = value, None
    else:
        match = re.fullmatch(r"([A-Z]{2})-([0-9]+)", value)
        if match is None:
            raise ScorecardSourceError("FCNL displayed District syntax changed")
        state, district = match.groups()
    # The standalone exported field supplies native typed state/district. Display
    # parentheses have seven original 1/0 conflicts; both occurrences survive.
    return (
        state,
        district,
        display[1],
        {
            "source_record": member,
            "csv_fields": dict(zip(sheet.header, row, strict=True)),
            "display_context": {"party": display[1], "state": display[2], "district": display[3]},
            "standalone_context": {"column_id": field["id"], "literal_value": value, "cache_value": cache},
        },
    )


def _item_references(column, path, chamber, congress_context=None):
    congresses = CONGRESS.findall(column["name"])
    congress = congresses[0] if len(congresses) == 1 else congress_context
    citations = list(BILL.finditer(column["name"]))
    references = [
        {
            "occurrence_id": "title-citation:" + str(n + 1),
            "citation_text": m[0],
            "kind": "bill",
            "source_path": path + f".name/characters[{m.start()}:{m.end()}]",
            "bill_citation_text": m[0],
            "congress_text": congress,
            "chamber_text": chamber,
        }
        for n, m in enumerate(citations)
    ]
    field = "bill_id" if column["column_type"] == "sponsorship_record" else "vote_id"
    value = column.get(field)
    if type(value) is not int or value < 1:
        raise ScorecardSourceError("FCNL source action lacks its reviewed native bill/vote identity")
    references.append(
        {
            "occurrence_id": "quorum:" + field,
            "citation_text": str(value),
            "kind": "quorum_" + field.removesuffix("_id"),
            "source_path": path + "." + field,
            "chamber_text": chamber,
        }
    )
    return congress, citations[0][0] if len(citations) == 1 else None, references, str(value)


def _narratives(page, page_path):
    """Retain all original introduction occurrences; do not reconcile 83 against 93."""
    result = []
    for index, widget in enumerate(page["widgets"]):
        if widget["widgetType"] != 4:
            continue
        content = widget["props"].get("content")
        if not isinstance(content, str) or not content:
            raise ScorecardSourceError("FCNL selected introduction is missing its authored content")
        # The complete literal page remains in methodology; these additional
        # source occurrences make every authored list item and href inspectable.
        from bs4 import BeautifulSoup

        tree = BeautifulSoup(content, "html.parser")
        path = page_path + f".widgets[{index}].props.content"
        result.append(
            {
                "source_path": path,
                "html": content,
                "title": widget["props"].get("title"),
                "text": tree.get_text(" ", strip=True),
                "list_items": [
                    {"source_path": path + f"/li[{n + 1}]", "text": li.get_text(" ", strip=True), "html": str(li)}
                    for n, li in enumerate(tree.select("li"))
                ],
                "links": [
                    {"source_path": path + f"/a[{n + 1}]", "href": a["href"], "text": a.get_text(" ", strip=True)}
                    for n, a in enumerate(tree.select("a[href]"))
                ],
            }
        )
    return result


def _linked_references(narratives, column, chamber, document):
    """Link only exact publisher item labels; differing 83/93 remain separate."""
    from bs4 import BeautifulSoup

    references = []
    for narrative in narratives:
        for occurrence in narrative["list_items"]:
            text = occurrence["text"].lstrip("\ufeff ")
            if not text.startswith(column["name"] + ":"):
                continue
            tree = BeautifulSoup(occurrence["html"], "html.parser")
            for n, anchor in enumerate(tree.select("a[href]"), 1):
                href = str(anchor["href"])
                reference = {
                    "occurrence_id": "publisher-link:" + str(len(references) + 1),
                    "citation_text": href,
                    "kind": "url",
                    "source_path": "capture:"
                    + document.capture_id
                    + "#"
                    + occurrence["source_path"]
                    + f"/a[{n}]/@href",
                    "chamber_text": chamber,
                }
                senate = re.fullmatch(
                    r"https://www\.senate\.gov/legislative/LIS/roll_call_votes/vote([0-9]+)([12])/vote_([0-9]+)_([12])_([0-9]+)\.htm",
                    href,
                )
                house = re.fullmatch(r"https://www\.congress\.gov/votes/house/([0-9]+)-([12])/([0-9]+)", href)
                if senate and senate.group(1, 2) == senate.group(3, 4):
                    reference.update(
                        kind="roll_call_url",
                        congress_text=senate[3],
                        session_text=senate[4],
                        roll_number_text=senate[5],
                    )
                elif house:
                    reference.update(
                        kind="roll_call_url", congress_text=house[1], session_text=house[2], roll_number_text=house[3]
                    )
                references.append(reference)
    return references


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition not in (EDITION, HISTORICAL):
        raise ScorecardSourceError("FCNL supports only the reviewed named campaign/118th selected-action renditions")
    document = context.read(INDEX, stage="fcnl:publisher", hosts=HOSTS)
    organization, selected = _index(document, edition)
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name=PUBLISHER,
        parser_version=parser_version,
        rendition_rule="explicit publisher pages and public sheet IDs; standalone exported context wins only typed context while conflicting display occurrences remain literal; current filtered rosters distinct from item periods; no aggregate ratings or inferred source targets; complete native cache/CSV and stable full selected reread",
        homepage="https://www.fcnl.org/",
    )
    bundle.tables["scorecard_publishers"][0].update(abbreviation="FCNL", source_path="window.organization")
    periods, counts = [], {}
    seen_pages, sheets, narratives_by_page = set(), [], {}
    for selection in SELECTIONS[edition.edition_id]:
        chamber, page_id, _, _, slug, _ = selection
        page, page_path = selected[chamber]
        if page_id not in seen_pages:
            seen_pages.add(page_id)
            narratives_by_page[page_id] = _narratives(page, page_path)
            bundle.add(
                "scorecard_methodologies",
                document,
                page_path,
                methodology_id=key("publisher-page", str(page_id)),
                methodology_text=json_column(
                    {
                        "organization": organization,
                        "selected_page": page,
                        "narrative_occurrences": narratives_by_page[page_id],
                    }
                ),
                disclosure_status="partial",
            )
        sheet = quorum_public.acquire(context, slug, "fcnl:" + chamber.lower())
        field, items = _review(sheet, selection)
        sheets.append((selection, sheet))
        source = sheet.json_document
        bundle.use(source, chamber + ":sheet-cache")
        bundle.use(sheet.csv_document, chamber + ":displayed-cells")
        bundle.add(
            "scorecard_methodologies",
            source,
            "$",
            methodology_id=key(chamber, "native-sheet"),
            chamber_text=chamber,
            methodology_text=json_column({k: v for k, v in sheet.data.items() if k not in {"columns", "row_data"}}),
            disclosure_status="partial",
        )
        periods.append(
            {
                "occurrence_id": chamber + ":sheet-label",
                "period_text": sheet.data["name"],
                "kind": "explicit",
                "source_path": "capture:" + source.capture_id + "#$.name",
                "chamber_text": chamber,
                "congress_text": "118" if edition == HISTORICAL else None,
            }
        )
        visible = {c["id"]: n for n, c in enumerate(sheet.columns, 1)}
        positions = {c["id"]: n for n, c in enumerate(sheet.data["columns"])}
        roster_ids = {str(m["id"]) for m in sheet.data["row_data"]}
        for column in sheet.columns:
            path = f"$.columns[{positions[column['id']]}]"
            bundle.add(
                "scorecard_methodologies",
                source,
                path,
                methodology_id=key(chamber, "column", str(column["id"])),
                chamber_text=chamber,
                methodology_text=json_column(quorum_public.column_metadata(column, roster_ids)),
                disclosure_status="partial",
            )
            if column not in items:
                continue
            congress, bill, references, native_id = _item_references(
                column, path, chamber, "118" if edition == HISTORICAL else None
            )
            references.extend(_linked_references(narratives_by_page[page_id], column, chamber, document))
            rolls = {
                (r["session_text"], r["roll_number_text"])
                for r in references
                if r["kind"] == "roll_call_url" and r.get("congress_text") == congress
            }
            session, roll = next(iter(rolls)) if len(rolls) == 1 else (None, None)
            bundle.add(
                "scorecard_items",
                source,
                path,
                item_id=key(chamber, str(sheet.data["id"]), str(column["id"])),
                publisher_item_id=native_id,
                item_kind_text=column["column_type"],
                title=column["name"],
                chamber_text=chamber,
                congress_text=congress,
                bill_citation_text=bill,
                session_text=session,
                roll_number_text=roll,
                position_basis="absent",
                references_json=json_column(references),
            )

        for n, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True)):
            identifier = str(member["id"])
            member_key = key(chamber, identifier)
            state, district, party, notes = _member(member, sheet, row, chamber, field, visible)
            bundle.add(
                "scorecard_members",
                source,
                f"$.row_data[{n}]",
                publisher_member_key=member_key,
                publisher_member_id=identifier,
                identifiers_json=json_column([{"scheme": "quorum", "value": identifier}]),
                member_name=member["firstname"] + " " + member["lastname"],
                chamber_text=chamber,
                state=state,
                district=district,
                party=party,
                notes_text=json_column(notes),
            )
            for column in items:
                present = identifier in column["data"]
                native = column["data"].get(identifier)
                value = row[visible[column["id"]]]
                if native is None:
                    valid = value == ""
                else:
                    valid = type(native) is int and LABELS[column["column_type"]].get(native) == value
                if not valid:
                    raise ScorecardSourceError("FCNL displayed action differs from the reviewed native enum cache")
                bundle.add(
                    "scorecard_member_item_results",
                    sheet.csv_document,
                    f"CSV/row={n + 2}/column={visible[column['id']] + 1};cache=capture:{source.capture_id}#$.columns[{positions[column['id']]}].data[{json.dumps(identifier)}]",
                    result_id="displayed-cell",
                    item_id=key(chamber, str(sheet.data["id"]), str(column["id"])),
                    publisher_member_key=member_key,
                    result_text=value,
                    reason_text=json_column(
                        {
                            "cache_present": present,
                            "cache_value": native,
                            "cache_source_path": f"$.columns[{positions[column['id']]}].data[{json.dumps(identifier)}]",
                            "csv_value_text": value,
                        }
                    ),
                )
        counts[chamber] = {"source_row_count": sheet.data["row_count"]}
    bundle.tables["scorecards"][0].update(
        edition_label_text=edition.title, periods_json=json_column(periods), source_path="window.pages"
    )
    repeated = context.read(INDEX, stage="fcnl:publisher:reread", hosts=HOSTS)
    if _index(repeated, edition) != (organization, selected):
        raise ScorecardSourceError(
            "FCNL publisher identity, selected page, notes or sheet selection changed during acquisition"
        )
    bundle.use(repeated, role="corroboration")
    for selection, sheet in sheets:
        chamber, _, _, _, slug, _ = selection
        repeat = quorum_public.acquire(context, slug, "fcnl:" + chamber.lower() + ":reread")
        _review(repeat, selection)
        if quorum_public.semantic_facts(repeat) != quorum_public.semantic_facts(sheet):
            raise ScorecardSourceError("FCNL complete selected sheet/cache/export facts changed during acquisition")
        bundle.use(repeat.json_document, role="corroboration")
        bundle.use(repeat.csv_document, role="corroboration")
    return bundle.finish(
        "Every selected native sheet column and current filtered member occurrence reconciles to the complete JSON row_count, visible CSV header/order/EOF and literal cache labels; every displayed action cell including blanks retained; complete source facts stable reread, timestamps retained but not used as rating facts",
        declared=counts,
    )
