"""BIPAC's requested Momentum vote-catalogue observation, never an empty scorecard."""

from spicy_docs.sources.scorecards.common import ScorecardContext, ScorecardSourceError, json_data

parser_version = "bipac-momentum-availability/1"
CATALOG = "https://admin.mplatform.io/api/v1/bipac/vr/bills?withDetail=true"
HOSTS = ("admin.mplatform.io",)


class BIPACOriginalUnrecovered(ScorecardSourceError):
    """The exact public request recovered no edition; prior rows remain valid."""


def availability(context: ScorecardContext):
    document = context.read(CATALOG, stage="bipac-momentum:requested-catalogue", hosts=HOSTS)
    if document.url != CATALOG or (document.response.content_type or "").split(";", 1)[0] != "application/json":
        raise ScorecardSourceError("BIPAC native catalogue route or JSON media type changed")
    rows = json_data(document)
    if rows != []:
        raise ScorecardSourceError(
            "BIPAC catalogue changed to an unsupported shape; qualify the original before replacing rows"
        )
    raise BIPACOriginalUnrecovered(
        "BIPAC's exact anonymous public vote-catalogue request returned []; no rating edition "
        "was recovered. This does not establish historical absence, retirement, or member-portal "
        "coverage. Preserve prior rows."
    )


def list_scorecards(context: ScorecardContext):
    return availability(context)


def acquire_scorecard(edition, context: ScorecardContext):
    raise ScorecardSourceError("BIPAC has no qualified original edition to acquire; preserve prior rows")
