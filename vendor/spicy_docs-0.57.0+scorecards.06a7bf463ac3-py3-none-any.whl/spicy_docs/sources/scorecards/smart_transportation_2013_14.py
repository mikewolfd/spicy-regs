"""SMART-TD's separately qualified original House and Senate 2013–14 PDF grids."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "smart-td-2013-14-qualified-original-pdf/1"
ORIGINAL_ROOT = "http://utu.org/worksite/washington/PDFs/"
FILENAMES = {
    "House": "SMART_Transportation_Scorecard_House_2013-14_(PRINT).pdf",
    "Senate": "SMART_Transportation_Scorecard_US_Senate_2013-14_(PRINT).pdf",
}
SOURCE_URLS = {
    "House": "https://web.archive.org/web/20150504132237id_/" + ORIGINAL_ROOT + FILENAMES["House"],
    "Senate": "https://web.archive.org/web/20150504132238id_/" + ORIGINAL_ROOT + FILENAMES["Senate"],
}
SOURCE_SHA256 = {
    "House": "a92c226eedcb278d49ecd73aecf545c45a105377d7c735fd43b8d995359de546",
    "Senate": "182c884dd32fadfaeb136b7d2a62d53e8162b9320bd865c2af81fc9525b703bf",
}
QUALIFIED_SHA256 = {
    "House": "c81e2f7e7da7996207d3d508aed6770fbbe5ec03601fa42437e7d3e45ba862ca",
    "Senate": "c689b6035eac7b6624b28f4323731e2603477e20fc6ca0776b019cb5a0f87929",
}
PAGE_COUNTS = {
    "House": {
        1: 25,
        2: 31,
        3: 31,
        4: 31,
        5: 31,
        6: 30,
        7: 31,
        8: 31,
        9: 30,
        10: 31,
        11: 31,
        12: 31,
        13: 31,
        14: 31,
        15: 9,
    },
    "Senate": {1: 25, 2: 29, 3: 29, 4: 17},
}
ROLL_HEADERS = {
    "House": [
        "RCV 23",
        "RCV 101",
        "RCV 137",
        "RCV 191",
        "RCV 418",
        "RCV 550",
        "RCV 177",
        "RCV 273",
        "RCV 288",
        "RCV 294",
        "RCV 295",
    ],
    "Senate": ["RCV 4", "RCV 123", "RCV 177", "RCV 178", "RCV 181", "RCV 219", "RCV 246", "RCV 248"],
}
PERIOD_HEADERS = {
    "House": ["113th Congress, Session 1 (2013)", "113th Congress, Session 2 (2014)"],
    "Senate": ["113th Congress, Session 1 (2013)", "Session 2 (2014)"],
}
SCORE_HEADERS = ["113th Congress Score", "2011 to Current"]
RECORD_FIELDS = {
    "state_text",
    "district_text",
    "member_name_text",
    "party_text",
    "roll_result_cells",
    "cosponsorship_cell_text",
    "congress_score_text",
    "since_2011_score_text",
    "notes_text",
}
EDITIONS = {
    chamber: ScorecardEdition(
        "smart_transportation",
        "2013-14-" + chamber.lower() + "-original-pdf",
        SOURCE_URLS[chamber],
        "SMART Transportation Division",
        congress="113",
        chamber=chamber,
        is_current=False,
    )
    for chamber in FILENAMES
}


@dataclass(frozen=True, slots=True)
class SMARTTransportationHouse201314Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return _list_chamber("House", context)

    def acquire_scorecard(self, edition, context):
        if edition != EDITIONS["House"]:
            raise ScorecardSourceError("Unknown SMART-TD House PDF edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


@dataclass(frozen=True, slots=True)
class SMARTTransportationSenate201314Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return _list_chamber("Senate", context)

    def acquire_scorecard(self, edition, context):
        if edition != EDITIONS["Senate"]:
            raise ScorecardSourceError("Unknown SMART-TD Senate PDF edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document, chamber):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URLS[chamber],
        source_sha256=SOURCE_SHA256[chamber],
        message="SMART-TD original PDF differs from its reviewed complete chamber rendition",
    )


def _list_chamber(chamber, context):
    document = context.read(
        SOURCE_URLS[chamber],
        stage="scorecards:smart-td:" + chamber.lower() + ":named-edition",
        hosts=("web.archive.org",),
    )
    _source(document, chamber)
    return [EDITIONS[chamber]]


def list_scorecards(context):
    return [edition for chamber in EDITIONS for edition in _list_chamber(chamber, context)]


def _facts(body, chamber):
    try:
        data = json.loads(body)
        assert data["format_version"] == "smart-td-2013-14-qualified-source-facts/1"
        assert data["source_sha256"] == SOURCE_SHA256[chamber] and data["chamber_text"] == chamber
        assert data["source_page_count"] == (15 if chamber == "House" else 6)
        assert data["publisher_name_text"] == "SMART Transportation Division"
        assert data["header_period_texts"] == PERIOD_HEADERS[chamber] and data["score_header_texts"] == SCORE_HEADERS
        assert {int(p): n for p, n in data["grid_page_counts"].items()} == PAGE_COUNTS[chamber]
        assert Counter(m["physical_page"] for m in data["members"]) == Counter(PAGE_COUNTS[chamber])
        assert [m["physical_page"] for m in data["members"]] == sorted(m["physical_page"] for m in data["members"])
        counts, glyphs, cosponsors = Counter(), Counter(), Counter()
        for m in data["members"]:
            page, row = m["physical_page"], m["record"]
            counts[page] += 1
            assert m["row_ordinal"] == counts[page] and set(row) == RECORD_FIELDS
            assert all(isinstance(v, str) for k, v in row.items() if k != "roll_result_cells")
            assert re.fullmatch(r"[A-Z]{2}", row["state_text"]) and row["member_name_text"].strip()
            assert row["party_text"] in (("R", "D", "") if chamber == "House" else ("R", "D", "I"))
            assert len(row["roll_result_cells"]) == len(ROLL_HEADERS[chamber])
            assert all(
                v in (("R", "W", "nv", "*", "") if chamber == "House" else ("R", "W", "nv", ""))
                for v in row["roll_result_cells"]
            )
            assert row["cosponsorship_cell_text"] in (("CS", "") if chamber == "House" else ("",))
            assert row["district_text"] if chamber == "House" else row["district_text"] == ""
            for field_name in ("congress_score_text", "since_2011_score_text"):
                value = row[field_name]
                assert re.fullmatch(r"\d+", value) or value in (
                    ("NEW", "*", "") if chamber == "House" else ("NEW", "#")
                )
            glyphs.update(row["roll_result_cells"])
            if chamber == "House":
                cosponsors.update([row["cosponsorship_cell_text"]])
        assert dict(glyphs) == data["roll_glyph_counts"] and dict(cosponsors) == data["cosponsorship_glyph_counts"]
        assert [h["physical_page"] for h in data["page_header_occurrences"]] == list(PAGE_COUNTS[chamber])
        for header in data["page_header_occurrences"]:
            assert (
                header["ordered_roll_headers"] == ROLL_HEADERS[chamber]
                and header["score_header_texts"] == SCORE_HEADERS
            )
            assert header["cosponsorship_header_text"] == ("Cosponsor 3040" if chamber == "House" else "")
            assert all(isinstance(v, str) for v in header["other_source_texts"])
        assert data["page_header_occurrences"][0]["period_heading_texts"] == PERIOD_HEADERS[chamber]
        assert [i["ordinal"] for i in data["items"]] == list(range(1, (13 if chamber == "House" else 9)))
        for item in data["items"]:
            ordinal = item["ordinal"]
            if ordinal <= len(ROLL_HEADERS[chamber]):
                assert item["header_text"] == ROLL_HEADERS[chamber][ordinal - 1]
                assert item["roll_number_text"] == item["header_text"][4:] and item["item_kind_text"] == "RCV"
                assert item["session_text"] == ("1" if ordinal <= 6 else "2")
                assert item["year_text"] == ("2013" if ordinal <= 6 else "2014")
            else:
                assert item["header_text"] == "Cosponsor 3040" and item["item_kind_text"] == "Cosponsor"
                assert all(item[k] is None for k in ("roll_number_text", "session_text", "year_text"))
            if chamber == "House":
                assert all(item[k] is None for k in ("narrative_text", "bill_citation_text", "amendment_citation_text"))
            else:
                assert item["narrative_text"].startswith("RCV#" + item["roll_number_text"] + ":")
                assert item["narrative_text"] in data["context_pages"][4]["native_text"]
                for k in ("bill_citation_text", "amendment_citation_text"):
                    assert item[k] is None or item[k] in item["narrative_text"]
        if chamber == "Senate":
            assert [p["physical_page"] for p in data["context_pages"]] == list(range(1, 7))
            assert all(isinstance(p["native_text"], str) for p in data["context_pages"])
            assert (
                data["source_legend_text"]
                == "Scorecard Guide and Codes\n"
                + data["context_pages"][4]["native_text"].split("Scorecard Guide and Codes", 1)[1].strip()
            )
            assert data["visually_blank_pages"] == [6] and not data["context_pages"][5]["native_text"].strip()
        else:
            assert (
                data["context_pages"] == []
                and data["source_legend_text"] is None
                and data["visually_blank_pages"] == []
            )
        return data
    except (AssertionError, KeyError, TypeError, ValueError, IndexError):
        raise ScorecardSourceError(
            "SMART-TD qualified facts omit or alter the complete original chamber shape"
        ) from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    chamber = next((c for c, value in EDITIONS.items() if edition == value), None)
    if chamber is None:
        raise ScorecardSourceError("Unknown SMART-TD original PDF edition; historical UTU identity remains separate")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("SMART-TD PDF requires pinned private observations and private retention")
    source = context.read(
        SOURCE_URLS[chamber], stage="scorecards:smart-td:" + chamber.lower() + ":original", hosts=("web.archive.org",)
    )
    _source(source, chamber)
    repeated = context.read(
        SOURCE_URLS[chamber],
        stage="scorecards:smart-td:" + chamber.lower() + ":original-reread",
        hosts=("web.archive.org",),
    )
    _source(repeated, chamber)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256[chamber],
        observations_sha256=QUALIFIED_SHA256[chamber],
        stage="scorecards:smart-td:" + chamber.lower() + ":qualified-source-facts",
    )
    data = _facts(qualified_observations, chamber)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="SMART Transportation Division",
        parser_version=parser_version,
        rendition_rule="Complete named original archived SMART-TD "
        + chamber
        + " PDF grid; separate publisher from unresolved historical UTU census identity",
        homepage="https://www.smart-union.org/",
    )
    groups = ("members", "ratings", "item-results", "items", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")

    def loc(page, path):
        return f"pdf:page={page};observation={observation}{path}"

    card = bundle.tables["scorecards"][0]
    card["timespan_text"] = "\n".join(data["header_period_texts"])
    card["periods_json"] = json.dumps(
        [
            {
                "occurrence_id": f"session:{n}",
                "kind": "explicit",
                "period_text": text,
                "congress_text": "113",
                "session_text": str(n),
                "year_text": str(2012 + n),
                "source_path": loc(1, f"/header-periods/{n - 1}"),
            }
            for n, text in enumerate(data["header_period_texts"], 1)
        ]
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(1, "/source-context"),
        methodology_id="source-context",
        chamber_text=chamber,
        methodology_text=json.dumps(
            {
                "publisher_name_text": data["publisher_name_text"],
                "original_publisher_url": ORIGINAL_ROOT + FILENAMES[chamber],
                "archive_replay_url": SOURCE_URLS[chamber],
                "page_header_occurrences": data["page_header_occurrences"],
                "visually_blank_pages": data["visually_blank_pages"],
            },
            ensure_ascii=False,
        ),
        methodology_url=source.url,
        disclosure_status="Native grid headers and periods. This rendition states no score formula, weights or preferred Yea/Nay action; unlabelled source statuses remain literal.",
    )
    if data["source_legend_text"] is not None:
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(5, "/source-guide-and-codes"),
            methodology_id="source-guide-and-codes",
            chamber_text=chamber,
            methodology_text=data["source_legend_text"],
            methodology_url=source.url,
            disclosure_status="Native Senate-only glyph legend; no House meaning or official action is inferred",
        )
    for metric, name, period in (
        ("congress-score", SCORE_HEADERS[0], "113th Congress"),
        ("2011-to-current", SCORE_HEADERS[1], SCORE_HEADERS[1]),
    ):
        path = loc(1, "/score-headers/" + ("0" if metric == "congress-score" else "1"))
        bundle.add(
            "scorecard_metrics",
            source,
            path,
            metric_id=metric,
            name=name,
            chamber_text=chamber,
            period_text=period,
            periods_json=json.dumps(
                [
                    {
                        "occurrence_id": "source-score-period",
                        "kind": "explicit",
                        "period_text": period,
                        "source_path": path,
                    }
                ]
            ),
            is_primary=None,
        )
    for item in data["items"]:
        ordinal = item["ordinal"]
        identity = key("column", str(ordinal))
        path = loc(1, f"/items/{ordinal}")
        refs = []
        for kind, column in (("bill", "bill_citation_text"), ("amendment", "amendment_citation_text")):
            citation = item[column]
            if citation is not None:
                start = item["narrative_text"].index(citation)
                refs.append(
                    {
                        "occurrence_id": kind + ":1",
                        "kind": kind,
                        "citation_text": citation,
                        column: citation,
                        "source_path": loc(5, f"/items/{ordinal}/narrative/characters/{start}:{start + len(citation)}"),
                    }
                )
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=identity,
            publisher_item_id=item["header_text"],
            item_kind_text=item["item_kind_text"],
            title=item["header_text"],
            congress_text="113",
            chamber_text=chamber,
            session_text=item["session_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=json.dumps(refs, ensure_ascii=False),
        )
        if item["narrative_text"] is not None:
            bundle.add(
                "scorecard_methodologies",
                source,
                loc(5, f"/items/{ordinal}/narrative"),
                methodology_id="item:" + identity,
                chamber_text=chamber,
                methodology_text=item["narrative_text"],
                methodology_url=source.url,
                disclosure_status="Exact original item narrative and spelling; repeated actions on one bill remain distinct",
            )
    for member in data["members"]:
        page, ordinal, row = member["physical_page"], member["row_ordinal"], member["record"]
        identity = key(f"page={page}", f"row={ordinal}")
        path = loc(page, f"/members/{ordinal}/record")
        note = json.dumps({"native_grid_fields": row}, ensure_ascii=False)
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=row["member_name_text"],
            state=row["state_text"],
            district=row["district_text"] if chamber == "House" else None,
            party=row["party_text"],
            chamber_text=chamber,
            notes_text=note,
        )
        for metric, column in (("congress-score", "congress_score_text"), ("2011-to-current", "since_2011_score_text")):
            value = row[column]
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/" + column,
                metric_id=metric,
                publisher_member_key=identity,
                value_text=value,
                value_number=value if re.fullmatch(r"\d+", value) else None,
                value_status_text=value if value and not re.fullmatch(r"\d+", value) else None,
                notes_text=json.dumps(
                    {"native_value": value, "native_member_notes": row["notes_text"], "native_empty_cell": value == ""},
                    ensure_ascii=False,
                ),
            )
        cells = [*row["roll_result_cells"]] + ([row["cosponsorship_cell_text"]] if chamber == "House" else [])
        for number, value in enumerate(cells, 1):
            field_path = (
                f"/roll_result_cells/{number - 1}"
                if number <= len(ROLL_HEADERS[chamber])
                else "/cosponsorship_cell_text"
            )
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + field_path,
                result_id="source-cell",
                item_id=key("column", str(number)),
                publisher_member_key=identity,
                result_text=value,
            )
    return bundle.finish(
        "Exact complete original chamber PDF and stable reread; all source grid headers, printed member contexts, score/status cells, result glyphs and observed blanks reconcile with independently reviewed native/rendered original data. No official roster, identity, action, score formula or historical UTU equivalence is supplied.",
        declared={
            "printed_roll_headers": len(ROLL_HEADERS[chamber]),
            "printed_cosponsorship_headers": 1 if chamber == "House" else 0,
            "printed_score_headers": 2,
        },
    )
