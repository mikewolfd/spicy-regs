"""Common Cause's named Democracy Scorecard PDFs, preserving original renditions."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, ClassVar
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "common-cause-named-qualified-original-pdf/1"
HOSTS = ("www.commoncause.org", "democracyscorecard.org", "web.archive.org")
INDEX = "https://www.commoncause.org/resources/democracy-scorecard/"
# Each bound comes from the complete selected publisher grid, including its
# omissions and alternatives. Archive timestamps and upload years are custody
# facts; they never replace the report's original edition or stated Congress.
SPECS: dict[str, dict[str, Any]] = {
    "2016-original": {
        "year": "2016",
        "congress": "114",
        "title": "2016 DEMOCRACY SCORECARD",
        "url": "https://www.commoncause.org/wp-content/uploads/2018/03/report.pdf",
        "original_url": "https://www.commoncause.org/wp-content/uploads/2018/03/report.pdf",
        "source_sha256": "4d9867a0a21bde326fdb96c0ebd5ba0d051e896806b7415b7cdab0de74be722a",
        "qualified_sha256": "3367c2feecc592d778050738c4a95b3febd03f03d9f267ffec13999d8744c184",
        "page_count": 27,
        "member_counts": {"House": 433, "Senate": 100},
        "members_by_page": {
            "5": 24,
            "6": 24,
            "7": 24,
            "8": 24,
            "9": 24,
            "10": 24,
            "11": 24,
            "12": 24,
            "13": 24,
            "14": 24,
            "15": 24,
            "16": 24,
            "17": 24,
            "18": 24,
            "19": 23,
            "20": 24,
            "21": 25,
            "22": 25,
            "23": 24,
            "24": 24,
            "25": 24,
            "26": 24,
            "27": 4,
        },
        "item_counts": {"House": 18, "Senate": 13},
        "glyph_counts": {"✘": 6177, "✔": 2836, "DNV": 80, "T": 1},
        "authority_url": "https://www.commoncause.org/press/common-cause-releases-scorecard-of-lawmaker-support-for-pro-democracy-bills-in-118th-congress/",
        "authority_target_url": "https://www.commoncause.org/wp-content/uploads/2018/03/report.pdf",
    },
    "2016-revised": {
        "year": "2016",
        "congress": "114",
        "title": "2016 DEMOCRACY SCORECARD",
        "url": "https://www.commoncause.org/wp-content/uploads/2018/05/DemocracyScorecard_REV2018.pdf",
        "original_url": "https://www.commoncause.org/wp-content/uploads/2018/05/DemocracyScorecard_REV2018.pdf",
        "source_sha256": "5f91a2e80928afef5fc776f0db81ce26e193737e084468d0cc726e8f3a6390ea",
        "qualified_sha256": "68e6ff9b48858c6028a5e24bb71763f381c20a49fd525a4f089a07a19833f915",
        "page_count": 27,
        "member_counts": {"House": 433, "Senate": 100},
        "members_by_page": {
            "5": 24,
            "6": 24,
            "7": 24,
            "8": 24,
            "9": 24,
            "10": 24,
            "11": 24,
            "12": 24,
            "13": 24,
            "14": 24,
            "15": 24,
            "16": 24,
            "17": 24,
            "18": 24,
            "19": 23,
            "20": 24,
            "21": 25,
            "22": 25,
            "23": 24,
            "24": 24,
            "25": 24,
            "26": 24,
            "27": 4,
        },
        "item_counts": {"House": 18, "Senate": 13},
        "glyph_counts": {"✘": 6175, "✔": 2838, "DNV": 80, "T": 1},
        "authority_url": "https://www.commoncause.org/resources/democracy-scorecard/",
        "authority_target_url": "https://www.commoncause.org/wp-content/uploads/2018/05/DemocracyScorecard_REV2018.pdf",
    },
    "2018-archived": {
        "year": "2018",
        "congress": "115",
        "title": "2018 DEMOCRACY SCORECARD",
        "url": "https://web.archive.org/web/20220420150550id_/https://democracyscorecard.org/wp-content/uploads/2018/09/DemocracyScorecard_2018_WEB.pdf",
        "original_url": "https://democracyscorecard.org/wp-content/uploads/2018/09/DemocracyScorecard_2018_WEB.pdf",
        "source_sha256": "349e7c9d2d8fd3dbb27fe303a0a97c282996ca4ea12bc8ddc25cef5fb4a56eb5",
        "qualified_sha256": "8e9609c356ba077597aea3fab6b34a3dae541e0d2f61159ddacaab5b9d47e73a",
        "page_count": 30,
        "member_counts": {"House": 434, "Senate": 99},
        "members_by_page": {
            "5": 21,
            "6": 21,
            "7": 21,
            "8": 21,
            "9": 21,
            "10": 21,
            "11": 21,
            "12": 21,
            "13": 21,
            "14": 21,
            "15": 21,
            "16": 21,
            "17": 21,
            "18": 21,
            "19": 21,
            "20": 21,
            "21": 21,
            "22": 21,
            "23": 21,
            "24": 20,
            "25": 15,
            "26": 23,
            "27": 23,
            "28": 23,
            "29": 23,
            "30": 7,
        },
        "item_counts": {"House": 15, "Senate": 15},
        "glyph_counts": {"✘": 5354, "✔": 2641},
        "authority_url": "https://www.commoncause.org/press/common-cause-releases-scorecard-of-lawmaker-support-for-pro-democracy-bills-in-118th-congress/",
        "authority_target_url": "https://democracyscorecard.org/wp-content/uploads/2018/09/DemocracyScorecard_2018_WEB.pdf",
    },
    "2020-archived": {
        "year": "2020",
        "congress": "116",
        "title": "2020 DEMOCRACY SCORECARD",
        "url": "https://web.archive.org/web/20201207222839id_/https://democracyscorecard.org/wp-content/uploads/2020/09/DemocracyScorecard_2020v9.pdf",
        "original_url": "https://democracyscorecard.org/wp-content/uploads/2020/09/DemocracyScorecard_2020v9.pdf",
        "source_sha256": "69ae161e945c1b946e0247fb53c9892eae8382c9beac02729eb490a911987682",
        "qualified_sha256": "d2049897c65a55a3c7a239a943490298642322d092fe1ec0d081ed779b8476b7",
        "page_count": 33,
        "member_counts": {"House": 428, "Senate": 100},
        "members_by_page": {
            "8": 21,
            "9": 21,
            "10": 21,
            "11": 21,
            "12": 21,
            "13": 21,
            "14": 21,
            "15": 21,
            "16": 21,
            "17": 21,
            "18": 21,
            "19": 21,
            "20": 21,
            "21": 21,
            "22": 21,
            "23": 21,
            "24": 21,
            "25": 21,
            "26": 21,
            "27": 20,
            "28": 9,
            "29": 23,
            "30": 23,
            "31": 23,
            "32": 23,
            "33": 8,
        },
        "item_counts": {"House": 15, "Senate": 20},
        "glyph_counts": {"✖": 4583, "✔": 3829, "N/A": 4, "✖/A": 4},
        "authority_url": "https://www.commoncause.org/press/common-cause-releases-scorecard-of-lawmaker-support-for-pro-democracy-bills-in-118th-congress/",
        "authority_target_url": "https://democracyscorecard.org/wp-content/uploads/2020/09/DemocracyScorecard_2020v9.pdf",
    },
    "2022-archived": {
        "year": "2022",
        "congress": "117",
        "title": "2022 DEMOCRACY SCORECARD",
        "url": "https://web.archive.org/web/20220908135906id_/https://democracyscorecard.org/wp-content/uploads/2022/09/DemocracyScorecard_2022v9.pdf",
        "original_url": "https://democracyscorecard.org/wp-content/uploads/2022/09/DemocracyScorecard_2022v9.pdf",
        "source_sha256": "29df04b8dd49c7dec47531c857e1382be6206091fe6512c56fd6d5a8b0059b3a",
        "qualified_sha256": "3d9004bb4929a8ddbbc55a6081e2d661c1fe8244623cf0ef1c7c97cbf11be615",
        "page_count": 32,
        "member_counts": {"House": 423, "Senate": 99},
        "members_by_page": {
            "6": 20,
            "7": 21,
            "8": 21,
            "9": 21,
            "10": 21,
            "11": 20,
            "12": 21,
            "13": 21,
            "14": 21,
            "15": 20,
            "16": 21,
            "17": 21,
            "18": 21,
            "19": 21,
            "20": 21,
            "21": 21,
            "22": 21,
            "23": 21,
            "24": 21,
            "25": 20,
            "26": 7,
            "27": 21,
            "28": 21,
            "29": 21,
            "30": 21,
            "31": 15,
        },
        "item_counts": {"House": 18, "Senate": 15},
        "glyph_counts": {"✔": 4577, "✖": 4508, "DNV": 14},
        "authority_url": "https://www.commoncause.org/press/common-cause-releases-scorecard-of-lawmaker-support-for-pro-democracy-bills-in-118th-congress/",
        "authority_target_url": "https://democracyscorecard.org/wp-content/uploads/2022/09/DemocracyScorecard_2022v9.pdf",
    },
    "2024-publisher-linked": {
        "year": "2024",
        "congress": "118",
        "title": "2024 DEMOCRACY SCORECARD",
        "url": "https://democracyscorecard.org/wp-content/uploads/2024/09/DemocracyScorecard_2024v6.pdf",
        "original_url": "https://democracyscorecard.org/wp-content/uploads/2024/09/DemocracyScorecard_2024v6.pdf",
        "source_sha256": "fda7971c645844ededd7ace300645fff27f6d4be527db0dc53065fcbcda39b15",
        "qualified_sha256": "a7e719676fdb01f6e2564c3c76b48c89d215c86900510d3cb0d2a7d46e2abcc1",
        "page_count": 31,
        "member_counts": {"House": 424, "Senate": 97},
        "members_by_page": {
            "5": 21,
            "6": 21,
            "7": 21,
            "8": 21,
            "9": 21,
            "10": 21,
            "11": 20,
            "12": 21,
            "13": 21,
            "14": 21,
            "15": 21,
            "16": 21,
            "17": 21,
            "18": 21,
            "19": 21,
            "20": 21,
            "21": 21,
            "22": 21,
            "23": 21,
            "24": 21,
            "25": 5,
            "26": 21,
            "27": 21,
            "28": 21,
            "29": 21,
            "30": 13,
        },
        "item_counts": {"House": 13, "Senate": 10},
        "glyph_counts": {"✖": 3317, "✔": 3083, "DNV": 80, "present": 2},
        "authority_url": "https://www.commoncause.org/press/common-cause-releases-scorecard-of-lawmaker-support-for-pro-democracy-bills-in-118th-congress/",
        "authority_target_url": "https://democracyscorecard.org/",
        "link_document_url": "https://democracyscorecard.org/",
        "link_document_sha256": "ef112f3dd16f89a4bace3ecd85d981697e056a201553da88eefb40d0af279ae4",
    },
}


def _spec(identifier: str) -> dict[str, Any]:
    if identifier not in SPECS:
        raise ScorecardSourceError("Common Cause requires a reviewed named original PDF rendition")
    return SPECS[identifier]


def _edition(identifier: str) -> ScorecardEdition:
    spec = _spec(identifier)
    return ScorecardEdition(
        "common_cause",
        identifier,
        spec["url"],
        spec["title"],
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    require_reviewed_pdf(
        document,
        source_url=spec["url"],
        source_sha256=spec["source_sha256"],
        message="Common Cause PDF differs from its reviewed original named rendition",
    )


def _authority(document, spec):
    parsed = soup(document)
    title = parsed.title.get_text(" ", strip=True) if parsed.title else ""
    links = {urljoin(document.url, node["href"]) for node in parsed.select("a[href]")}
    if (
        document.url != spec["authority_url"]
        or "Common Cause" not in title
        or spec["authority_target_url"] not in links
    ):
        raise ScorecardSourceError("Common Cause original publisher page no longer establishes this report link")


def _qualified(body: bytes, identifier: str, spec: dict[str, Any]) -> dict[str, Any]:
    from hashlib import sha256

    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("Common Cause semantic observations differ from their qualification pin")
    try:
        data = json.loads(body)
        source, front = data["source"], data["front"]
        if (
            data["schema_version"] != "common-cause-qualified-native-pdf/1"
            or data["edition_key"] != identifier
            or source["requested_url"] != spec["url"]
            or source["original_publisher_url"] != spec["original_url"]
            or source["sha256"] != spec["source_sha256"]
            or source["page_count"] != spec["page_count"]
            or front["publisher_name_text"] != "Common Cause"
            or front["year_text"] != spec["year"]
            or front["congress_text"] != spec["congress"]
            or front["title_text"] != spec["title"]
            or front["metric_label_text"] not in {"OVERALL", "TOTAL"}
            or not front["methodology_text"]
            or not front["methodology_pages"]
            or any(type(p) is not int or not 1 <= p <= spec["page_count"] for p in front["methodology_pages"])
            or front["legend"]["✔"] != "pro-democracy reform position"
        ):
            raise ValueError
        for note in front["footnotes"]:
            if (
                type(note["physical_page"]) is not int
                or not 1 <= note["physical_page"] <= spec["page_count"]
                or not note["marker_text"]
                or not note["text"]
            ):
                raise ValueError
        item_ids, counts = set(), Counter()
        for item in data["items"]:
            chamber = item["chamber_text"]
            if (
                chamber not in spec["item_counts"]
                or item["item_number_text"] != str(counts[chamber] + 1)
                or (chamber, item["item_number_text"]) in item_ids
                or not item["title_text"]
                or not item["native_header_text"]
                or not item["group_text"]
                or type(item["physical_page"]) is not int
                or not 1 <= item["physical_page"] <= spec["page_count"]
                or any(
                    ref["kind"] not in {"bill", "amendment"} or ref["citation_text"] not in item["title_text"]
                    for ref in item["references"]
                )
            ):
                raise ValueError
            item_ids.add((chamber, item["item_number_text"]))
            counts[chamber] += 1
        if dict(counts) != spec["item_counts"]:
            raise ValueError
        identities, populations, pages, glyphs = set(), Counter(), Counter(), Counter()
        page_ordinals: dict[str, int] = {}
        for member in data["members"]:
            chamber, page = member["chamber"], member["physical_page"]
            identity = (chamber, member["state_text"], member["district_text"], member["member_name_text"])
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or not member["member_name_text"]
                or not member["state_text"]
                or member["party_text"] not in {"D", "R", "I", "L"}
                or not isinstance(member["overall_value_text"], str)
                or not re.fullmatch(r"\d+/\d+\*?", member["overall_value_text"])
                or type(page) is not int
                or str(page) not in spec["members_by_page"]
                or type(member["page_ordinal"]) is not int
                or member["page_ordinal"] != page_ordinals.get(str(page), 0)
                or len(member["item_results"]) != spec["item_counts"][chamber]
                or any(value not in spec["glyph_counts"] for value in member["item_results"])
                or (chamber == "Senate" and member["district_text"] is not None)
            ):
                raise ValueError
            unknown = [str(i + 1) for i, value in enumerate(member["item_results"]) if value in {"T", "✖/A"}]
            if [cell["item_number_text"] for cell in member["unmapped_cells"]] != unknown or any(
                cell["native_text_code"] != member["item_results"][int(cell["item_number_text"]) - 1]
                or not cell["rendered_observation_text"]
                or cell["meaning_text"] is not None
                for cell in member["unmapped_cells"]
            ):
                raise ValueError
            identities.add(identity)
            populations[chamber] += 1
            pages[str(page)] += 1
            page_ordinals[str(page)] = member["page_ordinal"] + 1
            glyphs.update(member["item_results"])
        if (
            dict(populations) != spec["member_counts"]
            or dict(pages) != spec["members_by_page"]
            or dict(glyphs) != spec["glyph_counts"]
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "Common Cause observations do not establish the complete printed original rendition"
        ) from error


@dataclass(frozen=True, slots=True)
class CommonCausePDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError(
                "Common Cause semantic observations require a reviewed named rendition"
            ) from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        _policy(context)
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["url"], stage=f"common_cause:{self.edition_key}:list", hosts=HOSTS), spec)
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError("Common Cause reader requires its exact configured named rendition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _policy(context):
    if context.evidence_policy == "full":
        raise ScorecardSourceError("Common Cause PDF redistribution rights are not established")


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    identifier = edition.edition_id
    spec = _spec(identifier)
    if edition != _edition(identifier):
        raise ScorecardSourceError("Common Cause requires its exact reviewed named rendition")
    _policy(context)
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Common Cause requires qualified source facts and private observation retention")
    data = _qualified(qualified_observations, identifier, spec)
    authority = context.read(spec["authority_url"], stage=f"common_cause:{identifier}:publisher-link", hosts=HOSTS)
    _authority(authority, spec)
    link_document = None
    if spec.get("link_document_url"):
        link_document = context.read(
            spec["link_document_url"], stage=f"common_cause:{identifier}:report-site-link", hosts=HOSTS
        )
        links = {urljoin(link_document.url, node["href"]) for node in soup(link_document).select("a[href]")}
        if (
            link_document.url != spec["link_document_url"]
            or spec["original_url"] not in links
            or (
                spec.get("link_document_sha256")
                and link_document.response.sha256 != "sha256:" + spec["link_document_sha256"]
            )
        ):
            raise ScorecardSourceError(
                "Common Cause publisher-linked report page no longer establishes the original PDF link"
            )
    primary = context.read(spec["url"], stage=f"common_cause:{identifier}:pdf", hosts=HOSTS)
    _source(primary, spec)
    observation = retain_qualified(
        primary,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"common_cause:{identifier}:qualified-observations",
    )

    def path(page, suffix):
        return f"pdf:page[{page}];observation={observation};{suffix}"

    front = data["front"]
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Common Cause",
        parser_version=parser_version,
        homepage="https://www.commoncause.org/",
        rendition_rule="Named complete original PDF; original publisher link and explicit archive custody; every printed member, fraction and criterion cell; alternate 2016 renditions stay distinct; exact original PDF reread",
    )
    bundle.use(authority, "publisher-attribution")
    if link_document is not None:
        bundle.use(link_document, role="discovery")
    bundle.tables["scorecard_publishers"][0].update(
        scorecard_index_url=INDEX,
        source_url=authority.url,
        source_path="html:a[href=" + spec["authority_target_url"] + "]",
        capture_id=authority.capture_id,
        observed_at=authority.response.observed_at,
    )
    bundle.tables["scorecards"][0].update(
        edition_label_text=front["title_text"],
        timespan_text=front["year_text"],
        methodology_url=spec["original_url"],
        periods_json=json_column(
            [
                {
                    "occurrence_id": "original-edition-year",
                    "period_text": front["year_text"],
                    "kind": "explicit",
                    "year_text": front["year_text"],
                    "congress_text": front["congress_text"],
                    "source_path": path(1, "/edition-label"),
                }
            ]
        ),
    )
    method_path = path(front["methodology_pages"][0], "/methodology")
    for chamber in spec["item_counts"]:
        method = key(chamber, "methodology")
        bundle.add(
            "scorecard_methodologies",
            primary,
            method_path,
            methodology_id=method,
            chamber_text=chamber,
            methodology_url=spec["original_url"],
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_methodology_text": front["methodology_text"],
                    "source_methodology_pages": front["methodology_pages"],
                    "source_legend": front["legend"],
                    "source_cutoff_date_text": front["cutoff_date_text"],
                    "original_publisher_url": data["source"]["original_publisher_url"],
                    "archive_timestamp": data["source"]["archive_timestamp"],
                    "source_observations": data["source_observations"],
                    "source_footnotes": front["footnotes"],
                }
            ),
        )
        bundle.add(
            "scorecard_metrics",
            primary,
            path(1, "/metric-label"),
            metric_id=key(chamber, "overall"),
            name=front["metric_label_text"],
            chamber_text=chamber,
            period_text=front["year_text"],
            methodology_id=method,
        )
    for item in data["items"]:
        chamber, number = item["chamber_text"], item["item_number_text"]
        item_id, location = (
            key(chamber, "column", number),
            path(item["physical_page"], f"/scored-column[{number}]/header"),
        )
        references = [
            {
                "occurrence_id": f"header-citation-{i}",
                "citation_text": ref["citation_text"],
                "kind": ref["kind"],
                ref["kind"] + "_citation_text": ref["citation_text"],
                "chamber_text": chamber,
                "congress_text": front["congress_text"],
                "source_path": location + f"/citation[{i}]",
            }
            for i, ref in enumerate(item["references"])
        ]
        bills = [ref["citation_text"] for ref in item["references"] if ref["kind"] == "bill"]
        amendments = [ref["citation_text"] for ref in item["references"] if ref["kind"] == "amendment"]
        method = key(chamber, "column", number, "methodology")
        bundle.add(
            "scorecard_methodologies",
            primary,
            location,
            methodology_id=method,
            chamber_text=chamber,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "native_header_text": item["native_header_text"],
                    "source_group_text": item["group_text"],
                    "source_item_kind_text": item["item_kind_text"],
                    "source_criterion_notes": [
                        {**note, "source_path": f"pdf:page[{note['physical_page']}]/criterion-note"}
                        for note in item.get("criterion_notes", [])
                    ],
                    "criterion_scope": "One printed scoring column; all literal alternative citations remain one item and one member result.",
                }
            ),
        )
        target = item["group_text"] if item["group_text"] == "BILLS TO COSPONSOR" else None
        bundle.add(
            "scorecard_items",
            primary,
            location,
            item_id=item_id,
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=chamber,
            congress_text=front["congress_text"],
            bill_citation_text=next(iter(bills), None),
            amendment_citation_text=next(iter(amendments), None),
            references_json=json_column(references),
            publisher_position_text=target,
            position_basis="explicit" if target else "absent",
            position_source_path=location + "/group" if target else None,
        )
        bundle.add(
            "scorecard_metric_items",
            primary,
            location,
            metric_id=key(chamber, "overall"),
            item_id=item_id,
            participation_id="printed-column",
            methodology_id=method,
            publisher_position_text=target,
            position_basis="explicit" if target else "absent",
        )
    for member in data["members"]:
        chamber = member["chamber"]
        member_id = key(
            chamber,
            member["state_text"],
            *([member["district_text"]] if member["district_text"] else []),
            member["member_name_text"],
        )
        location = path(member["physical_page"], f"/member-row[{member['page_ordinal']}]")
        bundle.add(
            "scorecard_members",
            primary,
            location,
            publisher_member_key=member_id,
            member_name=member["member_name_text"],
            chamber_text=chamber,
            state=member["state_text"],
            district=member["district_text"],
            party=member["party_text"],
            period_text=front["year_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {"source_location_text": member["location_text"], "unmapped_source_cells": member["unmapped_cells"]}
            ),
        )
        notes = [
            {**note, "source_path": f"pdf:page[{note['physical_page']}]/footnote[{note['marker_text']}]"}
            for note in front["footnotes"]
            if member["overall_value_text"].endswith(note["marker_text"])
        ]
        bundle.add(
            "scorecard_member_ratings",
            primary,
            location + "/overall",
            publisher_member_key=member_id,
            metric_id=key(chamber, "overall"),
            value_text=member["overall_value_text"],
            notes_text=json_column(notes) if notes else None,
        )
        for index, glyph in enumerate(member["item_results"], 1):
            bundle.add(
                "scorecard_member_item_results",
                primary,
                location + f"/scored-column[{index}]",
                publisher_member_key=member_id,
                item_id=key(chamber, "column", str(index)),
                metric_id=key(chamber, "overall"),
                participation_id="printed-column",
                result_id="printed-cell",
                result_text=glyph,
                reason_text=front["legend"].get(glyph),
            )
    repeated = context.read(spec["url"], stage=f"common_cause:{identifier}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete source-defined original report; every named grid row, literal rating, scoring column and cell; original publisher link verified; exact PDF trailer/hash and byte-identical source reread",
        declared={},
    )
