"""AFT's complete original 111th Congress voting record, without fabricated scores."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "aft-111-qualified-original-pdf/1"
ORIGINAL_URL = "http://www.aft.org/votes"
SOURCE_URL = "https://web.archive.org/web/20120616151817id_/http://www.aft.org/votes"
SOURCE_SHA256 = "1585934a4ada8ff555c35835a3d58222025d4bdc5189221712dfed43835c48ce"
QUALIFIED_SHA256 = "3457f9704e375ac4b74cc8c4ed8a3b3d7ba979c40f62962d3ddad8ca14310e39"
PAGE_COUNTS = {2: 105, 3: 93, 4: 104, 5: 146, 7: 107}
GLYPHS = frozenset(("R", "W", "X", "I", "P", "S"))
EDITION = ScorecardEdition(
    "aft", "111-original-pdf", SOURCE_URL, "Voting Record", congress="111", chamber="both", is_current=False
)


@dataclass(frozen=True, slots=True)
class AFTReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URL,
        source_sha256=SOURCE_SHA256,
        message="AFT original archived PDF differs from its reviewed complete rendition",
    )


def list_scorecards(context):
    document = context.read(SOURCE_URL, stage="scorecards:aft:named-edition", hosts=("web.archive.org",))
    _source(document)
    return [EDITION]


def _facts(body):
    try:
        data = json.loads(body)
        assert data["format_version"] == "aft-111-qualified-source-facts/1"
        assert data["source_sha256"] == SOURCE_SHA256 and data["source_page_count"] == 7
        assert data["congress_text"] == "111" and data["timespan_text"] == "2009-10"
        assert data["prepared_date_text"] == "august 2010"
        assert [p["physical_page"] for p in data["context_pages"]] == list(range(1, 8))
        assert all(
            isinstance(p["native_authored_text"], str) and p["native_authored_text"].strip()
            for p in data["context_pages"]
        )
        assert isinstance(data["cover_methodology_text"], str) and data["cover_methodology_text"].strip()
        assert isinstance(data["state_heading_case_basis"], str) and data["state_heading_case_basis"].strip()
        assert Counter(m["physical_page"] for m in data["members"]) == Counter(PAGE_COUNTS)
        assert [m["physical_page"] for m in data["members"]] == sorted(m["physical_page"] for m in data["members"])
        counts, glyphs = Counter(), Counter()
        for m in data["members"]:
            page, row = m["physical_page"], m["record"]
            chamber = "Senate" if page == 7 else "House"
            counts[page] += 1
            assert m["row_ordinal"] == counts[page] and m["column_ordinal"] in (1, 2, 3)
            assert set(row) == {"chamber_text", "state_text", "member_name_text", "party_text", "result_cells"}
            assert row["chamber_text"] == chamber and row["party_text"] in ("D", "R", "I")
            assert all(isinstance(row[f], str) and row[f].strip() for f in ("state_text", "member_name_text"))
            assert isinstance(m["native_member_text"], str) and isinstance(m["native_result_text"], str)
            assert row["result_cells"] == m["native_result_text"].split()
            assert len(row["result_cells"]) == (9 if chamber == "Senate" else 10)
            assert all(isinstance(v, str) and v in GLYPHS for v in row["result_cells"])
            glyphs.update(row["result_cells"])
        assert dict(glyphs) == data["result_glyph_counts"]
        for chamber, count in (("House", 10), ("Senate", 9)):
            selected = [i for i in data["items"] if i["chamber_text"] == chamber]
            assert [i["ordinal_text"] for i in selected] == [str(n) for n in range(1, count + 1)]
            for item in selected:
                assert all(
                    isinstance(item[f], str) and item[f].strip() for f in ("title_text", "narrative_heading_text")
                )
                assert item["publisher_position_text"] in ("Y", "N") and item["narrative_fragments"]
                for fragment in item["narrative_fragments"]:
                    assert fragment["physical_page"] in ((6,) if chamber == "Senate" else (2, 3, 4))
                    assert isinstance(fragment["fragment_ordinal"], int) and fragment["fragment_ordinal"] > 0
                    assert fragment["native_lines"] and all(isinstance(line, str) for line in fragment["native_lines"])
                for cite in item["citation_occurrences"]:
                    fragment = next(
                        f
                        for f in item["narrative_fragments"]
                        if f["physical_page"] == cite["physical_page"]
                        and f["fragment_ordinal"] == cite["fragment_ordinal"]
                    )
                    text = "\n".join(fragment["native_lines"])
                    assert text[cite["character_start"] : cite["character_end"]] == cite["bill_citation_text"]
                    assert re.fullmatch(r"(?:H\.R\.|S\.|H\. Res\.|S\. Res\.)\s*\d+", cite["bill_citation_text"])
        assert len(data["items"]) == 19 and sum(glyphs.values()) == 5443
        return data
    except (AssertionError, KeyError, TypeError, ValueError, StopIteration):
        raise ScorecardSourceError("AFT qualified facts omit or alter the complete native source shape") from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("Unknown AFT original edition; no inferred annual scorecard")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AFT requires pinned private source observations and retention")
    source = context.read(SOURCE_URL, stage="scorecards:aft:original", hosts=("web.archive.org",))
    _source(source)
    repeated = context.read(SOURCE_URL, stage="scorecards:aft:original-reread", hosts=("web.archive.org",))
    _source(repeated)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="scorecards:aft:qualified-source-facts",
    )
    data = _facts(qualified_observations)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="American Federation of Teachers",
        parser_version=parser_version,
        rendition_rule="Complete original archived AFT 111th Congress voting-record PDF; no aggregate score is reported",
        homepage="https://www.aft.org/",
    )
    groups = ("members", "item-results", "items", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")

    def loc(page, path):
        return f"pdf:page={page};observation={observation}{path}"

    card = bundle.tables["scorecards"][0]
    card["timespan_text"] = data["timespan_text"]
    card["periods_json"] = json.dumps(
        [
            {
                "occurrence_id": "cover-timespan",
                "kind": "explicit",
                "period_text": data["timespan_text"],
                "congress_text": data["congress_text"],
                "source_path": loc(1, "/cover-methodology"),
            }
        ]
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(1, "/cover-methodology"),
        methodology_id="source-cover",
        methodology_text=json.dumps(
            {
                "native_cover_methodology_text": data["cover_methodology_text"],
                "original_publisher_url": ORIGINAL_URL,
                "archive_replay_url": SOURCE_URL,
                "prepared_date_text": data["prepared_date_text"],
                "state_heading_case_basis": data["state_heading_case_basis"],
            },
            ensure_ascii=False,
        ),
        methodology_url=source.url,
        disclosure_status="Native publisher period, preparation date, vote judgments and party explanation; no reported aggregate ratings",
    )
    for page in (3, 5, 7):
        text = data["context_pages"][page - 1]["native_authored_text"]
        legend = text[text.index("VOTE KEY:") :]
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(page, "/legend"),
            methodology_id=f"legend:{page}",
            chamber_text="Senate" if page == 7 else "House",
            methodology_text=legend,
            methodology_url=source.url,
            disclosure_status="Native complete source glyph legend; glyph meanings remain separate from official actions",
        )
    for item in data["items"]:
        chamber, ordinal = item["chamber_text"], item["ordinal_text"]
        identity = key(chamber, ordinal)
        path = loc(7 if chamber == "Senate" else 2, "/items/" + ordinal)
        refs = [
            {
                "occurrence_id": f"citation:{number}",
                "kind": "bill",
                "citation_text": cite["bill_citation_text"],
                "bill_citation_text": cite["bill_citation_text"],
                "source_path": loc(
                    cite["physical_page"],
                    f"/narrative-fragments/{cite['fragment_ordinal']}/characters/{cite['character_start']}:{cite['character_end']}",
                ),
            }
            for number, cite in enumerate(item["citation_occurrences"], 1)
        ]
        distinct = {cite["bill_citation_text"] for cite in item["citation_occurrences"]}
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=identity,
            publisher_item_id=ordinal,
            item_kind_text=chamber.upper() + " VOTES",
            title=item["title_text"],
            chamber_text=chamber,
            bill_citation_text=next(iter(distinct)) if len(distinct) == 1 else None,
            references_json=json.dumps(refs, ensure_ascii=False),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
        )
        fragment = item["narrative_fragments"][0]
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(fragment["physical_page"], f"/narrative-fragments/{fragment['fragment_ordinal']}"),
            methodology_id="item:" + identity,
            chamber_text=chamber,
            methodology_text=json.dumps(
                {
                    "native_heading_text": item["narrative_heading_text"],
                    "native_fragments": item["narrative_fragments"],
                    "citation_occurrences": item["citation_occurrences"],
                },
                ensure_ascii=False,
            ),
            methodology_url=source.url,
            disclosure_status="Complete original explanatory fragments and repeated citation occurrences; cross-page and cross-column continuations preserved",
        )
    for member in data["members"]:
        row, page, ordinal = member["record"], member["physical_page"], member["row_ordinal"]
        identity = key(row["chamber_text"], f"page={page}", f"row={ordinal}")
        path = loc(page, f"/members/{ordinal}/record")
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=row["member_name_text"],
            state=row["state_text"],
            party=row["party_text"],
            chamber_text=row["chamber_text"],
            period_text=data["timespan_text"],
            notes_text=json.dumps(
                {
                    "native_grid_fields": row,
                    "native_member_text": member["native_member_text"],
                    "native_result_text": member["native_result_text"],
                    "column_ordinal": member["column_ordinal"],
                },
                ensure_ascii=False,
            ),
        )
        for number, value in enumerate(row["result_cells"], 1):
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + f"/result_cells/{number - 1}",
                result_id="source-cell",
                item_id=key(row["chamber_text"], str(number)),
                publisher_member_key=identity,
                result_text=value,
            )
    return bundle.finish(
        "Exact complete seven-page original and stable reread; every printed member context, ordered result cell, repeated item header, position, glyph legend and narrative continuation reconciles with independent authored text and structured image outcomes. Metric-free native grid; no fabricated scores or official identities.",
        declared={"printed_pages": "7", "house_item_columns": "10", "senate_item_columns": "9"},
    )
