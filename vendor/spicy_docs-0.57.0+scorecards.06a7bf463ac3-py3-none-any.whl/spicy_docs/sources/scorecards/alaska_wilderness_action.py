"""Alaska Wilderness Action's original linked public score sheet, with unknown period.

The archived 2016 offering and the mutable public sheet are distinct inputs.
Every native CSV field survives; the reader does not infer a year, active roster,
official member identifier, annual/lifetime formula or legislative action grid.
"""

import csv
import io
import re
from collections import Counter
from hashlib import sha256

from bs4 import Comment, NavigableString

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "alaska-wilderness-action-linked-public-sheet/2"
NAME = "Alaska Wilderness Action"
HOME = "http://alaskawildernessaction.org/"
SHEET_ID = "1lMvylVu5fiQLOgSJnrqJ5eyik2WAMLyN4q8t04c3Yp4"
AUTHORITY = "https://web.archive.org/web/20170703142529id_/http://alaskawildernessaction.org/scorecard/"
RENDERER = "https://web.archive.org/web/20170224093420id_/http://alaskawildernessaction.org/js/spreadsheet.min.js"
RENDERER_SHA256 = "d2cde3a88a66743168721828e2cea290422ac247f4ed7179f07fbb7be7234159"
SHEET = "https://docs.google.com/spreadsheets/d/" + SHEET_ID
TITLE = SHEET + "/pubhtml"
CSV = SHEET + "/gviz/tq?tqx=out%3Acsv"
HEADERS = (
    "Name",
    "Party",
    "State",
    "SCOREGOESHERE",
    "In Congress?",
    "UID",
    "Congressional District",
    "Phone",
    "",
    "",
    "",
)
# Qualification bounds from the complete original export, not a declared roster.
REVIEWED_ROWS = 535
REVIEWED_FLAGS = {"House": 381, "Senate": 92, "": 62}
REVIEWED_BLANK_IDS = 1
EDITION = ScorecardEdition(
    "alaska_wilderness_action",
    "linked-public-score-sheet-" + SHEET_ID,
    CSV,
    "Scorecard",
    chamber="both",
)


def list_scorecards(context):
    # Named supported source selection, not an archive or latest-edition census.
    return (EDITION,)


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("Alaska Wilderness Action source field is missing or repeated: " + selector)
    return nodes[0]


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _layout(node, tags):
    children = [c.name for c in node.children if getattr(c, "name", None)]
    visible = [str(c).strip() for c in node.children if isinstance(c, NavigableString) and not isinstance(c, Comment)]
    if children != tags or any(visible):
        raise ScorecardSourceError("Alaska Wilderness Action native context has unreviewed structural notes")


def _html(document, url):
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("Alaska Wilderness Action selected source custody changed")
    if (document.response.content_type or "").split(";", 1)[0].lower() != "text/html":
        raise ScorecardSourceError("Alaska Wilderness Action selected original is not HTML")
    if (
        not re.search(rb"</html>\s*(?:<!--.*?-->\s*)*$", document.body, re.DOTALL | re.IGNORECASE)
        or b"</body>" not in document.body.lower()
    ):
        raise ScorecardSourceError("Alaska Wilderness Action selected HTML is incomplete")
    return soup(document)


def _authority(document):
    html = _html(document, AUTHORITY)
    article = _one(html, "#post-41")
    _layout(article, ["header", "div", "article", "article", "footer"])
    header = article.find("header", recursive=False)
    _layout(header, ["h1"])
    heading = _one(header, "h1.entry-title")
    article_footer = article.find("footer", recursive=False)
    publisher_footer = _one(html, "footer.row")
    _layout(publisher_footer, ["article", "article"])
    content = _one(article, ":scope > .entry-content")
    wrapper = _one(article, ":scope > #text-5")
    _layout(wrapper, ["div"])
    if wrapper.attrs != {"id": "text-5", "class": ["large-12", "columns", "widget", "widget_text"]}:
        raise ScorecardSourceError("Alaska Wilderness Action original sheet wrapper attributes changed")
    widget = _one(wrapper, ":scope > .textwidget")
    identity = _one(html, "#text-3 > .textwidget")
    contact = _one(html, "#text-2 > .textwidget")
    script = _one(widget, 'script[src="/js/spreadsheet.min.js"]')
    inline = [s.get_text() for s in widget.find_all("script") if not s.get("src")]
    if len(inline) != 1:
        raise ScorecardSourceError("Alaska Wilderness Action original application loader changed")
    loader = inline[0]
    if (
        _text(heading) != "Scorecard"
        or SHEET_ID not in loader
        or "Alaska Wilderness Action Statement on 2016 National Congressional Scorecard" not in _text(content)
        or "March 8, 2017" not in _text(content)
        or "affiliated but separate organization from Alaska Wilderness League" not in _text(identity)
        or NAME not in _text(contact)
        or script.get("type") != "text/javascript"
    ):
        raise ScorecardSourceError(
            "Alaska Wilderness Action publisher identity, linked sheet or archived offering changed"
        )
    calls = re.findall(r"\.loadSpreadsheet\('([^']+)', (?:false|true)\)", loader)
    if calls != [SHEET_ID, SHEET_ID] or '"order": [[ 3, "desc" ]]' not in loader:
        raise ScorecardSourceError("Alaska Wilderness Action original sheet selection or unfiltered sort changed")
    links = [a["href"] for a in content.find_all("a", href=True)]
    if links != [
        HOME + "wp-content/uploads/2017/03/Merged-Alaska-Scorecard-2017-FINAL.pdf",
        HOME + "scorecard-archive/",
        HOME + "wp-content/uploads/2017/03/AWA-Scorecard-Press-Statement-2017-FINAL.pdf",
    ]:
        raise ScorecardSourceError("Alaska Wilderness Action archived methodology/offering links changed")
    return {
        "archive_custody_url": document.url,
        "original_publisher_url": HOME + "scorecard/",
        "source_sheet_id": SHEET_ID,
        "archived_offering_label": "2016 National Congressional Scorecard",
        "archived_release_label": "March 8, 2017",
        "sheet_period_disclosure": "The linked public sheet itself states no rating period; archived offering is separate context",
        "regions": [
            {"text": _text(node), "html": str(node), "source_path": path}
            for node, path in [
                (header, "#post-41 > header"),
                (content, "#post-41 > .entry-content"),
                (widget, "#text-5 > .textwidget"),
                (identity, "#text-3 > .textwidget"),
                (contact, "#text-2 > .textwidget"),
                (article_footer, "#post-41 > footer"),
                (publisher_footer, "footer.row"),
                (wrapper, "#text-5"),
            ]
        ],
    }


def _renderer(document):
    if (
        document.url != RENDERER
        or document.response.requested_url != RENDERER
        or sha256(document.body).hexdigest() != RENDERER_SHA256
        or (document.response.content_type or "").split(";", 1)[0] not in {"text/javascript", "application/javascript"}
    ):
        raise ScorecardSourceError("Alaska Wilderness Action reviewed original spreadsheet renderer changed")
    return {
        "renderer_url": document.url,
        "renderer_sha256": RENDERER_SHA256,
        "source_path": "outputSpreadsheet(googleSpreadsheet)",
        "native_score_column": "SCOREGOESHERE",
        "publisher_display_score_label": "Total Score",
        "native_current_column": "In Congress?",
        "publisher_display_current_label": "Still In Congress?",
        "renderer_hidden_columns": ["UID", "Congressional District"],
        "renderer_population": "Every feed row; no In Congress? filter",
    }


def _title(document):
    html = _html(document, TITLE)
    _layout(_one(html, "body"), ["div", "div"])
    viewport = _one(html, "#sheets-viewport")
    _layout(viewport, [])
    if html.body.attrs != {"class": ["docs-gm"]} or viewport.attrs != {
        "id": "sheets-viewport",
        "class": ["widget-viewport"],
    }:
        raise ScorecardSourceError("Alaska Wilderness Action native sheet wrapper or notes changed")
    title = _one(html, "title")
    bar = _one(html, "#top-bar")
    name = _one(bar, "#doc-title")
    _layout(bar, ["div"])
    _layout(name, ["span"])
    if _text(title) != "Scorecard - Google Drive" or _text(name) != "Scorecard : Sheet1":
        raise ScorecardSourceError("Alaska Wilderness Action native sheet title or selected worksheet changed")
    return {
        "native_document_title": _text(title),
        "native_sheet_title": _text(name),
        "title_html": str(title),
        "sheet_title_html": str(bar),
        "source_paths": ["title", "#top-bar > #doc-title"],
    }


def _csv(document):
    if document.url != CSV or document.response.requested_url != CSV:
        raise ScorecardSourceError("Alaska Wilderness Action selected native CSV route changed")
    if (document.response.content_type or "").split(";", 1)[0] != "text/csv":
        raise ScorecardSourceError("Alaska Wilderness Action selected sheet answer is not CSV")
    try:
        text = document.body.decode("utf-8-sig")
        rows = list(csv.reader(io.StringIO(text, newline=""), strict=True))
        if tuple(rows[0]) != HEADERS or len(rows) != REVIEWED_ROWS + 1 or any(len(r) != len(HEADERS) for r in rows):
            raise ValueError
        members = rows[1:]
        if any(any(r[8:]) for r in members):
            raise ValueError
        if Counter(r[4] for r in members) != REVIEWED_FLAGS:
            raise ValueError
        ids = [r[5] for r in members if r[5]]
        if len(set(ids)) != len(ids) or len(ids) != REVIEWED_ROWS - REVIEWED_BLANK_IDS:
            raise ValueError
        # A mutable sheet's row order is a locator, not member identity. Require
        # exact source tuples to be unique across every occurrence, including
        # rows with a disclosed UID, before using a tuple for a missing UID.
        identities = [(r[0], r[2], r[6]) for r in members]
        if len(set(identities)) != len(identities):
            raise ValueError
        if any(
            not r[0]
            or not r[1]
            or not r[2]
            or not r[6]
            or not re.fullmatch(r"[+-]?\d+(?:\.\d+)?%", r[3])
            or (r[5] and not re.fullmatch(r"\d+", r[5]))
            for r in members
        ):
            raise ValueError
    except (ValueError, UnicodeError, csv.Error, IndexError):
        raise ScorecardSourceError(
            "Alaska Wilderness Action complete CSV fields, native row cohort or identities changed"
        ) from None
    return rows


def acquire_scorecard(selected, context):
    if selected != EDITION:
        raise ScorecardSourceError("Alaska Wilderness Action requires the exact linked public-sheet rendition")
    choices = (
        ("authority", AUTHORITY, ("web.archive.org",), _authority),
        ("renderer", RENDERER, ("web.archive.org",), _renderer),
        ("sheet-title", TITLE, ("docs.google.com",), _title),
        ("sheet-csv", CSV, ("docs.google.com",), _csv),
    )
    documents, facts = {}, {}
    for name, url, hosts, decode in choices:
        document = context.read(url, stage="awa:" + name + ":source", hosts=hosts)
        documents[name], facts[name] = document, decode(document)
    primary = documents["sheet-csv"]
    bundle = Bundle(
        selected,
        context,
        primary,
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="complete original linked public score-sheet CSV; all native rows/fields, unknown sheet period, archived publisher offering kept separate and exact semantic rereads",
        homepage=HOME,
    )
    bundle.use(primary, "sheet-csv")
    bundle.tables["scorecard_publishers"][0].update(scorecard_index_url=HOME + "scorecard/")
    bundle.tables["scorecards"][0].update(edition_label_text="Scorecard : Sheet1")
    for name in ["authority", "renderer", "sheet-title"]:
        document = documents[name]
        bundle.use(document, name)
        bundle.add(
            "scorecard_methodologies",
            document,
            {"authority": "#post-41", "renderer": "outputSpreadsheet(googleSpreadsheet)", "sheet-title": "#doc-title"}[
                name
            ],
            methodology_id=name,
            methodology_url=document.url,
            methodology_text=json_column(facts[name]),
            disclosure_status="partial",
        )
    bundle.add(
        "scorecard_methodologies",
        primary,
        "csv:record=1",
        methodology_id="native-sheet-columns",
        methodology_url=primary.url,
        methodology_text=json_column(
            {"headers": facts["sheet-csv"][0], "source_path": "csv:record=1", "empty_trailing_columns": [9, 10, 11]}
        ),
        disclosure_status="partial",
    )
    bundle.add(
        "scorecard_metrics",
        primary,
        "csv:record=1;column=4",
        metric_id="reported-total-score",
        name="SCOREGOESHERE",
        value_unit_text="percent",
        methodology_id="renderer",
    )
    for ordinal, values in enumerate(facts["sheet-csv"][1:], 2):
        member_key = (
            key("UID", values[5])
            if values[5]
            else key("native-name-state-district-v1", values[0], values[2], values[6])
        )
        path = "csv:record=" + str(ordinal)
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=member_key,
            publisher_member_id=values[5],
            identifiers_json=json_column(
                [{"scheme": "alaska_wilderness_action_sheet_uid", "value": values[5]}] if values[5] else []
            ),
            member_name=values[0],
            party=values[1],
            state=values[2],
            chamber_text=values[4],
            district=values[6],
            notes_text=json_column(
                {
                    "headers": list(HEADERS),
                    "native_values": values,
                    "field_paths": [path + ";column=" + str(i) for i in range(1, 12)],
                }
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + ";column=4",
            publisher_member_key=member_key,
            metric_id="reported-total-score",
            value_text=values[3],
            value_number=decimal_text(values[3]),
        )
    for name, url, hosts, decode in choices:
        repeat = context.read(url, stage="awa:" + name + ":reread", hosts=hosts)
        if decode(repeat) != facts[name]:
            raise ScorecardSourceError(
                "Alaska Wilderness Action native sheet cells or retained source context changed on reread"
            )
        bundle.use(repeat, name, role="corroboration")
    return bundle.finish(
        "native CSV reaches EOF; exact reviewed row/column cohort, unique disclosedUIDs and exact native name/state/district tuples reconcile; every field including blank flags/IDs/trailing cells retained; original publisher linkage and full sheet wrapper, renderer, native sheet title and completeCSV semantic facts agree on reread"
    )
