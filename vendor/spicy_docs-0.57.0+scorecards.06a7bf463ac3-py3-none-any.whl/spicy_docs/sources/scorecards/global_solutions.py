"""Citizens for Global Solutions' named 2010 original report and disclosed extras."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "global-solutions-2010-qualified-original-pdf/2"
NAME = "Citizens for Global Solutions"
HOSTS = ("web.archive.org",)
ORIGINAL_INDEX = "http://globalsolutions.org/capitol-hill/reportcard/2010"
ORIGINAL_PDF = "http://globalsolutions.org/files/public/documents/reportcard_2010.pdf"
INDEX = "https://web.archive.org/web/20101119043042id_/http://globalsolutions.org:80/capitol-hill/reportcard/2010"
PDF = "https://web.archive.org/web/20101123152630id_/http://globalsolutions.org/files/public/documents/reportcard_2010.pdf"
SOURCE_SHA256 = "2dde060ded8a60601e17afeadeef33937610f9cef55febac72d5e9237e27e6b0"
QUALIFIED_SHA256 = "9fc73aa8bcabe7cd347f1f17af9c42afff966f47b4a19eeeae4c15778e954e08"
PAGE_MEMBERS = {2: 263, 3: 270}
MEMBERS = {"Senate": 100, "House": 433}
ITEMS = {"Senate": 10, "House": 11}
MARKERS = 49
GRADING_CONTEXTS = (
    "weighted-methodology-left",
    "weighted-methodology-continuation",
    "grade-parameters",
    "extra-credit",
    "newly-elected-members",
    "extra-credit-leadership",
)
CONTEXT_IDS = {
    "senate-item-page-footer",
    "house-item-page-footer",
    "senate-key-period-and-weight-key",
    "house-key-period-and-weight-key",
    *GRADING_CONTEXTS,
    "historical-2008-kennedy-memorial-context",
    "2010-legislator-award-context",
    "publisher-about-us",
    "publisher-contact",
    "grade-page-2-footer",
    "grade-page-3-footer",
    "cover",
}
GRADES = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "D-", "F", "I", "S"}
PERIOD = "111th Congress 1st session 2009,\n110th Congress 2nd session 2008 and 1st session 2007"
EDITION = ScorecardEdition(
    "global_solutions",
    "2010-original-report-pdf",
    PDF,
    "CONGRESSIONAL Report Card 2010",
    year="2010",
    chamber="both",
    is_current=False,
)


def list_scorecards(context: ScorecardContext):
    return (EDITION,)


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _index(document):
    if document.url != INDEX or not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("CGS named archived guide custody or complete HTML boundary changed")
    html = soup(document)
    headings = html.select("h1")
    links = html.select('a[href="/files/public/documents/reportcard_2010.pdf"]')
    method, votes = html.select("#block-custom-3"), html.select("#block-custom-2")
    selection = html.select("#block-custom-1")
    if len(headings) != 1 or _text(headings[0]) != "2010 Congressional Report Card" or len(links) != 2:
        raise ScorecardSourceError("CGS original named guide or source-owned complete PDF link changed")
    if len(method) != 1 or len(votes) != 1 or not method[0].select_one('a[name="grades"]'):
        raise ScorecardSourceError("CGS original authored grading and key-vote context changed")
    if len(selection) != 1 or len(selection[0].select("#insufficient")) != 1:
        raise ScorecardSourceError("CGS original guide grade and selection context changed")
    legends = selection[0].select('table[cellpadding="0"][cellspacing="0"]')
    rows = legends[0].find_all("tr") if len(legends) == 1 else []
    codes = []
    for row in rows:
        cells = row.find_all("td", recursive=False)
        if len(cells) != 3 or not _text(cells[2]):
            raise ScorecardSourceError("CGS original guide legend shape changed")
        codes.append(_text(cells[0]))
    if codes != ["+", "-", "S", "A", "N"]:
        raise ScorecardSourceError("CGS original guide legend population changed")
    return {
        "heading": _text(headings[0]),
        "pdf_links": [{"href": node["href"], "text": _text(node)} for node in links],
        "methodology": {"text": _text(method[0]), "html": str(method[0]), "source_path": "#block-custom-3"},
        "key_vote_context": {"text": _text(votes[0]), "html": str(votes[0]), "source_path": "#block-custom-2"},
        # The default original guide has selection controls and issue labels,
        # not a complete member grid. Keep its grade/legend context separately
        # from the independently reviewed PDF ratings.
        "selection_and_legend_context": {
            "text": _text(selection[0]),
            "html": str(selection[0]),
            "source_path": "#block-custom-1",
        },
    }


def _asset(body):
    try:
        asset = json.loads(body)
        if (
            asset["schema_version"] != "global-solutions-published-grade-and-item-facts/1"
            or asset["source_sha256"] != SOURCE_SHA256
            or asset["page_count"] != 6
            or asset["title_text"] != EDITION.title
            or asset["year_text"] != "2010"
        ):
            raise ValueError
        members, items, contexts = asset["members"], asset["items"], asset["contexts"]
        if (
            Counter(row["chamber_text"] for row in members) != MEMBERS
            or Counter(row["page"] for row in members) != PAGE_MEMBERS
            or Counter(row["chamber_text"] for row in items) != ITEMS
            or sum(row["extra_credit_marker_present"] for row in members) != MARKERS
            or len(contexts) != len(CONTEXT_IDS)
            or {c["context_id"] for c in contexts} != CONTEXT_IDS
        ):
            raise ValueError
        seen = set()
        for row in members:
            chamber = row["chamber_text"]
            identity = (chamber, row["state_text"], row["district_text"], row["member_name_text"])
            if (
                identity in seen
                or row["grade_text"] not in GRADES
                or row["party_text"] not in {"R", "D", "I"}
                or not isinstance(row["extra_credit_marker_present"], bool)
                or not row["state_text"]
                or not row["member_name_text"]
                or (chamber == "Senate" and row["district_text"] is not None)
                or (chamber == "House" and not re.fullmatch(r"\d{2}", row["district_text"]))
            ):
                raise ValueError
            seen.add(identity)
        for chamber, count in ITEMS.items():
            selected = [row for row in items if row["chamber_text"] == chamber]
            if [row["publisher_item_id"] for row in selected] != [str(n) + "." for n in range(1, count + 1)]:
                raise ValueError
            for row in selected:
                if (
                    row["weight_text"] not in {"1", "2", "3"}
                    or row["publisher_position_text"] not in {"FOR", "AGAINST"}
                    or not re.fullmatch(r"\d+", row["congress_text"])
                    or not re.fullmatch(r"\d+", row["roll_number_text"])
                    or not row["title_text"]
                    or not row["authored_paragraph_text"]
                    or not row["references"]
                ):
                    raise ValueError
        if (
            any(not c["text"] or not c["source_path"] for c in contexts)
            or not asset["legend_native_text"]
            or not asset["member_footnote_native_text"]
        ):
            raise ValueError
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "CGS reviewed source facts do not establish the complete named original shape"
        ) from None
    return asset


@dataclass(slots=True)
class GlobalSolutionsPDFReader:
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)
    parser_version: ClassVar[str] = parser_version

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, selected: ScorecardEdition, context: ScorecardContext):
        if selected != EDITION:
            raise ScorecardSourceError("CGS caller selection is outside the named original 2010 report")
        index = context.read(INDEX, stage="scorecards:global_solutions:guide", hosts=HOSTS)
        index_facts = _index(index)
        primary = context.read(PDF, stage="scorecards:global_solutions:original-pdf", hosts=HOSTS)
        message = "CGS original report differs from its reviewed bytes or archive custody"
        require_reviewed_pdf(primary, source_url=PDF, source_sha256=SOURCE_SHA256, message=message)
        observation = retain_qualified(
            primary,
            self.qualified_observations,
            self.retain_observations,
            source_sha256=SOURCE_SHA256,
            observations_sha256=QUALIFIED_SHA256,
            stage="scorecards:global_solutions:qualified-2010",
        )
        asset = _asset(self.qualified_observations)
        repeat_index = context.read(INDEX, stage="scorecards:global_solutions:guide-reread", hosts=HOSTS)
        repeat_pdf = context.read(PDF, stage="scorecards:global_solutions:original-pdf-reread", hosts=HOSTS)
        require_reviewed_pdf(repeat_pdf, source_url=PDF, source_sha256=SOURCE_SHA256, message=message)
        if _index(repeat_index) != index_facts:
            raise ScorecardSourceError("CGS complete guide link and authored source context changed during reread")
        bundle = Bundle(
            selected,
            context,
            primary,
            publisher_name=NAME,
            parser_version=parser_version,
            rendition_rule="Named original complete 2010 PDF; literal grades and graphical extra-credit marks, complete weighted source item explanations, separate original HTML methodology observations",
            homepage="http://globalsolutions.org/",
        )
        bundle.use(index, "original-guide-authority", "html-methodology-context")
        bundle.use(primary, "complete-published-grades", "pdf-methodology", "weighted-key-items")
        bundle.use(repeat_index, "original-guide-authority", "html-methodology-context", role="corroboration")
        bundle.use(
            repeat_pdf, "complete-published-grades", "pdf-methodology", "weighted-key-items", role="corroboration"
        )
        bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = ORIGINAL_INDEX

        def located(path):
            return path + ";observation=" + observation

        contexts = {c["context_id"]: c for c in asset["contexts"]}
        periods = [
            {
                "occurrence_id": "report-edition",
                "kind": "explicit",
                "period_text": "2010",
                "year_text": "2010",
                "source_path": located("pdf:page=1;native-cover"),
            }
        ]
        for chamber in ITEMS:
            periods.append(
                {
                    "occurrence_id": chamber.lower() + "-selected-vote-period",
                    "kind": "explicit",
                    "period_text": PERIOD,
                    "chamber_text": chamber,
                    "source_path": located(contexts[chamber.lower() + "-key-period-and-weight-key"]["source_path"]),
                }
            )
        bundle.tables["scorecards"][0].update(
            title=asset["title_text"],
            edition_label_text="2010",
            timespan_text=PERIOD,
            periods_json=json_column(periods),
            source_path=located("pdf:page=1;native-cover"),
            methodology_url=ORIGINAL_PDF,
        )
        for row in asset["contexts"]:
            bundle.add(
                "scorecard_methodologies",
                primary,
                located(row["source_path"]),
                methodology_id=row["context_id"],
                methodology_text=row["text"],
                disclosure_status="explicit source text; no score reproduction",
            )
        bundle.add(
            "scorecard_methodologies",
            primary,
            located("pdf:page=3;native-legend-and-footnote"),
            methodology_id="native-grade-legend-and-extra-credit-footnote",
            methodology_text=json_column(
                {
                    "legend": asset["legend"],
                    "footnotes": asset["member_footnotes"],
                    "native_legend_text": asset["legend_native_text"],
                    "native_member_footnote_text": asset["member_footnote_native_text"],
                }
            ),
            disclosure_status="published grade and graphic mark descriptions; no numeric extra-credit amount",
        )
        grading_contexts = [contexts[name] for name in GRADING_CONTEXTS]
        bundle.add(
            "scorecard_methodologies",
            primary,
            located("pdf:page=6;native-grading-methodology"),
            methodology_id="native-complete-grading-methodology",
            methodology_text=json_column(
                [{"text": row["text"], "source_path": row["source_path"]} for row in grading_contexts]
            ),
            disclosure_status="explicit source paragraph group; no score reproduction",
        )
        bundle.add(
            "scorecard_methodologies",
            index,
            "#block-custom-3",
            methodology_id="original-html-context",
            methodology_text=json_column(
                {
                    **index_facts,
                    "source_custody": [
                        {
                            "original_publisher_url": ORIGINAL_INDEX,
                            "archive_url": INDEX,
                            "archive_timestamp": "20101119043042",
                        },
                        {
                            "original_publisher_url": ORIGINAL_PDF,
                            "archive_url": PDF,
                            "archive_timestamp": "20101123152630",
                        },
                    ],
                }
            ),
            disclosure_status="separate original HTML observation; its 20-vote statement does not replace the PDF's 21-vote methodology",
        )
        for chamber in ITEMS:
            bundle.add(
                "scorecard_metrics",
                primary,
                located("pdf:page=2;" + chamber + ";header=Grade"),
                metric_id=key(chamber, "grade"),
                name="Grade",
                methodology_id="native-complete-grading-methodology",
                chamber_text=chamber,
                period_text=PERIOD,
                periods_json=json_column([p for p in periods if p.get("chamber_text", chamber) == chamber]),
                scale_text=contexts["grade-parameters"]["text"],
            )
        for row in asset["items"]:
            item_id = key(row["chamber_text"], row["publisher_item_id"])
            path = located(row["source_path"])
            references = [{**r, "source_path": located(r["source_path"])} for r in row["references"]]
            bundle.add(
                "scorecard_methodologies",
                primary,
                path,
                methodology_id=key("item", item_id),
                chamber_text=row["chamber_text"],
                methodology_text=row["authored_paragraph_text"],
                disclosure_status="explicit",
            )
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=item_id,
                publisher_item_id=row["publisher_item_id"],
                item_kind_text="Key " + row["chamber_text"] + " Issues",
                title=row["title_text"],
                chamber_text=row["chamber_text"],
                congress_text=row["congress_text"],
                roll_number_text=row["roll_number_text"],
                bill_citation_text=row["bill_citation_text"],
                amendment_citation_text=row["amendment_citation_text"],
                references_json=json_column(references),
                publisher_position_text=row["publisher_position_text"],
                position_basis="explicit",
                position_source_path=path + ";native-supporters-statement",
            )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id=key(row["chamber_text"], "grade"),
                item_id=item_id,
                participation_id="printed-weighted-key-item",
                weight_text="W=" + row["weight_text"],
                weight_number=row["weight_text"],
                counts_toward_metric="true",
                methodology_id=key("item", item_id),
                publisher_position_text=row["publisher_position_text"],
                position_basis="explicit",
            )
        for row in asset["members"]:
            parts = [row["chamber_text"], row["state_text"]]
            if row["district_text"] is not None:
                parts.append(row["district_text"])
            member_key = key(*parts, row["member_name_text"])
            native_path = f"pdf:page={row['page']};native-member={row['source_ordinal']}"
            path = located(native_path)
            bundle.add(
                "scorecard_members",
                primary,
                path,
                publisher_member_key=member_key,
                identifiers_json="[]",
                member_name=row["member_name_text"],
                chamber_text=row["chamber_text"],
                state=row["state_text"],
                district=row["district_text"],
                party=row["party_text"],
                period_text="2010",
                notes_text=json_column(
                    {
                        "extra_credit_marker": {
                            "present": row["extra_credit_marker_present"],
                            "symbol_description": "source CGS logo symbol",
                            "source_path": native_path,
                            "legend_source_path": "pdf:page=3;native-legend",
                        },
                        "literal_asterisk_footnotes": asset["member_footnotes"]
                        if "*" in row["member_name_text"]
                        else [],
                        "footnote_source_path": "pdf:page=3;native-member-footnote"
                        if "*" in row["member_name_text"]
                        else None,
                    }
                ),
            )
            bundle.add(
                "scorecard_member_ratings",
                primary,
                path + ";cell=Grade",
                metric_id=key(row["chamber_text"], "grade"),
                publisher_member_key=member_key,
                value_text=row["grade_text"],
            )
        return bundle.finish(
            "Exact reviewed original PDF and source-owned guide link; every physical source grade row, native party/district/name/grade and graphic mark, complete numbered item paragraphs and source weights/positions, retained private observations and stable original PDF/HTML rereads",
        )


def acquire_scorecard(selected, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("CGS original PDF requires retained, independently qualified source observations")
    return GlobalSolutionsPDFReader(qualified_observations, retain_observations).acquire_scorecard(selected, context)
