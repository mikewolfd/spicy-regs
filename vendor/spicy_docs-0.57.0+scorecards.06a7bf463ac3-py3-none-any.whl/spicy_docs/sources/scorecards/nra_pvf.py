"""NRA-PVF's public election pages: explicitly labelled federal incumbents only."""

import re
from collections import Counter
from datetime import datetime

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    json_data,
    key,
    soup,
)

parser_version = "nra-pvf-public-election-federal-incumbents/2"
INDEX = "https://www.nrapvf.org/Umbraco/api/PublicGradesApi/GetCurrentStates"
HOSTS = ("www.nrapvf.org",)
FEDERAL = {"US-House": "US House", "U-S-House": "U.S House", "US-Senate": "US Senate"}
GRADE = re.compile(r"(?:A[+-]?|AQ|B[+]?|[CDF]|\?)")
ROLE = re.compile(r"(Incumbent|Candidate) \(([^()]+)\)")
DATE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
LEGEND_GRADES = ("A+", "A", "AQ", "B", "C", "D", "F", "?")


def _index(document):
    rows = json_data(document)
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("NRA-PVF current-state discovery is empty or changed")
    names = set()
    for row in rows:
        if (
            not isinstance(row, dict)
            or set(row) != {"name", "election", "date"}
            or not all(isinstance(value, str) and value for value in row.values())
            or not re.fullmatch(r"[A-Za-z]+(?: [A-Za-z]+)*", row["name"])
            or row["election"] != "General"
            or not DATE.fullmatch(row["date"])
            or row["name"] in names
        ):
            raise ScorecardSourceError("NRA-PVF current-state navigation identity or election shape changed")
        try:
            datetime.fromisoformat(row["date"])
        except ValueError as error:
            raise ScorecardSourceError("NRA-PVF navigation date is invalid") from error
        names.add(row["name"])
    return rows


def _edition(row):
    return ScorecardEdition(
        "nra_pvf",
        row["date"][:10]
        + "-"
        + row["election"].lower()
        + "-"
        + row["name"].lower().replace(" ", "-")
        + "-federal-incumbents",
        "https://www.nrapvf.org/grades/" + row["name"].lower().replace(" ", "-"),
        "NRA-PVF Grades and Endorsements: " + row["name"] + " " + row["election"],
        year=row["date"][:4],
    )


def list_scorecards(context: ScorecardContext):
    """Advertised state/election scopes; acquisition separately proves a nonempty cohort."""
    document = context.read(INDEX, stage="scorecards:nra_pvf:index", hosts=HOSTS)
    return tuple(_edition(row) for row in _index(document))


def _one(node, selector):
    found = node.select(selector)
    if len(found) != 1:
        raise ScorecardSourceError("NRA-PVF required source field is missing or repeated: " + selector)
    return found[0]


def _partition(parent, containers, label):
    expected = [id(n) for n in parent.select(".print-candidate")]
    assigned = [id(n) for child in containers for n in child.select(".print-candidate")]
    if sorted(expected) != sorted(assigned):
        raise ScorecardSourceError("NRA-PVF candidate contexts do not partition completely by " + label)


def _page(document, selected):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("NRA-PVF state page does not reach the original HTML document end")
    html = soup(document)
    from bs4 import NavigableString

    state_vars = re.findall(r"var archiveCurrentState = '([^']*)';", document.body.decode("utf-8"))
    header = _one(html, "h1").get_text("", strip=True)
    # North Carolina's acquired heading is &nbsp;; its native script still states the state.
    if state_vars != [selected["name"]] or header not in {"", selected["name"]}:
        raise ScorecardSourceError("NRA-PVF original state identity differs from the selected navigation row")
    container = _one(html, ".elections-container")
    navigation = [(n.get("data-type"), n.get_text("", strip=True)) for n in container.select("ul.nav-tabs > li")]
    if (
        not navigation
        or any(
            code not in {"General", "Special_General"} or code.replace("_", " ") != label for code, label in navigation
        )
        or len({code for code, _ in navigation}) != len(navigation)
        or selected["election"] not in {code for code, _ in navigation}
    ):
        raise ScorecardSourceError("NRA-PVF election navigation changed or exposes an unreviewed election type")
    elections = [_one(container, "#" + code) for code, _ in navigation]
    _partition(html, elections, "advertised election")
    for advertised in elections:
        advertised_groups = advertised.select(".election-group")
        _partition(advertised, advertised_groups, "advertised election group")
        for group in advertised_groups:
            advertised_scopes = group.select(".election-scope-container")
            _partition(group, advertised_scopes, "office scope")
            for scope in advertised_scopes:
                _partition(scope, scope.select(".election-position-container"), "election position")
    election = _one(container, "#" + selected["election"])
    marker = _one(html, ".incumbent_description").get_text("", strip=True)
    if marker != "*=Incumbent":
        raise ScorecardSourceError("NRA-PVF incumbent marker changed")
    legend = _one(html, "#whatGradesMeanModal")
    definitions = []
    for row in legend.select(".what-grades-mean-row"):
        grade = row.select(".what-grades-mean-grade")
        label = _one(row, ".what-grades-mean-label").get_text(" ", strip=True)
        definitions.append({"grade": grade[0].get_text("", strip=True) if len(grade) == 1 else None, "text": label})
    if tuple(row["grade"] for row in definitions) != (None, *LEGEND_GRADES):
        raise ScorecardSourceError("NRA-PVF complete grade/endorsement key changed")
    intro = [_one(legend, ".modal-body > p").get_text(" ", strip=True)]
    disclaimers = [n.get_text(" ", strip=True) for n in election.select(".grades-alert-text")]
    groups = election.select(".election-group")
    advertised_groups = [g for code, _ in navigation for g in _one(container, "#" + code).select(".election-group")]
    if not groups or len(advertised_groups) != len(html.select(".election-group")):
        raise ScorecardSourceError("NRA-PVF election group boundaries changed")
    member_nodes = html.select(".election-group .print-candidate")
    positions = {id(node): i for i, node in enumerate(member_nodes, 1)}
    rows, counts = [], Counter()
    counts["excluded_other_election_contexts"] = len(member_nodes) - len(election.select(".print-candidate"))
    group_facts, identities = [], set()
    for group in groups:
        date = _one(group, ".election-date").get_text(" ", strip=True)
        expected_date = datetime.fromisoformat(selected["date"])
        expected_text = (
            "Election held on "
            + expected_date.strftime("%A, %B ")
            + str(expected_date.day)
            + expected_date.strftime(", %Y")
        )
        if date != expected_text:
            raise ScorecardSourceError("NRA-PVF source election date differs from its current navigation")
        tabs = [
            (n.get("data-scope"), n.get_text("", strip=True), n.get("data-date")) for n in group.select(".related-tab")
        ]
        scopes = group.select(".election-scope-container")
        if (
            not tabs
            or [n.get("id") for n in scopes] != [row[0] for row in tabs]
            or len({row[0] for row in tabs}) != len(tabs)
            or any(not row[2] or not row[2].isdigit() for row in tabs)
            or len({row[2] for row in tabs}) != 1
        ):
            raise ScorecardSourceError("NRA-PVF complete scope tabs and disclosed scope containers differ")
        group_facts.append({"date_text": date, "tabs": tabs})
        for scope, (scope_id, scope_text, date_token) in zip(scopes, tabs, strict=True):
            federal = scope_id in FEDERAL
            if federal and scope_text != FEDERAL[scope_id]:
                raise ScorecardSourceError("NRA-PVF federal scope label differs from its native tab")
            if not federal and re.search(r"\b(?:US|U[. -]S)\b", scope_text, re.IGNORECASE):
                raise ScorecardSourceError("NRA-PVF acquired an unreviewed federal office label")
            offices = scope.select(".election-position-container")
            if not offices:
                raise ScorecardSourceError("NRA-PVF candidate position boundary is incomplete")
            for office in offices:
                office_text = _one(office, ".election-location").get_text(" ", strip=True)
                if federal and not office_text.startswith(scope_text + " - "):
                    raise ScorecardSourceError("NRA-PVF native federal office does not agree with its tab")
                candidates = office.select(".print-candidate")
                if not candidates:
                    raise ScorecardSourceError("NRA-PVF disclosed election position is empty")
                for candidate in candidates:
                    counts["all_candidate_contexts"] += 1
                    if not federal:
                        counts["excluded_nonfederal_contexts"] += 1
                        continue
                    grade = _one(candidate, ".candidate-grade").get_text("", strip=True)
                    name_node = _one(candidate, ".candidate-name")
                    star = _one(name_node, ".asterisk").get_text("", strip=True)
                    name = "".join(str(n) for n in name_node.contents if type(n) is NavigableString).strip()
                    role_text = _one(candidate, ".candidate-incumbent").get_text("", strip=True)
                    role = ROLE.fullmatch(role_text)
                    if (
                        not name
                        or len(name_node.find_all(recursive=False)) != 1
                        or not GRADE.fullmatch(grade)
                        or role is None
                        or star not in {"", "*"}
                        or (role[1] == "Incumbent") != (star == "*")
                    ):
                        raise ScorecardSourceError("NRA-PVF literal federal grade, name or incumbent marker changed")
                    counts["federal_candidate_contexts"] += 1
                    if role[1] != "Incumbent":
                        counts["excluded_federal_challenger_contexts"] += 1
                        continue
                    identity = (date_token, scope_id, office_text, name)
                    if identity in identities:
                        raise ScorecardSourceError("NRA-PVF repeats the same federal-incumbent source identity")
                    identities.add(identity)
                    counts["federal_incumbent_contexts"] += 1
                    endorsed = _one(candidate, ".candidate-endorsed")
                    rows.append(
                        {
                            "key": key(*identity),
                            "name": name,
                            "grade": grade,
                            "party": role[2],
                            "chamber": scope_text,
                            "office": office_text,
                            "district": office_text.removeprefix(scope_text + " - ")
                            if scope_id != "US-Senate"
                            else None,
                            "date": date,
                            "date_token": date_token,
                            "scope_id": scope_id,
                            "role_text": role_text,
                            "marker": star,
                            "endorsement_image_alts": [n.get("alt") for n in endorsed.select("img")],
                            "endorsement_classes": candidate.get("class"),
                            "source_position": positions[id(candidate)],
                        }
                    )
    return {
        "members": rows,
        "counts": dict(counts),
        "groups": group_facts,
        "marker": marker,
        "header": header,
        "definitions": definitions,
        "intro": intro,
        "disclaimers": disclaimers,
    }


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    index = context.read(INDEX, stage="scorecards:nra_pvf:index", hosts=HOSTS)
    states = _index(index)
    selected = [row for row in states if _edition(row) == edition]
    if len(selected) != 1:
        raise ScorecardSourceError("NRA-PVF edition is not an exact advertised current state/election scope")
    selected = selected[0]
    primary = context.read(edition.source_url, stage="scorecards:nra_pvf:state", hosts=HOSTS)
    facts = _page(primary, selected)
    if not facts["members"]:
        raise ScorecardSourceError(
            "NRA-PVF requested state/election has no disclosed federal incumbents; preserve prior scope"
        )
    repeated = context.read(edition.source_url, stage="scorecards:nra_pvf:reread:state", hosts=HOSTS)
    repeated_index = context.read(INDEX, stage="scorecards:nra_pvf:reread:index", hosts=HOSTS)
    if _page(repeated, selected) != facts or _index(repeated_index) != states:
        raise ScorecardSourceError("NRA-PVF complete state/election facts or navigation changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="NRA Political Victory Fund",
        parser_version=parser_version,
        rendition_rule="public state/election HTML; federal office plus explicit Incumbent marker; complete page and navigation reread",
        homepage="https://www.nrapvf.org/",
    )
    bundle.use(index, "current_state_election_navigation")
    bundle.use(repeated_index, "current_state_election_navigation", role="corroboration")
    bundle.use(primary, "federal_incumbent_grades", "grade_methodology")
    bundle.use(repeated, "federal_incumbent_grades", "grade_methodology", role="corroboration")
    periods = json_column(
        [
            {
                "occurrence_id": key("election", str(i)),
                "period_text": row["date_text"],
                "kind": "explicit",
                "year_text": edition.year,
                "source_path": f"(//*[@id='General']//div[@class='election-group']/div[@class='election-date'])[{i}]",
            }
            for i, row in enumerate(facts["groups"], 1)
        ]
    )
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text=selected["name"] + " " + selected["election"],
        periods_json=periods,
    )
    bundle.metric(primary, "grade", "Grade", path="//*[@id='whatGradesMeanModal']", unit="grade", primary=False)
    bundle.tables["scorecard_metrics"][0].update(is_primary=None, methodology_id="grade-key", periods_json=periods)
    bundle.add(
        "scorecard_methodologies",
        primary,
        "//*[@id='whatGradesMeanModal']",
        methodology_id="grade-key",
        methodology_text=json_column(
            {
                "grade_definitions": facts["definitions"],
                "introduction": facts["intro"],
                "incumbent_marker": facts["marker"],
                "election_groups": facts["groups"],
                "previous_election_disclaimers": facts["disclaimers"],
            }
        ),
        disclosure_status="partial",
    )
    for row in facts["members"]:
        path = f"(//div[contains(@class,'election-group')]//div[contains(concat(' ',normalize-space(@class),' '),' print-candidate ')])[{row['source_position']}]"
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=row["key"],
            member_name=row["name"],
            state=selected["name"],
            party=row["party"],
            district=row["district"],
            chamber_text=row["chamber"],
            period_text=row["date"],
            eligibility_text=row["role_text"],
            notes_text=json_column(
                {
                    "office": row["office"],
                    "incumbent_marker": row["marker"],
                    "scope_id": row["scope_id"],
                    "date_token": row["date_token"],
                    "endorsement_image_alts": row["endorsement_image_alts"],
                    "endorsement_classes": row["endorsement_classes"],
                }
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + "/div[contains(@class,'candidate-grade')]",
            publisher_member_key=row["key"],
            metric_id="grade",
            value_text=row["grade"],
        )
    return bundle.finish(
        "Complete advertised state/election HTML through EOF; every tab, office and candidate context accounted for; exact federal-office/Incumbent filter; source facts and navigation agree on reread. This is the publisher-listed election incumbent cohort, not a complete congressional roster.",
        declared={
            "scope_selection": "Publisher-designated federal incumbents contesting this listed state/election",
            "publisher_total_count": None,
            "observed_context_counts": facts["counts"],
        },
    )
