"""National Farmers Union's archived original 2016 state-table scorecard."""

from __future__ import annotations

import json
import re
from collections import Counter

from bs4 import BeautifulSoup, Tag

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key

parser_version = "national-farmers-union-archived-html/1"
HOME = "https://nfu.org/"
ORIGINAL = HOME + "scorecard/"
ARCHIVE_TIMESTAMP = "20250501000640"
ARCHIVE = f"https://web.archive.org/web/{ARCHIVE_TIMESTAMP}id_/{ORIGINAL}"
HOSTS = ("web.archive.org",)
EDITION = ScorecardEdition(
    "national_farmers_union",
    "2016-archived-html",
    ARCHIVE,
    "2016 Congressional Scorecard",
    year="2016",
    chamber="both",
    is_current=False,
)

# These are reviewed publisher table populations, including original omissions,
# duplicate state-context occurrences and the source's unnamed California row.
# They are neither congressional roster counts nor publisher-declared totals.
POPULATIONS = (
    ("Alabama", 2, 7),
    ("Alaska", 2, 1),
    ("Arizona", 2, 9),
    ("Arkansas", 2, 4),
    ("California", 2, 54),
    ("Colorado", 2, 7),
    ("Connecticut", 2, 5),
    ("Delaware", 2, 1),
    ("Florida", 2, 26),
    ("Georgia", 2, 14),
    ("Hawaii", 2, 2),
    ("Idaho", 2, 2),
    ("Illinois", 2, 17),
    ("Indiana", 2, 9),
    ("Iowa", 2, 4),
    ("Kansas", 2, 4),
    ("Kentucky", 2, 6),
    ("Louisiana", 2, 6),
    ("Maine", 2, 2),
    ("Maryland", 1, 8),
    ("Massachusetts", 2, 9),
    ("Michigan", 2, 14),
    ("Minnesota", 2, 8),
    ("Mississippi", 2, 4),
    ("Missouri", 2, 8),
    ("Montana", 2, 1),
    ("Nebraska", 2, 3),
    ("Nevada", 2, 4),
    ("New Hampshire", 2, 2),
    ("New Jersey", 2, 12),
    ("New Mexico", 2, 3),
    ("New York", 2, 26),
    ("North Carolina", 2, 13),
    ("North Dakota", 2, 1),
    ("Ohio", 2, 15),
    ("Oklahoma", 2, 5),
    ("Oregon", 2, 5),
    ("Pennsylvania", 2, 18),
    ("Rhode Island", 2, 2),
    ("South Carolina", 2, 7),
    ("South Dakota", 2, 1),
    ("Tennessee", 2, 9),
    ("Texas", 2, 37),
    ("Utah", 2, 4),
    ("Vermont", 2, 1),
    ("Virginia", 2, 11),
    ("Washington", 2, 10),
    ("West Virginia", 2, 8),
    ("Wisconsin", 2, 4),
    ("Wyoming", 2, 1),
)
HEADERS = {
    "Senate": (
        "Senate Votes",
        "Portman Stabenow Currency Amendment",
        "Thune Estate Tax Amendment",
        "Senate First TPA Vote",
        "Score",
    ),
    "House": ("House Votes", "COOL Repeal", "Commodity End User Relief Act", "Trade Promotion Authority", "Score"),
}
ACTIONS = frozenset({"Voted For", "Voted Against", "Not Voting", "Voting Against"})
COLORS = frozenset({"color: #339966;", "color: #ff0000;", "color: #000000;"})
INTRO = "Click on a state to learn how congress members voted on NFU’s most important issues."
OKLAHOMA_HEADER = (
    "Senate Votes",
    "Portman Stabenow Currency Amendment",
    "Thune Estate",
    "Tax Amendment",
    "Senate First TPA Vote",
    "Score",
)


def _text(tag):
    return " ".join(tag.get_text(" ", strip=True).split())


def _facts(document):
    try:
        soup = BeautifulSoup(document.body.decode("utf-8"), "html.parser")
        if soup.title is None or "2016 Congressional Scorecard" not in _text(soup.title):
            raise ValueError
        areas = soup.select(".entry-content")
        if len(areas) != 1:
            raise ValueError
        area = areas[0]
        headings = [_text(tag) for tag in area.select("h3, h4")]
        if headings != [
            EDITION.title,
            "Click on a state to learn how congress members",
            "voted on NFU’s most important issues.",
        ]:
            raise ValueError
        groups = area.select(".su-spoiler")
        if len(groups) != len(POPULATIONS) or len(area.find_all("table")) != len(groups):
            raise ValueError
        members = []
        headers = []
        native_groups = []
        occurrences = Counter()
        for ordinal, (group, population) in enumerate(zip(groups, POPULATIONS, strict=True)):
            state, senate_count, house_count = population
            titles = group.select(".su-spoiler-title")
            tables = group.select("table")
            if len(titles) != 1 or _text(titles[0]) != state or len(tables) != 1:
                raise ValueError
            chamber = None
            current_header = None
            seen_headers = []
            counts = Counter()
            for row_ordinal, row in enumerate(tables[0].find_all("tr")):
                cells = row.find_all(["td", "th"], recursive=False)
                values = [_text(cell) for cell in cells]
                if not cells:
                    raise ValueError
                if all(cell.name == "th" for cell in cells):
                    matching = [name for name, header in HEADERS.items() if tuple(values) == header]
                    if state == "Oklahoma" and tuple(values) == OKLAHOMA_HEADER:
                        matching = ["Senate"]
                    if len(matching) != 1:
                        raise ValueError
                    chamber = matching[0]
                    seen_headers.append(chamber)
                    current_header = values
                    headers.append(
                        {"state": state, "chamber": chamber, "group": ordinal, "row": row_ordinal, "values": values}
                    )
                    continue
                if chamber is None or any(cell.name != "td" for cell in cells):
                    raise ValueError
                path = f"html:.entry-content/.su-spoiler[{ordinal}]/table/tr[{row_ordinal}]"
                blocks = [(cells, [path + f"/td[{i}]" for i in range(5)], True)]
                if state == "Oklahoma" and chamber == "Senate":
                    # The original has a six-cell split header and one tr with
                    # five Inhofe td cells, a Lankford p label, and four more td
                    # cells. Retain both explicitly labeled blocks, without
                    # inventing an item alignment for this malformed grid.
                    children = [child for child in row.children if isinstance(child, Tag)]
                    if [child.name for child in children] != [
                        *(["td"] * 5),
                        "p",
                        *(["td"] * 4),
                    ] or current_header != list(OKLAHOMA_HEADER):
                        raise ValueError
                    blocks = [
                        (cells[:5], [path + f"/td[{i}]" for i in range(5)], False),
                        (
                            [children[5], *cells[5:]],
                            [path + "/p[0]", *[path + f"/td[{i}]" for i in range(5, 9)]],
                            False,
                        ),
                    ]
                elif len(cells) != 5 or row.find_all("p", recursive=False):
                    raise ValueError
                for block, paths, aligned in blocks:
                    values = [_text(cell) for cell in block]
                    if (
                        not values[0]
                        or not re.fullmatch(r"\d+(?:\.\d+)?%", values[-1])
                        or any(value not in ACTIONS for value in values[1:4])
                    ):
                        raise ValueError
                    styles = []
                    for cell in block[1:4]:
                        spans = cell.find_all("span")
                        if len(spans) != 1 or spans[0].get("style") not in COLORS:
                            raise ValueError
                        styles.append(spans[0]["style"])
                    identity = (state, chamber, values[0])
                    occurrences[identity] += 1
                    members.append(
                        {
                            "state": state,
                            "chamber": chamber,
                            "values": values,
                            "styles": styles,
                            "cell_text": [cell.get_text() for cell in block],
                            "cell_paths": paths,
                            "native_header": current_header,
                            "item_alignment_qualified": aligned,
                            "occurrence": occurrences[identity],
                        }
                    )
                    counts[chamber] += 1
            if seen_headers != ["Senate", "House"] or (counts["Senate"], counts["House"]) != (
                senate_count,
                house_count,
            ):
                raise ValueError
            native_groups.append({"state": state, "senate_rows": senate_count, "house_rows": house_count})
        return {
            "title": _text(soup.title),
            "headings": headings,
            "members": members,
            "groups": native_groups,
            "headers": headers,
        }
    except (UnicodeError, ValueError, TypeError, IndexError):
        raise ScorecardSourceError(
            "NFU archived original cannot establish the complete reviewed state-table rendition"
        ) from None


def list_scorecards(context):
    source = context.read(ARCHIVE, stage="scorecards:national_farmers_union:listing", hosts=HOSTS)
    _facts(source)
    return (EDITION,)


def acquire_scorecard(edition, context):
    if edition != EDITION:
        raise ScorecardSourceError("NFU requested edition is outside the reviewed archived original")
    source = context.read(ARCHIVE, stage="scorecards:national_farmers_union:edition", hosts=HOSTS)
    facts = _facts(source)
    end = context.read(ARCHIVE, stage="scorecards:national_farmers_union:edition-end", hosts=HOSTS)
    if facts != _facts(end):
        raise ScorecardSourceError("NFU archived original source facts changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="National Farmers Union",
        parser_version=parser_version,
        rendition_rule="nfu-original-2016-state-tables-archived-20250501/1",
        homepage=HOME,
    )
    bundle.use(source, "members_and_scores", "scored_items", "member_results", "methodology")
    bundle.use(end, "members_and_scores", "scored_items", "member_results", "methodology", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = ORIGINAL
    bundle.tables["scorecards"][0].update(
        timespan_text="2016",
        methodology_url=source.url,
        periods_json=json.dumps(
            [
                {
                    "occurrence_id": "title",
                    "kind": "explicit",
                    "year_text": "2016",
                    "period_text": EDITION.title,
                    "source_path": "html:.entry-content/h3",
                }
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "html:head/title",
        methodology_id="archive-provenance",
        methodology_text=json.dumps(
            {
                "native_document_title": facts["title"],
                "original_source_url": ORIGINAL,
                "archival_capture_timestamp": ARCHIVE_TIMESTAMP,
                "archival_replay_url": source.url,
            },
            ensure_ascii=False,
        ),
        methodology_url=source.url,
        disclosure_status="Archived original publisher provenance",
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "html:.entry-content/h4",
        methodology_id="native-introduction",
        methodology_text=INTRO,
        methodology_url=source.url,
        disclosure_status="Partial: original introduction; no disclosed formula or color legend",
    )
    for chamber, header in HEADERS.items():
        metric = chamber.lower() + ":score"
        first = next(h for h in facts["headers"] if h["chamber"] == chamber)
        path = f"html:.entry-content/.su-spoiler[0]/table/tr[{first['row']}]"
        bundle.metric(source, metric, header[-1], path=path, chamber=chamber, unit="%")
        for column, title in enumerate(header[1:4], 1):
            item = chamber.lower() + f":column-{column}"
            bundle.add(
                "scorecard_items",
                source,
                path + f"/th[{column}]",
                item_id=item,
                item_kind_text=header[0],
                title=title,
                chamber_text=chamber,
                references_json="[]",
                position_basis="absent",
            )
            bundle.add(
                "scorecard_metric_items",
                source,
                path + f"/th[{column}]",
                metric_id=metric,
                item_id=item,
                participation_id="source-column",
                position_basis="absent",
            )
    for header in facts["headers"]:
        bundle.add(
            "scorecard_methodologies",
            source,
            f"html:.entry-content/.su-spoiler[{header['group']}]/table/tr[{header['row']}]",
            methodology_id=f"native-header-{header['group']}-{header['chamber'].lower()}",
            methodology_text=json.dumps(
                {"native_state_heading": header["state"], "native_header_cells": header["values"]}, ensure_ascii=False
            ),
            methodology_url=source.url,
            disclosure_status="Original publisher table header; Oklahoma Senate alignment remains unqualified"
            if header["state"] == "Oklahoma" and header["chamber"] == "Senate"
            else "Original publisher table header",
        )
    for member in facts["members"]:
        state, chamber, values = member["state"], member["chamber"], member["values"]
        member_key = key(state, chamber, values[0], str(member["occurrence"]))
        paths = member["cell_paths"]
        party = re.search(r"\(([^()]*)\)", values[0])
        name = re.sub(r"^(?:Sen\.|Rep\.)\s+", "", values[0]).split(", (")[0]
        notes = {
            "native_member_label": values[0],
            "native_state_heading": state,
            "native_cells": values,
            "native_cell_text": member["cell_text"],
            "native_action_styles": member["styles"],
            "native_occurrence": member["occurrence"],
            "native_header_cells": member["native_header"],
            "native_cell_paths": paths,
            "item_alignment_qualified": member["item_alignment_qualified"],
        }
        bundle.add(
            "scorecard_members",
            source,
            paths[0],
            publisher_member_key=member_key,
            member_name=name,
            state=state,
            party=party[1] if party else None,
            chamber_text=chamber,
            identifiers_json="[]",
            notes_text=json.dumps(notes, ensure_ascii=False),
        )
        metric = chamber.lower() + ":score"
        bundle.add(
            "scorecard_member_ratings",
            source,
            paths[4],
            metric_id=metric,
            publisher_member_key=member_key,
            value_text=values[-1],
            value_number=decimal_text(values[-1]),
        )
        for column, action in enumerate(values[1:4], 1) if member["item_alignment_qualified"] else ():
            bundle.add(
                "scorecard_member_item_results",
                source,
                paths[column],
                metric_id=metric,
                item_id=chamber.lower() + f":column-{column}",
                participation_id="source-column",
                publisher_member_key=member_key,
                result_id="native-cell",
                action_text=action,
                result_text=action,
            )
    return bundle.finish(
        "All reviewed original state groups and all explicit member labels, ratings, native headers and action cells retained; the unambiguous item grids are parsed, while the malformed Oklahoma Senate grid remains literal member notes with typed item alignment unqualified. Source populations reconcile and all selected facts are stable on reread. This is the original 2016 HTML rendition archived on 2025-05-01; omissions, placeholders and contradictions remain without an invented official roster, preferred-position legend or formula.",
    )
