"""21Wilberforce's reviewed revised 116th Congress original PDF rendition."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.interpretation.citations import BILL_NUMBER_PATTERN
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "wilberforce-qualified-116-revised-pdf/1"
INDEX = "https://irfscorecard.org/"
ORIGINAL = "https://irfscorecard.org/wp-content/uploads/2021/05/2021_IRFSC_5.12.21-1.pdf"
SOURCE_SHA256 = "9e84482f20eb60963edbb83b8926772380b480c362f6c0c4853c65faa932e877"
QUALIFIED_SHA256 = "63f44a3e9ee21d751a9dd4d4ab727a4aba60a9bb0808cfa5eafb62c9d080ac52"
EDITION = ScorecardEdition(
    "wilberforce",
    "116-revised-5.12.21-pdf",
    "https://web.archive.org/web/20210628002821id_/" + ORIGINAL,
    "116th CONGRESS INTERNATIONAL RELIGIOUS FREEDOM CONGRESSIONAL SCORECARD",
    congress="116",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = dict(zip(range(36, 51), (29, 65, 39, 43, 25, 31, 43, 24, 39, 48, 33, 21, 55, 33, 20), strict=True))
ITEM_ORDINALS = {"SENATE": tuple(range(1, 18)) + tuple(range(22, 38)), "HOUSE": tuple(range(1, 55))}
CONTEXT_COUNT = 63
GROUP_COUNTS = {"SENATE": 3, "HOUSE": 6}
ACTION_CODES = (
    ("Y", "VOTED YES", "1"),
    ("CS", "COSPONSOR", "1"),
    ("OCS", "ORIGINAL COSPONSOR", "2"),
    ("PS", "PRIMARY SPONSOR", "2"),
    ("CA", "CONGRESSIONAL ADVOCATE-POC", "1"),
    ("M", "CAUCUS MEMBERSHIP", "1"),
    ("C-C", "CO-CHAIR", "2"),
)
METHOD_SCOPES = (
    "introduction-and-source-statistics",
    "source-methodology",
    "publisher-about",
    "source-grid-notes-and-exclusions",
    "notable-leaders",
)
BILLS = re.compile(BILL_NUMBER_PATTERN)


@dataclass(frozen=True, slots=True)
class WilberforcePDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=EDITION.source_url,
        source_sha256=SOURCE_SHA256,
        message="Wilberforce PDF differs from its reviewed complete original archive rendition",
    )


def list_scorecards(context):
    _source(context.read(EDITION.source_url, stage="scorecards:wilberforce:listing", hosts=("web.archive.org",)))
    return (EDITION,)


def _evidence(evidence):
    blocks = evidence["native_blocks"]
    if (
        evidence["source_label"] != "pdf-content"
        or evidence["offset_basis"]
        != "unicode_characters_in_original_defaultreader_native_block_lines_joined_by_newline"
        or type(evidence["source_ordinal"]) is not int
        or evidence["source_ordinal"] < 0
        or not blocks
        or evidence["physical_pages"] != sorted({block["physical_page"] for block in blocks})
        or any(
            type(block["physical_page"]) is not int
            or not 1 <= block["physical_page"] <= 51
            or type(block["native_block"]) is not int
            or block["native_block"] < 0
            or not block["text"]
            or not block["lines"]
            for block in blocks
        )
    ):
        raise ValueError


def _facts(body):
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "wilberforce-116-revised-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["page_count"] != 51
            or data["metadata"]["title_text"] != EDITION.title
            or data["metadata"]["publisher_text"] != "A PROJECT OF 21WILBERFORCE"
            or data["metadata"]["period_text"] != "January 2019 through December 2020"
            or tuple(
                tuple(row[field] for field in ("code_text", "action_text", "points_text"))
                for row in data["action_codes"]
            )
            != ACTION_CODES
        ):
            raise ValueError
        _evidence(data["metadata"]["period_evidence"])
        if re.sub(r"\s+", "", data["metadata"]["period_text"]) not in re.sub(
            r"\s+", "", data["metadata"]["period_evidence"]["native_blocks"][0]["text"]
        ):
            raise ValueError
        counts = Counter()
        for entry in data["members"]:
            record, ev = entry["record"], entry["evidence"]
            _evidence(ev)
            page = ev["physical_pages"][0]
            if (
                len(ev["physical_pages"]) != 1
                or page not in PAGE_MEMBERS
                or ev["source_ordinal"] != counts[page]
                or not record["member_name_text"]
                or not record["state_text"]
                or record["chamber_text"] not in ITEM_ORDINALS
                or record["party_text"] not in {None, "D", "R", "I", "DEMOCRATS", "REPUBLICANS", "LIBERTARIAN"}
                or not re.fullmatch(r"\d+|N/A", record["score_text"])
                or not re.fullmatch(r"[ABCDF][+-]?|N/A", record["grade_text"])
                or (
                    record["exclusion_marker_text"] is not None
                    and not re.fullmatch(r"\(\d+\)", record["exclusion_marker_text"])
                )
            ):
                raise ValueError
            counts[page] += 1
        if dict(counts) != PAGE_MEMBERS:
            raise ValueError
        for chamber, ordinals in ITEM_ORDINALS.items():
            entries = [entry for entry in data["items"] if entry["record"]["chamber_text"] == chamber]
            if tuple(entry["record"]["ordinal"] for entry in entries) != ordinals:
                raise ValueError
            for i, entry in enumerate(entries):
                _evidence(entry["evidence"])
                record = entry["record"]
                if (
                    entry["evidence"]["source_ordinal"] != i
                    or not record["title_text"]
                    or not record["description_text"]
                    or not record["native_item_text"]
                    or not BILLS.fullmatch(record["bill_citation_text"])
                ):
                    raise ValueError
        if len(data["items"]) != sum(map(len, ITEM_ORDINALS.values())):
            raise ValueError
        if dict(Counter(row["record"]["chamber_text"] for row in data["groups"])) != GROUP_COUNTS:
            raise ValueError
        for i, entry in enumerate(data["groups"]):
            _evidence(entry["evidence"])
            if (
                entry["evidence"]["source_ordinal"] != i
                or not entry["record"]["title_text"]
                or not entry["record"]["description_text"]
            ):
                raise ValueError
        if tuple(entry["record"]["scope_text"] for entry in data["methodology"]) != METHOD_SCOPES:
            raise ValueError
        for i, entry in enumerate(data["methodology"]):
            _evidence(entry["evidence"])
            if entry["evidence"]["source_ordinal"] != i:
                raise ValueError
        context = data["methodology"][-1]["record"]["context_entries"]
        if len(context) != CONTEXT_COUNT:
            raise ValueError
        for i, entry in enumerate(context):
            _evidence(entry["evidence"])
            if (
                entry["evidence"]["source_ordinal"] != i
                or entry["evidence"]["physical_pages"] != [8]
                or not entry["record"]["source_literal_text"]
            ):
                raise ValueError
        gap = data["source_discrepancies"][0]
        if (
            gap["declared_count"] != 37
            or gap["authored_count"] != 33
            or gap["undisclosed_ordinals"] != [18, 19, 20, 21]
        ):
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        raise ScorecardSourceError("Wilberforce facts fail the complete reviewed original PDF shape") from None


def _locator(entry, observation, pointer):
    return f"pdf:pages={','.join(map(str, entry['evidence']['physical_pages']))};observation={observation};{pointer}"


def _references(entry, observation):
    references, occurrences = [], []
    for block in entry["evidence"]["native_blocks"]:
        loc = f"pdf:page={block['physical_page']};observation={observation};native_block={block['native_block']}"
        for match in BILLS.finditer(block["text"]):
            occurrence_id = "native-bill-" + str(len(references))
            references.append(
                {
                    "occurrence_id": occurrence_id,
                    "kind": "bill",
                    "citation_text": match[0],
                    "bill_citation_text": match[0],
                    "source_path": loc,
                }
            )
            occurrences.append(
                {
                    "occurrence_id": occurrence_id,
                    "citation_text": match[0],
                    "physical_page": block["physical_page"],
                    "native_block": block["native_block"],
                    "start": match.start(),
                    "end": match.end(),
                    "offset_basis": "unicode_characters_in_original_defaultreader_native_block_lines_joined_by_newline",
                }
            )
    return references, occurrences


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Wilberforce PDF requires its reviewed named edition and privately retained native facts"
        )
    source = context.read(edition.source_url, stage="scorecards:wilberforce:pdf", hosts=("web.archive.org",))
    _source(source)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="wilberforce:qualified-116-revised",
    )
    facts = _facts(qualified_observations)
    end = context.read(edition.source_url, stage="scorecards:wilberforce:pdf-end", hosts=("web.archive.org",))
    _source(end)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="21Wilberforce",
        parser_version=parser_version,
        rendition_rule="wilberforce-116-reviewed-revised-pdf-only/1",
        homepage="https://21wilberforce.org/",
    )
    bundle.use(
        source, "members_and_ratings", "legislative_narratives", "group_contexts", "methodology", "notable_leaders"
    )
    bundle.use(
        end,
        "edition",
        "members_and_ratings",
        "legislative_narratives",
        "group_contexts",
        "methodology",
        role="corroboration",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    card = bundle.tables["scorecards"][0]
    card["methodology_url"] = ORIGINAL
    card["edition_label_text"] = facts["metadata"]["title_text"]
    card["timespan_text"] = facts["metadata"]["period_text"]
    card["periods_json"] = json.dumps(
        [
            {
                "occurrence_id": "native-period-0",
                "kind": "explicit",
                "period_text": card["timespan_text"],
                "source_path": "pdf:page=9;observation=" + observation + ";/metadata/period_text",
            }
        ]
    )
    for i, entry in enumerate(facts["methodology"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            _locator(entry, observation, f"/methodology/{i}"),
            methodology_id=entry["record"]["scope_text"],
            methodology_text=json.dumps(entry, ensure_ascii=False),
            methodology_url=ORIGINAL,
            disclosure_status=entry["record"]["scope_text"],
        )
    bundle.add(
        "scorecard_methodologies",
        source,
        "pdf:page=10;observation=" + observation + ";/action_codes",
        methodology_id="action-codes",
        methodology_text=json.dumps(facts["action_codes"], ensure_ascii=False),
        methodology_url=ORIGINAL,
        disclosure_status="Literal conditional action points; not per-item weights or a universal reproduction formula",
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "pdf:pages=4,13,14,18,49;observation=" + observation + ";/source_discrepancies",
        methodology_id="source-discrepancies",
        methodology_text=json.dumps(facts["source_discrepancies"], ensure_ascii=False),
        methodology_url=ORIGINAL,
        disclosure_status="Measured original-PDF disclosure differences; source values unchanged",
    )
    for chamber in ITEM_ORDINALS:
        for measure in ("Score", "Grade"):
            bundle.metric(
                source,
                key(chamber, measure),
                measure,
                path="pdf:pages=36,37,38,39,40,41,42,43,44,45,46,47,48,49,50;observation="
                + observation
                + ";/grid-headings",
                chamber=chamber,
                unit="points" if measure == "Score" else None,
            )
            metric = bundle.tables["scorecard_metrics"][-1]
            metric.update(
                is_primary=None,
                methodology_id="source-methodology",
                period_text=facts["metadata"]["period_text"],
                scale_text=("90 points" if chamber == "SENATE" else "134 points") if measure == "Score" else None,
            )
    for i, entry in enumerate([*facts["items"], *facts["groups"]]):
        record = entry["record"]
        legislative = i < len(facts["items"])
        chamber = record["chamber_text"]
        item_id = (
            key(chamber, str(record["ordinal"]))
            if legislative
            else key(chamber, "group", str(entry["evidence"]["source_ordinal"]))
        )
        loc = _locator(
            entry,
            observation,
            ("/items/" if legislative else "/groups/") + str(i if legislative else i - len(facts["items"])),
        )
        references, occurrences = _references(entry, observation)
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=str(record["ordinal"]) if legislative else None,
            item_kind_text="SCORED ITEMS" if legislative else "HUMAN RIGHTS AND RELIGIOUS FREEDOM GROUPS",
            title=record["title_text"],
            chamber_text=chamber,
            bill_citation_text=record.get("bill_citation_text"),
            references_json=json.dumps(references, ensure_ascii=False),
        )
        method_id = key("item", item_id)
        bundle.add(
            "scorecard_methodologies",
            source,
            loc,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_text=json.dumps(dict(**entry, citation_occurrences=occurrences), ensure_ascii=False),
            methodology_url=ORIGINAL,
            disclosure_status="Literal original legislative narrative"
            if legislative
            else "Literal group description; no inferred individual membership or point award",
        )
        if legislative:
            bundle.add(
                "scorecard_metric_items",
                source,
                loc,
                metric_id=key(chamber, "Score"),
                item_id=item_id,
                participation_id="publisher-numbered-scored-item",
                methodology_id=method_id,
                counts_toward_metric="true",
            )
    for i, entry in enumerate(facts["members"]):
        record, ev = entry["record"], entry["evidence"]
        identity = key(record["chamber_text"], str(ev["physical_pages"][0]), str(ev["source_ordinal"]))
        loc = _locator(entry, observation, f"/members/{i}")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            party=record["party_text"],
            chamber_text=record["chamber_text"],
            notes_text=json.dumps(
                {"exclusion_marker_text": record["exclusion_marker_text"], "native_evidence": ev}, ensure_ascii=False
            ),
        )
        for measure, value_field in (("Score", "score_text"), ("Grade", "grade_text")):
            value = record[value_field]
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + "/record/" + value_field,
                publisher_member_key=identity,
                metric_id=key(record["chamber_text"], measure),
                value_text=value,
                value_number=decimal_text(value) if measure == "Score" else None,
                value_status_text="N/A" if value == "N/A" else None,
            )
    return bundle.finish(
        "Complete reviewed original PDF, all physical pages/native occurrences and declared-count gaps retained; exact stable reread. Website member action ledger remains a separate unqualified rendition.",
        declared={
            "Senate legislative scored items": 37,
            "House legislative scored items": 54,
            "Senate possible points": 90,
            "House possible points": 134,
        },
    )
