"""Drum Major Institute's visible 2005 original PDF, including covered-layer refusal."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "drum-major-2005-qualified-visible-pdf/1"
ORIGINAL_URL = "http://www.drummajorinstitute.org:80/pdfs/DMI%202005%20Scorecard.pdf"
SOURCE_URL = "https://web.archive.org/web/20060822204435id_/" + ORIGINAL_URL
SOURCE_SHA256 = "f20bfab6359526257e85950ccea3cf2bc1551b7716604cb1fee9f72a19f6adbd"
QUALIFIED_SHA256 = "23b0c318700fe28c583534acb34ad49f662b7fcafa10b7956572208799013f96"
TITLE = "Congress at the Midterm: Their 2005 Middle-Class Record"
EDITION = ScorecardEdition(
    "drum_major", "2005-original-pdf", SOURCE_URL, TITLE, year="2005", chamber="both", is_current=False
)
PAGE_LAYOUT = (
    (10, "right", 17, "Senate", 34),
    (11, "left", 18, "Senate", 34),
    (11, "right", 19, "Senate", 32),
    *((n, side, n * 2 - 4 + (side == "right"), "House", 34) for n in range(12, 18) for side in ("left", "right")),
    (18, "left", 32, "House", 27),
)
NARRATIVE_LINKS = {"Senate": (5, 6, 8, 10, 11, 12, 13, 14), "House": (6, 7, 8, 9, 10, 11, 12, 15)}
GLYPHS = frozenset(("✓", "✗", "—", ""))


@dataclass(frozen=True, slots=True)
class DrumMajor2005Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URL,
        source_sha256=SOURCE_SHA256,
        message="DMI 2005 original PDF differs from its reviewed complete visible rendition",
    )


def list_scorecards(context):
    source = context.read(SOURCE_URL, stage="scorecards:drum_major:2005:named-edition", hosts=("web.archive.org",))
    _source(source)
    return [EDITION]


def _facts(body):
    try:
        data = json.loads(body)
        assert set(data) == {
            "format_version",
            "source_sha256",
            "physical_page_count",
            "title_text",
            "year_text",
            "publisher_name_text",
            "pages",
            "items",
            "method",
            "narratives",
            "source_contexts",
            "visible_source_rule",
            "observation_differences",
        }
        assert data["format_version"] == "drum-major-2005-qualified-visible-source-facts/1"
        assert data["source_sha256"] == SOURCE_SHA256 and data["physical_page_count"] == 21
        assert data["title_text"] == TITLE and data["year_text"] == "2005"
        assert data["publisher_name_text"] == "Drum Major Institute for Public Policy"
        assert len(data["pages"]) == len(PAGE_LAYOUT)
        for page, (number, side, printed, chamber, count) in zip(data["pages"], PAGE_LAYOUT, strict=True):
            assert (page["physical_page"], page["side"], page["printed_page"], page["chamber_text"]) == (
                number,
                side,
                printed,
                chamber,
            )
            assert page["score_column_heading_text"] == "SCORE" and page["grade_column_heading_text"] == "GRADE"
            assert isinstance(page["native_range_heading"], str) and page["native_range_heading"].strip()
            assert len(page["items"]) == 8 and len(page["members"]) == count
            for header in page["items"]:
                assert all(isinstance(header[f], str) and header[f].strip() for f in ("title_text", "citation_text"))
                assert header["preferred_position_text"] in ("YES", "NO")
            for ordinal, member in enumerate(page["members"], 1):
                assert member["ordinal"] == ordinal and len(member["result_glyph_texts"]) == 8
                assert all(v in GLYPHS for v in member["result_glyph_texts"])
                assert member["party_text"] in ("D", "R", "I") and re.fullmatch(r"[A-Z]{2}", member["state_text"])
                assert isinstance(member["member_name_text"], str) and member["member_name_text"].strip()
                assert re.fullmatch(r"[0-9]+", member["score_text"]) or member["score_text"] in ("INC", "INC.", "")
                assert member["grade_text"] in ("A", "B", "C", "D", "F", "INC", "INC.", "")
                assert isinstance(member["native_member_cell_text"], str) and member["native_member_cell_text"].strip()
                assert len(member["native_cells"]) == 12 and all(
                    isinstance(c["authored_text"], str) for c in member["native_cells"]
                )
        assert Counter(p["chamber_text"] for p in data["pages"] for _ in p["members"]) == Counter(
            {"Senate": 100, "House": 435}
        )
        assert [(n["printed_page"], n["physical_page"], n["side"]) for n in data["narratives"]] == [
            (p, (p + 4) // 2, "right" if p % 2 else "left") for p in range(5, 16)
        ]
        for narrative in data["narratives"]:
            assert narrative["native_spans"] and narrative["native_event_spans"] and narrative["citation_spans"]
            assert all(
                isinstance(s["display_text"], str) and isinstance(s["native_text"], str)
                for s in narrative["native_spans"]
            )
            assert isinstance(narrative["title_text"], str) and narrative["title_text"].strip()
            assert narrative["publisher_position_label_text"] in (
                "The Middle Class Supports",
                "The Middle Class Opposes",
            )
            metadata = narrative["image_factual_metadata"]
            assert not metadata["uncertainties"] and metadata["title_text"] == narrative["title_text"]
            assert metadata["publisher_position_label_text"] == narrative["publisher_position_label_text"]
        expected_contexts = [
            (n, side)
            for n in range(2, 22)
            for side in ("left", "right")
            if not 17 <= n * 2 - 4 + (side == "right") <= 32 and (n, side) != (21, "right")
        ]
        assert [(c["physical_page"], c["side"]) for c in data["source_contexts"]] == expected_contexts
        assert all(
            c["native_spans"] and all(isinstance(s["display_text"], str) for s in c["native_spans"])
            for c in data["source_contexts"]
        )
        method = data["method"]
        assert len(method["native_methodology_paragraphs"]) == 3 and all(
            p["native_text"].strip() for p in method["native_methodology_paragraphs"]
        )
        assert len(method["grade_legend"]) == 5 and len(method["item_headers"]) == 16
        assert len(method["aggregate_item_ratings"]) == 48 and len(method["aggregate_grade_distributions"]) == 12
        assert [(i["chamber_text"], i["ordinal"], i["narrative_printed_page"]) for i in data["items"]] == [
            (chamber, n, p)
            for chamber, printed_pages in NARRATIVE_LINKS.items()
            for n, p in enumerate(printed_pages, 1)
        ]
        for item in data["items"]:
            page = next(p for p in data["pages"] if p["chamber_text"] == item["chamber_text"])
            assert item["first_grid_header"] == page["items"][item["ordinal"] - 1]
            narrative = next(n for n in data["narratives"] if n["printed_page"] == item["narrative_printed_page"])
            assert item["narrative_title_text"] == narrative["title_text"]
            assert item["narrative_citation_text"] == narrative["image_factual_metadata"]["citation_text"]
        assert data["visible_source_rule"]["glyph_display"] == {
            "source_font": "MonotypeSorts",
            "U+0013": "✓",
            "U+0017": "✗",
            "basis": "Original rendered method legend and original glyph IDs/occurrence pixels; not an official action conversion",
        }
        assert all(
            isinstance(v, str) and v.strip() for k, v in data["visible_source_rule"].items() if k != "glyph_display"
        )
        return data
    except (AssertionError, KeyError, TypeError, ValueError, StopIteration):
        raise ScorecardSourceError(
            "DMI 2005 qualified observations omit or alter the reviewed visible source shape"
        ) from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("Unknown DMI edition; 2007 has separate shapes and rules")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("DMI 2005 requires pinned private source observations and retention")
    source = context.read(SOURCE_URL, stage="scorecards:drum_major:2005:original", hosts=("web.archive.org",))
    _source(source)
    repeated = context.read(SOURCE_URL, stage="scorecards:drum_major:2005:original-reread", hosts=("web.archive.org",))
    _source(repeated)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="scorecards:drum_major:2005:qualified-visible-source-facts",
    )
    data = _facts(qualified_observations)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=data["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="Complete visible archived DMI 2005 member grids, source methodology, item explanations and all native contextual prose; older covered grid excluded by original paint-order evidence",
        homepage="http://www.drummajorinstitute.org/",
    )
    groups = ("members", "ratings", "items", "item-results", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")

    def loc(page, side, path):
        return f"pdf:page={page};side={side};observation={observation}{path}"

    def dump(value):
        return json.dumps(value, ensure_ascii=False)

    card = bundle.tables["scorecards"][0]
    card["methodology_url"] = source.url
    card["periods_json"] = dump(
        [
            {
                "occurrence_id": "source-year",
                "kind": "explicit",
                "period_text": data["year_text"],
                "year_text": data["year_text"],
                "source_path": loc(1, "cover", "/title"),
            }
        ]
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(10, "left", "/how-this-works"),
        methodology_id="how-this-works",
        methodology_text=dump(
            {
                "native_methodology": data["method"],
                "source_visible_rule": data["visible_source_rule"],
                "original_publisher_url": ORIGINAL_URL,
                "archive_replay_url": SOURCE_URL,
            }
        ),
        methodology_url=source.url,
        disclosure_status="Explicit original methodology, grade legend and chamber/party assessments; no score reproduction",
    )
    for ctx in data["source_contexts"]:
        page, side = ctx["physical_page"], ctx["side"]
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(page, side, "/native-source-context"),
            methodology_id=f"source-context:{page}:{side}",
            methodology_text=dump(ctx),
            methodology_url=source.url,
            disclosure_status="Complete authored native explanatory, expert, background and forward-looking source spans; image-only artwork remains private source evidence",
        )
    for chamber in ("Senate", "House"):
        page = next(p for p in data["pages"] if p["chamber_text"] == chamber)
        for column, heading_field in (("score", "score_column_heading_text"), ("grade", "grade_column_heading_text")):
            bundle.add(
                "scorecard_metrics",
                source,
                loc(page["physical_page"], page["side"], "/" + heading_field),
                metric_id=key(chamber, column),
                methodology_id="how-this-works",
                name=page[heading_field],
                chamber_text=chamber,
                period_text=data["year_text"],
                is_primary=None,
            )
    for item in data["items"]:
        chamber, ordinal = item["chamber_text"], item["ordinal"]
        identity = key(chamber, str(ordinal))
        page = next(p for p in data["pages"] if p["chamber_text"] == chamber)
        path = loc(page["physical_page"], page["side"], f"/items/{ordinal - 1}")
        head = item["first_grid_header"]
        refs = []
        for occurrence in (p for p in data["pages"] if p["chamber_text"] == chamber):
            citation = occurrence["items"][ordinal - 1]["citation_text"]
            refs.append(
                {
                    "occurrence_id": f"grid:{occurrence['printed_page']}",
                    "kind": "amendment" if citation.startswith("SA ") else "bill",
                    "citation_text": citation,
                    "source_path": loc(
                        occurrence["physical_page"], occurrence["side"], f"/items/{ordinal - 1}/citation_text"
                    ),
                }
            )
        refs.append(
            {
                "occurrence_id": "overview",
                "kind": "publisher-citation",
                "citation_text": item["overview_header"]["citation_text"],
                "source_path": loc(10, "left", f"/item_headers/{chamber}/{ordinal}"),
            }
        )
        narrative = next(n for n in data["narratives"] if n["printed_page"] == item["narrative_printed_page"])
        refs.append(
            {
                "occurrence_id": "narrative",
                "kind": "publisher-citation",
                "citation_text": item["narrative_citation_text"],
                "source_path": loc(narrative["physical_page"], narrative["side"], "/citation_spans"),
            }
        )
        citation = head["citation_text"]
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=identity,
            publisher_item_id=str(ordinal),
            item_kind_text="HOW DID THE " + chamber.upper() + " VOTE?",
            title=head["title_text"],
            chamber_text=chamber,
            bill_citation_text=None if citation.startswith("SA ") else citation,
            amendment_citation_text=citation if citation.startswith("SA ") else None,
            references_json=dump(refs),
            publisher_position_text=head["preferred_position_text"],
            position_basis="explicit",
            position_source_path=path + "/preferred_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "score"),
            item_id=identity,
            participation_id="source-column",
            methodology_id="how-this-works",
            publisher_position_text=head["preferred_position_text"],
            position_basis="explicit",
            counts_toward_metric="true",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(narrative["physical_page"], narrative["side"], "/native-spans"),
            methodology_id="item:" + identity,
            chamber_text=chamber,
            methodology_text=dump(
                {
                    "original_narrative": narrative,
                    "overview_header": item["overview_header"],
                    "grid_header_occurrences": [
                        {
                            "physical_page": p["physical_page"],
                            "side": p["side"],
                            "printed_page": p["printed_page"],
                            "native_range_heading": p["native_range_heading"],
                            "header": p["items"][ordinal - 1],
                        }
                        for p in data["pages"]
                        if p["chamber_text"] == chamber
                    ],
                }
            ),
            methodology_url=source.url,
            disclosure_status="Complete located explanation and metadata, repeated native headers and citation spellings; no inferred roll calls or single vote date",
        )
    for page in data["pages"]:
        chamber, number, side = page["chamber_text"], page["physical_page"], page["side"]
        for member in page["members"]:
            ordinal = member["ordinal"]
            identity = key(chamber, f"printed-page={page['printed_page']}", f"row={ordinal}")
            path = loc(number, side, f"/members/{ordinal - 1}")
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=identity,
                member_name=member["member_name_text"],
                state=member["state_text"],
                party=member["party_text"],
                chamber_text=chamber,
                period_text=data["year_text"],
                notes_text=dump(
                    {
                        "native_member_cell_text": member["native_member_cell_text"],
                        "native_cells": member["native_cells"],
                        "native_range_heading": page["native_range_heading"],
                    }
                ),
            )
            for column in ("score", "grade"):
                value = member[column + "_text"]
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    path + "/" + column + "_text",
                    metric_id=key(chamber, column),
                    publisher_member_key=identity,
                    value_text=value,
                    value_number=value if column == "score" and re.fullmatch(r"[0-9]+", value) else None,
                    value_status_text=value if value in ("INC", "INC.") else None,
                )
            for n, glyph in enumerate(member["result_glyph_texts"], 1):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + f"/result_glyph_texts/{n - 1}",
                    result_id="source-cell",
                    item_id=key(chamber, str(n)),
                    publisher_member_key=identity,
                    result_text=glyph,
                )
    return bundle.finish(
        "The exact complete 21-physical-page original and stable reread match qualified visible source facts. All printed member grids, ordered comparison glyphs, SCORE/GRADE columns, repeated headers, original method and complete native narrative/context spans reconcile with independent PDF paint/text enumeration, structured image observations and a separate Ovis check. Covered earlier text is retained privately rather than emitted as visible members.",
        declared={"source_printed_senate_pages": "17–19", "source_printed_house_pages": "20–32"},
    )
