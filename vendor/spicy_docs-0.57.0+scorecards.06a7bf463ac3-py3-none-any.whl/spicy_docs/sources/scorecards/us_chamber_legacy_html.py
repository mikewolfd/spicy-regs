"""Named Chamber legacy HTML grids, including continuation tables and source conflicts."""

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.us_chamber_html import CITATION, ORIGIN, STATE_HEADINGS, original

parser_version = "us-chamber-named-legacy-html/1"
HOSTS = ("web.archive.org",)
TIMESTAMPS = {
    "2007": {"house": "20160204090210", "senate": "20160204090003"},
    "2008": {"house": "20161121233025", "senate": "20160204085940"},
    "2009": {"house": "20161121234310", "senate": "20160204090408"},
    "2010": {"house": "20161121233550", "senate": "20160204090342"},
}
PREFIXES = {
    ("2007", "house"): ["Alabama", "", "", ""],
    ("2007", "senate"): ["Alabama", ""],
    ("2008", "house"): ["ALABAMA"],
    ("2008", "senate"): ["ALABAMA"],
    ("2009", "house"): ["", "", "", ""],
    ("2009", "senate"): ["", "", "", "", ""],
    ("2010", "house"): ["Dist", "Member of Congress", "P", "State"],
    ("2010", "senate"): ["", "", ""],
}
SCORE_HEADERS = {
    "2007": ["2007%", "Cum %"],
    "2008": ["'08 %", "Cum %"],
    "2009": ["2009%", "2009 Cum"],
    "2010": ["2010%", "Culm %"],
}
TOKENS = {
    "+": '"Correct" vote, supporting the Chamber\'s position',
    "-": '"Wrong" vote, contrary to the Chamber\'s position',
    "?": "No recorded vote",
    "S": "Speaker did not vote",
    "P": 'Voted "present"',
}
NOTE = "Note: The percentage calculations were made using only + and - votes. The ?, S, and P votes were not included in the calculations."
CITATIONS = re.compile(CITATION.pattern, re.IGNORECASE)


def source_url(year, chamber):
    return "https://web.archive.org/web/" + TIMESTAMPS[year][chamber] + "id_/" + original(year, chamber)


def edition(year):
    return ScorecardEdition(
        "us_chamber",
        year,
        original(year, "house"),
        "How They Voted " + year,
        year=year,
        chamber="both",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return tuple(edition(year) for year in sorted(TIMESTAMPS, reverse=True))


def _one(element, selector):
    matches = element.select(selector)
    if len(matches) != 1:
        raise ScorecardSourceError("Chamber legacy source structure missing or repeated: " + selector)
    return matches[0]


def _values(row):
    return [cell.get_text(" ", strip=True) for cell in row.find_all("td", recursive=False)]


def _legend(year):
    # These are source statements, including the copied 2008 text in later editions.
    stated_year = "2007" if year == "2007" else "2008"
    annual = (
        "Percentage of correct votes of total cast by member on Chamber-selected issues during "
        + stated_year
        + ", the second session of the 110th Congress."
    )
    cumulative = (
        "Average annual percentage of correct votes cast by member on Chamber-selected issues since the Chamber began rating members in 1965, or since that member's first year in Congress, through "
        + stated_year
        + "."
    )
    sixth = (
        ["*", "Seat vacant on date of the vote"]
        if year == "2007"
        else ["", ""]
        if year == "2008"
        else ["N/A", "Insufficient votes cast"]
    )
    seventh = ["NA", "Insufficient votes cast", ""] if year == "2007" else ["", "", ""]
    return [
        ["+", TOKENS["+"], "'" + stated_year[-2:] + "%", annual],
        ["-", TOKENS["-"]],
        ["?", TOKENS["?"], "CUM%", cumulative],
        ["S", TOKENS["S"]],
        ["P", TOKENS["P"]],
        [*sixth, "", NOTE],
        seventh,
    ]


def _items(body, numbers, year):
    paragraphs = body.find_all("p", recursive=False)
    if year == "2010":
        paragraph = _one(body, 'a[id="bottom"]').find_parent("p")
        lines = paragraph.get_text("\n", strip=True).splitlines()
        result = []
        for line in lines:
            match = re.fullmatch(r"(\d+)\. (.+)", line)
            if match is None:
                raise ScorecardSourceError("Chamber legacy literal item title changed")
            result.append(
                {"number": match[1], "title": match[2], "narrative_text": line, "narrative_html": str(paragraph)}
            )
        if [i["number"] for i in result] != numbers:
            raise ScorecardSourceError("Chamber legacy source item inventory is incomplete")
        return result
    anchors = body.select("a[id]")
    if [a.get("id") for a in anchors] != numbers:
        raise ScorecardSourceError("Chamber legacy item anchors do not reconcile with every source column")
    starts = []
    for anchor in anchors:
        paragraph = anchor.find_parent("p")
        if paragraph not in paragraphs:
            raise ScorecardSourceError("Chamber legacy item anchor left its complete narrative")
        starts.append(paragraphs.index(paragraph))
    if starts != sorted(set(starts)):
        raise ScorecardSourceError("Chamber legacy item narrative boundaries are repeated or reordered")
    result = []
    for offset, number in enumerate(numbers):
        segment = paragraphs[starts[offset] : starts[offset + 1] if offset + 1 < len(starts) else len(paragraphs)]
        titles = [
            strong.get_text(" ", strip=True)
            for paragraph in segment
            for strong in paragraph.select("strong")
            if re.match(r"\(" + number + r"\)\s*\S", strong.get_text(" ", strip=True))
        ]
        if len(titles) != 1:
            raise ScorecardSourceError("Chamber legacy numbered narrative title is missing or repeated")
        result.append(
            {
                "number": number,
                "title": re.sub(r"^\(" + number + r"\)\s*", "", titles[0]),
                "narrative_text": "\n".join(p.get_text("\n", strip=True) for p in segment),
                "narrative_html": "".join(str(p) for p in segment),
            }
        )
    return result


def _identity(metadata, year, chamber, state):
    state_code = district = None
    if year == "2007":
        if chamber == "house":
            district, last, first, party = metadata
            name = last + ", " + first if first else last
        else:
            name, party = metadata
    elif year == "2008":
        pattern = r"(\d+\.|AL)\s+(.+) (\([RDI]\))" if chamber == "house" else r"(.+) (\([RDI]\))"
        match = re.fullmatch(pattern, metadata[0])
        if match is None:
            raise ScorecardSourceError("Chamber combined legacy member identity shape changed")
        if chamber == "house":
            district = match[1].removesuffix(".")
            name, party = match[2], match[3]
        else:
            name, party = match[1], match[2]
    elif year == "2009":
        if chamber == "house":
            district, name, party, state_code = metadata
        else:
            source_row_number, last, first, party, state_code = metadata
            if source_row_number and not source_row_number.isdigit():
                raise ScorecardSourceError("Chamber unlabeled Senate numeric source column changed")
            name = last + ", " + first if first else last
    elif chamber == "house":
        district, name, party, state_code = metadata
    else:
        name, party, state_code = metadata
    if (
        not name
        or party not in {"R", "D", "I", "(R)", "(D)", "(I)"}
        or (district is not None and not re.fullmatch(r"\d+|AL", district))
        or (state_code is not None and not re.fullmatch(r"[A-Z]{2}", state_code))
    ):
        raise ScorecardSourceError("Chamber literal legacy name, party, state or district changed")
    return {
        "name": name,
        "state": state_code or state,
        "district": district,
        "party": party,
        "key": key(chamber, state_code or state, district or "no-district", name),
    }


def _page(document, year, chamber):
    custody = re.fullmatch(
        r"https://web\.archive\.org/web/(\d{14})id_/(https://www\.uschamber\.com/[^?#]+)", document.url
    )
    if (
        custody is None
        or custody[2] != original(year, chamber)
        or document.response.requested_url != source_url(year, chamber)
    ):
        raise ScorecardSourceError("Chamber legacy capture left its selected original route")
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Chamber complete legacy HTML trailer is missing")
    html = soup(document)
    if _one(html, "link[rel='canonical']").get("href") != original(year, chamber):
        raise ScorecardSourceError("Chamber legacy canonical original identity changed")
    title = "How They Voted " + year + " - " + chamber.title()
    if title not in [h.get_text(" ", strip=True) for h in html.select("h1")]:
        raise ScorecardSourceError("Chamber legacy edition/chamber heading changed")
    body = _one(html, ".field-name-body .field-item")
    paragraphs = body.find_all("p", recursive=False)
    prelude = [p.get_text(" ", strip=True) for p in paragraphs[:2]]
    if (
        len(prelude) != 2
        or not prelude[0].startswith("Each " + chamber.title() + " vote used in the ratings is described separately")
        or prelude[1] != "Key to Symbols"
    ):
        raise ScorecardSourceError("Chamber legacy source attribution changed")
    if body.select("select, input, [class*='pager'], [class*='pagination']"):
        raise ScorecardSourceError("Chamber legacy grid exposes an unreviewed filter or page")
    tables = body.find_all("table", recursive=False)
    expected_tables = 3 if chamber == "house" and year != "2007" else 2
    if len(tables) != expected_tables or len(body.select("table")) != expected_tables:
        raise ScorecardSourceError("Chamber complete legacy table/continuation inventory changed")
    legend = [_values(r) for r in tables[0].select("tr")]
    if legend != _legend(year):
        raise ScorecardSourceError("Chamber legacy literal legend or period statement changed")
    rows = tables[1].select("tr")
    if not rows:
        raise ScorecardSourceError("Chamber complete legacy grid is empty")
    headings = _values(rows[0])
    prefix = PREFIXES[(year, chamber)]
    offset = len(prefix)
    numbers = headings[offset:-2]
    if (
        headings[:offset] != prefix
        or headings[-2:] != SCORE_HEADERS[year]
        or not numbers
        or numbers != [str(n) for n in range(1, len(numbers) + 1)]
    ):
        raise ScorecardSourceError("Chamber legacy source grid column shape changed")
    for number, cell in zip(numbers, rows[0].find_all("td", recursive=False)[offset:-2], strict=True):
        anchors = cell.select("a")
        if len(anchors) != 1 or anchors[0].get("href") != ("#bottom" if year == "2010" else "#" + number):
            raise ScorecardSourceError("Chamber legacy source column/item link changed")
    items = _items(body, numbers, year)
    state = prefix[0] if year in {"2007", "2008"} else None
    state_heading = state
    states = [state] if state else []
    members = []
    seen = set()
    expected_states = []
    for source_state in STATE_HEADINGS:
        expected_states.append(source_state.title() if year == "2007" else source_state)
        if year == "2008" and chamber == "house" and source_state in {"CALIFORNIA", "FLORIDA", "OHIO"}:
            expected_states.append(source_state + " (cont.)")
    allowed_tokens = set(TOKENS) | {""} | ({"*"} if year == "2007" else set())
    for table_number, table in enumerate(tables[1:], 2):
        for ordinal, row in enumerate(table.select("tr"), 1):
            if table_number == 2 and ordinal == 1:
                continue
            cells = row.find_all("td", recursive=False)
            values = _values(row)
            filled = [v for v in values if v]
            if len(values) != len(headings) or any(c.get("rowspan") or c.get("colspan") for c in cells):
                raise ScorecardSourceError("Chamber legacy member/state row is incomplete")
            if len(filled) == 1 and filled[0] in expected_states:
                state_heading = filled[0]
                if state_heading.endswith(" (cont.)"):
                    if state_heading.removesuffix(" (cont.)") != state:
                        raise ScorecardSourceError("Chamber source continuation lost its preceding state context")
                else:
                    state = state_heading
                states.append(state_heading)
                continue
            if state is None:
                raise ScorecardSourceError("Chamber legacy member row lacks its state context")
            member = _identity(values[:offset], year, chamber, state)
            if member["key"] in seen:
                raise ScorecardSourceError("Chamber legacy source member context is repeated")
            seen.add(member["key"])
            outcomes = values[offset:-2]
            scores = values[-2:]
            if any(v not in allowed_tokens for v in outcomes) or any(
                decimal_text(s) is None and s not in {"", "NA", "N/A", "n/a"} for s in scores
            ):
                raise ScorecardSourceError("Chamber legacy source result or rating shape changed")
            member.update(
                metadata=values[:offset],
                state_heading=state_heading,
                outcomes=outcomes,
                scores=scores,
                table=str(table_number),
                row=str(ordinal),
            )
            members.append(member)
    if not members or states != expected_states:
        raise ScorecardSourceError("Chamber complete legacy state/member inventory is missing")
    return {
        "title": title,
        "prelude": prelude,
        "headings": headings,
        "score_headers": headings[-2:],
        "legend": legend,
        "states": states,
        "members": members,
        "items": items,
        "legend_html": str(tables[0]),
        "custody": {"original_publisher_url": custody[2], "archive_url": document.url, "archive_timestamp": custody[1]},
    }


def _references(item, path):
    references = []
    for match in CITATIONS.finditer(item["title"]):
        citation = match[0]
        kind = (
            "nomination" if citation.lower().startswith("pn") else "amendment" if "amdt" in citation.lower() else "bill"
        )
        reference = {
            "occurrence_id": key("title", str(match.start())),
            "citation_text": citation,
            "kind": kind,
            "source_path": path,
        }
        if kind == "bill":
            reference["bill_citation_text"] = citation
        elif kind == "amendment":
            reference["amendment_citation_text"] = citation
        references.append(reference)
    return references


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    year = selected.edition_id
    if year not in TIMESTAMPS or selected != edition(year):
        raise ScorecardSourceError("Chamber selection is outside the named legacy HTML editions")
    documents = {}
    pages = {}
    repeats = {}
    for chamber in ("house", "senate"):
        documents[chamber] = context.read(
            source_url(year, chamber), stage="us-chamber-legacy-html:" + chamber, hosts=HOSTS
        )
        pages[chamber] = _page(documents[chamber], year, chamber)
    for chamber in ("house", "senate"):
        repeats[chamber] = context.read(
            source_url(year, chamber), stage="us-chamber-legacy-html:" + chamber + "-repeat", hosts=HOSTS
        )
        repeated = _page(repeats[chamber], year, chamber)
        if {k: v for k, v in repeated.items() if k != "custody"} != {
            k: v for k, v in pages[chamber].items() if k != "custody"
        }:
            raise ScorecardSourceError("Chamber complete legacy native source changed on reread")
    bundle = Bundle(
        selected,
        context,
        documents["house"],
        publisher_name="U.S. Chamber of Commerce",
        parser_version=parser_version,
        rendition_rule="Named original archived legacy HTML; all source continuation grids, ratings, item declarations and literal narrative/legend conflicts.",
        homepage=ORIGIN,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = ORIGIN + "/how-they-voted"
    bundle.tables["scorecards"][0].update(
        edition_label_text=selected.title,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "edition-year",
                    "period_text": year,
                    "kind": "explicit",
                    "year_text": year,
                    "source_path": "h1",
                }
            ]
        ),
    )
    for chamber, page in pages.items():
        document = documents[chamber]
        bundle.use(document, chamber + "-grid")
        bundle.use(repeats[chamber], chamber + "-grid", role="corroboration")
        path = ".field-name-body .field-item"
        method_id = key(chamber, "legacy-grid")
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=method_id,
            methodology_url=original(year, chamber),
            chamber_text=chamber.title(),
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_title": page["title"],
                    "literal_prelude": page["prelude"],
                    "literal_grid_headers": page["headings"],
                    "literal_state_headings": page["states"],
                    "source_custody": page["custody"],
                    "literal_legend_rows": page["legend"],
                    "literal_legend_html": page["legend_html"],
                    "literal_item_narratives": page["items"],
                    "observations": "The legend's literal 2007 second-session statement and copied 2008 year/Congress statements in 2009/2010 are retained, without repairing them or assigning item Congress/session. Numeric year/cumulative scores remain publisher values. No universal reproduction, source item weight, exact metric participation or official action is inferred. Narrative support/opposition is retained in full, without converting general policy prose into a vote-specific Y/N target. Unlabeled identity columns retain their positional source values; party parentheses and header spelling survive.",
                }
            ),
        )
        for position, header in enumerate(page["score_headers"]):
            bundle.metric(
                document,
                key(chamber, "year" if position == 0 else "cumulative"),
                header,
                path=path + " table:nth-of-type(2) tr:first-child",
                chamber=chamber.title(),
                unit="%",
                primary=position == 0,
            )
            bundle.tables["scorecard_metrics"][-1].update(
                methodology_id=method_id, period_text=year if position == 0 else page["legend"][2][3], periods_json="[]"
            )
        for item in page["items"]:
            item_path = path + "/item-declaration/" + item["number"]
            refs = _references(item, item_path)
            bundle.add(
                "scorecard_items",
                document,
                item_path,
                item_id=key(chamber, item["number"]),
                publisher_item_id=item["number"],
                item_kind_text="roll_call",
                title=item["title"],
                chamber_text=chamber.title(),
                references_json=json_column(refs),
                bill_citation_text=next((r["bill_citation_text"] for r in refs if r["kind"] == "bill"), None),
                amendment_citation_text=next(
                    (r["amendment_citation_text"] for r in refs if r["kind"] == "amendment"), None
                ),
            )
        for member in page["members"]:
            row_path = path + " table:nth-of-type(" + member["table"] + ") tr:nth-child(" + member["row"] + ")"
            bundle.add(
                "scorecard_members",
                document,
                row_path,
                publisher_member_key=member["key"],
                identifiers_json="[]",
                member_name=member["name"],
                chamber_text=chamber.title(),
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text=year,
                notes_text=json_column(
                    {
                        "literal_source_identity_columns": member["metadata"],
                        "literal_state_heading": member["state_heading"],
                        "literal_identity_headers": page["headings"][: len(member["metadata"])],
                        "identity_rule": "Exact named-edition source fields; surname plus first name where separately stated, party including parentheses, combined district prefix where supplied; the unlabeled Senate numeric column is not an external identifier.",
                    }
                ),
            )
            for position, literal in enumerate(member["scores"]):
                value = "N/A" if literal in {"NA", "N/A", "n/a"} else literal
                bundle.add(
                    "scorecard_member_ratings",
                    document,
                    row_path + "/rating/" + str(position + 1),
                    metric_id=key(chamber, "year" if position == 0 else "cumulative"),
                    publisher_member_key=member["key"],
                    value_text=value,
                    value_number=decimal_text(value),
                    value_status_text=value if value in {"", "N/A"} else None,
                    notes_text=json_column(
                        {"literal_source_value": literal, "literal_source_column": page["score_headers"][position]}
                    ),
                )
            for item, outcome in zip(page["items"], member["outcomes"], strict=True):
                reason = TOKENS.get(
                    outcome,
                    "Seat vacant on date of the vote"
                    if outcome == "*"
                    else "Blank source cell; its meaning and eligibility are not disclosed.",
                )
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    row_path + "/item/" + item["number"],
                    item_id=key(chamber, item["number"]),
                    publisher_member_key=member["key"],
                    result_id="native-grid",
                    result_text=outcome,
                    reason_text=reason,
                )
    return bundle.finish(
        "Both named original archived HTML documents reached their final trailer. Every continuation table was parsed in source order, the full literal state sequence and rectangular member rows reconcile with every numbered item column/narrative, and complete source facts agree on independent reread. Source conflicts and absent values remain visible.",
        declared={
            "publisher_declared_counts": None,
            "observed_complete_html_chambers": {
                ch: {"members": len(p["members"]), "state_headings": len(p["states"]), "items": len(p["items"])}
                for ch, p in pages.items()
            },
        },
    )
