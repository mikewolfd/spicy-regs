"""Drug Policy Action's named archived 2016 complete House grade list."""

import re
from urllib.parse import parse_qs, urljoin, urlsplit

from bs4 import Comment

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "drug-policy-action-archived-house-grades/2"
NAME = "Drug Policy Action"
ORIGIN = "http://www.drugpolicyaction.org/"
ORIGINAL_INDEX = ORIGIN + "voter-guide/"
ORIGINAL_LIST = ORIGINAL_INDEX + "list.php"
INDEX = "https://web.archive.org/web/20161030093405id_/http://www.drugpolicyaction.org:80/voter-guide/"
LIST = "https://web.archive.org/web/20161031223355id_/http://www.drugpolicyaction.org:80/voter-guide/list.php"
HOSTS = ("web.archive.org",)
TITLE = "Drug Policy Action Congressional Voter Guide"
BANNER = "2016 Marijuana Reform Matters"
GRADES = ("A", "B", "C", "D", "F", "I")
# Observed complete named original, not a publisher-declared or official roster count.
# The private source qualification pins every card and source-owned list link.
REVIEWED_ROWS = 432
FROM = re.compile(r"Representative from ([A-Za-z ]+)'s? (\d+)(st|nd|rd|th) District")


def edition():
    return ScorecardEdition(
        "drug_policy_action",
        "2016-house-all-representatives-archived-html",
        LIST,
        TITLE,
        year="2016",
        chamber="house",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return (edition(),)


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("Drug Policy Action native field is missing or repeated: " + selector)
    return nodes[0]


def _layout(node, expected):
    actual = [(child.name, tuple(child.get("class", ()))) for child in node.children if getattr(child, "name", None)]
    # Structural containers have no authored direct text in the reviewed original.
    # A new exclusion note must refuse rather than silently disappear; comments
    # are not visible source notes and whitespace is ordinary formatting.
    direct_text = [child for child in node.children if isinstance(child, str) and not isinstance(child, Comment)]
    allowed_attributes = {"class", "href"} if node.name == "a" else {"class"}
    if actual != expected or any(str(child).strip() for child in direct_text) or set(node.attrs) - allowed_attributes:
        raise ScorecardSourceError("Drug Policy Action native card exposes unreviewed fields or notes")


def _html(document, url):
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("Drug Policy Action archive custody escaped the selected original")
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Drug Policy Action archived HTML is incomplete")
    html = soup(document)
    _one(html, "html")
    _one(html, "body")
    if html.select("[class*='pagination'], [class*='pager'], [data-next-page]"):
        raise ScorecardSourceError("Drug Policy Action named original exposes an unreviewed partial population")
    return html


def _shared(html):
    logo = _one(html, ".header-logos > a")
    if logo.get("href") != ORIGIN or "Drug Policy Action" not in _text(logo):
        raise ScorecardSourceError("Drug Policy Action original publisher attribution changed")
    banner = [str(x).strip() for x in logo.parent.children if isinstance(x, str) and str(x).strip()]
    if banner != [BANNER]:
        raise ScorecardSourceError("Drug Policy Action named 2016 edition label changed")
    modal = _one(html, ".grades-modal")
    inner = _one(modal, ".inner-container")
    _layout(modal, [("div", ("inner-container",))])
    _layout(inner, [("div", ("logo-wide",)), ("h2", ())] + [("div", ("grade-wrapper",))] * len(GRADES))
    heading = _one(modal, "h2")
    wrappers = modal.select(".grade-wrapper")
    if _text(heading) != "Grading Criteria:" or len(wrappers) != len(GRADES):
        raise ScorecardSourceError("Drug Policy Action complete grading criteria changed")
    # The original structural grade wrappers carry only their class. Unknown
    # attributes there are not copied into emitted paragraph HTML, so refuse
    # them as possible explanatory content rather than claiming a full snapshot.
    if modal.select("[title], [aria-label], [data-tooltip], [style]"):
        raise ScorecardSourceError("Drug Policy Action grading exposes unreviewed attribute notes")
    definitions = []
    for number, wrapper in enumerate(wrappers, 1):
        _layout(wrapper, [("div", ("grade-medium",)), ("p", ())])
        _layout(_one(wrapper, ".grade-medium"), [("span", ("grade-sym",))])
        glyph = _text(_one(wrapper, ".grade-sym"))
        explanation = _one(wrapper, "p")
        if glyph != GRADES[number - 1] or not _text(explanation):
            raise ScorecardSourceError("Drug Policy Action native grade inventory or explanation changed")
        definitions.append(
            {
                "grade": glyph,
                "text": _text(explanation),
                "html": str(explanation),
                "source_path": f".grades-modal .grade-wrapper:nth-of-type({number + 1}) > p",
            }
        )
    about = _one(html, ".about-dpa-text")
    paragraphs = about.find_all("p", recursive=False)
    copyright_node = _one(html, ".copyright")
    if (
        len(paragraphs) != 2
        or not all(_text(p) for p in paragraphs)
        or "Drug Policy Action" not in _text(copyright_node)
    ):
        raise ScorecardSourceError("Drug Policy Action complete publisher context changed")
    return {
        "banner": banner[0],
        "publisher_logo_text": _text(logo),
        "grading_heading": _text(heading),
        "grading": definitions,
        "about": [
            {"text": _text(p), "html": str(p), "source_path": f".about-dpa-text > p:nth-of-type({n})"}
            for n, p in enumerate(paragraphs, 1)
        ],
        "copyright": {"text": _text(copyright_node), "html": str(copyright_node), "source_path": ".copyright"},
    }


def _index(document):
    html = _html(document, INDEX)
    shared = _shared(html)
    title = _one(html, ".header-copy > h1")
    intro = _one(html, ".header-copy > p")
    all_links = html.select('a[href="list.php"]')
    senate = html.select('a[href="senators.php"]')
    if _text(title) != TITLE or len(all_links) != 1 or len(senate) != 1 or not _text(intro):
        raise ScorecardSourceError("Drug Policy Action source-owned complete list route or guide context changed")
    if not _text(all_links[0]).startswith("View All Representatives"):
        raise ScorecardSourceError("Drug Policy Action source-owned list scope changed")
    senate_parent = senate[0].parent
    return {
        **shared,
        "title": _text(title),
        "intro": {"text": _text(intro), "html": str(intro), "source_path": ".header-copy > p"},
        "all_representatives": {
            "text": _text(all_links[0]),
            "href": all_links[0]["href"],
            "source_path": 'a[href="list.php"]',
        },
        "senate_reference": {
            "text": _text(senate_parent),
            "html": str(senate_parent),
            "href": senate[0]["href"],
            "source_path": 'a[href="senators.php"]/..',
        },
    }


def _list(document):
    html = _html(document, LIST)
    shared = _shared(html)
    container = _one(html, ".rep-list")
    heading = _one(container, "h1")
    cards = container.find_all("div", class_="rep-list-row", recursive=False)
    if (
        _text(heading) != "All Representatives"
        or len(cards) != REVIEWED_ROWS
        or len(cards) != len(html.select(".rep-list-row"))
    ):
        raise ScorecardSourceError("Drug Policy Action complete All Representatives population changed")
    if container.select("form, select, input, button, [hidden], .rep-list-row .rep-list-row"):
        raise ScorecardSourceError("Drug Policy Action full list exposes an unreviewed filter or hidden population")
    members, identities, labels = [], set(), set()
    for ordinal, card in enumerate(cards, 1):
        _layout(card, [("a", ("image",)), ("div", ("profile",)), ("div", ("grade-small",))])
        _layout(_one(card, ".profile"), [("a", ("name-link",)), ("br", ()), ("span", ("from",))])
        _layout(_one(card, ".grade-small"), [("span", ("grade-sym",)), ("br", ()), ("span", ("grade-cap",))])
        _layout(_one(card, ".name-link"), [("span", ("name",))])
        _layout(_one(card, "a.image"), [("img", ())])
        if card.select("[title], [aria-label], [data-tooltip], [style]"):
            raise ScorecardSourceError("Drug Policy Action native card exposes unreviewed attribute notes")
        anchors = card.select("a[href]")
        name = _one(card, ".profile .name-link .name")
        from_node = _one(card, ".profile .from")
        grade = _one(card, ".grade-small .grade-sym")
        label = _one(card, ".grade-small .grade-cap")
        image = _one(card, "a.image > img")
        if len(anchors) != 2 or anchors[0].get("href") != anchors[1].get("href"):
            raise ScorecardSourceError("Drug Policy Action repeated native member links disagree")
        href = anchors[1]["href"]
        parsed = urlsplit(href)
        try:
            query = parse_qs(parsed.query, strict_parsing=True)
        except ValueError as error:
            raise ScorecardSourceError("Drug Policy Action native member query is malformed") from error
        identity = query.get("bioguide_id", [])
        if (
            parsed.path != "legislator.php"
            or parsed.scheme
            or parsed.netloc
            or parsed.fragment
            or set(query) != {"bioguide_id", "list"}
            or query["list"] != ["1"]
            or len(identity) != 1
            or not re.fullmatch(r"[A-Z]\d{6}", identity[0])
            or identity[0] in identities
        ):
            raise ScorecardSourceError("Drug Policy Action source bioguide_id context is malformed or repeated")
        native_from = _text(from_node)
        match = FROM.fullmatch(native_from)
        if not match or not _text(name) or _text(grade) not in GRADES or not image.get("src"):
            raise ScorecardSourceError("Drug Policy Action native identity or literal grade shape changed")
        labels.add(_text(label))
        path = f".rep-list > .rep-list-row:nth-of-type({ordinal})"
        members.append(
            {
                "id": identity[0],
                "name": _text(name),
                "state": match[1],
                "district": match[2],
                "from": native_from,
                "from_html": str(from_node),
                "href": href,
                "image_src": image["src"],
                "grade": _text(grade),
                "grade_label": _text(label),
                "path": path,
            }
        )
        identities.add(identity[0])
    if labels != {"Grade"}:
        raise ScorecardSourceError("Drug Policy Action native measurement label changed")
    return {**shared, "heading": _text(heading), "members": members}


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition():
        raise ScorecardSourceError("Drug Policy Action selection is outside the named archived House grade rendition")
    index = context.read(INDEX, stage="scorecards:drug_policy_action:index", hosts=HOSTS)
    primary = context.read(LIST, stage="scorecards:drug_policy_action:all-representatives", hosts=HOSTS)
    index_facts, facts = _index(index), _list(primary)
    if index_facts["grading"] != facts["grading"] or index_facts["about"] != facts["about"]:
        raise ScorecardSourceError("Drug Policy Action complete list and guide methodology disagree")
    index_repeat = context.read(INDEX, stage="scorecards:drug_policy_action:index-reread", hosts=HOSTS)
    primary_repeat = context.read(LIST, stage="scorecards:drug_policy_action:all-representatives-reread", hosts=HOSTS)
    if _index(index_repeat) != index_facts or _list(primary_repeat) != facts:
        raise ScorecardSourceError(
            "Drug Policy Action native grades, identities or complete authored context changed on reread"
        )
    bundle = Bundle(
        selected,
        context,
        primary,
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="Named original archived All Representatives grade list; complete native static House cards, not undisclosed profile action grids or Senate grades",
        homepage=ORIGIN,
    )
    bundle.use(index, "guide-attribution", "source-list-link", "guide-grading-context")
    bundle.use(primary, "all-representatives", "list-grading-context")
    bundle.use(index_repeat, "guide-attribution", "source-list-link", "guide-grading-context", role="corroboration")
    bundle.use(primary_repeat, "all-representatives", "list-grading-context", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = ORIGINAL_INDEX
    periods = [
        {
            "occurrence_id": "edition-banner",
            "kind": "explicit",
            "period_text": BANNER,
            "year_text": "2016",
            "source_path": ".header-logos/text()",
        }
    ]
    bundle.tables["scorecards"][0].update(
        title=index_facts["title"],
        edition_label_text=BANNER,
        timespan_text=BANNER,
        periods_json=json_column(periods),
        source_path=".header-copy > h1",
        source_url=index.url,
        capture_id=index.capture_id,
        methodology_url=ORIGINAL_INDEX,
    )
    bundle.add(
        "scorecard_methodologies",
        primary,
        ".grades-modal",
        methodology_id="native-grading-criteria",
        chamber_text="house",
        cohort_text=facts["heading"],
        methodology_text=json_column(
            {
                "heading": facts["grading_heading"],
                "definitions": facts["grading"],
            }
        ),
        methodology_url=ORIGINAL_LIST,
        disclosure_status="explicit grade thresholds and missed-vote treatment; item grid not captured by this rendition",
    )
    bundle.add(
        "scorecard_methodologies",
        index,
        ".header-copy",
        methodology_id="native-guide-context",
        chamber_text="house",
        cohort_text=facts["heading"],
        methodology_text=json_column(
            {
                "guide": index_facts,
                "list_heading": facts["heading"],
                "list_publisher_context": {name: facts[name] for name in ("publisher_logo_text", "about", "copyright")},
                "source_custody": [
                    {
                        "original_publisher_url": ORIGINAL_INDEX,
                        "archive_url": INDEX,
                        "archive_timestamp": "20161030093405",
                    },
                    {
                        "original_publisher_url": ORIGINAL_LIST,
                        "archive_url": LIST,
                        "archive_timestamp": "20161031223355",
                    },
                ],
            }
        ),
        disclosure_status="source-owned complete House grade cohort; linked individual actions and Senate reference remain separate renditions",
    )
    bundle.add(
        "scorecard_metrics",
        primary,
        ".rep-list > .rep-list-row:nth-of-type(1) .grade-cap",
        metric_id="grade",
        methodology_id="native-grading-criteria",
        name="Grade",
        chamber_text="house",
        cohort_text=facts["heading"],
        period_text=BANNER,
        periods_json=json_column(periods),
        scale_text=json_column(GRADES),
    )
    definitions = {d["grade"]: d for d in facts["grading"]}
    for member in facts["members"]:
        member_key = key("bioguide_id", member["id"])
        path = member["path"]
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            identifiers_json=json_column([{"scheme": "bioguide_id", "value": member["id"]}]),
            member_name=member["name"],
            chamber_text="house",
            state=member["state"],
            district=member["district"],
            period_text=BANNER,
            notes_text=json_column(
                {
                    "native_from": {
                        "text": member["from"],
                        "html": member["from_html"],
                        "source_path": path + " .from",
                    },
                    "profile_link": {
                        "href": member["href"],
                        "original_url": urljoin(ORIGINAL_LIST, member["href"]),
                        "source_path": path + " a.name-link/@href",
                        "image_link_source_path": path + " a.image/@href",
                    },
                    "source_image": {"src": member["image_src"], "source_path": path + " a.image > img/@src"},
                }
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + " .grade-small .grade-sym",
            metric_id="grade",
            publisher_member_key=member_key,
            value_text=member["grade"],
            notes_text=json_column(
                {
                    "grade_label": {"text": member["grade_label"], "source_path": path + " .grade-cap"},
                    "grade_definition": definitions[member["grade"]],
                }
            ),
        )
    return bundle.finish(
        "Complete named original HTML through its terminal boundary; source guide explicitly links All Representatives; reviewed unique full card population, repeated native links, every literal grade/identity/definition/context and stable complete source rereads",
    )
