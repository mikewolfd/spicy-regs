"""AWI current member profiles, their disclosed actions and current-cohort rating history."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from typing import ClassVar
from urllib.parse import urlencode, urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import awi
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)

parser_version = "awi-current-original-member-profiles/1"
HISTORY = "Compassion Index Ratings Per Congressional Session"
PROFILE_ROOT = "#congresswebContent_cid_legislators_info"
BILL_PATH = re.compile(r"/AWI/bills/detail/id/([1-9][0-9]*)")
VOTE_PATH = re.compile(r"/AWI/votes/detail/id/([1-9][0-9]*)")
POSITIONS = {"We support this bill", "We oppose this bill", "We are monitoring this bill"}
BILL_ACTIONS = {
    "Legislator sponsored this bill",
    "Legislator cosponsored this bill",
    "Legislator has not cosponsored this bill",
}
VOTE_ACTIONS = {"Legislator voted Yea", "Legislator voted Nay", "Legislator did not vote"}
VOTE_RESULTS = {"Voted With Us", "Voted Against Us"}


def _profile_url(row):
    return row["profile_url"] + "?" + urlencode(awi.FRAME)


def _choices(document):
    return tuple(
        replace(e, edition_id=e.edition_id.removesuffix("-aggregate") + "-profiles")
        for e in awi._catalog(document)
        if e.is_current
    )


def _module(root, title):
    headings = [h for h in root.select("h4.congressweb-module-title") if awi._text(h) == title]
    if len(headings) != 1:
        raise ScorecardSourceError("AWI profile lacks one complete explicitly named scorecard module")
    module = headings[0].find_parent("div", class_="congressweb-module")
    content = module.find("div", class_="congressweb-module-content", recursive=False)
    if content is None:
        raise ScorecardSourceError("AWI profile module content shape changed")
    return content


def _period_modules(root, congress):
    titles = [awi._text(h) for h in root.select("h4.congressweb-module-title")]
    bill_titles = [t for t in titles if t.startswith("Bills for ")]
    vote_titles = [t for t in titles if t.startswith("Votes for ")]
    if len(bill_titles) != 1 or len(vote_titles) != 1:
        raise ScorecardSourceError("AWI profile lacks its complete named bill/vote period modules")
    period = re.fullmatch(r"Bills for the (" + congress + r"th Congress \([0-9]{4} - [0-9]{4}\))", bill_titles[0])
    if period is None or vote_titles[0] != "Votes for the " + period.group(1):
        raise ScorecardSourceError("AWI bill/vote source periods disagree with the requested Congress")
    return _module(root, bill_titles[0]), _module(root, vote_titles[0]), period.group(1)


def _profile(document, row, option):
    source = awi._document(document)
    root = source.select_one(PROFILE_ROOT)
    if root is None:
        raise ScorecardSourceError("AWI original response lacks its source member profile")
    congress, chamber = option.split("-")
    full_name = root.select_one(".congressweb-legislator-info-header h1")
    if full_name is None or not awi._text(full_name).endswith(" " + row["context"]):
        raise ScorecardSourceError("AWI profile identity disagrees with the native rating population")
    profile_name = awi._text(full_name).removesuffix(" " + row["context"])
    if not profile_name:
        raise ScorecardSourceError("AWI profile identity omits its native member name")
    history = _module(root, HISTORY)
    ratings, seen = [], set()
    for index, node in enumerate(history.find_all("div", recursive=False), 1):
        anchors = node.select("a[href]")
        match = (
            re.fullmatch(
                r"/AWI/legislators/info/mbr_id/" + row["id"] + r"/congress/([1-9][0-9]*)", str(anchors[0].get("href"))
            )
            if len(anchors) == 1
            else None
        )
        if match is None:
            raise ScorecardSourceError("AWI profile rating history lacks its exact native member/Congress link")
        period = match.group(1)
        label = period + "th Congress"
        value = awi._text(node)
        rating_match = re.fullmatch(re.escape(label) + r"\s*:\s*(-?[0-9]+%)", value)
        if awi._text(anchors[0]) != label or rating_match is None or period in seen:
            raise ScorecardSourceError("AWI profile history contains an unsupported or duplicate rating")
        seen.add(period)
        ratings.append(
            {
                "congress": period,
                "period": label,
                "value": rating_match.group(1),
                "href": anchors[0]["href"],
                "path": f"{PROFILE_ROOT}/module[{HISTORY}]/div[{index}]",
            }
        )
    current = [r for r in ratings if r["congress"] == congress]
    if len(current) != 1 or current[0]["value"] != row["value"]:
        raise ScorecardSourceError("AWI profile current rating disagrees with the complete native aggregate table")
    bills_module, votes_module, period_text = _period_modules(root, congress)
    # The source period is validated against the requested Congress, rather than
    # treating an unrelated biographical sponsored-bills module as scorecard data.
    bills, votes = [], []
    for index, node in enumerate(bills_module.select(".congressweb-bill"), 1):
        links = [a for a in node.select("a[href]") if BILL_PATH.fullmatch(str(a.get("href")))]
        first = node.select(".congressweb-bill-footer-content-item-first")
        second = node.select(".congressweb-bill-footer-content-item-second")
        if len(links) != 1 or len(first) != 1 or len(second) != 1:
            raise ScorecardSourceError("AWI scorecard bill lacks its native identity, position or member action")
        position, action, title = awi._text(first[0]), awi._text(second[0]), awi._text(links[0])
        if position not in POSITIONS or action not in BILL_ACTIONS or not re.match(r"(?:H\.R\.|S\.)[0-9]+: .+", title):
            raise ScorecardSourceError("AWI profile bill position, action or citation shape changed")
        identity = BILL_PATH.fullmatch(links[0]["href"])
        assert identity is not None
        bills.append(
            {
                "kind": "bill",
                "id": identity.group(1),
                "title": title,
                "citation": title.split(":", 1)[0],
                "position": position,
                "action": action,
                "result": None,
                "href": links[0]["href"],
                "date": None,
                "path": f"{PROFILE_ROOT}/module[Bills]/div.congressweb-bill[{index}]",
            }
        )
    for index, node in enumerate(votes_module.select(".congressweb-vote"), 1):
        links = [a for a in node.select("a[href]") if VOTE_PATH.fullmatch(str(a.get("href")))]
        parts = node.select(".congressweb-vote-footer-content-item-second")
        if len(links) != 1 or len(parts) not in {2, 3}:
            raise ScorecardSourceError("AWI scorecard vote lacks its native identity or complete member result")
        date, action = awi._text(parts[0]), awi._text(parts[1])
        result = awi._text(parts[2]) if len(parts) == 3 else None
        title = awi._text(links[0])
        if (
            action not in VOTE_ACTIONS
            or result not in VOTE_RESULTS | {None}
            or not date
            or not re.match(r"(?:H R|S) [0-9]+: .+", title)
        ):
            raise ScorecardSourceError("AWI profile vote action, outcome or citation shape changed")
        if (action == "Legislator did not vote") != (result is None):
            raise ScorecardSourceError("AWI profile vote omits its expected native publisher outcome")
        identity = VOTE_PATH.fullmatch(links[0]["href"])
        assert identity is not None
        votes.append(
            {
                "kind": "vote",
                "id": identity.group(1),
                "title": title,
                "citation": title.split(":", 1)[0],
                "position": None,
                "action": action,
                "result": result,
                "href": links[0]["href"],
                "date": date,
                "path": f"{PROFILE_ROOT}/module[Votes]/div.congressweb-vote[{index}]",
            }
        )
    if len({(i["kind"], i["id"]) for i in bills + votes}) != len(bills) + len(votes):
        raise ScorecardSourceError("AWI profile contains duplicate native scorecard item identities")
    comments = [awi._text(n) for n in root.select(".legislatorComment")]
    return {
        "name": awi._text(full_name),
        "member_name": profile_name,
        "ratings": ratings,
        "items": bills + votes,
        "comments": comments,
        "chamber": chamber,
        "period": period_text,
    }


def _vote_detail(document, item, option):
    source = awi._document(document)
    root = source.select_one("#congresswebContent_cid_votes_detail")
    title = root.select_one("h1.congressweb-module-title") if root else None
    if title is None or awi._text(title) != item["title"]:
        raise ScorecardSourceError("AWI vote detail disagrees with its exact native profile item")
    values = {}
    for node in root.select(".congressweb-fieldlabel-combo"):
        label, value = node.find("label", recursive=False), node.find("span", recursive=False)
        if label is not None and value is not None:
            name = awi._text(label)
            if name in values:
                raise ScorecardSourceError("AWI vote detail duplicates a source summary field")
            values[name] = awi._text(value)
    if set(values) != {"Our Position", "Roll Call No.", "Date", "Question", "Result"}:
        raise ScorecardSourceError("AWI vote summary fields changed")
    match = re.fullmatch(
        r"(House|Senate) #([1-9][0-9]*) \(([1-9][0-9]*)th Congress, ([1-2])(?:st|nd) Session\)", values["Roll Call No."]
    )
    if match is None or match.group(3) + "-" + match.group(1) != option or values["Date"] != item["date"]:
        raise ScorecardSourceError("AWI native vote Congress/chamber/date disagrees with the requested edition")
    return {
        "chamber": match.group(1),
        "roll": match.group(2),
        "congress": match.group(3),
        "session": match.group(4),
        "position": values["Our Position"],
        "date": values["Date"],
        "summary": values,
    }


@dataclass(frozen=True, slots=True)
class AWIProfileReader:
    parser_version: ClassVar[str] = parser_version

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("AWI source redistribution rights are not established")
        return _choices(context.read(awi.INDEX, stage="awi:profiles:catalog", hosts=awi.HOSTS))

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(edition, context)


def acquire_scorecard(edition, context):
    if context.evidence_policy == "full":
        raise ScorecardSourceError("AWI source redistribution rights are not established")
    if not edition.edition_id.endswith("-profiles"):
        raise ScorecardSourceError("AWI profiles require a distinct current-cohort rendition")
    aggregate = replace(edition, edition_id=edition.edition_id.removesuffix("-profiles") + "-aggregate")
    option = awi._native_option(aggregate)
    prefix = f"awi:{option}:profiles"
    catalog = context.read(awi.INDEX, stage=prefix + ":catalog", hosts=awi.HOSTS)
    choices = _choices(catalog)
    if edition not in choices:
        raise ScorecardSourceError("AWI profile rendition is not an advertised current Congress/chamber")
    primary = context.read(edition.source_url, stage=prefix + ":ratings", hosts=awi.HOSTS)
    label, rows = awi._table(primary, option)
    name_order = context.read(awi._table_url(option, "name"), stage=prefix + ":name-order", hosts=awi.HOSTS)
    if awi._facts(awi._table(name_order, option)[1]) != awi._facts(rows):
        raise ScorecardSourceError("AWI profile population differs across native rating/name orderings")
    profiles, item_sources, vote_details = {}, {}, {}
    for row in rows:
        document = context.read(_profile_url(row), stage=prefix + ":member:" + row["id"], hosts=awi.HOSTS)
        facts = _profile(document, row, option)
        profiles[row["id"]] = document, facts
        for item in facts["items"]:
            identity = (item["kind"], item["id"])
            shared = {k: item[k] for k in ("kind", "id", "title", "citation", "position", "href", "date")}
            if identity in item_sources and item_sources[identity][2] != shared:
                raise ScorecardSourceError("AWI profiles disagree about a native item's shared source facts")
            item_sources.setdefault(identity, (document, item, shared))
    for identity, (_, item, _) in item_sources.items():
        if item["kind"] == "vote":
            url = urljoin(awi.BASE, item["href"]) + "?" + urlencode(awi.FRAME)
            document = context.read(url, stage=prefix + ":vote:" + item["id"], hosts=awi.HOSTS)
            vote_details[identity] = document, _vote_detail(document, item, option)
    periods = {facts["period"] for _, facts in profiles.values()}
    if len(periods) != 1:
        raise ScorecardSourceError("AWI current profiles disagree about their literal scoring period")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Animal Welfare Institute",
        parser_version=parser_version,
        homepage=awi.HOMEPAGE,
        rendition_rule="complete current aggregate population, each exact native profile and disclosed current-Congress modules; history means ratings displayed for that current cohort, not a historical roster",
    )
    bundle.use(primary, "rating-population")
    bundle.use(catalog, "edition-catalog")
    bundle.use(name_order, "rating-population", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = awi.INDEX
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=option, edition_label_text=label, timespan_text=next(iter(periods))
    )
    metric_periods = sorted(
        {r["congress"] for _, facts in profiles.values() for r in facts["ratings"]}, key=int, reverse=True
    )
    for period in metric_periods:
        document, rating = next((d, r) for d, p in profiles.values() for r in p["ratings"] if r["congress"] == period)
        bundle.metric(
            document,
            key("Rating", period),
            HISTORY,
            path=rating["path"],
            chamber=edition.chamber if period == edition.congress else None,
            unit="%",
            primary=period == edition.congress,
        )
        bundle.tables["scorecard_metrics"][-1].update(period_text=rating["period"])
    for identity, (profile_document, item, _) in item_sources.items():
        document, detail = vote_details.get(identity, (profile_document, {}))
        item_id = key(item["kind"], item["id"])
        path = "#congresswebContent_cid_votes_detail/summary" if detail else item["path"]
        position = detail.get("position") if detail else item["position"]
        bundle.add(
            "scorecard_items",
            document,
            path,
            item_id=item_id,
            publisher_item_id=item["id"],
            item_kind_text="Bills" if item["kind"] == "bill" else "Votes",
            title=item["title"],
            item_date_text=item["date"],
            congress_text=edition.congress,
            chamber_text=edition.chamber,
            session_text=detail.get("session"),
            roll_number_text=detail.get("roll"),
            bill_citation_text=item["citation"],
            references_json="[]",
            publisher_position_text=position,
            position_basis="explicit" if position else "absent",
            position_source_path=path if position else None,
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            path,
            metric_id=key("Rating", edition.congress),
            item_id=item_id,
            participation_id="disclosed-current-profile",
            publisher_position_text=position,
            position_basis="explicit" if position else "absent",
        )
        if detail:
            bundle.use(document, "vote:" + item["id"])
    for row in rows:
        document, facts = profiles[row["id"]]
        member_key = key("mbr_id", row["id"])
        bundle.use(document, "member:" + row["id"])
        bundle.add(
            "scorecard_members",
            document,
            PROFILE_ROOT + "/.congressweb-legislator-info-header/h1",
            publisher_member_key=member_key,
            publisher_member_id=row["id"],
            member_name=facts["member_name"],
            chamber_text=edition.chamber,
            party=row["party"],
            state=row["state"],
            district=row["district"],
            period_text=edition.congress + "th Congress",
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "literal_context": row["context"],
                    "profile_identity_text": facts["name"],
                    "aggregate_member_name": row["name"],
                    "comments": facts["comments"],
                    "disclosed_bill_count": sum(i["kind"] == "bill" for i in facts["items"]),
                    "disclosed_vote_count": sum(i["kind"] == "vote" for i in facts["items"]),
                }
            ),
        )
        for rating in facts["ratings"]:
            bundle.add(
                "scorecard_member_ratings",
                document,
                rating["path"],
                metric_id=key("Rating", rating["congress"]),
                publisher_member_key=member_key,
                value_text=rating["value"],
                value_number=decimal_text(rating["value"]),
            )
        for item in facts["items"]:
            bundle.add(
                "scorecard_member_item_results",
                document,
                item["path"],
                publisher_member_key=member_key,
                metric_id=key("Rating", edition.congress),
                item_id=key(item["kind"], item["id"]),
                participation_id="disclosed-current-profile",
                result_id="profile",
                action_text=item["action"],
                result_text=item["result"],
            )
    for row in rows:
        repeated = context.read(_profile_url(row), stage=prefix + ":member:" + row["id"] + ":reread", hosts=awi.HOSTS)
        if _profile(repeated, row, option) != profiles[row["id"]][1]:
            raise ScorecardSourceError("AWI native member profile rating or item facts changed during acquisition")
        bundle.use(repeated, "member:" + row["id"], role="corroboration")
    for identity, (document, facts) in vote_details.items():
        repeated = context.read(document.url, stage=prefix + ":vote:" + identity[1] + ":reread", hosts=awi.HOSTS)
        if _vote_detail(repeated, item_sources[identity][1], option) != facts:
            raise ScorecardSourceError("AWI native vote summary changed during acquisition")
        bundle.use(repeated, "vote:" + identity[1], role="corroboration")
    repeated = context.read(edition.source_url, stage=prefix + ":ratings:reread", hosts=awi.HOSTS)
    if awi._facts(awi._table(repeated, option)[1]) != awi._facts(rows):
        raise ScorecardSourceError("AWI aggregate profile population changed during acquisition")
    bundle.use(repeated, "rating-population", role="corroboration")
    repeated_catalog = context.read(awi.INDEX, stage=prefix + ":catalog:reread", hosts=awi.HOSTS)
    if _choices(repeated_catalog) != choices:
        raise ScorecardSourceError("AWI current edition catalog changed during acquisition")
    bundle.use(repeated_catalog, "edition-catalog", role="corroboration")
    return bundle.finish(
        "Complete native aggregate table and name ordering agree; every source member profile has explicit complete rating, bill and vote modules; current ratings reconcile to aggregate; every selected profile, native vote summary, population and catalog agrees on reread",
        declared={
            "native_option": option,
            "scope": "Current publisher population with its disclosed current actions and displayed historical rating cohort; no inferred official roster, action results or scoring formula",
            "publisher_declared_member_count": None,
        },
    )
