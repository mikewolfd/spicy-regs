"""National NASW's own federal VoterVoice JSON editions.

Namespace authority comes from NASW's original page and linked application.
VoterVoice syntax helpers supply bounded reads, not publisher selection or an
assumed scoring formula. Raw API numbers are not converted to UI percentages.
"""

from __future__ import annotations

import re
from dataclasses import replace
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.votervoice_public import (
    Application,
    _identifier,
    _scalar,
    criterion,
    read_api,
    scorings,
)

parser_version = "nasw-national-federal-votervoice/1"
NAME = "National Association of Social Workers"
INDEX = "https://www.socialworkers.org/Advocacy/Legislative-Alerts?vvsrc=%2FScorecard"
PLUGIN = "https://www.votervoice.net/Scripts/JxAAAAAAAAA/Plugin.js"
APP = "https://www.votervoice.net/iframes/NASW/Scorecard"
HOSTS = ("www.votervoice.net",)
APPLICATION = Application("nasw", INDEX, PLUGIN, APP, "NASW", "4135", NAME, allow_unconfigured_items=True)


def _bootstrap(context):
    if context.evidence_policy == "full":
        raise ScorecardSourceError("NASW public application configuration needs hash_only or metadata_only evidence")
    original = context.read(INDEX, stage="scorecards:nasw:original", hosts=("www.socialworkers.org",))
    if not soup(original).select_one('script[src="' + PLUGIN + '"]'):
        raise ScorecardSourceError("NASW original page no longer links its reviewed national application")
    plugin = context.read(PLUGIN, stage="scorecards:nasw:plugin", hosts=HOSTS)
    text = plugin.body.decode("utf-8")
    if (
        "siteRootUrl: 'https://www.votervoice.net/iframes/NASW', defaultSrc: '/Home'" not in text
        or "src: siteRootUrl + (getQuery('vvsrc') || defaultSource)" not in text
    ):
        raise ScorecardSourceError("NASW source application's national route or explicit vvsrc selection changed")
    application = context.read(APP, stage="scorecards:nasw:application", hosts=HOSTS)
    text = application.body.decode("utf-8")
    match = re.search(r'api: \{ url: "/Api", key: "([^"\r\n]+)"', text)
    if match is None or 'associationIdName: "NASW"' not in text:
        raise ScorecardSourceError("NASW original scorecard application's anonymous API configuration changed")
    scripts = soup(application).select('script[src^="/UserSite/Scripts/Scorecard.Index?"]')
    if len(scripts) != 1:
        raise ScorecardSourceError("NASW original application scorecard client is missing or repeated")
    client = context.read(urljoin(APP, str(scripts[0]["src"])), stage="scorecards:nasw:client", hosts=HOSTS)
    code = client.body.decode("utf-8")
    if 'y=r("<td>N/A<\\/td>")' not in code or '"/Scorecards/"+n+"/Scorings"' not in code:
        raise ScorecardSourceError("NASW native absent-score display or scorecard data route changed")
    return [original, plugin, application, client], {
        "Authorization": match[1],
        "Accept-Language": "en-US",
        "VV-Language": "en-US",
    }


def _catalog(context, headers, suffix=""):
    governments, data = read_api(
        context, "/Governments?association=NASW&activeScorecards=true", headers, "governments" + suffix, APPLICATION
    )
    if data != [{"name": "Federal", "uri": "./USA"}]:
        raise ScorecardSourceError("NASW national application federal government selection changed")
    documents, records, editions, identities = [], [], [], set()
    for active in ("true", "false"):
        document, data = read_api(
            context,
            "/Scorecards?association=NASW&government=./USA&active=" + active,
            headers,
            "catalog:" + active + suffix,
            APPLICATION,
        )
        if not isinstance(data, list) or not all(isinstance(row, dict) for row in data):
            raise ScorecardSourceError("NASW federal edition catalog is not a complete array")
        documents.append(document)
        for row in data:
            identity = _identifier(row.get("id"), r"4135-\d+")
            title = row.get("name")
            if not isinstance(title, str):
                raise ScorecardSourceError("NASW federal edition lacks its native period label")
            current = re.fullmatch(r"(\d{4})-(\d{4}) Regular Session \((\d+)th\)", title)
            historical = re.fullmatch(r"(\d+)th Congress \((\d{4})-(\d{4})\)", title)
            period = (
                (current[1], current[2], current[3])
                if current
                else (historical[2], historical[3], historical[1])
                if historical
                else None
            )
            if period is None or int(period[1]) != int(period[0]) + 1 or identity in identities:
                raise ScorecardSourceError("NASW federal period or unique edition identity changed")
            items = row.get("criteria")
            if not isinstance(items, list) or not all(isinstance(item, dict) for item in items):
                raise ScorecardSourceError("NASW edition criteria are absent")
            item_ids = []
            for item in items:
                item_ids.append(_identifier(item.get("id"), r"[MSC]-4135-\d+"))
                if (
                    not isinstance(item.get("name"), str)
                    or not item["name"]
                    or not isinstance(item.get("billNumber"), str)
                ):
                    raise ScorecardSourceError("NASW native criterion name or bill citation changed")
            if len(item_ids) != len(set(item_ids)):
                raise ScorecardSourceError("NASW edition repeats a criterion identity")
            records.append((document, row))
            editions.append(ScorecardEdition("nasw", identity, INDEX, title, congress=period[2], is_current=False))
            identities.add(identity)
    if not records:
        raise ScorecardSourceError("NASW's observed national federal catalog unexpectedly became empty")
    latest = max(int(edition.congress) for edition in editions)
    return (
        governments,
        documents,
        records,
        tuple(replace(edition, is_current=int(edition.congress) == latest) for edition in editions),
    )


class NASWReader:
    parser_version = parser_version

    def list_scorecards(self, context: ScorecardContext):
        _, headers = _bootstrap(context)
        return _catalog(context, headers)[3]

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        boot, headers = _bootstrap(context)
        governments, catalogs, records, editions = _catalog(context, headers)
        if edition not in editions:
            raise ScorecardSourceError("NASW selected edition is outside the original national federal catalog")
        primary, source = next((doc, row) for doc, row in records if row["id"] == edition.edition_id)
        # A source-advertised edition with no criteria/scorings is a retained
        # requested-empty scope, not an accepted zero-rating edition.
        criteria = {item["id"]: item for item in source["criteria"]}
        scoring_document, rows = scorings(context, edition, headers, APPLICATION)
        if not criteria:
            raise ScorecardSourceError("NASW edition has no configured scoring criteria; preserve the prior scope")
        if any(factor["criterionId"] not in criteria for row in rows for factor in row["factors"]):
            raise ScorecardSourceError("NASW reported factor is not in the selected native edition")
        details = {identity: criterion(context, identity, headers, APPLICATION) for identity in criteria}
        repeated_details = {
            identity: criterion(context, identity, headers, APPLICATION, ":reread") for identity in criteria
        }
        repeated_scoring, repeated_rows = scorings(context, edition, headers, APPLICATION, ":reread")
        final_governments, final_catalogs, final_records, final_editions = _catalog(context, headers, ":reread")
        if (
            [row for _, row in records] != [row for _, row in final_records]
            or editions != final_editions
            or rows != repeated_rows
            or any(details[identity][1] != repeated_details[identity][1] for identity in criteria)
        ):
            raise ScorecardSourceError(
                "NASW native federal catalog, scoring population or criterion detail changed during reread"
            )
        bundle = Bundle(
            edition,
            context,
            primary,
            publisher_name=NAME,
            parser_version=self.parser_version,
            rendition_rule="Complete native national federal API arrays and every configured criterion detail; literal API scores, no UI percentage conversion",
            homepage="https://www.socialworkers.org/",
        )
        for number, document in enumerate(boot):
            bundle.use(document, "national-application-attribution:" + str(number))
        bundle.use(governments, "government-selection")
        bundle.use(final_governments, "government-selection", role="corroboration")
        for i, document in enumerate(catalogs):
            bundle.use(document, "federal-catalog:" + str(i))
            bundle.use(final_catalogs[i], "federal-catalog:" + str(i), role="corroboration")
        bundle.use(scoring_document, "native-member-scoring-array")
        bundle.use(repeated_scoring, "native-member-scoring-array", role="corroboration")
        edition_path = "$[id=" + source["id"] + "]"
        card = bundle.tables["scorecards"][0]
        bodies = {row["official"]["office"]["electedBody"] for row in rows}
        card.update(
            edition_label_text=source["name"],
            timespan_text=source["name"],
            chamber_scope_text=next(iter(bodies)) if len(bodies) == 1 else "both",
            source_path=edition_path,
        )
        bundle.add(
            "scorecard_methodologies",
            primary,
            edition_path,
            methodology_id="native-edition",
            methodology_text=json_column(source),
            disclosure_status="Native configured criterion catalog; no disclosed universal formula",
        )
        bundle.add(
            "scorecard_metrics",
            primary,
            edition_path + ".name",
            metric_id="score",
            name="Score",
            period_text=source["name"],
            methodology_id="native-edition",
            is_primary="true",
            chamber_text=next(iter(bodies)) if len(bodies) == 1 else None,
        )
        for ordinal, item in enumerate(source["criteria"]):
            identity, path = item["id"], edition_path + f".criteria[{ordinal}]"
            detail_document, detail, _actions = details[identity]
            bundle.use(detail_document, "criterion:" + identity)
            bundle.use(repeated_details[identity][0], "criterion:" + identity, role="corroboration")
            motion = detail.get("legislativeMotion")
            supports = None if motion is None else motion["associationStance"]["supportsMotion"]
            stance = str(supports).lower() if isinstance(supports, bool) else None
            references = []
            if motion:
                for kind, urls in (
                    ("motion", motion["externalUrls"]),
                    ("bill", motion["legislativeProposal"]["externalUrls"]),
                ):
                    for number, url in enumerate(urls):
                        field = "$.legislativeMotion." + ("legislativeProposal." if kind == "bill" else "")
                        references.append(
                            {
                                "occurrence_id": f"{kind}:{number}",
                                "kind": "url",
                                "citation_text": url,
                                "source_path": f"capture:{detail_document.capture_id}#{field}externalUrls[{number}]",
                            }
                        )
            date = re.search(r"\((\d{1,2}/\d{1,2}/\d{4})\)$", item["name"])
            roll = re.search(r"Roll no\. (\d+)", item["name"])
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=identity,
                publisher_item_id=identity,
                item_kind_text=detail["positionType"],
                title=item["name"],
                congress_text=edition.congress,
                item_date_text=date[1] if date else None,
                roll_number_text=roll[1] if roll else None,
                bill_citation_text=item["billNumber"],
                references_json=json_column(references),
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                position_source_path=f"capture:{detail_document.capture_id}#$.legislativeMotion.associationStance.supportsMotion"
                if stance is not None
                else None,
            )
            bundle.add(
                "scorecard_methodologies",
                detail_document,
                "$",
                methodology_id="criterion:" + identity,
                methodology_text=json_column(detail),
                disclosure_status="Complete native criterion object, including all position groups and publisher omissions",
            )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id="score",
                item_id=identity,
                participation_id="native-factor",
                methodology_id="criterion:" + identity,
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
            )
        for ordinal, row in enumerate(rows):
            member, office, path = row["official"], row["official"]["office"], f"$[{ordinal}]"
            identity = str(member["id"])
            name = " ".join(v for v in (member["givenNames"], member["surname"], member.get("suffix")) if v)
            bundle.add(
                "scorecard_members",
                scoring_document,
                path + ".official",
                publisher_member_key=identity,
                publisher_member_id=identity,
                member_name=name,
                chamber_text=office["electedBody"],
                state=office["state"],
                district=office["electoralDistrict"] or None,
                party=member["party"],
                period_text=source["name"],
                identifiers_json=json_column(
                    [
                        {"scheme": "votervoice_occupancy_id", "value": identity},
                        {"scheme": "votervoice_politician_id", "value": str(member["politicianId"])},
                    ]
                ),
                notes_text=json_column(row),
            )
            value = _scalar(row["score"]) if "score" in row else "N/A"
            bundle.add(
                "scorecard_member_ratings",
                scoring_document,
                path + ".score",
                metric_id="score",
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value),
                value_status_text=None if "score" in row else "N/A",
                notes_text=json_column(row),
            )
            for factor_number, factor in enumerate(row["factors"]):
                criterion_id = factor["criterionId"]
                doc, _detail, actions = details[criterion_id]
                action = actions.get(identity)
                result_path = path + f".factors[{factor_number}]"
                if action:
                    result_path += f";action_source=capture:{doc.capture_id}#{action[1]}"
                effect = _scalar(factor["effect"])
                bundle.add(
                    "scorecard_member_item_results",
                    scoring_document,
                    result_path,
                    publisher_member_key=identity,
                    item_id=criterion_id,
                    result_id=key(identity, criterion_id),
                    metric_id="score",
                    participation_id="native-factor",
                    action_text=action[0] if action else None,
                    result_text=_scalar(factor.get("position")),
                    contribution_text=effect,
                    contribution_number=decimal_text(effect),
                    reason_text=json_column(factor),
                )
        return bundle.finish(
            "Complete original national API arrays reached EOF; unique edition/member/item/factor identities; every configured criterion object preserved; "
            "federal catalogs, complete scoring arrays and all criterion objects match independent rereads. Missing criterion actions remain NULL, "
            "unconfigured target stance remains NULL, literal zero factors survive and absent native scores use the verified client's N/A display."
        )


def list_scorecards(context):
    return NASWReader().list_scorecards(context)


def acquire_scorecard(edition, context):
    return NASWReader().acquire_scorecard(edition, context)
