"""CFA's four publisher-reported voting records in its November 2000 newsletter.

This named article rendition is complete for its disclosed four-person cohort.
It is neither an all-member scorecard nor an inventory of CFA's current offerings.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "consumer-federation-named-newsletter-ratings/2"
PDF = "https://krex.k-state.edu/server/api/core/bitstreams/341883e5-02d2-49b8-8301-010e75f257e1/content"
HOSTS = ("krex.k-state.edu",)
SOURCE_SHA256 = "14ca4f08c88d2f0953954b41470d84f17b3e28df9e3411e0941d056feaee8c23"
QUALIFIED_SHA256 = "f6e658d0443bf9e981dc01110e0b4a3d0a5c95241102d53f7daaf41e39feb729"
EDITION_KEY = "2000-november-defeated-senators-lifetime-ratings"
TITLE = "No Big Advances for Consumers in New Congress"
COHORT = "the four Republican senators who were defeated"
EDITION = ScorecardEdition(
    "consumer_federation", EDITION_KEY, PDF, TITLE, year="2000", chamber="Senate", is_current=False
)
PARAGRAPH_COUNTS = (6, 6, 5)
HEADINGS = (None, "Bipartisan Cooperation Essential", "Results for CFA Endorsees")


def _source(document):
    message = "CFA November 2000 PDF differs from its reviewed original newsletter"
    if (document.response.content_type or "").split(";", 1)[0].strip().lower() != "application/pdf":
        raise ScorecardSourceError(message)
    require_reviewed_pdf(document, source_url=PDF, source_sha256=SOURCE_SHA256, message=message)


def _qualified(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("CFA observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        article = data["article"]
        record, evidence = article["record"], article["evidence"]
        if (
            set(data)
            != {
                "format_version",
                "edition_key",
                "source_sha256",
                "physical_page_count",
                "article",
                "publisher_name_text",
                "publisher_homepage_text",
                "publisher_source_path",
                "source_declared_member_count",
            }
            or set(article) != {"record", "evidence"}
            or set(evidence)
            != {"physical_page", "outcome_sha256", "observation_sha256", "schema_version", "json_pointer"}
            or set(record)
            != {
                "publication_label_text",
                "page_label_text",
                "article_title_text",
                "sections",
                "cohort_text",
                "metric_label_text",
                "period_text",
                "members",
                "uncertainties",
            }
            or data["format_version"] != "consumer-federation-qualified-newsletter-ratings/2"
            or data["edition_key"] != EDITION_KEY
            or data["source_sha256"] != SOURCE_SHA256
            or type(data["physical_page_count"]) is not int
            or data["physical_page_count"] != 4
            or type(data["source_declared_member_count"]) is not int
            or data["source_declared_member_count"] != 4
            or data["publisher_name_text"] != "Consumer Federation of America"
            or data["publisher_homepage_text"] != "www.consumerfed.org"
            or data["publisher_source_path"] != "PDF/page[3]/masthead"
            or record["publication_label_text"] != "November 2000 • CFAnews"
            or record["page_label_text"] != "Page 3"
            or record["article_title_text"] != TITLE
            or record["cohort_text"] != COHORT
            or record["metric_label_text"] != "consumer voting records"
            or record["period_text"] is not None
            or record["uncertainties"] != []
            or evidence["physical_page"] != 3
            or type(evidence["physical_page"]) is not int
            or evidence["json_pointer"] != "/outcome"
            or evidence["schema_version"] != "cfa-november2000-article-and-rating-facts/1"
            or any(not re.fullmatch(r"[0-9a-f]{64}", evidence[k]) for k in ("outcome_sha256", "observation_sha256"))
            or len(record["sections"]) != len(HEADINGS)
            or len(record["members"]) != 4
        ):
            raise ValueError
        for section, heading, count in zip(record["sections"], HEADINGS, PARAGRAPH_COUNTS, strict=True):
            if (
                set(section) != {"heading_text", "paragraphs"}
                or section["heading_text"] != heading
                or len(section["paragraphs"]) != count
            ):
                raise ValueError
            if any(not isinstance(text, str) or not text.strip() for text in section["paragraphs"]):
                raise ValueError
        paragraph = record["sections"][-1]["paragraphs"][-1]
        identities = set()
        for member in record["members"]:
            name, state, rating = member["member_name_text"], member["state_text"], member["value_text"]
            if (
                set(member)
                != {
                    "member_name_text",
                    "state_text",
                    "chamber_text",
                    "party_text",
                    "value_text",
                    "source_parenthetical_text",
                }
                or any(not isinstance(text, str) or not text for text in (name, state, rating))
                or (name, state) in identities
                or member["chamber_text"] != "Senate"
                or member["party_text"] != "Republican"
                or member["source_parenthetical_text"] != "(" + rating + ")"
                or name + " of " + state + " " + member["source_parenthetical_text"] not in paragraph
                or not re.fullmatch(r"(?:[0-9]+|[a-z]+) percent(?: CFA lifetime record)?", rating)
            ):
                raise ValueError
            identities.add((name, state))
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "CFA facts no longer establish the complete reviewed article and four-member cohort"
        ) from error


@dataclass(frozen=True, slots=True)
class ConsumerFederationNewsletterReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        _qualified(self.qualified_observations)
        _source(context.read(PDF, stage="consumer-federation:november2000:pdf:list", hosts=HOSTS))
        return (EDITION,)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("CFA reader requires the exact named November 2000 four-senator rendition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("CFA requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations)
    document = context.read(PDF, stage="consumer-federation:november2000:pdf", hosts=HOSTS)
    _source(document)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="consumer-federation:november2000:qualified-observations",
    )
    article = data["article"]["record"]
    path = f"pdf:page=3;observation={observation};/article/record"
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name=data["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="publisher-reported voting-record excerpt for exactly the four defeated senators in the November 2000 article; complete article and explicit cohort, reviewed original PDF and stable exact reread",
        homepage="http://" + data["publisher_homepage_text"],
    )
    bundle.tables["scorecard_publishers"][0].update(
        scorecard_index_url=None, source_path=data["publisher_source_path"], abbreviation="CFA"
    )
    bundle.tables["scorecards"][0].update(
        edition_label_text="November 2000 • CFAnews",
        published_at_text="November 2000",
        timespan_text=None,
        methodology_url=PDF,
        source_path=path,
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        path,
        methodology_id="native-article-context",
        chamber_text="Senate",
        cohort_text=article["cohort_text"],
        methodology_url=PDF,
        methodology_text=json_column(article),
        disclosure_status="partial",
    )
    bundle.add(
        "scorecard_metrics",
        document,
        path + "/metric_label_text",
        metric_id="reported-record",
        name=article["metric_label_text"],
        value_unit_text="percent",
        chamber_text="Senate",
        cohort_text=article["cohort_text"],
        period_text=article["period_text"],
        methodology_id="native-article-context",
    )
    for index, member in enumerate(article["members"]):
        location = path + f"/members/{index}"
        member_key = key("page", "3", "cohort-member", str(index + 1))
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=member["member_name_text"],
            state=member["state_text"],
            party=member["party_text"],
            chamber_text=member["chamber_text"],
            notes_text=json_column(
                {"cohort_text": article["cohort_text"], "source_path": "PDF/page[3]/article/record/cohort_text"}
            ),
            identifiers_json="[]",
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/value_text",
            metric_id="reported-record",
            publisher_member_key=member_key,
            value_text=member["value_text"],
            value_number=decimal_text(member["value_text"].removesuffix(" percent")),
            notes_text=json_column(
                {
                    "source_parenthetical_text": member["source_parenthetical_text"],
                    "source_path": f"PDF/page[3]/article/record/members/{index}/source_parenthetical_text",
                }
            ),
        )
    repeat = context.read(PDF, stage="consumer-federation:november2000:pdf:reread", hosts=HOSTS)
    _source(repeat)
    bundle.use(repeat, "edition", role="corroboration")
    return bundle.finish(
        "exact reviewed four-page original reaches PDF EOF; complete page-3 article with every disclosed cohort member and literal parenthetical rating; four source-declared members reconcile; exact original bytes agree on reread",
        declared={"members_in_reported_cohort": data["source_declared_member_count"]},
    )
