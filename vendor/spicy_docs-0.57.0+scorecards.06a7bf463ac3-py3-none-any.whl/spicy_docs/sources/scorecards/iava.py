"""IAVA Action Fund's original 2008 report, including grade and point distinctions.

Only the named archived publisher PDF and privately retained, independently
reviewed source observations qualify. Official identities stay downstream.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "iava-action-2008-qualified-pdf/1"
ORIGINAL_URL = "http://www.veteranreportcard.org/reportcard.pdf"
URL = "https://web.archive.org/web/20081009202506id_/http://www.veteranreportcard.org/reportcard.pdf"
HOSTS = ("web.archive.org",)
SOURCE_SHA256 = "809e48dd64a98599d80e2cbf7153549277761235a5dbee514929cd6214f31688"
QUALIFIED_SHA256 = "406d11ebc7fd42f5b8d541ac379c47a02f6259df4945652daee43d4c7809e0d4"
EDITION = ScorecardEdition(
    "iava",
    "2008-original-report-pdf",
    URL,
    "2008 Congressional Report Card",
    year="2008",
    congress="110",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    10: 31,
    11: 36,
    12: 32,
    13: 32,
    14: 33,
    15: 31,
    16: 33,
    17: 28,
    18: 34,
    19: 33,
    20: 33,
    21: 31,
    22: 33,
    23: 27,
    26: 36,
    27: 36,
    28: 30,
}
INDEX_COUNTS = {
    (32, "House"): 78,
    (33, "House"): 80,
    (34, "House"): 80,
    (35, "House"): 80,
    (36, "House"): 80,
    (37, "House"): 49,
    (37, "Senate"): 25,
    (38, "Senate"): 77,
}
ITEM_PAGES = {
    "House": {6: (1, 2, 3, 4), 7: (5, 6, 7, 8), 8: (9, 10), 9: (11, 12, 13)},
    "Senate": {24: (1, 2, 3, 4, 5), 25: (6, 7, 8, 9)},
}
# This source's full state headings and index abbreviations; no person crosswalk.
STATE_CODES = dict(
    zip(
        [
            "ALABAMA",
            "ALASKA",
            "ARIZONA",
            "ARKANSAS",
            "CALIFORNIA",
            "COLORADO",
            "CONNECTICUT",
            "DELAWARE",
            "FLORIDA",
            "GEORGIA",
            "HAWAII",
            "IDAHO",
            "ILLINOIS",
            "INDIANA",
            "IOWA",
            "KANSAS",
            "KENTUCKY",
            "LOUISIANA",
            "MAINE",
            "MARYLAND",
            "MASSACHUSETTS",
            "MICHIGAN",
            "MINNESOTA",
            "MISSISSIPPI",
            "MISSOURI",
            "MONTANA",
            "NEBRASKA",
            "NEVADA",
            "NEW HAMPSHIRE",
            "NEW JERSEY",
            "NEW MEXICO",
            "NEW YORK",
            "NORTH CAROLINA",
            "NORTH DAKOTA",
            "OHIO",
            "OKLAHOMA",
            "OREGON",
            "PENNSYLVANIA",
            "RHODE ISLAND",
            "SOUTH CAROLINA",
            "SOUTH DAKOTA",
            "TENNESSEE",
            "TEXAS",
            "UTAH",
            "VERMONT",
            "VIRGINIA",
            "WASHINGTON",
            "WEST VIRGINIA",
            "WISCONSIN",
            "WYOMING",
        ],
        [
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY",
        ],
        strict=True,
    )
)
PERIOD = "110th Congress"
GRADE_SCALES = {
    "House": "15 points A+\n13-14 points A\n10-12 points B\n7-9 points C\n4-6 points D\n3 points or fewer F",
    "Senate": "11 points A+\n9-10 points A\n7-8 points B\n5-6 points C\n3-4 points D\n2 points or fewer F",
}
VOTE_RULE = (
    "For every vote in line with IAVA Action and in support of veterans, the lawmaker receives one point. "
    "Those who vote against the position of IAVA Action, or those who fail to vote, do not receive a point."
)
BONUS_RULE = (
    "Any Senator or Representative who signed on to be a cosponsor of the Post-9/11 GI Bill "
    "(Senate bill 22, and House bill 5740) receives two additional points."
)


@dataclass(frozen=True, slots=True)
class IAVAReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=URL,
        source_sha256=SOURCE_SHA256,
        message="IAVA's named original 2008 PDF changed; source requalification required",
    )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:iava:listing", hosts=HOSTS)
    _source(source)
    return (EDITION,)


def _index_matches(entry, indices):
    """Exact publisher-only grid/index relation; no fuzzy names or official IDs."""
    record, chamber = entry["record"], entry["chamber_text"]
    last, _, first = record["member_name_text"].partition(", ")
    if last == "Wicker1":  # Printed superscript1 is proved by the original footnote.
        last = "Wicker"
    state = STATE_CODES[record["state_text"]] if chamber == "House" else record["state_text"]
    matches = [
        i
        for i in indices
        if i["chamber_text"] == chamber
        and i["record"]["state_text"] == state
        and i["record"]["district_text"] == record["district_text"]
        and i["record"]["last_name_text"] == last
    ]
    if len(matches) > 1 and first:
        matches = [i for i in matches if i["record"]["first_name_text"] == first]
    if len(matches) != 1:
        raise ValueError
    return matches[0]


def _facts(data):
    """Require every checked grid, index, item header and original context page."""
    try:
        if (
            data["format_version"] != "iava-2008-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 40
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
            or len(data["index_members"]) != sum(INDEX_COUNTS.values())
            or [p["physical_page"] for p in data["context_pages"]] != list(range(1, 41))
            or any(not isinstance(p["native_authored_text"], str) for p in data["context_pages"])
        ):
            raise ValueError
        counts, previous = Counter(), 0
        for entry in data["members"]:
            page, r = entry["physical_page"], entry["record"]
            chamber = "House" if page in range(10, 24) else "Senate"
            votes = 13 if chamber == "House" else 9
            if (
                page not in PAGE_MEMBERS
                or page < previous
                or entry["chamber_text"] != chamber
                or entry["row_ordinal"] != counts[page] + 1
                or set(r)
                != {
                    "state_text",
                    "district_text",
                    "member_name_text",
                    "grade_text",
                    "cosponsor_points_text",
                    "vote_results",
                    "total_text",
                }
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or r["state_text"] not in (STATE_CODES if chamber == "House" else STATE_CODES.values())
                or (chamber == "Senate" and r["district_text"] is not None)
                or (
                    chamber == "House"
                    and re.fullmatch(r"\d+|AL", r["district_text"] or "") is None
                    and (r["district_text"] is not None or r["member_name_text"] != "Wicker1")
                )
                or r["grade_text"] not in {"A+", "A", "B", "C", "D", "F", "INC", "S"}
                or r["cosponsor_points_text"] not in {"0", "2"}
                or len(r["vote_results"]) != votes
                or any(v not in {"1", "0", "A", "*", "S"} for v in r["vote_results"])
                or r["total_text"] not in {*map(str, range(votes + 3)), "INC", "S"}
            ):
                raise ValueError
            raw = " ".join(
                [
                    p
                    for p in (
                        r["district_text"],
                        r["member_name_text"],
                        r["grade_text"],
                        r["cosponsor_points_text"],
                        *r["vote_results"],
                        r["total_text"],
                    )
                    if p is not None
                ]
            )
            raw_forms = {raw}
            if chamber == "Senate":
                # The Oklahoma state heading shares the Coburn/Inhofe row line.
                raw_forms.add(r["state_text"] + " " + raw)
            if " ".join(entry["raw_authored_line"].split()) not in raw_forms:
                raise ValueError
            counts[page] += 1
            previous = page
        if dict(counts) != PAGE_MEMBERS:
            raise ValueError
        counts, identities = Counter(), set()
        for entry in data["index_members"]:
            r, context = entry["record"], (entry["physical_page"], entry["chamber_text"])
            if (
                context not in INDEX_COUNTS
                or entry["row_ordinal"] != counts[context] + 1
                or set(r)
                != {
                    "veteran_glyph_text",
                    "last_name_text",
                    "footnote_text",
                    "first_name_text",
                    "state_text",
                    "district_text",
                    "grade_text",
                }
                or r["veteran_glyph_text"] not in {None, "★"}
                or r["footnote_text"] not in {None, "1"}
                or r["state_text"] not in STATE_CODES.values()
                or any(not isinstance(r[f], str) or not r[f] for f in ["last_name_text", "first_name_text"])
                or r["grade_text"] not in {"A+", "A", "B", "C", "D", "F", "INC", "S"}
                or entry["raw_authored_fields"]
                != [
                    r[f]
                    for f in [
                        "veteran_glyph_text",
                        "last_name_text",
                        "footnote_text",
                        "first_name_text",
                        "state_text",
                        "district_text",
                        "grade_text",
                    ]
                ]
            ):
                raise ValueError
            identity = (
                entry["chamber_text"],
                r["state_text"],
                r["district_text"],
                r["last_name_text"],
                r["first_name_text"],
            )
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[context] += 1
        if dict(counts) != INDEX_COUNTS:
            raise ValueError
        linked = set()
        for entry in data["members"]:
            index = _index_matches(entry, data["index_members"])
            identity = (index["physical_page"], index["chamber_text"], index["row_ordinal"])
            if identity in linked or index["record"]["grade_text"] != entry["record"]["grade_text"]:
                raise ValueError
            linked.add(identity)
        if len(linked) != len(data["index_members"]):
            raise ValueError
        expected = [
            (chamber, page, n) for chamber, pages in ITEM_PAGES.items() for page, nums in pages.items() for n in nums
        ]
        actual = []
        for entry in data["items"]:
            r, chamber, page = entry["record"], entry["chamber_text"], entry["physical_page"]
            actual.append((chamber, page, r["ordinal"]))
            pages = [page] + ([page + 1] if chamber == "House" and r["ordinal"] in (8, 10) else [])
            if (
                r["chamber_text"] != chamber
                or r["paragraph_pages"] != pages
                or r["native_ordinal_text"].replace("ı", "1") != str(r["ordinal"])
                or r["title_text"] != " ".join(r["native_title_text"].split())
                or not r["native_paragraph_text"].startswith(r["native_ordinal_text"] + ". ")
                or r["publisher_position_text"] not in {"IAVA Action Supported", "IAVA Action Opposed"}
                or r["vote_year_text"] not in {"2007", "2008"}
                or re.fullmatch(r"\d+", r["roll_number_text"]) is None
                or not r["item_date_text"]
                or f"{r['vote_year_text']} {chamber} Vote #{r['roll_number_text']}" not in r["native_paragraph_text"]
            ):
                raise ValueError
        if actual != expected:
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError, AttributeError):
        raise ScorecardSourceError("IAVA observations fail the complete qualified source shape") from None


def acquire_scorecard(edition, context: ScorecardContext, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("IAVA's named 2008 PDF needs reviewed private observations")
    source = context.read(URL, stage="scorecards:iava:pdf", hosts=HOSTS)
    _source(source)
    repeated = context.read(URL, stage="scorecards:iava:pdf:reread", hosts=HOSTS)
    _source(repeated)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="iava:qualified-2008",
    )
    try:
        data = json.loads(qualified_observations)
    except (json.JSONDecodeError, UnicodeError):
        raise ScorecardSourceError("IAVA private observations are not qualified JSON") from None
    data = _facts(data)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="IAVA Action Fund",
        parser_version=parser_version,
        rendition_rule="Named complete original 2008 publisher PDF, retained through its explicit archival rendition",
        homepage="http://www.VeteranReportCard.org/",
    )
    groups = ("members", "ratings", "item-results", "items", "methodology", "source-context")
    bundle.use(source, *groups)
    bundle.use(repeated, *groups, role="corroboration")
    loc = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    # Notes are text, not canonical locator columns. Bind secondary locators to
    # this single original PDF edition without making fresh UUIDs source facts.
    note_loc = lambda page, pointer: f"pdf:page={page};source=iava:2008-original-report-pdf;{pointer}"
    pages = {p["physical_page"]: p["native_authored_text"] for p in data["context_pages"]}
    bundle.tables["scorecards"][0].update(
        edition_label_text="2008 Congressional Report Card",
        timespan_text=PERIOD,
        methodology_url=source.url,
        periods_json=json.dumps(
            [
                {
                    "occurrence_id": "0",
                    "period_text": PERIOD,
                    "kind": "explicit",
                    "congress_text": "110",
                    "source_path": loc(5, "/about-our-scoring"),
                },
                {
                    "occurrence_id": "1",
                    "period_text": "2008 Congressional Report Card",
                    "kind": "explicit",
                    "year_text": "2008",
                    "source_path": loc(1, "/title"),
                },
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(5, "/about-our-scoring"),
        methodology_id="source-method",
        methodology_text=pages[5],
        methodology_url=source.url,
        disclosure_status="Explicit votes, bonus points, chamber grade bands, incomplete terms and military-status rule",
    )
    # These are context and repeated grade cohorts, not invented score metrics.
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(4, "/report-context"),
        methodology_id="report-context",
        methodology_text=json.dumps(
            {
                "original_publisher_url": ORIGINAL_URL,
                "context_pages": [
                    {"physical_page": p, "native_authored_text": pages[p]} for p in (1, 3, 4, 29, 30, 31, 40)
                ],
            },
            ensure_ascii=False,
        ),
        methodology_url=source.url,
        disclosure_status="Original introduction, publisher context and complete named A TEAM/D LIST presentations",
    )
    for chamber, page, maximum in (("House", 10, "15"), ("Senate", 26, "11")):
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(page, "/legend-and-chart-header"),
            methodology_id=key(chamber, "legend"),
            chamber_text=chamber,
            methodology_text=pages[page].split("\n" + ("ALABAMA" if chamber == "House" else "AK") + "\n")[0],
            methodology_url=source.url,
            disclosure_status="Literal chart headings and native result/status legend",
        )
        for metric, name, unit, scale in (
            ("grade", "Grade", "grade", GRADE_SCALES[chamber]),
            ("points", "Total", "points", f"out of {maximum} possible points"),
        ):
            bundle.add(
                "scorecard_metrics",
                source,
                loc(page, "/" + metric),
                metric_id=key(chamber, metric),
                methodology_id="source-method",
                name=name,
                chamber_text=chamber,
                period_text=PERIOD,
                value_unit_text=unit,
                scale_text=scale,
            )
        bundle.add(
            "scorecard_metric_components",
            source,
            loc(5, "/grade-bands/" + chamber),
            parent_metric_id=key(chamber, "grade"),
            component_metric_id=key(chamber, "points"),
            combination_rule_text=GRADE_SCALES[chamber],
        )
        item_id = key(chamber, "cosponsor")
        citation = "House bill 5740" if chamber == "House" else "Senate bill 22"
        path = loc(5, "/post-9-11-gi-bill-cosponsor/" + chamber)
        target = "signed on to be a cosponsor"
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item_id,
            item_kind_text="cosponsor",
            title="Post-9/11 GI Bill",
            chamber_text=chamber,
            congress_text="110",
            bill_citation_text=citation,
            publisher_position_text=target,
            position_basis="explicit",
            position_source_path=path,
            references_json=json.dumps(
                [
                    {
                        "occurrence_id": "0",
                        "citation_text": citation,
                        "kind": "bill",
                        "bill_citation_text": citation,
                        "chamber_text": chamber,
                        "congress_text": "110",
                        "source_path": path,
                    }
                ]
            ),
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "points"),
            item_id=item_id,
            participation_id="source-points",
            methodology_id="source-method",
            publisher_position_text=target,
            position_basis="explicit",
            weight_text="two additional points",
            weight_number="2",
            contribution_rule_text=BONUS_RULE,
            counts_toward_metric="true",
        )
    for i, entry in enumerate(data["items"]):
        r, chamber = entry["record"], entry["chamber_text"]
        item_id = key(chamber, "vote", str(r["ordinal"]))
        path = loc(entry["physical_page"], f"/items/{i}/record")
        citation = f"{r['vote_year_text']} {chamber} Vote #{r['roll_number_text']}"
        references = [
            {
                "occurrence_id": "0",
                "citation_text": citation,
                "kind": "roll_call",
                "chamber_text": chamber,
                "congress_text": "110",
                "roll_number_text": r["roll_number_text"],
                "source_path": path + "/roll_number_text",
            }
        ]
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item_id,
            publisher_item_id=r["native_ordinal_text"],
            item_kind_text="key votes",
            title=r["title_text"],
            item_date_text=r["item_date_text"],
            congress_text="110",
            chamber_text=chamber,
            roll_number_text=r["roll_number_text"],
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
            references_json=json.dumps(references),
        )
        method = key("item", chamber, str(r["ordinal"]))
        narrative_loc = f"pdf:pages={','.join(map(str, r['paragraph_pages']))};observation={observation};/items/{i}/native-paragraph"
        bundle.add(
            "scorecard_methodologies",
            source,
            narrative_loc,
            methodology_id=method,
            chamber_text=chamber,
            methodology_text=json.dumps(r, ensure_ascii=False),
            methodology_url=source.url,
            disclosure_status="Literal numbered item header, vote year and complete source paragraph, including continuation pages and cross-references",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "points"),
            item_id=item_id,
            participation_id="source-points",
            methodology_id=method,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            weight_text="one point",
            weight_number="1",
            contribution_rule_text=VOTE_RULE,
            counts_toward_metric="true",
        )
    for i, entry in enumerate(data["members"]):
        r, chamber = entry["record"], entry["chamber_text"]
        index = _index_matches(entry, data["index_members"])
        native = index["record"]
        identity = key(
            chamber,
            native["state_text"],
            native["district_text"] or "blank-district",
            native["last_name_text"],
            native["first_name_text"],
        )
        path = loc(entry["physical_page"], f"/members/{i}/record")
        index_path = loc(index["physical_page"], f"/index/{index['chamber_text']}/{index['row_ordinal']}")
        notes = {
            "native_grid_fields": r,
            "raw_authored_line": entry["raw_authored_line"],
            "native_index_fields": native,
            "raw_index_fields": index["raw_authored_fields"],
            "grid_source_path": note_loc(entry["physical_page"], f"/members/{i}/record"),
            "index_source_path": note_loc(
                index["physical_page"], f"/index/{index['chamber_text']}/{index['row_ordinal']}"
            ),
            "index_link_rule": "Exact source chamber, state heading/abbreviation, district and last name; exact printed first-name disambiguation only when needed",
        }
        if r["member_name_text"] == "Wicker1":
            notes["source_footnotes"] = [
                {
                    "source_path": note_loc(p, "/Wicker-footnote"),
                    "native_text": pages[p].split("\n")[-1 if p == 17 else -3],
                }
                for p in (17, 37)
            ]
            # Keep both complete native footnote passages; line wraps stay literal.
            notes["source_footnotes"][1]["native_text"] = pages[37][pages[37].index("1 Roger Wicker,") :]
        bundle.add(
            "scorecard_members",
            source,
            index_path,
            publisher_member_key=identity,
            member_name=native["first_name_text"] + " " + native["last_name_text"],
            state=native["state_text"],
            district=native["district_text"],
            chamber_text=chamber,
            period_text=PERIOD,
            notes_text=json.dumps(notes, ensure_ascii=False),
        )
        for metric, field_name in (("grade", "grade_text"), ("points", "total_text")):
            value = r[field_name]
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/" + field_name,
                metric_id=key(chamber, metric),
                publisher_member_key=identity,
                value_text=value,
                value_number=value if metric == "points" and value.isdecimal() else None,
                value_status_text=value if value in {"INC", "S"} else None,
                notes_text=json.dumps(
                    {
                        "native_value": value,
                        "index_grade_text": native["grade_text"],
                        "index_source_path": note_loc(
                            index["physical_page"], f"/index/{index['chamber_text']}/{index['row_ordinal']}"
                        ),
                    },
                    ensure_ascii=False,
                ),
            )
        for ordinal, value in enumerate([r["cosponsor_points_text"], *r["vote_results"]]):
            item_id = key(chamber, "cosponsor") if ordinal == 0 else key(chamber, "vote", str(ordinal))
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + ("/cosponsor_points_text" if ordinal == 0 else f"/vote_results/{ordinal - 1}"),
                item_id=item_id,
                metric_id=key(chamber, "points"),
                participation_id="source-points",
                publisher_member_key=identity,
                result_id="source-cell",
                result_text=value,
                contribution_text=value if ordinal == 0 else None,
                contribution_number=value if ordinal == 0 else None,
            )
    return bundle.finish(
        "Exact reviewed original PDF and private observations; stable complete reread; all member grid and index pages, "
        "source-only one-to-one index links, item ordinals and result cells reconcile. Grades, points, stars, source blanks and "
        "INC/S/A/* glyphs survive; no official identities/actions or score reproduction inferred.",
        declared={"key_votes": "22", "House_key_votes": "13", "Senate_key_votes": "9", "incomplete_members": "30"},
    )
