"""Food Policy Action's named original lifetime PDF, with no inferred year.

The source table contains literal Senate district zeros and a lowercase n/a
score. Preserve the former and normalize only the native missing-value columns.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "food-policy-action-lifetime-qualified-pdf/1"
ORIGINAL_URL = "https://foodpolicyaction.org/wp-content/uploads/FPA-EWG-AF-Lifetime-Scorecard.pdf"
URL = "https://web.archive.org/web/20201101080039id_/" + ORIGINAL_URL
HOSTS = ("web.archive.org",)
SOURCE_SHA256 = "5b5144f8d84d2396b3961c5d78ab4a9c9938428439532134a073f7bbab9d2845"
QUALIFIED_SHA256 = "7c25ddf3a87603310ce34c9670510c33728a408e54d8beb8cb8be172cba4d17e"
HEADER = "State Title Name Party District LIFETIME SCORE"
PUBLISHER_LABELS = ["FOOD POLICY ACTION", "EWG ACTION FUND"]
PAGE_MEMBERS = {page: 30 if page == 5 else 15 if page == 18 else 31 for page in range(1, 19)}
EDITION = ScorecardEdition(
    "food_policy_action", "lifetime-archived-pdf", URL, "LIFETIME SCORE", chamber="both", is_current=False
)


@dataclass(frozen=True, slots=True)
class FoodPolicyActionLifetimeReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=URL,
        source_sha256=SOURCE_SHA256,
        message="Food Policy Action's reviewed lifetime original PDF changed; source requalification required",
    )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:food_policy_action:lifetime:listing", hosts=HOSTS)
    _source(source)
    return (EDITION,)


def _facts(data):
    """Require the entire reviewed PDF roster without applying official office rules."""
    try:
        if (
            data["format_version"] != "food-policy-action-lifetime-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 18
            or data["header_text"] != HEADER
            or data["publisher_labels"] != PUBLISHER_LABELS
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            page, record = entry["physical_page"], entry["record"]
            if (
                page not in counts
                or page < previous
                or entry["row_ordinal"] != counts[page] + 1
                or set(record)
                != {"state_text", "title_text", "member_name_text", "party_text", "district_text", "value_text"}
                or (
                    record["member_name_text"] is not None
                    and (not isinstance(record["member_name_text"], str) or not record["member_name_text"])
                )
                or re.fullmatch(r"[A-Za-z.]+", record["state_text"]) is None
                or record["title_text"] not in {"Sen", "Rep"}
                or record["party_text"] not in {"D", "R", "I", None}
                or (
                    record["district_text"] is not None
                    and re.fullmatch(r"\d+|At-Large", record["district_text"]) is None
                )
                or (
                    record["value_text"] != "n/a"
                    and (
                        re.fullmatch(r"\d{1,3}%", record["value_text"]) is None or int(record["value_text"][:-1]) > 100
                    )
                )
            ):
                raise ValueError
            if (record["member_name_text"] is None or record["party_text"] is None) and record != {
                "state_text": "Md.",
                "title_text": "Rep",
                "member_name_text": None,
                "party_text": None,
                "district_text": "7",
                "value_text": "100%",
            }:
                raise ValueError
            identity = (record["title_text"], record["state_text"], record["district_text"], record["member_name_text"])
            raw = " ".join(
                record[field]
                for field in (
                    "state_text",
                    "title_text",
                    "member_name_text",
                    "party_text",
                    "district_text",
                    "value_text",
                )
                if record[field] is not None
            )
            if identity in identities or entry["raw_authored_line"] != raw:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        if counts != PAGE_MEMBERS:
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "Food Policy Action lifetime facts do not establish the complete reviewed PDF roster"
        ) from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Food Policy Action lifetime PDF requires reviewed facts and private retention")
    source = context.read(URL, stage="scorecards:food_policy_action:lifetime:report", hosts=HOSTS)
    _source(source)
    reread = context.read(URL, stage="scorecards:food_policy_action:lifetime:reread", hosts=HOSTS)
    _source(reread)
    if source.body != reread.body:
        raise ScorecardSourceError("Food Policy Action lifetime PDF changed during its complete reread")
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="food_policy_action:qualified-lifetime-pdf",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Food Policy Action",
        parser_version=parser_version,
        rendition_rule="Complete original archived lifetime-rating PDF; no year, Congress, item grid or formula inferred",
        homepage="https://foodpolicyaction.org/",
    )
    bundle.use(source, "lifetime-ratings-and-native-member-context")
    bundle.use(reread, "lifetime-ratings-and-native-member-context", role="corroboration")
    card = bundle.tables["scorecards"][0]
    card.update(
        timespan_text="LIFETIME",
        edition_label_text="LIFETIME SCORE",
        source_path="pdf:pages=1-18",
        publisher_name_text="\n".join(data["publisher_labels"]),
    )
    bundle.add(
        "scorecard_metrics",
        source,
        "pdf:pages=1-18;header=LIFETIME SCORE",
        metric_id="lifetime",
        name="LIFETIME SCORE",
        period_text="LIFETIME",
        is_primary="true",
        value_unit_text="%",
    )
    for entry in data["members"]:
        record = entry["record"]
        identity = key(
            record["title_text"],
            record["state_text"],
            record["district_text"] or "blank-district",
            record["member_name_text"] or "blank-name",
        )
        path = f"pdf:page={entry['physical_page']};row={entry['row_ordinal']};observation={observation}"
        notes = json_column({"raw_authored_line": entry["raw_authored_line"], "native_fields": record})
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            chamber_text=record["title_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            period_text="LIFETIME",
            notes_text=notes,
        )
        value = "N/A" if record["value_text"] == "n/a" else record["value_text"]
        bundle.add(
            "scorecard_member_ratings",
            source,
            path + ";column=LIFETIME SCORE",
            metric_id="lifetime",
            publisher_member_key=identity,
            value_text=value,
            value_number=decimal_text(value),
            value_status_text="N/A" if value == "N/A" else None,
            notes_text=notes,
        )
    return bundle.finish(
        "Complete original PDF header/trailer and exact source pin; every reviewed page and member field reconciled; full roster page counts and unique literal identities; independent complete PDF reread matches."
    )
