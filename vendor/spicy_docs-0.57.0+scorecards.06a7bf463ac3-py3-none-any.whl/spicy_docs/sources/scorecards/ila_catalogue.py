"""ILA's complete original federal JSON leaderboard and weighted item catalogues."""

from __future__ import annotations

import json
import re
from urllib.parse import urljoin

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "ila-federal-native-api-catalogue/1"
BASE = "https://analysis.limitedgov.org"
INDEX = BASE + "/"
HOSTS = ("analysis.limitedgov.org", "www.limitedgov.org", "limitedgov.org", "scorecard.limitedgov.org")
METHOD = "https://www.limitedgov.org/methodology/"
CATEGORIES = BASE + "/api/legislatorScorecard/categories?organizationId=1"
ARTICLES = BASE + "/api/legislationPage/articles?organizationId=1&state=US"
MEMBER_FIELDS = {
    "id",
    "name",
    "first",
    "middle",
    "last",
    "suffix",
    "nickname",
    "role",
    "party",
    "district",
    "state",
    "from",
    "score",
    "points",
    "total",
    "votes",
    "weightSum",
    "meetsThreshold",
    "imageUrl",
    "thumbnailUrl",
    "rank",
    "chamber",
}
ARTICLE_FIELDS = {
    "articleId",
    "title",
    "description",
    "ilaPosition",
    "momsPosition",
    "weight",
    "categories",
    "year",
    "chamber",
    "billNumber",
    "status",
    "inFavor",
    "opposed",
    "state",
    "articleType",
}
MEASUREMENTS = ("score", "points", "total", "votes", "weightSum")


def _literal(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _number(value):
    if type(value) is int:
        return str(value)
    if isinstance(value, str) and decimal_text(value) is not None:
        return value
    raise ScorecardSourceError("ILA native numerical value is missing or has an unreviewed spelling")


def leaderboard_url(period):
    return (
        BASE
        + "/api/leaderboardPage/leaderboardData?organizationId=1&state=US&year="
        + period
        + "&needCongressAndState=false"
    )


def _application(source):
    document = soup(source)
    selected = document.select("script#__NEXT_DATA__")
    try:
        if len(selected) != 1:
            raise ValueError
        from spicy_docs.sources.scorecards.common import _invalid_json_constant, _unique_json_fields

        data = json.loads(
            selected[0].get_text(), object_pairs_hook=_unique_json_fields, parse_constant=_invalid_json_constant
        )
        props = data["props"]["pageProps"]
        organization = props["organization"]
        if (
            data["page"] != "/"
            or organization["id"] != "1"
            or organization["name"] != "Institute for Legislative Analysis"
            or organization["host"] != "analysis.limitedgov.org"
            or organization["settings"]["website"] != "https://scorecard.limitedgov.org/"
            or props["origin"] != BASE
        ):
            raise ValueError
        years = sorted({str(pair["year"]) for pair in props["yearsAndStates"] if pair["state"] == "US"})
        if not years or any(not re.fullmatch(r"20\d\d", year) for year in years):
            raise ValueError
        scripts = [script.get("src", "") for script in document.find_all("script")]
        matches = [url for url in scripts if re.fullmatch(r"/_next/static/chunks/pages/_app-[a-f0-9]+\.js", url)]
        if len(matches) != 1:
            raise ValueError
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("ILA original organization or native federal period selection changed") from None
    return organization, tuple(years), urljoin(source.url, matches[0])


def _loader(source):
    try:
        text = source.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("ILA native loader is not UTF-8") from None
    required = [
        "/api/leaderboardPage/leaderboardData?organizationId=",
        "&state=",
        "&year=",
        "&needCongressAndState=",
        "/api/legislationPage/articles?organizationId=",
        "/api/legislatorScorecard/categories?organizationId=",
    ]
    if any(fragment not in text for fragment in required):
        raise ScorecardSourceError("ILA native API loader endpoints changed")


def _catalog(app, leaderboard):
    organization, years, _ = _application(app)
    raw = json_data(leaderboard)
    if not isinstance(raw, dict) or set(raw) != {
        "people",
        "maxYearMatch",
        "uniqueParties",
        "uniqueYears",
        "stateYearCoupling",
    }:
        raise ScorecardSourceError("ILA original leaderboard root shape changed")
    periods = raw["uniqueYears"]
    if (
        not isinstance(periods, list)
        or any(
            not isinstance(p, dict)
            or set(p) != {"label", "value"}
            or not isinstance(p["value"], str)
            or not isinstance(p["label"], str)
            for p in periods
        )
        or len({p["value"] for p in periods}) != len(periods)
        or {p["value"] for p in periods} != set(years) | {"lifetime"}
        or any(p["label"] != ("Lifetime" if p["value"] == "lifetime" else p["value"]) for p in periods)
    ):
        raise ScorecardSourceError("ILA original federal leaderboard periods do not reconcile")
    return tuple(
        ScorecardEdition(
            "ila",
            p["value"] + "-api-catalogue",
            leaderboard_url(p["value"]),
            organization["settings"]["title"],
            year=None if p["value"] == "lifetime" else p["value"],
            chamber="both",
            is_current=p["value"] in {max(years), "lifetime"},
        )
        for p in periods
    )


def _roster(source, years):
    data = json_data(source)
    if (
        not isinstance(data, dict)
        or set(data) != {"people", "maxYearMatch", "uniqueParties", "uniqueYears", "stateYearCoupling"}
        or type(data["maxYearMatch"]) is not bool
        or not data["maxYearMatch"]
        or not isinstance(data["people"], list)
        or not data["people"]
    ):
        raise ScorecardSourceError("ILA native complete federal leaderboard is absent or changed")
    coupling = data["stateYearCoupling"]
    if not isinstance(coupling, list) or any(
        not isinstance(pair, dict)
        or set(pair) != {"state", "year"}
        or not isinstance(pair["state"], str)
        or type(pair["year"]) is not int
        for pair in coupling
    ):
        raise ScorecardSourceError("ILA native state/year coupling changed")
    native_years = {str(pair["year"]) for pair in coupling if pair["state"] == "US"}
    if native_years != set(years):
        raise ScorecardSourceError("ILA native leaderboard federal year set changed")
    identities = set()
    for member in data["people"]:
        if (
            not isinstance(member, dict)
            or set(member) != MEMBER_FIELDS
            or not isinstance(member["id"], str)
            or not member["id"]
            or member["id"] in identities
            or member["state"] != "US"
            or not isinstance(member["name"], str)
            or not all(isinstance(member[field], str) and member[field] for field in ["party", "from"])
            or member["chamber"] not in {"House", "Senate"}
            or type(member["meetsThreshold"]) is not bool
            or type(member["rank"]) is not int
            or member["rank"] < 1
        ):
            raise ScorecardSourceError("ILA native member identity, rank or threshold flag changed")
        identities.add(member["id"])
        for field in MEASUREMENTS:
            _number(member[field])
    if {m["chamber"] for m in data["people"]} != {"House", "Senate"}:
        raise ScorecardSourceError("ILA federal source leaderboard is missing a chamber")
    return data


def _items(source, categories, years):
    data, taxonomy = json_data(source), json_data(categories)
    if (
        not isinstance(taxonomy, dict)
        or set(taxonomy) != {"categories"}
        or not isinstance(taxonomy["categories"], list)
        or not taxonomy["categories"]
        or any(
            not isinstance(c, dict)
            or set(c) != {"id", "name"}
            or type(c["id"]) is not int
            or not isinstance(c["name"], str)
            or not c["name"]
            for c in taxonomy["categories"]
        )
        or len({c["id"] for c in taxonomy["categories"]}) != len(taxonomy["categories"])
    ):
        raise ScorecardSourceError("ILA native category taxonomy changed")
    if (
        not isinstance(data, dict)
        or set(data) != {"articles", "uniqueCategories", "uniqueYears", "categoryPairs"}
        or not isinstance(data["articles"], list)
        or not data["articles"]
        or not isinstance(data["uniqueYears"], list)
        or any(type(y) is not int for y in data["uniqueYears"])
        or {str(y) for y in data["uniqueYears"]} != set(years)
        or not isinstance(data["uniqueCategories"], list)
        or any(not isinstance(c, str) for c in data["uniqueCategories"])
        or not isinstance(data["categoryPairs"], list)
        or any(
            not isinstance(pair, dict) or set(pair) != {"id", "name"} or pair not in taxonomy["categories"]
            for pair in data["categoryPairs"]
        )
    ):
        raise ScorecardSourceError("ILA native federal item catalogue is absent or changed")
    names = {c["name"] for c in taxonomy["categories"]}
    identities = set()
    for item in data["articles"]:
        if (
            not isinstance(item, dict)
            or set(item) != ARTICLE_FIELDS
            or not isinstance(item["articleId"], str)
            or not item["articleId"]
            or item["articleId"] in identities
            or item["state"] != "US"
            or item["chamber"] not in {"House", "Senate"}
            or str(item["year"]) not in years
            or not isinstance(item["title"], str)
            or not item["title"]
            or not isinstance(item["ilaPosition"], str)
            or not item["ilaPosition"]
            or not isinstance(item["categories"], list)
            or not item["categories"]
            or any(not isinstance(category, str) for category in item["categories"])
            or not set(item["categories"]) <= names
        ):
            raise ScorecardSourceError("ILA native federal item identity, year, position or category changed")
        identities.add(item["articleId"])
        _number(item["weight"])
    actual_categories = {name for item in data["articles"] for name in item["categories"]}
    if (
        actual_categories != set(data["uniqueCategories"])
        or {p["name"] for p in data["categoryPairs"]} != actual_categories
    ):
        raise ScorecardSourceError("ILA native item category summary does not reconcile")
    return data, taxonomy


def _methodology(source):
    document = soup(source)
    headings = [h for h in document.find_all(["h1", "h2"]) if h.get_text(" ", strip=True) == "Methodology"]
    if not headings:
        raise ScorecardSourceError("ILA original methodology page identity changed")
    if len(document.select(".entry-content")) != 1:
        raise ScorecardSourceError("ILA original methodology content selection changed")
    blocks = [node.get_text(" ", strip=True) for node in document.select(".entry-content .et_pb_text_inner")]
    if (
        not blocks
        or any(not block for block in blocks)
        or not any("Limited Government Index" in block and "voting records" in block for block in blocks)
        or not any("percentage scale" in block for block in blocks)
    ):
        raise ScorecardSourceError("ILA original methodology disclosures changed")
    return blocks


def list_scorecards(context):
    app = context.read(INDEX, stage="scorecards:ila:listing-app", hosts=HOSTS)
    _, years, _ = _application(app)
    roster = context.read(leaderboard_url(max(years)), stage="scorecards:ila:listing-api", hosts=HOSTS)
    _roster(roster, years)
    return _catalog(app, roster)


def acquire_scorecard(edition, context):
    app = context.read(INDEX, stage="scorecards:ila:app-start", hosts=HOSTS)
    organization, years, loader_url = _application(app)
    loader = context.read(loader_url, stage="scorecards:ila:loader-start", hosts=HOSTS)
    _loader(loader)
    source = context.read(edition.source_url, stage="scorecards:ila:leaderboard-start", hosts=HOSTS)
    if edition not in _catalog(app, source):
        raise ScorecardSourceError("Selected ILA native federal period is absent or changed")
    period = next(
        p["value"] for p in json_data(source)["uniqueYears"] if p["value"] + "-api-catalogue" == edition.edition_id
    )
    roster = _roster(source, years)
    articles = context.read(ARTICLES, stage="scorecards:ila:articles-start", hosts=HOSTS)
    categories = context.read(CATEGORIES, stage="scorecards:ila:categories-start", hosts=HOSTS)
    items, taxonomy = _items(articles, categories, years)
    method = context.read(METHOD, stage="scorecards:ila:methodology-start", hosts=HOSTS)
    paragraphs = _methodology(method)
    source_end = context.read(edition.source_url, stage="scorecards:ila:leaderboard-end", hosts=HOSTS)
    articles_end = context.read(ARTICLES, stage="scorecards:ila:articles-end", hosts=HOSTS)
    categories_end = context.read(CATEGORIES, stage="scorecards:ila:categories-end", hosts=HOSTS)
    method_end = context.read(METHOD, stage="scorecards:ila:methodology-end", hosts=HOSTS)
    loader_end = context.read(loader_url, stage="scorecards:ila:loader-end", hosts=HOSTS)
    _loader(loader_end)
    app_end = context.read(INDEX, stage="scorecards:ila:app-end", hosts=HOSTS)
    if (
        _roster(source_end, years) != roster
        or _items(articles_end, categories_end, years) != (items, taxonomy)
        or _methodology(method_end) != paragraphs
        or loader_end.body != loader.body
        or _application(app_end) != _application(app)
        or _catalog(app_end, source_end) != _catalog(app, source)
    ):
        raise ScorecardSourceError("ILA native federal catalogue changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=organization["name"],
        parser_version=parser_version,
        rendition_rule="ila-native-api-leaderboard-and-weighted-items/1",
        homepage="https://www.limitedgov.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        edition_label_text="Lifetime" if period == "lifetime" else period,
        methodology_url=method.url,
        series_id=key("ila", organization["settings"]["title"]),
    )
    for document, groups in [
        (app, ("organization", "federal_periods")),
        (loader, ("api_selection",)),
        (source, ("members", "ratings")),
        (articles, ("items",)),
        (categories, ("taxonomy",)),
        (method, ("methodology",)),
    ]:
        bundle.use(document, *groups)
    for document, groups in [
        (app_end, ("organization", "federal_periods")),
        (loader_end, ("api_selection",)),
        (source_end, ("members", "ratings")),
        (articles_end, ("items",)),
        (categories_end, ("taxonomy",)),
        (method_end, ("methodology",)),
    ]:
        bundle.use(document, *groups, role="corroboration")
    bundle.add(
        "scorecard_methodologies",
        app,
        "script#__NEXT_DATA__/props/pageProps/organization",
        methodology_id="native-organization",
        methodology_text=_literal(organization),
        methodology_url=app.url,
        disclosure_status="literal original organization settings and publisher selection",
    )
    bundle.add(
        "scorecard_methodologies",
        categories,
        "/categories",
        methodology_id="native-categories",
        methodology_text=_literal(taxonomy),
        methodology_url=categories.url,
        disclosure_status="literal original category taxonomy, including categories outside federal item catalogue",
    )
    for ordinal, text in enumerate(paragraphs):
        bundle.add(
            "scorecard_methodologies",
            method,
            f".entry-content .et_pb_text_inner/{ordinal}",
            methodology_id=key("block", str(ordinal)),
            methodology_text=text,
            methodology_url=method.url,
        )
    for field in MEASUREMENTS:
        bundle.metric(
            source,
            field,
            field,
            path="/people/*/" + field,
            unit="percent" if field == "score" else None,
            primary=field == "score",
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = "Lifetime" if period == "lifetime" else period
    selected = [item for item in items["articles"] if period == "lifetime" or str(item["year"]) == period]
    for ordinal, item in enumerate(items["articles"]):
        if item not in selected:
            continue
        path = f"/articles/{ordinal}"
        identifier = key("article", item["articleId"])
        refs = []
        if item["billNumber"]:
            refs.append(
                {
                    "occurrence_id": "billNumber",
                    "kind": "citation",
                    "citation_text": item["billNumber"],
                    "source_path": path + "/billNumber",
                }
            )
        bundle.add(
            "scorecard_items",
            articles,
            path,
            item_id=identifier,
            publisher_item_id=item["articleId"],
            title=item["title"],
            item_kind_text=item["articleType"],
            chamber_text=item["chamber"],
            bill_citation_text=item["billNumber"],
            references_json=_literal(refs),
            publisher_position_text=item["ilaPosition"],
            position_basis="explicit",
            position_source_path=path + "/ilaPosition",
        )
        bundle.add(
            "scorecard_metric_items",
            articles,
            path + "/weight",
            metric_id="score",
            item_id=identifier,
            participation_id="native-weight",
            publisher_position_text=item["ilaPosition"],
            position_basis="explicit",
            weight_text=_number(item["weight"]),
            weight_number=_number(item["weight"]),
        )
        bundle.add(
            "scorecard_methodologies",
            articles,
            path,
            methodology_id=key("article", item["articleId"]),
            chamber_text=item["chamber"],
            effective_at_text=str(item["year"]),
            methodology_text=_literal(item),
            methodology_url=articles.url,
            disclosure_status="literal original item metadata and signed weight; no inferred roll call or score reproduction",
        )
    for ordinal, member in enumerate(roster["people"]):
        path = f"/people/{ordinal}"
        member_key = key("person", member["id"])
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            member_name=member["name"],
            state=member["from"],
            district=member["district"] or None,
            party=member["party"],
            chamber_text=member["chamber"],
            period_text="Lifetime" if period == "lifetime" else period,
            identifiers_json=_literal([{"scheme": "limitedgov.org:person", "value": member["id"]}]),
            notes_text=_literal(member),
        )
        for field in MEASUREMENTS:
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/" + field,
                metric_id=field,
                publisher_member_key=member_key,
                value_text=_number(member[field]),
                value_number=_number(member[field]),
                value_status_text="true" if member["meetsThreshold"] else "false",
                rank_text=str(member["rank"]) if field == "score" else None,
                notes_text=_literal({"meetsThreshold": member["meetsThreshold"]}),
            )
    return bundle.finish(
        "Complete native federal JSON people/item/category arrays and publisher period membership; every unique source identity and native score/threshold/rank/weight spelling preserved; stable complete rereads. Named API catalogue rendition excludes member-specific detail/actions, display rounding and calculated display N/A; no official congressional acquisition or score reproduction."
    )
