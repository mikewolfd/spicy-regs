"""Named complete national DAV Capwiz originals; regional DAV chapters are separate sources."""

import re
from collections import Counter
from copy import deepcopy

from bs4 import Comment

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

from . import capwiz_html
from .capwiz_html import header as _header
from .capwiz_html import native as _native
from .capwiz_html import text as _text

parser_version = "dav-named-capwiz-html/2"
ORIGINAL = "http://capwiz.com/dav/scorecard.xc"
HOSTS = ("web.archive.org",)
RENDITIONS = {
    "110-2-house-archived-native": ("20080922195159", "110", ("house",), (2,)),
    "109-2-both-archived-native": ("20061121145631", "109", ("senate", "house"), (5, 4)),
}
LEGEND = {
    "Y": "Voted Yes (No position by organization)",
    "N": "Voted No (No position by organization)",
    "+": "Voted With Us",
    "-": "Voted Against Us",
    "P": "Voted Present",
    "NV": "Did Not Vote",
    "I": "Not in Office",
    "S": "Speaker (Typically the speaker does not participate in roll call votes.)",
}
# Measured named original populations, including source replacement occurrences;
# these are neither official-roster counts nor publisher-declared totals.
HOUSE_110 = dict(
    zip(
        [
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY",
        ],
        (
            7,
            1,
            8,
            4,
            54,
            7,
            5,
            1,
            25,
            13,
            2,
            2,
            20,
            10,
            5,
            4,
            6,
            9,
            2,
            9,
            10,
            15,
            8,
            5,
            9,
            1,
            3,
            3,
            2,
            13,
            3,
            29,
            13,
            1,
            18,
            5,
            5,
            19,
            2,
            6,
            1,
            9,
            32,
            3,
            1,
            11,
            9,
            3,
            8,
            1,
        ),
        strict=True,
    )
)
HOUSE_109 = {**HOUSE_110, "IL": 19, "IN": 9, "LA": 7, "MD": 8, "MS": 4, "NJ": 14, "TX": 33}
REVIEWED_ROWS = {
    "110-2-house-archived-native": {"house": HOUSE_110},
    "109-2-both-archived-native": {"senate": dict.fromkeys(HOUSE_110, 2), "house": HOUSE_109},
}
MEMBER = re.compile(r"(?:(\d+)\. )?(.+) \(([A-Z])-([A-Z]{2})(?:-(AL|\d+))?\)")
CITATIONS = capwiz_html.CITATIONS
ITEM = capwiz_html.ITEM


def edition(edition_id):
    if edition_id not in RENDITIONS:
        raise ScorecardSourceError("DAV edition is outside the named national originals")
    timestamp, congress, chambers, _ = RENDITIONS[edition_id]
    return ScorecardEdition(
        "dav",
        edition_id,
        "https://web.archive.org/web/" + timestamp + "id_/" + ORIGINAL,
        "Federal Vote Scorecard - " + congress + "th Congress, Second Session",
        congress=congress,
        chamber="both" if len(chambers) == 2 else chambers[0],
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return tuple(edition(name) for name in RENDITIONS)


def _children(node, allowed):
    return capwiz_html.authored_children(node, allowed, publisher="DAV")


def _items(dl, chamber, congress, ordinal, expected):
    return capwiz_html.items(
        dl, chamber, congress, ordinal, expected, publisher="DAV", detail_in_span=congress == "110"
    )


def _grid(table, chamber, items, ordinal, populations, has_positions):
    path = "(//table[@id='votes'])[" + str(ordinal) + "]"
    if (
        table.get("summary")
        != "This table contains U.S. "
        + ("House of Representatives" if chamber == "house" else "Senate")
        + " Key Votes by state."
    ):
        raise ScorecardSourceError("DAV native table chamber statement changed")
    rows = _children(table, {"tr"})
    headers, members, states, counts, positions = [], [], [], Counter(), None
    for n, row in enumerate(rows, 1):
        row_path = path + "/tr[" + str(n) + "]"
        cells = _children(row, {"th", "td"})
        rid = row.get("id", "")
        if len(cells) == 1 and not _text(row) and cells[0].name == "td":
            if cells[0].find():
                raise ScorecardSourceError("DAV spacer contains unreviewed content")
            headers.append(_header(row, row_path, cells))
            continue
        if len(cells) != len(items) + 2:
            raise ScorecardSourceError("DAV complete native grid width changed")
        if not rid:
            label = _text(cells[0])
            values = [_text(c) for c in cells[1:-1]]
            if not has_positions or n not in (1, 2) or cells[0].name != "th" or _text(cells[-1]):
                raise ScorecardSourceError("DAV unreviewed global header")
            if n == 1 and (label != "Congressional Session" or values != ["2"] * len(items)):
                raise ScorecardSourceError("DAV native session header changed")
            if n == 2:
                if label != "Disabled American Veterans Vote Position" or any(v not in LEGEND for v in values):
                    raise ScorecardSourceError("DAV preferred-position header changed")
                positions = values
        elif re.fullmatch(r"STATE_[A-Z]{2}_0", rid):
            state = rid.split("_")[1]
            if state not in populations or state in states or cells[0].name != "th" or _text(cells[-1]) != "Score":
                raise ScorecardSourceError("DAV state/header inventory is incomplete or repeated")
            states.append(state)
            for j, (cell, item) in enumerate(zip(cells[1:-1], items, strict=True), 1):
                anchors = _children(cell, {"a"})
                if (
                    len(anchors) != 1
                    or _text(cell) != str(j)
                    or anchors[0].get("href") != item["href"]
                    or anchors[0].get("title") != item["title_text"].removeprefix(str(j) + ". ")
                ):
                    raise ScorecardSourceError("DAV repeated state item labels conflict with complete explanations")
        elif re.fullmatch(r"STATE_[A-Z]{2}_[1-9]\d*", rid):
            state, publisher_id = rid.split("_")[1:]
            if not states or state != states[-1] or any(c.name != "td" or c.find() for c in cells):
                raise ScorecardSourceError("DAV member cells have unreviewed content or state placement")
            identity = _text(cells[0])
            match = MEMBER.fullmatch(identity)
            if not match or match[4] != state or (chamber == "senate" and (match[1] or match[5])):
                raise ScorecardSourceError("DAV source identity does not fit its literal chamber/state fields")
            prefix, name, party, _, district = match.groups()
            if prefix and district and prefix != district:
                raise ScorecardSourceError("DAV source district fields disagree")
            actions = [_text(c) or None for c in cells[1:-1]]
            score = _text(cells[-1]) or None
            if any(a is not None and a not in LEGEND for a in actions) or (
                score is not None and not re.fullmatch(r"\d+(?:\.\d+)?%", score)
            ):
                raise ScorecardSourceError("DAV literal action or score vocabulary changed")
            if any(m["publisher_id"] == publisher_id for m in members):
                raise ScorecardSourceError("DAV member publisher identity is repeated within one chamber")
            members.append(
                {
                    "publisher_id": publisher_id,
                    "row_id": rid,
                    "path": row_path,
                    "name": name,
                    "party": party,
                    "state": state,
                    "district": district or prefix,
                    "identity": identity,
                    "district_prefix": prefix,
                    "district_suffix": district,
                    "actions": actions,
                    "score": score,
                    "row_attributes": dict(row.attrs),
                    "cells": [_native(c, row_path + "/td[" + str(j) + "]") for j, c in enumerate(cells, 1)],
                }
            )
            counts[state] += 1
            continue
        else:
            raise ScorecardSourceError("DAV row is outside its complete native state/member structure")
        headers.append(_header(row, row_path, cells))
    if dict(counts) != populations or set(states) != set(populations) or (has_positions and positions is None):
        raise ScorecardSourceError("DAV complete named source population or preferred header is missing")
    return {
        "path": path,
        "attributes": dict(table.attrs),
        "headers": headers,
        "members": members,
        "positions": positions,
    }


def _facts(document, selected):
    if document.url != selected.source_url or document.response.requested_url != selected.source_url:
        raise ScorecardSourceError("DAV archive custody escaped the selected original route")
    if (
        not document.body.rstrip().lower().endswith(b"</html>")
        or "html" not in (document.response.content_type or "").lower()
    ):
        raise ScorecardSourceError("DAV original HTML is incomplete or the format changed")
    html = soup(document)
    if (
        len(html.select("html")) != 1
        or len(html.select("body")) != 1
        or len(html.select("#grid h1")) != 1
        or _text(html.select_one("#grid h1")) != selected.title
    ):
        raise ScorecardSourceError("DAV national original document/period boundary changed")
    _, congress, chambers, item_counts = RENDITIONS[selected.edition_id]
    tables, explanations, headings = html.select("table#votes"), html.select("dl#keyvotes"), html.select(".cwh2 h2")
    legends = html.select("#legend dl")
    if (
        len(tables) != len(chambers)
        or len(explanations) != len(chambers)
        or len(headings) != len(chambers)
        or len(legends) != 1
    ):
        raise ScorecardSourceError("DAV complete chamber/item/legend inventory changed")
    legend_nodes = _children(legends[0], {"dt", "dd"})
    if [x.name for x in legend_nodes] != ["dt", "dd"] * len(LEGEND) or {
        _text(legend_nodes[j]): _text(legend_nodes[j + 1]) for j in range(0, len(legend_nodes), 2)
    } != LEGEND:
        raise ScorecardSourceError("DAV native action legend changed")
    filters = html.select("#choosestate select")
    expected_states = set(REVIEWED_ROWS[selected.edition_id][chambers[0]])
    if len(filters) != len(chambers) + 1:
        raise ScorecardSourceError("DAV complete client-side state filter inventory changed")
    for state_filter in filters:
        options = _children(state_filter, {"option"})
        if (
            state_filter.get("name") != "state"
            or state_filter.get("onchange") != "showOnlyRowsMatching('STATE_', this.value, true);"
            or len(options) != len(expected_states) + 1
            or options[0].get("value") != ""
            or _text(options[0]) != "All States"
            or {o.get("value") for o in options[1:]} != expected_states
        ):
            raise ScorecardSourceError("DAV native filter no longer establishes the complete all-state rendition")
    result = {}
    for n, (chamber, table, dl, heading, count) in enumerate(
        zip(chambers, tables, explanations, headings, item_counts, strict=True), 1
    ):
        expected_heading = (
            "U.S. "
            + ("House of Representatives" if chamber == "house" else "Senate")
            + " "
            + congress
            + "th Congress, Second Session"
        )
        if _text(heading) != expected_heading:
            raise ScorecardSourceError("DAV native chamber period conflicts with the named rendition")
        items = _items(dl, chamber, congress, n, count)
        result[chamber] = {
            "items": items,
            **_grid(table, chamber, items, n, REVIEWED_ROWS[selected.edition_id][chamber], congress == "110"),
        }
    # Preserve the remaining authored context, including replacement notes, blank
    # notes, state filters and legend. Do not repeat private member grids as method.
    context = deepcopy(html.body)
    for node in context.select("table#votes, dl#keyvotes, script, style"):
        node.decompose()
    for node in context.find_all(string=lambda value: isinstance(value, Comment)):
        node.extract()
    return {
        "chambers": result,
        "context": {
            "text": _text(context),
            "html": str(context),
            "source_path": "//body",
            "source_custody": {
                "original_publisher_url": ORIGINAL,
                "archive_url": selected.source_url,
                "archive_timestamp": RENDITIONS[selected.edition_id][0],
            },
        },
    }


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition(selected.edition_id):
        raise ScorecardSourceError("DAV selected edition metadata conflicts with its named original")
    document = context.read(selected.source_url, stage="dav:national-original", hosts=HOSTS)
    facts = _facts(document, selected)
    repeat = context.read(selected.source_url, stage="dav:national-original-reread", hosts=HOSTS)
    if _facts(repeat, selected) != facts:
        raise ScorecardSourceError("DAV complete source facts changed on reread")
    bundle = Bundle(
        selected,
        context,
        document,
        publisher_name="Disabled American Veterans",
        parser_version=parser_version,
        rendition_rule="named-original-archive-all-native-members-and-items",
        homepage="https://www.dav.org",
    )
    bundle.use(document, "members", "ratings", "items", "actions", "methodology")
    bundle.use(repeat, "members", "ratings", "items", "actions", "methodology", role="corroboration")
    period = RENDITIONS[selected.edition_id][1] + "th Congress, Second Session"
    bundle.tables["scorecards"][0].update(
        edition_label_text=selected.title,
        source_path="//*[@id='grid']/div/h1",
        timespan_text=period,
        session_text="2",
        periods_json=json_column(
            [
                {
                    "occurrence_id": "native-heading-period",
                    "kind": "explicit",
                    "period_text": period,
                    "congress_text": selected.congress,
                    "session_text": "2",
                    "source_path": "//*[@id='grid']/div/h1",
                }
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        "//body",
        methodology_id="native-rendition-context",
        methodology_text=json_column(facts["context"]),
        disclosure_status="partial",
    )
    for chamber, grid in facts["chambers"].items():
        metric = key(chamber, "score")
        bundle.add(
            "scorecard_methodologies",
            document,
            grid["path"],
            methodology_id=key(chamber, "native-grid-context"),
            chamber_text=chamber,
            methodology_text=json_column(
                {"table_attributes": grid["attributes"], "headers_and_spacers": grid["headers"]}
            ),
            disclosure_status="partial",
        )
        bundle.add(
            "scorecard_metrics",
            document,
            grid["path"],
            metric_id=metric,
            name="Score",
            chamber_text=chamber,
            value_unit_text="%",
            period_text=period,
        )
        for number, item in enumerate(grid["items"], 1):
            item_id = key(chamber, item["publisher_id"])
            position = grid["positions"][number - 1] if grid["positions"] is not None else None
            bundle.add(
                "scorecard_items",
                document,
                item["path"],
                item_id=item_id,
                publisher_item_id=item["publisher_id"],
                item_kind_text="roll_call",
                title=item["title"],
                item_date_text=item["date"],
                congress_text=selected.congress,
                chamber_text=chamber,
                session_text="2",
                roll_number_text=item["roll"],
                references_json=json_column(item["references"]),
                publisher_position_text=position,
                position_basis="explicit" if position is not None else None,
                position_source_path=grid["path"] + "/tr[2]/td[" + str(number) + "]" if position is not None else None,
            )
            bundle.add(
                "scorecard_methodologies",
                document,
                item["description_path"],
                methodology_id=key(chamber, "item", item["publisher_id"]),
                chamber_text=chamber,
                methodology_text=json_column(
                    {
                        field: item[field]
                        for field in (
                            "title_text",
                            "title_html",
                            "description",
                            "description_html",
                            "href",
                            "path",
                            "description_path",
                        )
                    }
                ),
                disclosure_status="explicit",
            )
            bundle.add(
                "scorecard_metric_items",
                document,
                grid["path"],
                metric_id=metric,
                item_id=item_id,
                participation_id="grid-column",
                publisher_position_text=position,
                position_basis="explicit" if position is not None else None,
            )
        for member in grid["members"]:
            member_key = key(chamber, member["publisher_id"])
            bundle.add(
                "scorecard_members",
                document,
                member["path"],
                publisher_member_key=member_key,
                publisher_member_id=member["publisher_id"],
                identifiers_json="[]",
                member_name=member["name"],
                chamber_text=chamber,
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text=period,
                notes_text=json_column(
                    {
                        field: member[field]
                        for field in (
                            "identity",
                            "row_id",
                            "row_attributes",
                            "district_prefix",
                            "district_suffix",
                            "cells",
                        )
                    }
                ),
            )
            bundle.add(
                "scorecard_member_ratings",
                document,
                member["cells"][-1]["source_path"],
                metric_id=metric,
                publisher_member_key=member_key,
                value_text=member["score"],
                value_number=decimal_text(member["score"]),
            )
            for item, cell, action in zip(grid["items"], member["cells"][1:-1], member["actions"], strict=True):
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    cell["source_path"],
                    metric_id=metric,
                    participation_id="grid-column",
                    item_id=key(chamber, item["publisher_id"]),
                    publisher_member_key=member_key,
                    result_id="native-cell",
                    result_text=action,
                    reason_text=LEGEND.get(action),
                )
    return bundle.finish(
        "Complete named original HTML reached closing HTML; every native chamber, all-state filter, measured state subtotal, replacement member occurrence, score and action cell, key-vote explanation, repeated header and legend reconciled; all retained authored facts reread unchanged."
    )
