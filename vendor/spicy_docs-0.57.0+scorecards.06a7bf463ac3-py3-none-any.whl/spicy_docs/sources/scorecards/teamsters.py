"""The named complete Teamsters House Capwiz rendition, with archive custody."""

import re
from collections import Counter
from copy import deepcopy

from bs4 import Comment, NavigableString

from spicy_docs.schemas.tables import json_column

from . import capwiz_html
from .common import Bundle, ScorecardContext, ScorecardEdition, ScorecardSourceError, decimal_text, key, soup

parser_version = "teamsters-named-capwiz-html/1"
ORIGINAL = "https://ibt.capwiz.com/ibt/scorecard.xc"
TIMESTAMP = "20210416160812"
EDITION = "115-2-house-archived-native"
TITLE = "Federal Teamster Priority Vote Scorecard - 115th Congress, Second Session"
PERIOD = "115th Congress, Second Session"
LEGEND = {
    "Y": "Voted Yes (No position by organization)",
    "N": "Voted No (No position by organization)",
    "✔": "Voted With Us",
    "❌": "Voted Against Us",
    "P": "Voted Present",
    "NV": "Did Not Vote",
    "0": "Not in Office",
    "S": "Speaker (Typically the speaker does not participate in roll call votes.)",
}
# Measured from this named original's complete native grid, including replacement
# occurrences and the MP delegate. This is not an official roster denominator.
POPULATIONS = dict(
    zip(
        [
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY",
        ],
        (
            7,
            1,
            10,
            4,
            53,
            7,
            5,
            1,
            27,
            14,
            2,
            2,
            18,
            9,
            4,
            4,
            6,
            6,
            2,
            8,
            9,
            15,
            8,
            4,
            8,
            1,
            3,
            4,
            2,
            12,
            3,
            28,
            13,
            1,
            1,
            17,
            6,
            5,
            21,
            2,
            7,
            1,
            9,
            37,
            4,
            1,
            11,
            10,
            3,
            8,
            1,
        ),
        strict=True,
    )
)
MEMBER = re.compile(r"(.+) \(([A-Z])-([A-Z]{2})-(AL|\d+)\)")


def edition(edition_id):
    if edition_id != EDITION:
        raise ScorecardSourceError("Teamsters edition is outside the named recovered House original")
    return ScorecardEdition(
        "teamsters",
        EDITION,
        "https://web.archive.org/web/" + TIMESTAMP + "id_/" + ORIGINAL,
        TITLE,
        congress="115",
        chamber="house",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return (edition(EDITION),)


def _children(node, allowed):
    return capwiz_html.authored_children(node, allowed, publisher="Teamsters")


def _grid(table, items):
    path = "(//table[@id='votes'])[1]"
    if table.get("summary") != "This table contains U.S. House of Representatives Key Votes by state.":
        raise ScorecardSourceError("Teamsters native table chamber statement changed")
    members, headers, states, spacers, counts = [], [], [], [], Counter()
    for ordinal, row in enumerate(_children(table, {"tr"}), 1):
        row_path = path + "/tr[" + str(ordinal) + "]"
        cells = _children(row, {"th", "td"})
        rid = row.get("id", "")
        if re.fullmatch(r"STATE_[A-Z]{2}_spacer_2", rid):
            state = rid.split("_")[1]
            if (
                len(cells) != 1
                or cells[0].name != "td"
                or cells[0].find()
                or capwiz_html.text(row)
                or not states
                or state != states[-1]
                or state in spacers
            ):
                raise ScorecardSourceError("Teamsters native spacer/state boundary changed")
            spacers.append(state)
        elif re.fullmatch(r"STATE_[A-Z]{2}_0", rid):
            state = rid.split("_")[1]
            if (
                len(cells) != len(items) + 2
                or state not in POPULATIONS
                or state in states
                or cells[0].name != "th"
                or capwiz_html.text(cells[-1]) != "Score"
            ):
                raise ScorecardSourceError("Teamsters state/header inventory is incomplete or repeated")
            states.append(state)
            for number, (cell, item) in enumerate(zip(cells[1:-1], items, strict=True), 1):
                anchors = _children(cell, {"a"})
                if (
                    len(anchors) != 1
                    or capwiz_html.text(cell) != str(number)
                    or anchors[0].get("href") != item["href"]
                    or anchors[0].get("title") != item["title_text"].removeprefix(str(number) + ". ")
                ):
                    raise ScorecardSourceError("Teamsters state item labels conflict with complete explanations")
        elif re.fullmatch(r"STATE_[A-Z]{2}_[1-9]\d*", rid):
            state, publisher_id = rid.split("_")[1:]
            if (
                len(cells) != len(items) + 2
                or any(c.name != "td" for c in cells)
                or not states
                or state != states[-1]
                or state in spacers
                or any(c.find() for c in cells[1:])
            ):
                raise ScorecardSourceError("Teamsters member cells have unreviewed content or state placement")
            anchors = cells[0].find_all(recursive=False)
            if (
                len(anchors) != 1
                or anchors[0].name != "a"
                or anchors[0].find()
                or anchors[0].get("href") != "bio/?id=" + publisher_id
            ):
                raise ScorecardSourceError("Teamsters native member link conflicts with its unlabeled publisher ID")
            prefix_parts = []
            for child in cells[0].children:
                if isinstance(child, Comment):
                    continue
                if isinstance(child, NavigableString):
                    prefix_parts.append(str(child))
                elif child is not anchors[0]:
                    raise ScorecardSourceError("Teamsters native identity contains unreviewed child content")
            prefix = " ".join(" ".join(prefix_parts).split())
            match = MEMBER.fullmatch(capwiz_html.text(anchors[0]))
            if not match or match[3] != state or (prefix and prefix != match[4] + "."):
                raise ScorecardSourceError("Teamsters literal name/state/district fields disagree")
            name, party, _, district = match.groups()
            actions = [capwiz_html.text(c) or None for c in cells[1:-1]]
            score = capwiz_html.text(cells[-1]) or None
            if any(a is not None and a not in LEGEND for a in actions) or (
                score is not None and not re.fullmatch(r"\d+(?:\.\d+)?%", score)
            ):
                raise ScorecardSourceError("Teamsters literal action or score vocabulary changed")
            if any(m["publisher_id"] == publisher_id for m in members):
                raise ScorecardSourceError("Teamsters native member identity is repeated")
            members.append(
                {
                    "publisher_id": publisher_id,
                    "row_id": rid,
                    "path": row_path,
                    "name": name,
                    "party": party,
                    "state": state,
                    "district": district,
                    "identity": capwiz_html.text(cells[0]),
                    "district_prefix": prefix,
                    "member_href": anchors[0]["href"],
                    "actions": actions,
                    "score": score,
                    "row_attributes": dict(row.attrs),
                    "cells": [capwiz_html.native(c, row_path + "/td[" + str(n) + "]") for n, c in enumerate(cells, 1)],
                }
            )
            counts[state] += 1
            continue
        else:
            raise ScorecardSourceError("Teamsters row is outside the complete native state/member structure")
        headers.append(capwiz_html.header(row, row_path, cells))
    if dict(counts) != POPULATIONS or set(states) != set(POPULATIONS) or spacers != states:
        raise ScorecardSourceError("Teamsters complete named native population/state boundaries are missing")
    return {"path": path, "attributes": dict(table.attrs), "headers": headers, "members": members}


def _facts(document, selected):
    if document.url != selected.source_url or document.response.requested_url != selected.source_url:
        raise ScorecardSourceError("Teamsters archive custody escaped the selected original route")
    if (
        not document.body.rstrip().lower().endswith(b"</html>")
        or "html" not in (document.response.content_type or "").lower()
    ):
        raise ScorecardSourceError("Teamsters original HTML is incomplete or the format changed")
    html = soup(document)
    if (
        len(html.select("html")) != 1
        or len(html.select("body")) != 1
        or len(html.select("title")) != 1
        or capwiz_html.text(html.title) != "Legislative Action Center -- Teamster Priority Vote Scorecard"
        or len(html.select("#grid h1")) != 1
        or capwiz_html.text(html.select_one("#grid h1")) != TITLE
        or len(html.select(".cwh2 h2")) != 1
        or capwiz_html.text(html.select_one(".cwh2 h2")) != "U.S. House of Representatives " + PERIOD
    ):
        raise ScorecardSourceError("Teamsters original document/chamber/period boundary changed")
    tables, explanations, legends = html.select("table#votes"), html.select("dl#keyvotes"), html.select("#legend dl")
    if len(tables) != 1 or len(explanations) != 1 or len(legends) != 1:
        raise ScorecardSourceError("Teamsters complete chamber/item/legend inventory changed")
    legend_nodes = _children(legends[0], {"dt", "dd"})
    if [n.name for n in legend_nodes] != ["dt", "dd"] * len(LEGEND) or {
        capwiz_html.text(legend_nodes[n]): capwiz_html.text(legend_nodes[n + 1]) for n in range(0, len(legend_nodes), 2)
    } != LEGEND:
        raise ScorecardSourceError("Teamsters native action legend changed")
    filters = html.select("#choosestate select")
    if len(filters) != 2:
        raise ScorecardSourceError("Teamsters complete client-side state filter inventory changed")
    for state_filter in filters:
        options = _children(state_filter, {"option"})
        if (
            state_filter.get("name") != "state"
            or state_filter.get("onchange") != "showOnlyRowsMatching('STATE_', this.value, true);"
            or len(options) != len(POPULATIONS) + 1
            or options[0].get("value") != ""
            or capwiz_html.text(options[0]) != "All States"
            or {o.get("value") for o in options[1:]} != set(POPULATIONS)
        ):
            raise ScorecardSourceError("Teamsters filter no longer establishes the complete all-state rendition")
    items = capwiz_html.items(explanations[0], "house", "115", 1, 2, publisher="Teamsters", detail_in_span=True)
    for item in items:
        # Retain the publisher's exact No/no spelling and its complete explanation.
        positions = re.findall(r"urged a (No|no) vote\.", item["description"])
        if len(positions) != 1:
            raise ScorecardSourceError("Teamsters explicit preferred position is missing or ambiguous")
        item["position"] = positions[0]
    context = deepcopy(html.body)
    for node in context.select("table#votes, dl#keyvotes, script, style"):
        node.decompose()
    for node in context.find_all(string=lambda value: isinstance(value, Comment)):
        node.extract()
    return {
        "items": items,
        "grid": _grid(tables[0], items),
        "context": {
            "document_title": capwiz_html.text(html.title),
            "text": capwiz_html.text(context),
            "html": str(context),
            "source_path": "//body",
            "source_custody": {
                "original_publisher_url": ORIGINAL,
                "archive_url": selected.source_url,
                "archive_timestamp": TIMESTAMP,
            },
        },
    }


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition(selected.edition_id):
        raise ScorecardSourceError("Teamsters selected edition metadata conflicts with its named original")
    document = context.read(selected.source_url, stage="teamsters:national-original", hosts=("web.archive.org",))
    facts = _facts(document, selected)
    repeat = context.read(selected.source_url, stage="teamsters:national-original-reread", hosts=("web.archive.org",))
    if _facts(repeat, selected) != facts:
        raise ScorecardSourceError("Teamsters complete source facts changed on reread")
    bundle = Bundle(
        selected,
        context,
        document,
        publisher_name="International Brotherhood of Teamsters",
        parser_version=parser_version,
        rendition_rule="named-original-archive-all-native-house-members-and-items",
        homepage="https://teamster.org",
    )
    bundle.use(document, "members", "ratings", "items", "actions", "methodology")
    bundle.use(repeat, "members", "ratings", "items", "actions", "methodology", role="corroboration")
    bundle.tables["scorecards"][0].update(
        edition_label_text=TITLE,
        source_path="//*[@id='grid']/div/h1",
        timespan_text=PERIOD,
        session_text="2",
        periods_json=json_column(
            [
                {
                    "occurrence_id": "native-heading-period",
                    "kind": "explicit",
                    "period_text": PERIOD,
                    "congress_text": "115",
                    "session_text": "2",
                    "source_path": "//*[@id='grid']/div/h1",
                }
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        "//body",
        methodology_id="native-rendition-context",
        methodology_text=json_column(facts["context"]),
        disclosure_status="partial",
    )
    grid, metric = facts["grid"], "house:score"
    bundle.add(
        "scorecard_methodologies",
        document,
        grid["path"],
        methodology_id="house:native-grid-context",
        chamber_text="house",
        methodology_text=json_column({"table_attributes": grid["attributes"], "headers_and_spacers": grid["headers"]}),
        disclosure_status="partial",
    )
    bundle.add(
        "scorecard_metrics",
        document,
        grid["path"],
        metric_id=metric,
        name="Score",
        chamber_text="house",
        value_unit_text="%",
        period_text=PERIOD,
        is_primary=None,
    )
    for item in facts["items"]:
        item_id = key("house", item["publisher_id"])
        bundle.add(
            "scorecard_items",
            document,
            item["path"],
            item_id=item_id,
            publisher_item_id=item["publisher_id"],
            item_kind_text="roll_call",
            title=item["title"],
            item_date_text=item["date"],
            congress_text="115",
            chamber_text="house",
            session_text="2",
            roll_number_text=item["roll"],
            references_json=json_column(item["references"]),
            publisher_position_text=item["position"],
            position_basis="explicit",
            position_source_path=item["description_path"],
        )
        bundle.add(
            "scorecard_methodologies",
            document,
            item["description_path"],
            methodology_id=key("house", "item", item["publisher_id"]),
            chamber_text="house",
            methodology_text=json_column(
                {
                    field: item[field]
                    for field in (
                        "title_text",
                        "title_html",
                        "description",
                        "description_html",
                        "href",
                        "path",
                        "description_path",
                    )
                }
            ),
            disclosure_status="explicit",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            grid["path"],
            metric_id=metric,
            item_id=item_id,
            participation_id="grid-column",
            publisher_position_text=item["position"],
            position_basis="explicit",
        )
    for member in grid["members"]:
        member_key = key("house", member["publisher_id"])
        bundle.add(
            "scorecard_members",
            document,
            member["path"],
            publisher_member_key=member_key,
            publisher_member_id=member["publisher_id"],
            identifiers_json="[]",
            member_name=member["name"],
            chamber_text="house",
            state=member["state"],
            district=member["district"],
            party=member["party"],
            period_text=PERIOD,
            notes_text=json_column(
                {
                    field: member[field]
                    for field in ("identity", "row_id", "row_attributes", "district_prefix", "member_href", "cells")
                }
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            member["cells"][-1]["source_path"],
            metric_id=metric,
            publisher_member_key=member_key,
            value_text=member["score"],
            value_number=decimal_text(member["score"]),
            notes_text=json_column(member["cells"][-1]),
        )
        for item, cell, action in zip(facts["items"], member["cells"][1:-1], member["actions"], strict=True):
            bundle.add(
                "scorecard_member_item_results",
                document,
                cell["source_path"],
                metric_id=metric,
                participation_id="grid-column",
                item_id=key("house", item["publisher_id"]),
                publisher_member_key=member_key,
                result_id="native-cell",
                result_text=action,
                reason_text=LEGEND.get(action),
            )
    return bundle.finish(
        "Complete named original HTML reached closing HTML; all native state filters, measured state subtotals, replacement member occurrences, scores and action cells, key-vote descriptions, repeated headers, spacers, context and legend reconciled and reread unchanged."
    )
