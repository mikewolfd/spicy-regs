"""Observed Capwiz DOM and item syntax, with explicit publisher-owned scopes.

Publisher readers supply the selected original, period, population, action legend
and grid rules. These helpers neither discover publishers nor choose editions.
"""

import re
from collections import Counter
from copy import deepcopy
from urllib.parse import parse_qs, urlsplit

from bs4 import Comment, NavigableString

from .common import ScorecardSourceError

ITEM = re.compile(r"(.+) \((\d{2}/\d{2}/\d{4}), Roll Call No\. (\d+)\)")


CITATIONS = {
    "bill": re.compile(r"H\.R\. \d+|S\. \d+"),
    "amendment": re.compile(r"(?:Amdt\.?|Amendment) (?:No\. )?\d+"),
}


def text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def authored_children(node, allowed, *, publisher):
    for child in node.children:
        if isinstance(child, Comment):
            continue
        if isinstance(child, NavigableString):
            if str(child).strip():
                raise ScorecardSourceError(publisher + " structural container has unreviewed authored text")
        elif child.name not in allowed:
            raise ScorecardSourceError(publisher + " structural container has unreviewed child content")
    return node.find_all(recursive=False)


def native(node, path):
    retained = deepcopy(node)
    for comment in retained.find_all(string=lambda value: isinstance(value, Comment)):
        comment.extract()
    return {"source_path": path, "text": text(node), "attributes": dict(node.attrs), "html": str(retained)}


def header(row, path, cells):
    ordinals = Counter()
    retained = []
    for cell in cells:
        ordinals[cell.name] += 1
        retained.append(native(cell, path + "/" + cell.name + "[" + str(ordinals[cell.name]) + "]"))
    return {**native(row, path), "cells": retained}


def items(dl, chamber, congress, ordinal, expected, *, publisher, detail_in_span=False):
    children = authored_children(dl, {"dt", "dd"}, publisher=publisher)
    if [c.name for c in children] != ["dt", "dd"] * expected:
        raise ScorecardSourceError(publisher + " complete key-vote explanation inventory changed")
    items = []
    for n in range(expected):
        dt, dd = children[n * 2 : n * 2 + 2]
        path = "(//dl[@id='keyvotes'])[" + str(ordinal) + "]"
        title_text = text(dt)
        number = str(n + 1)
        match = ITEM.fullmatch(title_text.removeprefix(number + ". "))
        links = dd.select("a[href]")
        if not title_text.startswith(number + ". ") or not match or len(links) != 1 or text(links[0]) != "More":
            raise ScorecardSourceError(publisher + " item title, literal date, roll or detail link changed")
        title, date, roll = match.groups()
        link = links[0]
        if detail_in_span:
            parent = link.parent
            if (
                parent.name != "span"
                or parent.parent is not dd
                or authored_children(parent, {"a"}, publisher=publisher) != [link]
            ):
                raise ScorecardSourceError(publisher + " detail link left the observed direct span")
            span_ordinal = dd.find_all("span", recursive=False).index(parent) + 1
            link_path = "/span[" + str(span_ordinal) + "]/a/@href"
        else:
            if link.parent is not dd:
                raise ScorecardSourceError(publisher + " detail link left the observed direct description")
            link_path = "/a/@href"
        href = links[0]["href"]
        route = urlsplit(href)
        query = parse_qs(route.query, keep_blank_values=True)
        if (
            route.scheme
            or route.netloc
            or route.path != "vote.xc"
            or set(query) != {"votenum", "chamber", "congress", "voteid", "state"}
            or any(len(v) != 1 for v in query.values())
            or query["votenum"] != [roll]
            or query["congress"] != [congress + "2"]
            or query["chamber"] != ["H" if chamber == "house" else "S"]
            or query["state"] != ["US"]
            or not re.fullmatch(r"\d+", query["voteid"][0])
        ):
            raise ScorecardSourceError(publisher + " native item route conflicts with the named period or title")
        refs = [
            {
                "occurrence_id": "native-detail-link",
                "kind": "publisher_item",
                "citation_text": href,
                "source_path": path + "/dd[" + number + "]" + link_path,
            },
            {
                "occurrence_id": "title-roll",
                "kind": "roll_call",
                "citation_text": "Roll Call No. " + roll,
                "roll_number_text": roll,
                "congress_text": congress,
                "session_text": "2",
                "chamber_text": chamber,
                "source_path": path + "/dt[" + number + "]",
            },
        ]
        for field, node in (("title", dt), ("description", dd)):
            for kind, pattern in CITATIONS.items():
                for occurrence, citation in enumerate(pattern.finditer(text(node)), 1):
                    refs.append(
                        {
                            "occurrence_id": field + "-" + kind + "-" + str(occurrence),
                            "kind": kind,
                            "citation_text": citation.group(),
                            "source_path": path + ("/dt[" if field == "title" else "/dd[") + number + "]",
                        }
                    )
        items.append(
            {
                "title": title,
                "title_text": title_text,
                "date": date,
                "roll": roll,
                "publisher_id": query["voteid"][0],
                "href": href,
                "references": refs,
                "path": path + "/dt[" + number + "]",
                "description_path": path + "/dd[" + number + "]",
                "description": text(dd),
                "title_html": str(dt),
                "description_html": str(dd),
            }
        )
    return items
