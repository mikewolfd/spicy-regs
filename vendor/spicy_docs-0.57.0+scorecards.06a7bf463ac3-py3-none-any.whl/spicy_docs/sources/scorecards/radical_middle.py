"""Radical Middle's complete online leader reports, separate from unavailable printed grids."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from string import ascii_lowercase
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Comment

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key

parser_version = "radical-middle-native-online/1"
HOME = "https://radicalmiddle.com/"
HOSTS = ("radicalmiddle.com", "www.radicalmiddle.com")


@dataclass(frozen=True, slots=True)
class Report:
    filename: str
    period: str
    edition_id: str
    title: str
    rating_start: str
    rating_end: str
    count: int
    issue: str
    congress: str | None
    items: int

    @property
    def edition(self):
        return ScorecardEdition(
            "radical_middle",
            self.edition_id,
            HOME + self.filename,
            self.title,
            congress=self.congress,
            chamber="both",
            is_current=False,
        )


REPORTS = (
    Report(
        "x_scorecard02.htm",
        "107th Congress (covering 2001 and 2002)",
        "107-online-leaders",
        "Congress' top visionaries: Reps. Filner and Frank and Sen. Tim Johnson",
        'The "Visionary 20"',
        "Congress' rainbow",
        23,
        "Issue No. 41 (January / February 2003) -- Mark Satin, editor",
        "107",
        20,
    ),
    Report(
        "x_scorecard04.htm",
        "108th Congress (covering all of 2003 and 2004)",
        "108-online-leaders",
        'An identifiable "radical middle" is quietly at work – in Congress!',
        'The "Radical Middle 18"',
        "On first glance",
        18,
        "Issue No. 60 (December 2004) -- Mark Satin, Editor",
        "108",
        20,
    ),
    Report(
        "x_scorecard07.htm",
        "109th and 110th sessions of Congress (2005-present)",
        "109-110-online-poll-winners",
        "There is a radical middle in Congress",
        "The winners",
        "Collective portrait of the winners",
        21,
        "Issue No. 113 (December 2007) -- Mark Satin, Editor",
        None,
        0,
    ),
)


def _text(tag):
    if tag.name == "p":
        # FrontPage omitted closing p tags near the poll certification. Only
        # strings belonging to this paragraph survive, rather than duplicating
        # the subsequent nested paragraph contents into every earlier record.
        return " ".join(
            " ".join(
                str(n) for n in tag.find_all(string=True) if not isinstance(n, Comment) and n.find_parent("p") is tag
            ).split()
        )
    return " ".join(tag.get_text(" ", strip=True).split())


def _navigation(soup, base):
    wanted = {r.filename for r in REPORTS}
    found = {a.get("href") for a in soup.select("a[href]") if a.get("href") in wanted}
    if found != wanted:
        raise ScorecardSourceError("Radical Middle original navigation no longer lists every reviewed report")
    return tuple(urljoin(base, r.filename) for r in REPORTS)


def _facts(source, report):
    try:
        # These original FrontPage reports explicitly declare windows-1252.
        # Treating them as UTF-8 corrupts the publisher's curly quotes and names.
        soup = BeautifulSoup(source.body.decode("windows-1252"), "html.parser")
        charset = soup.find("meta", attrs={"http-equiv": "Content-Type"})
        content_type = charset.get("content") if charset else None
        if not isinstance(content_type, str) or "charset=windows-1252" not in content_type.lower():
            raise ValueError
        if soup.title is None or not (
            "Radical Middle" in _text(soup.title)
            or (not report.items and _text(soup.title) == "Congressional Scorecard 109th & 110th Congresses 2005-2008")
        ):
            raise ValueError
        _navigation(soup, source.url)
        native_paragraphs = soup.select("p")
        paragraphs = [(i, _text(p)) for i, p in enumerate(native_paragraphs)]
        starts = [j for j, (_, text) in enumerate(paragraphs) if text == report.issue]
        ends = [j for j, (_, text) in enumerate(paragraphs) if text == "ABOUT THE RADICAL MIDDLE CONCEPT"]
        if len(starts) != 1 or len(ends) != 1 or starts[0] >= ends[0]:
            raise ValueError
        article = paragraphs[starts[0] : ends[0]]
        complete = " ".join(t for _, t in article)
        if report.period not in complete or report.title not in complete:
            raise ValueError
        # A br element can put several explicitly scored members in one paragraph.
        # These complete boundaries exclude article biographies and other scorecards.
        first = next(j for j, (_, t) in enumerate(article) if t == report.rating_start)
        last = next(j for j, (_, t) in enumerate(article) if t == report.rating_end)
        ratings = []
        chamber = None
        cohort = None
        pattern = re.compile(
            r"(?:(Sen\.|Rep\.)\s+)?([^()]+?)\s*\(([^()]*)\),\s*(\d+(?:%|\s+points|\s+votes)?)\s*(?=(?:Sen\.|Rep\.)|$)"
        )
        for index, text in article[first + 1 : last]:
            if text.startswith("In addition, three Republicans"):
                cohort = text
            if text.startswith("In the Senate"):
                chamber = "Senate"
            elif text.startswith("And in the House"):
                chamber = "House"
            matches = list(pattern.finditer(text))
            if not matches:
                continue
            if (
                any(text[(matches[j - 1].end() if j else 0) : m.start()].strip() for j, m in enumerate(matches))
                or text[matches[-1].end() :].strip()
            ):
                raise ValueError
            for ordinal, match in enumerate(matches):
                prefix, name, context, value = match.groups()
                row_chamber = "Senate" if prefix == "Sen." else "House" if prefix == "Rep." else chamber
                if row_chamber is None:
                    raise ValueError
                party = re.match(r"^([DRI])-", context)
                state = re.search(r"\b([A-Z]{2})$", context)
                ratings.append(
                    {
                        "paragraph": index,
                        "occurrence": ordinal,
                        "name": name.strip(),
                        "context": context,
                        "prefix": prefix,
                        "chamber": row_chamber,
                        "party": party[1] if party else "Republicans" if cohort else None,
                        "state": state[1] if state else None,
                        "value": value,
                        "literal": match[0].strip(),
                        "cohort": cohort,
                    }
                )
        if (
            len(ratings) != report.count
            or len({(r["chamber"], r["name"], r["context"]) for r in ratings}) != report.count
        ):
            raise ValueError
        items = []
        if report.items:
            if not any(t == "Keeping score" for _, t in article) or "ACCESS TO THE SCORECARD" not in complete:
                raise ValueError
            if (
                "535 Senators and Representatives" not in complete
                or "cannot" not in complete
                or "reproduced on this web page" not in complete
            ):
                raise ValueError
            anchors = [(j, re.match(r"^([a-t])\.\s+", t)) for j, (_, t) in enumerate(article)]
            anchors = [(j, m[1]) for j, m in anchors if m]
            if [letter for _, letter in anchors] != list(ascii_lowercase[:20]):
                raise ValueError
            for j, (start, letter) in enumerate(anchors):
                stop = (
                    anchors[j + 1][0]
                    if j + 1 < len(anchors)
                    else next(
                        k
                        for k in range(start + 1, len(article))
                        if article[k][1] in {"_______________", "ACCESS TO THE SCORECARD"}
                    )
                )
                records = article[start:stop]
                heading = native_paragraphs[records[0][0]].find("b")
                if heading is None or not _text(heading).startswith(letter + ". "):
                    raise ValueError
                items.append(
                    {
                        "id": letter,
                        "paragraph": records[0][0],
                        "paragraphs": records,
                        "title": _text(heading),
                        "description": " ".join(t for _, t in records),
                    }
                )
        elif (
            "21 judges cast 105 votes" not in complete
            or "71 members of Congress received one or more votes" not in complete
        ):
            raise ValueError
        return {"ratings": ratings, "items": items, "article": article, "document_title": _text(soup.title)}
    except (UnicodeError, ValueError, StopIteration, TypeError, IndexError):
        raise ScorecardSourceError(
            "Radical Middle report cannot establish the complete reviewed online rendition"
        ) from None


def list_scorecards(context):
    source = context.read(HOME, stage="scorecards:radical_middle:listing", hosts=HOSTS)
    _navigation(BeautifulSoup(source.body, "html.parser"), source.url)
    return tuple(r.edition for r in REPORTS)


def acquire_scorecard(edition, context):
    reports = [r for r in REPORTS if r.edition == edition]
    if len(reports) != 1:
        raise ScorecardSourceError("Radical Middle requested report is outside the reviewed original editions")
    report = reports[0]
    source = context.read(edition.source_url, stage="scorecards:radical_middle:report", hosts=HOSTS)
    facts = _facts(source, report)
    end = context.read(edition.source_url, stage="scorecards:radical_middle:report-end", hosts=HOSTS)
    if facts != _facts(end, report):
        raise ScorecardSourceError("Radical Middle online source facts changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Radical Middle Newsletter",
        parser_version=parser_version,
        rendition_rule="radical-middle-complete-online-reported-leaders-and-issue-narratives/1",
        homepage=HOME,
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    bundle.use(end, "members_and_scores", "scored_items", "methodology", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = HOME
    card = bundle.tables["scorecards"][0]
    card.update(
        timespan_text=report.period,
        published_at_text=report.issue,
        methodology_url=source.url,
        periods_json=json.dumps(
            [
                {
                    "occurrence_id": "report",
                    "kind": "relative" if "present" in report.period else "explicit",
                    "period_text": report.period,
                    "source_path": "html:article",
                }
            ]
        ),
    )
    metric = "nomination-votes" if not report.items else "score"
    bundle.metric(
        source,
        metric,
        "votes" if not report.items else "scores",
        path="html:article/ratings",
        unit="votes" if not report.items else "%" if report.congress == "107" else "points",
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "html:title",
        methodology_id="native-document-title",
        methodology_text=facts["document_title"],
        methodology_url=source.url,
        disclosure_status="Original document title",
    )
    for index, text in facts["article"]:
        if text:
            bundle.add(
                "scorecard_methodologies",
                source,
                f"html:p[{index}]",
                methodology_id=f"paragraph-{index}",
                methodology_text=text,
                methodology_url=source.url,
                disclosure_status="Original online report paragraph",
            )
    for rating in facts["ratings"]:
        member = key(rating["chamber"], rating["name"], rating["context"])
        path = f"html:p[{rating['paragraph']}]/rating[{rating['occurrence']}]"
        notes = {
            "native_label": rating["literal"],
            "native_context": rating["context"],
            "native_prefix": rating["prefix"],
            "native_cohort": rating["cohort"],
        }
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=member,
            member_name=rating["name"],
            state=rating["state"],
            party=rating["party"],
            chamber_text=rating["chamber"],
            identifiers_json="[]",
            notes_text=json.dumps(notes, ensure_ascii=False),
        )
        numeric = re.fullmatch(r"(\d+)(?:\s+(?:points|votes))?", rating["value"])
        bundle.add(
            "scorecard_member_ratings",
            source,
            path,
            metric_id=metric,
            publisher_member_key=member,
            value_text=rating["value"],
            value_number=numeric[1] if numeric else decimal_text(rating["value"]),
        )
    for item in facts["items"]:
        path = f"html:p[{item['paragraph']}]"
        references = []
        for index, text in item["paragraphs"]:
            for occurrence, citation in enumerate(
                re.finditer(r"\b(?:S\.Amdt\.|S\.Con\.Res\.|H\.Con\.Res\.|S\.Res\.|H\.Res\.|H\.R\.|S\.)\s*\d+", text)
            ):
                amendment = citation[0].startswith("S.Amdt.")
                references.append(
                    {
                        "occurrence_id": f"p{index}-{occurrence}",
                        "kind": "amendment" if amendment else "bill",
                        "citation_text": citation[0],
                        "amendment_citation_text" if amendment else "bill_citation_text": citation[0],
                        "congress_text": report.congress,
                        "source_path": f"html:p[{index}]/text[{citation.start()}:{citation.end()}]",
                    }
                )
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item["id"],
            publisher_item_id=item["id"],
            item_kind_text="issue areas",
            title=item["title"],
            congress_text=report.congress,
            references_json=json.dumps(references, ensure_ascii=False),
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=metric,
            item_id=item["id"],
            participation_id="issue-area",
            counts_toward_metric="true",
        )
    return bundle.finish(
        "Every explicitly listed online member rating and all source lettered issue-area narratives parsed; complete article boundaries, reviewed populations, native report identity and original archive links checked; all selected source facts stable on reread. The unavailable printed grid and unlisted poll nominees are outside this named online rendition.",
        declared={"online_leaders": report.count, "issue_areas": report.items},
    )
