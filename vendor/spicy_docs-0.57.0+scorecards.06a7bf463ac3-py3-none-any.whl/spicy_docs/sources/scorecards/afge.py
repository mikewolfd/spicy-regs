"""AFGE's original 2025 HTML explanations and complete reviewed PDF score grids."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.common import (
    soup as parse_html,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "afge-native-tracker-qualified-pdf/1"
HOSTS = ("www.afge.org",)
INDEX = "https://www.afge.org/take-action/afge-on-capitol-hill/issue-papers--voting-records/"
TRACKER = "https://www.afge.org/take-action/legislative-resources/legislative-bill-tracker/voting-record-tracker/"
PDFS: dict[str, dict[str, Any]] = {
    "House": {
        "url": "https://www.afge.org/globalassets/documents/events/legcon/2026/house-score-card-votes-jan-14-2026-v2.pdf",
        "sha256": "b9c0812036cd10be3740573c1e0279c39996f88415cc566c47b7a68505e3326b",
        "pages": 27,
        "members": 432,
        "columns": [1, 3, 2, 4, 5, 6],
        "titles": [
            "Reconciliation (50)",
            "March 2025 Government Funding (70)",
            "Cuts to Federal Benefits (145)",
            "Norcross Collective Bargaining (319)",
            "H.R. 2550 Discharge Petition (331)",
            "H.R. 2550 Final Passage (332)",
        ],
    },
    "Senate": {
        "url": "https://www.afge.org/globalassets/documents/events/legcon/2026/senate-voting-record-spreadsheet-jan-14-2026.pdf",
        "sha256": "e90bd87bf46f637bac7eef85fb8d4812b8436db6cffcd75735634fd5dcc9c4bc",
        "pages": 5,
        "members": 100,
        "columns": [7, 3, 8, 3, 9],
        "titles": [
            "Vought OMB Confirmation (37)",
            "March 2025 Cloture on Funding (128)",
            "Alsobrooks Collective Bargaining (175)",
            "Full Year Appropriations March 2025",
            "Shutdown Fairness Act (609)",
        ],
    },
}
QUALIFIED_SHA256 = "05561959f4ab58aa905de204ebf077e7367a248db4f6ff155ab4bb2e62a6d999"
TRACKER_FACTS_SHA256 = "249d4272b3bcef0d5a6e0b3edd51cb02a56e93f270b38b3a2434e4799d2ce3cb"
EDITION = ScorecardEdition("afge", "2025", TRACKER, "Voting Record Tracker", year="2025", chamber="both")
GLYPHS = {"R", "W", "?", "I", "*", ""}
CITATION = re.compile(r"(?:H\.\s*Con\.\s*Res\.|H\.\s*Res\.|H\.R\.|S\.\s*Amdt\.|S\.)\s*\d+")


def _tracker(document):
    soup = parse_html(document)
    headings = soup.select("h1.content-detail-title")
    tables = soup.select("table#example")
    if len(headings) != 1 or headings[0].get_text(" ", strip=True) != EDITION.title or len(tables) != 1:
        raise ScorecardSourceError("AFGE tracker identity or complete native vote table changed")
    intro = [
        p.get_text(" ", strip=True)
        for p in soup.find_all("p")
        if p.get_text(" ", strip=True).startswith("AFGE scored several Congressional votes")
    ]
    if intro != [
        "AFGE scored several Congressional votes in 2025. Click here to see how your member of Congress and Senators voted and their score with AFGE."
    ]:
        raise ScorecardSourceError("AFGE source-stated edition period changed")
    table = tables[0]
    headers = [c.get_text(" ", strip=True) for c in table.select("thead th")]
    if headers != ["Vote Name", "AFGE Position", "Chamber", "Date", "Vote Link"]:
        raise ScorecardSourceError("AFGE tracker vote columns changed")
    records = []
    for row in table.select("tbody > tr"):
        cells = row.find_all("td", recursive=False)
        if len(cells) != 5:
            raise ScorecardSourceError("AFGE tracker has an incomplete vote row")
        titles = cells[0].select("p > strong")
        if len(titles) != 1:
            raise ScorecardSourceError("AFGE tracker item title is ambiguous")
        records.append(
            {
                "title": titles[0].get_text(" ", strip=True),
                "source_text": cells[0].get_text(" ", strip=True),
                "position": cells[1].get_text(" ", strip=True),
                "chamber": cells[2].get_text(" ", strip=True),
                "date": cells[3].get_text(" ", strip=True),
                "links": [
                    {"title": a.get_text(" ", strip=True), "url": urljoin(document.url, a["href"])}
                    for a in cells[4].find_all("a", href=True)
                ],
            }
        )
    links = {urljoin(document.url, a["href"]) for a in soup.find_all("a", href=True)}
    facts = {"items": records, "pdf_urls": sorted(s["url"] for s in PDFS.values())}
    if (
        len(records) != 9
        or any(not r["title"] or not r["source_text"] or not r["date"] or not r["links"] for r in records)
        or any(r["position"] not in {"Support", "Oppose"} for r in records)
        or not set(facts["pdf_urls"]) <= links
        or sha256(json_column(facts).encode()).hexdigest() != TRACKER_FACTS_SHA256
    ):
        raise ScorecardSourceError("AFGE tracker differs from its reviewed item explanations or PDF selections")
    return facts


def _pdf(document, spec):
    if (
        document.url != spec["url"]
        or not document.body.startswith(b"%PDF-")
        or b"%%EOF" not in document.body[-4096:]
        or sha256(document.body).hexdigest() != spec["sha256"]
    ):
        raise ScorecardSourceError("AFGE PDF differs from its reviewed complete original")


def _qualified(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("AFGE semantic facts differ from the reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "afge-qualified-current-pdf/1"
            or data["edition_key"] != "2025"
            or data["source_sha256"] != {c.lower(): s["sha256"] for c, s in PDFS.items()}
            or data["physical_page_counts"] != {c: s["pages"] for c, s in PDFS.items()}
            or data["member_counts"] != {c: s["members"] for c, s in PDFS.items()}
            or data["item_column_counts"] != {c: len(s["columns"]) for c, s in PDFS.items()}
            or data["column_titles"] != {c: s["titles"] for c, s in PDFS.items()}
        ):
            raise ValueError
        identities, counts, pages = set(), Counter(), {c: Counter() for c in PDFS}
        for entry in data["members"]:
            r, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            spec = PDFS[chamber]
            physical = evidence["physical_pages"]
            identity = (chamber, tuple(physical), evidence["json_pointer"])
            if (
                identity in identities
                or not r["state_text"]
                or not r["member_name_text"]
                or not r["party_text"]
                or not re.fullmatch(r"\d+%", r["score_text"])
                or (chamber == "House" and not re.fullmatch(r"\d+", r["district_text"]))
                or (chamber == "Senate" and r["district_text"] is not None)
                or (r["notes_text"] is not None and not isinstance(r["notes_text"], str))
                or set(r["item_results"]) != {str(i) for i in range(1, len(spec["columns"]) + 1)}
                or any(g not in GLYPHS for g in r["item_results"].values())
                or len(physical) != 1
                or type(physical[0]) is not int
                or not 1 <= physical[0] <= spec["pages"]
                or evidence["schema_version"]
                not in {"afge-current-pdf-member-facts/1", "afge-current-pdf-native-reviewed-facts/1"}
                or not evidence["json_pointer"].startswith("/members/")
                or any(
                    not re.fullmatch(r"[a-f0-9]{64}", evidence[f])
                    for f in ["outcome_sha256", "observation_sha256", "native_text_sha256"]
                )
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[chamber][str(physical[0])] += 1
        if dict(counts) != data["member_counts"] or any(
            dict(pages[c]) != data["member_page_counts"][c]
            or set(pages[c]) != {str(i) for i in range(1, PDFS[c]["pages"] + 1)}
            for c in PDFS
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError("AFGE semantic facts no longer establish complete source grids") from error


@dataclass(frozen=True, slots=True)
class AFGEReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        _qualified(self.qualified_observations)
        document = context.read(INDEX, stage="afge:index", hosts=HOSTS)
        soup = parse_html(document)
        matches = [
            a
            for a in soup.find_all("a", href=True)
            if a.get_text(" ", strip=True) == "2025 Voting Records" and urljoin(document.url, a["href"]) == TRACKER
        ]
        if len(matches) != 1:
            raise ScorecardSourceError("AFGE index no longer identifies the reviewed 2025 tracker")
        return (EDITION,)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _references(r, path):
    citations = []
    for i, match in enumerate(CITATION.finditer(r["source_text"])):
        literal = match.group()
        kind = "amendment" if "Amdt." in literal else "bill"
        citations.append(
            {
                "occurrence_id": f"citation:{i}",
                "citation_text": literal,
                "kind": kind,
                "source_path": path + "/td[1]",
                kind + "_citation_text": literal,
            }
        )
    for i, link in enumerate(r["links"]):
        occurrence = {
            "occurrence_id": f"vote-link:{i}",
            "citation_text": link["url"],
            "kind": "roll_call",
            "source_path": path + f"/td[5]//a[{i + 1}]/@href",
        }
        if m := re.search(r"/votes/(house|senate)/(\d+)-(\d+)/(\d+)", link["url"]):
            occurrence.update(chamber_text=m[1].title(), congress_text=m[2], session_text=m[3], roll_number_text=m[4])
        elif m := re.search(r"/vote_(\d+)_(\d+)_(\d+)\.htm", link["url"]):
            occurrence.update(chamber_text="Senate", congress_text=m[1], session_text=m[2], roll_number_text=m[3])
        citations.append(occurrence)
    return citations


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("AFGE reader requires its reviewed named 2025 tracker edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AFGE requires pinned reviewed PDF facts and private retention")
    data = _qualified(qualified_observations)
    tracker = context.read(TRACKER, stage="afge:tracker", hosts=HOSTS)
    facts = _tracker(tracker)
    bundle = Bundle(
        edition,
        context,
        tracker,
        publisher_name="American Federation of Government Employees",
        parser_version=parser_version,
        homepage="https://www.afge.org/",
        rendition_rule="complete native tracker item explanations plus both reviewed original member PDF grids",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        edition_label_text="2025",
        methodology_url=TRACKER,
        timespan_text="2025",
        periods_json=json_column(
            [
                {
                    "occurrence_id": "tracker-period",
                    "period_text": "2025",
                    "year_text": "2025",
                    "kind": "explicit",
                    "source_path": "introductory paragraph",
                }
            ]
        ),
    )
    for i, r in enumerate(facts["items"], 1):
        path = f"table#example/tbody/tr[{i}]"
        refs = _references(r, path)
        bills = [x["citation_text"] for x in refs if x["kind"] == "bill"]
        amendments = [x["citation_text"] for x in refs if x["kind"] == "amendment"]
        roll = re.search(r"Roll Call Vote (\d+)", r["title"]) if r["chamber"] in PDFS else None
        bundle.add(
            "scorecard_methodologies",
            tracker,
            path,
            methodology_id=key("item", str(i)),
            chamber_text=r["chamber"],
            disclosure_status="explicit",
            methodology_text=json_column(r),
        )
        bundle.add(
            "scorecard_items",
            tracker,
            path,
            item_id=str(i),
            item_kind_text="Congressional vote",
            title=r["title"],
            item_date_text=r["date"],
            chamber_text=r["chamber"],
            roll_number_text=roll[1] if roll else None,
            bill_citation_text=next(iter(bills), None),
            amendment_citation_text=next(iter(amendments), None),
            references_json=json_column(refs),
            publisher_position_text=r["position"],
            position_basis="explicit",
            position_source_path=path + "/td[2]",
        )
    documents, observations = {}, {}
    for chamber, spec in PDFS.items():
        document = context.read(spec["url"], stage="afge:pdf:" + chamber.lower(), hosts=HOSTS)
        _pdf(document, spec)
        documents[chamber] = document
        observations[chamber] = retain_qualified(
            document,
            qualified_observations,
            retain_observations,
            source_sha256=spec["sha256"],
            observations_sha256=QUALIFIED_SHA256,
            stage="afge:qualified-observations:" + chamber.lower(),
        )
        bundle.use(document, chamber + "-members", chamber + "-ratings", chamber + "-results", chamber + "-metrics")
        path = "pdf:all-pages;observation=" + observations[chamber]
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=key(chamber, "grid"),
            chamber_text=chamber,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_column_titles": data["column_titles"][chamber],
                    "source_observations": [x for x in data["reviewed_source_observations"] if x["chamber"] == chamber],
                    "source_legend": [],
                    "source_formula_text": None,
                    "source_weight_text": None,
                }
            ),
        )
        bundle.metric(document, chamber, "AFGE Score", path=path, chamber=chamber, unit="%")
        for column, item in enumerate(spec["columns"], 1):
            bundle.add(
                "scorecard_metric_items",
                document,
                path + "/column/" + str(column),
                metric_id=chamber,
                item_id=str(item),
                participation_id=key(chamber, str(column)),
                methodology_id=key(chamber, "grid"),
                publisher_position_text=facts["items"][item - 1]["position"],
                position_basis="explicit",
            )
    for i, entry in enumerate(data["members"]):
        r, chamber = entry["record"], entry["chamber"]
        document, spec = documents[chamber], PDFS[chamber]
        path = (
            "pdf:pages="
            + str(entry["evidence"]["physical_pages"][0])
            + ";observation="
            + observations[chamber]
            + f";/members/{i}/record"
        )
        member = key(
            chamber,
            str(entry["evidence"]["physical_pages"][0]),
            entry["evidence"]["json_pointer"],
            r["state_text"],
            *([r["district_text"]] if r["district_text"] else []),
            r["member_name_text"],
        )
        bundle.add(
            "scorecard_members",
            document,
            path,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            chamber_text=chamber,
            period_text="2025",
            identifiers_json="[]",
            notes_text=r["notes_text"],
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            path + "/score_text",
            publisher_member_key=member,
            metric_id=chamber,
            value_text=r["score_text"],
            value_number=decimal_text(r["score_text"]),
            notes_text=r["notes_text"],
        )
        for column, item in enumerate(spec["columns"], 1):
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + "/item_results/" + str(column),
                publisher_member_key=member,
                metric_id=chamber,
                item_id=str(item),
                participation_id=key(chamber, str(column)),
                result_id=key(chamber, str(column)),
                result_text=r["item_results"][str(column)],
            )
    repeated = context.read(TRACKER, stage="afge:tracker:reread", hosts=HOSTS)
    if _tracker(repeated) != facts:
        raise ScorecardSourceError("AFGE tracker changed during complete acquisition")
    bundle.use(repeated, role="corroboration")
    for chamber, spec in PDFS.items():
        repeated = context.read(spec["url"], stage="afge:pdf:reread:" + chamber.lower(), hosts=HOSTS)
        _pdf(repeated, spec)
        bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "All native tracker items, both complete PDF page populations, every published percentage and action cell "
        "reconcile retained semantic and independent native observations; complete original renditions reread stably",
        declared={
            "source_counts_basis": "complete publisher-defined named member grids, not official membership census",
            "members_by_chamber": data["member_counts"],
            "members_by_physical_page": data["member_page_counts"],
            "publisher_items": 9,
            "source_grid_action_columns": data["item_column_counts"],
            "compound_item_participation": "HTML item3 retains House70, Senate128 and Senate133 as separate cells",
        },
    )
