"""AFBF's complete archived Senate key-vote tables from its original app.

This named rendition supplies actions and preferred positions, not a published
aggregate rating. Missing standing fields stay missing, including replacement
members. The publisher's House samples and other Congresses are outside scope.
"""

from __future__ import annotations

import re
from hashlib import sha256

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    json_data,
    key,
    soup,
)

parser_version = "farm-bureau-115-senate-original-archived-json/1"
HOSTS = ("web.archive.org",)
APP = "https://scorecard.fb.org/"
ARCHIVE = "https://web.archive.org/web/"
HOME = ARCHIVE + "20171121171212id_/" + APP + "partials/home"
METHOD = ARCHIVE + "20180410203306id_/" + APP + "partials/scorecard"
CLIENT = ARCHIVE + "20171024054959id_/" + APP + "resources/js/builds/app.js"
CATALOG = ARCHIVE + "20180410192404id_/" + APP + "api/key-votes"
VOTES = {
    "111": ("20180410203309", "1c021cfd91c704df58d20c848467400f4ed035dde87539754d19b61f501ad4d1"),
    "127": ("20180410203307", "696a2e6f439435bfa4dd8135fee70e2e85f0719ad2a07299d00ac607e4f256e0"),
    "303": ("20180410203307", "d40aac13ed5749729410eeb6eb1544791515d54e50d0075922e8e287d62509f1"),
    "71": ("20180410203307", "d5d1aa31178a7f30af800157d03a9857085b93b7e6ad5eb63956dd604ca91627"),
}
PINS = {
    HOME: "196ae40dfac35334d1355c814a89688bc81ec4fd1b934bc8fd9cd3f43d1e0cef",
    METHOD: "748c5ca3afc9be319295bc48f36864a3872ac556297b95288ba87d74f0adee05",
    CLIENT: "9b6d1318a470393a6ff77a49a63cec4fb0176f88cc9e568416daecc9c0773134",
    CATALOG: "a17d46c1254c4035150cd066f65b0621cea73fa6e4ab58cd8d904781efe8e8ea",
}
EDITION = ScorecardEdition(
    "farm_bureau",
    "115-senate-original-archived-key-vote-tables",
    METHOD,
    "FB Advocacy Congressional Voting Record",
    congress="115",
    chamber="senate",
    is_current=False,
)
VOTE_FIELDS = {
    "id",
    "number",
    "title",
    "rollCall",
    "description",
    "session",
    "chamber",
    "resolution",
    "position",
    "meeting",
    "date",
}
MEMBER_FIELDS = {"id", "first_name", "middle_name", "last_name", "party", "state", "district", "photoUrl"}


def _read(context, url, digest, group):
    document = context.read(url, stage="farm-bureau:" + group, hosts=HOSTS)
    if document.url != url or sha256(document.body).hexdigest() != digest:
        raise ScorecardSourceError("AFBF named original archived rendition changed at " + group)
    return document


def _catalog(document):
    records = json_data(document)
    if not isinstance(records, dict) or not records:
        raise ScorecardSourceError("AFBF key-vote catalogue is empty or not an object")
    selected = {}
    for identity, row in records.items():
        if (
            not isinstance(row, dict)
            or set(row) != VOTE_FIELDS
            or row["id"] != identity
            or any(not isinstance(row[field], str) for field in VOTE_FIELDS - {"date"})
            or type(row["date"]) is not int
        ):
            raise ScorecardSourceError("AFBF native key-vote fields or identities changed")
        if (row["meeting"], row["chamber"]) != ("115", "senate"):
            continue
        if (
            row["session"] != "1"
            or row["rollCall"] not in VOTES
            or row["rollCall"] in selected
            or row["position"] not in {"approve", "oppose"}
            or not row["title"]
            or not row["description"]
            or not row["resolution"]
        ):
            raise ScorecardSourceError("AFBF selected Senate vote scope is incomplete or changed")
        selected[row["rollCall"]] = row
    if set(selected) != set(VOTES):
        raise ScorecardSourceError("AFBF selected catalogue is missing an original Senate item")
    return selected


def _members(document, roll):
    records = json_data(document)
    if not isinstance(records, dict) or len(records) != 100:
        raise ScorecardSourceError("AFBF original Senate table is incomplete")
    for identity, row in records.items():
        if (
            not re.fullmatch(r"[A-Z]\d{6}", identity)
            or not isinstance(row, dict)
            or set(row) not in (MEMBER_FIELDS, MEMBER_FIELDS | {"standing"})
            or row["id"] != identity
            or row["district"] is not False
            or any(
                not isinstance(row[field], str) or not row[field]
                for field in ("first_name", "last_name", "party", "state")
            )
            or row["middle_name"] is not None
            and not isinstance(row["middle_name"], str)
            or not isinstance(row["photoUrl"], str)
            or not re.fullmatch(r"[A-Z]{2}", row["state"])
        ):
            raise ScorecardSourceError("AFBF original member fields or identity changed")
        if "standing" in row and (
            not isinstance(row["standing"], dict)
            or set(row["standing"]) != {roll}
            or row["standing"][roll] not in {"Yes", "No", "Not Voting"}
        ):
            raise ScorecardSourceError("AFBF member standing does not match its selected vote")
    return records


def list_scorecards(context: ScorecardContext):
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("AFBF reader supports only the named original archived Senate tables")
    home, method, client, catalogue = (
        _read(context, url, PINS[url], group)
        for url, group in (
            (HOME, "overview"),
            (METHOD, "methodology"),
            (CLIENT, "original-client"),
            (CATALOG, "key-votes"),
        )
    )
    selected = _catalog(catalogue)
    tables = {}
    for roll, (timestamp, digest) in VOTES.items():
        url = ARCHIVE + timestamp + "id_/" + APP + "api/scorecard/115/senate/1/" + roll
        document = _read(context, url, digest, "vote:" + roll)
        tables[roll] = (document, _members(document, roll))
    first = tables[next(iter(VOTES))][1]
    for _, members in tables.values():
        if set(members) != set(first) or any(
            {k: v for k, v in members[identity].items() if k != "standing"}
            != {k: v for k, v in first[identity].items() if k != "standing"}
            for identity in first
        ):
            raise ScorecardSourceError("AFBF source-defined member cohort changes between votes")
    bundle = Bundle(
        edition,
        context,
        method,
        publisher_name="American Farm Bureau Federation",
        parser_version=parser_version,
        rendition_rule="afbf-native-complete-115-senate-key-vote-tables/1",
        homepage="https://www.fb.org/",
    )
    for document, group in ((home, "overview"), (client, "client-scope"), (catalogue, "items")):
        bundle.use(document, group)
    for document, selector, identity in ((home, "#copy", "publisher-overview"), (method, "#copy", "key-vote-criteria")):
        nodes = soup(document).select(selector)
        if len(nodes) != 1:
            raise ScorecardSourceError("AFBF original narrative section is missing")
        bundle.add(
            "scorecard_methodologies",
            document,
            selector,
            methodology_id=identity,
            methodology_text=nodes[0].get_text(" ", strip=True),
            disclosure_status="explicit: key-vote selection",
        )
    legends = soup(method).select("#state-select")
    if len(legends) != 1:
        raise ScorecardSourceError("AFBF original action legend and state filter are missing")
    bundle.add(
        "scorecard_methodologies",
        method,
        "#state-select",
        methodology_id="native-action-key-and-filter",
        methodology_text=json_column({"text": legends[0].get_text(" ", strip=True), "html": str(legends[0])}),
        disclosure_status="explicit: publisher action key",
    )
    for roll, row in selected.items():
        path = "$[" + repr(row["id"]) + "]"
        citation_kind = "nomination" if row["resolution"].startswith("P.N. ") else "bill"
        bundle.add(
            "scorecard_items",
            catalogue,
            path,
            item_id=row["id"],
            publisher_item_id=row["id"],
            item_kind_text="recorded floor vote",
            title=row["title"],
            item_date_text=str(row["date"]),
            congress_text=row["meeting"],
            chamber_text=row["chamber"],
            session_text=row["session"],
            roll_number_text=roll,
            bill_citation_text=row["resolution"] if citation_kind == "bill" else None,
            references_json=json_column(
                [
                    {
                        "occurrence_id": "resolution",
                        "citation_text": row["resolution"],
                        "kind": citation_kind,
                        "source_path": path + ".resolution",
                        "congress_text": row["meeting"],
                        "chamber_text": row["chamber"],
                        "session_text": row["session"],
                        "roll_number_text": roll,
                    }
                ]
            ),
            publisher_position_text=row["position"],
            position_basis="explicit",
            position_source_path=path + ".position",
        )
        bundle.add(
            "scorecard_methodologies",
            catalogue,
            path,
            methodology_id=key(row["id"], "rationale"),
            methodology_text=json_column({"native_item": row}),
            disclosure_status="explicit: publisher item rationale",
        )
    member_document = tables[next(iter(VOTES))][0]
    bundle.use(member_document, "member-identities")
    for identity in sorted(first):
        row = first[identity]
        path = "$[" + repr(identity) + "]"
        identifiers = []
        # A Bioguide photo locator explicitly names that identity. Other publisher
        # IDs stay untyped rather than relying on their spelling alone.
        if re.fullmatch(r"http://bioguide\.congress\.gov/bioguide/photo/[A-Z]/" + identity + r"\.jpg", row["photoUrl"]):
            identifiers.append({"scheme": "bioguide", "value": identity})
        bundle.add(
            "scorecard_members",
            member_document,
            path,
            publisher_member_key=identity,
            publisher_member_id=row["id"],
            identifiers_json=json_column(identifiers),
            member_name=row["first_name"] + " " + row["last_name"],
            chamber_text="senate",
            state=row["state"],
            district="false",
            party=row["party"],
            notes_text=json_column(
                {
                    "native_identity": {field: row[field] for field in sorted(MEMBER_FIELDS)},
                    "source_path": path,
                }
            ),
        )
    for roll, (document, members) in tables.items():
        bundle.use(document, "vote:" + roll)
        for identity in sorted(members):
            row = members[identity]
            path = "$[" + repr(identity) + "]"
            action = row.get("standing", {}).get(roll)
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + ".standing[" + repr(roll) + "]" if action is not None else path,
                result_id=key(selected[roll]["id"], identity),
                item_id=selected[roll]["id"],
                publisher_member_key=identity,
                action_text=action,
            )
    for url, digest, group in [
        (CATALOG, PINS[CATALOG], "key-votes"),
        *((tables[roll][0].url, VOTES[roll][1], "vote:" + roll) for roll in VOTES),
    ]:
        reread = _read(context, url, digest, "stable-reread:" + group)
        bundle.use(reread, "items" if group == "key-votes" else group, role="corroboration")
    return bundle.finish(
        "The exact original key-vote catalogue selects every item for Congress 115 Senate. "
        "Every selected original API response reaches valid JSON EOF, contains the complete named member cohort, "
        "and agrees on source identities. Original archive digests and fresh rereads match; all item/member "
        "cells are retained, including absent standing fields. No aggregate score or official action is calculated."
    )
