"""Defenders Action Fund's named original Conservation Report Card PDFs."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "defenders-action-named-original-pdf/1"
HOSTS = ("defenders.org",)
# Each bound was measured across every printed source grid page, including
# replaced members, source spellings and undisclosed at-large districts.
SPECS: dict[str, dict[str, Any]] = {
    "2005": {
        "url": "https://defenders.org/sites/default/files/publications/2005reportcard.pdf",
        "source_sha256": "6499698ea0594f7330449e0092914ab3c42a8000f8112a6665728638c6585716",
        "qualified_sha256": "0c425db13a22b7d54857130cce571557927d5aa054094708235752fa398bde81",
        "combined_facts_sha256": "d807e6cebe5b90ef0051bed8bdb7c322b4579c618363eac0b3a5cb8f235cb7ad",
        "title": "CONSERVATION \nREPORT CARD",
        "year": "2005",
        "congress": "109",
        "session": "1",
        "period": "2005",
        "session_label": "1st Session",
        "page_count": 22,
        "member_counts": {"House": 438, "Senate": 100},
        "item_counts": {"House": 9, "Senate": 8},
        "page_members": {
            "5": 20,
            "6": 22,
            "7": 22,
            "8": 22,
            "9": 14,
            "11": 40,
            "12": 47,
            "13": 41,
            "14": 39,
            "15": 39,
            "16": 41,
            "17": 37,
            "18": 44,
            "19": 39,
            "20": 45,
            "21": 26,
        },
        "glyph_counts": {"-": 2499, "+": 2115, "NV": 91, "NA": 33, "S": 4},
    },
    "2005-2006": {
        "url": "https://defenders.org/sites/default/files/publications/2006reportcard.pdf",
        "source_sha256": "6ab8fb78522bee0f997beba9caab23536a108d7fba60c66ed062192acefe2e3a",
        "qualified_sha256": "7b71fb29e558d3fe16229756393ac1e08b61672cc97161d52c0d70cf53c2b910",
        "combined_facts_sha256": "d807e6cebe5b90ef0051bed8bdb7c322b4579c618363eac0b3a5cb8f235cb7ad",
        "title": "Conservation \nReport Card",
        "year": "2005-2006",
        "congress": "109",
        "session": None,
        "period": "2005-2006",
        "session_label": None,
        "page_count": 25,
        "member_counts": {"House": 439, "Senate": 101},
        "item_counts": {"House": 20, "Senate": 11},
        "page_members": {
            "4": 20,
            "5": 20,
            "6": 21,
            "7": 20,
            "8": 20,
            "11": 32,
            "12": 38,
            "13": 32,
            "14": 32,
            "15": 34,
            "16": 31,
            "17": 31,
            "18": 29,
            "19": 35,
            "20": 33,
            "21": 31,
            "22": 33,
            "23": 31,
            "24": 17,
        },
        "glyph_counts": {"-": 5243, "+": 4297, "NV": 217, "NA": 119, "S": 13, "P": 1, "?": 1},
    },
}
GLYPHS = {"+", "-", "P", "S", "NV", "NA", "?", None}


def _spec(identifier):
    if identifier not in SPECS:
        raise ScorecardSourceError("Defenders Action Fund requires a reviewed named original PDF edition")
    return SPECS[identifier]


def _edition(identifier):
    spec = _spec(identifier)
    return ScorecardEdition(
        "defenders_action",
        identifier,
        spec["url"],
        spec["title"],
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    require_reviewed_pdf(
        document,
        source_url=spec["url"],
        source_sha256=spec["source_sha256"],
        message="Defenders Action Fund source differs from the complete reviewed original PDF",
    )


def _qualified(body, identifier, spec):
    try:
        if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
            raise ValueError
        data = json.loads(body)
        if (
            data["format_version"] != "defenders-action-qualified-native-pdf/1"
            or data["edition_key"] != identifier
            or data["combined_source_facts_sha256"] != spec["combined_facts_sha256"]
            or data["source_url"] != spec["url"]
            or data["source_sha256"] != spec["source_sha256"]
            or data["source_page_count"] != spec["page_count"]
            or data["page_members"] != spec["page_members"]
        ):
            raise ValueError
        method = data["methodology"]
        if method["native_metric_label"] != "SCORE" or method["declared_key_votes"] != spec["item_counts"]:
            raise ValueError
        for field_name in ("introduction_text", "incomplete_note_text"):
            if not isinstance(method[field_name], str) or not method[field_name]:
                raise ValueError
        for page_field in ("introduction_page", "legend_page", "incomplete_note_page"):
            if type(method[page_field]) is not int or not 1 <= method[page_field] <= spec["page_count"]:
                raise ValueError
        codes = []
        for legend in method["legend"]:
            if not isinstance(legend["code_text"], str) or not isinstance(legend["meaning_text"], str):
                raise TypeError
            codes.append(legend["code_text"])
        if codes != ["+", "-", "P", "S", "NV", "NA", "100%", "0%"]:
            raise ValueError
        grid_legend = method.get("grid_legend", [])
        if grid_legend:
            if [entry["code_text"] for entry in grid_legend] != codes or not all(
                isinstance(entry["meaning_text"], str) and entry["meaning_text"] for entry in grid_legend
            ):
                raise ValueError
            if (
                not isinstance(method.get("grid_legend_text"), str)
                or type(method.get("grid_legend_page")) is not int
                or not 1 <= method["grid_legend_page"] <= spec["page_count"]
            ):
                raise ValueError
        item_ordinals = {chamber: [] for chamber in spec["item_counts"]}
        for item in data["items"]:
            chamber, ordinal = item["chamber_text"], item["ordinal"]
            if chamber not in item_ordinals or type(ordinal) is not int:
                raise ValueError
            page = item["physical_page"]
            if type(page) is not int or not 1 <= page <= spec["page_count"]:
                raise ValueError
            if not all(isinstance(item[name], str) and item[name] for name in ("title_text", "native_paragraph_text")):
                raise ValueError
            paragraph = item["native_paragraph_text"]
            if re.findall(r"H\.R\.\s*\d+", paragraph) != item["bill_citations"]:
                raise ValueError
            rolls = re.findall(r"Roll Call No\.\s*(\d+)", paragraph)
            if rolls != ([] if item["roll_number_text"] is None else [item["roll_number_text"]]):
                raise ValueError
            if item["item_date_text"] is not None and item["item_date_text"] not in paragraph:
                raise ValueError
            item_ordinals[chamber].append(ordinal)
        if any(values != list(range(1, spec["item_counts"][chamber] + 1)) for chamber, values in item_ordinals.items()):
            raise ValueError
        counts, pages, glyphs, identities = Counter(), Counter(), Counter(), set()
        for member in data["members"]:
            r, chamber = member["record"], member["chamber_text"]
            page, ordinal = member["physical_page"], member["row_ordinal"]
            if (
                chamber not in spec["member_counts"]
                or type(page) is not int
                or str(page) not in spec["page_members"]
                or type(ordinal) is not int
                or ordinal != pages[str(page)] + 1
                or type(member["source_line_index"]) is not int
                or member["source_line_index"] < 0
                or not isinstance(member["raw_name_line"], str)
                or not all(isinstance(r[name], str) and r[name] for name in ("member_name_text", "state_text"))
                or r["party_text"] not in {"R", "D", "I"}
                or (r["district_text"] is not None and re.fullmatch(r"\d+", r["district_text"]) is None)
                or not isinstance(r["item_results"], list)
                or len(r["item_results"]) != spec["item_counts"][chamber]
                or any(glyph not in GLYPHS for glyph in r["item_results"])
                or not isinstance(r["value_text"], str)
                or re.fullmatch(r"\d{1,3}%|NA|Incomplete", r["value_text"]) is None
            ):
                raise ValueError
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[str(page)] += 1
            glyphs.update(r["item_results"])
        if (
            dict(counts) != spec["member_counts"]
            or dict(pages) != spec["page_members"]
            or dict(glyphs) != spec["glyph_counts"]
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "Defenders Action Fund facts do not establish the complete reviewed printed rendition"
        ) from error


@dataclass(frozen=True, slots=True)
class DefendersActionPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError("Defenders observations must identify a reviewed named edition") from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("Defenders original PDF redistribution rights are not established")
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["url"], stage=f"defenders_action:{self.edition_key}:list", hosts=HOSTS), spec)
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError("Defenders reader requires its exact configured named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _normalized(value):
    # User-selected native-column normalization; original code remains in private
    # observations and attributable source notes, including score-column NA.
    return "N/A" if value == "NA" else value


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != _edition(edition.edition_id):
        raise ScorecardSourceError("Defenders requires the exact reviewed named edition")
    if context.evidence_policy == "full":
        raise ScorecardSourceError("Defenders original PDF redistribution rights are not established")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Defenders requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    stage = f"defenders_action:{edition.edition_id}"
    document = context.read(spec["url"], stage=stage + ":pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=stage + ":qualified-observations",
    )

    def location(page, pointer):
        return f"pdf:page[{page}];observation={observation};{pointer}"

    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="Defenders of Wildlife Action Fund",
        parser_version=parser_version,
        rendition_rule="complete named original PDF; every printed member, fraction, native criterion and legend checked against original pages; NA normalized to N/A without interpreting unknown glyphs or recalculating",
        homepage="www.defendersactionfund.org",
    )
    front = data["methodology"]
    cover_path = location(1, "/cover")
    periods = [
        {"occurrence_id": "cover:year", "period_text": spec["period"], "kind": "explicit", "source_path": cover_path},
        {
            "occurrence_id": "cover:congress",
            "period_text": "109th Congress",
            "kind": "explicit",
            "source_path": cover_path,
        },
    ]
    if spec["session_label"] is not None:
        periods.append(
            {
                "occurrence_id": "cover:session",
                "period_text": spec["session_label"],
                "kind": "explicit",
                "source_path": cover_path,
            }
        )
    bundle.tables["scorecard_publishers"][0]["source_path"] = location(spec["page_count"], "/publisher")
    bundle.tables["scorecards"][0].update(
        edition_label_text=spec["period"],
        timespan_text=spec["period"],
        session_text=spec["session_label"],
        periods_json=json_column(periods),
        methodology_url=document.url,
        source_path=cover_path,
    )
    for chamber in spec["member_counts"]:
        grid_page = min(member["physical_page"] for member in data["members"] if member["chamber_text"] == chamber)
        method_id = key(chamber, "legend")
        method_path = location(front["introduction_page"], "/methodology")
        bundle.add(
            "scorecard_methodologies",
            document,
            method_path,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_url=document.url,
            disclosure_status="partial",
            methodology_text=json_column(front),
        )
        bundle.add(
            "scorecard_metrics",
            document,
            location(grid_page, "/grid/header/SCORE"),
            metric_id=key(chamber, "score"),
            methodology_id=method_id,
            name="SCORE",
            value_unit_text="%",
            chamber_text=chamber,
            period_text=spec["period"],
            periods_json=json_column(periods),
        )
    for index, item in enumerate(data["items"]):
        chamber, ordinal = item["chamber_text"], str(item["ordinal"])
        path = location(item["physical_page"], f"/items/{index}")
        item_id, method_id = key(chamber, ordinal), key(chamber, "item", ordinal)
        references = []
        for match in re.finditer(r"H\.R\.\s*\d+|Roll Call No\.\s*\d+", item["native_paragraph_text"]):
            citation = match.group()
            kind = "bill" if citation.startswith("H.R.") else "roll_call"
            reference = {
                "occurrence_id": f"native:{len(references)}",
                "citation_text": citation,
                "kind": kind,
                "source_path": path + f"/native_paragraph_text/chars[{match.start()}:{match.end()}]",
                "chamber_text": chamber,
                "congress_text": spec["congress"],
                "session_text": spec["session_label"],
            }
            reference["bill_citation_text" if kind == "bill" else "roll_number_text"] = (
                citation if kind == "bill" else item["roll_number_text"]
            )
            references.append(reference)
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_url=document.url,
            disclosure_status="partial",
            methodology_text=item["native_paragraph_text"],
        )
        bundle.add(
            "scorecard_items",
            document,
            path,
            item_id=item_id,
            publisher_item_id=ordinal,
            item_kind_text="Key Votes" if edition.edition_id == "2005" else "Key Issues and Votes",
            title=item["title_text"],
            item_date_text=item["item_date_text"],
            congress_text=spec["congress"],
            chamber_text=chamber,
            session_text=spec["session_label"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=next(iter(item["bill_citations"]), None),
            references_json=json_column(references),
            position_basis="absent",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            path,
            metric_id=key(chamber, "score"),
            item_id=item_id,
            participation_id="printed-key-vote",
            methodology_id=method_id,
            position_basis="absent",
        )
    # The later report's grid says "With Us" where its item-page legend says
    # "For Conservation". Preserve both; native result meanings use that grid's
    # own legend when it is printed, without deriving preferred Yea/Nay.
    legend = {entry["code_text"]: entry["meaning_text"] for entry in (front.get("grid_legend") or front["legend"])}
    for index, member in enumerate(data["members"]):
        r, chamber = member["record"], member["chamber_text"]
        path = location(member["physical_page"], f"/members/{index}/record")
        member_key = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            document,
            path,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text=spec["period"],
            identifiers_json="[]",
            notes_text=json_column(
                {"raw_name_line": member["raw_name_line"], "source_line_index": member["source_line_index"]}
            ),
        )
        value = _normalized(r["value_text"])
        bundle.add(
            "scorecard_member_ratings",
            document,
            path + "/value_text",
            metric_id=key(chamber, "score"),
            publisher_member_key=member_key,
            value_text=value,
            value_number=decimal_text(value),
            value_status_text="Incomplete" if value == "Incomplete" else None,
            notes_text=json_column({"native_value_text": r["value_text"]}) if value != r["value_text"] else None,
        )
        for offset, raw_glyph in enumerate(r["item_results"], 1):
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + f"/item_results/{offset - 1}",
                item_id=key(chamber, str(offset)),
                result_id="native-cell",
                publisher_member_key=member_key,
                result_text=_normalized(raw_glyph),
                reason_text=legend.get(raw_glyph),
            )
    reread = context.read(spec["url"], stage=stage + ":pdf:reread", hosts=HOSTS)
    _source(reread, spec)
    bundle.use(reread, "edition", role="corroboration")
    return bundle.finish(
        "exact complete named PDF and private reviewed observations; source member/page/ordinal/item/glyph bounds reconciled; identical original PDF reread before closing",
        declared={"key_votes:" + chamber: count for chamber, count in spec["item_counts"].items()},
    )
