"""AGC's complete native aggregate tables and key-vote indexes.

Profiles, sponsorships and individual actions are separate renditions. No roll
number or official member identifier is inferred from a publisher URL.
"""

import re
from urllib.parse import urlsplit

from bs4 import Comment

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key, soup, validate_url

parser_version = "agc-html-aggregate-key-vote-index/1"
NAME = "Associated General Contractors of America"
HOMEPAGE = "https://www.agc.org/"
INDEX = "https://advocacy.agc.org/legislator-scorecard/"
ORIGIN = "https://agcscorecard.voxara.net"
STYLE = ORIGIN + "/css/style.css"
TITLE = "CONGRESSIONAL SCORECARD"
CONGRESSES = ("119", "118", "117", "116")
# Exact observed complete cohorts in the retained qualification, not official
# roster counts or publisher-declared counts. Drift needs a fresh qualification.
REVIEWED_COUNTS = {
    ("119", "house"): (445, 5),
    ("119", "senate"): (102, 2),
    ("118", "house"): (442, 10),
    ("118", "senate"): (102, 4),
    ("117", "house"): (449, 9),
    ("117", "senate"): (100, 6),
    ("116", "house"): (437, 12),
    ("116", "senate"): (99, 3),
}


def _url(kind, chamber, congress):
    return f"{ORIGIN}/{kind}-{chamber}?search-congress={congress}"


def edition(congress):
    if congress not in CONGRESSES:
        raise ScorecardSourceError("AGC congressional rendition has not been qualified")
    return ScorecardEdition(
        "agc",
        congress + "-aggregate-key-vote-index",
        _url("members", "house", congress),
        TITLE,
        congress=congress,
        chamber="both",
        is_current=congress == CONGRESSES[0],
    )


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("AGC native field is missing or repeated: " + selector)
    return nodes[0]


def _layout(node, children):
    elements = [child.name for child in node.children if getattr(child, "name", None)]
    text = [str(child).strip() for child in node.children if isinstance(child, str) and not isinstance(child, Comment)]
    if elements != children or any(text):
        raise ScorecardSourceError("AGC native table exposes unreviewed content or notes")


def _html(document, url):
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("AGC selected original route changed")
    if not document.body.rstrip().lower().endswith(b"</html>") or b"</body>" not in document.body.lower():
        raise ScorecardSourceError("AGC original HTML is incomplete")
    html = soup(document)
    _one(html, "html")
    _one(html, "body")
    # The publisher's WordPress guide has unrelated navigation. Only a native
    # scorecard table's pagination describes the selected scoring population.
    if url != INDEX and html.select("[class*='pagination'], [class*='pager'], [data-next-page], a[rel='next']"):
        raise ScorecardSourceError("AGC original exposes an unreviewed partial population")
    return html


def _authority(document):
    html = _html(document, INDEX)
    heading = _one(html, "#main h1")
    frame = _one(html, "iframe#agcscorecard")
    context = _one(html, "#main .fusion-text")
    if _text(heading) != "How Congress Voted" or frame.get("src") != ORIGIN + "/members-house" or not _text(context):
        raise ScorecardSourceError("AGC publisher no longer designates the selected scorecard host")
    return {"heading": _text(heading), "context": _text(context), "scorecard_url": frame["src"]}


def _name_display(document):
    if document.url != STYLE or document.response.requested_url != STYLE:
        raise ScorecardSourceError("AGC selected name-display stylesheet route changed")
    try:
        css = re.sub(r"/\*.*?\*/", "", document.body.decode("utf-8"), flags=re.DOTALL)
    except UnicodeError as error:
        raise ScorecardSourceError("AGC name-display stylesheet is not UTF-8") from error
    rules = re.findall(r"(?:^|})\s*span\.hide\s*\{([^{}]*)\}", css)
    if len(rules) != 1 or not re.fullmatch(r"\s*display\s*:\s*none\s*;\s*", rules[0]):
        raise ScorecardSourceError("AGC native sorting surname is no longer explicitly hidden")
    return "span.hide { display: none; }"


def _table(document, kind, chamber, congress):
    html = _html(document, _url(kind, chamber, congress))
    if _text(_one(html, "title")) != NAME or _text(_one(html, "h1")) != TITLE:
        raise ScorecardSourceError("AGC scorecard attribution or heading changed")
    if len(html.select('link[rel="stylesheet"][href="' + STYLE + '"]')) != 1:
        raise ScorecardSourceError("AGC native name-display stylesheet reference changed")
    form = _one(html, "form#searchForm")
    if form.get("action") != kind + "-" + chamber or form.get("method", "").upper() != "GET":
        raise ScorecardSourceError("AGC unfiltered table form changed")
    options = _one(html, "select#search-congress").find_all("option", recursive=False)
    if [o.get("value") for o in options] != list(CONGRESSES) or [
        o.get("value") for o in options if o.has_attr("selected")
    ] != [congress]:
        raise ScorecardSourceError("AGC selected period or complete congressional catalog changed")
    labels = [_text(o) for o in options]
    if any(
        not re.fullmatch(c + r"(?:st|nd|rd|th) Congress", label) for c, label in zip(CONGRESSES, labels, strict=True)
    ):
        raise ScorecardSourceError("AGC congressional label changed")
    if html.select("input[checked]") or any(n.get("value", "") for n in html.select("input[type='search']")):
        raise ScorecardSourceError("AGC member table is filtered")
    selected_states = html.select("select#search-state option[selected]")
    if selected_states and (len(selected_states) != 1 or selected_states[0].get("value") != ""):
        raise ScorecardSourceError("AGC member table has a selected state")
    table = _one(html, "table#myTable")
    container = _one(html, ".record-list > section.container-fluid")
    responsive = _one(container, "section.table-responsive")
    _layout(container.parent, ["section"])
    _layout(container, ["section"])
    _layout(responsive, ["table"])
    _layout(table, ["thead", "tbody"])
    expected = (
        ["MEMBER", "PARTY", "CHAMBER", "DISTRICT", "CURRENT", "LIFETIME"]
        if kind == "members"
        else ["BILL", "TITLE", "AGC", "RESULT"]
    )
    if len(html.select("table")) != 1 or [_text(n) for n in table.select("thead th")] != expected:
        raise ScorecardSourceError("AGC native table columns changed")
    if table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]"):
        raise ScorecardSourceError("AGC table exposes unreviewed notes or exclusions")
    rows = _one(table, "tbody").find_all("tr", recursive=False)
    expected_count = REVIEWED_COUNTS[(congress, chamber)][0 if kind == "members" else 1]
    if len(rows) != expected_count or len(table.select("tbody tr")) != len(rows):
        raise ScorecardSourceError("AGC complete named table population changed")
    _layout(_one(table, "tbody"), ["tr"] * len(rows))
    facts, identities = [], set()
    for number, row in enumerate(rows, 1):
        cells = row.find_all("td", recursive=False)
        _layout(row, ["td"] * len(expected))
        route = re.fullmatch(r"document\.location='([^']+)'", row.get("onclick", ""))
        if (
            len(cells) != len(expected)
            or len(row.select("td")) != len(cells)
            or route is None
            or set(row.attrs) - {"class", "scope", "onclick", "style"}
            or any(set(cell.attrs) - {"class"} for cell in cells)
        ):
            raise ScorecardSourceError("AGC native row shape changed")
        url = route[1]
        validate_url(url, ("agcscorecard.voxara.net",))
        prefix = f"/{kind}-{chamber}/"
        parsed = urlsplit(url)
        native_id = parsed.path.removeprefix(prefix)
        if not parsed.path.startswith(prefix) or not native_id or "/" in native_id or parsed.fragment:
            raise ScorecardSourceError("AGC native row identifier changed")
        values = [_text(c) for c in cells]
        if kind == "members":
            sort_span = cells[0].find_all("span", recursive=False)
            if (
                len(sort_span) != 1
                or sort_span[0].get("class") != ["hide"]
                or len(cells[0].find_all()) != 1
                or any(cell.find() for cell in cells[1:])
                or set(sort_span[0].attrs) != {"class"}
            ):
                raise ScorecardSourceError("AGC native visible member name changed")
            values[0] = " ".join(
                str(n).strip() for n in cells[0].children if isinstance(n, str) and not isinstance(n, Comment)
            ).strip()
            if (
                not re.fullmatch(r"[A-Z]\d{6}", native_id)
                or parsed.query != "congress=" + congress
                or values[2] != chamber.title()
                or not re.fullmatch(r"[A-Z]{2} - (?:\d+|Senate|At-Large)", values[3])
                or any(not re.fullmatch(r"\d+%", v) for v in values[4:])
            ):
                raise ScorecardSourceError("AGC member period, chamber, district or native percentages changed")
            identity = native_id
        else:
            if parsed.query or any(c.find() for c in cells) or not all(values):
                raise ScorecardSourceError("AGC key-vote index exposes an unreviewed item shape")
            # The 116th Senate source reuses one URL for two differently titled
            # H.R.268 actions. Its URL alone is not a unique scoring-item ID.
            identity = key(native_id, values[1])
        if not all(values) or identity in identities:
            raise ScorecardSourceError("AGC native table repeats or omits an identity")
        identities.add(identity)
        facts.append(
            {
                "id": native_id,
                "identity": identity,
                "values": values,
                "url": url,
                "path": f"#myTable > tbody > tr:nth-of-type({number})",
                "sort_text": _text(sort_span[0]) if kind == "members" else None,
            }
        )
    return {"period": labels[CONGRESSES.index(congress)], "headers": expected, "rows": facts}


def list_scorecards(context):
    source = context.read(
        _url("members", "house", CONGRESSES[0]), stage="scorecards:agc:catalog", hosts=("agcscorecard.voxara.net",)
    )
    _table(source, "members", "house", CONGRESSES[0])
    return tuple(edition(c) for c in CONGRESSES)


def acquire_scorecard(selected, context):
    if selected.congress not in CONGRESSES or selected != edition(selected.congress):
        raise ScorecardSourceError("AGC selection is outside the qualified aggregate and key-vote-index rendition")
    authority = context.read(INDEX, stage="scorecards:agc:publisher-authority", hosts=("advocacy.agc.org",))
    authority_facts = _authority(authority)
    style = context.read(STYLE, stage="scorecards:agc:name-display", hosts=("agcscorecard.voxara.net",))
    style_rule = _name_display(style)
    documents, facts = {}, {}
    for chamber in ("house", "senate"):
        for kind in ("members", "key-votes"):
            document = context.read(
                _url(kind, chamber, selected.congress),
                stage=f"scorecards:agc:{kind}:{chamber}",
                hosts=("agcscorecard.voxara.net",),
            )
            documents[(kind, chamber)] = document
            facts[(kind, chamber)] = _table(document, kind, chamber, selected.congress)
    bundle = Bundle(
        selected,
        context,
        documents[("members", "house")],
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="Complete native unfiltered House and Senate aggregate tables and key-vote indexes; profiles, item details, individual actions and sponsorship grids are separate renditions",
        homepage=HOMEPAGE,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        edition_label_text=facts[("members", "house")]["period"], source_path="h1", methodology_url=INDEX
    )
    bundle.use(authority, "publisher-authority", "publisher-guide")
    bundle.use(style, "name-display")
    bundle.add(
        "scorecard_methodologies",
        authority,
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(authority_facts),
        methodology_url=INDEX,
        disclosure_status="Native aggregate values and key-vote indexes; individual votes, sponsorships and past profile scores are outside this rendition",
    )
    for chamber in ("house", "senate"):
        members = documents[("members", chamber)]
        items = documents[("key-votes", chamber)]
        bundle.use(members, f"members:{chamber}", f"ratings:{chamber}")
        bundle.use(items, f"items:{chamber}", f"positions:{chamber}")
        bundle.add(
            "scorecard_methodologies",
            items,
            "#myTable",
            methodology_id=key("native-key-vote-index", chamber),
            chamber_text=chamber.title(),
            methodology_text=json_column(facts[("key-votes", chamber)]),
            disclosure_status="Native publisher bill outcomes and item detail URLs; no member action grid or metric weight is stated by the selected index",
        )
        period = facts[("members", chamber)]["period"]
        for column, name in enumerate(facts[("members", chamber)]["headers"][4:], 5):
            metric = key(chamber, name)
            bundle.add(
                "scorecard_metrics",
                members,
                f"#myTable > thead > tr > th:nth-of-type({column})",
                metric_id=metric,
                name=name,
                chamber_text=chamber.title(),
                period_text=period if name == "CURRENT" else name,
                value_unit_text="%",
            )
        for member in facts[("members", chamber)]["rows"]:
            name, party, native_chamber, from_text, current, lifetime = member["values"]
            state, district = from_text.split(" - ")
            member_key = key(chamber, member["id"])
            bundle.add(
                "scorecard_members",
                members,
                member["path"],
                publisher_member_key=member_key,
                publisher_member_id=member["id"],
                member_name=name,
                party=party,
                chamber_text=native_chamber,
                state=state,
                district=district,
                period_text=period,
                identifiers_json=json_column([{"scheme": "agc", "value": member["id"]}]),
                notes_text=json_column(
                    {
                        "native_district_text": from_text,
                        "native_sort_text": member["sort_text"],
                        "profile_url": member["url"],
                    }
                ),
            )
            for column, metric_name, value in ((5, "CURRENT", current), (6, "LIFETIME", lifetime)):
                bundle.add(
                    "scorecard_member_ratings",
                    members,
                    member["path"] + f" > td:nth-of-type({column})",
                    metric_id=key(chamber, metric_name),
                    publisher_member_key=member_key,
                    value_text=value,
                    value_number=decimal_text(value),
                )
        for item in facts[("key-votes", chamber)]["rows"]:
            citation, title, position, _result = item["values"]
            bundle.add(
                "scorecard_items",
                items,
                item["path"],
                item_id=key(chamber, item["identity"]),
                publisher_item_id=item["id"],
                item_kind_text="KEY VOTES",
                title=title,
                chamber_text=chamber.title(),
                congress_text=selected.congress,
                bill_citation_text=citation,
                publisher_position_text=position,
                position_basis="explicit",
                position_source_path=item["path"] + " > td:nth-of-type(3)",
            )
    repeat = context.read(INDEX, stage="scorecards:agc:publisher-authority-reread", hosts=("advocacy.agc.org",))
    if _authority(repeat) != authority_facts:
        raise ScorecardSourceError("AGC publisher designation or source guide changed on reread")
    bundle.use(repeat, "publisher-authority", "publisher-guide", role="corroboration")
    repeat = context.read(STYLE, stage="scorecards:agc:name-display-reread", hosts=("agcscorecard.voxara.net",))
    if _name_display(repeat) != style_rule:
        raise ScorecardSourceError("AGC native name-display rule changed on reread")
    bundle.use(repeat, "name-display", role="corroboration")
    for (kind, chamber), original in facts.items():
        repeat = context.read(
            _url(kind, chamber, selected.congress),
            stage=f"scorecards:agc:{kind}:{chamber}:reread",
            hosts=("agcscorecard.voxara.net",),
        )
        if _table(repeat, kind, chamber, selected.congress) != original:
            raise ScorecardSourceError("AGC complete native membership, ratings or key-vote items changed on reread")
        groups = (
            (f"members:{chamber}", f"ratings:{chamber}")
            if kind == "members"
            else (f"items:{chamber}", f"positions:{chamber}")
        )
        bundle.use(repeat, *groups, role="corroboration")
    return bundle.finish(
        "Complete original publisher-designated unfiltered native House/Senate tables reached closing HTML; each named cohort and item count matches its retained qualification; both chamber tables, congressional labels, native IDs/values and publisher guide agree on reread. Profiles and item details are separate source renditions."
    )
