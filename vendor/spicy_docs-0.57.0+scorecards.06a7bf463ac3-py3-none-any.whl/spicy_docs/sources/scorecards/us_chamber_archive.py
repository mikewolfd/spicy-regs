"""Chamber's complete 2018 publisher JSON, retained through an explicit archive rendition."""

import re
from urllib.parse import parse_qs, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "us-chamber-2018-archived-native-json/2"
ORIGIN = "https://www.uschamber.com"
INDEX = ORIGIN + "/how-they-voted/2018"
SCRIPT_PATH = "/sites/all/modules/custom/htv_vue/js/dist/htv_app.js"
JSON_PATH = "/sites/all/modules/custom/htv_vue/json/2018/"
HOSTS = ("web.archive.org",)
TITLE = "2018 How They Voted Scorecard"
EDITION = ScorecardEdition("us_chamber", "2018", INDEX, TITLE, year="2018", chamber="both", is_current=False)
URLS = {
    "index": "https://web.archive.org/web/20190703155934id_/" + INDEX,
    "renderer": "https://web.archive.org/web/20190703155934id_/" + ORIGIN + SCRIPT_PATH,
    **{
        name: "https://web.archive.org/web/20191107202657id_/" + ORIGIN + JSON_PATH + name + ".json"
        for name in ("house", "senate", "bills/house", "bills/senate")
    },
}
ORIGINALS = {
    "index": INDEX,
    "renderer": ORIGIN + SCRIPT_PATH,
    **{name: ORIGIN + JSON_PATH + name + ".json" for name in ("house", "senate", "bills/house", "bills/senate")},
}
MEMBER_FIELDS = {"first_name", "last_name", "party", "state", "annual", "cumulative", "id", "chamber"}
ITEM_FIELDS = {"roll", "action", "number", "title", "link", "letter_link", "summary"}
TOKENS = {
    "+": '"Correct" vote',
    "-": '"Wrong" vote',
    "p": "Voted Present",
    "?": "No recorded vote",
    "s": "Speaker did not vote",
    "": "Empty native cell; publisher renderer omits it from the member Votes Used table.",
}
VOTE_LEGEND_DECLARATION = (
    "voteLegend: {\n"
    "          '+': ['support', 'Support'],\n"
    "          '-': ['oppose', 'Oppose'],\n"
    "          'p': ['present', 'Voted Present'],\n"
    "          '?': ['novote', 'No Recorded Vote'],\n"
    "          's': ['speaker', 'Speaker']\n"
    "        }"
)
DISPLAY_RULES = (
    "var currentYear = '2018';",
    "$.when($.getJSON(houseData), $.getJSON(senateData), $.getJSON(houseBills), $.getJSON(senateBills))",
    "self.bills[chamber][--bill].title",
    "self.targetBill = self.bills[chamber][--bill];",
    "!isNaN(key) && self.activeMember[key]",
    "Annual Score",
    "Cumulative Score",
    ' = "Wrong" vote',
    ' = "Correct" vote',
    "Speaker did not vote",
)


def _original(document, name):
    match = re.fullmatch(
        r"https://web\.archive\.org/web/(\d{14})id_/(https://www\.uschamber\.com/[^?#]+)", document.url
    )
    if match is None or match[2] != ORIGINALS[name] or document.response.requested_url != URLS[name]:
        raise ScorecardSourceError("Chamber archival capture escaped the selected original publisher route")
    return {"original_publisher_url": match[2], "archive_url": document.url, "archive_timestamp": match[1]}


def _index(document):
    _original(document, "index")
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Chamber archived index is incomplete")
    html = soup(document)
    title = html.select("h1.page-title")
    canonical = html.select("link[rel='canonical']")
    if (
        len(title) != 1
        or title[0].get_text(" ", strip=True) != "How They Voted " + TITLE
        or len(canonical) != 1
        or canonical[0].get("href") != INDEX
        or len(html.select("#htv_app")) != 1
        or SCRIPT_PATH.replace("/", "\\/").removeprefix("\\/") not in document.body.decode("utf-8")
    ):
        raise ScorecardSourceError("Chamber original edition or native application declaration changed")
    return title[0].get_text(" ", strip=True)


def _renderer(document):
    _original(document, "renderer")
    try:
        text = document.body.decode("utf-8")
    except UnicodeError as error:
        raise ScorecardSourceError("Chamber archived renderer is not UTF-8") from error
    declarations = {
        "houseData": "house.json",
        "senateData": "senate.json",
        "houseBills": "bills/house.json",
        "senateBills": "bills/senate.json",
    }
    if (
        VOTE_LEGEND_DECLARATION not in text
        or any(rule not in text for rule in DISPLAY_RULES)
        or any(
            "var " + variable + " = '" + JSON_PATH + suffix + "';" not in text
            for variable, suffix in declarations.items()
        )
    ):
        raise ScorecardSourceError("Chamber native file selection, item mapping or display semantics changed")
    return text


def _items(document, chamber):
    _original(document, "bills/" + chamber)
    rows = json_data(document)
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("Chamber complete native item array is absent")
    seen = set()
    for item in rows:
        if (
            not isinstance(item, dict)
            or set(item) != ITEM_FIELDS
            or type(item["roll"]) is not int
            or item["roll"] < 1
            or any(not isinstance(item[field], str) for field in ITEM_FIELDS - {"roll"})
            or any(not item[field] for field in ITEM_FIELDS - {"roll"})
            or item["roll"] in seen
            or not item["letter_link"].startswith(ORIGIN + "/letter/")
        ):
            raise ScorecardSourceError("Chamber source item identity, shape or reference changed")
        seen.add(item["roll"])
        _roll_context(item, chamber)
        if re.fullmatch(r"(?:H\.\s*R\.|S\.(?:\s*J\.\s*Res\.)?|P\.N\.)\s*\d+", item["number"]) is None:
            raise ScorecardSourceError("Chamber source citation form changed")
    return rows


def _roll_context(item, chamber):
    link = urlsplit(item["link"])
    if chamber == "house":
        match = re.fullmatch(r"/evs/2018/roll(\d{3})\.xml", link.path)
        if link.scheme != "http" or link.netloc != "clerk.house.gov" or link.query or match is None:
            raise ScorecardSourceError("Chamber House item official roll reference changed")
        roll = str(int(match[1]))
        congress = session = None
    else:
        values = parse_qs(link.query)
        if (
            link.scheme != "https"
            or link.netloc != "www.senate.gov"
            or link.path != "/legislative/LIS/roll_call_lists/roll_call_vote_cfm.cfm"
            or set(values) != {"congress", "session", "vote"}
            or values["congress"] != ["115"]
            or values["session"] != ["2"]
            or len(values["vote"]) != 1
            or re.fullmatch(r"\d{5}", values["vote"][0]) is None
        ):
            raise ScorecardSourceError("Chamber Senate item official roll reference changed")
        roll = str(int(values["vote"][0]))
        congress, session = values["congress"][0], values["session"][0]
    if roll != str(item["roll"]):
        raise ScorecardSourceError("Chamber native roll and official reference disagree")
    return congress, session, roll


def _member_key(row):
    # The original file repeats T000469 for Norma Torres and Paul Tonko. Preserve
    # source contexts and the literal ID; do not promote its spelling to Bioguide.
    return key(
        EDITION.scorecard_id,
        row["chamber"],
        row["state"],
        str(row.get("district", "senate")),
        row["first_name"],
        row["last_name"],
    )


def _members(document, chamber, item_count):
    _original(document, chamber)
    rows = json_data(document)
    columns = {str(ordinal) for ordinal in range(1, item_count + 1)}
    expected = MEMBER_FIELDS | columns | ({"district"} if chamber == "house" else set())
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("Chamber complete native member array is absent")
    seen = set()
    for row in rows:
        if (
            not isinstance(row, dict)
            or set(row) != expected
            or any(not isinstance(row[field], str) for field in expected - {"district"})
            or row["chamber"] != chamber
            or not row["first_name"]
            or not row["last_name"]
            or re.fullmatch(r"[A-Z]\d{6}", row["id"]) is None
            or re.fullmatch(r"[A-Z]{2}", row["state"]) is None
            or row["party"] not in {"D", "R", "I"}
            or (chamber == "house" and (type(row["district"]) is not int or row["district"] < 0))
            or any(row[column] not in TOKENS for column in columns)
            or any(re.fullmatch(r"(?:\d+%|n/a|S|)", row[field]) is None for field in ("annual", "cumulative"))
        ):
            raise ScorecardSourceError("Chamber complete member context, score or item grid changed")
        identity = _member_key(row)
        if identity in seen:
            raise ScorecardSourceError("Chamber native member context repeats")
        seen.add(identity)
    return rows


def _position(item):
    # Retain only an explicit source phrase; concerns or encouraging language
    # do not establish a preferred legislative action.
    match = re.search(
        r"(?:The )?U\.S\. Chamber(?: of Commerce)? (?:strongly )?(supports|opposes|urges your support)", item["summary"]
    )
    return match[1] if match else None


def list_scorecards(context: ScorecardContext):
    index = context.read(URLS["index"], stage="chamber-2018-archived-index", hosts=HOSTS)
    _index(index)
    _renderer(context.read(URLS["renderer"], stage="chamber-2018-archived-renderer", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("Chamber archive reader only accepts the qualified native 2018 edition")
    documents = {}
    for name, url in URLS.items():
        document = context.read(url, stage="chamber-2018-" + name, hosts=HOSTS)
        _original(document, name)
        documents[name] = document
    label = _index(documents["index"])
    _renderer(documents["renderer"])
    items = {chamber: _items(documents["bills/" + chamber], chamber) for chamber in ("house", "senate")}
    members = {chamber: _members(documents[chamber], chamber, len(items[chamber])) for chamber in items}
    repeats = {}
    for name, url in URLS.items():
        document = context.read(url, stage="chamber-2018-stable-" + name, hosts=HOSTS)
        _original(document, name)
        if document.body != documents[name].body or document.url != documents[name].url:
            raise ScorecardSourceError("Chamber archived original source changed during acquisition")
        repeats[name] = document
    bundle = Bundle(
        edition,
        context,
        documents["index"],
        publisher_name="U.S. Chamber of Commerce",
        parser_version=parser_version,
        homepage=ORIGIN,
        rendition_rule="explicit archived original index/application and all four native JSON files; original URLs retained; archive custody is recorded; later composite methods are not applied",
    )
    bundle.tables["scorecards"][0].update(edition_label_text=label, methodology_url=ORIGINALS["renderer"])
    for name, document in documents.items():
        bundle.use(document, "native-" + name)
        bundle.use(repeats[name], "native-" + name, role="corroboration")
    custody = {name: _original(document, name) for name, document in documents.items()}
    bundle.add(
        "scorecard_methodologies",
        documents["renderer"],
        "script/native-source-and-display-rules",
        methodology_id="native-display",
        methodology_url=ORIGINALS["renderer"],
        methodology_text=json_column(
            {
                "source_expressions": list(DISPLAY_RULES),
                "symbol_key": TOKENS,
                "source_cell_legend": {
                    "+": "Support",
                    "-": "Oppose",
                    "p": "Voted Present",
                    "?": "No Recorded Vote",
                    "s": "Speaker",
                },
                "source_custody": custody,
                "member_identity_rule": "Exact chamber/state/district/first_name/last_name context. Repeated source IDs remain literal and are not asserted as Bioguide.",
                "score_methodology": "Annual and Cumulative Score values are source literals. The retained renderer does not disclose score weights, exclusions or cumulative formula.",
                "empty_cells": "Native empty strings are retained. The publisher renderer omits them from Votes Used; no action or count eligibility is invented.",
            }
        ),
        disclosure_status="partial",
    )
    for field, name in (("annual", "Annual Score"), ("cumulative", "Cumulative Score")):
        bundle.metric(documents["renderer"], field, name, path="script/" + name, unit="%", primary=field == "annual")
        bundle.tables["scorecard_metrics"][-1].update(
            methodology_id="native-display",
            period_text="2018" if field == "annual" else None,
        )
    result_count = 0
    for chamber, chamber_items in items.items():
        item_document, member_document = documents["bills/" + chamber], documents[chamber]
        item_ids = []
        for offset, item in enumerate(chamber_items):
            path = "/" + str(offset)
            item_id = key(edition.scorecard_id, chamber, "item", str(offset + 1))
            item_ids.append(item_id)
            congress, session, roll = _roll_context(item, chamber)
            nomination = item["number"].startswith("P.N.")
            target = _position(item)
            references = [
                {
                    "occurrence_id": "number",
                    "citation_text": item["number"],
                    "kind": "nomination" if nomination else "bill",
                    "source_path": path + "/number",
                    "bill_citation_text": None if nomination else item["number"],
                },
                {
                    "occurrence_id": "roll-link",
                    "citation_text": item["link"],
                    "kind": "roll_call",
                    "source_path": path + "/link",
                    "chamber_text": chamber,
                    "congress_text": congress,
                    "session_text": session,
                    "roll_number_text": roll,
                },
            ]
            bundle.add(
                "scorecard_items",
                item_document,
                path,
                item_id=item_id,
                publisher_item_id=None,
                item_kind_text=item["action"],
                title=item["title"],
                chamber_text=chamber,
                congress_text=congress,
                session_text=session,
                roll_number_text=str(item["roll"]),
                bill_citation_text=None if nomination else item["number"],
                references_json=json_column(references),
                publisher_position_text=target,
                position_basis="explicit summary phrase" if target else None,
                position_source_path=path + "/summary" if target else None,
            )
            method = key(chamber, "item", str(offset + 1))
            bundle.add(
                "scorecard_methodologies",
                item_document,
                path,
                methodology_id=method,
                chamber_text=chamber,
                methodology_text=json_column(item),
                methodology_url=item["letter_link"],
                disclosure_status="partial",
            )
            bundle.add(
                "scorecard_metric_items",
                item_document,
                path,
                metric_id="annual",
                item_id=item_id,
                participation_id="native-votes-used",
                methodology_id=method,
                publisher_position_text=target,
                position_basis="explicit summary phrase" if target else None,
            )
        for offset, member in enumerate(members[chamber]):
            path = "/" + str(offset)
            member_key = _member_key(member)
            metadata = {field: value for field, value in member.items() if not field.isdigit()}
            bundle.add(
                "scorecard_members",
                member_document,
                path,
                publisher_member_key=member_key,
                publisher_member_id=member["id"],
                identifiers_json="[]",
                member_name=member["first_name"] + " " + member["last_name"],
                chamber_text=chamber,
                state=member["state"],
                district=str(member["district"]) if chamber == "house" else None,
                party=member["party"],
                period_text="2018",
                notes_text=json_column(metadata),
            )
            for field in ("annual", "cumulative"):
                literal = member[field]
                value = "N/A" if literal == "n/a" else literal
                bundle.add(
                    "scorecard_member_ratings",
                    member_document,
                    path + "/" + field,
                    metric_id=field,
                    publisher_member_key=member_key,
                    value_text=value,
                    value_number=decimal_text(value),
                    value_status_text=value if value in {"S", "N/A", ""} else None,
                    notes_text=json_column({"literal_source_value": literal}),
                )
            for ordinal, item_id in enumerate(item_ids, 1):
                result_count += 1
                value = member[str(ordinal)]
                bundle.add(
                    "scorecard_member_item_results",
                    member_document,
                    path + "/" + str(ordinal),
                    result_id="native-cell",
                    metric_id="annual",
                    item_id=item_id,
                    participation_id="native-votes-used",
                    publisher_member_key=member_key,
                    result_text=value,
                    reason_text=TOKENS[value],
                )
    acquired = bundle.finish(
        "Archived publisher index names 2018 and declares native application. Application declares all four full JSON files and one-based item mapping. Every file parses to EOF, all source member columns reconcile to complete chamber item arrays, exact member contexts are unique, official item links reconcile to native rolls, and all six original captures repeat byte-for-byte with unchanged archive custody. Empty cells and duplicate source IDs remain observations.",
        declared={
            "native_file_members": {chamber: len(rows) for chamber, rows in members.items()},
            "native_file_items": {chamber: len(rows) for chamber, rows in items.items()},
            "native_member_item_cells": result_count,
            "explicit_source_population_count": None,
        },
    )
    return acquired
