"""Named historical Chamber HTML grids and literal publisher roll/item declarations."""

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "us-chamber-named-archived-html/1"
ORIGIN = "https://www.uschamber.com"
HOSTS = ("web.archive.org",)
TIMESTAMPS = {
    "2011": {"house": "20161121235551", "senate": "20160204090146"},
    "2012": {"house": "20141026023339", "senate": "20160204090122"},
    "2013": {"house": "20140314072442", "senate": "20160204090055"},
}
PREFIXES = {
    ("2011", "house"): ["Last Name", "First Name", "Party", "State", "District"],
    ("2011", "senate"): ["Last Name", "Party"],
    ("2012", "house"): ["Last Name", "First Name", "Party", "State", "District"],
    ("2012", "senate"): ["Last Name", "First Name", "Party", "State", "District"],
    ("2013", "house"): ["District", "2013 Member of Congress", "Party"],
    ("2013", "senate"): ["LastName", "Party", "State"],
}
SCORE_HEADERS = {"2011": ["%", "Lifetime"], "2012": ["%", "Lifetime"]}
# Literal observed inventory of the named originals, including the Senate typo.
# A missing middle heading could otherwise assign rows to the preceding state.
STATE_HEADINGS = (
    "ALABAMA",
    "ALASKA",
    "ARIZONA",
    "ARKANSAS",
    "CALIFORNIA",
    "COLORADO",
    "CONNECTICUT",
    "DELAWARE",
    "FLORIDA",
    "GEORGIA",
    "HAWAII",
    "IDAHO",
    "ILLINOIS",
    "INDIANA",
    "IOWA",
    "KANSAS",
    "KENTUCKY",
    "LOUISIANA",
    "MAINE",
    "MARYLAND",
    "MASSACHUSETTS",
    "MICHIGAN",
    "MINNESOTA",
    "MISSISSIPPI",
    "MISSOURI",
    "MONTANA",
    "NEBRASKA",
    "NEVADA",
    "NEW HAMPSHIRE",
    "NEW JERSEY",
    "NEW MEXICO",
    "NEW YORK",
    "NORTH CAROLINA",
    "NORTH DAKOTA",
    "OHIO",
    "OKLAHOMA",
    "OREGON",
    "PENNSYLVANIA",
    "RHODE ISLAND",
    "SOUTH CAROLINA",
    "SOUTH DAKOTA",
    "TENNESSEE",
    "TEXAS",
    "UTAH",
    "VERMONT",
    "VIRGINIA",
    "WASHINGTON",
    "WEST VIRGINIA",
    "WISCONSIN",
    "WYOMING",
)
TOKENS = {
    "+": '"Correct" vote, supporting the Chamber\'s position',
    "-": '"Wrong" vote, contrary to the Chamber\'s position',
    "?": "No recorded vote",
    "": "Blank source cell; its scoring eligibility is not disclosed.",
    "S": "Literal S token; this rendition's Key to Symbols does not disclose its meaning.",
    "P": "Literal P token; this rendition's Key to Symbols does not disclose its meaning.",
}
ROLL = re.compile(r"(\d+)\. (\d{3})-([12])-([HS])-RC(\d+)\s+(.+)")
CITATION = re.compile(
    r"(?:H\s*\.?\s*(?:R|Con\.?\s*Res|J\.?\s*Res|Res)\s*\.?|S\s*\.?\s*(?:Amdt\.?|J\.?\s*Res\.?|Con\.?\s*Res\.?|Res\.?)?)\s*\d+|PN\s*\d+"
)


def original(year, chamber):
    return ORIGIN + "/how-they-voted-" + year + "-" + chamber


def source_url(year, chamber):
    return "https://web.archive.org/web/" + TIMESTAMPS[year][chamber] + "id_/" + original(year, chamber)


def edition(year):
    return ScorecardEdition(
        "us_chamber",
        year,
        original(year, "house"),
        "How They Voted " + year,
        year=year,
        chamber="both",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return tuple(edition(year) for year in sorted(TIMESTAMPS, reverse=True))


def _one(element, selector):
    result = element.select(selector)
    if len(result) != 1:
        raise ScorecardSourceError("Chamber archived HTML source structure is missing or repeated: " + selector)
    return result[0]


def _page(document, year, chamber):
    custody = re.fullmatch(
        r"https://web\.archive\.org/web/(\d{14})id_/(https://www\.uschamber\.com/[^?#]+)", document.url
    )
    if (
        custody is None
        or custody[2] != original(year, chamber)
        or document.response.requested_url != source_url(year, chamber)
    ):
        raise ScorecardSourceError("Chamber archived HTML capture escaped its selected original route")
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Chamber archived HTML document is incomplete")
    html = soup(document)
    if _one(html, "link[rel='canonical']").get("href") != original(year, chamber):
        raise ScorecardSourceError("Chamber archived HTML original canonical identity changed")
    title = "How They Voted " + year + " - " + chamber.title()
    if title not in [h.get_text(" ", strip=True) for h in html.select("h1")]:
        raise ScorecardSourceError("Chamber archived HTML edition/chamber heading changed")
    body = _one(html, ".field-name-body .field-item")
    table = _one(body, "table")
    paragraphs = body.find_all("p", recursive=False)
    prelude = [p.get_text(" ", strip=True) for p in paragraphs[:5]]
    if (
        len(prelude) != 5
        or not prelude[0].startswith("Each " + chamber.title() + " vote used in the ratings is described separately")
        or prelude[1:] != ["Key to Symbols", *[symbol + " " + TOKENS[symbol] for symbol in ("+", "-", "?")]]
    ):
        raise ScorecardSourceError("Chamber archived grid source attribution or literal legend changed")
    if body.select("select, input, [class*='pager'], [class*='pagination']"):
        raise ScorecardSourceError("Chamber archived grid exposes an unreviewed source filter or page")
    rows = table.select("tr")
    if not rows:
        raise ScorecardSourceError("Chamber full archived member grid is empty")
    cells = rows[0].find_all("td", recursive=False)
    prefix = PREFIXES[(year, chamber)]
    headings = [c.get_text(" ", strip=True) for c in cells]
    score_headers = SCORE_HEADERS.get(year, ["2013%" if chamber == "house" else "2013 %", "Cum %"])
    numbers = headings[len(prefix) : -2]
    if (
        headings[: len(prefix)] != prefix
        or headings[-2:] != score_headers
        or numbers != [str(n) for n in range(1, len(numbers) + 1)]
        or not numbers
    ):
        raise ScorecardSourceError("Chamber archived source grid columns changed")
    expected_href = {"2011": "#bottom", "2012": "#bills"}.get(year)
    for number, cell in zip(numbers, cells[len(prefix) : -2], strict=True):
        anchors = cell.select("a")
        if len(anchors) != 1 or anchors[0].get("href") != (expected_href or "#" + number):
            raise ScorecardSourceError("Chamber source column-to-item link changed")
    item_paragraphs = [p for p in paragraphs[5:] if re.match(r"1\. \d{3}-[12]-[HS]-RC", p.get_text(" ", strip=True))]
    if len(item_paragraphs) != 1:
        raise ScorecardSourceError("Chamber complete original item declaration is missing or repeated")
    item_paragraph = item_paragraphs[0]
    descriptions = item_paragraph.get_text("\n", strip=True).splitlines()
    items = []
    for description in descriptions:
        match = ROLL.fullmatch(description)
        if match is None or match[4] != {"house": "H", "senate": "S"}[chamber]:
            raise ScorecardSourceError("Chamber source item Congress/session/roll declaration changed")
        position = re.search(r" Position: ([YN])$", description)
        if (year in {"2011", "2012"}) != (position is not None):
            raise ScorecardSourceError("Chamber explicit target position disclosure changed")
        items.append(
            {
                "number": match[1],
                "congress": match[2],
                "session": match[3],
                "roll": match[5],
                "title": match[6],
                "description": description,
                "position": position[1] if position else None,
            }
        )
    if [item["number"] for item in items] != numbers or len({item["roll"] for item in items}) != len(items):
        raise ScorecardSourceError("Chamber item inventory does not reconcile with all source grid columns")
    if year == "2013" and [a.get("id") for a in item_paragraph.select("a[id]")] != numbers:
        raise ScorecardSourceError("Chamber literal item anchors disagree with their source columns")
    members = []
    states = []
    state = None
    seen = set()
    for ordinal, row in enumerate(rows[1:], 2):
        cells = row.find_all("td", recursive=False)
        values = [c.get_text(" ", strip=True) for c in cells]
        filled = [v for v in values if v]
        if len(filled) == 1 and filled[0].isupper():
            state = filled[0]
            states.append(state)
            if sum(int(c.get("colspan", "1")) for c in cells) != len(headings):
                raise ScorecardSourceError("Chamber state heading spans do not reconcile with the grid")
            continue
        if state is None or len(cells) != len(headings) or any(c.get("colspan") or c.get("rowspan") for c in cells):
            raise ScorecardSourceError("Chamber source member row lacks its complete state/grid context")
        metadata = dict(zip(prefix, values[: len(prefix)], strict=True))
        last = metadata.get("Last Name", metadata.get("LastName", metadata.get("2013 Member of Congress")))
        first = metadata.get("First Name")
        party = metadata["Party"]
        district = metadata.get("District")
        state_code = metadata.get("State")
        name = (last + ", " + first) if first else last
        if (
            not last
            or not name
            or party not in {"R", "D", "I"}
            or (district is not None and not re.fullmatch(r"\d+|AL", district))
            or (state_code is not None and not re.fullmatch(r"[A-Z]{2}", state_code))
        ):
            raise ScorecardSourceError("Chamber literal member name, party, state or district shape changed")
        member_key = key(chamber, state_code or state, district or "no-district", name)
        if member_key in seen:
            raise ScorecardSourceError("Chamber historical source member context is repeated")
        seen.add(member_key)
        outcomes = values[len(prefix) : -2]
        scores = values[-2:]
        if any(outcome not in TOKENS for outcome in outcomes) or any(
            decimal_text(score) is None and score not in {"", "n/a", "NA", "N/A"} for score in scores
        ):
            raise ScorecardSourceError("Chamber literal grid outcome or rating shape changed")
        members.append(
            {
                "key": member_key,
                "name": name,
                "state": state_code or state,
                "state_heading": state,
                "district": district,
                "party": party,
                "metadata": metadata,
                "outcomes": outcomes,
                "scores": scores,
                "row": str(ordinal),
            }
        )
    expected_states = ["MINNESTOA" if chamber == "senate" and s == "MINNESOTA" else s for s in STATE_HEADINGS]
    if not members or states != expected_states:
        raise ScorecardSourceError("Chamber complete historical state/member inventory is missing")
    return {
        "title": title,
        "prelude": prelude,
        "headings": headings,
        "score_headers": score_headers,
        "states": states,
        "members": members,
        "items": items,
        "item_paragraph_html": str(item_paragraph),
        "custody": {"original_publisher_url": custody[2], "archive_url": document.url, "archive_timestamp": custody[1]},
    }


def _references(item, chamber, path):
    refs = [
        {
            "occurrence_id": "source-roll",
            "citation_text": item["congress"] + "-" + item["session"] + "-" + chamber[0].upper() + "-RC" + item["roll"],
            "kind": "roll_call",
            "congress_text": item["congress"],
            "session_text": item["session"],
            "chamber_text": chamber.title(),
            "roll_number_text": item["roll"],
            "source_path": path,
        }
    ]
    for match in CITATION.finditer(item["title"]):
        citation = match[0]
        kind = "nomination" if citation.startswith("PN") else "amendment" if "Amdt" in citation else "bill"
        ref = {
            "occurrence_id": key("title", str(match.start())),
            "citation_text": citation,
            "kind": kind,
            "congress_text": item["congress"],
            "source_path": path,
        }
        if kind == "amendment":
            ref["amendment_citation_text"] = citation
        elif kind == "bill":
            ref["bill_citation_text"] = citation
        refs.append(ref)
    return refs


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    year = selected.edition_id
    if year not in TIMESTAMPS or selected != edition(year):
        raise ScorecardSourceError("Chamber caller selection is outside the named historical HTML editions")
    documents = {}
    pages = {}
    for chamber in ("house", "senate"):
        documents[chamber] = context.read(source_url(year, chamber), stage="us-chamber-html:" + chamber, hosts=HOSTS)
        pages[chamber] = _page(documents[chamber], year, chamber)
    repeats = {}
    for chamber in ("house", "senate"):
        repeats[chamber] = context.read(
            source_url(year, chamber), stage="us-chamber-html:" + chamber + "-repeat", hosts=HOSTS
        )
        repeated = _page(repeats[chamber], year, chamber)
        if {k: v for k, v in repeated.items() if k != "custody"} != {
            k: v for k, v in pages[chamber].items() if k != "custody"
        }:
            raise ScorecardSourceError("Chamber complete historical native grid changed on reread")
    primary = documents["house"]
    bundle = Bundle(
        selected,
        context,
        primary,
        publisher_name="U.S. Chamber of Commerce",
        parser_version=parser_version,
        rendition_rule="Named original archived HTML chamber grids; complete literal member ratings and item results, with original source custody retained.",
        homepage=ORIGIN,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = ORIGIN + "/how-they-voted"
    all_congresses = {item["congress"] for page in pages.values() for item in page["items"]}
    if len(all_congresses) != 1:
        raise ScorecardSourceError("Chamber source item Congress declarations disagree across the edition")
    congress = next(iter(all_congresses))
    bundle.tables["scorecards"][0].update(
        congress_text=congress,
        edition_label_text=selected.title,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "edition-year",
                    "period_text": year,
                    "kind": "explicit",
                    "year_text": year,
                    "source_path": "h1",
                }
            ]
        ),
    )
    for chamber, page in pages.items():
        document = documents[chamber]
        bundle.use(document, chamber + "-grid")
        bundle.use(repeats[chamber], chamber + "-grid", role="corroboration")
        path = ".field-name-body .field-item"
        method_id = key(chamber, "native-grid")
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=method_id,
            methodology_url=original(year, chamber),
            chamber_text=chamber.title(),
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_title": page["title"],
                    "literal_prelude": page["prelude"],
                    "literal_grid_headers": page["headings"],
                    "literal_state_headings": page["states"],
                    "source_custody": page["custody"],
                    "literal_item_declaration_html": page["item_paragraph_html"],
                    "observations": "Ratings preserve literal year and cumulative/lifetime headers. No universal score formula, item weight, member eligibility or exact metric participation is inferred. S/P and blank cell meanings are not disclosed in this rendition's legend. Source-labelled Senate District values are preserved, without assigning House district semantics.",
                }
            ),
        )
        for offset, header in enumerate(page["score_headers"]):
            bundle.metric(
                document,
                key(chamber, "year" if offset == 0 else "cumulative"),
                header,
                path=path + " table tr:first-child",
                chamber=chamber.title(),
                unit="%" if "%" in header else None,
                primary=offset == 0,
            )
            metric = bundle.tables["scorecard_metrics"][-1]
            metric.update(methodology_id=method_id, period_text=year if offset == 0 else None, periods_json="[]")
        for item in page["items"]:
            item_id = key(chamber, item["number"])
            item_path = path + "/item-declaration/" + item["number"]
            refs = _references(item, chamber, item_path)
            bundle.add(
                "scorecard_items",
                document,
                item_path,
                item_id=item_id,
                publisher_item_id=item["number"],
                item_kind_text="roll_call",
                title=item["title"],
                congress_text=item["congress"],
                chamber_text=chamber.title(),
                session_text=item["session"],
                roll_number_text=item["roll"],
                bill_citation_text=next((r["bill_citation_text"] for r in refs if r["kind"] == "bill"), None),
                amendment_citation_text=next(
                    (r["amendment_citation_text"] for r in refs if r["kind"] == "amendment"), None
                ),
                references_json=json_column(refs),
                publisher_position_text=item["position"],
                position_basis="explicit" if item["position"] else None,
                position_source_path=item_path + "/Position" if item["position"] else None,
            )
        for member in page["members"]:
            row_path = path + " table tr:nth-child(" + member["row"] + ")"
            bundle.add(
                "scorecard_members",
                document,
                row_path,
                publisher_member_key=member["key"],
                identifiers_json="[]",
                member_name=member["name"],
                chamber_text=chamber.title(),
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text=year,
                notes_text=json_column(
                    {
                        "literal_source_fields": member["metadata"],
                        "literal_state_heading": member["state_heading"],
                        "name_rule": "Literal source surname plus source first name when separately supplied; no official identity is inferred.",
                    }
                ),
            )
            for offset, literal in enumerate(member["scores"]):
                value = "N/A" if literal in {"n/a", "NA", "N/A"} else literal
                bundle.add(
                    "scorecard_member_ratings",
                    document,
                    row_path + "/rating/" + str(offset + 1),
                    metric_id=key(chamber, "year" if offset == 0 else "cumulative"),
                    publisher_member_key=member["key"],
                    value_text=value,
                    value_number=decimal_text(value),
                    value_status_text=value if value in {"", "N/A"} else None,
                    notes_text=json_column(
                        {"literal_source_value": literal, "literal_source_column": page["score_headers"][offset]}
                    ),
                )
            for item, outcome in zip(page["items"], member["outcomes"], strict=True):
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    row_path + "/item/" + item["number"],
                    item_id=key(chamber, item["number"]),
                    publisher_member_key=member["key"],
                    result_id="native-grid",
                    result_text=outcome,
                    reason_text=TOKENS[outcome],
                )
    acquired = bundle.finish(
        "Both selected original archived chamber HTML documents reached their final trailer. Complete table columns reconcile with every numbered item declaration, every member row has all rating/item cells and explicit state context, and complete native rows/legend/headers/item declarations agree on reread. No absent member, action or rating is fabricated.",
        declared={
            "publisher_declared_counts": None,
            "observed_complete_html_chambers": {
                ch: {"members": len(p["members"]), "state_headings": len(p["states"]), "items": len(p["items"])}
                for ch, p in pages.items()
            },
        },
    )
    return acquired
