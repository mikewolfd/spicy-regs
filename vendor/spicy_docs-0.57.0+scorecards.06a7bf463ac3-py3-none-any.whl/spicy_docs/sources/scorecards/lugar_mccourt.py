"""Lugar Center/McCourt's original embedded HTML Bipartisan Index rankings."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass

from bs4 import BeautifulSoup

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key

parser_version = "lugar-mccourt-native-html/1"
INDEX = "https://www.thelugarcenter.org/ourwork-Bipartisan-Index.html"
HOSTS = ("www.thelugarcenter.org",)


@dataclass(frozen=True, slots=True)
class Scope:
    tab: int
    table: int
    period: str
    chamber: str
    count: int
    congress: str | None
    year: str | None = None

    @property
    def edition(self):
        label = "lifetime-103-115" if self.tab == 12 else self.year or self.congress
        return ScorecardEdition(
            "lugar_mccourt",
            f"{label}-{self.chamber.lower()}-html",
            INDEX,
            f"Bipartisan Index {self.chamber} Scores — {self.period}",
            year=self.year,
            congress=self.congress,
            chamber=self.chamber,
            is_current=False,
        )


# Reviewed original table populations, not official congressional roster sizes.
# A changed population needs a fresh source review, so a cut table cannot replace prior rows.
SCOPES = (
    Scope(2, 0, "118th Congress First Session (2023)", "House", 436, "118", "2023"),
    Scope(3, 0, "118th Congress First Session (2023)", "Senate", 98, "118", "2023"),
    Scope(4, 0, "117th Congress (2021-2022)", "Senate", 98, "117"),
    Scope(5, 0, "117th Congress (2021-2022)", "House", 441, "117"),
    Scope(6, 0, "117th Congress First Session (2021)", "Senate", 98, "117", "2021"),
    Scope(7, 0, "117th Congress First Session (2021)", "House", 435, "117", "2021"),
    Scope(8, 0, "116th Congress (2019-2020)", "Senate", 99, "116"),
    Scope(9, 0, "116th Congress (2019-2020)", "House", 437, "116"),
    Scope(10, 0, "116th Congress First Session (2019)", "Senate", 98, "116", "2019"),
    Scope(11, 0, "116th Congress First Session (2019)", "House", 437, "116", "2019"),
    Scope(12, 0, "103rd - 115th Congresses (1993-2018)", "Senate", 250, None),
    Scope(13, 0, "115th Congress (2017-2018)", "Senate", 100, "115"),
    Scope(14, 0, "115th Congress (2017-2018)", "House", 436, "115"),
    Scope(15, 0, "115th Congress First Session (2017)", "Senate", 98, "115", "2017"),
    Scope(16, 0, "115th Congress First Session (2017)", "House", 438, "115", "2017"),
    Scope(17, 0, "114th Congress (2015-2016)", "Senate", 98, "114"),
    Scope(18, 0, "114th Congress (2015-2016)", "House", 427, "114"),
    Scope(19, 0, "114th Congress First Session (2015)", "Senate", 98, "114", "2015"),
    Scope(20, 0, "114th Congress First Session (2015)", "House", 438, "114", "2015"),
    Scope(21, 0, "113th Congress", "Senate", 98, "113"),
    Scope(22, 0, "113th Congress", "House", 422, "113"),
    *(
        Scope(
            23,
            112 - congress,
            f"{congress}{'rd' if congress == 103 else 'th'} Congress",
            "Senate",
            99 if congress in {109, 110} else 98,
            str(congress),
        )
        for congress in range(112, 102, -1)
    ),
)


def _text(tag):
    return " ".join(tag.get_text(" ", strip=True).split())


def _page(document):
    try:
        soup = BeautifulSoup(document.body.decode("utf-8"), "html.parser")
        if soup.title is None or "The Lugar Center" not in _text(soup.title):
            raise ValueError
        groups = soup.select('#tabGroups > div[id$="-group"]')
        # The observed index is an embedded full archive, not a paginated result list.
        if not groups:
            groups = soup.select('div[id^="tab"][id$="-group"]')
        ids = [g.get("id") for g in groups]
        if len(ids) != len(set(ids)) or not {f"tab{i}-group" for i in range(1, 32)} <= set(ids):
            raise ValueError
        for n, marker in (
            (29, "Overview of The Lugar Center-McCourt School Bipartisan Index"),
            (30, "The Bipartisan Index - Frequently Asked Questions"),
        ):
            if marker not in _text(soup.select_one(f"#tab{n}-group")):
                raise ValueError
        return soup
    except (UnicodeError, ValueError, AttributeError):
        raise ScorecardSourceError(
            "Lugar/McCourt original index is missing its complete reviewed archive shape"
        ) from None


def _table(table, *, lifetime):
    rows = []
    for tr in table.find_all("tr"):
        cells = tr.find_all(["td", "th"], recursive=False)
        if not cells:
            raise ScorecardSourceError("Lugar/McCourt table has an empty source row")
        rows.append([{"text": _text(c), "native_sheet_value": c.get("data-sheets-value")} for c in cells])
    expected = (
        ["#", "Name", "State", "Party", "Congresses", "Score"]
        if lifetime
        else ["#", "Name", "State", "Party", "Score", "", "#", "Name", "State", "Party", "Score"]
    )
    heads = [i for i, row in enumerate(rows) if [c["text"] for c in row] == expected]
    if len(heads) != 1:
        raise ScorecardSourceError("Lugar/McCourt rating columns drifted")
    data = rows[heads[0] + 1 :]
    if not data:
        raise ScorecardSourceError("Lugar/McCourt cannot establish an empty ranking")
    for row in data:
        if len(row) != (7 if lifetime else 13):
            raise ScorecardSourceError("Lugar/McCourt source row width changed")
        for side in (row,) if lifetime else (row[:6], row[7:]):
            values = [c["text"] for c in side]
            if (
                not values[0].isdigit()
                or not values[1]
                or not values[2]
                or re.fullmatch(r"[A-Z]{2}", values[3]) is None
                or not values[4]
                or decimal_text(values[-1]) is None
            ):
                raise ScorecardSourceError("Lugar/McCourt source rating is malformed")
        if not lifetime and row[6]["text"]:
            raise ScorecardSourceError("Lugar/McCourt table separator contains unknown source data")
    return heads[0] + 1, data


def _scope(soup, scope):
    group = soup.select_one(f"#tab{scope.tab}-group")
    if scope.period not in _text(group):
        raise ScorecardSourceError("Lugar/McCourt edition period changed")
    tables = [t for t in group.select("table") if "Name" in _text(t) and "Score" in _text(t)]
    expected = 10 if scope.tab == 23 else 2 if scope.tab == 12 else 1
    if len(tables) != expected:
        raise ScorecardSourceError("Lugar/McCourt score-table membership changed")
    lifetime = scope.tab == 12
    offset, rows = _table(tables[scope.table], lifetime=lifetime)
    if len(rows) != scope.count:
        raise ScorecardSourceError("Lugar/McCourt ranking population differs from its reviewed complete source")
    alternate = _table(tables[1], lifetime=True)[1] if lifetime else [r[7:] for r in rows]
    if len(alternate) != scope.count:
        raise ScorecardSourceError("Lugar/McCourt alphabetical listing is incomplete")
    if scope.tab == 23:
        heading = tables[scope.table].find_previous("h2")
        if _text(heading) != scope.period:
            raise ScorecardSourceError("Lugar/McCourt historical table order changed")
    primary = rows if lifetime else [r[:6] for r in rows]
    identities = [tuple(c["text"] for c in row[1:5]) for row in primary]
    if len(identities) != len(set(identities)):
        raise ScorecardSourceError("Lugar/McCourt contains duplicate native member contexts")
    # Preserve notes/exclusions, all original cell attributes and the alternate view.
    copy = BeautifulSoup(str(group), "html.parser")
    for t in copy.select("table"):
        if "Name" in _text(t) and "Score" in _text(t):
            t.decompose()
    return {
        "rows": primary,
        "alternate": alternate,
        "offset": offset,
        "edition_notes": _text(copy),
        "methodology": _text(soup.select_one("#tab29-group")),
        "faq": _text(soup.select_one("#tab30-group")),
    }


def list_scorecards(context):
    source = context.read(INDEX, stage="scorecards:lugar_mccourt:listing", hosts=HOSTS)
    soup = _page(source)
    for scope in SCOPES:
        _scope(soup, scope)
    return tuple(s.edition for s in SCOPES)


def acquire_scorecard(edition, context):
    candidates = [s for s in SCOPES if s.edition == edition]
    if len(candidates) != 1:
        raise ScorecardSourceError("Lugar/McCourt edition is outside the reviewed native archive")
    scope = candidates[0]
    source = context.read(INDEX, stage="scorecards:lugar_mccourt:rankings", hosts=HOSTS)
    facts = _scope(_page(source), scope)
    end = context.read(INDEX, stage="scorecards:lugar_mccourt:rankings-end", hosts=HOSTS)
    if facts != _scope(_page(end), scope):
        raise ScorecardSourceError("Lugar/McCourt selected rankings or methodology changed during capture")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="The Lugar Center and Georgetown University McCourt School of Public Policy",
        parser_version=parser_version,
        rendition_rule="lugar-mccourt-original-html-by-score-with-alphabetical-preserved/1",
        homepage="https://www.thelugarcenter.org/",
    )
    bundle.use(source, "members_and_scores", "methodology")
    bundle.use(end, "members_and_scores", "methodology", role="corroboration")
    path = f"html:#tab{scope.tab}-group/score-table[{scope.table}]"
    card = bundle.tables["scorecards"][0]
    card.update(
        timespan_text=scope.period,
        methodology_url="https://www.thelugarcenter.org/ourwork-44.html",
        session_text="First Session" if scope.year else None,
        periods_json=json.dumps(
            [{"occurrence_id": "edition", "kind": "explicit", "period_text": scope.period, "source_path": path}]
        ),
    )
    bundle.metric(source, "bipartisan-index", "Bipartisan Index", path=path, chamber=scope.chamber)
    for identifier, text in (
        ("methodology", facts["methodology"]),
        ("faq", facts["faq"]),
        ("edition-notes", facts["edition_notes"]),
        ("alphabetical-view", json.dumps(facts["alternate"], ensure_ascii=False)),
    ):
        bundle.add(
            "scorecard_methodologies",
            source,
            f"{path}/{identifier}",
            methodology_id=identifier,
            methodology_text=text,
            methodology_url=source.url,
            disclosure_status="Original alphabetical view; source conflicts retained"
            if identifier == "alphabetical-view"
            else None,
        )
    for i, row in enumerate(facts["rows"]):
        native = [c["text"] for c in row]
        member = key(scope.chamber, *native[1:5])
        locator = f"{path}/tr[{i + facts['offset']}]"
        bundle.add(
            "scorecard_members",
            source,
            locator,
            publisher_member_key=member,
            member_name=" ".join(native[1:3]),
            state=native[3],
            party=native[4],
            chamber_text=scope.chamber,
            identifiers_json="[]",
            notes_text=json.dumps({"native_cells": row}, ensure_ascii=False),
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            locator,
            metric_id="bipartisan-index",
            publisher_member_key=member,
            value_text=native[-1],
            value_number=decimal_text(native[-1]),
            rank_text=native[0],
            notes_text=json.dumps({"Congresses": native[5]} if scope.tab == 12 else {}, ensure_ascii=False),
        )
    return bundle.finish(
        "Every reviewed source table row parsed to EOF; exact native population, column shape and unique member contexts checked; independent alphabetical view retained; selected source facts and method stable on reread"
    )
