"""The separate FreedomWorks WordPress House and Senate tables, retaining mixed native periods."""

from __future__ import annotations

import json
import re
from collections import Counter

from bs4 import BeautifulSoup

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.freedomworks import citation_occurrences, citation_reference

# /4 shares the print reader's bill and amendment grammar and leaves the
# unstated primary-metric designation NULL; /3 remains a private candidate.
parser_version = "freedomworks-wordpress-native-table/4"
ORIGINAL = "https://www.freedomworks.org/senate-scorecard/"
ARCHIVE = "https://web.archive.org/web/20240509063510id_/" + ORIGINAL
HOSTS = ("web.archive.org",)
EDITION = ScorecardEdition(
    "freedomworks",
    "senate-wordpress-mixed-periods-archived-table",
    ARCHIVE,
    "Senate Scorecard",
    congress="117",
    chamber="Senate",
    is_current=False,
)
HOUSE_ORIGINAL = "https://www.freedomworks.org/house-scorecard/"
HOUSE_ARCHIVE = "https://web.archive.org/web/20240509063156id_/" + HOUSE_ORIGINAL
HOUSE_EDITION = ScorecardEdition(
    "freedomworks",
    "house-wordpress-native-periods-archived-table",
    HOUSE_ARCHIVE,
    "House Scorecard",
    congress="117",
    chamber="House",
    is_current=False,
)
EDITIONS = (EDITION, HOUSE_EDITION)
REVIEWED_COUNTS = {"Senate": (99, 10), "House": (444, 9)}
NATIVE_ROLES = {"Senate": {"Senator"}, "House": {"US Representative", "US Resident Commissioner", "US Delegate"}}
PARTIES = {"gop": "Republican", "dem": "Democrat", "ind": "Independent"}


def _text(tag):
    return " ".join(tag.get_text(" ", strip=True).split())


def _facts(document, edition):
    chamber = edition.chamber
    member_rows, item_columns = REVIEWED_COUNTS[chamber]
    try:
        soup = BeautifulSoup(document.body.decode("utf-8"), "html.parser")
        heading = soup.select_one(".overview-heading")
        if heading is None or _text(heading.select_one(".page-lead")) != "117th Congress":
            raise ValueError
        if _text(heading.select_one(".top-line")) != chamber or soup.select_one("footer.site-footer") is None:
            raise ValueError
        feeds = soup.select("section.legislator-vote-feed")
        if len(feeds) != 1 or _text(feeds[0].select_one(".feed-title")) != f"{chamber} Key Votes":
            raise ValueError
        feed = feeds[0]
        for name in ("state", "party"):
            selected = feed.select(f"select[name='{name}'] option[selected]")
            if any(option.get("value") != "0" for option in selected):
                raise ValueError
        searches = feed.select("input[name='search']")
        if len(searches) != 1 or searches[0].get("value") not in {None, ""}:
            raise ValueError
        party_options = {str(x["value"]): _text(x) for x in feed.select("#party-filter option") if x["value"] != "0"}
        if party_options != PARTIES:
            raise ValueError
        tables = feed.select("table")
        if len(tables) != 1 or tables[0].get("id") != "vote-table":
            raise ValueError
        columns = [_text(x) for x in tables[0].select("thead th")]
        if len(columns) != item_columns + 1 or columns[0] != "Official" or any(not t for t in columns):
            raise ValueError
        rows = tables[0].select("tbody > tr")
        if len(rows) != member_rows:
            raise ValueError
        members = []
        for ordinal, row in enumerate(rows):
            cells = row.find_all("td", recursive=False)
            if len(cells) != len(columns):
                raise ValueError
            cards = cells[0].select("article.legislator-card")
            if len(cards) != 1:
                raise ValueError
            card = cards[0]
            ident = card.get("id")
            link, meta = card.select_one(".card-name a[href]"), card.select(".card-meta .meta-item")
            if not isinstance(ident, str) or not ident.isdecimal() or link is None or len(meta) != 2:
                raise ValueError
            if link.get("href") != f"/scorecard/legislator/{ident}/" or _text(meta[0]) not in NATIVE_ROLES[chamber]:
                raise ValueError
            card_classes = card.get("class")
            if not isinstance(card_classes, list):
                raise TypeError
            party_keys = [p for p in PARTIES if p + "-card" in card_classes]
            district_pattern = r"[A-Z]{2}" if chamber == "Senate" else r"[A-Z]{2}-\d+"
            if len(party_keys) != 1 or re.fullmatch(district_pattern, _text(meta[1])) is None:
                raise ValueError
            scores = []
            for score_index, score in enumerate(card.select(".card-scores > .card-score")):
                title, value = score.select_one(".score-title"), score.select_one("strong")
                if title is None or value is None:
                    raise ValueError
                literal = _text(value)
                if literal not in {"NA", "N/A"} and re.fullmatch(r"\d+(?:\.\d+)?%", literal) is None:
                    raise ValueError
                observation = {"title": _text(title), "value": literal, "classes": score.get("class")}
                tooltips = score.select(".score-tooltiptext")
                if tooltips:
                    observation["tooltip_occurrences"] = [
                        {
                            "text": _text(tooltip),
                            "source_path": f"html:#vote-table/tbody/tr[{ordinal}]/.card-scores/li[{score_index}]/.score-tooltiptext[{index}]",
                        }
                        for index, tooltip in enumerate(tooltips)
                    ]
                scores.append(observation)
            if [r["title"] for r in scores] != ["Lifetime Score", "Session Score"]:
                raise ValueError
            actions = []
            for column, cell in enumerate(cells[1:], 1):
                title, result = cell.select_one(".bill-title"), cell.select_one(".bill-vote")
                if title is None or _text(title) != columns[column] or result is None:
                    raise ValueError
                value = _text(result)
                if value not in {"Voted Against Freedom", "Voted For Freedom"}:
                    raise ValueError
                expected = "yes-vote" if value == "Voted For Freedom" else "no-vote"
                result_classes = result.get("class")
                if not isinstance(result_classes, list) or expected not in result_classes:
                    raise ValueError
                actions.append(
                    {"column": column, "title": _text(title), "result": value, "classes": result.get("class")}
                )
            member = {
                "id": ident,
                "name": _text(link),
                "href": link.get("href"),
                "role": _text(meta[0]),
                "state": _text(meta[1]).split("-", 1)[0],
                "party_key": party_keys[0],
                "party": party_options[party_keys[0]],
                "ordinal": ordinal,
                "classes": card.get("class"),
                "scores": scores,
                "actions": actions,
            }
            if chamber == "House":
                member.update(district=_text(meta[1]).split("-", 1)[1], district_text=_text(meta[1]))
            members.append(member)
        if len({m["id"] for m in members}) != member_rows:
            raise ValueError
        years = [{"value": x.get("value"), "text": _text(x)} for x in soup.select("#year-dropdown option")]
        if years != [{"value": str(y), "text": str(y)} for y in range(2022, 2012, -1)]:
            raise ValueError
        return {
            "members": members,
            "columns": columns,
            "heading": _text(heading),
            "year_options": years,
            "party_options": party_options,
            "document_title": _text(soup.title),
        }
    except (ValueError, TypeError, AttributeError, KeyError) as error:
        raise ScorecardSourceError("FreedomWorks WordPress native table is incomplete or changed shape") from error


def list_scorecards(context):
    for edition in EDITIONS:
        source = context.read(edition.source_url, stage="scorecards:freedomworks_wordpress:index", hosts=HOSTS)
        _facts(source, edition)
    return EDITIONS


def acquire_scorecard(edition, context):
    if edition not in EDITIONS:
        raise ScorecardSourceError("FreedomWorks WordPress edition has not been qualified")
    chamber = edition.chamber
    original = ORIGINAL if chamber == "Senate" else HOUSE_ORIGINAL
    source = context.read(edition.source_url, stage="scorecards:freedomworks_wordpress:edition", hosts=HOSTS)
    facts = _facts(source, edition)
    end = context.read(edition.source_url, stage="scorecards:freedomworks_wordpress:edition-end", hosts=HOSTS)
    if _facts(end, edition) != facts:
        raise ScorecardSourceError("FreedomWorks WordPress table changed during its stable reread")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="FreedomWorks",
        parser_version=parser_version,
        rendition_rule="freedomworks-wordpress-mixed-period-native-table/1",
        homepage="https://www.freedomworks.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "member_results", "native_context")
    bundle.use(end, "members_and_scores", "scored_items", "member_results", "native_context", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = original
    bundle.tables["scorecards"][0].update(timespan_text=facts["heading"], methodology_url=source.url)
    bundle.add(
        "scorecard_methodologies",
        source,
        "/",
        methodology_id="native-context",
        methodology_text=json.dumps({k: v for k, v in facts.items() if k != "members"}, ensure_ascii=False),
        methodology_url=source.url,
        disclosure_status=(
            "Native context contradicts item periods; scoring formula undisclosed"
            if chamber == "Senate"
            else "Native heading and graph period labels retained; scoring formula undisclosed"
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "/",
        methodology_id="archive-provenance",
        methodology_text=json.dumps(
            {
                "original_source_url": original,
                "archival_replay_url": source.url,
                "scope": "Complete original native table; separate from overview cohorts and JSON charts",
                "period_conflict": (
                    "117th Congress heading and 2022 graph default coexist with explicit 118th item titles"
                    if chamber == "Senate"
                    else "117th Congress heading and 2022 graph default retained; no item Congress inferred"
                ),
                "year_or_final_score_not_inferred": True,
            }
        ),
        methodology_url=source.url,
        disclosure_status=(
            "Named complete native table rendition with conflicting source period labels"
            if chamber == "Senate"
            else "Named complete native table rendition with retained source period labels"
        ),
    )
    # Each card shows both scores side by side; neither the cards nor the page
    # designates one as primary, so is_primary stays NULL.
    for index, (metric, name) in enumerate((("lifetime", "Lifetime Score"), ("session", "Session Score"))):
        bundle.add(
            "scorecard_metrics",
            source,
            f"html:#vote-table/tbody/tr[0]/.card-scores/li[{index}]",
            metric_id=metric,
            name=name,
            value_unit_text="%",
            chamber_text=chamber,
        )
    occurrence = Counter()
    item_ids = []
    for column, title in enumerate(facts["columns"][1:], 1):
        occurrence[title] += 1
        ident = key(chamber, title, str(occurrence[title]))
        item_ids.append(ident)
        path = f"html:#vote-table/thead/th[{column}]"
        refs = [citation_reference(o) for o in citation_occurrences([("title", title, path, "native-title")])]
        congress = re.search(r"\((\d+)th\)", title)
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=ident,
            item_kind_text=f"{chamber} Key Votes",
            title=title,
            congress_text=congress[1] if congress else None,
            chamber_text=chamber,
            references_json=json.dumps(refs),
            position_basis="absent",
        )
    for member in facts["members"]:
        path = f"html:#vote-table/tbody/tr[{member['ordinal']}]"
        bundle.add(
            "scorecard_members",
            source,
            path + "/.legislator-card",
            publisher_member_key=member["id"],
            publisher_member_id=member["id"],
            member_name=member["name"],
            state=member["state"],
            district=member.get("district"),
            party=member["party"],
            chamber_text=chamber,
            identifiers_json="[]",
            notes_text=json.dumps(
                {k: v for k, v in member.items() if k not in {"scores", "actions"}}, ensure_ascii=False
            ),
        )
        for index, (metric, score) in enumerate(zip(("lifetime", "session"), member["scores"], strict=True)):
            value = "N/A" if score["value"] == "NA" else score["value"]
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + f"/.card-scores/li[{index}]",
                metric_id=metric,
                publisher_member_key=member["id"],
                value_text=value,
                value_number=decimal_text(value),
                value_status_text="N/A" if value == "N/A" else None,
                notes_text=json.dumps(score, ensure_ascii=False),
            )
        for item_id, action in zip(item_ids, member["actions"], strict=True):
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + f"/td[{action['column']}]",
                item_id=item_id,
                publisher_member_key=member["id"],
                result_id="native-freedom-alignment",
                action_text=action["result"],
                result_text=action["result"],
                reason_text=json.dumps(action, ensure_ascii=False),
            )
    return bundle.finish(
        f"All reviewed native {chamber} table rows, both literal member score metrics, every source column and repeated action "
        "title/result reconcile; unfiltered inputs, unique native IDs, original footer and all selected facts are stable on reread. "
        f"This named table rendition retains the source's {'conflicting period labels' if chamber == 'Senate' else 'period labels'} and aggregate heading without deriving a year, "
        "official identities, preferred votes, roll calls, weights or metric participation. Other page cohorts and JSON charts are outside this table rendition."
    )
