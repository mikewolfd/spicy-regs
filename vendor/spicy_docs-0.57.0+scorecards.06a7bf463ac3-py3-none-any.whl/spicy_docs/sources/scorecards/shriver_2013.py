"""Shriver's original visible 2013 Poverty Scorecard, with native source gaps."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "shriver-2013-qualified-visible-pdf/1"
ORIGINAL_URL = "http://povertylaw.org/sites/default/files/images/publications/2013-poverty-scorecard-final.pdf"
SOURCE_URL = "https://web.archive.org/web/20151017061552id_/" + ORIGINAL_URL
SOURCE_SHA256 = "d940edac96c30e12e586fd3c2f1377c1eb96c1d84205a8f6f7fa2c4f08597dab"
QUALIFIED_SHA256 = "b8f04c96472ea913ce586f366cbb8247e042ce2f06b79254bef5f7eb6491acf2"
TITLE = "POVERTY SCORECARD 2013"
EDITION = ScorecardEdition(
    "shriver", "2013-original-pdf", SOURCE_URL, TITLE, year="2013", chamber="both", is_current=False
)
GLYPHS = frozenset(("●", "○", "–", ""))
GRADES = frozenset(("A+", "A", "B", "C", "D", "F", "F-", ""))
BILL = re.compile(r"\b(?:H\.?\s*R\.?|[HS]\.?\s*(?:Con\.?\s*Res\.?|J\.?\s*Res\.?|Res\.?)|S\.)\s*[0-9]+\b")
AMENDMENT = re.compile(r"\b[HS]\.\s*Amdt\.\s*[0-9]+\b")


@dataclass(frozen=True, slots=True)
class Shriver2013Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URL,
        source_sha256=SOURCE_SHA256,
        message="Shriver2013 original differs from its reviewed complete visible PDF",
    )


def list_scorecards(context):
    document = context.read(SOURCE_URL, stage="scorecards:shriver:2013:named-edition", hosts=("web.archive.org",))
    _source(document)
    return [EDITION]


def _facts(body):
    try:
        data = json.loads(body)
        assert set(data) == {
            "format_version",
            "source_sha256",
            "physical_page_count",
            "title_text",
            "year_text",
            "publisher_name_text",
            "grids",
            "items",
            "method",
            "source_contexts",
            "source_cohort_reconciliation",
            "visible_source_rule",
        }
        assert data["format_version"] == "shriver-2013-qualified-visible-source-facts/1"
        assert data["source_sha256"] == SOURCE_SHA256 and data["physical_page_count"] == 77
        assert data["title_text"] == TITLE and data["year_text"] == "2013"
        assert data["publisher_name_text"] == "Sargent Shriver National Center on Poverty Law"
        assert [p["physical_page"] for p in data["grids"]] == list(range(13, 75))
        counts, scored, names = Counter(), Counter(), []
        for page in data["grids"]:
            assert isinstance(page["state_text"], str) and page["state_text"].strip()
            for table in page["tables"]:
                chamber = table["chamber_text"]
                assert chamber in ("Senate", "House") and table["members"]
                assert len(table["column_centers"]) == 18
                assert table["column_centers"] == sorted(table["column_centers"])
                for ordinal, member in enumerate(table["members"], 1):
                    assert member["source_ordinal"] == ordinal
                    assert member["member_name_text"].strip() and member["name_box"] and member["name_origin"]
                    assert member["party_text"] in ("D", "R", "I", "")
                    assert (
                        member["district_text"] is None
                        if chamber == "Senate"
                        else bool(re.fullmatch(r"[0-9]+|at-large", member["district_text"]))
                    )
                    assert member["grade_text"] in GRADES
                    assert member["score_text"] == "" or re.fullmatch(r"[0-9]+%", member["score_text"])
                    assert member["poverty_rate_text"] == "N/A" or re.fullmatch(
                        r"[0-9]+\.[0-9]+%", member["poverty_rate_text"]
                    )
                    assert len(member["actions"]) == 18 and all(v in GLYPHS for v in member["actions"])
                    assert isinstance(member["source_action_evidence"], list)
                    assert bool(member["score_text"]) == bool(member["grade_text"])
                    counts[chamber] += 1
                    scored[chamber] += bool(member["score_text"])
                    names.append(member["member_name_text"])
        assert counts == Counter(Senate=100, House=434) and scored == Counter(Senate=98, House=427)
        assert names.count("Vacant") == 1
        assert Counter(i["chamber_text"] for i in data["items"]) == Counter(Senate=18, House=18)
        for chamber in ("Senate", "House"):
            assert [i["ordinal"] for i in data["items"] if i["chamber_text"] == chamber] == list(range(1, 19))
        for item in data["items"]:
            assert item["native_vote_label_text"].strip() and item["issue_area_text"].strip()
            assert item["physical_page"] in (9, 10, 11, 12) and item["native_paragraphs"]
            assert item["full_description_text"] == "\n".join(p["native_text"] for p in item["native_paragraphs"])
            assert (
                item["full_description_text"][: item["publisher_label_end_offset"]]
                .strip()
                .endswith(item["native_vote_label_text"] + ".")
            )
        assert [c["physical_page"] for c in data["source_contexts"]] == list(range(1, 78))
        for context in data["source_contexts"]:
            assert context["visible_text_spans"] or context.get("visible_image_attribution")
            assert all(
                isinstance(s["text"], str) and s["box"] and isinstance(s["sequence"], int)
                for s in context["visible_text_spans"]
            )
        method = data["method"]
        assert method["physical_page"] == 8 and len(method["native_methodology_paragraphs"]) == 4
        assert all(p["source_text"].strip() and p["source_spans"] for p in method["native_methodology_paragraphs"])
        assert len(method["grade_scale"]) == 7 and method["native_distribution_table"]["rows"]
        assert [(g["glyph_text"], g["meaning_text"]) for g in method["glyph_legend"]] == [
            ("●", "VOTED TO FIGHT POVERTY"),
            ("○", "VOTED AGAINST FIGHTING POVERTY"),
            ("–", "DID NOT VOTE"),
        ]
        cohort = data["source_cohort_reconciliation"]
        assert cohort["method_house_denominator_text"] == "435" and cohort["method_graded_house_count_text"] == "427"
        assert cohort["printed_house_rows"] == 434
        assert cohort["states"]["ALABAMA"]["labels"] == ["2", "3", "4", "5", "6", "7"]
        assert cohort["states"]["ALABAMA"]["gaps_within_printed_numeric_range"] == [1]
        assert data["visible_source_rule"].strip()
        return data
    except (AssertionError, KeyError, TypeError, ValueError):
        raise ScorecardSourceError("Shriver2013 observations omit or alter the reviewed source shape") from None


def _references(item, source_path, all_labels):
    text = item["full_description_text"]
    prefix_end = item["publisher_label_end_offset"]
    occurrences = []
    for kind, pattern in (("bill", BILL), ("amendment", AMENDMENT)):
        for match in pattern.finditer(text, prefix_end):
            citation = match[0]
            # S.281 is also a publisher vote label in a parenthetical cross-reference.
            # The source's vote-label vocabulary alone is not a Senate bill identity.
            parenthetical_vote = (
                kind == "bill"
                and re.sub(r"\s+", "", citation) in all_labels
                and text[max(0, match.start() - 1) : match.start()] == "("
            )
            occurrences.append(
                {
                    "kind": "publisher-vote-label" if parenthetical_vote else kind,
                    "citation_text": citation,
                    "source_path": source_path + f"/full_description_text;start={match.start()};end={match.end()}",
                }
            )
    occurrences.sort(key=lambda r: int(r["source_path"].split(";start=")[-1].split(";")[0]))
    for n, occurrence in enumerate(occurrences, 1):
        occurrence["occurrence_id"] = str(n)
    return occurrences


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("Unknown Shriver2013 named edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Shriver2013 requires pinned private original observations and retention")
    source = context.read(SOURCE_URL, stage="scorecards:shriver:2013:original", hosts=("web.archive.org",))
    _source(source)
    repeated = context.read(SOURCE_URL, stage="scorecards:shriver:2013:original-reread", hosts=("web.archive.org",))
    _source(repeated)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="scorecards:shriver:2013:qualified-visible-source-facts",
    )
    data = _facts(qualified_observations)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=data["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="Complete original visible Shriver2013 PDF rendition; retain every printed member/vacancy and source glyph, separate percent/grade/poverty context and original435-versus434 source discrepancy",
        homepage="http://povertylaw.org/",
    )
    groups = ("members", "ratings", "items", "item-results", "methodology")
    bundle.use(source, *groups)
    bundle.use(repeated, "edition", *groups, role="corroboration")

    def loc(page, path):
        return f"pdf:page={page};observation={observation}{path}"

    def dump(value):
        return json.dumps(value, ensure_ascii=False)

    card = bundle.tables["scorecards"][0]
    card["methodology_url"] = source.url
    card["periods_json"] = dump(
        [
            {
                "occurrence_id": "cover-year",
                "kind": "explicit",
                "year_text": "2013",
                "period_text": "2013",
                "source_path": loc(1, "/cover"),
            }
        ]
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        loc(8, "/method"),
        methodology_id="methodology",
        methodology_url=source.url,
        methodology_text=dump(
            {
                "native_method": data["method"],
                "visible_source_rule": data["visible_source_rule"],
                "original_publisher_url": ORIGINAL_URL,
                "archive_url": SOURCE_URL,
                "source_cohort_reconciliation": data["source_cohort_reconciliation"],
            }
        ),
        disclosure_status="Explicit equal weighting, missed-vote denominator and chamber-specific eligibility; source435House denominator differs from434printed occurrences; no score reproduction",
    )
    for original in data["source_contexts"]:
        number = original["physical_page"]
        bundle.add(
            "scorecard_methodologies",
            source,
            loc(number, "/visible-source-context"),
            methodology_id=f"source-context:{number}",
            methodology_url=source.url,
            methodology_text=dump(original),
            disclosure_status="Original visible native text occurrences, coordinates and publisher attribution; hidden/stale template text excluded",
        )
    for chamber in ("Senate", "House"):
        first = next(p for p in data["grids"] if any(t["chamber_text"] == chamber for t in p["tables"]))
        for column in ("score", "grade"):
            bundle.add(
                "scorecard_metrics",
                source,
                loc(first["physical_page"], "/" + column + "-column"),
                metric_id=key(chamber, column),
                methodology_id="methodology",
                name=column.upper(),
                chamber_text=chamber,
                period_text="2013",
                value_unit_text="%" if column == "score" else None,
                is_primary=None,
            )
    all_labels = {re.sub(r"\s+", "", i["native_vote_label_text"]) for i in data["items"]}
    for item in data["items"]:
        chamber, ordinal = item["chamber_text"], item["ordinal"]
        identity, path = key(chamber, str(ordinal)), loc(item["physical_page"], f"/items/{chamber}/{ordinal}")
        references = _references(item, path, all_labels)
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=identity,
            publisher_item_id=item["native_vote_label_text"],
            item_kind_text=chamber.upper() + " VOTES",
            title=item["issue_area_text"] + ": " + item["native_vote_label_text"],
            chamber_text=chamber,
            references_json=dump(references),
            publisher_position_text=None,
            position_basis="absent",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path,
            metric_id=key(chamber, "score"),
            item_id=identity,
            participation_id="source-column",
            methodology_id="methodology",
            weight_text="Each vote is given equal weight.",
            weight_number=None,
            counts_toward_metric="true",
            position_basis="absent",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id="item:" + identity,
            chamber_text=chamber,
            methodology_url=source.url,
            methodology_text=dump(item),
            disclosure_status="Complete original authored narrative, issue-area and publisher vote label; explicit citation occurrences remain distinct; no inferred floor roll, date, Congress or preferred action",
        )
    for page in data["grids"]:
        number = page["physical_page"]
        for table_index, table in enumerate(page["tables"]):
            chamber = table["chamber_text"]
            for member in table["members"]:
                ordinal = member["source_ordinal"]
                identity = key(chamber, f"physical-page={number}", f"table={table_index}", f"row={ordinal}")
                path = loc(number, f"/tables/{table_index}/members/{ordinal - 1}")
                bundle.add(
                    "scorecard_members",
                    source,
                    path,
                    publisher_member_key=identity,
                    member_name=member["member_name_text"],
                    state=page["state_text"],
                    district=member["district_text"],
                    party=member["party_text"],
                    chamber_text=chamber,
                    period_text="2013",
                    notes_text=dump(
                        {
                            "poverty_rate_text": member["poverty_rate_text"],
                            "poverty_rate_basis": "Native contextual POVERTY RATE column; not a congressional performance rating",
                            "source_name_box": member["name_box"],
                            "source_name_origin": member["name_origin"],
                            "row_kind": "source-vacancy"
                            if member["member_name_text"] == "Vacant"
                            else "source-member-occurrence",
                        }
                    ),
                )
                for column in ("score", "grade"):
                    value = member[column + "_text"]
                    bundle.add(
                        "scorecard_member_ratings",
                        source,
                        path + "/" + column + "_text",
                        metric_id=key(chamber, column),
                        publisher_member_key=identity,
                        value_text=value,
                        value_number=value[:-1] if column == "score" and value else None,
                    )
                for item_ordinal, glyph in enumerate(member["actions"], 1):
                    bundle.add(
                        "scorecard_member_item_results",
                        source,
                        path + f"/actions/{item_ordinal - 1}",
                        result_id="source-cell",
                        item_id=key(chamber, str(item_ordinal)),
                        publisher_member_key=identity,
                        result_text=glyph,
                    )
    return bundle.finish(
        "Complete exact 77-page original and identical original reread; every 534 printed row and 9612 native cell reconciles with original character/vector paint and images, including 525 scores, the explicit vacancy, blank rows and omitted Alabama district 1. All 36 native item narratives and visible source/method contexts remain intact; model refusals and corrections stay private.",
        declared={
            "method_house_denominator_text": "435",
            "method_scored_house_count_text": "427",
            "parsed_house_occurrences": 434,
            "method_senate_denominator_text": "100",
            "method_scored_senate_count_text": "98",
            "source_missing_house_label": "ALABAMA:1",
        },
    )
