"""AFGE annual PDFs with grouped vote topics and numbered member End Notes."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "afge-noted-grouped-qualified-pdf/2"
INDEX = "https://www.afge.org/take-action/afge-on-capitol-hill/issue-papers--voting-records/"
HOSTS = ("www.afge.org",)
QUALIFIED_EDITIONS: dict[str, dict[str, Any]] = {
    "2023": {
        "url": "https://www.afge.org/globalassets/images/apps/legcon/2024/2023-voting-record_feb8.pdf",
        "source_sha256": "1b5d9ebe396e231e994c4ecf008eea113e6b611edb3d62ed6c51ff04b192675f",
        "observations_sha256": "946d29d3bd26241ece10438384f3b3ff0e5a9a034a410745710e434e2697cbe0",
        "pages": 59,
        "members": {"House": 443, "Senate": 101},
        "topics": {"House": 10, "Senate": 7},
        "columns": {"House": 16, "Senate": 8},
        "notes": {"House": 58, "Senate": 19},
        "member_pages": {
            "House": {
                "11": 14,
                "12": 18,
                "13": 19,
                "14": 19,
                "15": 17,
                "16": 16,
                "17": 18,
                "18": 16,
                "19": 17,
                "20": 16,
                "21": 17,
                "22": 16,
                "23": 18,
                "24": 15,
                "25": 16,
                "26": 17,
                "27": 16,
                "28": 18,
                "29": 18,
                "30": 17,
                "31": 16,
                "32": 16,
                "33": 19,
                "34": 18,
                "35": 15,
                "36": 18,
                "37": 3,
            },
            "Senate": {
                "45": 9,
                "46": 10,
                "47": 9,
                "48": 9,
                "49": 9,
                "50": 9,
                "51": 9,
                "52": 9,
                "53": 9,
                "54": 9,
                "55": 9,
                "56": 1,
            },
        },
        "mapping": {
            "House": [
                [6, 2],
                [5, 1],
                [7, 0],
                [8, 0],
                [10, 1],
                [6, 0],
                [6, 1],
                [10, 0],
                [5, 0],
                [9, 0],
                [9, 1],
                [4, 0],
                [3, 0],
                [1, 1],
                [2, 0],
                [1, 0],
            ],
            "Senate": [[4, 0], [6, 0], [7, 0], [6, 1], [2, 0], [1, 0], [5, 0], [3, 0]],
        },
        "source_asserted_links": {
            "Senate:7": {
                "title": "Nomination of Kalpana Kotagal to be a Member of the Equal Employment Opportunity Commission",
                "column_title": "Kalpana Kotagal EEOC Confirmation (184)",
            }
        },
        "year": "2023",
        "congress": "118",
        "congress_label": "118th Congress",
        "session": "1",
        "session_label": "first session",
        "score_label": "AFGE Score %",
    },
    "2022": {
        "url": "https://www.afge.org/globalassets/documents/generalreports/2023/2022-voting-record_feb9_may22.pdf",
        "source_sha256": "658fe7cb8739e9aacebcc025a6543f6c91f391c1d6f534292f8e7b05b9e20983",
        "observations_sha256": "d96610ae22dd775b077090428522f8e5bb3bccdedae8b2a836663e9005d03750",
        "pages": 50,
        "members": {"House": 447, "Senate": 100},
        "topics": {"House": 16, "Senate": 11},
        "columns": {"House": 18, "Senate": 12},
        "notes": {"House": 27, "Senate": 4},
        "member_pages": {
            "House": {
                "16": 25,
                "17": 31,
                "18": 29,
                "19": 28,
                "20": 26,
                "21": 29,
                "22": 26,
                "23": 28,
                "24": 26,
                "25": 26,
                "26": 29,
                "27": 28,
                "28": 27,
                "29": 28,
                "30": 29,
                "31": 27,
                "32": 5,
            },
            "Senate": {"42": 16, "43": 17, "44": 17, "45": 16, "46": 17, "47": 17},
        },
        "mapping": {
            "House": [
                [1, 0],
                [2, 0],
                [3, 0],
                [4, 0],
                [5, 0],
                [6, 0],
                [7, 0],
                [8, 0],
                [9, 0],
                [10, 0],
                [11, 0],
                [12, 0],
                [13, 0],
                [14, 0],
                [15, 0],
                [16, 0],
                [16, 1],
                [16, 2],
            ],
            "Senate": [
                [1, 0],
                [2, 0],
                [3, 0],
                [4, 0],
                [5, 0],
                [5, 1],
                [6, 0],
                [7, 0],
                [8, 0],
                [9, 0],
                [10, 0],
                [11, 0],
            ],
        },
        "source_asserted_links": {
            "Senate:7": {
                "title": "The Omnibus Funding Bill The “Consolidated Appropriations Act” (H.R. 2617) – Roll Call Vote #412",
                "column_title": "Omnibus (421)",
                "prose_roll_number_text": "#412",
            }
        },
        "year": "2022",
        "congress": "117",
        "congress_label": "117th Congress",
        "session": "2",
        "session_label": "second session",
        "score_label": "AFGE Score (%)",
    },
}
LEGEND = {
    "R": "Voted With AFGE",
    "W": "Voted Against AFGE",
    "?": "Did Not Vote",
    "I": "Not In Office or Not Eligible to Vote",
}
CITATION = re.compile(
    r"\b(?:H\.\s*(?:R\.|(?:J\.|Con\.)?\s*Res\.|Amdt\.)|S\.\s*(?:(?:J\.|Con\.)\s*Res\.|Amdt\.)?)\s*\d+\b|\bPN\s*\d+\b|\bSA\s*\d+\b"
)
SCHEMAS = {
    "afge-noted-pdf-front-facts/1",
    "afge-noted-pdf-topic-facts/1",
    "afge-noted-pdf-member-facts/1",
    "afge-noted-pdf-end-note-facts/1",
    "afge-noted-pdf-native-reviewed-facts/1",
}


def _edition(identifier):
    spec = QUALIFIED_EDITIONS[identifier]
    return ScorecardEdition(
        "afge",
        identifier,
        spec["url"],
        spec["year"] + " VOTING RECORD",
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    require_reviewed_pdf(
        document,
        source_url=spec["url"],
        source_sha256=spec["source_sha256"],
        message="AFGE noted PDF differs from the complete reviewed original",
        trailer_window=4096,
    )


def _evidence(e, spec):
    pages = e["physical_pages"]
    if (
        not isinstance(pages, list)
        or not pages
        or len(pages) != len(set(pages))
        or any(type(p) is not int or not 1 <= p <= spec["pages"] for p in pages)
        or e["schema_version"] not in SCHEMAS
        or not isinstance(e["json_pointer"], str)
        or not e["json_pointer"].startswith("/")
        or any(not re.fullmatch(r"[0-9a-f]{64}", e[k]) for k in ["outcome_sha256", "observation_sha256"])
    ):
        raise ValueError


def _qualified(body):
    try:
        if not isinstance(body, bytes):
            raise TypeError
        data = json.loads(body)
        spec = QUALIFIED_EDITIONS[data["edition_key"]]
        if (
            sha256(body).hexdigest() != spec["observations_sha256"]
            or data["format_version"] != "afge-qualified-noted-pdf/1"
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["pages"]
            or data["member_counts"] != spec["members"]
            or data["topic_counts"] != spec["topics"]
            or data["note_counts"] != spec["notes"]
            or data["action_column_counts"] != spec["columns"]
            or data["member_page_counts"] != spec["member_pages"]
        ):
            raise ValueError
        _evidence(data["front"]["evidence"], spec)
        front = data["front"]["record"]
        if (
            front["title_text"] != spec["year"] + " VOTING RECORD"
            or front["year_text"] != spec["year"]
            or front["congress_text"] != spec["congress_label"]
            or front["session_text"] != spec["session_label"]
            or front["score_label_text"] != spec["score_label"]
            or front["score_unit_text"] != "%"
            or not front["period_statements"]
            or len(front["legend"]) != len(LEGEND)
            or {r["token_text"]: r["meaning_text"] for r in front["legend"]} != LEGEND
        ):
            raise ValueError
        topics = {}
        for e in data["topics"]:
            _evidence(e["evidence"], spec)
            r, ch, ordinal = e["record"], e["chamber"], e["source_topic_ordinal"]
            plain = " ".join(r["source_narrative_text"].split())
            if (
                ch not in spec["topics"]
                or type(ordinal) is not int
                or not 1 <= ordinal <= spec["topics"][ch]
                or (ch, ordinal) in topics
                or not re.fullmatch(r"\d+\.", r["item_number_text"])
                or not r["title_text"]
                or not plain.startswith(r["title_text"])
                or not r["actions"]
            ):
                raise ValueError
            for a in r["actions"]:
                if (
                    not a["title_text"]
                    or a["title_text"] not in plain
                    or a["preferred_vote_text"] not in {"Yes", "No", "Yea"}
                    or (a["date_text"] is not None and a["date_text"] not in plain)
                    or (a["roll_number_text"] is not None and not re.fullmatch(r"#?\d+", a["roll_number_text"]))
                ):
                    raise ValueError
            topics[ch, ordinal] = r
        if any(
            {n for ch0, n in topics if ch0 == ch} != set(range(1, count + 1)) for ch, count in spec["topics"].items()
        ):
            raise ValueError
        columns = {ch: {} for ch in spec["columns"]}
        for p in data["participations"]:
            ch, column = p["chamber"], p["column_ordinal"]
            ordinal, index = spec["mapping"][ch][column - 1]
            a = topics[ch, ordinal]["actions"][index]
            if (
                type(column) is not int
                or not 1 <= column <= spec["columns"][ch]
                or column in columns[ch]
                or p["source_topic_ordinal"] != ordinal
                or p["action_index"] != index
                or not re.fullmatch(r"\d+", p["roll_number_text"])
                or p["column_title_text"] != data["column_titles"][ch][column - 1]
                or not re.search(r"\((?:Roll Call )?" + p["roll_number_text"] + r"\)$", p["column_title_text"])
                or p["publisher_position_text"] != a["preferred_vote_text"]
                or p["date_text"] != a["date_text"]
            ):
                raise ValueError
            if a["roll_number_text"] is None or a["roll_number_text"].removeprefix("#") != p["roll_number_text"]:
                asserted = spec["source_asserted_links"][f"{ch}:{column}"]
                if (
                    a["title_text"] != asserted["title"]
                    or p["column_title_text"] != asserted["column_title"]
                    or a["roll_number_text"] != asserted.get("prose_roll_number_text")
                ):
                    raise ValueError
            columns[ch][column] = p
        if any(
            set(columns[ch]) != set(range(1, count + 1)) or len(data["column_titles"][ch]) != count
            for ch, count in spec["columns"].items()
        ):
            raise ValueError
        notes = {}
        for e in data["end_notes"]:
            _evidence(e["evidence"], spec)
            r, ch = e["record"], e["chamber"]
            if (
                ch not in spec["notes"]
                or not re.fullmatch(r"\d+\.", r["note_number_text"])
                or not r["note_text"]
                or (ch, r["note_number_text"].removesuffix(".")) in notes
            ):
                raise ValueError
            notes[ch, r["note_number_text"].removesuffix(".")] = r
        if dict(Counter(ch for ch, _ in notes)) != spec["notes"]:
            raise ValueError
        identities, members, pages, used_notes = set(), Counter(), {ch: Counter() for ch in spec["members"]}, set()
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, ch = e["record"], e["chamber"]
            physical = e["evidence"]["physical_pages"]
            identity = (ch, tuple(physical), e["evidence"]["json_pointer"])
            if (
                ch not in spec["members"]
                or identity in identities
                or len(physical) != 1
                or str(physical[0]) not in spec["member_pages"][ch]
                or not r["member_name_text"]
                or not r["state_text"]
                or r["party_text"] not in {"D", "R", "I", "E"}
                or not re.fullmatch(r"\d+", r["score_text"])
                or (ch == "House" and not re.fullmatch(r"AL|\d{1,2}", r["district_text"]))
                or (ch == "Senate" and r["district_text"] is not None)
                or (r["end_notes_text"] is not None and (ch, r["end_notes_text"]) not in notes)
                or set(r["item_results"]) != {str(n) for n in columns[ch]}
                or any(token not in set(LEGEND) | {""} for token in r["item_results"].values())
                or not re.fullmatch(r"[0-9a-f]{64}", e["evidence"]["native_text_sha256"])
                or not e["evidence"]["json_pointer"].startswith("/members/")
                or type(e["evidence"]["state_heading_physical_page"]) is not int
                or not 1 <= e["evidence"]["state_heading_physical_page"] <= physical[0]
            ):
                raise ValueError
            identities.add(identity)
            members[ch] += 1
            pages[ch][str(physical[0])] += 1
            if r["end_notes_text"]:
                used_notes.add((ch, r["end_notes_text"]))
        if (
            dict(members) != spec["members"]
            or any(dict(pages[ch]) != spec["member_pages"][ch] for ch in pages)
            or used_notes != set(notes)
        ):
            raise ValueError
        return data, spec
    except (ValueError, KeyError, TypeError, AttributeError, IndexError) as error:
        raise ScorecardSourceError("AFGE noted facts do not establish the pinned complete reviewed edition") from error


@dataclass(frozen=True, slots=True)
class AFGENotedPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        data, spec = _qualified(self.qualified_observations)
        _source(context.read(spec["url"], stage=f"afge:{data['edition_key']}:noted-pdf:list", hosts=HOSTS), spec)
        return (_edition(data["edition_key"]),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AFGE noted PDF requires pinned reviewed facts and private observation retention")
    data, spec = _qualified(qualified_observations)
    if edition != _edition(data["edition_key"]):
        raise ScorecardSourceError("AFGE noted PDF selection differs from the qualified named edition")
    document = context.read(spec["url"], stage=f"afge:{edition.edition_id}:noted-pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["observations_sha256"],
        stage=f"afge:{edition.edition_id}:qualified-noted-observations",
    )
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="American Federation of Government Employees",
        parser_version=parser_version,
        homepage="https://www.afge.org/",
        rendition_rule="complete named annual PDF with reviewed source topic occurrences, grid columns, all native member cells and literal numbered End Notes; stable original reread",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX

    def path(group, n=None, suffix=""):
        e = data[group] if n is None else data[group][n]
        pages = ",".join(str(p) for p in e["evidence"]["physical_pages"])
        return (
            f"pdf:pages={pages};observation={observation};/{group}"
            + ("" if n is None else f"/{n}")
            + "/record"
            + suffix
        )

    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        edition_label_text=front["title_text"],
        methodology_url=document.url,
        timespan_text=front["period_statements"][0],
        congress_text=front["congress_text"],
        session_text=front["session_text"],
        periods_json=json_column(
            [
                {
                    "occurrence_id": str(i),
                    "kind": "explicit",
                    "period_text": text,
                    "year_text": spec["year"],
                    "congress_text": front["congress_text"],
                    "session_text": front["session_text"],
                    "source_path": path("front", suffix=f"/period_statements/{i}"),
                }
                for i, text in enumerate(front["period_statements"])
            ]
        ),
    )
    for ch in spec["members"]:
        method = key(ch, "printed-method")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front"),
            methodology_id=method,
            chamber_text=ch,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_methodology_statements": front["source_methodology_statements"],
                    "source_legend": front["legend"],
                    "source_column_titles": data["column_titles"][ch],
                    "source_formula_text": None,
                    "source_weight_text": None,
                    "source_observations": data["source_observations"],
                }
            ),
        )
        bundle.add(
            "scorecard_metrics",
            document,
            path("front", suffix="/score_label_text"),
            metric_id=ch,
            methodology_id=method,
            name=front["score_label_text"],
            value_unit_text=front["score_unit_text"],
            chamber_text=ch,
            period_text=spec["year"],
            is_primary="true",
        )
    for n, e in enumerate(data["topics"]):
        r, ch, ordinal = e["record"], e["chamber"], e["source_topic_ordinal"]
        item, location = key(ch, "topic", str(ordinal)), path("topics", n)
        participations = [
            p for p in data["participations"] if p["chamber"] == ch and p["source_topic_ordinal"] == ordinal
        ]
        refs = []
        for i, m in enumerate(CITATION.finditer(r["source_narrative_text"])):
            text = m[0]
            kind = (
                "nomination"
                if text.startswith("PN")
                else "amendment"
                if "Amdt" in text or text.startswith("SA")
                else "bill"
            )
            ref = {
                "occurrence_id": str(i),
                "citation_text": text,
                "kind": kind,
                "source_path": location + f"/source_narrative_text/offset={m.start()}",
            }
            if kind in {"bill", "amendment"}:
                ref[kind + "_citation_text"] = text
            refs.append(ref)
        for i, a in enumerate(r["actions"]):
            if a["roll_number_text"] is not None:
                refs.append(
                    {
                        "occurrence_id": f"action:{i}",
                        "citation_text": a["roll_number_text"],
                        "kind": "roll_call",
                        "roll_number_text": a["roll_number_text"].removeprefix("#"),
                        "congress_text": spec["congress"],
                        "session_text": spec["session"],
                        "chamber_text": ch,
                        "source_path": location + f"/actions/{i}/roll_number_text",
                    }
                )
        for p in participations:
            refs.append(
                {
                    "occurrence_id": f"grid:{p['column_ordinal']}",
                    "citation_text": p["column_title_text"],
                    "kind": "roll_call",
                    "roll_number_text": p["roll_number_text"],
                    "congress_text": spec["congress"],
                    "session_text": spec["session"],
                    "chamber_text": ch,
                    "source_path": location + f"/source-grid-column/{p['column_ordinal']}",
                }
            )
        bills = {v["bill_citation_text"] for v in refs if "bill_citation_text" in v}
        amendments = {v["amendment_citation_text"] for v in refs if "amendment_citation_text" in v}
        only = r["actions"][0] if len(r["actions"]) == 1 else None
        method = key(ch, "topic", str(ordinal), "method")
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=method,
            chamber_text=ch,
            disclosure_status="explicit",
            methodology_text=json_column(
                {
                    "source_topic_ordinal": ordinal,
                    "source_item_number_text": r["item_number_text"],
                    "source_actions": [{k: v for k, v in a.items() if k != "uncertainties"} for a in r["actions"]],
                    "member_names_with_explicit_rules": r["member_names_with_explicit_rules"],
                    "source_grid_participations": participations,
                }
            ),
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=item,
            publisher_item_id=r["item_number_text"],
            title=r["title_text"],
            item_kind_text="Congressional vote topic",
            item_date_text=only["date_text"] if only else None,
            congress_text=spec["congress"],
            session_text=spec["session"],
            chamber_text=ch,
            roll_number_text=only["roll_number_text"].removeprefix("#") if only and only["roll_number_text"] else None,
            bill_citation_text=next(iter(bills)) if len(bills) == 1 else None,
            amendment_citation_text=next(iter(amendments)) if len(amendments) == 1 else None,
            references_json=json_column(refs),
            publisher_position_text=only["preferred_vote_text"] if only else None,
            position_basis="explicit" if only else None,
            position_source_path=location + "/actions/0/preferred_vote_text" if only else None,
        )
        for p in participations:
            bundle.add(
                "scorecard_metric_items",
                document,
                location + f"/source-grid-column/{p['column_ordinal']}",
                metric_id=ch,
                item_id=item,
                participation_id=key(ch, str(p["column_ordinal"])),
                methodology_id=method,
                publisher_position_text=p["publisher_position_text"],
                position_basis="explicit",
            )
    note_lookup = {}
    for n, e in enumerate(data["end_notes"]):
        r, ch = e["record"], e["chamber"]
        number = r["note_number_text"].removesuffix(".")
        location = path("end_notes", n)
        # The row retains the observation ID; embedded literal notes use a stable PDF locator.
        note_lookup[ch, number] = {
            "source_note_number_text": r["note_number_text"],
            "source_note_text": r["note_text"],
            "source_path": location.replace(f";observation={observation}", ""),
        }
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=key(ch, "end-note", number),
            chamber_text=ch,
            disclosure_status="explicit",
            methodology_text=json_column(note_lookup[ch, number]),
        )
    for n, e in enumerate(data["members"]):
        r, ch = e["record"], e["chamber"]
        location = path("members", n)
        member = key(
            ch,
            str(e["evidence"]["physical_pages"][0]),
            e["evidence"]["json_pointer"],
            r["state_text"],
            *([r["district_text"]] if r["district_text"] else []),
            r["member_name_text"],
        )
        notes = json_column(
            {
                "source_end_notes_reference_text": r["end_notes_text"],
                "source_end_note": note_lookup[ch, r["end_notes_text"]] if r["end_notes_text"] else None,
            }
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            chamber_text=ch,
            period_text=spec["year"],
            identifiers_json="[]",
            notes_text=notes,
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/score_text",
            publisher_member_key=member,
            metric_id=ch,
            value_text=r["score_text"],
            value_number=decimal_text(r["score_text"]),
            notes_text=notes,
        )
        for p in (p for p in data["participations"] if p["chamber"] == ch):
            token = r["item_results"][str(p["column_ordinal"])]
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + f"/item_results/{p['column_ordinal']}",
                publisher_member_key=member,
                item_id=key(ch, "topic", str(p["source_topic_ordinal"])),
                metric_id=ch,
                participation_id=key(ch, str(p["column_ordinal"])),
                result_id=key(ch, str(p["column_ordinal"])),
                result_text=token,
                reason_text=LEGEND.get(token),
            )
    repeated = context.read(spec["url"], stage=f"afge:{edition.edition_id}:noted-pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "All native member rows, literal ratings/cells, source topic occurrences, grid associations and numbered End Notes reconcile qualified source facts; original reread identical",
        declared={
            "physical_pages": spec["pages"],
            "members_by_chamber": spec["members"],
            "members_by_physical_page": spec["member_pages"],
            "publisher_topics_by_chamber": spec["topics"],
            "source_grid_action_columns": spec["columns"],
            "source_described_actions": sum(len(e["record"]["actions"]) for e in data["topics"]),
            "source_end_notes_by_chamber": spec["notes"],
            "source_member_note_references": sum(e["record"]["end_notes_text"] is not None for e in data["members"]),
            "count_basis": "complete original named populations, topic occurrence order and grid/note scope; no official membership substitution",
            "topic_identity_rule_version": "afge-printed-topic-occurrence/1",
            "grid_topic_mapping_rule_version": "afge-exact-roll-or-qualified-source-title/2",
            "source_native_rendition_observations": data["source_observations"],
        },
    )
