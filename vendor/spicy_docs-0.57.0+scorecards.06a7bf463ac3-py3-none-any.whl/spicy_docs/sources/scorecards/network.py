"""NETWORK's original 2025 voting-record PDF and reviewed semantic source facts."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from bs4 import BeautifulSoup

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "network-qualified-2025-pdf/1"
INDEX = "https://networklobby.org/2025-voting-record/"
URL = "https://media.networklobby.org/uploads/2026/01/2025-NETWORK-Voting-Record.pdf"
SOURCE_SHA256 = "3a24e08e239f2a612c2fa83e7b4317fdc41122747d5ed4fc4a6a7ac331c482e0"
QUALIFIED_SHA256 = "1de36c41d33b590c7b8e63bd372b38c7ba0e86593e03c25c2703eec0405c2e5a"
EDITION = ScorecardEdition(
    "network", "2025-pdf", URL, "2025 Congressional Voting Record", year="2025", congress="119", chamber="both"
)
PAGE_MEMBERS = {3: 100, 5: 120, 6: 105, 7: 106, 8: 115}
TOKENS = {"+", "–", "o", "|"}
ITEM_IDENTITIES = {
    "Senate": (
        ("S.5", "7", "Nay", "July 1, 2025"),
        ("H.R.1968", "133", "Nay", "March 14, 2025"),
        ("S.146", "104", "Yea", "February 13, 2025"),
        ("H.R.1", "372", "Nay", "July 1, 2025"),
        ("H.R.4", "411", "Nay", "July 17, 2025"),
        ("H.R.5371", "618", "Nay", "November 10, 2025"),
        ("S.3385", "644", "Yea", "December 11, 2025"),
    ),
    "House": (
        ("S.5", "23", "Nay", "January 22, 2025"),
        ("H.R.1968", "70", "Nay", "March 11, 2025"),
        ("H.R.22", "102", "Nay", "April 10, 2025"),
        ("S.146", "104", "Yea", "April 2025, 2025"),
        ("H.R.1", "190", "Nay", "July 3, 2025"),
        ("H.R. 4", "168", "Nay", "June 12, 2025"),
        ("H.R.4922", "270", "Nay", "September 16, 2025"),
        ("H.R.5371", "285", "Nay", "November 12, 2025"),
        ("H.R.3898", "330", "Nay", "December 11, 2025"),
        ("H.R.2550", "332", "Yea", "December 11, 2025"),
    ),
}


@dataclass(frozen=True, slots=True)
class NETWORKReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _index(source):
    try:
        soup = BeautifulSoup(source.body.decode("utf-8"), "html.parser")
        canonical = soup.select_one('link[rel="canonical"]')
        if (
            canonical is None
            or canonical.get("href") != INDEX
            or not any("2025 Voting Record" in h.get_text(" ", strip=True) for h in soup.select("h1"))
            or URL not in {a.get("href") for a in soup.select("a[href]")}
        ):
            raise ValueError
    except (UnicodeDecodeError, ValueError):
        raise ScorecardSourceError("NETWORK original edition page no longer identifies the qualified PDF") from None


def list_scorecards(context):
    source = context.read(INDEX, stage="scorecards:network:listing", hosts=("networklobby.org",))
    _index(source)
    return (EDITION,)


def _facts(data):
    try:
        if data["format_version"] != "network-2025-qualified-source-facts/1" or data["sources"] != {
            "pdf-2025-content": {"sha256": SOURCE_SHA256, "page_count": 9}
        }:
            raise ValueError
        counts, identities = dict.fromkeys(PAGE_MEMBERS, 0), set()
        for entry in data["members"]:
            record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            page = evidence["physical_page"]
            identity = (chamber, record["state_text"], record["member_name_text"])
            count = 7 if chamber == "Senate" else 10
            if (
                page not in counts
                or evidence["source_label"] != "pdf-2025-content"
                or evidence["source_ordinal"] != counts[page]
                or chamber != ("Senate" if page == 3 else "House")
                or identity in identities
                or not record["member_name_text"]
                or not record["state_text"]
                or record["party_text"] not in {"D", "R", "I", "PPD"}
                or (record["district_text"] is not None and re.fullmatch(r"\d+", record["district_text"]) is None)
                or (chamber == "Senate" and record["district_text"] is not None)
                or not record["notes_text"]
                or set(record["results"]) != {str(i) for i in range(1, count + 1)}
                or any(v not in TOKENS for v in record["results"].values())
                or (
                    record["score_text"] not in {"NV", "N/A"}
                    and (
                        re.fullmatch(r"\d{1,3}%", record["score_text"]) is None or int(record["score_text"][:-1]) > 100
                    )
                )
            ):
                raise ValueError
            counts[page] += 1
            identities.add(identity)
        if counts != PAGE_MEMBERS or len(data["items"]) != 17 or len(data["methodology"]) != 3:
            raise ValueError
        for chamber, required in ITEM_IDENTITIES.items():
            entries = [e for e in data["items"] if e["chamber"] == chamber]
            if len(entries) != len(required):
                raise ValueError
            for ordinal, (entry, identity) in enumerate(zip(entries, required, strict=True), 1):
                record, evidence = entry["record"], entry["evidence"]
                if (
                    tuple(
                        record[k]
                        for k in ("bill_citation_text", "roll_number_text", "publisher_position_text", "item_date_text")
                    )
                    != identity
                    or record["ordinal"] != ordinal
                    or evidence["source_ordinal"] != ordinal - 1
                    or evidence["physical_page"] != (2 if chamber == "Senate" else 4)
                    or evidence["source_label"] != "pdf-2025-content"
                    or any(not record[k] for k in ("title", "description_text", "outcome_text"))
                ):
                    raise ValueError
        if [m["evidence"]["physical_page"] for m in data["methodology"]] != [1, 3, 6]:
            raise ValueError
        if any(not m["record"]["methodology_text"] for m in data["methodology"]):
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("NETWORK facts fail the complete qualified 2025 PDF shape") from None


def _references(record, chamber, path):
    return json.dumps(
        [
            {
                "occurrence_id": kind,
                "kind": kind,
                "citation_text": record[field_name],
                field_name: record[field_name],
                "congress_text": "119",
                "chamber_text": chamber,
                "session_text": "1st Session",
                "source_path": path + "/" + field_name,
            }
            for kind, field_name in (("bill", "bill_citation_text"), ("roll_call", "roll_number_text"))
        ],
        ensure_ascii=False,
    )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("NETWORK PDF requires reviewed semantic facts and private retention")
    index = context.read(INDEX, stage="scorecards:network:edition-page", hosts=("networklobby.org",))
    _index(index)
    source = context.read(URL, stage="scorecards:network:pdf", hosts=("media.networklobby.org",))
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="network:qualified-2025-pdf",
    )
    data = _facts(json.loads(qualified_observations))
    end = context.read(URL, stage="scorecards:network:pdf-end", hosts=("media.networklobby.org",))
    index_end = context.read(INDEX, stage="scorecards:network:edition-page-end", hosts=("networklobby.org",))
    _index(index_end)
    if sha256(end.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("NETWORK PDF changed during complete edition acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="NETWORK Lobby",
        parser_version=parser_version,
        rendition_rule="network-complete-original-2025-voting-record-pdf/1",
        homepage="https://networklobby.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(session_text="1st Session", methodology_url=URL)
    bundle.use(source, "members_and_scores", "scored_items", "member_results", "methodology")
    bundle.use(index, "edition", role="discovery")
    bundle.use(index_end, "edition", role="corroboration")
    bundle.use(end, "members_and_scores", "scored_items", "member_results", "methodology", role="corroboration")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}"),
            methodology_id=f"source-{i}",
            methodology_text=entry["record"]["methodology_text"],
            methodology_url=URL,
            disclosure_status=entry["record"]["scope_text"],
        )
    for chamber, page in (("Senate", 3), ("House", 5)):
        bundle.metric(
            source, key(chamber, "percent"), "%", path=path(page, "/score-heading"), chamber=chamber, unit="percent"
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = "119th Congress — 1st Session"
    for i, entry in enumerate(data["items"]):
        record, chamber = entry["record"], entry["chamber"]
        ordinal = str(record["ordinal"])
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        item_id, method_id = key(chamber, ordinal), key("item", chamber, ordinal)
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=ordinal,
            item_kind_text="roll_call",
            title=record["title"],
            congress_text="119",
            chamber_text=chamber,
            session_text="1st Session",
            item_date_text=record["item_date_text"],
            roll_number_text=record["roll_number_text"],
            bill_citation_text=record["bill_citation_text"],
            references_json=_references(record, chamber, loc),
            publisher_position_text=record["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_text=record["description_text"] + "\n" + record["outcome_text"],
            methodology_url=URL,
            disclosure_status="literal original item narrative and outcome; source citation/date conflicts preserved",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "percent"),
            item_id=item_id,
            participation_id="publisher-scored-votes",
            methodology_id=method_id,
            publisher_position_text=record["publisher_position_text"],
            position_basis="explicit",
            counts_toward_metric="true",
        )
    for i, entry in enumerate(data["members"]):
        record, chamber = entry["record"], entry["chamber"]
        identity = key(chamber, record["state_text"], record["member_name_text"])
        loc = path(entry["evidence"]["physical_page"], f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=record["notes_text"],
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            loc + "/score_text",
            metric_id=key(chamber, "percent"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, glyph in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "percent"),
                participation_id="publisher-scored-votes",
                publisher_member_key=identity,
                result_id="publisher-glyph",
                result_text=glyph,
            )
    return bundle.finish(
        "Complete original 2025 PDF: every member row, published percent/NV/N/A value, chamber-specific item narrative "
        "and action glyph reconciles to original native text, span positions and reviewed page images; publisher PDF link "
        "and exact PDF bytes remain stable across the bounded read. Printed compound member labels, explicit district, "
        "midterm exclusions, honor-roll context and conflicting source dates/citations remain literal. No official action "
        "conversion, inferred weights, district assignment or score reproduction."
    )
