"""IAM's publisher-selected 2024 native API rendition; no inferred Congress."""

from .rds_bt50 import Publisher, acquire_current, list_current

parser_version = "machinists-rds-bt50-2024-api/1"
PUBLISHER = Publisher(
    "machinists",
    "International Association of Machinists and Aerospace Workers",
    "https://www.goiam.org/",
    "https://www.goiam.org/iam-legislative-scorecard/#/",
    3709,
    "IAM Scorecard 2024",
    parser_version,
    congress=None,
    year="2024",
    session_id=822,
    score_set_title="2024",
    nomination_prefix="PN",
    retain_native_context=True,
    script_selectors=(
        "script[src*='/wp-content/plugins/rds-bt50-scorecard/public/./js/bt50-scorecard-app.js?']",
        "script[src*='/wp-content/plugins/rds-bt50-scorecard/public/./js/bt50-scorecard-common.js?']",
    ),
)
EDITION = PUBLISHER.edition


def list_scorecards(context):
    return list_current(context, PUBLISHER)


def acquire_scorecard(edition, context):
    return acquire_current(edition, context, PUBLISHER)
