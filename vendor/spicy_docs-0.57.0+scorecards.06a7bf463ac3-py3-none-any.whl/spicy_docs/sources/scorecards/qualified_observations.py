"""Private retention of reviewed PDF facts, independent of their semantic schema.

Publisher readers validate their own data shape. This helper binds the reviewed
asset to its original PDF and records a fresh observation for each acquisition.
It never runs an extraction model or publishes the asset's bytes.
"""

from collections.abc import Callable, Mapping
from hashlib import sha256
from uuid import UUID

from spicy_docs.reading.pdf_bytes import TRAILER_WINDOW, check_pdf_bytes
from spicy_docs.sources.scorecards.common import ScorecardSourceError, SourceDocument
from spicy_docs.transport.source_acquirer import check_final_url

RetainObservations = Callable[..., Mapping[str, object]]


def require_reviewed_pdf(
    document: SourceDocument,
    *,
    source_url: str,
    source_sha256: str,
    message: str,
    trailer_window: int = TRAILER_WINDOW,
) -> None:
    """Require exact reviewed bytes and final URL, preserving the reader's refusal.

    Existing source and PDF guards establish acquisition facts. Publisher
    readers still own their edition, source window and semantic completeness.
    No extraction, capture, reread or retention happens here.
    """
    check_final_url(document.url, source_url, error_type=ScorecardSourceError, message=message)
    if document.response.sha256 != "sha256:" + source_sha256:
        raise ScorecardSourceError(message)
    try:
        check_pdf_bytes(
            document.body, error_type=ScorecardSourceError, label="Reviewed source", trailer_window=trailer_window
        )
    except ScorecardSourceError:
        # Keep every source wrapper's established, credential-free refusal.
        raise ScorecardSourceError(message) from None


def retain_qualified(
    document: SourceDocument,
    body: bytes,
    callback: RetainObservations,
    *,
    source_sha256: str,
    observations_sha256: str,
    stage: str,
) -> str:
    """Admit exact reviewed inputs and require opaque private evidence identity."""
    if (
        not isinstance(body, bytes)
        or sha256(body).hexdigest() != observations_sha256
        or sha256(document.body).hexdigest() != source_sha256
    ):
        raise ScorecardSourceError("PDF or semantic observations differ from the reviewed qualification pins")
    try:
        receipt = callback(document, body, stage=stage)
        value = receipt.get("observation_id")
        identifier = UUID(value) if isinstance(value, str) else None
        if not isinstance(value, str) or identifier is None or str(identifier) != value or identifier.version != 4:
            raise ValueError
    except Exception:  # noqa: BLE001 - private callbacks must not echo bytes, paths or credentials
        raise ScorecardSourceError("Qualified semantic observations were not retained privately") from None
    return value
