"""PPFA's publisher-linked VoterVoice federal edition and scoring arrays.

The rating rendition reads every named criterion and its source action groups.
The separate criterion rendition retains archived actions without inventing a
rating population when the publisher's scoring array is empty.
"""

from __future__ import annotations

import re
from urllib.parse import urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "planned_parenthood-votervoice-detailed-federal/1"
criteria_parser_version = "planned_parenthood-votervoice-criteria-federal/1"
INDEX = "https://www.plannedparenthoodaction.org/congressional-scorecard"
PLUGIN = "https://www.votervoice.net/Scripts/eREAAAAAAAA/Plugin.js?app=scorecards"
APP = "https://www.votervoice.net/iframes/PPFA/Scorecard"
API = "https://www.votervoice.net/Api"
HOSTS = ("www.votervoice.net",)
TYPES = {"M": "Roll Call Votes", "S": "Sponsorship", "C": "Custom Action"}


from spicy_docs.sources.scorecards.votervoice_public import (
    Application,
    _array,
    _identifier,
    _scalar,
    bootstrap,
    criterion,
    read_api,
    scorings,
)

APPLICATION = Application(
    "planned_parenthood",
    INDEX,
    PLUGIN,
    APP,
    "PPFA",
    "4473",
    "Planned Parenthood Action Fund.",
    allow_unconfigured_items=True,
)


def _bootstrap(context):
    return bootstrap(context, APPLICATION)


def _read(context, path, headers, stage):
    return read_api(context, path, headers, stage, APPLICATION)


def _scorings(context, edition, headers, suffix=""):
    return scorings(context, edition, headers, APPLICATION, suffix)


def _criterion(context, identity, headers, suffix=""):
    return criterion(context, identity, headers, APPLICATION, suffix)


def _editions(context, headers, suffix=""):
    governments, data = _read(
        context, "/Governments?association=PPFA&activeScorecards=true", headers, "governments" + suffix
    )
    rows = _array(data, "government list")
    if [row for row in rows if row.get("name") == "Federal"] != [{"name": "Federal", "uri": "./USA"}]:
        raise ScorecardSourceError("PPFA federal government selection changed")
    documents, catalogs = [], []
    for active in ("true", "false"):
        document, data = _read(
            context,
            "/Scorecards?association=PPFA&government=./USA&active=" + active,
            headers,
            ("editions" if active == "true" else "inactive-editions") + suffix,
        )
        if not isinstance(data, list) or not all(isinstance(row, dict) for row in data):
            raise ScorecardSourceError("PPFA federal edition list is malformed")
        documents.append(document)
        catalogs.append(data)
    seen, congresses, editions = set(), set(), []
    for row in catalogs[0] + catalogs[1]:
        identity = _identifier(row.get("id"), r"4473-\d+")
        title = row.get("name")
        if not isinstance(title, str):
            raise ScorecardSourceError("PPFA edition period is absent")
        congress = re.fullmatch(r"(\d{4})-(\d{4}) Regular Session \((\d+)th\)", title)
        historical = re.fullmatch(r"(\d+)th Congress \((\d{4})-(\d{4})\)", title)
        if congress:
            period = (congress[1], congress[2], congress[3])
        elif historical:
            period = (historical[2], historical[3], historical[1])
        else:
            raise ScorecardSourceError("PPFA federal edition label changed shape")
        if int(period[1]) != int(period[0]) + 1 or identity in seen or period[2] in congresses:
            raise ScorecardSourceError("PPFA federal edition period or identity is repeated")
        seen.add(identity)
        congresses.add(period[2])
        criteria = row.get("criteria")
        if not isinstance(criteria, list) or not all(isinstance(item, dict) for item in criteria):
            raise ScorecardSourceError("PPFA edition criterion list is malformed")
        item_ids = []
        for item in criteria:
            cid = _identifier(item.get("id"), r"[MSC]-4473-\d+")
            if not isinstance(item.get("name"), str) or not item["name"]:
                raise ScorecardSourceError("PPFA scoring item is unnamed")
            if "billNumber" in item and not isinstance(item["billNumber"], str):
                raise ScorecardSourceError("PPFA source legislative citation changed type")
            item_ids.append(cid)
        if len(set(item_ids)) != len(item_ids):
            raise ScorecardSourceError("PPFA edition repeats a scoring item identity")
        # Empty archived configurations are observations, not acquired editions.
        if criteria:
            editions.append(
                ScorecardEdition(
                    "planned_parenthood", identity, INDEX, title, congress=period[2], chamber="both", is_current=False
                )
            )
    if not editions:
        raise ScorecardSourceError("PPFA catalog has no configured federal edition")
    current = max(int(e.congress or "0") for e in editions)
    editions = [
        ScorecardEdition(
            e.publisher_id,
            e.edition_id,
            e.source_url,
            e.title,
            congress=e.congress,
            chamber=e.chamber,
            is_current=int(e.congress or "0") == current,
        )
        for e in editions
    ]
    return governments, documents, catalogs[0] + catalogs[1], tuple(editions)


def _position(document, native):
    motion = native.get("legislativeMotion")
    if motion and motion["associationStance"]["supportsMotion"] is not None:
        return str(
            motion["associationStance"]["supportsMotion"]
        ).lower(), "$.legislativeMotion.associationStance.supportsMotion"
    html = soup_text(native.get("explanationHtml"))
    paragraphs = [(n, p.get_text().strip()) for n, p in enumerate(html.find_all("p"))]
    preferred = [(n, text) for n, text in paragraphs if re.search(r"\bA vote (?:FOR|AGAINST)\b", text)]
    if len(preferred) > 1:
        raise ScorecardSourceError("PPFA item has multiple preferred-action paragraphs")
    if preferred:
        n, text = preferred[0]
        return text, f"$.explanationHtml#p[{n}]"
    return None, None


def soup_text(text):
    from bs4 import BeautifulSoup

    return BeautifulSoup(text or "", "html.parser")


def _references(document, native):
    refs = []
    motion = native.get("legislativeMotion")
    if motion:
        for group, urls in [
            ("motion", motion["externalUrls"]),
            ("proposal", motion["legislativeProposal"]["externalUrls"]),
        ]:
            for n, url in enumerate(urls):
                field_path = "$.legislativeMotion." + ("legislativeProposal." if group == "proposal" else "")
                refs.append(
                    {
                        "occurrence_id": f"{group}:{n}",
                        "kind": "url",
                        "citation_text": url,
                        "source_path": f"capture:{document.capture_id}#{field_path}externalUrls[{n}]",
                    }
                )
    # Every literal publisher link survives, including an erroneous official URL.
    for n, anchor in enumerate(soup_text(native.get("explanationHtml")).find_all("a", href=True)):
        url = str(anchor["href"])
        if urlsplit(url).scheme not in {"http", "https"}:
            raise ScorecardSourceError("PPFA explanation reference is not an absolute public URL")
        refs.append(
            {
                "occurrence_id": f"explanation:{n}",
                "kind": "url",
                "citation_text": url,
                "source_path": f"capture:{document.capture_id}#$.explanationHtml#a[{n}]@href",
            }
        )
    return refs


def _methodology(original):
    paragraphs = [(n, p.get_text().strip()) for n, p in enumerate(soup(original).find_all("p"))]
    selected = [
        (n, text)
        for n, text in paragraphs
        if text.startswith(
            (
                "The Planned Parenthood Action Fund compiles a scorecard",
                "The Planned Parenthood Action Fund calculates a members' score",
                "Any recorded votes taken by the full House or Senate",
                "For a member of Congress to earn a score of 100%",
            )
        )
    ]
    if len(selected) != 4 or "current and preceding six sessions of Congress" not in selected[1][1]:
        raise ScorecardSourceError("PPFA original score period and methodology changed shape")
    return selected


class PPFAReader:
    """Complete per-Congress scoring arrays, with every advertised criterion."""

    criteria_only = False
    parser_version = parser_version

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        _, headers = _bootstrap(context)
        editions = _editions(context, headers)[3]
        if self.criteria_only:
            return tuple(
                ScorecardEdition(
                    e.publisher_id,
                    e.edition_id + ":criteria",
                    e.source_url,
                    e.title,
                    congress=e.congress,
                    chamber=e.chamber,
                    is_current=e.is_current,
                )
                for e in editions
            )
        return editions

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        boot, headers = _bootstrap(context)
        methodology = _methodology(boot[0])
        governments, catalogs, catalog, editions = _editions(context, headers)
        source_id = edition.edition_id.removesuffix(":criteria") if self.criteria_only else edition.edition_id
        selected = next((e for e in editions if e.edition_id == source_id), None)
        expected = (
            None
            if selected is None
            else ScorecardEdition(
                selected.publisher_id,
                source_id + (":criteria" if self.criteria_only else ""),
                selected.source_url,
                selected.title,
                congress=selected.congress,
                chamber=selected.chamber,
                is_current=selected.is_current,
            )
        )
        if edition != expected:
            raise ScorecardSourceError("PPFA selected edition is not in the original federal catalog")
        source = next(row for row in catalog if row["id"] == source_id)
        primary = catalogs[0] if any(row["id"] == source_id for row in json_data(catalogs[0])) else catalogs[1]
        scoring_document, rows = (None, []) if self.criteria_only else _scorings(context, edition, headers)
        criteria = {item["id"]: item for item in source["criteria"]}
        if any(f["criterionId"] not in criteria for r in rows for f in r["factors"]):
            raise ScorecardSourceError("PPFA factor refers to an undisclosed edition item")
        details = {cid: _criterion(context, cid, headers) for cid in criteria}
        if any(details[cid][1]["displayName"] != criteria[cid]["name"] for cid in criteria):
            raise ScorecardSourceError("PPFA criterion detail disagrees with its catalog title")
        if any(str(r["official"]["id"]) not in details[f["criterionId"]][2] for r in rows for f in r["factors"]):
            raise ScorecardSourceError("PPFA factor is absent from the complete criterion action groups")
        repeated_details = {cid: _criterion(context, cid, headers, ":reread") for cid in details}
        repeated_scoring, repeated_rows = (
            (None, []) if self.criteria_only else _scorings(context, edition, headers, ":reread")
        )
        final_governments, finals, repeated_catalog, repeated_editions = _editions(context, headers, ":reread")
        if (
            catalog != repeated_catalog
            or editions != repeated_editions
            or rows != repeated_rows
            or any(details[cid][1] != repeated_details[cid][1] for cid in details)
        ):
            raise ScorecardSourceError(
                "PPFA federal edition, scoring population or criterion detail changed during reread"
            )
        bundle = Bundle(
            edition,
            context,
            primary,
            publisher_name="Planned Parenthood Action Fund",
            parser_version=self.parser_version,
            rendition_rule=(
                "Complete advertised federal criterion details and literal member position groups; no ratings"
                if self.criteria_only
                else "Complete per-Congress scoring arrays and every advertised criterion; cumulative profiles are separate"
            ),
            homepage="https://www.plannedparenthoodaction.org/",
        )
        for number, doc in enumerate(boot):
            bundle.use(doc, "publisher-application:" + str(number))
        bundle.use(governments, "government-selection")
        bundle.use(final_governments, "government-selection", role="corroboration")
        for number, doc in enumerate(catalogs):
            if doc is not primary:
                bundle.use(doc, "archive-catalog")
            bundle.use(finals[number], "edition" if doc is primary else "archive-catalog", role="corroboration")
        if scoring_document is not None:
            assert repeated_scoring is not None
            bundle.use(scoring_document, "member-scoring-arrays")
            bundle.use(repeated_scoring, "member-scoring-arrays", role="corroboration")
        edition_path = "$[id=" + source_id + "]"
        bundle.tables["scorecards"][0].update(
            edition_label_text=source["name"],
            timespan_text=source["name"],
            publisher_edition_key=source_id,
            source_path=edition_path,
            methodology_url=INDEX,
        )
        bundle.add(
            "scorecard_methodologies",
            boot[0],
            "p[score-methodology]",
            methodology_id="publisher",
            methodology_text="\n\n".join(text for _, text in methodology),
            methodology_url=INDEX,
            disclosure_status="partial",
        )
        if not self.criteria_only:
            bundle.add(
                "scorecard_metrics",
                primary,
                edition_path,
                metric_id="score",
                name="Score",
                period_text=source["name"],
                is_primary="true",
                methodology_id="publisher",
                cohort_text="Publisher's federal chamber scoring-array population",
            )
        for ordinal, item in enumerate(source["criteria"]):
            cid = item["id"]
            path = edition_path + f".criteria[{ordinal}]"
            doc, native, _actions = details[cid]
            bundle.use(doc, "criterion:" + cid)
            bundle.use(repeated_details[cid][0], "criterion:" + cid, role="corroboration")
            stance, position_path = _position(doc, native)
            citation = item.get("billNumber")
            amendment = citation is not None and bool(re.match(r"[HS]\.Amdt\.", citation))
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=cid,
                publisher_item_id=cid,
                item_kind_text=TYPES[cid[0]],
                title=item["name"],
                congress_text=edition.congress,
                item_date_text=date[1] if (date := re.search(r"\((\d{1,2}/\d{1,2}/\d{4})\)$", item["name"])) else None,
                roll_number_text=roll[1]
                if (roll := re.search(r"(?:Roll\s+[Nn]o\.?|Record Vote Number:)\s*(\d+)", item["name"]))
                else None,
                bill_citation_text=None if amendment else citation,
                amendment_citation_text=citation if amendment else None,
                references_json=json_column(_references(doc, native)),
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                position_source_path=f"capture:{doc.capture_id}#{position_path}" if position_path is not None else None,
            )
            bundle.add(
                "scorecard_methodologies",
                doc,
                "$",
                methodology_id="item:" + cid,
                methodology_text=json_column({field: value for field, value in native.items() if field != "positions"}),
                disclosure_status="partial",
            )
            if not self.criteria_only:
                bundle.add(
                    "scorecard_metric_items",
                    primary,
                    path,
                    metric_id="score",
                    item_id=cid,
                    participation_id="factor",
                    publisher_position_text=stance,
                    position_basis="explicit" if stance is not None else None,
                    contribution_rule_text="Native factors[].effect; no inferred weight or reproduced score",
                )
        if self.criteria_only:
            self._actions(bundle, details, source["name"])
        else:
            self._ratings(bundle, scoring_document, rows, details, source["name"])
        return bundle.finish(
            "Complete catalog/detail arrays reached EOF; unique edition/member/item/factor identities; "
            + (
                "every source factor belongs to the edition and reconciles to a complete criterion action group; "
                if not self.criteria_only
                else "complete literal criterion action groups, with no fabricated ratings; "
            )
            + "entire active/inactive federal catalogs, selected scoring array and all detail objects agree on independent reread",
            declared={
                "member_contexts": len(bundle.tables["scorecard_members"]),
                "items": len(criteria),
                "member_factors": sum(len(r["factors"]) for r in rows),
                "criterion_actions": sum(len(detail[2]) for detail in details.values()),
                "native_numeric_scores": sum("score" in r for r in rows),
                "rendition": "criteria" if self.criteria_only else "detailed",
                "count_basis": "Lengths of complete publisher JSON arrays, not separately stated numeric totals",
            },
        )

    @staticmethod
    def _ratings(bundle, scoring_document, rows, details, period):
        for ordinal, row in enumerate(rows):
            path = f"$[{ordinal}]"
            member, office = row["official"], row["official"]["office"]
            mid = str(member["id"])
            name = " ".join(v for v in [member["givenNames"], member["surname"], member.get("suffix")] if v)
            bundle.add(
                "scorecard_members",
                scoring_document,
                path + ".official",
                publisher_member_key=mid,
                publisher_member_id=mid,
                member_name=name,
                chamber_text=office["electedBody"],
                state=office["state"],
                district=office["electoralDistrict"] or None,
                party=member["party"],
                period_text=period,
                identifiers_json=json_column(
                    [
                        {"scheme": "votervoice_occupancy_id", "value": mid},
                        {"scheme": "votervoice_politician_id", "value": str(member["politicianId"])},
                    ]
                ),
                notes_text=json_column(member),
            )
            value = _scalar(row["score"]) if "score" in row else "N/A"
            bundle.add(
                "scorecard_member_ratings",
                scoring_document,
                path + ".score",
                metric_id="score",
                publisher_member_key=mid,
                value_text=value,
                value_number=decimal_text(value),
                value_status_text=None if "score" in row else "Source client displays N/A for absent score",
                notes_text="Current cumulative profile score is a separate measurement and is not used here",
            )
            for fno, factor in enumerate(row["factors"]):
                cid = factor["criterionId"]
                action = details[cid][2][mid][0]
                result_path = (
                    path
                    + f".factors[{fno}];action_source=capture:{details[cid][0].capture_id}#{details[cid][2][mid][1]}"
                )
                effect = _scalar(factor["effect"])
                bundle.add(
                    "scorecard_member_item_results",
                    scoring_document,
                    result_path,
                    publisher_member_key=mid,
                    item_id=cid,
                    result_id=key(mid, cid),
                    metric_id="score",
                    participation_id="factor",
                    action_text=action,
                    result_text=_scalar(factor.get("position")),
                    contribution_text=effect,
                    contribution_number=decimal_text(effect),
                    reason_text=json_column(factor),
                )

    @staticmethod
    def _actions(bundle, details, period):
        members = {}
        for cid, (doc, native, _actions) in details.items():
            for group_number, group in enumerate(native["positions"]):
                for member_number, member in enumerate(group["officials"]):
                    mid = str(member["occupancyId"])
                    path = f"$.positions[{group_number}].officials[{member_number}]"
                    members.setdefault(mid, []).append((doc, path, member))
                    bundle.add(
                        "scorecard_member_item_results",
                        doc,
                        path,
                        publisher_member_key=mid,
                        item_id=cid,
                        result_id=key(mid, cid),
                        action_text=group["description"],
                        reason_text=json_column(member),
                    )
        for mid, occurrences in members.items():
            doc, path, member = occurrences[0]
            bundle.add(
                "scorecard_members",
                doc,
                path,
                publisher_member_key=mid,
                publisher_member_id=mid,
                member_name=member["displayName"],
                period_text=period,
                identifiers_json=json_column([{"scheme": "votervoice_occupancy_id", "value": mid}]),
                notes_text=json_column([native for _, _, native in occurrences]),
            )


class PPFACriteriaReader(PPFAReader):
    """Complete criterion/member-action rendition without a rating measurement."""

    criteria_only = True
    parser_version = criteria_parser_version


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    return PPFAReader().list_scorecards(context)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    return PPFAReader().acquire_scorecard(edition, context)
