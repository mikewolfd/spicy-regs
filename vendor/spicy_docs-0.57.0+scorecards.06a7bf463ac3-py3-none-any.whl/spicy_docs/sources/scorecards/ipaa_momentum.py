"""IPAA's named Momentum item/action snapshot; browser-computed ratings stay unqualified.

The response repeats and changes member identities, even within a vote. Keep
vote/member occurrences instead of choosing one identity for the whole Congress.
The frozen byte pins establish this rendition, not a continuing live service.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    json_data,
    key,
)

parser_version = "ipaa-momentum-native-items-20261005/1"
HOME = "https://www.ipaa.org/"
INDEX = "https://ipaagrassroots.org/voting-records"
CLIENT = "https://ipaagrassroots.org/_next/static/chunks/204gm1ur7_-nj.js"
CATALOG = "https://admin.mplatform.io/api/v1/ipaa1/vr/bills?withDetail=true"
HOSTS = ("www.ipaa.org", "ipaagrassroots.org", "admin.mplatform.io")
PINS = {
    HOME: "d2fc7739866d6a9d1f5e1b56f672c123b6ea823c8ee0e564977aec7275b511d0",
    INDEX: "5c2cc004dcbc93ca919ed87e757ea3039719d8e3e16f7adf441d623cf258d620",
    CLIENT: "c88b9215ed44446971f49e664ee3abe2c298039827571c0f9e08436606e026b7",
    CATALOG: "40ef59d2779d9cedc739a1208997e41cfb2c912912e1d9838be2b54f1f028666",
}
# Reviewed original vote IDs and occurrence counts, not publisher-declared totals.
# See the pinned private qualification receipt cited in the research guide.
SCOPES = {
    ("119th Congress", "FH"): {2267: 432, 2270: 433, 2271: 433, 2273: 431},
    ("119th Congress", "FS"): {2266: 100, 2269: 100},
    ("118th Congress", "FH"): {2112: 441, 2113: 441, 2114: 441, 2115: 436},
    ("118th Congress", "FS"): {2117: 101, 2116: 102, 2118: 102},
    ("117th Congress", "FH"): {1972: 433},
    ("117th Congress", "FS"): {1980: 101, 1981: 101, 1982: 101, 1983: 101, 1984: 101, 2005: 101, 2102: 101, 2103: 101},
    ("116th Congress", "FH"): {1468: 435, 1469: 435, 1470: 435, 1850: 433, 1851: 433},
    ("116th Congress", "FS"): {1035: 101},
    ("115th Congress", "FH"): {588: 448, 593: 448, 594: 448, 595: 448, 596: 446, 983: 444, 984: 444},
    ("115th Congress", "FS"): {587: 101, 599: 101, 598: 101, 601: 101, 597: 101},
    ("114th Congress", "FH"): {
        298: 450,
        141: 444,
        142: 448,
        143: 448,
        156: 447,
        157: 448,
        146: 450,
        158: 449,
        148: 449,
        149: 450,
        150: 449,
        151: 449,
        152: 449,
    },
    ("114th Congress", "FS"): {127: 101, 128: 101, 374: 101, 129: 101, 297: 101},
    ("113th Congress", "FH"): {
        159: 450,
        160: 450,
        161: 450,
        300: 450,
        162: 446,
        163: 447,
        164: 447,
        165: 448,
        166: 448,
        167: 447,
        275: 448,
    },
}
EDITIONS = tuple(
    ScorecardEdition(
        "ipaa",
        session.split()[0] + "-" + chamber + "-native-items-20261005",
        INDEX,
        f"{session} Key Votes -  {chamber}",
        congress=session,
        chamber=chamber,
        is_current=False,
    )
    for session, chamber in SCOPES
)
BILL_INTS = {"id", "BillID", "Actions", "Versions", "Votes", "PassedFlag", "site_id"}
BILL_TEXT = {
    "StateBillID",
    "StateCode",
    "BillName",
    "Summary",
    "Session",
    "Sponsors",
    "KeyWords",
    "LastAction",
    "ActionDate",
    "BillProgress",
    "Created",
    "mbr_sponsor_ids",
    "mbr_weight",
    "updated_at",
}
BILL_NULLABLE = {"Subjects", "mbr_comments", "mbr_title", "mbr_summary", "mbr_cosponsorship", "featured", "created_at"}
VOTE_INTS = {"id", "VoteID", "YesVotes", "NoVotes", "bill_id"}
VOTE_TEXT = {"Chamber", "Motion", "VoteDate", "mbr_position", "mbr_weight", "disabled", "AbsentVotes", "AbstainVotes"}
MEMBER_INTS = {"LegislatorID", "KnowWhoPersonID", "vote_id"}
MEMBER_TEXT = {"Name", "Party", "District", "Vote"}


def _fields(row, ints, texts, nullable, nested):
    if (
        not isinstance(row, dict)
        or set(row) != ints | texts | nullable | nested
        or any(type(row[k]) is not int for k in ints)
        or any(not isinstance(row[k], str) for k in texts)
        or any(row[k] is not None and not isinstance(row[k], str) for k in nullable)
        or any(not isinstance(row[k], list) for k in nested)
    ):
        raise ScorecardSourceError("IPAA native fields or types changed")


def parse_catalog(document):
    """Validate the actual native tree before selecting a Congress and chamber."""
    rows = json_data(document)
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("IPAA catalogue is not a nonempty complete array")
    bills, votes = set(), set()
    for bill in rows:
        _fields(bill, BILL_INTS, BILL_TEXT, BILL_NULLABLE, {"vote_records"})
        if bill["site_id"] != 1144 or bill["StateCode"] != "US" or bill["id"] in bills or bill["id"] <= 0:
            raise ScorecardSourceError("IPAA bill identity, tenant or federal scope changed")
        bills.add(bill["id"])
        for vote in bill["vote_records"]:
            # OtherVotes is nullable integer, unlike the native text tally fields.
            if not isinstance(vote, dict) or "OtherVotes" not in vote:
                raise ScorecardSourceError("IPAA native vote is missing its tally")
            other = vote["OtherVotes"]
            if other is not None and type(other) is not int:
                raise ScorecardSourceError("IPAA native OtherVotes changed type")
            _fields(
                {k: v for k, v in vote.items() if k != "OtherVotes"},
                VOTE_INTS,
                VOTE_TEXT,
                {"mvr_summary"},
                {"legislators"},
            )
            if (
                vote["id"] <= 0
                or vote["id"] in votes
                or vote["bill_id"] != bill["id"]
                or vote["Chamber"] not in {"FH", "FS"}
                or vote["disabled"] not in {"0", "1"}
                or not vote["legislators"]
            ):
                raise ScorecardSourceError("IPAA native vote identity, relationship or population changed")
            votes.add(vote["id"])
            for member in vote["legislators"]:
                _fields(member, MEMBER_INTS, MEMBER_TEXT, set(), set())
                # Zero KnowWhoPersonID is present in the original, including named
                # members. Preserve it literally; do not resolve or discard it.
                if member["vote_id"] != vote["id"] or member["LegislatorID"] <= 0:
                    raise ScorecardSourceError("IPAA member identity or vote relationship changed")
    return rows


def _read(context, url, stage):
    document = context.read(url, stage="ipaa-momentum:" + stage, hosts=HOSTS)
    if document.url != url or sha256(document.body).hexdigest() != PINS[url]:
        raise ScorecardSourceError("IPAA named original changed; requalify before replacing prior rows")
    if url == CATALOG and (document.response.content_type or "").split(";", 1)[0] != "application/json":
        raise ScorecardSourceError("IPAA catalogue response is not JSON")
    return document


def _scope(rows, edition):
    selected = [
        (bi, bill, vi, vote)
        for bi, bill in enumerate(rows)
        if bill["Session"] == edition.congress
        for vi, vote in enumerate(bill["vote_records"])
        if vote["Chamber"] == edition.chamber
    ]
    actual = {vote["id"]: len(vote["legislators"]) for _, _, _, vote in selected}
    if actual != SCOPES[edition.congress, edition.chamber]:
        raise ScorecardSourceError("IPAA selected vote membership or member occurrence count changed")
    return selected


def list_scorecards(context: ScorecardContext):
    document = _read(context, CATALOG, "discovery")
    rows = parse_catalog(document)
    offered = {(bill["Session"], vote["Chamber"]) for bill in rows for vote in bill["vote_records"]}
    if offered != set(SCOPES):
        raise ScorecardSourceError("IPAA offered item editions changed")
    for edition in EDITIONS:
        _scope(rows, edition)
    return EDITIONS


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition not in EDITIONS:
        raise ScorecardSourceError("IPAA reader requires a named original item edition")
    home = _read(context, HOME, "publisher")
    index = _read(context, INDEX, "index")
    client = _read(context, CLIENT, "client")
    catalog = _read(context, CATALOG, "catalogue")
    selected = _scope(parse_catalog(catalog), edition)
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="Independent Petroleum Association of America",
        parser_version=parser_version,
        rendition_rule="ipaa1-pinned-complete-native-vote-member-occurrences/1",
        homepage=HOME,
    )
    bundle.use(home, "publisher-identity")
    bundle.use(client, "client-selection")
    bundle.use(catalog, "native-items-and-members")
    bundle.tables["scorecard_publishers"][0].update(capture_id=home.capture_id, source_url=home.url)
    first_path = f"$[{selected[0][0]}].Session"
    bundle.tables["scorecards"][0].update(
        edition_label_text=edition.title,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "session",
                    "period_text": edition.congress,
                    "kind": "explicit",
                    "source_path": first_path,
                }
            ]
        ),
        capture_id=catalog.capture_id,
        source_url=catalog.url,
        source_path=first_path,
    )
    seen_bills = set()
    declared = {}
    for bi, bill, vi, vote in selected:
        bill_path = f"$[{bi}]"
        vote_path = f"{bill_path}.vote_records[{vi}]"
        item_id = key("ipaa1", "vote", str(vote["id"]))
        if bill["id"] not in seen_bills:
            seen_bills.add(bill["id"])
            bundle.add(
                "scorecard_methodologies",
                catalog,
                bill_path,
                methodology_id=key("bill", str(bill["id"])),
                methodology_text=json_column({k: v for k, v in bill.items() if k != "vote_records"}),
                disclosure_status="explicit: native bill fields, including weights and source notes",
            )
        native_vote = {k: v for k, v in vote.items() if k != "legislators"}
        bundle.add(
            "scorecard_methodologies",
            catalog,
            vote_path,
            methodology_id=item_id,
            methodology_text=json_column(native_vote),
            chamber_text=vote["Chamber"],
            disclosure_status="explicit: native vote fields; disabled and weight retained without calculating scores",
        )
        declared[str(vote["id"])] = {
            k: vote[k] for k in ("YesVotes", "NoVotes", "OtherVotes", "AbsentVotes", "AbstainVotes")
        }
        bundle.add(
            "scorecard_items",
            catalog,
            vote_path,
            item_id=item_id,
            publisher_item_id=str(vote["VoteID"]),
            title=vote["Motion"],
            item_date_text=vote["VoteDate"],
            congress_text=bill["Session"],
            chamber_text=vote["Chamber"],
            bill_citation_text=bill["StateBillID"],
            references_json=json_column(
                [
                    {
                        "occurrence_id": "StateBillID",
                        "citation_text": bill["StateBillID"],
                        "kind": "bill",
                        "source_path": bill_path + ".StateBillID",
                        "congress_text": bill["Session"],
                        "chamber_text": vote["Chamber"],
                    }
                ]
            ),
            publisher_position_text=vote["mbr_position"],
            position_basis="explicit",
            position_source_path=vote_path + ".mbr_position",
        )
        # Rank duplicate native IDs by full native record, preserving multiplicity.
        # Reordering source arrays cannot silently select a different name variant.
        variants = defaultdict(list)
        for member in vote["legislators"]:
            variants[member["LegislatorID"]].append(json_column(member))
        for values in variants.values():
            values.sort()
        repeats = Counter()
        for mi, member in enumerate(vote["legislators"]):
            path = f"{vote_path}.legislators[{mi}]"
            native = json_column(member)
            repeated = (member["LegislatorID"], native)
            ordinal = variants[member["LegislatorID"]].index(native) + repeats[repeated] + 1
            repeats[repeated] += 1
            member_key = key(item_id, "legislator", str(member["LegislatorID"]), str(ordinal))
            bundle.add(
                "scorecard_members",
                catalog,
                path,
                publisher_member_key=member_key,
                publisher_member_id=str(member["LegislatorID"]),
                identifiers_json=json_column(
                    [
                        {"scheme": "LegislatorID", "value": str(member["LegislatorID"])},
                        {"scheme": "KnowWhoPersonID", "value": str(member["KnowWhoPersonID"])},
                    ]
                ),
                member_name=member["Name"],
                chamber_text=vote["Chamber"],
                district=member["District"],
                party=member["Party"],
                period_text=bill["Session"],
                notes_text=native,
            )
            bundle.add(
                "scorecard_member_item_results",
                catalog,
                path + ".Vote",
                item_id=item_id,
                result_id=member_key,
                publisher_member_key=member_key,
                action_text=member["Vote"],
            )
    reread = _read(context, CATALOG, "stable-reread")
    bundle.use(reread, "native-items-and-members", role="corroboration")
    return bundle.finish(
        "Named 2026-10-05 original: exact publisher, app, client and full-array JSON pins; "
        "valid JSON EOF; every selected Session/Chamber vote ID and its member-occurrence count "
        "match the reviewed capture; every native field within each selected bill/vote/member is retained. "
        "The client selects periods from this full array. Repeated IDs, identity variants and tally "
        "inconsistencies remain literal. A second retained catalogue read matches the pin. "
        "Completeness covers item/action occurrences only, not rendered ratings, lifetime scores, "
        "a chamber roster, other editions or present-day availability.",
        declared={"native_vote_tallies": declared},
    )
