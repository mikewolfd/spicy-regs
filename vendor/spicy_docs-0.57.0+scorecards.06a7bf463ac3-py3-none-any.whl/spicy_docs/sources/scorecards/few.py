"""Federally Employed Women's reviewed original 117th Congress session PDFs."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.interpretation.citations import BILL_NUMBER_PATTERN
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "few-qualified-117-session-pdfs/2"
INDEX = "https://www.few.org/legislative/"
QUALIFIED_SHA256 = "2778461a8240815b6d0354f1bb1a888b664d1b0a4b021aa115de07c82b3887db"
ORIGINALS = {
    "117-first": "https://www.few.org/wp-content/uploads/2022/03/FEW-Legislative-Score-Card-117th-First-Session-2022.pdf",
    "117-second": "https://www.few.org/wp-content/uploads/2023/03/FEWs-Voting-Record-Scorecard-for-the-117th-Congress-Second-Session.pdf",
}
SOURCE_PINS = {
    "117-first": "9d67062dda036b52d92743ea148dc5653ddb86e7f661f3e4fc6c69b783d1f9f9",
    "117-second": "b47cb4809311a9b975be5312fd842d970137905e30b6ec01b9e3136223ff565a",
}
EDITIONS = tuple(
    ScorecardEdition(
        "few",
        edition,
        "https://web.archive.org/web/" + timestamp + "id_/" + ORIGINALS[edition],
        title,
        congress="117",
        chamber="both",
        is_current=False,
    )
    for edition, timestamp, title in (
        ("117-first", "20230803185543", "FEW’s Voting Record Scorecard For the 117th Congress – First Session"),
        (
            "117-second",
            "20230803144019",
            "117th Congress – Second Session Federally Employed Women Voting Record Scorecard",
        ),
    )
)
PAGE_MEMBERS = {
    "117-first": {
        "House": dict(
            zip(
                range(9, 36),
                (
                    17,
                    16,
                    23,
                    21,
                    15,
                    21,
                    16,
                    16,
                    15,
                    14,
                    15,
                    16,
                    17,
                    14,
                    15,
                    15,
                    18,
                    14,
                    19,
                    15,
                    16,
                    14,
                    22,
                    17,
                    15,
                    17,
                    2,
                ),
                strict=True,
            )
        ),
        "Senate": {41: 30, 42: 36, 43: 34},
    },
    "117-second": {
        "House": dict(
            zip(range(9, 26), (16, 27, 29, 26, 26, 27, 26, 26, 28, 24, 28, 29, 28, 26, 30, 26, 12), strict=True)
        ),
        "Senate": {27: 7, 28: 21, 29: 20, 30: 20, 31: 21, 32: 11},
    },
}
PAGE_COUNTS = {"117-first": 43, "117-second": 36}
METHOD_COUNTS = {"117-first": 11, "117-second": 8}
CONTEXT_COUNTS = {
    "117-first": {"honorable-mentions": 153, "farewells": 45},
    "117-second": {"honorable-mentions": 155, "farewells": 76},
}
CONTEXT_PAGES = {
    "117-first": {"honorable-mentions": [4, 5, 6], "farewells": [35, 36, 37]},
    "117-second": {"honorable-mentions": [5, 6], "farewells": [33, 34, 35]},
}
GRID_HEADERS = {
    "117-first": {"House": ("H.R.2119", "H.R.1065", "H.R.5", "H.J.R.17", "H.R.7"), "Senate": ("S.J.Res.13",)},
    "117-second": {
        "House": ("HR 3110", "HR 2617", "S 4524", "HR 2116", "HR 2771"),
        "Senate": ("HR 2471", "S 4524", "HR 2617"),
    },
}
BILLS = re.compile(BILL_NUMBER_PATTERN)
TOKENS = {"117-first": {"Y", "N", "NV", "N/A"}, "117-second": {"Yea", "Nay", "No Vote", "Present", ""}}


@dataclass(frozen=True, slots=True)
class FEWPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document, edition):
    require_reviewed_pdf(
        document,
        source_url=edition.source_url,
        source_sha256=SOURCE_PINS[edition.edition_id],
        message="FEW PDF differs from its reviewed original archived rendition",
    )


def list_scorecards(context):
    for edition in EDITIONS:
        _source(
            context.read(
                edition.source_url,
                stage="scorecards:few:" + edition.edition_id + ":listing",
                hosts=("web.archive.org",),
            ),
            edition,
        )
    return EDITIONS


def _facts(body, edition):
    try:
        data = json.loads(body)
        name = edition.edition_id
        facts = data["editions"][name]
        if (
            data["format_version"] != "few-117-qualified-source-facts/2"
            or facts["source_sha256"] != SOURCE_PINS[name]
            or facts["page_count"] != PAGE_COUNTS[name]
        ):
            raise ValueError
        counts = {(chamber, page): 0 for chamber, pages in PAGE_MEMBERS[name].items() for page in pages}
        identities = set()
        for entry in facts["members"]:
            record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            page = evidence["physical_page"]
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if (
                (chamber, page) not in counts
                or evidence["source_label"] != "pdf-content"
                or evidence["source_ordinal"] != counts[chamber, page]
                or identity in identities
                or not record["member_name_text"]
                or not record["state_text"]
                or not record["notes_text"]
                or record["party_text"] not in {"D", "R", "I"}
                or set(record["results"]) != {str(i) for i in range(1, len(GRID_HEADERS[name][chamber]) + 1)}
                or any(value not in TOKENS[name] for value in record["results"].values())
                or not re.fullmatch(r"\d{1,3}%", record["score_text"])
                or int(record["score_text"][:-1]) > 100
                or (chamber == "Senate" and record["district_text"] is not None)
                or ((name == "117-first" and chamber == "Senate") != (record["term_ends_text"] is not None))
            ):
                raise ValueError
            counts[chamber, page] += 1
            identities.add(identity)
        if counts != {(chamber, page): n for chamber, pages in PAGE_MEMBERS[name].items() for page, n in pages.items()}:
            raise ValueError
        contexts = dict.fromkeys(CONTEXT_COUNTS[name], 0)
        for entry in facts["context"]:
            evidence = entry["evidence"]
            scope = evidence["scope"]
            if (
                scope not in contexts
                or not entry["record"]["source_literal_text"]
                or evidence["source_ordinal"] != contexts[scope]
                or evidence["source_label"] != "pdf-content"
                or evidence["offset_basis"] != "unicode_characters_in_original_defaultreader_native_span_text"
                or not evidence["native_spans"]
                or evidence["physical_pages"]
                != sorted({locator["physical_page"] for locator in evidence["native_spans"]})
                or any(page not in CONTEXT_PAGES[name][scope] for page in evidence["physical_pages"])
                or any(
                    set(locator) != {"physical_page", "native_block", "native_line", "native_span", "start", "end"}
                    or any(type(value) is not int or value < 0 for value in locator.values())
                    or locator["end"] <= locator["start"]
                    for locator in evidence["native_spans"]
                )
            ):
                raise ValueError
            contexts[scope] += 1
        if (
            contexts != CONTEXT_COUNTS[name]
            or not facts["metadata"]["period_statements"]
            or len(facts["methodology"]) != METHOD_COUNTS[name]
        ):
            raise ValueError
        if any(
            not row["record"]["methodology_text"] or row["evidence"]["source_label"] != "pdf-content"
            for row in facts["methodology"]
        ):
            raise ValueError
        for scope in CONTEXT_COUNTS[name]:
            methods = [row for row in facts["methodology"] if row["record"]["scope_text"] == scope]
            if len(methods) != 1:
                raise ValueError
            method = methods[0]
            disclosure = json.loads(method["record"]["methodology_text"])
            if (
                disclosure["context_entries"]
                != [entry for entry in facts["context"] if entry["evidence"]["scope"] == scope]
                or method["evidence"]["physical_pages"] != CONTEXT_PAGES[name][scope]
                or "physical_page" in method["evidence"]
                or not isinstance(disclosure["context_statements"], list)
            ):
                raise ValueError
        for chamber in ("House", "Senate", None):
            entries = [entry for entry in facts["items"] if entry["chamber"] == chamber]
            expected = len(GRID_HEADERS[name][chamber]) if chamber else (5 if name == "117-first" else 3)
            if len(entries) != expected:
                raise ValueError
            grid_ordinals = set()
            for i, entry in enumerate(entries, 1):
                record, evidence = entry["record"], entry["evidence"]
                if (
                    record["ordinal"] != i
                    or evidence["source_ordinal"] != i - 1
                    or evidence["source_label"] != "pdf-content"
                    or not record["title_text"]
                    or not record["description_text"]
                    or not record["native_source_lines"]
                ):
                    raise ValueError
                if record["is_scored"] != bool(chamber):
                    raise ValueError
                if chamber:
                    ordinal = record["grid_ordinal"]
                    weight = "20%" if chamber == "House" else "100%" if name == "117-first" else "33%"
                    if (
                        not isinstance(ordinal, int)
                        or not 1 <= ordinal <= expected
                        or ordinal in grid_ordinals
                        or record["grid_header_text"] != GRID_HEADERS[name][chamber][ordinal - 1]
                        or record["weight_text"] != weight
                        or record["grid_position_text"] != (None if name == "117-first" else "Yea")
                    ):
                        raise ValueError
                    grid_ordinals.add(ordinal)
                elif any(
                    record[field] is not None
                    for field in (
                        "grid_ordinal",
                        "grid_header_text",
                        "grid_position_text",
                        "weight_text",
                        "item_date_text",
                    )
                ):
                    raise ValueError
        return facts
    except (KeyError, TypeError, ValueError, IndexError):
        raise ScorecardSourceError("FEW facts fail the complete reviewed session PDF shape") from None


def _references(record, loc, grid_path):
    references, occurrences = [], []
    for index, match in enumerate(BILLS.finditer(record["description_text"])):
        occurrence = {
            "occurrence_id": f"native-bill-{index}",
            "kind": "bill",
            "citation_text": match[0],
            "bill_citation_text": match[0],
            "source_path": loc + "/description_text",
        }
        references.append(occurrence)
        occurrences.append(
            dict(
                **{name: value for name, value in occurrence.items() if name != "source_path"},
                source_text_field="description_text",
                start=match.start(),
                end=match.end(),
                offset_basis="unicode_characters_in_retained_native_item_text",
            )
        )
    # The source prints this historical long-form citation, rather than H.J.Res.
    historical = re.search(r"(House Joint\s+Resolution 208) of the 92nd Congress", record["description_text"])
    if historical:
        references.append(
            {
                "occurrence_id": "native-historical-resolution",
                "kind": "citation",
                "citation_text": historical[1],
                "congress_text": "92",
                "source_path": loc + "/description_text",
            }
        )
        occurrences.append(
            {
                "occurrence_id": "native-historical-resolution",
                "kind": "citation",
                "citation_text": historical[1],
                "congress_text": "92",
                "source_text_field": "description_text",
                "start": historical.start(1),
                "end": historical.end(1),
                "offset_basis": "unicode_characters_in_retained_native_item_text",
            }
        )
    if record["grid_header_text"]:
        header = record["grid_header_text"]
        references.append(
            {
                "occurrence_id": "native-grid-header",
                "kind": "bill" if BILLS.fullmatch(header) else "citation",
                "citation_text": header,
                "source_path": grid_path + "/grid_header_text",
            }
        )
        occurrences.append(
            {
                "occurrence_id": "native-grid-header",
                "kind": references[-1]["kind"],
                "citation_text": header,
                "source_text_field": "grid_header_text",
                "start": 0,
                "end": len(header),
                "offset_basis": "unicode_characters_in_retained_native_grid_header",
            }
        )
    if record["roll_number_text"]:
        roll = re.search(r"Roll no\. " + re.escape(record["roll_number_text"]) + r"\b", record["description_text"])
        if roll is None:
            raise ScorecardSourceError("FEW explicit roll text is absent from its original narrative")
        references.append(
            {
                "occurrence_id": "native-explicit-roll",
                "kind": "roll_call",
                "citation_text": roll[0],
                "roll_number_text": record["roll_number_text"],
                "chamber_text": "House",
                "congress_text": "117",
                "session_text": "1",
                "source_path": loc + "/description_text",
            }
        )
        occurrences.append(
            {
                "occurrence_id": "native-explicit-roll",
                "kind": "roll_call",
                "citation_text": roll[0],
                "source_text_field": "description_text",
                "start": roll.start(),
                "end": roll.end(),
                "offset_basis": "unicode_characters_in_retained_native_item_text",
            }
        )
    return references, occurrences


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition not in EDITIONS or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("FEW PDF requires a reviewed named edition, semantic facts and private retention")
    name = edition.edition_id
    source = context.read(edition.source_url, stage="scorecards:few:" + name + ":pdf", hosts=("web.archive.org",))
    _source(source, edition)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_PINS[name],
        observations_sha256=QUALIFIED_SHA256,
        stage="few:qualified-" + name,
    )
    facts = _facts(qualified_observations, edition)
    end = context.read(edition.source_url, stage="scorecards:few:" + name + ":pdf-end", hosts=("web.archive.org",))
    _source(end, edition)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Federally Employed Women",
        parser_version=parser_version,
        rendition_rule="few-original-117-session-pdf-native-and-qualified-data-facts/1",
        homepage="https://www.few.org/",
    )
    bundle.use(
        source,
        "members_and_scores",
        "scored_items",
        "member_results",
        "methodology",
        "supplemental_legislation",
        "recognition_and_departure_context",
    )
    bundle.use(
        end, "edition", "members_and_scores", "scored_items", "member_results", "methodology", role="corroboration"
    )
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    card = bundle.tables["scorecards"][0]
    card["session_text"] = "First Session" if name == "117-first" else "Second Session"
    card["published_at_text"] = facts["metadata"]["publication_date_text"]
    card["methodology_url"] = ORIGINALS[name]
    card["timespan_text"] = facts["metadata"]["period_statements"][0]
    card["periods_json"] = json.dumps(
        [
            {
                "occurrence_id": f"native-period-{i}",
                "kind": "explicit",
                "period_text": text,
                "source_path": path(
                    1 if i == 0 else 2 if name == "117-first" else 4, f"/metadata/period_statements/{i}"
                ),
            }
            for i, text in enumerate(facts["metadata"]["period_statements"])
        ],
        ensure_ascii=False,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    for i, entry in enumerate(facts["methodology"]):
        pages = entry["evidence"].get("physical_pages")
        method_path = (
            f"pdf:pages={','.join(str(page) for page in pages)};observation={observation};/methodology/{i}"
            if pages
            else path(entry["evidence"]["physical_page"], f"/methodology/{i}")
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            method_path,
            methodology_id=f"native-method-{i}",
            methodology_text=entry["record"]["methodology_text"],
            methodology_url=ORIGINALS[name],
            disclosure_status=entry["record"]["scope_text"],
        )
    for chamber in ("House", "Senate"):
        page = min(PAGE_MEMBERS[name][chamber])
        bundle.metric(
            source,
            key(chamber, "alignment"),
            "Alignment with FEW" if name == "117-first" else "Score",
            path=path(page, "/score-heading"),
            chamber=chamber,
            unit="percent",
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = facts["metadata"]["period_statements"][0]
    for i, entry in enumerate(facts["items"]):
        record, chamber = entry["record"], entry["chamber"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        item_id = key(chamber or "supplemental", str(record["grid_ordinal"] if chamber else record["ordinal"]))
        grid_loc = path(min(PAGE_MEMBERS[name][chamber]), f"/items/{i}/record") if chamber else loc
        references, occurrences = _references(record, loc, grid_loc)
        # Both literal citations survive the second House HR2771/H.R.2471 conflict.
        bill = (
            record["grid_header_text"]
            if record["grid_header_text"] and BILLS.fullmatch(record["grid_header_text"])
            else next((reference["citation_text"] for reference in references if reference["kind"] == "bill"), None)
        )
        target = record["grid_position_text"] if chamber and name == "117-second" else record["publisher_position_text"]
        position_loc = (
            grid_loc + "/grid_position_text" if chamber and name == "117-second" else loc + "/publisher_position_text"
        )
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=str(record["grid_ordinal"]) if chamber else None,
            item_kind_text="Roll Call Votes Recorded"
            if chamber and name == "117-first"
            else "Votes/Actions"
            if chamber
            else "Bills Introduced and/or Cosponsored"
            if name == "117-first"
            else "More Key FEW Legislation",
            title=record["title_text"],
            item_date_text=record["item_date_text"],
            congress_text="117",
            chamber_text=chamber,
            session_text="1" if name == "117-first" else "2",
            bill_citation_text=bill,
            references_json=json.dumps(references, ensure_ascii=False),
            publisher_position_text=target,
            position_basis="explicit" if target else None,
            position_source_path=position_loc if target else None,
        )
        method_id = key("item", item_id)
        bundle.add(
            "scorecard_methodologies",
            source,
            loc,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_text=json.dumps(dict(**record, citation_occurrences=occurrences), ensure_ascii=False),
            methodology_url=ORIGINALS[name],
            disclosure_status="Literal publisher narrative, grid header/position and weight; source conflicts remain separate, supplemental items do not participate in scores",
        )
        if chamber:
            bundle.add(
                "scorecard_metric_items",
                source,
                path(8 if chamber == "House" else 41, f"/items/{i}/record/weight_text")
                if name == "117-first"
                else grid_loc,
                metric_id=key(chamber, "alignment"),
                item_id=item_id,
                participation_id="publisher-scored-actions",
                methodology_id=method_id,
                publisher_position_text=target,
                position_basis="explicit",
                weight_text=record["weight_text"],
                weight_number=decimal_text(record["weight_text"]),
                counts_toward_metric="true",
            )
    for i, entry in enumerate(facts["members"]):
        record, chamber = entry["record"], entry["chamber"]
        identity = key(chamber, str(entry["evidence"]["physical_page"]), str(entry["evidence"]["source_ordinal"]))
        loc = path(entry["evidence"]["physical_page"], f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=json.dumps(
                {"native_row_notes": json.loads(record["notes_text"]), "term_ends_text": record["term_ends_text"]},
                ensure_ascii=False,
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            loc + "/score_text",
            metric_id=key(chamber, "alignment"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "alignment"),
                participation_id="publisher-scored-actions",
                publisher_member_key=identity,
                result_id="native-action-cell",
                result_text=value,
            )
    return bundle.finish(
        "Complete reviewed original FEW archived session PDF: every authored member/action/percent and separate item, source method, recognition and departure context reconciles against native text and original rendered pages. Source pin, page population, item/header order and independently reviewed semantic asset are required; reread drift refuses. Blank cells, source dates/tallies/citations/term years and 33% weights remain literal. No official IDs/actions, score reproduction, recognition bonuses, live API or whole-archive coverage inferred.",
        declared={
            "physical_pages": PAGE_COUNTS[name],
            "native_rated_rows": len(facts["members"]),
            "native_context_records": len(facts["context"]),
            "native_scored_items": sum(entry["record"]["is_scored"] for entry in facts["items"]),
        },
    )
