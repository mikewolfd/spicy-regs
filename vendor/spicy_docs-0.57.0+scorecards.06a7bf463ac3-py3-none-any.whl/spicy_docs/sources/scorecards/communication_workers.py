"""CWA's explicit annual HTML lists and complete publisher key-vote grids."""

from __future__ import annotations

import re
from urllib.parse import parse_qs, urlsplit

from bs4 import Comment, NavigableString

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "cwa-native-descending-lists-and-key-vote-grids/2"
NAME = "Communications Workers of America"
SITE = "https://scorecard.cwa-union.org"
AUTHORITY = "https://cwa-union.org/cwa-congressional-scorecard"
HOSTS = ("scorecard.cwa-union.org", "cwa-union.org")
YEAR = "2025"
EDITION = ScorecardEdition(
    "communication_workers",
    "2025-native-descending-lists-and-key-vote-grids",
    SITE + "/",
    "CWA Congressional Scorecard — 2025 native lists and key votes",
    year=YEAR,
    chamber="both",
)
CHAMBERS = {"House": "1", "Senate": "2"}
MAX_PAGES = 100


def list_scorecards(context: ScorecardContext):
    return (EDITION,)


def _fail(message):
    raise ScorecardSourceError("CWA " + message)


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _one(nodes, label):
    if len(nodes) != 1:
        _fail(label + " is missing or duplicated")
    return nodes[0]


def _structural(node, names):
    for child in node.children:
        if isinstance(child, Comment):
            continue
        if isinstance(child, NavigableString):
            if child.strip():
                _fail("unexpected visible text in a structural table container")
        elif child.name not in names:
            _fail("unknown table or row structure")


def _html(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        _fail("complete HTML boundary is missing")
    html = soup(document)
    attribution = html.select('meta[property="og:site_name"]')
    item_page = re.fullmatch(r"/scorecard/votes/\d+", urlsplit(document.url).path)
    if (attribution and _one(attribution, "site attribution").get("content") != "CWA Congressional Scorecard") or (
        not attribution and not item_page
    ):
        _fail("scorecard site attribution changed")
    title = _text(_one(html.select("head title"), "source page title"))
    logo = _one(html.select(".navbar-brand img"), "publisher branding")
    if (
        not (title == "CWA Congressional Scorecard" or title.endswith(" | CWA Congressional Scorecard"))
        or logo.get("alt") != "CWA Congressional Scorecard logo"
    ):
        _fail("source title or publisher branding changed")
    return html


def _footer(html):
    node = _one(html.select(".block--cwafooter"), "source footer")
    return {"text": _text(node), "html": str(node), "source_path": ".block--cwafooter"}


def _authority(document):
    if document.url != AUTHORITY or not document.body.rstrip().lower().endswith(b"</html>"):
        _fail("original authority custody or HTML boundary changed")
    html = soup(document)
    title = _one(html.select("main h1"), "original resource heading")
    content = _one(html.select("main .block--cwa-union-content article .block--basic > div"), "original resource body")
    if _text(title) != "CWA Congressional Scorecard" or len(content.select('a[href="' + SITE + '/"]')) != 1:
        _fail("original resource no longer establishes the scorecard application link")
    return {
        "title_text": _text(title),
        "text": _text(content),
        "html": str(content),
        "source_path": "main .block--cwa-union-content article .block--basic > div",
    }


def _application(document):
    if document.url != SITE + "/":
        _fail("application custody changed")
    html = _html(document)
    content = _one(html.select(".block--homepageintro-2 .field--name-body"), "application introduction")
    if _text(_one(content.select("h1"), "application heading")) != "Congressional Vote Scorecard":
        _fail("application title changed")
    return {
        "text": _text(content),
        "html": str(content),
        "source_path": ".block--homepageintro-2 .field--name-body",
        "footer": _footer(html),
    }


def _filters(view):
    container = _one(view.select(".view-filters"), "source filter container")
    _structural(container, {"form"})
    form = _one(view.select("form.views-exposed-form"), "source filters")
    attributes = {
        "form": {"accept-charset", "action", "class", "data-drupal-selector", "id", "method"},
        "fieldset": {"class", "data-drupal-selector", "id"},
        "legend": {"class"},
        "div": {"class", "data-drupal-selector", "id"},
        "input": {
            "class",
            "data-drupal-selector",
            "id",
            "name",
            "maxlength",
            "size",
            "type",
            "value",
            "checked",
            "placeholder",
        },
        "select": {"class", "data-drupal-selector", "id", "name"},
        "option": {"value", "selected"},
        "label": {"class", "for"},
    }
    for node in [form, *form.find_all()]:
        allowed = attributes.get(node.name)
        if allowed is None or set(node.attrs) - allowed:
            _fail("unreviewed explanatory filter structure or note attributes")
        if node.name not in {"label", "legend", "option"}:
            _structural(node, set(attributes))
        elif node.name == "legend" and _text(node):
            _fail("unreviewed explanatory filter legend")
        elif node.name == "label" and (
            not node.get("for")
            or not any(control.get("id") == node.get("for") for control in form.select("input, select"))
        ):
            _fail("unreviewed standalone filter label")
    return [
        {
            "tag": node.name,
            "name": node.get("name"),
            "value": node.get("value"),
            "placeholder_text": node.get("placeholder"),
            "checked": node.has_attr("checked"),
            "label_text": next(
                (_text(label) for label in form.select("label[for]") if label["for"] == node.get("id")), None
            ),
            "options": [
                {"value": option.get("value"), "text": _text(option), "selected": option.has_attr("selected")}
                for option in node.select("option")
            ],
        }
        for node in form.select("input, select")
    ]


def _selected(filters, name):
    fields = [f for f in filters if f["name"] == name]
    if fields and fields[0]["tag"] == "select":
        _one(fields, "source field " + name)
        choices = [o for o in fields[0]["options"] if o["selected"]] or fields[0]["options"][:1]
        return _one(choices, "selected " + name)["value"]
    checked = [f for f in fields if f["checked"]]
    return _one(checked or fields, "selected " + name)["value"]


def _table(view, columns):
    if set(view.attrs) - {"class"}:
        _fail("unreviewed note attributes on a table view")
    _structural(view, {"div", "nav"})
    for child in view.find_all(recursive=False):
        if child.name == "div" and not set(child.get("class", [])) & {"view-filters", "view-content"}:
            _fail("unreviewed explanatory content in a table view")
    content = _one(view.select(".view-content"), "table content")
    if set(content.attrs) - {"class"}:
        _fail("unreviewed note attributes on table content")
    _structural(content, {"div"})
    wrapper = _one(content.find_all("div", recursive=False), "table wrapper")
    if set(wrapper.attrs) - {"class", "data-drupal-views-infinite-scroll-content-wrapper"}:
        _fail("unreviewed note attributes on a table wrapper")
    if "views-infinite-scroll-content-wrapper" in wrapper.get("class", []):
        # The unpaginated key-vote indexes include this publisher Drupal wrapper;
        # member views put their responsive table directly under view-content.
        _structural(wrapper, {"div"})
        wrapper = _one(wrapper.find_all("div", recursive=False), "responsive table wrapper")
        if wrapper.get("class") != ["table-responsive"]:
            _fail("key-vote responsive table wrapper changed")
    _structural(wrapper, {"table"})
    table = _one(wrapper.select("table"), "native table")
    if set(wrapper.attrs) - {"class"} or set(table.attrs) - {"class"}:
        _fail("unreviewed note attributes on a responsive table")
    _structural(table, {"thead", "tbody"})
    head = _one(table.find_all("thead", recursive=False), "table header section")
    if set(head.attrs) - {"class"}:
        _fail("unreviewed note attributes on a table header section")
    _structural(head, {"tr"})
    header_row = _one(head.find_all("tr", recursive=False), "table header row")
    if header_row.attrs:
        _fail("unreviewed note attributes on a table header row")
    _structural(header_row, {"th"})
    headers = header_row.find_all("th", recursive=False)
    for header in headers:
        for node in header.find_all():
            allowed = {"a": {"href", "title"}, "span": {"class"}}.get(node.name)
            if allowed is None or set(node.attrs) - allowed:
                _fail("unreviewed explanatory header structure or note attributes")
            titles = {
                "full-name": {"sort by Name", "sort by Legislator"},
                "state": {"sort by State"},
                "district": {"sort by District"},
                "party": {"sort by Party"},
                "years-score": {"sort by Score"},
                "lifetime-score": {"sort by Lifetime Score"},
                "date": {"sort by Date"},
                "title": {"sort by Legislation"},
                "afl-position": {"sort by CWA Position"},
                "result": {"sort by Result"},
            }
            column = next(
                (c.removeprefix("views-field-") for c in header.get("class", []) if c.startswith("views-field-")), None
            )
            if node.has_attr("title") and node["title"] not in titles.get(column, set()):
                _fail("unreviewed explanatory header title")
    if any(set(header.attrs) - {"class", "id", "scope", "aria-sort"} for header in headers):
        _fail("unreviewed note attributes on a table header")
    if (
        len(headers) != len(columns)
        or [
            next((c.removeprefix("views-field-") for c in h.get("class", []) if c.startswith("views-field-")), None)
            for h in headers
        ]
        != columns
    ):
        _fail("native table columns changed")
    body = _one(table.select("tbody"), "table body")
    if body.attrs:
        _fail("unreviewed note attributes on a table body section")
    _structural(body, {"tr"})
    rows = []
    for ordinal, row in enumerate(body.find_all("tr", recursive=False), 1):
        if row.attrs:
            _fail("unreviewed note attributes on a native row")
        _structural(row, {"td"})
        cells = row.find_all("td", recursive=False)
        if (
            len(cells) != len(columns)
            or [
                next(
                    (c.removeprefix("views-field-") for c in cell.get("class", []) if c.startswith("views-field-")),
                    None,
                )
                for cell in cells
            ]
            != columns
        ):
            _fail("native row columns changed")
        for cell in cells:
            if set(cell.attrs) - {"class", "headers"}:
                _fail("unreviewed note attributes on a native cell")
            for node in cell.find_all():
                allowed = {
                    "a": {"href", "hreflang"},
                    "img": {"class", "src", "loading", "width", "height", "alt"},
                    "div": {"class"},
                    "span": {"class"},
                    "i": {"class"},
                    "br": set(),
                    "time": {"datetime"},
                }.get(node.name)
                if allowed is None or set(node.attrs) - allowed:
                    _fail("unreviewed explanatory cell structure or note attributes")
                if node.name == "img" and node.get("alt", ""):
                    _fail("unreviewed image alternative-text note")
        rows.append((ordinal, dict(zip(columns, cells, strict=True))))
    if not rows:
        _fail("native member or key-vote table is empty; preserve the prior scope")
    return headers, rows


def _pager(view, page):
    pager = view.select("nav.pager")
    if not pager:
        if page:
            _fail("pagination ended without its selected terminal page")
        return {"current_page": 0, "last_page": 0, "has_next": False}
    pager = _one(pager, "pagination")
    if pager.attrs != {"class": ["pager"], "aria-label": "Pagination"}:
        _fail("unreviewed note attributes on pagination")
    _structural(pager, {"ul"})
    listing = _one(pager.find_all("ul", recursive=False), "pagination list")
    if listing.attrs != {
        "class": ["pagination", "pager__items", "js-pager__items", "justify-content-center", "flex-wrap"]
    }:
        _fail("unreviewed pagination list attributes")
    _structural(listing, {"li"})
    for entry in listing.find_all("li", recursive=False):
        if set(entry.attrs) - {"class", "role"}:
            _fail("unreviewed pagination row attributes")
        classes = entry.get("class", [])
        if "pager__item--ellipsis" in classes:
            _structural(entry, {"span"})
            span = _one(entry.find_all("span", recursive=False), "pagination ellipsis")
            if (
                entry.get("role") != "presentation"
                or span.attrs != {"class": ["page-link"]}
                or _text(span) != "…"
                or span.find()
            ):
                _fail("unreviewed explanatory pagination ellipsis")
            continue
        if "role" in entry.attrs:
            _fail("unreviewed explanatory pagination row role")
        _structural(entry, {"a"})
        link = _one(entry.find_all("a", recursive=False), "pagination link")
        if set(link.attrs) - {"class", "href", "title", "rel", "aria-current"}:
            _fail("unreviewed explanatory pagination link attributes")
        for span in link.find_all():
            if (
                span.name != "span"
                or span.attrs not in ({"class": ["visually-hidden"]}, {"aria-hidden": "true"})
                or span.find()
            ):
                _fail("unreviewed explanatory pagination label structure")
        number = _one(parse_qs(urlsplit(link.get("href", "")).query).get("page", []), "pagination page value")
        if not re.fullmatch(r"\d+", number):
            _fail("unknown pagination page value")
        role = next((r for r in ("first", "previous", "next", "last") if "pager__item--" + r in classes), None)
        if role:
            labels = {
                "first": "First page « First",
                "previous": "Previous page ‹ Previous",
                "next": "Next page Next ›",
                "last": "Last page Last »",
            }
            title, label = "Go to " + role + " page", labels[role]
        elif link.get("aria-current") == "page":
            title, label = "Current page", "Current page " + str(int(number) + 1)
        else:
            title, label = "Go to page " + str(int(number) + 1), "Page " + str(int(number) + 1)
        if link.get("title") != title or _text(link) != label:
            _fail("unreviewed explanatory pagination title or label")
    current = _one(pager.select('a[aria-current="page"]'), "current source page")
    links = pager.select("a[href]")
    numbers = []
    for link in links:
        query = parse_qs(urlsplit(link["href"]).query)
        value = _one(query.get("page", []), "pagination page value")
        if not re.fullmatch(r"\d+", value) or int(value) >= MAX_PAGES:
            _fail("source pagination exceeds the reviewed bound")
        numbers.append(int(value))
    if int(_one(parse_qs(urlsplit(current["href"]).query).get("page", []), "current page value")) != page:
        _fail("source repeated or substituted a different page")
    next_link = pager.select("li.pager__item--next a")
    if len(next_link) > 1 or (next_link and int(parse_qs(urlsplit(next_link[0]["href"]).query)["page"][0]) != page + 1):
        _fail("source next-page sequence changed")
    return {"current_page": page, "last_page": max(numbers), "has_next": bool(next_link)}


def _member(cells, chamber):
    node = cells["full-name"]
    link = _one(node.select("a[href]"), "native member link")
    path = urlsplit(link["href"]).path.removeprefix("/index.php")
    match = re.fullmatch(r"/scorecard/legislators/([A-Za-z0-9_-]+)", path)
    if not match or _text(node) != _text(link) or not _text(link):
        _fail("native member identity or unexplained name-cell content changed")
    image_link = _one(cells["image__target-id"].select("a[href]"), "repeated native image identity")
    if urlsplit(image_link["href"]).path.removeprefix("/index.php") != path:
        _fail("image and member links disagree")
    state = _text(cells["state"])
    district = _text(cells["district"]) if chamber == "House" else None
    if not re.fullmatch(r"[A-Z]{2}", state) or (district is not None and not re.fullmatch(r"\d+", district)):
        _fail("native state/district shape changed")
    return {
        "publisher_member_id": match[1],
        "member_name": _text(link),
        "member_link_text": link["href"],
        "state": state,
        "district": district,
        "party": _text(cells["party"]),
    }


def _member_page(document, chamber, page, *, item=False):
    html = _html(document)
    view = _one(
        html.select("main .view-scorecard-legislator-votes" if item else "main .view-scorecard-legislators"),
        "member view",
    )
    filters = _filters(view)
    names = {field["name"] for field in filters if field["name"] is not None}
    expected = {"party", "vote"} if item else {"chamber", "years_target_id", "party", "name"}
    if names != expected:
        _fail("unreviewed member-list or action filter controls")
    if item:
        if _selected(filters, "party") != "All" or _selected(filters, "vote") != "All":
            _fail("member-action view is filtered")
    elif (
        _selected(filters, "chamber") != CHAMBERS[chamber]
        or _selected(filters, "years_target_id") != YEAR
        or _selected(filters, "party") != "All"
        or _selected(filters, "name") != ""
    ):
        _fail("member-list chamber/year was substituted or the roster is filtered")
    columns = [
        "image__target-id",
        "full-name",
        "state",
        *(["district"] if chamber == "House" else []),
        "party",
        *(["position"] if item else ["years-score", "lifetime-score"]),
    ]
    headers, rows = _table(view, columns)
    facts = []
    for ordinal, cells in rows:
        row = _member(cells, chamber)
        row["source_path"] = (
            (".view-scorecard-legislator-votes" if item else ".view-scorecard-legislators")
            + " .view-content table tbody tr:nth-child("
            + str(ordinal)
            + ")"
        )
        if item:
            row["action_text"] = _text(cells["position"])
            if row["action_text"] not in {"Yes", "No", "Not Voting"}:
                _fail("unknown native vote cell")
        else:
            for column in ("years-score", "lifetime-score"):
                value = _text(_one(cells[column].select(".c100 > span"), "native score scalar"))
                if _text(cells[column]) != value or (
                    value not in {"", "%"} and not re.fullmatch(r"\d+(?:\.\d+)?%", value)
                ):
                    _fail("unknown native percentage or additional score-cell note")
                # The filtered originals print six bare percent signs and one
                # blank lifetime cell. Preserve these; never fill from a profile
                # or the separate default-list rendition.
                row[column] = value or None
        facts.append(row)
    return {
        "rows": facts,
        "headers": [_text(h) for h in headers],
        "filters": filters,
        "pagination": _pager(view, page),
        "footer": _footer(html),
    }


def _votes(document, chamber):
    html = _html(document)
    view = _one(html.select("main .view-scorecard-key-votes"), "key-vote view")
    filters = _filters(view)
    if {field["name"] for field in filters if field["name"] is not None} != {"chamber", "year"}:
        _fail("unreviewed key-vote index filter controls")
    if _selected(filters, "chamber") != CHAMBERS[chamber] or _selected(filters, "year") != YEAR:
        _fail("key-vote chamber or year was substituted")
    if view.select("nav.pager"):
        _fail("key-vote index became paginated")
    headers, rows = _table(view, ["date", "title", "afl-position", "result"])
    result = []
    for ordinal, cells in rows:
        link = _one(cells["title"].select("a[href]"), "native key-vote link")
        path = urlsplit(link["href"]).path.removeprefix("/index.php")
        match = re.fullmatch(r"/scorecard/votes/(\d+)", path)
        date = _one(cells["date"].select("time"), "native key-vote date")
        if not match or not date.get("datetime") or not _text(link):
            _fail("key-vote identity or date changed")
        result.append(
            {
                "publisher_item_id": match[1],
                "item_url": SITE + path,
                "title": _text(link),
                "description_text": _text(cells["title"]),
                "description_html": str(cells["title"]),
                "item_date_text": _text(date),
                "datetime_text": date["datetime"],
                "publisher_position_text": _text(cells["afl-position"]),
                "publisher_position_html": str(cells["afl-position"]),
                "result_text": _text(cells["result"]),
                "source_path": ".view-scorecard-key-votes tbody tr:nth-child(" + str(ordinal) + ")",
            }
        )
    if len({r["publisher_item_id"] for r in result}) != len(result):
        _fail("duplicate key-vote identifiers")
    return {
        "items": result,
        "headers": [_text(header) for header in headers],
        "filters": filters,
        "footer": _footer(html),
    }


def _item_context(document, title):
    html = _html(document)
    if _text(_one(html.select("main h1"), "key-vote heading")) != title:
        _fail("key-vote list and detail titles disagree")
    context = _one(html.select("main .scorecard_vote"), "authored key-vote context")
    parent = context.parent
    if set(parent.attrs) - {"class"} or "block--cwau-scorecard-content" not in parent.get("class", []):
        _fail("authored key-vote context wrapper changed")
    _structural(parent, {"div"})
    children = parent.find_all("div", recursive=False)
    if len(children) != 3 or children[0] is not context or children[1].get("id") != "legislator-votes":
        _fail("unreviewed explanatory content around the key-vote grid")
    if children[2].get("class") != ["container", "mt-3", "mb-2"]:
        _fail("key-vote navigation wrapper changed")
    grid = children[1]
    if set(grid.attrs) - {"class", "id"}:
        _fail("unreviewed note attributes around the key-vote grid")
    for expected in ("row", "col-12", "views-element-container", "view-scorecard-legislator-votes"):
        _structural(grid, {"div"})
        grid = _one(grid.find_all("div", recursive=False), "key-vote grid container")
        if set(grid.attrs) - {"class"} or expected not in grid.get("class", []):
            _fail("unreviewed explanatory structure around the key-vote grid")
    label = _text(_one(context.select("h6.scorecard-title"), "key-vote date/bill label"))
    parts = label.split(" | ")
    if len(parts) > 2:
        _fail("key-vote date/bill label changed")
    return {
        "text": _text(context),
        "html": str(context),
        "date_bill_label_text": label,
        "bill_citation_text": parts[1] if len(parts) == 2 and parts[1] else None,
        "source_path": ".scorecard_vote",
    }


def _roster_url(chamber, page):
    # Explicit publisher UI descending sort avoids its observed unstable
    # ascending surname-tie page boundary; uniqueness and full rereads still gate it.
    return (
        SITE + f"/legislators?years_target_id={YEAR}&chamber={CHAMBERS[chamber]}&order=full_name&sort=desc&page={page}"
    )


def _walk(context, url, chamber, *, item=False, title=None):
    records, identities, last = [], set(), None
    for page in range(MAX_PAGES):
        selected = url(page)
        document = context.read(selected, stage="scorecards:communication_workers:member-page", hosts=HOSTS)
        if document.url != selected:
            _fail("member-page custody changed")
        facts = _member_page(document, chamber, page, item=item)
        if title is not None:
            facts["item_context"] = _item_context(document, title)
        # Only page-zero context is emitted. Refuse differing later-page
        # explanations rather than silently dropping an exclusion or note.
        if records and any(
            facts.get(field) != records[0][1].get(field) for field in ("headers", "filters", "footer", "item_context")
        ):
            _fail("native header/filter/footer/item context differs across source pages")
        declaration = facts["pagination"]
        if last is None:
            last = declaration["last_page"]
        if declaration["last_page"] != last:
            _fail("pagination boundary changed during the full source walk")
        for row in facts["rows"]:
            identity = row["publisher_member_id"]
            if identity in identities:
                _fail("duplicate native member ID across source pages; roster not repaired")
            identities.add(identity)
        records.append((document, facts))
        if not declaration["has_next"]:
            if page != last:
                _fail("source walk stopped before the declared terminal page")
            return records
    _fail("pagination did not finish within the bound")


def acquire_scorecard(edition, context):
    if edition != EDITION:
        _fail("only the named qualified 2025 rendition is supported")
    authority = context.read(AUTHORITY, stage="scorecards:communication_workers:authority", hosts=HOSTS)
    authority_facts = _authority(authority)
    primary = context.read(SITE + "/", stage="scorecards:communication_workers:application", hosts=HOSTS)
    application = _application(primary)
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="Named complete2025 publisher descending annual/lifetime member lists and separately complete key-vote grids; native sparse populations and list/profile differences preserved; no invented cells or official identities",
        homepage="https://cwa-union.org/",
    )
    inputs = [(authority, authority_facts, _authority), (primary, application, _application)]
    for document, facts, label in [
        (authority, authority_facts, "original-authority"),
        (primary, application, "original-application"),
    ]:
        bundle.use(document, label)
        bundle.add(
            "scorecard_methodologies",
            document,
            facts["source_path"],
            methodology_id=label,
            methodology_text=json_column(facts),
            disclosure_status="complete selected native context; no inferred methodology",
        )
    members = {}
    declarations = {}
    for chamber, chamber_code in CHAMBERS.items():
        pages = _walk(context, lambda page, ch=chamber: _roster_url(ch, page), chamber)
        declarations[chamber + "_roster_pages"] = len(pages)
        for document, facts in pages:
            inputs.append(
                (document, facts, lambda d, ch=chamber, pg=facts["pagination"]["current_page"]: _member_page(d, ch, pg))
            )
            bundle.use(document, key("member-list", chamber, str(facts["pagination"]["current_page"])))
        first, first_facts = pages[0]
        bundle.add(
            "scorecard_methodologies",
            first,
            ".view-scorecard-legislators",
            methodology_id=key(chamber, "native-list-context"),
            chamber_text=chamber,
            methodology_text=json_column(
                {"headers": first_facts["headers"], "filters": first_facts["filters"], "footer": first_facts["footer"]}
            ),
            disclosure_status="selected native year; current and former members; source score formula undisclosed",
        )
        for column, name, period in [("years-score", "Score", YEAR), ("lifetime-score", "Lifetime Score", None)]:
            bundle.add(
                "scorecard_metrics",
                first,
                ".view-scorecard-legislators thead",
                metric_id=key(chamber, column),
                name=name,
                value_unit_text="%",
                chamber_text=chamber,
                period_text=period,
            )
        for document, facts in pages:
            for row in facts["rows"]:
                identity = (chamber, row["publisher_member_id"])
                members[identity] = row
                member_key = key(*identity)
                bundle.add(
                    "scorecard_members",
                    document,
                    row["source_path"],
                    publisher_member_key=member_key,
                    publisher_member_id=row["publisher_member_id"],
                    member_name=row["member_name"],
                    state=row["state"],
                    district=row["district"],
                    party=row["party"],
                    chamber_text=chamber,
                    identifiers_json="[]",
                    period_text=YEAR,
                    notes_text=json_column({"native_member_link": row["member_link_text"]}),
                )
                for column in ("years-score", "lifetime-score"):
                    bundle.add(
                        "scorecard_member_ratings",
                        document,
                        row["source_path"] + ";cell=" + column,
                        metric_id=key(chamber, column),
                        publisher_member_key=member_key,
                        value_text=row[column],
                        value_number=decimal_text(row[column]),
                        notes_text=json_column({"native_cell_text": ""}) if row[column] is None else None,
                    )
        index_url = SITE + f"/votes?chamber={chamber_code}&year={YEAR}"
        index = context.read(index_url, stage="scorecards:communication_workers:key-vote-index", hosts=HOSTS)
        if index.url != index_url:
            _fail("key-vote index custody changed")
        index_facts = _votes(index, chamber)
        inputs.append((index, index_facts, lambda d, ch=chamber: _votes(d, ch)))
        bundle.use(index, key("key-vote-index", chamber))
        bundle.add(
            "scorecard_methodologies",
            index,
            ".view-scorecard-key-votes",
            methodology_id=key(chamber, "native-vote-index-context"),
            chamber_text=chamber,
            methodology_text=json_column(
                {"headers": index_facts["headers"], "filters": index_facts["filters"], "footer": index_facts["footer"]}
            ),
            disclosure_status="literal native source filters and current/former-member scope",
        )
        for item in index_facts["items"]:
            pages = _walk(
                context,
                lambda page, base=item["item_url"]: base + (f"?page={page}" if page else ""),
                chamber,
                item=True,
                title=item["title"],
            )
            declarations["item_" + item["publisher_item_id"] + "_pages"] = len(pages)
            first, first_facts = pages[0]
            source_context = first_facts["item_context"]
            differing_party_cells = []
            for document, facts in pages:
                if facts["item_context"] != source_context:
                    _fail("key-vote explanation changed across its grid pages")
                inputs.append(
                    (
                        document,
                        facts,
                        lambda d, ch=chamber, pg=facts["pagination"]["current_page"], title=item["title"]: {
                            **_member_page(d, ch, pg, item=True),
                            "item_context": _item_context(d, title),
                        },
                    )
                )
                bundle.use(
                    document,
                    key("key-vote-members", item["publisher_item_id"], str(facts["pagination"]["current_page"])),
                )
                for row in facts["rows"]:
                    identity = (chamber, row["publisher_member_id"])
                    primary_member = members.get(identity)
                    if primary_member is None or any(
                        primary_member[f] != row[f] for f in ("member_name", "state", "district")
                    ):
                        _fail("native list/action identity disagreement; no inferred repair")
                    if primary_member["party"] != row["party"]:
                        differing_party_cells.append(
                            {
                                "publisher_member_id": row["publisher_member_id"],
                                "party_text": row["party"],
                                "source_url": document.url,
                                "source_path": row["source_path"] + ";cell=party",
                            }
                        )
                    bundle.add(
                        "scorecard_member_item_results",
                        document,
                        row["source_path"] + ";cell=position",
                        item_id=item["publisher_item_id"],
                        publisher_member_key=key(*identity),
                        result_id="native-vote",
                        action_text=row["action_text"],
                    )
            bundle.add(
                "scorecard_items",
                index,
                item["source_path"],
                item_id=item["publisher_item_id"],
                publisher_item_id=item["publisher_item_id"],
                item_kind_text="Key Votes",
                title=item["title"],
                item_date_text=item["item_date_text"],
                chamber_text=chamber,
                bill_citation_text=source_context["bill_citation_text"],
                publisher_position_text=item["publisher_position_text"],
                position_basis="explicit",
                position_source_path=item["source_path"] + " td.views-field-afl-position",
            )
            bundle.add(
                "scorecard_methodologies",
                first,
                ".scorecard_vote",
                methodology_id=key("item", item["publisher_item_id"]),
                chamber_text=chamber,
                methodology_text=json_column(
                    {
                        "native_index_fields": item,
                        "native_detail_context": source_context,
                        "native_filter_context": first_facts["filters"],
                        "native_grid_context": {
                            "headers": first_facts["headers"],
                            "footer": first_facts["footer"],
                            "source_path": ".view-scorecard-legislator-votes",
                        },
                        "native_party_cell_occurrences": differing_party_cells,
                    }
                ),
                disclosure_status="complete authored key-vote context; literal source positions, tally, result and differing party-cell text; no inferred preferred Yes/No",
            )
    for document, facts, parse in inputs:
        repeated = context.read(document.url, stage="scorecards:communication_workers:full-native-reread", hosts=HOSTS)
        if repeated.url != document.url or parse(repeated) != facts:
            _fail("native source fields, identity, context or pagination changed during full reread")
        bundle.use(repeated, *bundle.roles[document.capture_id]["field_groups"], role="corroboration")
    return bundle.finish(
        "Complete original authority/application and declared terminal pages of unique native2025descending member lists and every source-listed key-vote grid; all selected native fields and authored contexts rechecked by complete reread; sparse original action populations preserved",
        declared=declarations,
    )
