"""American Bakers' named federal VoterVoice editions and native source criteria."""

from __future__ import annotations

import re
from dataclasses import replace

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardContext, ScorecardEdition, ScorecardSourceError, decimal_text, key
from .votervoice_public import Application, _identifier, _scalar, bootstrap, criterion, read_api, scorings

parser_version = "american-bakers-federal-votervoice/1"
NAME = "American Bakers Association"
INDEX = "https://americanbakers.org/take-action/grassroots-advocacy?vvsrc=%2FScorecard"
PLUGIN = "https://www.votervoice.net/Scripts/LwkAAAAAAAA/Plugin.js"
APP = "https://www.votervoice.net/iframes/ABA/Scorecard"
APPLICATION = Application("american_bakers", INDEX, PLUGIN, APP, "ABA", "2351", NAME, plugin_default_source="/Home")
SUPPORTED = {"2351-1541", "2351-1413"}
ABSENT_DISPLAY = 'y=r("<td>N/A<\\/td>")'
SCORE_DISPLAY = "v.score!==i&&(y.html(v.score),s.score.anySet=!0),s.score.push(y)"
SCORE_HEADING = 'd.append("<th>Score<\\/th>")'


def _display(client):
    code = client.body.decode("utf-8")
    if SCORE_DISPLAY not in code or SCORE_HEADING not in code:
        raise ScorecardSourceError("American Bakers source numeric score display or heading changed")
    literal = ABSENT_DISPLAY.encode()
    offset = client.body.index(literal)
    return {
        "text": "N/A",
        "client_literal": ABSENT_DISPLAY,
        "source_url": client.url,
        "source_path": f"bytes:{offset}-{offset + len(literal)}",
    }


def _catalog(context, headers, suffix=""):
    governments, data = read_api(
        context, "/Governments?association=ABA&activeScorecards=true", headers, "governments" + suffix, APPLICATION
    )
    if data != [{"name": "Federal", "uri": "./USA"}]:
        raise ScorecardSourceError("American Bakers original federal government selection changed")
    documents, records, editions, identities, congresses = [], [], [], set(), set()
    for active in ("true", "false"):
        document, data = read_api(
            context,
            "/Scorecards?association=ABA&government=./USA&active=" + active,
            headers,
            "catalog:" + active + suffix,
            APPLICATION,
        )
        if not isinstance(data, list) or not all(isinstance(row, dict) for row in data):
            raise ScorecardSourceError("American Bakers edition catalog is not a complete array")
        documents.append(document)
        for row in data:
            identity = _identifier(row.get("id"), r"2351-\d+")
            title = row.get("name")
            period = re.fullmatch(r"(\d+)th Congress \((\d{4})-(\d{4})\)", title) if isinstance(title, str) else None
            if not period or int(period[3]) != int(period[2]) + 1 or identity in identities or period[1] in congresses:
                raise ScorecardSourceError("American Bakers literal period or unique edition identity changed")
            items = row.get("criteria")
            if not isinstance(items, list) or not all(isinstance(item, dict) for item in items):
                raise ScorecardSourceError("American Bakers native criterion catalog is absent")
            item_ids = []
            for item in items:
                item_ids.append(_identifier(item.get("id"), r"[MSC]-2351-\d+"))
                if (
                    not isinstance(item.get("name"), str)
                    or not item["name"]
                    or ("billNumber" in item and not isinstance(item["billNumber"], str))
                ):
                    raise ScorecardSourceError("American Bakers literal item name or optional bill citation changed")
            if len(item_ids) != len(set(item_ids)):
                raise ScorecardSourceError("American Bakers native edition repeats a criterion identity")
            records.append((document, row))
            editions.append(
                ScorecardEdition("american_bakers", identity, INDEX, title, congress=period[1], is_current=False)
            )
            identities.add(identity)
            congresses.add(period[1])
    if not records:
        raise ScorecardSourceError("American Bakers observed federal catalog unexpectedly became empty")
    latest = max(int(edition.congress) for edition in editions)
    return governments, documents, records, tuple(replace(e, is_current=int(e.congress) == latest) for e in editions)


def _reconcile(source, rows, details):
    criteria = {item["id"]: item for item in source["criteria"]}
    if not criteria:
        raise ScorecardSourceError("American Bakers named edition lacks configured criteria")
    if any(factor["criterionId"] not in criteria for row in rows for factor in row["factors"]):
        raise ScorecardSourceError("American Bakers factor is outside the selected criterion catalog")
    for identity, item in criteria.items():
        _, detail, actions = details[identity]
        if detail["displayName"] != item["name"]:
            raise ScorecardSourceError("American Bakers criterion detail and edition title disagree")
        factor_members = {
            str(row["official"]["id"]) for row in rows if any(f["criterionId"] == identity for f in row["factors"])
        }
        if not factor_members or factor_members != set(actions):
            raise ScorecardSourceError(
                "American Bakers complete factor/member and native position-group populations disagree"
            )
    if any(not row["factors"] for row in rows):
        raise ScorecardSourceError("American Bakers native member lacks its source scoring factors")


class AmericanBakersReader:
    parser_version = parser_version

    def list_scorecards(self, context: ScorecardContext):
        _, headers = bootstrap(context, APPLICATION)
        return tuple(e for e in _catalog(context, headers)[3] if e.edition_id in SUPPORTED)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        if edition.edition_id not in SUPPORTED:
            raise ScorecardSourceError("American Bakers older offered edition remains catalog-only")
        boot, headers = bootstrap(context, APPLICATION)
        display = _display(boot[3])
        governments, catalogs, records, editions = _catalog(context, headers)
        if edition not in editions:
            raise ScorecardSourceError("American Bakers selected edition is outside its original federal catalog")
        primary, source = next((doc, row) for doc, row in records if row["id"] == edition.edition_id)
        scoring_document, rows = scorings(context, edition, headers, APPLICATION)
        criteria = {item["id"]: item for item in source["criteria"]}
        details = {identity: criterion(context, identity, headers, APPLICATION) for identity in criteria}
        _reconcile(source, rows, details)
        repeated_details = {
            identity: criterion(context, identity, headers, APPLICATION, ":reread") for identity in criteria
        }
        repeated_scoring, repeated_rows = scorings(context, edition, headers, APPLICATION, ":reread")
        final_governments, final_catalogs, final_records, final_editions = _catalog(context, headers, ":reread")
        _reconcile(source, repeated_rows, repeated_details)
        if (
            [row for _, row in records] != [row for _, row in final_records]
            or editions != final_editions
            or rows != repeated_rows
            or any(details[c][1] != repeated_details[c][1] for c in criteria)
        ):
            raise ScorecardSourceError("American Bakers catalog, complete scoring array or criterion changed on reread")
        bundle = Bundle(
            edition,
            context,
            primary,
            publisher_name=NAME,
            parser_version=self.parser_version,
            rendition_rule="Complete named original VoterVoice arrays and criterion positions; source score spelling and native client N/A, no formula",
            homepage="https://americanbakers.org/",
        )
        for number, document in enumerate(boot):
            bundle.use(document, "original-application-attribution:" + str(number))
        bundle.use(governments, "government-selection")
        bundle.use(final_governments, "government-selection", role="corroboration")
        for i, document in enumerate(catalogs):
            bundle.use(document, "federal-catalog:" + str(i))
            bundle.use(final_catalogs[i], "federal-catalog:" + str(i), role="corroboration")
        bundle.use(scoring_document, "native-member-scoring-array")
        bundle.use(repeated_scoring, "native-member-scoring-array", role="corroboration")
        edition_path = "$[id=" + source["id"] + "]"
        bodies = {row["official"]["office"]["electedBody"] for row in rows}
        bundle.tables["scorecards"][0].update(
            edition_label_text=source["name"],
            timespan_text=source["name"],
            chamber_scope_text=next(iter(bodies)) if len(bodies) == 1 else "both",
            source_path=edition_path,
        )
        bundle.add(
            "scorecard_methodologies",
            primary,
            edition_path,
            methodology_id="native-edition",
            methodology_text=json_column(source),
            disclosure_status="Native configured criteria; no disclosed universal score formula",
        )
        heading_offset = boot[3].body.index(SCORE_HEADING.encode())
        bundle.add(
            "scorecard_metrics",
            boot[3],
            f"bytes:{heading_offset}-{heading_offset + len(SCORE_HEADING.encode())}",
            metric_id="score",
            name="Score",
            period_text=source["name"],
            methodology_id="native-edition",
            is_primary=None,
            chamber_text=next(iter(bodies)) if len(bodies) == 1 else None,
        )
        for ordinal, item in enumerate(source["criteria"]):
            identity, path = item["id"], edition_path + f".criteria[{ordinal}]"
            document, detail, _actions = details[identity]
            bundle.use(document, "criterion:" + identity)
            bundle.use(repeated_details[identity][0], "criterion:" + identity, role="corroboration")
            motion = detail.get("legislativeMotion")
            supports = None if motion is None else motion["associationStance"]["supportsMotion"]
            stance = str(supports).lower() if isinstance(supports, bool) else None
            references = []
            if motion:
                for kind, urls in (
                    ("motion", motion["externalUrls"]),
                    ("bill", motion["legislativeProposal"]["externalUrls"]),
                ):
                    for number, url in enumerate(urls):
                        field = "$.legislativeMotion." + ("legislativeProposal." if kind == "bill" else "")
                        references.append(
                            {
                                "occurrence_id": f"{kind}:{number}",
                                "kind": "url",
                                "citation_text": url,
                                "source_path": f"capture:{document.capture_id}#{field}externalUrls[{number}]",
                            }
                        )
            date = re.search(r"\((\d{1,2}/\d{1,2}/\d{4})\)$", item["name"])
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=identity,
                publisher_item_id=identity,
                item_kind_text=detail["positionType"],
                title=item["name"],
                congress_text=edition.congress,
                item_date_text=date[1] if date else None,
                bill_citation_text=item.get("billNumber"),
                references_json=json_column(references),
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                position_source_path=f"capture:{document.capture_id}#$.legislativeMotion.associationStance.supportsMotion"
                if stance is not None
                else None,
            )
            bundle.add(
                "scorecard_methodologies",
                document,
                "$",
                methodology_id="criterion:" + identity,
                methodology_text=json_column(detail),
                disclosure_status="Complete original criterion, explanations, position groups and source omissions",
            )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id="score",
                item_id=identity,
                participation_id="native-factor",
                methodology_id="criterion:" + identity,
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
            )
        for ordinal, row in enumerate(rows):
            member, office, path = row["official"], row["official"]["office"], f"$[{ordinal}]"
            identity = str(member["id"])
            name = " ".join(v for v in (member["givenNames"], member["surname"], member.get("suffix")) if v)
            bundle.add(
                "scorecard_members",
                scoring_document,
                path + ".official",
                publisher_member_key=identity,
                publisher_member_id=identity,
                member_name=name,
                chamber_text=office["electedBody"],
                state=office["state"],
                district=office["electoralDistrict"] or None,
                party=member.get("party"),
                period_text=source["name"],
                identifiers_json=json_column(
                    [
                        {"scheme": "votervoice_occupancy_id", "value": identity},
                        {"scheme": "votervoice_politician_id", "value": str(member["politicianId"])},
                    ]
                ),
                notes_text=json_column(row),
            )
            present = "score" in row
            value = _scalar(row["score"]) if present else "N/A"
            rating_path = (
                path + ".score"
                if present
                else path + f";display_source=capture:{boot[3].capture_id}#" + display["source_path"]
            )
            bundle.add(
                "scorecard_member_ratings",
                scoring_document,
                rating_path,
                metric_id="score",
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value),
                value_status_text=None if present else "N/A",
                notes_text=json_column(
                    {
                        "native_scoring": row,
                        "score_field_present": present,
                        "absent_score_display": None if present else display,
                    }
                ),
            )
            for number, factor in enumerate(row["factors"]):
                criterion_id = factor["criterionId"]
                document, _detail, actions = details[criterion_id]
                action = actions[identity]
                result_path = path + f".factors[{number}];action_source=capture:{document.capture_id}#{action[1]}"
                effect = _scalar(factor["effect"])
                bundle.add(
                    "scorecard_member_item_results",
                    scoring_document,
                    result_path,
                    publisher_member_key=identity,
                    item_id=criterion_id,
                    result_id=key(identity, criterion_id),
                    metric_id="score",
                    participation_id="native-factor",
                    action_text=action[0],
                    result_text=_scalar(factor.get("position")),
                    contribution_text=effect,
                    contribution_number=decimal_text(effect),
                    reason_text=json_column(factor),
                )
        return bundle.finish(
            "Complete original catalog and scoring arrays reached EOF; unique native IDs; every factor/member set reconciles exactly with its complete criterion positions; full arrays and criterion objects reread unchanged. Native missing score remains absent in source notes and uses only the verified client's N/A display; no official roster or score formula is supplied."
        )


def list_scorecards(context):
    return AmericanBakersReader().list_scorecards(context)


def acquire_scorecard(edition, context):
    return AmericanBakersReader().acquire_scorecard(edition, context)
