"""CQ's original 2025 presidential-support and general participation member tables.

The two source-defined populations and their denominators remain separate.
Blank cells, native spellings, party typography and in-year members survive.
"""

import re
from collections import Counter
from dataclasses import replace

from bs4 import Comment, NavigableString

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "cq-native-2025-member-tables/1"
HOSTS = ("media.cq.com",)
ORIGIN = "https://media.cq.com/pub/table/index.php?id="
NAME = "CQ - Roll Call"
KINDS = {
    "presidential-support": {"House": "547", "Senate": "548"},
    "participation": {"House": "553", "Senate": "554"},
}
HEADINGS = {
    "547": "2025 Presidential Support Scores — House",
    "548": "2025 Presidential Support Scores — Senate",
    "553": "Participation 2025: House",
    "554": "Participation 2025: Senate",
}
HEADERS = {
    "547": ("", "SUPPORT", "OPPOSE", "VOTE"),
    "548": ("", "SUPPORT", "OPPOSE", "PARTICIPATION"),
    "553": ("", "ELIGIBLE", "CAST", "VOTE (%)"),
    "554": ("", "ELIGIBLE", "CAST", "VOTE (%)"),
}
DEFINITIONS = {
    "presidential-support": ("PRESIDENTIAL SUPPORT:", "PRESIDENTIAL OPPOSITION:", "VOTE PARTICIPATION:"),
    "participation": ("ELIGIBLE VOTES:", "VOTES CAST:", "PARTICIPATION RATE:"),
}
# Exact observed source cohorts, not publisher-declared or official rosters.
# Each state heading and every source-defined in-year occurrence must reconcile.
_HOUSE_COUNTS = {
    "ALABAMA": 7,
    "ALASKA": 1,
    "AMERICAN SAMOA": 1,
    "ARIZONA": 10,
    "ARKANSAS": 4,
    "CALIFORNIA": 52,
    "COLORADO": 8,
    "CONNECTICUT": 5,
    "DELAWARE": 1,
    "DISTRICT OF COLUMBIA": 1,
    "FLORIDA": 28,
    "GEORGIA": 14,
    "GUAM": 1,
    "HAWAII": 2,
    "IDAHO": 2,
    "ILLINOIS": 17,
    "INDIANA": 9,
    "IOWA": 4,
    "KANSAS": 4,
    "KENTUCKY": 6,
    "LOUISIANA": 6,
    "MAINE": 2,
    "MARYLAND": 8,
    "MASSACHUSETTS": 9,
    "MICHIGAN": 13,
    "MINNESOTA": 8,
    "MISSISSIPPI": 4,
    "MISSOURI": 8,
    "MONTANA": 2,
    "NEBRASKA": 3,
    "NEVADA": 4,
    "NEW HAMPSHIRE": 2,
    "NEW JERSEY": 12,
    "NEW MEXICO": 3,
    "NEW YORK": 26,
    "NORTH CAROLINA": 14,
    "NORTH DAKOTA": 1,
    "NORTHERN MARIANAS": 1,
    "OHIO": 15,
    "OKLAHOMA": 5,
    "OREGON": 6,
    "PENNSYLVANIA": 17,
    "PUERTO RICO": 1,
    "RHODE ISLAND": 2,
    "SOUTH CAROLINA": 7,
    "SOUTH DAKOTA": 1,
    "TENNESSEE": 10,
    "TEXAS": 38,
    "UTAH": 4,
    "VERMONT": 1,
    "VIRGIN ISLANDS": 1,
    "VIRGINIA": 12,
    "WASHINGTON": 10,
    "WEST VIRGINIA": 2,
    "WISCONSIN": 8,
    "WYOMING": 1,
}
_SENATE_COUNTS = {
    "ALABAMA": 2,
    "ALASKA": 2,
    "ARIZONA": 2,
    "ARKANSAS": 2,
    "CALIFORNIA": 2,
    "COLORADO": 2,
    "CONNECTICUT": 2,
    "DELAWARE": 2,
    "FLORIDA": 3,
    "GEORGIA": 2,
    "HAWAII": 2,
    "IDAHO": 2,
    "ILLINOIS": 2,
    "INDIANA": 2,
    "IOWA": 2,
    "KANSAS": 2,
    "KENTUCKY": 2,
    "LOUISIANA": 2,
    "MAINE": 2,
    "MARYLAND": 2,
    "MASSACHUSETTS": 2,
    "MICHIGAN": 2,
    "MINNESOTA": 2,
    "MISSISSIPPI": 2,
    "MISSOURI": 2,
    "MONTANA": 2,
    "NEBRASKA": 2,
    "NEVADA": 2,
    "NEW HAMPSHIRE": 2,
    "NEW JERSEY": 2,
    "NEW MEXICO": 2,
    "NEW YORK": 2,
    "NORTH CAROLINA": 2,
    "NORTH DAKOTA": 2,
    "OHIO": 2,
    "OKLAHOMA": 2,
    "OREGON": 2,
    "PENNSYLVANIA": 2,
    "RHODE ISLAND": 2,
    "SOUTH CAROLINA": 2,
    "SOUTH DAKOTA": 2,
    "TENNESSEE": 2,
    "TEXAS": 2,
    "UTAH": 2,
    "VERMONT": 2,
    "VIRGINIA": 2,
    "WASHINGTON": 2,
    "WEST VIRGINIA": 2,
    "WISCONSIN": 2,
    "WYOMING": 2,
}
REVIEWED_STATE_COUNTS = {
    "547": _HOUSE_COUNTS,
    "548": _SENATE_COUNTS,
    # The participation source includes one additional Florida occurrence.
    "553": {**_HOUSE_COUNTS, "FLORIDA": 29},
    "554": _SENATE_COUNTS,
}
# These source headings lack the usual style. Their exact original row, label,
# blank cells and sibling state sequence establish their role; blanks alone do not.
GROUP_EXCEPTIONS = {"553": {339: "NORTH DAKOTA", 341: "NORTHERN MARIANAS"}}


def edition(kind):
    if kind not in KINDS:
        raise ScorecardSourceError("CQ requires a qualified named 2025 native table rendition")
    return ScorecardEdition(
        "congressional_quarterly",
        "2025-" + kind + "-native-tables",
        ORIGIN + KINDS[kind]["House"],
        "2025 Presidential Support Scores" if kind == "presidential-support" else "Participation 2025",
        year="2025",
        chamber="both",
    )


def list_scorecards(context):
    # Explicit supported rendition selection; this is not a publisher-wide index.
    return tuple(edition(kind) for kind in KINDS)


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("CQ native field is missing or repeated: " + selector)
    return nodes[0]


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _layout(node, children):
    tags = [child.name for child in node.children if getattr(child, "name", None)]
    visible = [
        str(child).strip()
        for child in node.children
        if isinstance(child, NavigableString) and not isinstance(child, Comment)
    ]
    if tags != children or any(visible):
        raise ScorecardSourceError("CQ table contains unreviewed structural content or notes")


def _metadata(document, html, identifier):
    scripts = [
        node for node in html.find_all("script") if re.match(r"\s*if \(window.console\) console.log\(", node.get_text())
    ]
    if len(scripts) != 1 or scripts[0].attrs:
        raise ScorecardSourceError("CQ native table metadata script changed")
    matched = re.fullmatch(
        r"\s*if \(window.console\) console.log\(\s*(\{.*\})\s*\);\s*", scripts[0].get_text(), re.DOTALL
    )
    if matched is None:
        raise ScorecardSourceError("CQ native table metadata is not a literal JSON object")
    # Reuse the existing strict JSON decoder for the literal embedded bytes;
    # this view never becomes another acquisition or public capture.
    data = json_data(SourceDocument(document.capture_id, replace(document.response, body=matched[1].encode())))
    if (
        not isinstance(data, dict)
        or data.get("table_id") != identifier
        or data.get("headline") != HEADINGS[identifier]
        or data.get("columns") != "4"
        or data.get("visible") != "t"
        or data.get("sortable") != "f"
        or data.get("wrapper") != "cq"
        or not isinstance(data.get("chatter"), str)
        or not data["chatter"]
        or any(value is not None and not isinstance(value, str) for value in data.values())
    ):
        raise ScorecardSourceError("CQ selected literal table metadata or unfiltered table shape changed")
    return data


def _facts(document, kind, chamber):
    identifier = KINDS[kind][chamber]
    url = ORIGIN + identifier
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("CQ selected original route changed")
    if (document.response.content_type or "").split(";", 1)[0].strip().lower() != "text/html":
        raise ScorecardSourceError("CQ selected original is not HTML")
    if not document.body.rstrip().lower().endswith(b"</html>") or b"</body>" not in document.body.lower():
        raise ScorecardSourceError("CQ native HTML is incomplete")
    html = soup(document)
    if _text(_one(html, "title")) != "CQ.com - " + HEADINGS[identifier]:
        raise ScorecardSourceError("CQ original title, year or chamber changed")
    _one(html, "html")
    _one(html, "body")
    container = _one(html, "#tableToolContainer")
    if html.select("[class*='pagination'], [class*='pager'], [data-next-page], a[rel='next']"):
        raise ScorecardSourceError("CQ native table exposes an unreviewed partial population")
    area = _one(html, "#contentArea")
    wrapper = _one(html, "#bigWhiteBoxWrapper")
    if container.parent is not area or area.parent is not wrapper:
        raise ScorecardSourceError("CQ native table ownership or context wrapper changed")
    _layout(area, ["div", "script"])
    _layout(wrapper, ["div"])
    display_script = area.find("script", recursive=False)
    if (
        area.attrs != {"id": "contentArea", "class": ["clearfix"]}
        or wrapper.attrs != {"id": "bigWhiteBoxWrapper", "class": ["clearfix"]}
        or display_script.attrs
    ):
        raise ScorecardSourceError("CQ native table context attributes changed")
    table = _one(container, "table")
    if table.attrs != {"id": "table-" + identifier, "tabletooltable": "", "class": ["tableToolTable"]}:
        raise ScorecardSourceError("CQ selected native table identity or attributes changed")
    heading = _one(container, "h2")
    if _text(heading) != HEADINGS[identifier]:
        raise ScorecardSourceError("CQ native table heading changed")
    paragraphs = container.find_all("p", recursive=False)
    extras = (["footnotes"] if identifier == "548" else []) + (["source"] if kind == "presidential-support" else [])
    _layout(container, ["h2", "p", "table"] + ["p"] * len(extras))
    if container.attrs != {"id": "tableToolContainer"} or heading.attrs or len(paragraphs) != 1 + len(extras):
        raise ScorecardSourceError("CQ native table context changed")
    if paragraphs[0].attrs or [p.get("class") for p in paragraphs[1:]] != [[name] for name in extras]:
        raise ScorecardSourceError("CQ native methodology or footnote shape changed")
    metadata = _metadata(document, html, identifier)
    method = paragraphs[0]
    method_view = soup(
        SourceDocument(document.capture_id, replace(document.response, body=metadata["chatter"].encode()))
    )
    if _text(method) != _text(method_view):
        raise ScorecardSourceError("CQ native methodology differs from its source metadata")
    labels = [_text(tag) for tag in method.find_all("strong")]
    if labels != [*DEFINITIONS[kind], "KEY: Republicans"]:
        raise ScorecardSourceError("CQ metric definitions or bold party key changed")
    if any(tag.name not in {"strong", "em", "br"} or tag.attrs for tag in method.find_all()):
        raise ScorecardSourceError("CQ native methodology has an unreviewed markup shape")
    expected_key = "KEY: Republicans Democrats" + (" independents" if chamber == "Senate" else "")
    if not _text(method).endswith(expected_key):
        raise ScorecardSourceError("CQ native plain or italic party key changed")
    italic = method.find_all("em")
    if ([_text(tag) for tag in italic] if italic else []) != (["independents"] if chamber == "Senate" else []):
        raise ScorecardSourceError("CQ native independent party key changed")
    for name in extras:
        if not isinstance(metadata.get(name), str):
            raise ScorecardSourceError("CQ native source or footnote metadata changed")
        node = _one(container, "p." + name)
        if _text(node) != _text(
            soup(SourceDocument(document.capture_id, replace(document.response, body=metadata[name].encode())))
        ):
            raise ScorecardSourceError("CQ native source or footnote differs from its metadata")
    _layout(table, ["thead", "tbody"])
    head, body = _one(table, "thead"), _one(table, "tbody")
    _layout(head, ["tr"])
    header_row = _one(head, "tr")
    _layout(header_row, ["th"] * 4)
    headers = header_row.find_all("th", recursive=False)
    if head.attrs or body.attrs or header_row.attrs or tuple(_text(h) for h in headers) != HEADERS[identifier]:
        raise ScorecardSourceError("CQ native metric columns changed")
    for index, header in enumerate(headers, 1):
        if header.attrs != {"class": ["col" + str(index)]} or header.find():
            raise ScorecardSourceError("CQ native metric column has unreviewed content")
    rows = body.find_all("tr", recursive=False)
    expected = REVIEWED_STATE_COUNTS[identifier]
    _layout(body, ["tr"] * len(rows))
    if len(rows) != len(expected) + sum(expected.values()) or len(body.find_all("tr")) != len(rows):
        raise ScorecardSourceError("CQ complete named table population changed")
    states, members, counts = [], [], Counter()
    state = None
    exceptions = GROUP_EXCEPTIONS.get(identifier, {})
    for ordinal, row in enumerate(rows, 1):
        _layout(row, ["td"] * 4)
        cells = row.find_all("td", recursive=False)
        if set(row.attrs) != {"class"} or len(cells) != 4:
            raise ScorecardSourceError("CQ native row shape or note changed")
        if [c.attrs for c in cells] != [{"class": []}, *[{"class": ["centered"]}] * 3]:
            raise ScorecardSourceError("CQ native cell shape or note changed")
        values = [_text(c) for c in cells]
        location = f"#table-{identifier} > tbody > tr:nth-of-type({ordinal})"
        is_exception = ordinal in exceptions
        is_group = row.get("class") == ["bolded", "shaded"] or is_exception
        if is_group:
            if (
                len(states) >= len(expected)
                or values[0] != list(expected)[len(states)]
                or any(values[1:])
                or any(c.find() for c in cells)
                or (is_exception and (values[0] != exceptions[ordinal] or row.get("class") != []))
            ):
                raise ScorecardSourceError("CQ native state heading or reviewed style exception changed")
            state = values[0]
            states.append(
                {"label": state, "attributes": row.attrs, "source_path": location, "cell_html": [str(c) for c in cells]}
            )
            continue
        if state is None or row.get("class") != [] or not values[0]:
            raise ScorecardSourceError("CQ native member row lacks its original state context")
        tags = cells[0].find_all()
        if (
            len(tags) > 1
            or (tags and (tags[0].name not in {"strong", "em"} or tags[0].attrs))
            or any(c.find() for c in cells[1:])
        ):
            raise ScorecardSourceError("CQ native member party syntax or result notes changed")
        style = tags[0].name if tags else "plain"
        if style == "em" and chamber != "Senate":
            raise ScorecardSourceError("CQ member has unreviewed party presentation")
        if chamber == "House":
            member = re.fullmatch(r"(AL|\d+)\s+(.+)", values[0])
            if member is None:
                raise ScorecardSourceError("CQ native House district/name changed")
            district, name = member.groups()
        else:
            district, name = None, values[0]
        if tags and _text(tags[0]) != name:
            raise ScorecardSourceError("CQ party markup no longer identifies only the printed member name")
        if any(not re.fullmatch(r"\d+|--|", value) for value in values[1:]):
            raise ScorecardSourceError("CQ native metric value has an unreviewed shape")
        counts[state] += 1
        members.append(
            {
                "member_name": name,
                "district": district,
                "state": state,
                "party": {"strong": "Republicans", "plain": "Democrats", "em": "independents"}[style],
                "values": values[1:],
                "source_path": location,
                "native_name_html": str(cells[0]),
                "party_format": style,
                "row_attributes": row.attrs,
            }
        )
    if dict(counts) != expected or [s["label"] for s in states] != list(expected):
        raise ScorecardSourceError("CQ every-state named member cohort did not reconcile")
    footer = _one(html, "#Wrapperfooter")
    if "CQ - Roll Call" not in _text(footer) or "All Rights Reserved." not in _text(footer):
        raise ScorecardSourceError("CQ original publisher/rights footer changed")
    context = {
        "metadata": metadata,
        "display_script": {"text": display_script.get_text(), "source_path": "#contentArea > script"},
        "metadata_source_path": "script[1]/console.log/table-metadata",
        "heading": {"text": _text(heading), "html": str(heading), "source_path": "#tableToolContainer > h2"},
        "methodology": {
            "text": _text(method),
            "html": str(method),
            "source_path": "#tableToolContainer > p:nth-of-type(1)",
        },
        "extra_context": [
            {"text": _text(p), "html": str(p), "source_path": f"#tableToolContainer > p:nth-of-type({i + 2})"}
            for i, p in enumerate(paragraphs[1:])
        ],
        "headers": [
            {
                "text": _text(h),
                "html": str(h),
                "source_path": f"#table-{identifier} > thead > tr > th:nth-of-type({i + 1})",
            }
            for i, h in enumerate(headers)
        ],
        "states": states,
        "footer": {"text": _text(footer), "html": str(footer), "source_path": "#Wrapperfooter"},
    }
    return {"context": context, "members": members}


def acquire_scorecard(selected, context):
    kind = next((kind for kind in KINDS if selected == edition(kind)), None)
    if kind is None:
        raise ScorecardSourceError("CQ requires exact named 2025 rendition metadata")
    documents, facts = {}, {}
    for chamber, identifier in KINDS[kind].items():
        document = context.read(ORIGIN + identifier, stage=f"cq:{kind}:{chamber}:table", hosts=HOSTS)
        documents[chamber], facts[chamber] = document, _facts(document, kind, chamber)
    bundle = Bundle(
        selected,
        context,
        documents["House"],
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="complete named CQ native House/Senate tables; exact state/member cohorts, all literal measurement cells and source-specific definitions/footnotes; full native facts stable on reread",
        homepage="https://www.cq.com/",
    )
    bundle.tables["scorecards"][0].update(edition_label_text="2025", timespan_text="2025")
    for chamber, document in documents.items():
        bundle.use(document, chamber)
        native = facts[chamber]
        method_id = key(chamber, "native-table-context")
        bundle.add(
            "scorecard_methodologies",
            document,
            "#tableToolContainer",
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_url=document.url,
            methodology_text=json_column(native["context"]),
            disclosure_status="explicit",
        )
        for index, label in enumerate(HEADERS[KINDS[kind][chamber]][1:], 2):
            bundle.add(
                "scorecard_metrics",
                document,
                f"#table-{KINDS[kind][chamber]} > thead > tr > th:nth-of-type({index})",
                metric_id=key(chamber, str(index)),
                name=label,
                chamber_text=chamber,
                period_text="2025",
                methodology_id=method_id,
                value_unit_text="votes" if kind == "participation" and index < 4 else "percent",
            )
        occurrences = Counter()
        for member in native["members"]:
            identity = key(chamber, member["state"], member["district"] or "Senate", member["member_name"])
            occurrences[identity] += 1
            member_key = key(identity, str(occurrences[identity]))
            location = member["source_path"]
            bundle.add(
                "scorecard_members",
                document,
                location + " > td:nth-of-type(1)",
                publisher_member_key=member_key,
                member_name=member["member_name"],
                district=member["district"],
                state=member["state"],
                party=member["party"],
                chamber_text=chamber,
                period_text="2025",
                identifiers_json="[]",
                notes_text=json_column({k: member[k] for k in ["native_name_html", "party_format", "row_attributes"]}),
            )
            for index, value in enumerate(member["values"], 2):
                bundle.add(
                    "scorecard_member_ratings",
                    document,
                    location + f" > td:nth-of-type({index})",
                    publisher_member_key=member_key,
                    metric_id=key(chamber, str(index)),
                    value_text=value,
                    value_number=decimal_text(value),
                )
    for chamber, identifier in KINDS[kind].items():
        repeat = context.read(ORIGIN + identifier, stage=f"cq:{kind}:{chamber}:reread", hosts=HOSTS)
        if _facts(repeat, kind, chamber) != facts[chamber]:
            raise ScorecardSourceError(
                "CQ native member cells, metadata, definitions or authored context changed on reread"
            )
        bundle.use(repeat, chamber, role="corroboration")
    return bundle.finish(
        "complete HTML EOF and unpaginated native House/Senate tables; every reviewed state heading and in-year source member occurrence reconciles; all three metric cells per member, including blanks; exact source facts/metadata/context agree on full reread"
    )
