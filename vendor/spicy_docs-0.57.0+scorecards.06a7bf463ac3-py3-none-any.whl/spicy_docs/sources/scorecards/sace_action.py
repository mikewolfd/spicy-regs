"""SACE Action Fund's original regional federal PDF scorecards."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "sace-action-named-original-regional-pdf/1"
HOSTS = ("www.cleanenergyactionfund.org",)
INDEX = "https://www.cleanenergyactionfund.org/news-resources/"
STATES = {"Florida", "Georgia", "North Carolina", "South Carolina", "Tennessee"}
# Measured complete printed publisher populations and exact original pins.
SPECS: dict[str, dict[str, Any]] = {
    "2007": {
        "source": {
            "url": "https://www.cleanenergyactionfund.org/wp-content/uploads/2013/08/SACEAF2007scorecardfinal.pdf",
            "sha256": "49eb01efcba369c2e7e84b410a84320e0db1c8d9eb516d51ec0988ef5e340a8a",
            "page_count": 12,
        },
        "qualified_sha256": "09f534d51d9932277cb4fe6dce6ead0d46407395b16990a1118df433c67b4dcd",
        "title": "2007 Clean Energy & Global Warming Scorecard 1st Session,",
        "year": "2007",
        "period": "2007",
        "congress": "110th Congress",
        "session": "1st Session",
        "member_counts": {"House": 66, "Senate": 10},
        "members_by_page": {"7": 25, "8": 2, "9": 15, "10": 15, "11": 8, "12": 11},
        "item_ids": {"House": ["1", "2", "3", "4", "5", "6", "7", "8"], "Senate": ["1", "2", "3", "4", "5", "6"]},
        "glyph_counts": {"✗": 302, "✓": 265, "no vote": 16, "no vote*": 1, "------": 4},
        "scored_votes_by_chamber": {"House": 8, "Senate": 6},
        "source_headers": {
            "House": [
                "Vote #1: CLEAN Act (oil subsidies repeal)",
                'Vote #2 Coal to Liquids as "Alternative Fuel"',
                "Vote #3 Select Committee on Global Warming",
                "Vote #4 Global Warming Resolution",
                "Vote #5: Clean Energy: RES, tax credits and energy efficiency",
                "Vote #6: RES Amend- ment",
                "Vote #7: Clean Energy: CAFE, RFS, energy efficiency, tax credits, RES",
                "Vote #8: Clean Energy: CAFE, RFS, energy efficiency",
            ],
            "Senate": [
                "Vote #1 Global Warming through water resources",
                "Vote #2: Clean Energy: CAFE, RFS",
                "Vote #3: Biofuels Amendment",
                "Vote #4: Clean Energy: CAFE, RFS, energy efficiency, tax credits, RES",
                "Vote #5: Clean Energy: CAFE, RFS, energy efficiency, tax credits",
                "Vote #6: Clean Energy: CAFE, RFS energy efficiency",
            ],
        },
        "metric_names": {"House": "8 key votes in 2007", "Senate": "6 key votes in 2007"},
    },
    "2008": {
        "source": {
            "url": "https://www.cleanenergyactionfund.org/wp-content/uploads/2013/08/SACEAF2008scorecardfinal.pdf",
            "sha256": "e1e4fe0fea7fe1cf8d191bbe14d96d64dae20feded67ec7326032967fb9b46f3",
            "page_count": 13,
        },
        "qualified_sha256": "5a68d93bba93dbe0f3f63490226804b43bcae9c956b9f0eeca8872de2d9b4ab1",
        "title": "2008 Clean Energy & Global Warming Scorecard 2nd Session,",
        "year": "2008",
        "period": "2008",
        "congress": "110th Congress",
        "session": "2nd Session",
        "member_counts": {"House": 66, "Senate": 10},
        "members_by_page": {"8": 25, "9": 2, "10": 15, "11": 15, "12": 8, "13": 11},
        "item_ids": {"House": ["1", "2", "3", "4", "5", "6", "7"], "Senate": ["1", "2", "3", "4", "5", "6", "7", "8"]},
        "glyph_counts": {"✗": 269, "✓": 245, "no vote": 28},
        "scored_votes_by_chamber": {"House": 7, "Senate": 8},
        "source_headers": {
            "House": [
                "Vote #1: Tax Credits for Clean Renewable Energy (1)",
                "Vote #2 Tax Credits for Clean Renewable Energy (2)",
                "Vote #3 Energy Efficiency: Buildings",
                "Vote #4 Energy Efficiency: RES",
                "Vote #5: High Carbon Fuels: ANWR drilling",
                "Vote #6: High Carbon Fuels: repeal of Sec 526",
                "Vote #7: High Carbon Fuels: offshore drilling",
            ],
            "Senate": [
                "Vote #1: Tax Credits for Clean Renewable Energy (1)",
                "Vote #2 Tax Credits for Clean Renewable Energy (2)",
                "Vote #3 Energy Efficiency investments",
                "Vote #4 Energy Efficiency (LIHEAP and weather- izing",
                "Vote #5: Global Warming (1)",
                "Vote #6: Global Warming (2)",
                "Vote #7: High Carbon Fuels: ANWR drilling",
                "Vote #8: High Carbon Fuels: OCS drilling",
            ],
        },
        "metric_names": {"House": "7 key votes in 2008", "Senate": "8 key votes in 2008"},
    },
    "2009-2010": {
        "source": {
            "url": "https://www.cleanenergyactionfund.org/wp-content/uploads/2013/08/SACEAF2010scorecardfinal.pdf",
            "sha256": "b687204aecd1f9d0b4bfcf3fdf96b8c37e2448874831d26904a1865b8a0927eb",
            "page_count": 12,
        },
        "qualified_sha256": "d2af0d6455149ae696272c9680a21ef589176e395f31200da25af2f03e9b50d7",
        "title": "2009-2010 Clean Energy & Climate Action Scorecard",
        "year": None,
        "period": "2009-2010",
        "congress": "111th Congress",
        "session": None,
        "member_counts": {"House": 68, "Senate": 11},
        "members_by_page": {"7": 24, "8": 5, "9": 16, "10": 15, "11": 8, "12": 11},
        "item_ids": {"House": ["1", "2", "3 & 4", "5"], "Senate": ["1", "2", "3", "4", "5"]},
        "glyph_counts": {"✗": 189, "✓": 119, "no vote": 6, "---": 13},
        "scored_votes_by_chamber": {"House": 5, "Senate": 5},
        "source_headers": {
            "House": [
                "Vote #1: Clean Energy & Energy Efficient Recovery",
                "Vote #2 Clean Energy Budget Priorities",
                "Votes #3 & #4: Climate Pollution Reductions",
                "Vote #5: High-Risk Energy & Offshore Drilling Reforms",
            ],
            "Senate": [
                "Vote #1: Clean Energy & Energy Efficient Recovery",
                "Vote #2 Clean Energy Budget Priorities",
                "Vote #3: Climate Change & National Security",
                "Vote #4: Offshore Drilling",
                "Vote #5: Clean Air Act Protections",
            ],
        },
        "metric_names": {"House": "5 key votes in 2009-2010", "Senate": "5 key votes in 2009-2010"},
    },
    "2011": {
        "source": {
            "url": "https://www.cleanenergyactionfund.org/wp-content/uploads/2013/08/SACEAF2011scorecardfinal.pdf",
            "sha256": "aac8689588a787dc6402837aa6f8f210f43352681bc8488ba787004992ba2255",
            "page_count": 11,
        },
        "qualified_sha256": "f681193582a56fa20cd1cb62fc87ec724856b855adbaa46c54cc14589fa52050",
        "title": "2011 Clean Energy & Climate Action Scorecard",
        "year": "2011",
        "period": "2011",
        "congress": "112th Congress",
        "session": "first session",
        "member_counts": {"House": 66, "Senate": 10},
        "members_by_page": {"6": 25, "7": 2, "8": 15, "9": 15, "10": 8, "11": 11},
        "item_ids": {"House": ["1", "2", "3", "4", "5"], "Senate": ["1", "2", "3", "4"]},
        "glyph_counts": {"✗": 258, "✓": 106, "no vote": 6},
        "scored_votes_by_chamber": {"House": 5, "Senate": 4},
        "source_headers": {
            "House": [
                "Vote #1: Clean Air Act roll backs",
                "Vote #2: Confirming scientific basis of climate science",
                "Vote #3: Energy Efficiency repeals",
                "Vote #4: Urging support for the Keystone Pipeline",
                "Vote #5: Requiring coal ash stnds to protect health",
            ],
            "Senate": [
                "Vote #1: Clean Air Act roll backs",
                "Vote #2 End Corn Ethanol Tax Credit",
                "Vote #2 Closing Big Oil Tax Loophole",
                "Vote #3: Block implementation of CSAPR",
            ],
        },
        "metric_names": {"House": "5 key votes in 2011", "Senate": "4 key votes in 2011"},
    },
    "2012": {
        "source": {
            "url": "https://www.cleanenergyactionfund.org/wp-content/uploads/2013/08/SACEAF2012scorecardfinal.pdf",
            "sha256": "2c8ce88d2fa2102b3751cf74d7a4d5c1c58efcfb0beac4df12b546c7d9abc789",
            "page_count": 11,
        },
        "qualified_sha256": "9dde39c0c7f6415216ca57d5550bb99a10431c5c6be45105b701e4113e73e3ee",
        "title": "2012 Clean Energy & Climate Action Scorecard",
        "year": "2012",
        "period": "2012",
        "congress": "112th Congress",
        "session": "second session",
        "member_counts": {"House": 66, "Senate": 10},
        "members_by_page": {"6": 25, "7": 2, "8": 15, "9": 15, "10": 8, "11": 11},
        "item_ids": {"House": ["1", "2", "3", "4"], "Senate": ["1", "2", "3", "4"]},
        "glyph_counts": {"✗": 210, "no vote": 7, "✓": 87},
        "scored_votes_by_chamber": {"House": 4, "Senate": 4},
        "source_headers": {
            "House": [
                "Vote #1: Climate Change Education Program defunding",
                "Vote #2: Office of EE & RE defunding",
                "Vote #3: Inadequate Coal Ash Regulations",
                "Vote #4: Expediting the Keystone Pipeline",
            ],
            "Senate": [
                "Vote #1: Repeal of Big Oil Tax Subsidies",
                "Vote #2: Renewable Energy incentives",
                "Vote #3: Reversal of the Mercury Standard",
                "Vote #4: Expediting the Keystone Pipeline",
            ],
        },
        "metric_names": {"House": "4 key votes in 2012", "Senate": "4 key votes in 2012"},
    },
}


def _spec(identifier: str) -> dict[str, Any]:
    if identifier not in SPECS:
        raise ScorecardSourceError("SACE Action Fund requires a reviewed named original edition")
    return SPECS[identifier]


def _edition(identifier: str) -> ScorecardEdition:
    spec = _spec(identifier)
    return ScorecardEdition(
        "sace_action",
        identifier,
        spec["source"]["url"],
        spec["title"],
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    require_reviewed_pdf(
        document,
        source_url=spec["source"]["url"],
        source_sha256=spec["source"]["sha256"],
        message="SACE Action Fund PDF differs from its reviewed original edition",
        trailer_window=1024,
    )


def _evidence(evidence, spec):
    if (
        not isinstance(evidence["physical_pages"], list)
        or not evidence["physical_pages"]
        or any(type(p) is not int or not 1 <= p <= spec["source"]["page_count"] for p in evidence["physical_pages"])
        or evidence["schema_version"] not in {"sace-action-pdf-facts/2", "sace-action-pdf-members/1"}
        or not isinstance(evidence["outcome_file"], str)
        or not evidence["outcome_file"]
        or not re.fullmatch(r"[0-9a-f]{64}", evidence["outcome_sha256"])
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("SACE Action Fund observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "sace-action-qualified-pdf/1"
            or data["edition_key"] != identifier
            or data["source"] != spec["source"]
            or data["member_counts"] != spec["member_counts"]
            or data["members_by_page"] != spec["members_by_page"]
            or data["item_ids"] != spec["item_ids"]
            or data["glyph_counts"] != spec["glyph_counts"]
            or data["source_headers"] != spec["source_headers"]
            or data["scored_votes_by_chamber"] != spec["scored_votes_by_chamber"]
            or data["uncertainties"]
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["title_text"] != spec["title"]
            or front["period_text"] != spec["period"]
            or front["congress_text"] != spec["congress"]
            or front["session_text"] != spec["session"]
            or set(front["region_states"]) != STATES
            or not front["methodology_text"]
            or not front["publisher_name_text"]
            or not {"✓", "✗", "no vote"} <= set(front["legend"])
            or any(not isinstance(v, str) or not v for v in front["legend"].values())
        ):
            raise ValueError
        items, item_counts, item_columns = set(), Counter(), {}
        for entry in data["items"]:
            _evidence(entry["evidence"], spec)
            r = entry["record"]
            chamber, identifier_ = r["chamber_text"], r["item_id_text"]
            if (
                chamber not in spec["item_ids"]
                or identifier_ not in spec["item_ids"][chamber]
                or (chamber, identifier_) in items
                or any(
                    not isinstance(r[f], str) or not r[f]
                    for f in [
                        "publisher_item_id_text",
                        "source_item_label_text",
                        "title_text",
                        "source_column_label_text",
                        "source_column_number_text",
                        "publisher_position_text",
                        "source_native_text",
                    ]
                )
                or r["source_column_label_text"]
                != spec["source_headers"][chamber][spec["item_ids"][chamber].index(identifier_)]
                or not re.fullmatch(r"[1-9]\d*", r["roll_number_text"])
                or (r["date_text"] is not None and (not isinstance(r["date_text"], str) or not r["date_text"]))
                or r["source_weighting_phrase"]
                != (
                    "double counting"
                    if identifier == "2009-2010" and chamber == "House" and identifier_ == "3 & 4"
                    else None
                )
                or any(c["kind"] not in {"bill", "amendment"} or not c["citation_text"] for c in r["citations"])
                or any(
                    not v["citation_text"]
                    or v["chamber_text"] not in {"House", "Senate"}
                    or not re.fullmatch(r"[1-9]\d*", v["roll_number_text"])
                    for v in r["roll_references"]
                )
                or not any(
                    v["chamber_text"] == chamber and v["roll_number_text"] == r["roll_number_text"]
                    for v in r["roll_references"]
                )
            ):
                raise ValueError
            items.add((chamber, identifier_))
            item_columns[(chamber, identifier_)] = r["source_column_number_text"]
            item_counts[chamber] += 1
        if dict(item_counts) != {c: len(ids) for c, ids in spec["item_ids"].items()}:
            raise ValueError
        identities, counts, pages, glyphs = set(), Counter(), Counter(), Counter()
        for entry in data["members"]:
            _evidence(entry["evidence"], spec)
            if entry["name_correction_evidence"] is not None:
                _evidence(entry["name_correction_evidence"], spec)
            r = entry["record"]
            chamber = r["chamber_text"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or r["state_text"] not in STATES
                or r["party_text"] not in {"D", "R", None}
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or (chamber == "House" and not re.fullmatch(r"(?:FL|GA|NC|SC|TN)\d\d", r["district_text"]))
                or (chamber == "Senate" and r["district_text"] is not None)
                or (r["value_text"] is not None and not re.fullmatch(r"\d+%(?:\*|\d+)?|NA|N/A|—|–", r["value_text"]))
                or len(entry["evidence"]["physical_pages"]) != 1
                or [v["item_id_text"] for v in r["item_results"]] != spec["item_ids"][chamber]
                or any(
                    v["result_text"] not in (set(spec["glyph_counts"]) - {"source-blank"}) | {None}
                    for v in r["item_results"]
                )
                or any(
                    v["source_column_number_text"] != item_columns[(chamber, v["item_id_text"])]
                    for v in r["item_results"]
                )
                or any(
                    v["source_column_label_text"] != spec["source_headers"][chamber][i]
                    for i, v in enumerate(r["item_results"])
                )
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[str(entry["evidence"]["physical_pages"][0])] += 1
            glyphs.update("source-blank" if v["result_text"] is None else v["result_text"] for v in r["item_results"])
        if (
            dict(counts) != spec["member_counts"]
            or dict(pages) != spec["members_by_page"]
            or dict(glyphs) != spec["glyph_counts"]
        ):
            raise ValueError
        for note in data["footnotes"]:
            if (
                type(note["physical_page"]) is not int
                or not 1 <= note["physical_page"] <= spec["source"]["page_count"]
                or not note["text"]
            ):
                raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "SACE Action Fund facts do not establish the complete reviewed regional rendition"
        ) from error


@dataclass(frozen=True, slots=True)
class SACEPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError(
                "SACE Action Fund observations must identify a reviewed named edition"
            ) from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("SACE Action Fund PDF redistribution rights are not established")
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["source"]["url"], stage=f"sace_action:{self.edition_key}:list", hosts=HOSTS), spec)
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError("SACE Action Fund reader requires its exact configured named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != _edition(edition.edition_id):
        raise ScorecardSourceError("SACE Action Fund requires the exact reviewed named edition")
    if context.evidence_policy == "full":
        raise ScorecardSourceError("SACE Action Fund PDF redistribution rights are not established")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("SACE Action Fund requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    primary = context.read(spec["source"]["url"], stage=f"sace_action:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(primary, spec)
    observation = retain_qualified(
        primary,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source"]["sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"sace_action:{edition.edition_id}:qualified-observations",
    )

    def location(entry, pointer):
        return f"pdf:pages={','.join(str(p) for p in entry['evidence']['physical_pages'])};observation={observation};{pointer}/record"

    front = data["front"]["record"]
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name=front["publisher_name_text"],
        parser_version=parser_version,
        rendition_rule="complete named original regional PDF: every source member, native score and printed action cell, item fact, source footnote and label conflict; stable original reread",
        homepage="https://www.cleanenergyactionfund.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        timespan_text=front["period_text"], session_text=front["session_text"], methodology_url=primary.url
    )
    front_path = location(data["front"], "/front")
    for chamber in spec["item_ids"]:
        method_id = key(chamber, "regional-methodology")
        bundle.add(
            "scorecard_methodologies",
            primary,
            front_path,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_url=primary.url,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    **front,
                    "printed_columns": data["source_headers"][chamber],
                    "source_scored_votes": data["scored_votes_by_chamber"][chamber],
                }
            ),
        )
        bundle.add(
            "scorecard_metrics",
            primary,
            front_path,
            metric_id=key(chamber, "score"),
            name=spec["metric_names"][chamber],
            value_unit_text="%",
            chamber_text=chamber,
            period_text=front["period_text"],
            methodology_id=method_id,
        )
    for i, note in enumerate(data["footnotes"]):
        path = f"pdf:pages={note['physical_page']};observation={observation};/footnotes/{i}"
        bundle.add(
            "scorecard_methodologies",
            primary,
            path,
            methodology_id=key("printed-footnote", str(i)),
            disclosure_status="explicit",
            methodology_text=note["text"],
        )
    for i, entry in enumerate(data["items"]):
        r = entry["record"]
        chamber, item_id = r["chamber_text"], key(r["chamber_text"], r["item_id_text"])
        path = location(entry, f"/items/{i}")
        references = [
            {
                "occurrence_id": f"{c['kind']}:{j}",
                "kind": c["kind"],
                "citation_text": c["citation_text"],
                "source_path": path + f"/citations/{j}",
                "chamber_text": chamber,
                c["kind"] + "_citation_text": c["citation_text"],
            }
            for j, c in enumerate(r["citations"])
        ]
        references.extend(
            {"occurrence_id": f"roll_call:{j}", "kind": "roll_call", **v, "source_path": path + f"/roll_references/{j}"}
            for j, v in enumerate(r["roll_references"])
        )
        method_id = key(chamber, "item", r["item_id_text"])
        public_method = {k: v for k, v in r.items() if k != "source_native_text"}
        # The complete original paragraph remains in private reviewed evidence.
        # Public methodology retains facts, source numbering and weighting text.
        bundle.add(
            "scorecard_methodologies",
            primary,
            path,
            methodology_id=method_id,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(public_method),
        )
        bundle.add(
            "scorecard_items",
            primary,
            path,
            item_id=item_id,
            publisher_item_id=r["publisher_item_id_text"],
            item_kind_text="Vote",
            title=r["title_text"],
            item_date_text=r["date_text"],
            chamber_text=chamber,
            congress_text=front["congress_text"],
            session_text=front["session_text"],
            roll_number_text=r["roll_number_text"],
            bill_citation_text=next((c["citation_text"] for c in r["citations"] if c["kind"] == "bill"), None),
            amendment_citation_text=next(
                (c["citation_text"] for c in r["citations"] if c["kind"] == "amendment"), None
            ),
            references_json=json_column(references),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            primary,
            path,
            metric_id=key(chamber, "score"),
            item_id=item_id,
            participation_id="printed-voting-column",
            methodology_id=method_id,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
        )
    for i, entry in enumerate(data["members"]):
        r = entry["record"]
        chamber = r["chamber_text"]
        path = location(entry, f"/members/{i}")
        member_key = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text=front["period_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "original_value_text": r["value_text"],
                    "source_footnote_ids_on_page": [
                        key("printed-footnote", str(j))
                        for j, note in enumerate(data["footnotes"])
                        if note["physical_page"] in entry["evidence"]["physical_pages"]
                    ],
                    "source_scope": "printed regional delegation; replacement and tenure rows remain literal",
                }
            ),
        )
        value = "N/A" if r["value_text"] == "NA" else r["value_text"]
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + "/value_text",
            publisher_member_key=member_key,
            metric_id=key(chamber, "score"),
            value_text=value,
            value_number=decimal_text(value),
            value_status_text=value if value in {"N/A", "—", "–"} else None,
        )
        for j, cell in enumerate(r["item_results"]):
            bundle.add(
                "scorecard_member_item_results",
                primary,
                path + f"/item_results/{j}",
                result_id="printed-cell",
                publisher_member_key=member_key,
                item_id=key(chamber, cell["item_id_text"]),
                metric_id=key(chamber, "score"),
                participation_id="printed-voting-column",
                result_text=cell["result_text"],
                reason_text=front["legend"].get(cell["result_text"]),
            )
    repeated = context.read(spec["source"]["url"], stage=f"sace_action:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete original regional printed scorecard, all source scores and action cells, native label conflicts and footnotes; original PDF reread identically",
        declared={
            "members_by_chamber": spec["member_counts"],
            "members_by_page": spec["members_by_page"],
            "item_ids_by_chamber": spec["item_ids"],
            "glyph_counts": spec["glyph_counts"],
            "source_scored_votes_by_chamber": spec["scored_votes_by_chamber"],
            "printed_columns_by_chamber": spec["source_headers"],
            "source_counts_basis": "complete printed Florida/Georgia/North Carolina/South Carolina/Tennessee delegation; no national roster claim",
        },
    )
