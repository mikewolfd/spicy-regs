"""Named AFGE annual PDFs, from reviewed complete native and semantic facts."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar, TypedDict

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "afge-named-annual-qualified-pdf/1"
INDEX = "https://www.afge.org/take-action/afge-on-capitol-hill/issue-papers--voting-records/"
HOSTS = ("www.afge.org",)


class EditionSpec(TypedDict):
    url: str
    source_sha256: str
    observations_sha256: str
    pages: int
    members: dict[str, int]
    items: dict[str, int]
    member_pages: dict[str, dict[str, int]]
    year: str
    congress: str
    congress_label: str
    session: str
    session_label: str


QUALIFIED_EDITIONS: dict[str, EditionSpec] = {
    "2015": {
        "url": "https://www.afge.org/globalassets/documents/issue-papers/2015-voting-record.pdf",
        "source_sha256": "0505350304758c0681cc13d42e2edbfa3a67524cb055d71baf81c3834d4b6daa",
        "observations_sha256": "9ec2094650d76cb3ce24160f8f4768f7080256b1adfe8032f9b57d6b61787a08",
        "pages": 56,
        "members": {"House": 435, "Senate": 100},
        "items": {"House": 17, "Senate": 11},
        "member_pages": {
            "House": {
                "17": 18,
                "18": 20,
                "19": 22,
                "20": 21,
                "21": 19,
                "22": 21,
                "23": 18,
                "24": 21,
                "25": 19,
                "26": 19,
                "27": 20,
                "28": 18,
                "29": 18,
                "30": 19,
                "31": 22,
                "32": 19,
                "33": 19,
                "34": 19,
                "35": 20,
                "36": 22,
                "37": 19,
                "38": 19,
                "39": 3,
            },
            "Senate": {"49": 18, "50": 18, "51": 18, "52": 18, "53": 18, "54": 10},
        },
        "year": "2015",
        "congress": "114",
        "congress_label": "114th Congress",
        "session": "1",
        "session_label": "first session",
    },
}
LEGEND = {"R": "Voted With AFGE", "W": "Voted Against AFGE", "?": "Did Not Vote", "I": "Not In Office"}
CITATION = re.compile(
    r"\b(?:H\.\s*(?:R\.|(?:J\.|Con\.)?\s*Res\.|Amdt\.)|S\.\s*(?:(?:J\.|Con\.)\s*Res\.|Amdt\.)?)\s*\d+\b"
)
SCHEMAS = {
    "afge-annual-pdf-front-facts/1",
    "afge-annual-pdf-item-data-facts/2",
    "afge-annual-pdf-member-facts/1",
    "afge-annual-pdf-native-reviewed-facts/1",
}


def _edition(identifier: str) -> ScorecardEdition:
    spec = QUALIFIED_EDITIONS[identifier]
    return ScorecardEdition(
        "afge",
        identifier,
        spec["url"],
        spec["year"] + " VOTING RECORD",
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document: SourceDocument, spec: EditionSpec) -> None:
    if (
        document.url != spec["url"]
        or not document.body.startswith(b"%PDF-")
        or b"%%EOF" not in document.body[-4096:]
        or sha256(document.body).hexdigest() != spec["source_sha256"]
    ):
        raise ScorecardSourceError("AFGE annual PDF differs from the complete reviewed original")


def _evidence(evidence: dict, spec: EditionSpec) -> None:
    pages = evidence["physical_pages"]
    if (
        not isinstance(pages, list)
        or not pages
        or len(pages) != len(set(pages))
        or any(type(p) is not int or not 1 <= p <= spec["pages"] for p in pages)
        or evidence["schema_version"] not in SCHEMAS
        or not isinstance(evidence["json_pointer"], str)
        or not evidence["json_pointer"].startswith("/")
        or any(not re.fullmatch(r"[0-9a-f]{64}", evidence[k]) for k in ["outcome_sha256", "observation_sha256"])
    ):
        raise ValueError


def _qualified(body: bytes) -> tuple[dict, EditionSpec]:
    try:
        if not isinstance(body, bytes):
            raise TypeError
        data = json.loads(body)
        spec = QUALIFIED_EDITIONS[data["edition_key"]]
        if (
            sha256(body).hexdigest() != spec["observations_sha256"]
            or data["format_version"] != "afge-qualified-annual-pdf/1"
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["pages"]
            or data["member_counts"] != spec["members"]
            or data["item_counts"] != spec["items"]
            or data["member_page_counts"] != spec["member_pages"]
            or set(data["column_titles"]) != set(spec["items"])
            or any(
                len(data["column_titles"][c]) != n or any(not title for title in data["column_titles"][c])
                for c, n in spec["items"].items()
            )
        ):
            raise ValueError
        _evidence(data["front"]["evidence"], spec)
        front = data["front"]["record"]
        if (
            front["title_text"] != spec["year"] + " VOTING RECORD"
            or front["year_text"] != spec["year"]
            or front["congress_text"] != spec["congress_label"]
            or front["session_text"] != spec["session_label"]
            or front["score_label_text"] != "AFGE Score (%)"
            or front["score_unit_text"] != "%"
            or not front["period_statements"]
            or not front["source_intro_text"]
            or front["uncertainties"]
            or len(front["legend"]) != len(LEGEND)
            or {r["token_text"]: r["meaning_text"] for r in front["legend"]} != LEGEND
        ):
            raise ValueError
        plain = " ".join(front["source_intro_text"].split())
        if any(
            statement not in plain for statement in front["period_statements"] + front["source_methodology_statements"]
        ):
            raise ValueError
        annotations = front["member_annotation_definitions"]
        if len({r["annotation_text"] for r in annotations}) != len(annotations) or any(
            not r["annotation_text"] or not r["meaning_text"] for r in annotations
        ):
            raise ValueError
        items = set()
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            number = r["item_number_text"].removesuffix(".")
            if (
                chamber not in spec["items"]
                or not number.isdigit()
                or not 1 <= int(number) <= spec["items"][chamber]
                or r["item_number_text"] != number + "."
                or (chamber, number) in items
                or not r["title_text"]
                or not r["source_narrative_text"]
                or r["title_text"] not in " ".join(r["source_narrative_text"].split())
                or r["preferred_vote_text"] not in {"Yes", "No"}
                or not r["publisher_position_sentence_text"]
                or r["publisher_position_sentence_text"] not in " ".join(r["source_narrative_text"].split())
                or not re.fullmatch(r"\d+", r["roll_number_text"])
                or not r["date_text"]
                or r["date_text"] not in " ".join(r["source_narrative_text"].split())
                or any(
                    not c or c not in r["source_narrative_text"]
                    for k in ["bill_citations", "amendment_citations"]
                    for c in r[k]
                )
            ):
                raise ValueError
            items.add((chamber, number))
        if dict(Counter(c for c, _ in items)) != spec["items"]:
            raise ValueError
        identities, members, pages = set(), Counter(), {c: Counter() for c in spec["members"]}
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            physical = e["evidence"]["physical_pages"]
            identity = (chamber, tuple(physical), e["evidence"]["json_pointer"])
            if (
                chamber not in spec["members"]
                or identity in identities
                or len(physical) != 1
                or str(physical[0]) not in spec["member_pages"][chamber]
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or not r["state_text"]
                or r["party_text"] not in {"D", "R", "I"}
                or not re.fullmatch(r"\d+", r["score_text"])
                or (chamber == "House" and not re.fullmatch(r"AL|\d{2}", r["district_text"]))
                or (chamber == "Senate" and r["district_text"] is not None)
                or (
                    r["end_notes_text"] is not None
                    and r["end_notes_text"] not in {a["annotation_text"] for a in annotations}
                )
                or set(r["item_results"]) != {n for c, n in items if c == chamber}
                or any(token not in LEGEND for token in r["item_results"].values())
                or not re.fullmatch(r"[0-9a-f]{64}", e["evidence"]["native_text_sha256"])
                or not e["evidence"]["json_pointer"].startswith("/members/")
                or type(e["evidence"]["state_heading_physical_page"]) is not int
                or not 1 <= e["evidence"]["state_heading_physical_page"] <= physical[0]
            ):
                raise ValueError
            identities.add(identity)
            members[chamber] += 1
            pages[chamber][str(physical[0])] += 1
        if dict(members) != spec["members"] or any(dict(pages[c]) != spec["member_pages"][c] for c in pages):
            raise ValueError
        return data, spec
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        raise ScorecardSourceError("AFGE annual facts do not establish the pinned complete reviewed edition") from error


@dataclass(frozen=True, slots=True)
class AFGEPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        data, spec = _qualified(self.qualified_observations)
        _source(context.read(spec["url"], stage=f"afge:{data['edition_key']}:pdf:list", hosts=HOSTS), spec)
        return (_edition(data["edition_key"]),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _references(record: dict, location: str, chamber: str, spec: EditionSpec) -> list[dict]:
    refs = []
    for n, match in enumerate(CITATION.finditer(record["source_narrative_text"])):
        text = match[0]
        kind = "amendment" if "Amdt" in text else "bill"
        refs.append(
            {
                "occurrence_id": str(n),
                "citation_text": text,
                "kind": kind,
                kind + "_citation_text": text,
                "source_path": location + f"/source_narrative_text/offset={match.start()}",
            }
        )
    refs.append(
        {
            "occurrence_id": "roll",
            "citation_text": record["roll_number_text"],
            "kind": "roll_call",
            "roll_number_text": record["roll_number_text"],
            "congress_text": spec["congress"],
            "session_text": spec["session"],
            "chamber_text": chamber,
            "source_path": location + "/roll_number_text",
        }
    )
    return refs


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AFGE annual PDF requires pinned reviewed facts and private observation retention")
    data, spec = _qualified(qualified_observations)
    if edition != _edition(data["edition_key"]):
        raise ScorecardSourceError("AFGE annual PDF selection differs from the qualified named edition")
    document = context.read(spec["url"], stage=f"afge:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["observations_sha256"],
        stage=f"afge:{edition.edition_id}:qualified-observations",
    )
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="American Federation of Government Employees",
        parser_version=parser_version,
        homepage="https://www.afge.org/",
        rendition_rule="complete named annual original PDF; every native row, score, item and cell reconciles reviewed semantic facts; stable original reread",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX

    def path(group, n=None, suffix=""):
        e = data[group] if n is None else data[group][n]
        pages = ",".join(str(p) for p in e["evidence"]["physical_pages"])
        pointer = "/" + group + ("" if n is None else f"/{n}") + "/record"
        return f"pdf:pages={pages};observation={observation};{pointer}{suffix}"

    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        edition_label_text=front["title_text"],
        methodology_url=document.url,
        timespan_text=front["period_statements"][0],
        congress_text=front["congress_text"],
        session_text=front["session_text"],
        periods_json=json_column(
            [
                {
                    "occurrence_id": str(i),
                    "kind": "explicit",
                    "period_text": statement,
                    "year_text": spec["year"],
                    "congress_text": front["congress_text"],
                    "session_text": front["session_text"],
                    "source_path": path("front", suffix=f"/period_statements/{i}"),
                }
                for i, statement in enumerate(front["period_statements"])
            ]
        ),
    )
    annotations = {r["annotation_text"]: r["meaning_text"] for r in front["member_annotation_definitions"]}
    for chamber in spec["members"]:
        method = key(chamber, "printed-method")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front"),
            methodology_id=method,
            chamber_text=chamber,
            methodology_url=document.url,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "period_statements": front["period_statements"],
                    "source_methodology_statements": front["source_methodology_statements"],
                    "source_legend": front["legend"],
                    "member_annotation_definitions": front["member_annotation_definitions"]
                    if chamber == "House"
                    else [],
                    "source_column_titles": data["column_titles"][chamber],
                    "source_formula_text": None,
                    "source_weight_text": None,
                }
            ),
        )
        bundle.add(
            "scorecard_metrics",
            document,
            path("front", suffix="/score_label_text"),
            metric_id=chamber,
            methodology_id=method,
            name=front["score_label_text"],
            value_unit_text=front["score_unit_text"],
            chamber_text=chamber,
            period_text=spec["year"],
            is_primary="true",
        )
    for n, e in enumerate(data["items"]):
        r, chamber = e["record"], e["chamber"]
        number = r["item_number_text"].removesuffix(".")
        item, location = key(chamber, number), path("items", n)
        refs = _references(r, location, chamber, spec)
        bills = {v["bill_citation_text"] for v in refs if "bill_citation_text" in v}
        amendments = {v["amendment_citation_text"] for v in refs if "amendment_citation_text" in v}
        method = key(chamber, "item", number)
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=method,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(
                {
                    "source_item_number_text": r["item_number_text"],
                    "publisher_position_sentence_text": r["publisher_position_sentence_text"],
                    "source_bill_citations": r["bill_citations"],
                    "source_amendment_citations": r["amendment_citations"],
                    "member_names_with_explicit_rules": r["member_names_with_explicit_rules"],
                }
            ),
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=item,
            publisher_item_id=r["item_number_text"],
            title=r["title_text"],
            item_kind_text="roll call",
            item_date_text=r["date_text"],
            congress_text=spec["congress"],
            session_text=spec["session"],
            chamber_text=chamber,
            roll_number_text=r["roll_number_text"],
            bill_citation_text=next(iter(bills)) if len(bills) == 1 else None,
            amendment_citation_text=next(iter(amendments)) if len(amendments) == 1 else None,
            references_json=json_column(refs),
            publisher_position_text=r["preferred_vote_text"],
            position_basis="explicit",
            position_source_path=location + "/publisher_position_sentence_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id=chamber,
            item_id=item,
            participation_id="printed-grid",
            methodology_id=method,
            publisher_position_text=r["preferred_vote_text"],
            position_basis="explicit",
        )
    for n, e in enumerate(data["members"]):
        r, chamber = e["record"], e["chamber"]
        location = path("members", n)
        member = key(
            chamber,
            str(e["evidence"]["physical_pages"][0]),
            e["evidence"]["json_pointer"],
            r["state_text"],
            *([r["district_text"]] if r["district_text"] else []),
            r["member_name_text"],
        )
        note = (
            json_column({"source_end_note_text": r["end_notes_text"], "meaning_text": annotations[r["end_notes_text"]]})
            if r["end_notes_text"]
            else None
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            chamber_text=chamber,
            period_text=spec["year"],
            identifiers_json="[]",
            notes_text=note,
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/score_text",
            publisher_member_key=member,
            metric_id=chamber,
            value_text=r["score_text"],
            value_number=decimal_text(r["score_text"]),
            notes_text=note,
        )
        for number, token in r["item_results"].items():
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + "/item_results/" + number,
                publisher_member_key=member,
                item_id=key(chamber, number),
                metric_id=chamber,
                participation_id="printed-grid",
                result_id="printed-cell",
                result_text=token,
                reason_text=LEGEND[token],
            )
    repeated = context.read(spec["url"], stage=f"afge:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "All named member rows, scores, numbered item definitions, literal legend and action cells reconcile original native and reviewed semantic observations; complete source reread is identical",
        declared={
            "physical_pages": spec["pages"],
            "members_by_chamber": spec["members"],
            "members_by_physical_page": spec["member_pages"],
            "items_by_chamber": spec["items"],
            "count_basis": "all printed named source grid rows, including publisher-listed replacements and former members",
            "identity_rule": "source chamber plus physical row context; annual key from explicit printed year",
            "source_congress_text": front["congress_text"],
            "source_session_text": front["session_text"],
            "reference_period_rule": "explicit ordinal 114th Congress/first session yields Congress114/session1; no date-based inference",
        },
    )
