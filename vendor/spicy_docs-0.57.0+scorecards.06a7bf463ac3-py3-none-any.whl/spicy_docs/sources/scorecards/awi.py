"""AWI's complete publisher-defined Congressional Compassion Index rating tables."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from typing import ClassVar
from urllib.parse import urlencode, urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.common import (
    soup as source_soup,
)

parser_version = "awi-original-compassion-aggregate/1"
PUBLISHER = "animal_welfare_institute"
BASE = "https://www.congressweb.com"
HOMEPAGE = "https://awionline.org/"
HOSTS = ("www.congressweb.com",)
FRAME = {
    "framed_parent_url": "https://awionline.org/take-action/",
    "framed_parent_is_microsite": "false",
    "frame_is_responsive": "true",
    "frame_is_websticker": "false",
    "frame_hide_menu": "false",
    "frame_container_id": "iframe",
    "full_height_websticker": "false",
}
INDEX = BASE + "/AWI/legislators?" + urlencode(FRAME)
FORM = "/AWI/legislators/membercompassionindex"
NAME_PATH = re.compile(r"/AWI/legislators/info/mbr_id/([1-9][0-9]*)")


def _text(node):
    return re.sub(r"\s+", " ", node.get_text(" ", strip=True)).strip()


def _document(document):
    # HTML parsers can repair truncated tables. Require the original complete document boundary too.
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("AWI source HTML lacks its complete document boundary")
    soup = source_soup(document)
    title = soup.select_one("title")
    if title is None or not _text(title).endswith(" | Animal Welfare Institute"):
        raise ScorecardSourceError("AWI source lacks its original publisher identity")
    if soup.select("a[rel=next], .pagination, .congressweb-pagination"):
        raise ScorecardSourceError("AWI pagination shape requires a qualified explicit walk")
    if not soup.select_one(".congressweb-poweredby"):
        raise ScorecardSourceError("AWI source lacks its terminal application footer")
    return soup


def _table_url(option, sort=None):
    values = {"congress_chamber": option}
    if sort is not None:
        values["sort"] = sort
    return BASE + FORM + "?" + urlencode(values | FRAME)


def _native_option(edition):
    match = re.fullmatch(r"([1-9][0-9]*)-(House|Senate)-aggregate", edition.edition_id)
    if match is None:
        raise ScorecardSourceError("AWI aggregate reader requires an explicit native Congress/chamber edition")
    congress, chamber = match.groups()
    option = congress + "-" + chamber
    if (
        edition.publisher_id != PUBLISHER
        or edition.source_url != _table_url(option)
        or edition.congress != congress
        or edition.chamber != chamber
    ):
        raise ScorecardSourceError("AWI edition differs from its exact publisher query")
    return option


def _catalog(document):
    soup = _document(document)
    root = soup.select_one("#congresswebContent_cid_legislators_main")
    if root is None or "AWI's Compassion Index rating" not in _text(root):
        raise ScorecardSourceError("AWI original index no longer identifies its Compassion Index")
    forms = root.select(f'form[action="{FORM}"][method="get"]')
    if len(forms) != 1:
        raise ScorecardSourceError("AWI requires its one complete original scorecard form")
    options, editions = set(), []
    for node in forms[0].select('select[name="congress_chamber"] option'):
        value = node.get("value")
        if value == "" and node.has_attr("disabled"):
            continue
        match = re.fullmatch(r"([1-9][0-9]*)-(House|Senate)", str(value))
        if match is None or value in options:
            raise ScorecardSourceError("AWI index contains an unknown or duplicate edition option")
        congress, chamber = match.groups()
        if _text(node) != f"{congress}th Congress, {chamber}":
            raise ScorecardSourceError("AWI index edition label disagrees with its native query")
        options.add(value)
        editions.append(
            ScorecardEdition(
                PUBLISHER,
                value + "-aggregate",
                _table_url(value),
                f"Congressional Compassion Index: {congress}th Congress, {chamber}",
                congress=congress,
                chamber=chamber,
            )
        )
    if not editions:
        raise ScorecardSourceError("AWI original index has an empty or incomplete edition catalog")
    latest = max(int(e.congress) for e in editions)
    return tuple(replace(e, is_current=int(e.congress) == latest) for e in editions)


def _table(document, option):
    soup = _document(document)
    if document.body.lower().count(b"<table") != 1 or document.body.lower().count(b"</table>") != 1:
        raise ScorecardSourceError("AWI original rating table lacks its complete native closing boundary")
    root = soup.select_one("#congresswebContent_cid_legislators_membercompassionindex")
    if root is None:
        raise ScorecardSourceError("AWI original response lacks its complete rating table scope")
    congress, chamber = option.split("-")
    title = root.select_one("h1.congressweb-module-title")
    label = f"Congressional Compassion Index: {congress}th Congress, {chamber}"
    native = root.select_one(f'form[action="{FORM}"] input[name="congress_chamber"]')
    if title is None or _text(title) != label or native is None or native.get("value") != option:
        raise ScorecardSourceError("AWI source title and hidden query do not identify the requested edition")
    tables = root.select("table.congressweb-module-listTable")
    if len(tables) != 1:
        raise ScorecardSourceError("AWI requires exactly one complete native rating table")
    rows = tables[0].find_all("tr", recursive=False)
    if not rows:  # BeautifulSoup may expose an explicit tbody in another source layout.
        raise ScorecardSourceError("AWI rating table layout changed")
    headers = [_text(c) for c in rows[0].find_all("th", recursive=False)]
    if headers != (["Representative", "Rating"] if chamber == "House" else ["Senator", "Rating"]):
        raise ScorecardSourceError("AWI rating table columns changed")
    population, seen = [], set()
    for ordinal, tr in enumerate(rows[1:], 1):
        cells = tr.find_all("td", recursive=False)
        if len(cells) != 2:
            raise ScorecardSourceError("AWI rating row does not supply every native field")
        links = cells[0].select("a[href]")
        contexts = cells[0].select(".congressweb-legislator-sub-content")
        if len(links) != 1 or len(contexts) != 1:
            raise ScorecardSourceError("AWI rating row lacks a unique source member identity")
        match = NAME_PATH.fullmatch(str(links[0].get("href")))
        member, context, value = _text(links[0]), _text(contexts[0]), _text(cells[1])
        parsed = re.fullmatch(r"\(([A-Z])-([A-Z]{2})(?:-([0-9]+))?\)", context)
        if match is None or parsed is None or not member or not re.fullmatch(r"-?[0-9]+%", value):
            raise ScorecardSourceError("AWI rating row has an unsupported native value or identity shape")
        identifier, party, state, district = match.group(1), *parsed.groups()
        # Historical tables join the source's current member directory. A historic
        # House row can therefore print a current Senator and no district. Preserve
        # that displayed context; the table's Congress/chamber remains separate.
        if identifier in seen:
            raise ScorecardSourceError("AWI rating population contains duplicate publisher member IDs")
        seen.add(identifier)
        population.append(
            {
                "id": identifier,
                "name": member,
                "context": context,
                "party": party,
                "state": state,
                "district": district,
                "value": value,
                "profile_url": urljoin(BASE, links[0]["href"]),
                "path": f"#congresswebContent_cid_legislators_membercompassionindex/table/tr[{ordinal + 1}]",
            }
        )
    if not population:
        raise ScorecardSourceError("AWI rating table is empty; a complete rating population is not established")
    return label, population


def _facts(rows):
    return {r["id"]: {k: v for k, v in r.items() if k != "path"} for r in rows}


@dataclass(frozen=True, slots=True)
class AWIAggregateReader:
    parser_version: ClassVar[str] = parser_version

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("AWI source redistribution rights are not established")
        return _catalog(context.read(INDEX, stage="awi:aggregate:catalog", hosts=HOSTS))

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(edition, context)


def acquire_scorecard(edition, context):
    if context.evidence_policy == "full":
        raise ScorecardSourceError("AWI source redistribution rights are not established")
    option = _native_option(edition)
    catalog = context.read(INDEX, stage=f"awi:{option}:aggregate:catalog", hosts=HOSTS)
    choices = _catalog(catalog)
    if edition not in choices:
        raise ScorecardSourceError("AWI requested edition is absent from the complete original catalog")
    primary = context.read(edition.source_url, stage=f"awi:{option}:aggregate:ratings", hosts=HOSTS)
    label, rows = _table(primary, option)
    name_order = context.read(_table_url(option, "name"), stage=f"awi:{option}:aggregate:name-order", hosts=HOSTS)
    if _facts(_table(name_order, option)[1]) != _facts(rows):
        raise ScorecardSourceError("AWI rating and name orderings do not expose the same complete source facts")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Animal Welfare Institute",
        parser_version=parser_version,
        homepage=HOMEPAGE,
        rendition_rule="complete original Congress/chamber aggregate rating table; source-native names, IDs and values; item detail is a distinct rendition",
    )
    bundle.use(primary, "rating-population")
    bundle.use(catalog, "edition-catalog")
    bundle.use(name_order, "rating-population", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=option, edition_label_text=label, timespan_text=f"{edition.congress}th Congress"
    )
    metric = "Rating"
    bundle.metric(
        primary,
        metric,
        metric,
        path="#congresswebContent_cid_legislators_membercompassionindex/table/tr[1]/th[2]",
        chamber=edition.chamber,
        unit="%",
    )
    for r in rows:
        identifier = key("mbr_id", r["id"])
        bundle.add(
            "scorecard_members",
            primary,
            r["path"] + "/td[1]",
            publisher_member_key=identifier,
            publisher_member_id=r["id"],
            member_name=r["name"],
            party=r["party"],
            state=r["state"],
            district=r["district"],
            chamber_text=edition.chamber,
            period_text=f"{edition.congress}th Congress",
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "literal_context": r["context"],
                    "publisher_profile_url": r["profile_url"],
                    "identity_scope": "Publisher mbr_id and displayed edition name; no official or historical identity resolution.",
                }
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            r["path"] + "/td[2]",
            metric_id=metric,
            publisher_member_key=identifier,
            value_text=r["value"],
            value_number=decimal_text(r["value"]),
        )
    repeated = context.read(edition.source_url, stage=f"awi:{option}:aggregate:ratings:reread", hosts=HOSTS)
    if _facts(_table(repeated, option)[1]) != _facts(rows):
        raise ScorecardSourceError("AWI source population or rating changed during the complete capture")
    repeated_catalog = context.read(INDEX, stage=f"awi:{option}:aggregate:catalog:reread", hosts=HOSTS)
    if _catalog(repeated_catalog) != choices:
        raise ScorecardSourceError("AWI original edition catalog changed during acquisition")
    bundle.use(repeated, "rating-population", role="corroboration")
    bundle.use(repeated_catalog, "edition-catalog", role="corroboration")
    return bundle.finish(
        "Complete source-defined aggregate table reaches its original closing table/document and terminal footer; every native member/value agrees across rating/name orderings and reread; native edition catalog reread agrees",
        declared={
            "native_option": option,
            "scope": "publisher-defined aggregate rating table; no inferred official roster size, item methodology or action grid",
            "publisher_declared_member_count": None,
        },
    )
