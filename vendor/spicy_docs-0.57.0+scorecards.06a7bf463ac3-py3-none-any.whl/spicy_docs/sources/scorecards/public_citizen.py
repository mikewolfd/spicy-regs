"""Named Public Citizen archived HTML renditions, including conflicting native periods."""

import re
from collections import Counter

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "public-citizen-named-archived-html/1"
ORIGIN = "https://www.citizen.org"
HOSTS = ("web.archive.org",)
MAP = "https://web.archive.org/web/20001019060933id_/http://www.citizen.org:80/vchart00/map.htm"
KEY = "https://web.archive.org/web/20001204232100id_/http://www.citizen.org:80/vchart00/key.htm"
MONEY = "https://web.archive.org/web/20001109030000id_/http://www.citizen.org:80/vchart00/money.htm"
TIMESTAMPS = {"senate": "20041027035010", "house": "20041027040416"}
PERIODS = {"senate": "1999 - 2000", "house": "1997/1998"}
LEGEND = {
    "+": "Vote for the Public Citizen Position",
    "-": "Vote against the Public Citizen Position",
    "O": "Did not vote",
    "I": "Ineligible - not in Congress at time of vote",
    "P": 'Present - voted "present" to avoid conflict of interest',
    "S": "The Speaker of the House by tradition rarely votes",
}
# Observed complete named originals, not an official roster or publisher count claim.
# Qualification records the source hashes, every native row and every state subtotal.
HOUSE_STATE_ROWS = {
    "Alabama": 7,
    "Alaska": 1,
    "Arizona": 6,
    "Arkansas": 4,
    "California": 52,
    "Colorado": 6,
    "Connecticut": 6,
    "Delaware": 1,
    "Florida": 23,
    "Georgia": 11,
    "Hawaii": 2,
    "Idaho": 1,
    "Illinois": 20,
    "Indiana": 10,
    "Iowa": 5,
    "Kansas": 4,
    "Kentucky": 6,
    "Louisiana": 7,
    "Maine": 2,
    "Maryland": 8,
    "Massachusetts": 10,
    "Michigan": 16,
    "Minnesota": 8,
    "Mississippi": 5,
    "Missouri": 9,
    "Montana": 1,
    "Nebraska": 3,
    "Nevada": 2,
    "N.H.": 2,
    "New Jersey": 13,
    "New Mexico": 3,
    "New York": 31,
    "North Carolina": 12,
    "North Dakota": 1,
    "Ohio": 19,
    "Oklahoma": 6,
    "Oregon": 5,
    "Pennsylvania": 21,
    "Rhode Island": 2,
    "South Carolina": 6,
    "South Dakota": 1,
    "Tennessee": 9,
    "Texas": 30,
    "Utah": 3,
    "Vermont": 1,
    "Virginia": 11,
    "Washington": 9,
    "West Virginia": 3,
    "Wisconsin": 9,
    "Wyoming": 1,
}
BILL = re.compile(r"H\.J\. Res \d+|H\.R\. \d+|S\. \d+")
AMENDMENT = re.compile(r"Amdt\. \d+")
ROLL = re.compile(r"(?:Roll Call Vote |R\.C\.V\. #)(\d+)")
DATE = re.compile(r"\d{1,2}/\d{1,2}/\d{2}")
POSITION = re.compile(r"(?:Public Citizen|PC) Vote = (Yes|No)")


def original(chamber):
    return "http://www.citizen.org/vchart00/" + chamber + "votechart.cfm"


def source_url(chamber):
    return "https://web.archive.org/web/" + TIMESTAMPS[chamber] + "id_/" + original(chamber)


def edition(chamber):
    if chamber not in TIMESTAMPS:
        raise ScorecardSourceError("Public Citizen chamber is outside the named archived renditions")
    return ScorecardEdition(
        "public_citizen",
        "vchart00-" + chamber + "-archived-html",
        source_url(chamber),
        "Public Citizen Vote Chart U.S. " + ("Senate " if chamber == "senate" else "House - ") + PERIODS[chamber],
        congress="106" if chamber == "senate" else None,
        chamber=chamber,
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return tuple(edition(chamber) for chamber in TIMESTAMPS)


def _text(element):
    return " ".join(element.get_text(" ", strip=True).split())


def _html(document, url):
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("Public Citizen archived custody escaped its selected original route")
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Public Citizen archived HTML is incomplete")
    html = soup(document)
    if len(html.select("html")) != 1 or len(html.select("body")) != 1:
        raise ScorecardSourceError("Public Citizen original HTML document boundary changed")
    if html.select("table table, select, [class*='pagination'], [class*='pager']"):
        raise ScorecardSourceError("Public Citizen original rendition exposes an unreviewed nested grid or filter")
    return html


def _map(document):
    html = _html(document, MAP)
    tables = html.select("table")
    forms = [
        {"method": f.get("method"), "action": f.get("action"), "buttons": [i.get("value") for i in f.select("input")]}
        for f in html.select("form")
    ]
    if (
        len(tables) != 5
        or _text(tables[0]) != "1999-2000"
        or forms
        != [
            {"method": "GET", "action": "allsen_1.IDC", "buttons": ["Senate"]},
            {"method": "GET", "action": "allhs_1.IDC", "buttons": ["House"]},
        ]
        or not _text(tables[-1]).startswith("The 106th Congress ")
    ):
        raise ScorecardSourceError("Public Citizen archived index period or source-defined all-record routes changed")
    return {
        "period": _text(tables[0]),
        "forms": forms,
        "links": [a.get("href") for a in html.select("a[href]")],
        "text": _text(html.body),
    }


def _key(document):
    html = _html(document, KEY)
    tables = html.select("table")
    if len(tables) != 2:
        raise ScorecardSourceError("Public Citizen complete score key changed")
    score = tables[0].select("tr")
    if (
        len(score) != 3
        or _text(score[0]) != "Vote Chart Key"
        or not _text(score[2]).startswith("Score The Public Citizen")
    ):
        raise ScorecardSourceError("Public Citizen native score-method statement changed")
    legend = {}
    for row in tables[1].select("tr"):
        cells = row.find_all("td", recursive=False)
        if len(cells) != 2 or _text(cells[0]) in legend:
            raise ScorecardSourceError("Public Citizen key token inventory is incomplete or repeated")
        legend[_text(cells[0])] = _text(cells[1])
    if legend != LEGEND:
        raise ScorecardSourceError("Public Citizen literal result key requires requalification")
    return {"score": _text(score[2]), "legend": legend, "text": _text(html.body)}


def _money(document):
    html = _html(document, MONEY)
    tables = html.select("table")
    if (
        len(tables) != 2
        or not _text(tables[0]).startswith("Money, Money, Money...")
        or len(tables[1].select("td")) != 1
    ):
        raise ScorecardSourceError("Public Citizen native financial-column context changed")
    return {
        "text": _text(tables[1]),
        "links": [{"href": a.get("href"), "text": _text(a)} for a in tables[1].select("a[href]")],
    }


def _description(cell, path, ordinal):
    text = _text(cell)
    number = re.match(r"(\d+)\. ", text)
    bill = BILL.search(text)
    roll = ROLL.search(text)
    date = DATE.search(text)
    positions = POSITION.findall(text)
    anchors = [a.get("name") for a in cell.select("a[name]")]
    if not number or not bill or not roll or not date or len(positions) != 1 or bill.start() < number.end():
        raise ScorecardSourceError("Public Citizen authored item identity, date, roll or position shape changed")
    refs = [
        {
            "occurrence_id": "publisher-fragment-" + str(n),
            "kind": "publisher_fragment",
            "citation_text": anchor,
            "source_path": path + "/descendant::a[@name=" + repr(anchor) + "]/@name",
        }
        for n, anchor in enumerate(anchors, 1)
    ]
    for kind, pattern, field in (
        ("bill", BILL, "bill_citation_text"),
        ("amendment", AMENDMENT, "amendment_citation_text"),
        ("roll_call", ROLL, "roll_number_text"),
    ):
        for occurrence, match in enumerate(pattern.finditer(text), 1):
            refs.append(
                {
                    "occurrence_id": kind + "-" + str(occurrence),
                    "kind": kind,
                    "citation_text": match[0],
                    field: match[1] if kind == "roll_call" else match[0],
                    "source_path": path + "::text[" + str(match.start()) + ":" + str(match.end()) + "]",
                }
            )
    return {
        "ordinal": ordinal,
        "path": path,
        "number": number[1],
        "anchors": anchors,
        "title": text[number.end() : bill.start()].strip(),
        "bill": bill[0],
        "amendment": next(iter(AMENDMENT.findall(text[: roll.end()])), None),
        "date": date[0],
        "roll": roll[1],
        "position": positions[0],
        "text": text,
        "references": refs,
    }


def _chart(document, chamber):
    html = _html(document, source_url(chamber))
    tables = html.select("table")
    item_count = 12 if chamber == "senate" else 15
    prefix = ["State", "Senator", "Party"] if chamber == "senate" else ["State", "Dist.", "Member", "Party"]
    headings = prefix + [str(n) for n in range(1, item_count + 1)] + ["Score", "PAC $", "Other $", "Total $"]
    if len(tables) != (5 if chamber == "senate" else 4):
        raise ScorecardSourceError("Public Citizen complete chart/table inventory changed")
    header_cells = tables[0].select("tr")[0].find_all("td", recursive=False)
    if len(header_cells) != 3 or _text(header_cells[1]) != edition(chamber).title:
        raise ScorecardSourceError("Public Citizen native chamber/period heading changed")
    key_href = "http://www.citizen.org/" + ("vchart00" if chamber == "senate" else "vchart98") + "/key.htm"
    if [(a.get("href"), _text(a)) for a in header_cells[2].select("a[href]")] != [(key_href, "Key")]:
        raise ScorecardSourceError("Public Citizen native header-key reference changed")
    intro = [_text(r) for r in tables[0].select("tr")[1:] if _text(r)]
    if chamber == "senate" and (len(intro) != 1 or "roll call votes in the 106th Congress." not in intro[0]):
        raise ScorecardSourceError("Public Citizen source-stated Senate Congress/methodology changed")
    if chamber == "house" and intro:
        raise ScorecardSourceError("Public Citizen conflicted House chart introduced unreviewed period context")
    grid = tables[1].select("tr")
    cells = grid[0].find_all("th", recursive=False)
    links = [[a.get("href") for a in c.select("a[href]")] for c in cells]
    if (
        [_text(c) for c in cells] != headings
        or links[len(prefix) : -4] != [["#" + str(n) + "."] for n in range(1, item_count + 1)]
        or links[-4:] != [["key.htm"], ["money.htm"], ["money.htm"], ["money.htm"]]
    ):
        raise ScorecardSourceError("Public Citizen complete grid header or literal column references changed")
    if html.select("form, input"):
        raise ScorecardSourceError("Public Citizen full chart exposes an unreviewed filter or page")
    description_index = 3 if chamber == "senate" else 2
    descriptions = []
    for row_index, row in enumerate(tables[description_index].select("tr"), 1):
        for cell_index, cell in enumerate(row.find_all("td", recursive=False), 1):
            if re.match(r"\d+\. ", _text(cell)):
                path = (
                    "//table[" + str(description_index + 1) + "]/tr[" + str(row_index) + "]/td[" + str(cell_index) + "]"
                )
                descriptions.append(_description(cell, path, len(descriptions) + 1))
    expected_numbers = list(range(1, 13)) if chamber == "senate" else [*range(1, 20), *range(1, 16)]
    expected_anchors = (
        [[str(n) + "."] for n in range(1, 12)] + [[]]
        if chamber == "senate"
        else [[str(n) + "."] for n in range(1, 20)] + [["1"], ["2"], ["3"]] + [[] for _ in range(12)]
    )
    if [d["number"] for d in descriptions] != list(map(str, expected_numbers)) or [
        d["anchors"] for d in descriptions
    ] != expected_anchors:
        raise ScorecardSourceError("Public Citizen complete authored description occurrence/anchor inventory changed")
    members = []
    seen = set()
    allowed = {"+", "-", "I", "O", "P"} if chamber == "senate" else {"+", "-", "I", "0", "S"}
    for row_index, row in enumerate(grid[1:], 2):
        cells = row.find_all("td", recursive=False)
        values = [_text(c) for c in cells]
        if len(cells) != len(headings) or any(c.get("rowspan") or c.get("colspan") for c in cells):
            raise ScorecardSourceError("Public Citizen member row lacks its complete native cells")
        metadata = dict(zip(prefix, values[: len(prefix)], strict=True))
        name = metadata.get("Senator", metadata.get("Member"))
        district = metadata.get("Dist.")
        member_key = key(chamber, metadata["State"], district or "no-district", name)
        if (
            not all(metadata.values())
            or metadata["Party"] not in {"Rep.", "Dem.", "Ind."}
            or (district is not None and not re.fullmatch(r"\d+|AL", district))
            or member_key in seen
        ):
            raise ScorecardSourceError("Public Citizen literal native member identity is missing, repeated or changed")
        seen.add(member_key)
        results = values[len(prefix) : -4]
        if (
            any(v not in allowed for v in results)
            or not re.fullmatch(r"\d+%", values[-4])
            or any(not re.fullmatch(r"\$[\d,]+|NA", v) for v in values[-3:])
        ):
            raise ScorecardSourceError("Public Citizen native result, rating or financial-field vocabulary changed")
        members.append(
            {
                "key": member_key,
                "name": name,
                "metadata": metadata,
                "district": district,
                "results": results,
                "score": values[-4],
                "finance": values[-3:],
                "row": row_index,
            }
        )
    counts = Counter(m["metadata"]["State"] for m in members)
    expected = dict.fromkeys(HOUSE_STATE_ROWS, 2) if chamber == "senate" else HOUSE_STATE_ROWS
    if counts != expected:
        raise ScorecardSourceError("Public Citizen complete source state/member inventory does not reconcile")
    navigation = [(a.get("href"), _text(a)) for a in tables[-1].select("a[href]")]
    original_map = "http://www.citizen.org/" + ("vchart00" if chamber == "senate" else "vchart98") + "/map.htm"
    if navigation != [(original_map, ""), (original_map, "Return to Map"), ("#Top", "BACK TO TOP")]:
        raise ScorecardSourceError("Public Citizen native chart return links changed")
    outside = [p for p in html.body.select("p") if p.find_parent("table") is None and _text(p)]
    if len(outside) != 1 or not _text(outside[0]).startswith("Vote counts compiled by "):
        raise ScorecardSourceError("Public Citizen original vote-count attribution changed")
    footer = {
        "text": _text(outside[0]),
        "links": [{"href": a.get("href"), "text": _text(a)} for a in outside[0].select("a[href]")],
        "source_path": "(//body//p[not(ancestor::table) and normalize-space()])[1]",
    }
    description_heading = _text(tables[2]) if chamber == "senate" else _text(tables[2].select("tr")[0])
    return {
        "heading": _text(header_cells[1]),
        "key_href": key_href,
        "intro": intro,
        "footer": footer,
        "description_heading": description_heading,
        "headings": headings,
        "links": links,
        "descriptions": descriptions,
        "members": members,
        "navigation": navigation,
        "text": _text(html.body),
    }


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    chamber = selected.chamber
    if chamber not in TIMESTAMPS or selected != edition(chamber):
        raise ScorecardSourceError("Public Citizen caller selection is outside the named archived HTML renditions")
    urls = {"map": MAP, "chart": source_url(chamber), "key": KEY, "money": MONEY}
    parsers = {"map": _map, "chart": lambda d: _chart(d, chamber), "key": _key, "money": _money}
    documents, facts, repeats = {}, {}, {}
    for name, url in urls.items():
        document = context.read(url, stage="public-citizen:" + name, hosts=HOSTS)
        documents[name], facts[name] = document, parsers[name](document)
    for name, url in urls.items():
        document = context.read(url, stage="public-citizen:" + name + "-repeat", hosts=HOSTS)
        if parsers[name](document) != facts[name]:
            raise ScorecardSourceError("Public Citizen complete original source facts changed on reread: " + name)
        repeats[name] = document
    chart = facts["chart"]
    primary = documents["chart"]
    bundle = Bundle(
        selected,
        context,
        primary,
        publisher_name="Public Citizen",
        parser_version=parser_version,
        rendition_rule="Named publisher-owned archived CFM rendition, complete native table and all authored descriptions; index and chart periods remain separate observations.",
        homepage=ORIGIN,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = "http://www.citizen.org/vchart00/map.htm"
    periods = [
        {
            "occurrence_id": "chart-period",
            "period_text": PERIODS[chamber],
            "kind": "explicit",
            "source_path": "//table[1]/tr[1]/td[2]",
        },
        {
            "occurrence_id": "index-period",
            "period_text": facts["map"]["period"],
            "kind": "explicit",
            "source_path": MAP + "#//table[1]",
        },
    ]
    bundle.tables["scorecards"][0].update(
        title=chart["heading"],
        edition_label_text=chart["heading"],
        timespan_text=PERIODS[chamber],
        periods_json=json_column(periods),
        source_path="//table[1]/tr[1]/td[2]",
        methodology_url="http://www.citizen.org/vchart00/key.htm",
    )
    for name in urls:
        bundle.use(documents[name], name)
        bundle.use(repeats[name], name, role="corroboration")
    method_id = "native-score-key"
    bundle.add(
        "scorecard_methodologies",
        documents["key"],
        "//table[1]/tr[3]",
        methodology_id=method_id,
        chamber_text=chamber,
        methodology_text=json_column(facts["key"]),
        methodology_url="http://www.citizen.org/vchart00/key.htm",
        disclosure_status="explicit",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["money"],
        "//table[2]",
        methodology_id="financial-column-context",
        chamber_text=chamber,
        methodology_text=json_column(facts["money"]),
        disclosure_status="explicit",
    )
    custody = {
        "archive_url": source_url(chamber),
        "archive_timestamp": TIMESTAMPS[chamber],
        "original_publisher_url": original(chamber),
    }
    bundle.add(
        "scorecard_methodologies",
        primary,
        "//table[1]",
        methodology_id="native-rendition-context",
        chamber_text=chamber,
        disclosure_status="partial",
        methodology_text=json_column(
            {
                "source_custody": custody,
                "source_heading": chart["heading"],
                "source_intro": chart["intro"],
                "source_description_heading": chart["description_heading"],
                "source_vote_count_attribution": chart["footer"],
                "source_headers": chart["headings"],
                "source_header_links": chart["links"],
                "source_key_href": chart["key_href"],
                "source_return_links": chart["navigation"],
                "source_index_period": facts["map"]["period"],
                "source_index_forms": facts["map"]["forms"],
                "source_index_links": facts["map"]["links"],
                "observations": "The archived index advertises IDC forms, not direct CFM links. House chart and index periods and navigation conflict; year and Congress are unresolved. House description occurrences beyond the 15 exact grid fragments have no invented member results. Senate column 12 has a missing fragment anchor; its unique literal numbered description is retained without creating an anchor. Numeric 0 is not the legend's letter O. Finance fields are source context, not score metrics. No official identities, actions, item weights, primary designation or score reproduction are inferred.",
            }
        ),
    )
    bundle.add(
        "scorecard_metrics",
        primary,
        "//table[2]/tr[1]/th[" + str(len(chart["headings"]) - 3) + "]",
        metric_id="score",
        methodology_id=method_id,
        name="Score",
        value_unit_text="%",
        chamber_text=chamber,
        period_text=PERIODS[chamber],
        periods_json=json_column(periods),
    )
    for item in chart["descriptions"]:
        item_id = key("description", str(item["ordinal"]))
        refs = [
            {**r, "chamber_text": chamber, **({"congress_text": "106"} if chamber == "senate" else {})}
            for r in item["references"]
        ]
        bundle.add(
            "scorecard_items",
            primary,
            item["path"],
            item_id=item_id,
            publisher_item_id=item["number"] + ".",
            item_kind_text="roll_call",
            title=item["title"],
            item_date_text=item["date"],
            chamber_text=chamber,
            congress_text=selected.congress,
            roll_number_text=item["roll"],
            bill_citation_text=item["bill"],
            amendment_citation_text=item["amendment"],
            references_json=json_column(refs),
            publisher_position_text=item["position"],
            position_basis="explicit",
            position_source_path=item["path"],
        )
        bundle.add(
            "scorecard_methodologies",
            primary,
            item["path"],
            methodology_id=key("description", str(item["ordinal"])),
            chamber_text=chamber,
            methodology_text=item["text"],
            disclosure_status="explicit",
        )
    prefix_size = 3 if chamber == "senate" else 4
    item_count = 12 if chamber == "senate" else 15
    for number in range(1, item_count + 1):
        bundle.add(
            "scorecard_metric_items",
            primary,
            "//table[2]/tr[1]/th[" + str(prefix_size + number) + "]",
            metric_id="score",
            item_id=key("description", str(number)),
            participation_id="grid-column",
            methodology_id=method_id,
            publisher_position_text=chart["descriptions"][number - 1]["position"],
            position_basis="explicit",
        )
    for member in chart["members"]:
        row_path = "//table[2]/tr[" + str(member["row"]) + "]"
        finance = [
            {
                "label": label,
                "value_text": "N/A" if value == "NA" else value,
                "literal_source_value": value,
                "source_path": row_path + "/td[" + str(len(chart["headings"]) - 2 + offset) + "]",
            }
            for offset, (label, value) in enumerate(
                zip(("PAC $", "Other $", "Total $"), member["finance"], strict=True)
            )
        ]
        bundle.add(
            "scorecard_members",
            primary,
            row_path,
            publisher_member_key=member["key"],
            identifiers_json="[]",
            member_name=member["name"],
            chamber_text=chamber,
            state=member["metadata"]["State"],
            district=member["district"],
            party=member["metadata"]["Party"],
            period_text=PERIODS[chamber],
            notes_text=json_column({"literal_identity_fields": member["metadata"], "financial_fields": finance}),
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            row_path + "/td[" + str(len(chart["headings"]) - 3) + "]",
            metric_id="score",
            publisher_member_key=member["key"],
            value_text=member["score"],
            value_number=decimal_text(member["score"]),
        )
        for number, result in enumerate(member["results"], 1):
            bundle.add(
                "scorecard_member_item_results",
                primary,
                row_path + "/td[" + str(prefix_size + number) + "]",
                item_id=key("description", str(number)),
                result_id="grid-cell",
                metric_id="score",
                participation_id="grid-column",
                publisher_member_key=member["key"],
                result_text=result,
                reason_text=facts["key"]["legend"].get(result),
            )
    return bundle.finish(
        "Complete named HTML documents reached closing HTML; every native state subtotal, member row, rating, financial field, description occurrence and scoring column reconciled; all four original source facts reread unchanged."
    )
