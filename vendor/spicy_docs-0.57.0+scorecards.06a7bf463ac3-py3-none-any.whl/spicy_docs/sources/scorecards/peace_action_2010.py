"""Peace Action and Peace Action West's original joint 2010 voting-record PDF."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "peace-action-qualified-2010-pdf/1"
URL = "https://www.peaceaction.org/wp-content/uploads/2017/05/2010vr.pdf"
INDEX = "https://www.peaceaction.org/know-the-score/"
SOURCE_SHA256 = "14521640bfe5b41c927457d802b3d58ba21bfe77250fa7e9d4e50183cc336355"
QUALIFIED_SHA256 = "6afd9918b0e78d08c3f71dcb66d5b99afb9cce211ce79365d7c8db97496ff112"
EDITION = ScorecardEdition(
    "peace_action",
    "2010-joint-pdf",
    URL,
    "Congressional Voting Record for the 111th Congress, 2010",
    year="2010",
    congress="111",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {2: 27, 3: 59, 4: 57, 5: 51, 6: 51, 7: 57, 8: 55, 9: 55, 10: 23, 11: 20, 12: 40, 13: 40}
ITEM_ROLLS = {
    "House": ("98", "432", "433", "474", "394", "316", "16", "645"),
    "Senate": ("168", "176", "199", "282", "283", "285", "286", "287", "293", "294", "295", "296", "297", "298"),
}
TOKENS = {"globe", "radiation", "NV", "P", "p", "*", "S"}


@dataclass(frozen=True, slots=True)
class PeaceAction2010Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _source(document):
    if not document.body.startswith(b"%PDF-") or sha256(document.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("Peace Action original 2010 PDF differs from its reviewed source pin")


def list_scorecards(context):
    _source(context.read(URL, stage="scorecards:peace_action:2010-listing", hosts=("www.peaceaction.org",)))
    return (EDITION,)


def _facts(data):
    try:
        if data["format_version"] != "peace-action-2010-qualified-source-facts/1" or data["sources"] != {
            "pdf-2010-content": {"sha256": SOURCE_SHA256, "page_count": 14}
        }:
            raise ValueError
        counts, identities = dict.fromkeys(PAGE_MEMBERS, 0), set()
        for entry in data["members"]:
            record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            page = evidence["physical_page"]
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if (
                page not in counts
                or evidence["source_label"] != "pdf-2010-content"
                or evidence["source_ordinal"] != counts[page]
                or chamber != ("House" if page <= 10 else "Senate")
                or identity in identities
                or not record["member_name_text"]
                or not record["state_text"]
                or not record["notes_text"]
                or record["party_text"] not in {"D", "R", "I"}
                or (record["district_text"] is not None and re.fullmatch(r"\d+\.?", record["district_text"]) is None)
                or (chamber == "Senate" and record["district_text"] is not None)
                or set(record["results"]) != {str(i) for i in range(1, len(ITEM_ROLLS[chamber]) + 1)}
                or any(v not in TOKENS for v in record["results"].values())
                or re.fullmatch(r"\d{1,3}%", record["score_text"]) is None
                or int(record["score_text"][:-1]) > 100
            ):
                raise ValueError
            counts[page] += 1
            identities.add(identity)
        if counts != PAGE_MEMBERS or len(data["methodology"]) != 5:
            raise ValueError
        if len(data["items"]) != sum(len(v) for v in ITEM_ROLLS.values()):
            raise ValueError
        for chamber, rolls in ITEM_ROLLS.items():
            entries = [e for e in data["items"] if e["chamber"] == chamber]
            if len(entries) != len(rolls):
                raise ValueError
            for ordinal, (entry, roll) in enumerate(zip(entries, rolls, strict=True), 1):
                record, evidence = entry["record"], entry["evidence"]
                page = 2 if chamber == "House" else 10 if ordinal <= 7 else 11
                if (
                    record["ordinal"] != ordinal
                    or record["roll_number_text"] != roll
                    or record["publisher_position_glyph"] not in {"globe", "radiation"}
                    or evidence["physical_page"] != page
                    or evidence["source_label"] != "pdf-2010-content"
                    or evidence["source_ordinal"] != (ordinal - 1 if page != 11 else ordinal - 8)
                    or record["item_date_text"] is not None
                    or any(
                        not record[f]
                        for f in (
                            "title",
                            "description_text",
                            "outcome_text",
                            "native_header_text",
                            "native_roll_citation_text",
                        )
                    )
                ):
                    raise ValueError
        if [m["evidence"]["physical_page"] for m in data["methodology"]] != [2, 3, 12, 10, 14]:
            raise ValueError
        if any(
            not m["record"]["methodology_text"] or m["evidence"]["source_label"] != "pdf-2010-content"
            for m in data["methodology"]
        ):
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("Peace Action facts fail the complete reviewed joint 2010 PDF shape") from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Peace Action 2010 PDF requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:peace_action:2010-pdf", hosts=("www.peaceaction.org",))
    _source(source)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="peace_action:qualified-2010-joint-pdf",
    )
    data = _facts(json.loads(qualified_observations))
    end = context.read(URL, stage="scorecards:peace_action:2010-pdf-end", hosts=("www.peaceaction.org",))
    _source(end)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Peace Action",
        parser_version=parser_version,
        rendition_rule="peace-action-complete-joint-2010-voting-record-pdf/1",
        homepage="https://www.peaceaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0]["methodology_url"] = URL
    bundle.use(source, "members_and_scores", "scored_items", "member_results", "methodology")
    bundle.use(end, "members_and_scores", "scored_items", "member_results", "methodology", role="corroboration")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}"),
            methodology_id=f"source-{i}",
            methodology_text=entry["record"]["methodology_text"],
            methodology_url=source.url,
            disclosure_status=entry["record"]["scope_text"],
        )
    for chamber, page in (("House", 2), ("Senate", 11)):
        bundle.metric(
            source, key(chamber, "total"), "TOTAL", path=path(page, "/score-heading"), chamber=chamber, unit="percent"
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = "FOR THE 111TH CONGRESS, 2010"
    for i, entry in enumerate(data["items"]):
        record, chamber = entry["record"], entry["chamber"]
        ordinal = str(record["ordinal"])
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        item_id, method_id = key(chamber, ordinal), key("item", chamber, ordinal)
        references = [
            {
                "occurrence_id": "native-roll",
                "kind": "roll_call",
                "citation_text": record["native_roll_citation_text"],
                "roll_number_text": record["roll_number_text"],
                "congress_text": "111",
                "chamber_text": chamber,
                "source_path": loc + "/native_roll_citation_text",
            }
        ]
        if record["bill_citation_text"]:
            references.append(
                {
                    "occurrence_id": "native-act-name",
                    "kind": "citation",
                    "citation_text": record["bill_citation_text"],
                    "source_path": loc + "/bill_citation_text",
                }
            )
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=ordinal,
            item_kind_text="roll_call",
            title=record["title"],
            congress_text="111",
            chamber_text=chamber,
            roll_number_text=record["roll_number_text"],
            bill_citation_text=record["bill_citation_text"],
            references_json=json.dumps(references, ensure_ascii=False),
            publisher_position_text=record["publisher_position_glyph"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_glyph",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_text=json.dumps(record, ensure_ascii=False),
            methodology_url=source.url,
            disclosure_status="Joint publisher item header, description and outcome; explicit roll digits beside the full original citation; no inferred bill number, date or session",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "total"),
            item_id=item_id,
            participation_id="publisher-scored-votes",
            methodology_id=method_id,
            publisher_position_text=record["publisher_position_glyph"],
            position_basis="explicit",
            counts_toward_metric="true",
        )
    for i, entry in enumerate(data["members"]):
        record, chamber = entry["record"], entry["chamber"]
        identity = key(
            chamber, record["state_text"], record["district_text"] or "not-printed", record["member_name_text"]
        )
        loc = path(entry["evidence"]["physical_page"], f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=record["notes_text"],
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            loc + "/score_text",
            metric_id=key(chamber, "total"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, glyph in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "total"),
                participation_id="publisher-scored-votes",
                publisher_member_key=identity,
                result_id="publisher-glyph",
                result_text=glyph,
            )
    return bundle.finish(
        "Complete joint Peace Action / Peace Action West original 2010 PDF: every source member row, published percent, chamber-specific scored description and action symbol reconciles to exact embedded text/font spans and reviewed original page images. PDF bytes are stable across complete rereads. Globe/radiation symbol names remain distinct from NV, Present, inactive and Speaker statuses; source legends and exclusions, literal district punctuation, full roll citations and native item prose survive. No official action conversion, inferred session/date/bill number/weights or score reproduction."
    )
