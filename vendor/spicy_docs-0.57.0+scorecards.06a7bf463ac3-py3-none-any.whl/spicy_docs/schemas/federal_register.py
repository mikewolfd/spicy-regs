"""Stable public Federal Register source columns and their faithful projection."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from spicy_docs.schemas.tables import FEDERAL_REGISTER_RECORD_KEY, table_contract

FEDERAL_REGISTER_COLUMNS: tuple[str, ...] = (
    "document_number",
    "title",
    "abstract",
    "document_type",
    "publication_date",
    "effective_on",
    "comments_close_on",
    "signing_date",
    "agencies_json",
    "agency_slugs",
    "docket_ids_json",
    "regulation_id_numbers_json",
    "cfr_references_json",
    "topics_json",
    "html_url",
    "pdf_url",
    "body_html_url",
    "volume",
    "start_page",
    "end_page",
    "subtype",
    "executive_order_number",
    "modify_date",
    "regulations_dot_gov_info_json",
    "regulations_dot_gov_docket_id",
    "regulations_dot_gov_document_id",
    "regulations_dot_gov_comments_count",
    "regulations_dot_gov_checked_at",
    "action",
    "correction_of",
    "corrections_json",
    "significant",
)


def _text(value: object) -> str | None:
    return None if value is None else str(value)


def _stated_json(document: Mapping[str, Any], field: str, empty: object) -> str | None:
    """A field requested from schema 1.2 on: NULL where the record predates the request, ``empty`` where it states
    nothing, else the value as JSON."""
    if field not in document:
        return None
    value = document[field]
    return json.dumps(empty if value is None else value)


def project_federal_register_document(document: Mapping[str, Any]) -> dict[str, str | None]:
    """Project one exact API record onto the stable public source columns.

    ``modify_date`` is always NULL: the API states no update instant. The ``regulations_dot_gov_*`` columns read only
    what the Register's ``regulations_dot_gov_info`` states; a docket is never read off a document id's prefix.
    """

    agencies = document.get("agencies") or []
    agency_slugs = ",".join(
        str(agency["slug"]) for agency in agencies if isinstance(agency, Mapping) and agency.get("slug")
    )
    info = document.get("regulations_dot_gov_info") or {}
    significant = document.get("significant")
    return {
        "document_number": _text(document.get("document_number")),
        "title": _text(document.get("title")),
        "abstract": _text(document.get("abstract")),
        "document_type": _text(document.get("type")),
        "publication_date": _text(document.get("publication_date")),
        "effective_on": _text(document.get("effective_on")),
        "comments_close_on": _text(document.get("comments_close_on")),
        "signing_date": _text(document.get("signing_date")),
        "agencies_json": json.dumps(agencies),
        "agency_slugs": agency_slugs or None,
        "docket_ids_json": json.dumps(document.get("docket_ids") or []),
        "regulation_id_numbers_json": json.dumps(document.get("regulation_id_numbers") or []),
        "cfr_references_json": json.dumps(document.get("cfr_references") or []),
        "topics_json": json.dumps(document.get("topics") or []),
        "html_url": _text(document.get("html_url")),
        "pdf_url": _text(document.get("pdf_url")),
        "body_html_url": _text(document.get("body_html_url")),
        "volume": _text(document.get("volume")),
        "start_page": _text(document.get("start_page")),
        "end_page": _text(document.get("end_page")),
        "subtype": _text(document.get("subtype")),
        "executive_order_number": _text(document.get("executive_order_number")),
        # The API exposes no update instant; preserve the public null column.
        "modify_date": None,
        "regulations_dot_gov_info_json": _stated_json(document, "regulations_dot_gov_info", {}),
        "regulations_dot_gov_docket_id": _text(info.get("docket_id")),
        "regulations_dot_gov_document_id": _text(info.get("document_id")),
        "regulations_dot_gov_comments_count": _text(info.get("comments_count")),
        "regulations_dot_gov_checked_at": _text(info.get("checked_regulationsdotgov_at")),
        "action": _text(document.get("action")),
        "correction_of": _text(document.get("correction_of")),
        "corrections_json": _stated_json(document, "corrections", []),
        "significant": None if significant is None else str(significant).lower(),
    }


#: The published table: the projection plus the host's derived ``rin``. The identity is the dated record, because
#: the Register reuses a document number when it republishes a correction under it on another date. Its key spelling is
#: the ``number@date`` DocSpec already records (``federal-register-source-record-id/1``). ``documents.fr_doc_num`` names a document
#: number only, so it is not a :class:`~spicy_docs.schemas.tables.Reference`: the host's ``table_joins`` watches it,
#: and the resolved link, on ``unpadded_federal_register_document_number``, is a DocSpec layer.
FEDERAL_REGISTER = table_contract(
    "federal_register",
    grain="One row per dated Federal Register document: a rule, proposed rule, notice or presidential document.",
    identity=("document_number", "publication_date"),
    version_column=None,
    key_spelling=FEDERAL_REGISTER_RECORD_KEY,
    columns={
        "document_number": "The Register's document number, spelled as it serves it (`2017-07442`, unpadded before 2013).",
        "title": "The document's title.",
        "abstract": "The agency's abstract of the document; often NULL.",
        "document_type": (
            "The Register's category as the API states it: `Rule`, `Proposed Rule`, `Notice`, "
            "`Presidential Document`, and on older records `Uncategorized Document`, `Correction` (none after "
            "2008-08-08) and `Sunshine Act Document`; NULL on a few records. Since 2008 a correction, an "
            "effective-date delay or a confirmation of a rule is itself typed `Rule` and shares the rule's RIN, "
            "docket and title; subtype is NULL on recent records, so tell them apart by `action`."
        ),
        "publication_date": "The date the document was published, canonical YYYY-MM-DD.",
        "effective_on": (
            "The `effective_on` date the Federal Register API states for the document. On a rule it is usually the "
            "effective date; the API also states one on some proposed rules and notices (a comment-period extension "
            "can carry the original proposal's date), so a date here does not by itself show that anything took "
            "effect. NULL where the API states none, as on most notices."
        ),
        "comments_close_on": "The public comment deadline, for a document that opens a comment period; often NULL.",
        "signing_date": "The date a presidential document was signed; NULL for other documents.",
        "agencies_json": "The issuing agencies as the Register's agency objects, a JSON array.",
        "agency_slugs": "The issuing agencies' Register slugs, comma-separated; NULL when none.",
        "docket_ids_json": "The docket labels the document states, a JSON array, as printed (many are agency numbers).",
        "regulation_id_numbers_json": (
            "The Regulation Identifier Numbers the API lists, a JSON array. `[]` on a large share of Rule documents "
            "every year, an API limit: some of those state a RIN in the printed text, and some print it inside "
            "docket_ids_json."
        ),
        "cfr_references_json": "The CFR citations the document affects, a JSON array of `{title, part, chapter, citation_url}`.",
        "topics_json": "The Register's CFR index terms for the document (`topics`), a JSON array; `[]` when it lists none.",
        "html_url": "The document's page on federalregister.gov.",
        "pdf_url": "The document's PDF rendition.",
        "body_html_url": "The document's full-text HTML body; the XML body the Register also serves carries no boilerplate.",
        "volume": "The Federal Register volume.",
        "start_page": "The document's first page.",
        "end_page": "The document's last page.",
        "subtype": (
            "The Register's subtype when the API sets it; NULL on recent records, so it does not separate a "
            "correction from its rule (`action` does)."
        ),
        "executive_order_number": "The executive order number, for a presidential executive order; NULL otherwise.",
        "modify_date": "Always NULL: the Register's API states no update instant.",
        "regulations_dot_gov_info_json": (
            "The Register's own statement of the regulations.gov docket and document it matched this document to "
            "(the API's `regulations_dot_gov_info`), a JSON object exactly as stated: `{}` where the Register states "
            "nothing, the time of its check alone where it checked and found nothing, otherwise any of the docket, "
            "the document, the comment count, the supporting documents and their titles. NULL on a row not read "
            "since the field was first requested (2026-10-03)."
        ),
        "regulations_dot_gov_docket_id": (
            "The regulations.gov docket the Register states for this document; NULL where it states none, even where "
            "it states a document: a docket is never read off the front of a document id."
        ),
        "regulations_dot_gov_document_id": (
            "The regulations.gov document the Register states for this document; NULL where it states none."
        ),
        "regulations_dot_gov_comments_count": (
            "Regulations.gov's comment count for that document as the Register relayed it at "
            "regulations_dot_gov_checked_at. The Register stops checking soon after the comment period closes, so "
            "the count is as of that check. It can be far higher than the comments regulations.gov posts "
            "(IRS-2024-0010-0001: 384,423 against 12 posted, 2026-10-03): a different fact from the posted comment "
            "rows this service holds. NULL where the Register states no count."
        ),
        "regulations_dot_gov_checked_at": (
            "When the Register last checked regulations.gov for this document, as it states it (UTC); NULL where it "
            "has not checked."
        ),
        "action": (
            "The document's action line as the API states it (`Final rule.`, `Final rule; correction.`, "
            "`Proposed rule; extension of comment period.`); NULL where it states none, as on many older records. "
            "It tells a rule from its later correction, delay or confirmation, which share the rule's type, RIN, "
            "docket and title."
        ),
        "correction_of": (
            "For one of the Register's own editorial corrections (numbered like `C1-2012-1234`), the API address of "
            "the document it corrects; NULL otherwise. An agency's correction published as a rule carries no such "
            "link; its `action` names it a correction."
        ),
        "corrections_json": (
            "The API addresses of the corrections the Register links to this document (its own editorial "
            "corrections), a JSON array; `[]` where it links none. NULL on a row not read since the field was first "
            "requested (2026-10-03)."
        ),
        "significant": (
            "Whether the document was deemed significant under Executive Order 12866, as the API states it: `true` "
            "or `false`; NULL where the API states neither, which is common, so NULL does not mean `false`."
        ),
        "rin": "The host's derived first RIN of `regulation_id_numbers_json`; NULL when it states none.",
    },
)

__all__ = [
    "FEDERAL_REGISTER",
    "FEDERAL_REGISTER_COLUMNS",
    "project_federal_register_document",
]
