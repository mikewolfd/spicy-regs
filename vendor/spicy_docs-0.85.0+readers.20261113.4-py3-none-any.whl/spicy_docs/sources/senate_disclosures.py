"""Senate public electronic PTRs, with source-native listing and report observations.

Narrow attributed port of parseSenateElectronicPtr and title/path rules from
Austin Starks' congressional-disclosures, revision
2965e8796bd4cb9423a83b964a1f9dbd076a0ad6 (MIT; senate_disclosures.LICENSE).
The existing bounded transport owns protected reads. The small session opener
implements the publisher's public agreement; it never retains session secrets.
Annual reports, paper extraction, identity enrichment and amendment matching are
outside this reader. A selected year is the filing/submission year.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from datetime import date
from urllib.parse import urlencode, urlsplit
from uuid import UUID

from spicy_docs.transport.capture import BoundedHttpCapture
from spicy_docs.transport.source_acquirer import utc_now

ORIGIN = "https://efdsearch.senate.gov"
SEARCH_URL = ORIGIN + "/search/report/data/"
PARSER_REVISION = "2965e8796bd4cb9423a83b964a1f9dbd076a0ad6"
HEADERS = ("#", "Transaction Date", "Owner", "Ticker", "Asset Name", "Asset Type", "Type", "Amount", "Comment")
MAX_BYTES = 2 * 1024 * 1024
_TITLE = re.compile(r"Periodic Transaction Report for (\d{2}/\d{2}/\d{4})(?: \(Amendment(?: (\d+))?\))?")
_PATH = re.compile(r"/search/view/(ptr|paper)/([0-9a-fA-F-]{36})/")


class SenateDisclosureError(ValueError):
    """Unresolved access, identity, scope or layout; never an empty population."""


def text(node):
    return " ".join(node.get_text().split())


def soup(body):
    from bs4 import BeautifulSoup

    if not isinstance(body, bytes) or not body or len(body) > MAX_BYTES:
        raise SenateDisclosureError("Senate response is empty or exceeds its byte bound")
    try:
        return BeautifulSoup(body.decode("utf-8"), "html.parser")
    except UnicodeError as error:
        raise SenateDisclosureError("Senate response is not UTF-8") from error


def slash_date(value):
    if not re.fullmatch(r"\d{2}/\d{2}/\d{4}", value):
        raise SenateDisclosureError("Senate date layout differs")
    try:
        month, day, year = map(int, value.split("/"))
        return date(year, month, day).isoformat()
    except ValueError as error:
        raise SenateDisclosureError("Senate date is invalid") from error


def report_title(value):
    match = _TITLE.fullmatch(value)
    if not match:
        raise SenateDisclosureError("Unexpected Senate PTR title")
    return {
        "report_date": slash_date(match[1]),
        "amendment_status": "none" if "(Amendment" not in value else "numbered" if match[2] else "unnumbered",
        "amendment_number": int(match[2]) if match[2] else None,
    }


def report_identity(path):
    match = _PATH.fullmatch(path)
    if not match or str(UUID(match[2])) != match[2].lower():
        raise SenateDisclosureError("Unexpected Senate report locator")
    return match[1], match[2].lower()


@dataclass(frozen=True)
class SenateYear:
    year: int

    def __post_init__(self):
        if type(self.year) is not int or not 2012 <= self.year <= 2100:
            raise SenateDisclosureError("Select an explicit supported Senate filing year")

    def form(self, start=0, length=100):
        if type(start) is not int or start < 0 or type(length) is not int or not 1 <= length <= 100:
            raise SenateDisclosureError("Invalid Senate page coordinates")
        return {
            "start": str(start),
            "length": str(length),
            "report_types": "[11]",
            "filer_types": "[]",
            "submitted_start_date": f"01/01/{self.year} 00:00:00",
            "submitted_end_date": f"12/31/{self.year} 23:59:59",
            "candidate_state": "",
            "senator_state": "",
            "office_id": "",
            "first_name": "",
            "last_name": "",
        }


def parse_search(body, selection, *, start, length=100):
    """Validate one exact page; the caller must reconcile every page's counts."""
    selection.form(start, length)
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise SenateDisclosureError("Senate search exceeds its byte bound")
    try:
        value = json.loads(body)
    except (ValueError, UnicodeError) as error:
        raise SenateDisclosureError("Senate search did not return JSON; access remains unresolved") from error
    if not isinstance(value, dict) or value.get("result") != "ok" or not isinstance(value.get("data"), list):
        raise SenateDisclosureError("Unexpected Senate search success shape")
    total = value.get("recordsFiltered")
    if (
        type(total) is not int
        or total < 0
        or type(value.get("recordsTotal")) is not int
        or value["recordsTotal"] < total
    ):
        raise SenateDisclosureError("Senate search counts are invalid")
    if start > total or len(value["data"]) != min(length, total - start):
        raise SenateDisclosureError("Senate search page is truncated or out of range")
    rows = []
    for position, row in enumerate(value["data"], start=1):
        if not isinstance(row, list) or len(row) != 5 or not all(isinstance(cell, str) for cell in row):
            raise SenateDisclosureError("Senate search row must have exactly five literal cells")
        first, last, filer, link, submitted = row
        anchors = soup(link.encode()).select("a")
        if len(anchors) != 1:
            raise SenateDisclosureError("Senate search row must state one report link")
        path = anchors[0].get("href", "")
        kind, identity = report_identity(path)
        title = text(anchors[0])
        filed_date = slash_date(submitted.strip())
        if not first.strip() or not last.strip() or not filer.strip() or int(filed_date[:4]) != selection.year:
            raise SenateDisclosureError("Senate search row identity or filing year differs")
        rows.append(
            {
                "report_id": identity,
                "report_kind": "electronic" if kind == "ptr" else "paper",
                "source_url": ORIGIN + path,
                "first_name": first.strip(),
                "last_name": last.strip(),
                "filer_label": filer.strip(),
                "report_title": title,
                "submitted_date": filed_date,
                "filing_year": selection.year,
                "search_start": start,
                "search_row": position,
                "raw_search_cells": row,
                **report_title(title),
            }
        )
    if len({row["report_id"] for row in rows}) != len(rows):
        raise SenateDisclosureError("Senate search repeats a report identity")
    return value["recordsTotal"], total, rows


def parse_electronic_ptr(body, filing):
    """Literal cells plus native counts; no amendment collapse or estimated values."""
    path = urlsplit(filing["source_url"])
    if path.scheme != "https" or path.netloc != "efdsearch.senate.gov" or path.query or path.fragment:
        raise SenateDisclosureError("Senate filing URL differs")
    kind, identity = report_identity(path.path)
    if kind != "ptr" or identity != filing["report_id"]:
        raise SenateDisclosureError("Only the stated electronic PTR identity can be read")
    page = soup(body)
    headings = page.select("h1")
    if len(headings) != 1 or text(headings[0]) != filing["report_title"]:
        raise SenateDisclosureError("Senate report title differs from its listing")
    report_title(text(headings[0]))
    names = page.select("h2.filedReport")
    if len(names) != 1:
        raise SenateDisclosureError("Senate report filer heading is missing")
    name = text(names[0])
    # The publisher prints its search identity in parentheses after the display name.
    expected = f"({filing['last_name']}, {filing['first_name']})"

    def normalize(value):
        return re.sub(r"[\W_]+", "", value).casefold()

    printed = re.search(r"\(([^()]*)\)$", name)
    # The listing's split surname may include Jr. while its full filer label
    # and report move the suffix after the given names (McConnell, 2025).
    # Compare either native listing representation, never a fuzzy person match.
    listing_label = re.fullmatch(r"(.+) \((?:Senator|Former Senator|Candidate)\)", filing["filer_label"])
    expected_names = [expected]
    if listing_label:
        expected_names.append(listing_label[1])
    if printed is None or normalize(printed[1]) not in {normalize(value) for value in expected_names}:
        raise SenateDisclosureError("Senate report filer differs from its listing")
    filed = [text(node) for node in page.select("p.muted strong") if text(node).startswith("Filed ")]
    if len(filed) != 1 or not re.fullmatch(r"Filed \d{2}/\d{2}/\d{4} @ (?:[1-9]|1[0-2])(?::[0-5]\d)? [AP]M", filed[0]):
        raise SenateDisclosureError("Senate filed timestamp layout differs")
    if slash_date(filed[0].split()[1]) != filing["submitted_date"]:
        raise SenateDisclosureError("Senate filed date differs from its listing")
    tables = page.select("table")
    if len(tables) != 1 or tuple(text(th) for th in tables[0].select("thead th")) != HEADERS:
        raise SenateDisclosureError("Unexpected Senate transaction table layout")
    if [text(h) for h in page.select("h3")] != ["Transactions"]:
        raise SenateDisclosureError("Unexpected Senate report sections")
    total_nodes = [text(li) for li in page.select("li") if re.fullmatch(r"\(\d+ transactions? total\)", text(li))]
    if len(total_nodes) != 1:
        raise SenateDisclosureError("Senate report omitted its transaction count")
    total = int(re.search(r"\d+", total_nodes[0])[0])
    transactions = []
    for position, tr in enumerate(tables[0].select("tbody tr"), start=1):
        cells = tr.find_all("td", recursive=False)
        if len(cells) != len(HEADERS) or any(c.has_attr("colspan") or c.has_attr("rowspan") for c in cells):
            raise SenateDisclosureError("Unexpected Senate transaction row width or span")
        raw = [text(c) for c in cells]
        if not raw[0].isascii() or not raw[0].isdigit() or int(raw[0]) <= 0:
            raise SenateDisclosureError("Senate transaction row number is invalid")
        transactions.append(
            {
                "row_number": int(raw[0]),
                "row_position": position,
                "transaction_date": slash_date(raw[1]),
                "transaction_date_raw": raw[1],
                "owner": raw[2],
                "ticker": None if raw[3] in ("", "--") else raw[3],
                "ticker_raw": raw[3],
                "asset_name": raw[4],
                "asset_type": raw[5],
                "transaction_type": raw[6],
                "amount_raw": raw[7],
                "comment": None if raw[8] in ("", "--") else raw[8],
                "comment_raw": raw[8],
                "raw_cells": raw,
                "source_locator": f"table tbody tr:nth-of-type({position})",
            }
        )
    if len(transactions) != total or {r["row_number"] for r in transactions} != set(range(1, total + 1)):
        raise SenateDisclosureError("Senate transaction rows differ from the printed count/identities")
    return {"filer_heading": name, "filed_at_raw": filed[0], "transaction_count": total, "transactions": transactions}


class SenateEfdReader:
    """Protected reads with ephemeral caller-owned agreement/session credentials."""

    def __init__(self, *, cookie, csrf, max_requests=200, transport=None, interval=0.5):
        if not cookie or not csrf:
            raise SenateDisclosureError("An accepted Senate public agreement session is required")
        self._headers = {
            "Cookie": cookie,
            "X-CSRFToken": csrf,
            "Referer": ORIGIN + "/search/",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        self._secrets = (cookie, csrf)
        self.client = BoundedHttpCapture(
            max_requests=max_requests,
            timeout_seconds=30,
            min_request_interval_seconds=interval,
            user_agent="spicy-docs-senate-disclosures/1.0",
            error_type=SenateDisclosureError,
            transport=transport,
            clock=utc_now,
        )

    @classmethod
    def open(cls, *, accepted_terms=False, **kwargs):
        """Two bounded public-session requests; no token/cookie enters retained evidence."""
        if accepted_terms is not True:
            raise SenateDisclosureError("Explicit acceptance of Senate eFD use restrictions is required")
        import httpx

        from spicy_docs.transport.bounded import bounded_response_chunks

        home = ORIGIN + "/search/home/"
        try:
            with httpx.Client(
                timeout=30, follow_redirects=False, trust_env=False, headers={"Accept-Encoding": "identity"}
            ) as session:
                with session.stream("GET", home) as response:
                    if response.status_code != 200:
                        raise SenateDisclosureError(f"Senate agreement unavailable: HTTP {response.status_code}")
                    body = b"".join(
                        bounded_response_chunks(response, max_bytes=65536, error_type=SenateDisclosureError)
                    )
                tokens = soup(body).select('input[name="csrfmiddlewaretoken"]')
                if len(tokens) != 1 or not tokens[0].get("value"):
                    raise SenateDisclosureError("Senate public agreement token is unavailable")
                time.sleep(0.5)
                with session.stream(
                    "POST",
                    home,
                    data={"prohibition_agreement": "1"},
                    headers={"Referer": home, "X-CSRFToken": tokens[0]["value"]},
                ) as response:
                    if response.status_code != 302 or response.headers.get("location") != "/search/":
                        raise SenateDisclosureError(f"Senate agreement refused: HTTP {response.status_code}")
                    # The agreement body is session material, not a filing.
                    b"".join(bounded_response_chunks(response, max_bytes=65536, error_type=SenateDisclosureError))
                cookie = "; ".join(k + "=" + v for k, v in session.cookies.items())
                csrf = session.cookies.get("csrftoken")
                return cls(cookie=cookie, csrf=csrf, **kwargs)
        except httpx.HTTPError:
            raise SenateDisclosureError("Senate public agreement transport failed") from None

    def _capture(self, url, **kwargs):
        capture = self.client.capture(url, max_bytes=MAX_BYTES, request_headers=self._headers, max_attempts=1, **kwargs)
        if any(secret.encode() in capture.body for secret in self._secrets):
            raise SenateDisclosureError("Senate response echoed session material; not retained")
        if capture.content_encoding != "identity":
            raise SenateDisclosureError("Senate response encoding differs")
        return capture

    def search(self, selection, *, start=0, length=100):
        capture = self._capture(SEARCH_URL, method="POST", content=urlencode(selection.form(start, length)).encode())
        if (capture.content_type or "").split(";")[0].strip() != "application/json":
            raise SenateDisclosureError("Senate search did not return JSON; session access remains unresolved")
        return capture

    def report(self, filing):
        kind, identity = report_identity(urlsplit(filing["source_url"]).path)
        if (
            kind != "ptr"
            or identity != filing["report_id"]
            or filing["source_url"] != ORIGIN + f"/search/view/ptr/{identity}/"
        ):
            raise SenateDisclosureError("Senate report is outside selected electronic filing scope")
        capture = self._capture(filing["source_url"])
        if (capture.content_type or "").split(";")[0].strip() != "text/html":
            raise SenateDisclosureError("Senate report did not return HTML")
        return capture

    def close(self):
        self.client.close()
