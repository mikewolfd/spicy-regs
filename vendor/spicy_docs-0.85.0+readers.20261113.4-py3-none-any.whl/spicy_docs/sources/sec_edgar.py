"""Literal SEC submissions and companyfacts JSON with bounded, declared access.

Official API shapes suffice for this scope. See docs/sources/sec-edgar.md for
the qualified EdgarTools revision and why its analytical selection is not used.
No ticker resolution, XBRL context reconstruction or amendment replacement.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from urllib.parse import quote

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.sources.sec_comments.acquisition import _checked_agent, declared_user_agent
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_byte_bound, check_request_count, check_timing

MAX_BYTES = 32 * 1024 * 1024
BASE = "https://data.sec.gov"


class EdgarError(ValueError):
    """An unresolved SEC request or malformed publisher observation."""


def cik(value: str | int) -> str:
    text = str(value)
    if not re.fullmatch(r"[0-9]{1,10}", text) or int(text) == 0:
        raise EdgarError("SEC issuer requires a numeric CIK, not a ticker")
    return text.zfill(10)


def accession(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{10}-[0-9]{2}-[0-9]{6}", value):
        raise EdgarError("SEC accession has an invalid shape")
    return value


def iso_date(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value):
        raise EdgarError("SEC date must be YYYY-MM-DD")
    try:
        date.fromisoformat(value)
    except ValueError as error:
        raise EdgarError("SEC date is invalid") from error
    return value


def submissions_url(issuer, continuation=None):
    issuer = cik(issuer)
    if continuation is None:
        return f"{BASE}/submissions/CIK{issuer}.json"
    if not isinstance(continuation, str) or not re.fullmatch(rf"CIK{issuer}-submissions-[0-9]+\.json", continuation):
        raise EdgarError("SEC continuation must belong to the selected CIK")
    return f"{BASE}/submissions/{continuation}"


def companyfacts_url(issuer):
    return f"{BASE}/api/xbrl/companyfacts/CIK{cik(issuer)}.json"


def filing_url(issuer, number, document=None):
    root = f"https://www.sec.gov/Archives/edgar/data/{int(cik(issuer))}/{accession(number).replace('-', '')}/"
    if document is None:
        return root + number + "-index.html"
    # Insider forms can name a publisher stylesheet directory (xslF345X05/...).
    if (
        not isinstance(document, str)
        or not document
        or re.search(r"[\\?#%]", document)
        or any(part in {"", ".", ".."} for part in document.split("/"))
    ):
        raise EdgarError("SEC primary document must be a safe relative path")
    return root + quote(document, safe="/.-_")


def read_json(body: bytes):
    value = load_bounded_json(
        body,
        source="SEC EDGAR",
        error_type=EdgarError,
        number_policy="decimal",
        max_bytes=MAX_BYTES,
        max_nodes=4_000_000,
    )
    if not isinstance(value, dict):
        raise EdgarError("SEC EDGAR response must be an object")
    return value


@dataclass(frozen=True)
class SubmissionPage:
    metadata: dict
    rows: tuple[dict, ...]
    continuations: tuple[dict, ...]


def read_submissions(body: bytes, issuer, *, continuation: str | None = None) -> SubmissionPage:
    """Read all compact columns, including unknown ones; unequal arrays refuse."""
    issuer = cik(issuer)
    submissions_url(issuer, continuation)
    value = read_json(body)
    if continuation is None:
        if cik(value.get("cik", "")) != issuer or not isinstance(value.get("name"), str):
            raise EdgarError("SEC submissions issuer identity differs")
        filings = value.get("filings")
        if not isinstance(filings, dict) or not isinstance(filings.get("files"), list):
            raise EdgarError("SEC submissions lacks continuation inventory")
        columns, files = filings.get("recent"), filings["files"]
        metadata = {key: item for key, item in value.items() if key != "filings"}
        metadata["filings_metadata"] = {key: item for key, item in filings.items() if key not in {"recent", "files"}}
    else:
        columns, files, metadata = value, [], {}
    if (
        not isinstance(columns, dict)
        or not {"accessionNumber", "filingDate", "reportDate", "form", "primaryDocument"} <= columns.keys()
    ):
        raise EdgarError("SEC submissions missing required compact columns")
    if any(not isinstance(values, list) for values in columns.values()) or len({len(v) for v in columns.values()}) != 1:
        raise EdgarError("SEC submissions column lengths differ")
    rows = tuple(dict(zip(columns, values, strict=True)) for values in zip(*columns.values(), strict=True))
    seen = set()
    for row in rows:
        number = accession(row["accessionNumber"])
        if number in seen:
            raise EdgarError("SEC submissions repeats an accession within a page")
        seen.add(number)
        iso_date(row["filingDate"])
        if row["reportDate"] not in {None, ""}:
            iso_date(row["reportDate"])
        if not isinstance(row["form"], str) or not row["form"]:
            raise EdgarError("SEC submission lacks its form")
        if row["primaryDocument"] not in {None, ""}:
            filing_url(issuer, number, row["primaryDocument"])
    names = set()
    for file in files:
        if not isinstance(file, dict):
            raise EdgarError("SEC continuation descriptor must be an object")
        if not isinstance(file.get("name"), str):
            raise EdgarError("SEC continuation lacks its filename")
        submissions_url(issuer, file["name"])
        if file["name"] in names:
            raise EdgarError("SEC continuation repeats its filename")
        names.add(file["name"])
        if type(file.get("filingCount")) is not int or file["filingCount"] < 0:
            raise EdgarError("SEC continuation lacks its filing count")
        if iso_date(file.get("filingFrom")) > iso_date(file.get("filingTo")):
            raise EdgarError("SEC continuation date bounds are reversed")
    return SubmissionPage(metadata, rows, tuple(files))


def read_companyfacts(body: bytes, issuer) -> dict:
    value = read_json(body)
    if (
        cik(value.get("cik", "")) != cik(issuer)
        or not isinstance(value.get("entityName"), str)
        or not isinstance(value.get("facts"), dict)
    ):
        raise EdgarError("SEC companyfacts issuer or expected shape differs")
    return value


def fact_observations(value: dict, concepts):
    """Yield every selected observation with its exact API JSON pointer and unit."""

    def escape(part):
        return part.replace("~", "~0").replace("/", "~1")

    for taxonomy, concept in concepts:
        tax = value["facts"].get(taxonomy, {})
        if not isinstance(tax, dict):
            raise EdgarError("SEC taxonomy must be an object")
        if concept not in tax:
            continue
        data = tax[concept]
        if not isinstance(data, dict) or not isinstance(data.get("units"), dict):
            raise EdgarError("SEC concept lacks unit arrays")
        for unit, rows in data["units"].items():
            if not unit or not isinstance(rows, list):
                raise EdgarError("SEC unit observations must be an array")
            for index, row in enumerate(rows):
                if not isinstance(row, dict) or not {"val", "accn", "end", "filed", "form"} <= row.keys():
                    raise EdgarError("SEC fact lacks identity, value or period")
                accession(row["accn"])
                iso_date(row["filed"])
                iso_date(row["end"])
                if "start" in row and row["start"] is not None and iso_date(row["start"]) > row["end"]:
                    raise EdgarError("SEC fact period is reversed")
                if row["val"] is not None and (type(row["val"]) not in {int, Decimal}):
                    raise EdgarError("SEC fact value must be numeric or explicit null")
                if not isinstance(row["form"], str) or not row["form"]:
                    raise EdgarError("SEC fact lacks its form")
                pointer = (
                    "/facts/" + "/".join(map(escape, (taxonomy, concept))) + "/units/" + escape(unit) + f"/{index}"
                )
                yield taxonomy, concept, unit, data.get("label"), data.get("description"), row, pointer


class EdgarAcquirer(SourceAcquirer):
    """Sequential declared SEC access; no wall recovery and no hidden retries."""

    def __init__(
        self,
        *,
        contact_email=None,
        max_requests=16,
        max_bytes=MAX_BYTES,
        min_request_interval_seconds=0.5,
        timeout_seconds=60,
        transport=None,
    ):
        check_request_count(max_requests)
        check_byte_bound(max_bytes, "max_bytes", MAX_BYTES)
        check_timing(timeout_seconds, min_request_interval_seconds)
        if min_request_interval_seconds < 0.5:
            raise EdgarError("SEC EDGAR requires at least 0.5 seconds between requests")
        agent = (
            declared_user_agent(contact_email)
            .replace("sec-comments", "sec-edgar")
            .replace("SEC rulemaking comments", "SEC EDGAR")
        )
        _checked_agent(agent, live=transport is None)
        self.max_bytes = max_bytes
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=timeout_seconds,
            min_request_interval_seconds=min_request_interval_seconds,
            user_agent=agent,
            label="SEC EDGAR",
            error_type=EdgarError,
            context_key="sec_edgar_acquisition",
            transport=transport,
            keyless=True,
        )

    def acquire(self, issuer, *, kind="submissions", continuation=None):
        if kind not in {"submissions", "companyfacts"} or (kind != "submissions" and continuation is not None):
            raise EdgarError("Unsupported SEC EDGAR route")
        url = submissions_url(issuer, continuation) if kind == "submissions" else companyfacts_url(issuer)

        def parse(capture, _limit):
            if capture.resolved_url != url:
                raise EdgarError("SEC final URL differs from its selected locator")
            return (
                read_submissions(capture.body, issuer, continuation=continuation)
                if kind == "submissions"
                else read_companyfacts(capture.body, issuer)
            )

        return self.capture_validated(
            url,
            media_types=("application/json",),
            parse=parse,
            max_bytes=self.max_bytes,
            unavailable=lambda response: EdgarError(
                f"SEC EDGAR HTTP {response.status_code}; request remains unresolved"
            ),
            context={"cik": cik(issuer), "kind": kind, "continuation": continuation},
            reset_budget=False,
            max_attempts=1,
        )
