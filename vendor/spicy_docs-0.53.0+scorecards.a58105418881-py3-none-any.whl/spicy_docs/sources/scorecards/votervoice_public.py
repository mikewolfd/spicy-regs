"""Bounded primitives of the publisher-linked public VoterVoice scorecard app.

Each publisher configures its own original attribution and owns table meanings.
Only the reviewed, read-only API paths receive the anonymous bootstrap header.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal
from urllib.parse import urljoin, urlsplit

from spicy_docs.sources.scorecards.common import ScorecardSourceError, decimal_text, json_data, soup

API = "https://www.votervoice.net/Api"
HOSTS = ("www.votervoice.net",)
TYPES = {"M": "Roll Call Votes", "S": "Sponsorship", "C": "Custom Action"}


@dataclass(frozen=True)
class Application:
    publisher_id: str
    index_url: str
    plugin_url: str
    application_url: str
    association: str
    native_prefix: str
    stance_name: str
    allow_unconfigured_items: bool = False


def _scalar(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int, Decimal)):
        raise ScorecardSourceError("VoterVoice native scalar changed type")
    return str(value)


def _identifier(value, pattern):
    text = _scalar(value)
    if text is None or re.fullmatch(pattern, text) is None:
        raise ScorecardSourceError("VoterVoice source identity changed shape")
    return text


def _array(data, description):
    if not isinstance(data, list) or not data or not all(isinstance(row, dict) for row in data):
        raise ScorecardSourceError("VoterVoice " + description + " is not a complete nonempty array")
    return data


def bootstrap(context, application):
    if context.evidence_policy == "full":
        raise ScorecardSourceError(
            "VoterVoice public application bootstrap requires hash_only or metadata_only evidence"
        )
    original = context.read(
        application.index_url,
        stage="scorecards:" + application.publisher_id + ":index",
        hosts=(urlsplit(application.index_url).hostname,),
    )
    if not soup(original).select_one('script[src="' + application.plugin_url + '"]'):
        raise ScorecardSourceError("VoterVoice no longer links the reviewed public scorecard application")
    plugin = context.read(
        application.plugin_url, stage="scorecards:" + application.publisher_id + ":plugin", hosts=HOSTS
    )
    text = plugin.body.decode("utf-8")
    if (
        "siteRootUrl: 'https://www.votervoice.net/iframes/" + application.association + "', defaultSrc: '/Scorecard'"
        not in text
    ):
        raise ScorecardSourceError("VoterVoice scorecard application attribution changed")
    app = context.read(
        application.application_url, stage="scorecards:" + application.publisher_id + ":application", hosts=HOSTS
    )
    text = app.body.decode("utf-8")
    match = re.search(r'api: \{ url: "/Api", key: "([^"\r\n]+)"', text)
    if match is None or 'associationIdName: "' + application.association + '"' not in text:
        raise ScorecardSourceError("VoterVoice public application bootstrap is absent")
    scripts = soup(app).select('script[src^="/UserSite/Scripts/Scorecard.Index?"]')
    if len(scripts) != 1:
        raise ScorecardSourceError("VoterVoice source scorecard client is absent or repeated")
    script_url = urljoin(application.application_url, str(scripts[0]["src"]))
    client = context.read(script_url, stage="scorecards:" + application.publisher_id + ":source-client", hosts=HOSTS)
    # The source client, rather than a score formula, supplies absent-score display
    # and the table's native field meaning. Keep this bootstrap private.
    code = client.body.decode("utf-8")
    if 'y=r("<td>N/A<\\/td>")' not in code or '"/Scorecards/"+n+"/Scorings"' not in code:
        raise ScorecardSourceError("VoterVoice scorecard client display or data route changed")
    headers = {"Authorization": match[1], "Accept-Language": "en-US", "VV-Language": "en-US"}
    return [original, plugin, app, client], headers


def read_api(context, path, headers, stage, application):
    # Only fixed reviewed GET paths receive the page-provided public header.
    paths = (
        r"/Governments\?association=" + re.escape(application.association) + r"&activeScorecards=true",
        r"/Scorecards\?association=" + re.escape(application.association) + r"&government=\./USA&active=(?:true|false)",
        r"/Scorecards/" + application.native_prefix + r"-\d+/Scorings",
        r"/Scorecards/Criteria/[MSC]-"
        + application.native_prefix
        + r"-\d+\?association="
        + re.escape(application.association),
    )
    if not any(re.fullmatch(pattern, path) for pattern in paths):
        raise ScorecardSourceError("VoterVoice read is outside the reviewed scorecard API")
    document = context.read_request(
        API + path,
        method="GET",
        content=None,
        stage="scorecards:" + application.publisher_id + ":" + stage,
        hosts=HOSTS,
        request_headers=headers,
    )
    if (document.response.content_type or "").split(";", 1)[0].strip() != "application/json":
        raise ScorecardSourceError("VoterVoice API response is not JSON")
    return document, json_data(document)


def scorings(context, edition, headers, application, suffix=""):
    document, data = read_api(
        context,
        "/Scorecards/" + edition.edition_id + "/Scorings",
        headers,
        "scorings:" + edition.edition_id + suffix,
        application,
    )
    rows = _array(data, "edition scoring population")
    identities = []
    for row in rows:
        member = row.get("official")
        if not isinstance(member, dict) or not isinstance(member.get("office"), dict):
            raise ScorecardSourceError("VoterVoice source member context is absent")
        identities.append(_identifier(member.get("id"), r"[1-9]\d*"))
        _identifier(member.get("politicianId"), r"[1-9]\d*")
        office = member["office"]
        if office.get("electedBody") not in {"US House", "US Senate"}:
            raise ScorecardSourceError("VoterVoice scoring population contains a noncongressional office")
        for field in ["givenNames", "surname", "displayName"]:
            if not isinstance(member.get(field), str) or not member[field]:
                raise ScorecardSourceError("VoterVoice native member field is absent")
        if member.get("party") is not None and not isinstance(member["party"], str):
            raise ScorecardSourceError("VoterVoice native party changed type")
        for field in ["state", "electoralDistrict", "constituency"]:
            if not isinstance(office.get(field), str):
                raise ScorecardSourceError("VoterVoice native office field changed type")
        if not office["state"] or (office["electedBody"] == "US Senate" and office["electoralDistrict"]):
            raise ScorecardSourceError("VoterVoice source chamber and district disagree")
        if "score" in row and decimal_text(_scalar(row["score"])) is None:
            raise ScorecardSourceError("VoterVoice reported numeric score is malformed")
        factors = row.get("factors")
        if not isinstance(factors, list) or not all(isinstance(f, dict) for f in factors):
            raise ScorecardSourceError("VoterVoice scoring factors are absent")
        ids = []
        for factor in factors:
            cid = _identifier(factor.get("criterionId"), r"[MSC]-" + application.native_prefix + r"-\d+")
            if factor.get("positionType") != TYPES[cid[0]]:
                raise ScorecardSourceError("VoterVoice factor type and criterion identity disagree")
            if decimal_text(_scalar(factor.get("effect"))) is None:
                raise ScorecardSourceError("VoterVoice native factor effect is absent or malformed")
            _scalar(factor.get("position"))
            ids.append(cid)
        if len(ids) != len(set(ids)):
            raise ScorecardSourceError("VoterVoice member repeats a scoring factor")
    if len(identities) != len(set(identities)):
        raise ScorecardSourceError("VoterVoice scoring population repeats a member context")
    return document, rows


def criterion(context, identity, headers, application, suffix=""):
    document, data = read_api(
        context,
        "/Scorecards/Criteria/" + identity + "?association=" + application.association,
        headers,
        "criterion:" + identity + suffix,
        application,
    )
    if not isinstance(data, dict) or data.get("positionType") != TYPES[identity[0]]:
        raise ScorecardSourceError("VoterVoice criterion detail has a different action shape")
    if not isinstance(data.get("displayName"), str) or not data["displayName"]:
        raise ScorecardSourceError("VoterVoice criterion detail is unnamed")
    positions = data.get("positions")
    if application.allow_unconfigured_items:
        if not isinstance(positions, list) or not all(isinstance(group, dict) for group in positions):
            raise ScorecardSourceError("VoterVoice criterion position groups are malformed")
    else:
        positions = _array(positions, "criterion position groups")
    actions = {}
    for group_number, group in enumerate(positions):
        if not isinstance(group.get("description"), str) or not group["description"]:
            raise ScorecardSourceError("VoterVoice criterion position group is unnamed")
        if not isinstance(group.get("officials"), list):
            raise ScorecardSourceError("VoterVoice criterion position member array is absent")
        for member_number, member in enumerate(group["officials"]):
            mid = _identifier(member.get("occupancyId"), r"[1-9]\d*")
            if mid in actions or not isinstance(member.get("displayName"), str):
                raise ScorecardSourceError("VoterVoice criterion repeats a member action or lacks its name")
            actions[mid] = (group["description"], f"$.positions[{group_number}].officials[{member_number}]")
    motion = data.get("legislativeMotion")
    if motion is not None:
        if not isinstance(motion, dict) or not isinstance(motion.get("legislativeProposal"), dict):
            raise ScorecardSourceError("VoterVoice legislative detail changed shape")
        stance = motion.get("associationStance")
        if not isinstance(stance, dict) or stance.get("associationName") != application.stance_name:
            raise ScorecardSourceError("VoterVoice publisher position attribution changed")
        if not isinstance(stance.get("supportsMotion"), bool) and not (
            application.allow_unconfigured_items and stance.get("supportsMotion") is None
        ):
            raise ScorecardSourceError("VoterVoice publisher motion position is absent")
        for urls in [motion.get("externalUrls"), motion["legislativeProposal"].get("externalUrls")]:
            if not isinstance(urls, list) or not all(
                isinstance(url, str) and urlsplit(url).scheme in {"https", "http"} for url in urls
            ):
                raise ScorecardSourceError("VoterVoice legislative reference list changed shape")
    if data.get("explanationHtml") is not None and not isinstance(data["explanationHtml"], str):
        raise ScorecardSourceError("VoterVoice criterion explanation changed type")
    return document, data, actions
