"""Publisher-specific third-party congressional scorecard readers."""

from importlib import import_module

from spicy_docs.sources.scorecards.common import (
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    validate_scorecard_bundle,
)

ADAPTER_PUBLISHERS = {
    name: {
        "c4ip_api": "c4ip",
        "cpac_current": "cpac",
        "cpac_pdf_2023": "cpac",
        "nfib_pdf": "nfib",
        "frc_action_pdf": "frc_action",
        "national_parks_action_api": "national_parks_action",
        "national_parks_action_api_details": "national_parks_action",
        "national_parks_action_pdf_2020": "national_parks_action",
        "us_chamber_archive": "us_chamber",
        "us_chamber_2019": "us_chamber",
        "new_american_roster": "new_american",
    }.get(name, name)
    for name in (
        "lcv",
        "afl_cio",
        "heritage_action",
        "humane_world_action",
        "nea",
        "c4ip",
        "c4ip_api",
        "afp",
        "ijm",
        "hrc",
        "end_citizens_united",
        "ajp_action",
        "numbersusa",
        "cpac",
        "cpac_current",
        "cpac_pdf_2023",
        "afscme",
        "aauw",
        "ara",
        "leadership_conference",
        "american_energy_alliance",
        "ntu",
        "club_for_growth",
        "foreign_policy_america",
        "ada",
        "norml",
        "naacp",
        "nfib",
        "nfib_pdf",
        "arts_action",
        "frc_action",
        "frc_action_pdf",
        "ffrf_action",
        "acec",
        "national_parks_action",
        "national_parks_action_api",
        "national_parks_action_api_details",
        "national_parks_action_pdf_2020",
        "aclu",
        "first_focus",
        "childrens_defense",
        "new_american",
        "new_american_roster",
        "us_chamber_archive",
        "us_chamber_2019",
        "network",
        "nrf",
        "goa",
        "planned_parenthood",
    )
}
ADAPTERS = tuple(ADAPTER_PUBLISHERS)


def get_adapter(name: str):
    if name not in ADAPTERS:
        raise ScorecardSourceError("Unknown scorecard publisher adapter")
    module = "humane" if name == "humane_world_action" else name
    return import_module(f"spicy_docs.sources.scorecards.{module}")


__all__ = [
    "ADAPTERS",
    "ADAPTER_PUBLISHERS",
    "ScorecardAcquisition",
    "ScorecardContext",
    "ScorecardEdition",
    "ScorecardSourceError",
    "get_adapter",
    "validate_scorecard_bundle",
]
