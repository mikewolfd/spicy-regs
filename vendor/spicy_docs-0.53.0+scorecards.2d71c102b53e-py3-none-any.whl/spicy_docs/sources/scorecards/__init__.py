"""Publisher-specific third-party congressional scorecard readers."""

from importlib import import_module

from spicy_docs.sources.scorecards.common import (
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    validate_scorecard_bundle,
)

ADAPTER_PUBLISHERS = {
    name: {"c4ip_api": "c4ip", "cpac_current": "cpac"}.get(name, name)
    for name in (
        "lcv",
        "afl_cio",
        "heritage_action",
        "humane_world_action",
        "nea",
        "c4ip",
        "c4ip_api",
        "afp",
        "ijm",
        "hrc",
        "end_citizens_united",
        "ajp_action",
        "numbersusa",
        "cpac",
        "cpac_current",
        "afscme",
        "aauw",
        "ara",
        "leadership_conference",
        "american_energy_alliance",
        "ntu",
    )
}
ADAPTERS = tuple(ADAPTER_PUBLISHERS)


def get_adapter(name: str):
    if name not in ADAPTERS:
        raise ScorecardSourceError("Unknown scorecard publisher adapter")
    module = "humane" if name == "humane_world_action" else name
    return import_module(f"spicy_docs.sources.scorecards.{module}")


__all__ = [
    "ADAPTERS",
    "ADAPTER_PUBLISHERS",
    "ScorecardAcquisition",
    "ScorecardContext",
    "ScorecardEdition",
    "ScorecardSourceError",
    "get_adapter",
    "validate_scorecard_bundle",
]
