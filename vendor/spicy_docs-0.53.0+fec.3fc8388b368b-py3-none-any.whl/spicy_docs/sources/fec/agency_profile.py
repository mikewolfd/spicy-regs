"""Bounded agency-report records from one retained FEC FOIA annual XML or Oversight.gov report page.

The parsers are the qualified native readers
:func:`spicy_docs.sources.agency_reports.foia.parse_foia_annual_report` and
:func:`spicy_docs.sources.agency_reports.oversight.parse_oversight_report`;
this profile pins one retained original by digest and hands their complete
parsed structures to the publisher as ordered records. Coordinates identify
observations; no field is interpreted, summed or linked.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from urllib.parse import urlsplit

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.agency_reports.foia import parse_foia_annual_report
from spicy_docs.sources.agency_reports.oversight import parse_oversight_report
from spicy_docs.sources.fec.originals import MAX_FILE_BYTES, original_capture

SCHEMA_NAME = "fec-agency-report-record"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
SCOPE_ID = "fec-retained-agency-reports"
MAX_PAGE_BYTES = 1024**2
MAX_RECORD_BYTES = 128 * 1024
MAX_DECODED_BYTES = 64 * 1024**2
#: Oversight's own public report host; the HTML parser re-checks the /reports/ path shape.
OVERSIGHT_URL_PREFIX = "https://www.oversight.gov/reports/"


def _oversight_url(url: object) -> str:
    """Accept exactly the public Oversight report URL shape, without credentials or fragments."""
    if not isinstance(url, str) or len(url) > 16 * 1024 or not url.startswith(OVERSIGHT_URL_PREFIX):
        raise ValueError("Oversight report capture requires the public report page URL")
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "www.oversight.gov"
        or parsed.port not in (None, 443)
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("Oversight report capture requires a credential-free report page URL")
    return url


def _oversight_capture(capture: Mapping) -> dict:
    """Validate one retained Oversight page capture: the digest/size/time rules of an FEC original, its own host."""
    value = original_capture(capture, validate_url=_oversight_url)
    if "resolvedUrl" in value and value["resolvedUrl"] != value["requestUrl"]:
        raise ValueError("Oversight report capture resolved to a different request")
    if value["representation"] != "opaque":
        raise ValueError("Oversight report page is not an opaque original")
    return value


def agency_report_scope(
    capture,
    *,
    format,
    max_records_per_page=1000,
    max_record_bytes=MAX_RECORD_BYTES,
    max_decoded_bytes=MAX_DECODED_BYTES,
):
    """Select one complete retained agency-report original, with explicit format and resource bounds.

    ``format`` is ``"foia-xml"`` for a native NIEM FOIA annual report on an FEC host or
    ``"oversight-html"`` for an Oversight.gov report page; nothing else is a selected input.
    """
    if format not in {"foia-xml", "oversight-html"}:
        raise ValueError("select a supported agency report format")
    capture = _oversight_capture(capture) if format == "oversight-html" else original_capture(capture)
    if capture["representation"] != "opaque":
        raise ValueError("agency report originals are opaque bytes")
    for value, maximum in (
        (max_records_per_page, 1000),
        (max_record_bytes, MAX_RECORD_BYTES),
        (max_decoded_bytes, MAX_DECODED_BYTES),
    ):
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError("FEC agency report parsing bound is invalid")
    if capture["byteSize"] > max_decoded_bytes:
        raise ValueError("FEC agency report exceeds its decoded byte bound")
    return {
        "capture": capture,
        "format": format,
        "max_records_per_page": max_records_per_page,
        "max_record_bytes": max_record_bytes,
        "max_decoded_bytes": max_decoded_bytes,
    }


def _scope(value):
    if not isinstance(value, Mapping) or set(value) != {
        "capture",
        "format",
        "max_records_per_page",
        "max_record_bytes",
        "max_decoded_bytes",
    }:
        raise ValueError("FEC agency report scope fields differ")
    return agency_report_scope(**dict(value))


def _key(index):
    return f"fec-agency://page/{index}"


def iter_retained_agency_originals(scope, *, blob_source):
    """Yield the scope's one selected original as a single blob page."""
    scope = _scope(scope)
    capture = scope["capture"]
    yield SourceNativeBlobPage(
        0,
        0,
        _key(0),
        capture["responseSha256"],
        capture["byteSize"],
        blob_source,
        "application/octet-stream",
    )


def _records(stream, scope):
    capture = scope["capture"]
    raw = stream.read(scope["max_decoded_bytes"] + 1)
    if len(raw) != capture["byteSize"] or "sha256:" + hashlib.sha256(raw).hexdigest() != capture["responseSha256"]:
        raise ValueError("FEC agency report bytes differ from the selected capture")
    if scope["format"] == "foia-xml":
        parsed = parse_foia_annual_report(raw, max_bytes=scope["max_decoded_bytes"])
        yield {"kind": "foia-report", "report": {"source": parsed["source"], "metadata": parsed["metadata"]}}
        for ordinal, element in enumerate(parsed["elements"]):
            yield {"kind": "foia-element", "ordinal_in_report": ordinal, "element": element}
    else:
        parsed = parse_oversight_report(raw, url=capture["requestUrl"], max_bytes=scope["max_decoded_bytes"])
        yield {"kind": "oversight-report", "report": {"source": parsed["source"], "metadata": parsed["metadata"]}}
        for ordinal, field in enumerate(parsed["metadata"]["fields"]):
            yield {"kind": "oversight-field", "ordinal_in_report": ordinal, "field": field}
        for ordinal, body in enumerate(parsed["bodies"]):
            yield {"kind": "oversight-body", "ordinal_in_report": ordinal, "body": body}
        for ordinal, asset in enumerate(parsed["assets"]):
            yield {"kind": "oversight-asset", "ordinal_in_report": ordinal, "asset": asset}


def _page(index, rows, *, terminal):
    return {"requestKey": _key(index), "page": index, "results": rows, "terminal": terminal}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = query_scope
    capture = scope["capture"]
    expected_media = "application/octet-stream"
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["responseSha256"],
        capture["byteSize"],
        expected_media,
    ):
        raise ValueError("FEC agency original differs from its selected capture")
    records = _records(stream, scope)
    page, rows, size = 0, [], 0
    for ordinal, parsed in enumerate(records):
        row = {
            "id": f"{evidence_ref}/{ordinal:020d}",
            "ordinal": ordinal,
            "format": scope["format"],
            "record": parsed,
        }
        row_size = len(canonical_json_bytes(row))
        overhead = len(canonical_json_bytes(_page(page, [], terminal=False)))
        if overhead + row_size > MAX_PAGE_BYTES or row_size > scope["max_record_bytes"]:
            raise ValueError("FEC agency parsed record exceeds its page byte bound")
        if rows and (
            len(rows) == scope["max_records_per_page"] or overhead + size + row_size + len(rows) > MAX_PAGE_BYTES
        ):
            yield _page(page, rows, terminal=False)
            page, rows, size = page + 1, [], 0
            if len(canonical_json_bytes(_page(page, [], terminal=False))) + row_size > MAX_PAGE_BYTES:
                raise ValueError("FEC agency parsed record exceeds its page byte bound")
        rows.append(row)
        size += row_size
    if not rows:
        raise ValueError("FEC agency report produced no records")
    yield _page(page, rows, terminal=True)


@dataclass
class _Traversal:
    pages: int = 0
    terminal: bool = False

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise ValueError("FEC agency page sequence differs")
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if not self.pages or not self.terminal:
            raise ValueError("FEC agency stream did not finish")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise ValueError("FEC agency acquisition requires one original window")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise ValueError("FEC agency original is missing")


def _window(key):
    if not isinstance(key, str) or re.fullmatch(r"fec-agency://page/(0|[1-9][0-9]*)", key) is None:
        raise ValueError("FEC agency page key is invalid")
    return 0


def _validate_record(record, *, query_scope, page_window):
    digest = query_scope["capture"]["responseSha256"]
    if record["format"] != query_scope["format"] or record["id"] != f"{digest}/{record['ordinal']:020d}":
        raise ValueError("FEC agency record coordinates differ from the selected original")


_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["id", "ordinal", "format", "record"],
    "properties": {
        "id": {"type": "string"},
        "ordinal": {"type": "integer", "minimum": 0},
        "format": {"type": "string", "enum": ["foia-xml", "oversight-html"]},
        "record": {"type": "object"},
    },
    "x-spicy-record-order": [
        {"fieldPath": "/id", "nullOrder": "forbidden", "tupleComparison": "utf16-code-unit", "valueType": "string"}
    ],
}


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


FEC_AGENCY_REPORT_PROFILE = SourceNativeProfile(
    name="Retained FEC agency reports",
    source_system_id="urn:spicy-docs:source:fec-agency-reports",
    source_system_version="1",
    acquisition_policy_id="urn:spicy-docs:acquisition:fec-agency-reports",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="fec-agency-record",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "One selected retained original; no complete agency-report population or archive-wide coverage.",
            "FOIA annual reports keep every XML element, association and namespace declaration literally.",
            "Oversight pages keep every field, body, recommendation section and declared asset with source positions.",
            "No field is interpreted, aggregated or linked; linked document originals are never fetched.",
            "Word Flat OPC remains an acquired document with an explicit native-parser refusal.",
        ],
    },
    validate_query_scope=_scope,
    parse_page_response=lambda raw: {},
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_FILE_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=lambda row: dict(row),
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": row["id"],
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_validate_record,
    records_included=lambda response, **kwargs: True,
    acquisition_check=_Acquisition,
    page_window=_window,
)

__all__ = ["FEC_AGENCY_REPORT_PROFILE", "agency_report_scope", "iter_retained_agency_originals"]
