"""Shared remote publication planning, guarded CAS execution, and readback verification.

One product-agnostic publication layer for any DDK catalog and DocSpec managed job:
- pins accepted whole-job Parquet outputs into declared logical table partitions;
- bundles frozen catalog artifacts (catalog.ddk.json, catalog.lock.json,
  catalog.report.json, and companion SQL/schema artifacts);
- delegates immutable remote object upload, guarded CAS pointer swap, cold
  reconciliation, guarded restore, orphan cleanup protection, and native
  readback verification to `docspec remote-publication`;
- never stores cloud credentials in configs, requests, or retained receipts.
"""

import base64
from collections.abc import Callable, Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import UTC, datetime, timezone
from hashlib import md5, sha256
import io
import ipaddress
import json
from pathlib import Path, PurePosixPath
import re
import tempfile
from tempfile import TemporaryDirectory
from types import MappingProxyType
from typing import Any
from urllib.parse import urljoin, urlsplit
import urllib.error
import urllib.request
from uuid import NAMESPACE_URL, uuid5

from blake3 import blake3

from .adapters.docspec_publication import (
    validate_remote_destination_config,
    validate_remote_publication_receipt,
)
from .catalog_access import DEFAULT_HTTP_USER_AGENT, CatalogError
from .catalog_delivery import CatalogArtifacts, FrozenCatalogRelease, export_frozen_catalog_release
from .catalog_managed_jobs import managed_job_publication_inputs
from .documents import json_dumps, parse_json, read_json
from .locks import verify_remote_release_lock_pin


POINTER_SCHEMA_VERSION = "ddk-remote-pointer-v1"
PARQUET_CONTENT_TYPE = "application/vnd.apache.parquet"
JSON_CONTENT_TYPE = "application/json"
DEFAULT_POINTER_CACHE_CONTROL = "no-store"
_SAFE_PART = re.compile(r"^[A-Za-z0-9._=-]{1,128}$")
_SAFE_KEY_PART = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HEX32 = re.compile(r"^[0-9a-f]{32}$")
_ALIAS_SAFE = re.compile(r"^[a-z][a-z0-9-]*$")


def _need(condition, message):
    if not condition:
        raise CatalogError("CATALOG-PUBLICATION", message)


def _canonical_json_bytes(value):
    return json_dumps(value, sort_keys=True).encode("utf-8")


def _validate_external_http_url(
    url: str,
    *,
    allow_insecure_http: bool = False,
    allow_query: bool = False,
) -> str:
    _need(isinstance(url, str) and bool(url.strip()), "External URL must be a nonempty string")
    cleaned = url.strip()
    parsed = urlsplit(cleaned)
    _need(parsed.scheme in {"http", "https"} and bool(parsed.hostname),
          f"External URL must use http:// or https:// with a valid host: {url!r}")
    _need(not parsed.username and not parsed.password,
          f"External URL must not embed credentials: {url!r}")
    if parsed.fragment:
        raise CatalogError("CATALOG-REMOTE-URL", f"External URL must not include a fragment: {url!r}")
    if not allow_query and parsed.query:
        raise CatalogError("CATALOG-REMOTE-URL", f"External URL must not include a query string: {url!r}")
    host = parsed.hostname.lower()
    is_loopback = host in {"localhost", "127.0.0.1", "::1"}
    if not is_loopback:
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            ip = None
        if ip is not None:
            if ip.is_loopback:
                is_loopback = True
            elif ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_private or ip.is_reserved:
                raise CatalogError("CATALOG-REMOTE-URL", f"External URL host address is not permitted: {url!r}")
    if is_loopback and not allow_insecure_http:
        raise CatalogError(
            "CATALOG-REMOTE-URL",
            f"Loopback external URL requires allow_insecure_http=True: {url!r}",
        )
    if parsed.scheme == "http" and not allow_insecure_http:
        raise CatalogError(
            "CATALOG-REMOTE-URL",
            f"Plain http:// external URL requires allow_insecure_http=True: {url!r}",
        )
    return cleaned


class _NoRedirectHttpHandler(urllib.request.HTTPRedirectHandler):
    """Refuse HTTP redirects during remote verification and anonymous readback."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise CatalogError("CATALOG-REMOTE-REDIRECT", f"HTTP redirects are refused during verification (HTTP {code})")


def _no_redirect_http_get(
    url: str,
    *,
    allow_insecure_http: bool = False,
    timeout: float = 15.0,
    user_agent: str | None = None,
) -> tuple[bytes, str | None]:
    clean_url = _validate_external_http_url(url, allow_insecure_http=allow_insecure_http, allow_query=True)
    opener = urllib.request.build_opener(_NoRedirectHttpHandler())
    ua = (user_agent or "").strip() or DEFAULT_HTTP_USER_AGENT
    req = urllib.request.Request(clean_url, headers={"User-Agent": ua}, method="GET")
    try:
        with opener.open(req, timeout=timeout) as resp:
            return resp.read(), resp.headers.get("ETag")
    except CatalogError:
        raise
    except urllib.error.HTTPError as exc:
        if exc.code in (301, 302, 303, 307, 308):
            raise CatalogError("CATALOG-REMOTE-REDIRECT", f"HTTP redirect refused for {clean_url}") from exc
        raise CatalogError("CATALOG-REMOTE-IO", f"Anonymous HTTP GET {clean_url} failed with HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise CatalogError("CATALOG-REMOTE-IO", f"Anonymous HTTP GET {clean_url} failed: {exc.reason}") from exc


def _safe_rel_path(path_str, *, allow_equals=True):
    _need(isinstance(path_str, str) and bool(path_str), "Remote relative path must be a nonempty string")
    rel = PurePosixPath(path_str)
    pattern = _SAFE_PART if allow_equals else _SAFE_KEY_PART
    _need(
        rel.as_posix() == path_str
        and not rel.is_absolute()
        and not any(part in {"", ".", ".."} or not pattern.fullmatch(part) for part in rel.parts)
        and "\\" not in path_str,
        f"Unsafe remote publication relative path: {path_str!r}",
    )
    return path_str


def default_partition_remote_rel_key(table_name, partition_keys, partition_values, *, filename="part.parquet"):
    """Build deterministic Hive-style remote member path under tables/<table_name>/."""
    _need(_SAFE_KEY_PART.fullmatch(table_name or ""), f"Invalid logical table name: {table_name!r}")
    _need(_SAFE_KEY_PART.fullmatch(filename or ""), f"Invalid member filename: {filename!r}")
    segments = ["tables", table_name]
    for key in partition_keys:
        _need(_SAFE_KEY_PART.fullmatch(key or ""), f"Invalid partition key: {key!r}")
        value = partition_values[key]
        _need(isinstance(value, str) and _SAFE_KEY_PART.fullmatch(value),
              f"Invalid partition value for {key!r}: {value!r}")
        segments.append(f"{key}={value}")
    segments.append(filename)
    return "/".join(segments)


@dataclass(frozen=True)
class RemoteDestination:
    """Remote S3-compatible prefix and env-var credential bindings."""

    owned_prefix: str
    properties: Mapping[str, str] = field(default_factory=dict)
    secret_env: Mapping[str, str] = field(default_factory=dict)
    release_prefix: str = "releases"
    pointer_key: str = "current.json"

    def __post_init__(self):
        validated = validate_remote_destination_config({
            "owned_prefix": self.owned_prefix,
            "properties": dict(self.properties),
            "secret_env": dict(self.secret_env),
            "release_prefix": self.release_prefix,
            "pointer_key": self.pointer_key,
        })
        object.__setattr__(self, "properties", MappingProxyType(validated["properties"]))
        object.__setattr__(self, "secret_env", MappingProxyType(validated["secret_env"]))
        _safe_rel_path(self.release_prefix, allow_equals=False)
        _safe_rel_path(self.pointer_key, allow_equals=False)

    def to_payload(self):
        return {
            "owned_prefix": self.owned_prefix,
            "properties": dict(self.properties),
            "secret_env": dict(self.secret_env),
            "release_prefix": self.release_prefix,
            "pointer_key": self.pointer_key,
        }


def cloudflare_r2_destination(
    account_id: str,
    bucket: str,
    prefix: str,
    *,
    access_key_env: str = "R2_ACCESS_KEY_ID",
    secret_key_env: str = "R2_SECRET_ACCESS_KEY",
    public_base_url: str | None = None,
    release_prefix: str = "releases",
    pointer_key: str = "current.json",
) -> RemoteDestination:
    """Construct a default Cloudflare R2 ``RemoteDestination`` without inline secrets."""
    acct = (account_id or "").strip()
    bkt = (bucket or "").strip().strip("/")
    pfx = (prefix or "").strip().strip("/")
    _need(bool(acct) and "/" not in acct, "Cloudflare R2 destination requires a valid account_id")
    _need(bool(bkt) and "/" not in bkt, "Cloudflare R2 destination requires a valid bucket")
    _need(bool(pfx), "Cloudflare R2 destination requires a nonempty prefix")
    props: dict[str, str] = {
        "endpoint": f"https://{acct}.r2.cloudflarestorage.com",
        "region": "auto",
        "provider": "cloudflare-r2",
    }
    if public_base_url:
        props["public_base_url"] = public_base_url.rstrip("/")
    return RemoteDestination(
        owned_prefix=f"s3://{bkt}/{pfx}",
        properties=props,
        secret_env={
            "access_key_id": access_key_env,
            "secret_access_key": secret_key_env,
        },
        release_prefix=release_prefix,
        pointer_key=pointer_key,
    )


@dataclass(frozen=True)
class ExpectedPointer:
    """Optimistic concurrency precondition on the live CAS pointer."""

    kind: str
    etag: str | None = None
    sha256: str | None = None
    size: int | None = None

    @classmethod
    def absent(cls):
        return cls(kind="absent")

    @classmethod
    def present(cls, etag, sha256_hex, size):
        _need(isinstance(etag, str) and bool(etag), "Expected CAS pointer requires nonempty etag")
        _need(isinstance(sha256_hex, str) and bool(_HEX64.fullmatch(sha256_hex)),
              "Expected CAS pointer requires 64-hex sha256")
        _need(type(size) is int and size > 0, "Expected CAS pointer requires positive integer size")
        return cls(kind="present", etag=etag, sha256=sha256_hex, size=size)

    def to_payload(self):
        if self.kind == "absent":
            return {"kind": "absent"}
        if self.kind == "present":
            return {
                "kind": "present",
                "etag": self.etag,
                "sha256": self.sha256,
                "size": self.size,
            }
        raise CatalogError("CATALOG-PUBLICATION", f"Unsupported ExpectedPointer kind: {self.kind!r}")


@dataclass(frozen=True)
class IcebergTableSnapshotSpec:
    """Immutable Apache Iceberg v2 table snapshot pin for DDK locks and remote pointer releases."""

    metadata_location: str
    metadata_sha256: str
    snapshot_id: int
    schema_id: int
    manifest_list: str
    table_name: str | None = None
    table_uuid: str | None = None
    metadata_bytes: bytes | None = None
    remote_rel_key: str | None = None

    def __post_init__(self):
        _need(isinstance(self.metadata_location, str) and bool(self.metadata_location.strip()),
              "Iceberg snapshot requires nonempty metadata_location")
        _need(isinstance(self.metadata_sha256, str) and bool(_HEX64.fullmatch(self.metadata_sha256)),
              "Iceberg snapshot requires 64-character lowercase hex metadata_sha256")
        _need(type(self.snapshot_id) is int, "Iceberg snapshot requires integer snapshot_id")
        _need(type(self.schema_id) is int and self.schema_id >= 0,
              "Iceberg snapshot requires non-negative integer schema_id")
        _need(isinstance(self.manifest_list, str) and bool(self.manifest_list.strip()),
              "Iceberg snapshot requires nonempty manifest_list")
        if self.table_name is not None:
            _need(_SAFE_KEY_PART.fullmatch(self.table_name),
                  f"Invalid Iceberg logical table_name: {self.table_name!r}")
        if self.table_uuid is not None:
            _need(isinstance(self.table_uuid, str) and bool(self.table_uuid.strip()),
                  "Iceberg table_uuid must be a nonempty string when provided")
        if self.remote_rel_key is not None:
            _safe_rel_path(self.remote_rel_key, allow_equals=False)
        if self.metadata_bytes is not None:
            raw = bytes(self.metadata_bytes)
            _need(sha256(raw).hexdigest() == self.metadata_sha256,
                  "Supplied Iceberg metadata_bytes SHA-256 differs from metadata_sha256")
            object.__setattr__(self, "metadata_bytes", raw)

    @classmethod
    def from_metadata(cls, metadata_json_bytes_or_path, *, metadata_location=None,
                      table_name=None, remote_rel_key=None, include_bytes=False):
        raw = _read_iceberg_metadata_bytes(metadata_json_bytes_or_path)
        inspected = inspect_iceberg_table_metadata(raw)
        loc = metadata_location or inspected.get("location")
        if not loc and isinstance(metadata_json_bytes_or_path, (str, Path)):
            p = Path(metadata_json_bytes_or_path)
            if p.is_file():
                loc = p.resolve().as_uri()
        _need(isinstance(loc, str) and bool(loc),
              "Supply metadata_location or Iceberg metadata containing a table location")
        _need(inspected["current_snapshot_id"] is not None and inspected["manifest_list"] is not None,
              "Iceberg metadata has no active current snapshot or manifest-list")
        return cls(
            metadata_location=loc,
            metadata_sha256=inspected["metadata_sha256"],
            snapshot_id=inspected["current_snapshot_id"],
            schema_id=inspected["current_schema_id"],
            manifest_list=inspected["manifest_list"],
            table_name=table_name,
            table_uuid=inspected["table_uuid"],
            metadata_bytes=raw if include_bytes else None,
            remote_rel_key=remote_rel_key,
        )

    def to_catalog_dict(self):
        return {
            **({"tableUuid": self.table_uuid} if self.table_uuid else {}),
            "metadataLocation": self.metadata_location,
            "metadataSha256": self.metadata_sha256,
            "snapshotId": self.snapshot_id,
            "schemaId": self.schema_id,
            "manifestList": self.manifest_list,
        }

    def to_lock_dict(self, *, remote_key=None):
        return {
            **({"tableName": self.table_name} if self.table_name else {}),
            **({"tableUuid": self.table_uuid} if self.table_uuid else {}),
            "metadataLocation": self.metadata_location,
            "metadataSha256": self.metadata_sha256,
            "snapshotId": self.snapshot_id,
            "schemaId": self.schema_id,
            "manifestList": self.manifest_list,
            **({"remoteKey": remote_key} if remote_key else {}),
        }

    def to_manifest_dict(self, *, remote_key=None):
        return {
            **({"table_name": self.table_name} if self.table_name else {}),
            **({"table_uuid": self.table_uuid} if self.table_uuid else {}),
            "metadata_location": self.metadata_location,
            "metadata_sha256": self.metadata_sha256,
            "snapshot_id": self.snapshot_id,
            "schema_id": self.schema_id,
            "manifest_list": self.manifest_list,
            **({"remote_key": remote_key} if remote_key else {}),
        }


def _read_iceberg_metadata_bytes(metadata_json_bytes_or_path) -> bytes:
    if isinstance(metadata_json_bytes_or_path, (bytes, bytearray, memoryview)):
        return bytes(metadata_json_bytes_or_path)
    if isinstance(metadata_json_bytes_or_path, Path):
        return metadata_json_bytes_or_path.read_bytes()
    if isinstance(metadata_json_bytes_or_path, str):
        stripped = metadata_json_bytes_or_path.lstrip()
        if stripped.startswith("{"):
            return metadata_json_bytes_or_path.encode("utf-8")
        return Path(metadata_json_bytes_or_path).read_bytes()
    raise CatalogError("CATALOG-PUBLICATION", "Iceberg metadata must be bytes, JSON text, or a file Path")


def inspect_iceberg_table_metadata(metadata_json_bytes_or_path) -> dict:
    """Parse standard Apache Iceberg v2 ``metadata.json`` and extract snapshot & schema pins."""
    raw = _read_iceberg_metadata_bytes(metadata_json_bytes_or_path)
    doc = parse_json(raw)
    _need(isinstance(doc, dict), "Iceberg table metadata must be a JSON object")
    fmt_version = doc.get("format-version")
    _need(type(fmt_version) is int and fmt_version >= 2,
          f"Expected Apache Iceberg format-version >= 2, got {fmt_version!r}")
    table_uuid = doc.get("table-uuid")
    _need(isinstance(table_uuid, str) and bool(table_uuid.strip()),
          "Iceberg v2 metadata requires a nonempty string 'table-uuid'")

    current_schema_id = doc.get("current-schema-id")
    _need(type(current_schema_id) is int and current_schema_id >= 0,
          "Iceberg v2 metadata requires non-negative integer 'current-schema-id'")

    schemas = doc.get("schemas")
    _need(isinstance(schemas, list) and bool(schemas),
          "Iceberg v2 metadata requires a nonempty 'schemas' array")
    matched_schemas = [
        s for s in schemas
        if isinstance(s, dict) and s.get("schema-id") == current_schema_id
    ]
    _need(len(matched_schemas) == 1,
          f"Iceberg v2 metadata must contain exactly one schema matching current-schema-id {current_schema_id}")
    active_schema = matched_schemas[0]
    raw_fields = active_schema.get("fields")
    _need(isinstance(raw_fields, list), "Iceberg schema requires a 'fields' list")
    schema_fields = []
    for f in raw_fields:
        _need(isinstance(f, dict) and type(f.get("id")) is int and isinstance(f.get("name"), str) and "type" in f,
              "Invalid field entry in Iceberg schema")
        schema_fields.append({
            "id": f["id"],
            "name": f["name"],
            "required": bool(f.get("required", False)),
            "type": deepcopy(f["type"]),
            **({"doc": f["doc"]} if isinstance(f.get("doc"), str) else {}),
        })

    current_snapshot_id = doc.get("current-snapshot-id")
    manifest_list = None
    if current_snapshot_id is not None and current_snapshot_id != -1:
        _need(type(current_snapshot_id) is int,
              "Iceberg 'current-snapshot-id' must be an integer")
        snapshots = doc.get("snapshots") or ()
        matched_snaps = [
            s for s in snapshots
            if isinstance(s, dict) and s.get("snapshot-id") == current_snapshot_id
        ]
        _need(len(matched_snaps) == 1,
              f"Iceberg metadata missing snapshot entry for current-snapshot-id {current_snapshot_id}")
        snap = matched_snaps[0]
        manifest_list = snap.get("manifest-list")
        _need(isinstance(manifest_list, str) and bool(manifest_list.strip()),
              "Active Iceberg v2 snapshot requires a nonempty 'manifest-list'")
    else:
        current_snapshot_id = None

    meta_sha = sha256(raw).hexdigest()
    meta_b3 = blake3(raw).hexdigest()
    return {
        "format_version": fmt_version,
        "format-version": fmt_version,
        "table_uuid": table_uuid,
        "table-uuid": table_uuid,
        "location": doc.get("location"),
        "current_snapshot_id": current_snapshot_id,
        "current-snapshot-id": current_snapshot_id,
        "current_schema_id": current_schema_id,
        "current-schema-id": current_schema_id,
        "manifest_list": manifest_list,
        "manifest-list": manifest_list,
        "fields": schema_fields,
        "metadata_sha256": meta_sha,
        "metadata_blake3": meta_b3,
        "size": len(raw),
    }


def bind_iceberg_snapshots_to_lock(lock_doc_or_bytes, snapshots):
    """Bind one or more ``IcebergTableSnapshotSpec`` pins into ``catalog.lock.json``."""
    from .documents import validate_document

    as_bytes = isinstance(lock_doc_or_bytes, (bytes, bytearray, memoryview))
    doc = deepcopy(parse_json(bytes(lock_doc_or_bytes)) if as_bytes else lock_doc_or_bytes)
    _need(isinstance(doc, dict) and doc.get("kind") == "lock", "Expected a DDK catalog.lock.json document")
    entries = []
    seen_locs = set()
    for snap in snapshots:
        spec = snap if isinstance(snap, IcebergTableSnapshotSpec) else IcebergTableSnapshotSpec(**snap)
        _need(spec.metadata_location not in seen_locs,
              f"Duplicate Iceberg metadata_location in lock: {spec.metadata_location!r}")
        seen_locs.add(spec.metadata_location)
        entries.append(spec.to_lock_dict())
    doc["icebergSnapshots"] = sorted(entries, key=lambda x: (x.get("tableName", ""), x["metadataLocation"]))
    issues = validate_document(doc, "lock")
    _need(not issues, f"Updated lock failed schema validation: {issues[0].message if issues else ''}")
    return (_canonical_json_bytes(doc) + b"\n") if as_bytes else doc


@dataclass(frozen=True)
class LogicalTableMemberSpec:
    """Mapping from one sealed whole-job or external Parquet output to one logical-table partition."""

    output_name: str
    partition_values: Mapping[str, str] = field(default_factory=dict)
    remote_rel_key: str | None = None
    content_type: str = PARQUET_CONTENT_TYPE
    external_url: str | None = None
    preserve_remote_key: bool = False
    footer_sha256: str | None = None
    allow_insecure_http: bool = False

    def __post_init__(self):
        _need(isinstance(self.output_name, str) and bool(self.output_name),
              "Logical table member requires nonempty output_name")
        _need(isinstance(self.partition_values, Mapping)
              and all(isinstance(k, str) and isinstance(v, str) for k, v in self.partition_values.items()),
              "Partition values must map string partition names to string values")
        object.__setattr__(self, "partition_values", MappingProxyType(dict(self.partition_values)))
        if self.remote_rel_key is not None:
            _safe_rel_path(self.remote_rel_key, allow_equals=True)
        if self.preserve_remote_key:
            _need(self.remote_rel_key is not None,
                  "preserve_remote_key=True requires an explicit remote_rel_key")
        if self.external_url is not None:
            object.__setattr__(
                self,
                "external_url",
                _validate_external_http_url(self.external_url, allow_insecure_http=self.allow_insecure_http),
            )
        if self.footer_sha256 is not None:
            _need(isinstance(self.footer_sha256, str) and bool(_HEX64.fullmatch(self.footer_sha256)),
                  "Logical table member footer_sha256 must be 64-character lowercase hex")


@dataclass(frozen=True)
class LogicalTableSpec:
    """Logical dataset table grouping one or more whole-job Parquet partitions/members and/or an Iceberg snapshot."""

    table_name: str
    partition_keys: tuple[str, ...] = ()
    members: tuple[LogicalTableMemberSpec, ...] = ()
    iceberg_snapshot: IcebergTableSnapshotSpec | None = None

    def __post_init__(self):
        _need(_SAFE_KEY_PART.fullmatch(self.table_name or ""),
              f"Invalid logical table name: {self.table_name!r}")
        keys = tuple(self.partition_keys)
        _need(len(keys) == len(set(keys)) and all(_SAFE_KEY_PART.fullmatch(k or "") for k in keys),
              f"Invalid or duplicate partition keys for table {self.table_name!r}")
        members = tuple(self.members)
        if self.iceberg_snapshot is not None:
            _need(isinstance(self.iceberg_snapshot, IcebergTableSnapshotSpec),
                  f"iceberg_snapshot on {self.table_name!r} must be an IcebergTableSnapshotSpec")
        _need(bool(members) or self.iceberg_snapshot is not None,
              f"Logical table {self.table_name!r} requires at least one member or iceberg_snapshot")
        object.__setattr__(self, "partition_keys", keys)
        object.__setattr__(self, "members", members)


@dataclass(frozen=True)
class RemotePublicationPlan:
    """Self-contained immutable remote publication request and CAS pointer payload."""

    release_id: str
    publish_command: Mapping
    pointer_bytes: bytes
    pointer_sha256: str
    pointer_size: int
    manifest_bytes: bytes
    manifest_sha256: str
    manifest_blake3: str
    remote_keys: tuple[str, ...]
    external_member_keys: tuple[str, ...] = ()


def _normalize_catalog_release(catalog_release):
    if isinstance(catalog_release, FrozenCatalogRelease):
        return catalog_release
    if isinstance(catalog_release, (CatalogArtifacts, str, Path)):
        return export_frozen_catalog_release(catalog_release)
    raise CatalogError("CATALOG-PUBLICATION", "Unsupported catalog_release type for remote publication")


def _compute_release_id(job_inputs, release, logical_tables_payload, private_outputs, iceberg_snapshots_payload=()):
    seed = {
        "dataset": job_inputs["dataset"],
        "candidate_manifest_digest": job_inputs["candidate"]["manifest"]["digest"],
        "policy_id": job_inputs["policy_id"],
        "lock_sha256": release.lock_sha256,
        "catalog_sha256": release.catalog_sha256,
        "logical_tables": logical_tables_payload,
        "private_outputs": sorted(private_outputs),
        **({"iceberg_snapshots": iceberg_snapshots_payload} if iceberg_snapshots_payload else {}),
    }
    return sha256(_canonical_json_bytes(seed)).hexdigest()


def _stage_artifact_entry(artifact, remote_key, staging_dir):
    entry = {
        "name": artifact["name"],
        "remote_key": remote_key,
        "content_type": artifact["content_type"],
        "size": artifact["size"],
        "sha256": artifact["sha256"],
        "blake3": artifact["blake3"],
    }
    raw = artifact["bytes"]
    if staging_dir is not None:
        staging_root = Path(staging_dir).resolve()
        staging_root.mkdir(parents=True, exist_ok=True)
        staged = staging_root / f"{artifact['sha256']}-{PurePosixPath(artifact['name']).name}"
        if not staged.exists():
            staged.write_bytes(raw)
        entry["path"] = str(staged)
    else:
        entry["bytes_base64"] = base64.b64encode(raw).decode("ascii")
    return entry


def _resolve_plan_member_schema_source(
    output_name: str,
    out: Mapping[str, Any],
    member_paths: Mapping[str, Path | str] | None,
    evidence_schemas: Mapping[str, str],
) -> Any:
    if member_paths is not None and output_name in member_paths:
        return member_paths[output_name]
    raw_path = out.get("path")
    if isinstance(raw_path, (str, Path)) and Path(raw_path).is_file():
        return Path(raw_path)
    comp = out.get("completion")
    if isinstance(comp, Mapping):
        comp_path = comp.get("path") or comp.get("locator")
        if isinstance(comp_path, (str, Path)) and Path(comp_path).is_file():
            return Path(comp_path)
    schema_sha = out.get("schema_sha256")
    if isinstance(schema_sha, str) and schema_sha in evidence_schemas:
        return base64.b64decode(evidence_schemas[schema_sha])
    ipc_b64 = out.get("schema_ipc_base64")
    if isinstance(ipc_b64, str) and ipc_b64:
        return base64.b64decode(ipc_b64)
    raise _schema_error(
        f"Cannot resolve Parquet file or Arrow schema IPC for output {output_name!r}; "
        "supply member_paths or completed job schema evidence"
    )


def build_remote_publication_plan(
    *,
    job_inputs,
    catalog_release,
    logical_tables,
    destination,
    operation,
    expected_pointer,
    iceberg_snapshots=(),
    private_outputs=(),
    expected_epoch=None,
    expected_selection_revision=None,
    artifact_staging_dir=None,
    release_id=None,
    compact_pointer=True,
    pointer_cache_control=DEFAULT_POINTER_CACHE_CONTROL,
    authority=None,
    witness_reader=None,
    declared_schemas: Mapping[str, Any] | None = None,
    member_paths: Mapping[str, Path | str] | None = None,
    schema_check_order: bool = True,
    schema_check_nullability: bool = False,
):
    """Assemble and validate one deterministic `docspec remote-publication` publish plan."""
    if not (isinstance(job_inputs, Mapping) and "completed_outputs" in job_inputs
            and "accepted_qualification" in job_inputs and "candidate" in job_inputs):
        job_inputs = managed_job_publication_inputs(
            job_inputs,
            authority=authority,
            witness_reader=witness_reader,
            expected_epoch=expected_epoch,
            expected_selection_revision=expected_selection_revision,
        )
    epoch = job_inputs["expected_epoch"] if expected_epoch is None else expected_epoch
    selection_rev = (
        job_inputs["expected_selection_revision"]
        if expected_selection_revision is None
        else expected_selection_revision
    )
    _need(type(epoch) is int and epoch >= 0, "Remote publication requires integer expected_epoch")
    _need(type(selection_rev) is int and selection_rev >= 0,
          "Remote publication requires integer expected_selection_revision")
    _need(isinstance(operation, str) and bool(operation), "Remote publication requires nonempty operation id")
    _need(isinstance(destination, RemoteDestination), "destination must be a RemoteDestination")
    _need(isinstance(expected_pointer, ExpectedPointer), "expected_pointer must be an ExpectedPointer")

    frozen_catalog = _normalize_catalog_release(catalog_release)
    completed_outputs = job_inputs["completed_outputs"]
    private_set = set(private_outputs)
    _need(private_set <= set(completed_outputs),
          "Declared private_outputs must refer to completed job outputs")

    seen_tables = set()
    seen_outputs = set()
    rel_member_specs = []
    for table in logical_tables:
        _need(isinstance(table, LogicalTableSpec), "logical_tables entries must be LogicalTableSpec")
        _need(table.table_name not in seen_tables, f"Duplicate logical table {table.table_name!r}")
        seen_tables.add(table.table_name)
        seen_partitions = set()
        expected_pkeys = set(table.partition_keys)
        table_members = []
        for member in table.members:
            _need(member.output_name not in private_set,
                  f"Private output {member.output_name!r} cannot appear in published logical table")
            _need(member.output_name in completed_outputs,
                  f"Logical table member {member.output_name!r} missing from completed whole-job outputs")
            _need(member.output_name not in seen_outputs,
                  f"Duplicate logical table mapping for output {member.output_name!r}")
            seen_outputs.add(member.output_name)
            _need(set(member.partition_values) == expected_pkeys,
                  f"Partition keys mismatch for {table.table_name!r}/{member.output_name!r}")
            pkey = tuple(sorted(member.partition_values.items()))
            _need(pkey not in seen_partitions,
                  f"Duplicate partition values {dict(member.partition_values)!r} in {table.table_name!r}")
            seen_partitions.add(pkey)
            rel_key = member.remote_rel_key or default_partition_remote_rel_key(
                table.table_name, table.partition_keys, member.partition_values,
            )
            _safe_rel_path(rel_key, allow_equals=True)
            out = completed_outputs[member.output_name]
            table_members.append((member, out, rel_key))
        rel_member_specs.append((table, table_members))

    missing_outputs = sorted(set(completed_outputs) - seen_outputs - private_set)
    _need(not missing_outputs,
          f"Non-private whole-job outputs missing from logical_tables: {missing_outputs!r}")

    if declared_schemas is not None:
        evidence = job_inputs.get("evidence")
        evidence_manifest = getattr(evidence, "manifest", None)
        evidence_schemas = (
            evidence_manifest.get("schemas", {}) if isinstance(evidence_manifest, Mapping) else {}
        )
        schema_candidates: dict[str, list[Any]] = {}
        has_iceberg_only = False
        for table, table_members in rel_member_specs:
            if not table_members:
                has_iceberg_only = True
                continue
            schema_candidates[table.table_name] = [
                _resolve_plan_member_schema_source(member.output_name, out, member_paths, evidence_schemas)
                for member, out, _rel_key in table_members
            ]
        verify_parquet_schema_parity(
            declared_schemas,
            schema_candidates,
            check_order=schema_check_order,
            check_nullability=schema_check_nullability,
            allow_subset_tables=has_iceberg_only,
        )

    collected_snapshots: list[IcebergTableSnapshotSpec] = []
    seen_snap_locs = set()
    for table, _ in rel_member_specs:
        if table.iceberg_snapshot is not None:
            snap = table.iceberg_snapshot
            if snap.table_name is None:
                snap = IcebergTableSnapshotSpec(
                    metadata_location=snap.metadata_location,
                    metadata_sha256=snap.metadata_sha256,
                    snapshot_id=snap.snapshot_id,
                    schema_id=snap.schema_id,
                    manifest_list=snap.manifest_list,
                    table_name=table.table_name,
                    table_uuid=snap.table_uuid,
                    metadata_bytes=snap.metadata_bytes,
                    remote_rel_key=snap.remote_rel_key,
                )
            _need(snap.metadata_location not in seen_snap_locs,
                  f"Duplicate Iceberg snapshot metadata_location {snap.metadata_location!r}")
            seen_snap_locs.add(snap.metadata_location)
            collected_snapshots.append(snap)
    for extra_snap in iceberg_snapshots or ():
        _need(isinstance(extra_snap, IcebergTableSnapshotSpec),
              "iceberg_snapshots entries must be IcebergTableSnapshotSpec")
        _need(extra_snap.metadata_location not in seen_snap_locs,
              f"Duplicate Iceberg snapshot metadata_location {extra_snap.metadata_location!r}")
        seen_snap_locs.add(extra_snap.metadata_location)
        collected_snapshots.append(extra_snap)

    snap_id_basis = [s.to_manifest_dict() for s in collected_snapshots]

    if release_id is None:
        id_basis = [
            {
                "table_name": table.table_name,
                "partition_keys": list(table.partition_keys),
                "members": [
                    {
                        "output_name": member.output_name,
                        "partition_values": dict(member.partition_values),
                        "rel_key": rel_key,
                        "sha256": out["sha256"],
                    }
                    for member, out, rel_key in members
                ],
                **({"iceberg_snapshot": table.iceberg_snapshot.to_manifest_dict()} if table.iceberg_snapshot else {}),
            }
            for table, members in rel_member_specs
        ]
        release_id = _compute_release_id(job_inputs, frozen_catalog, id_basis, private_set, snap_id_basis)
    else:
        _need(isinstance(release_id, str) and bool(_HEX64.fullmatch(release_id)),
              "Explicit release_id must be 64-character lowercase hex")

    prefix = f"{destination.release_prefix}/{release_id}"
    logical_tables_cmd = []
    manifest_tables = []
    all_remote_keys = []
    external_member_keys = []
    used_remote_keys = set()
    snap_remote_keys_by_loc = {}
    staged_iceberg_artifacts = []
    for idx, snap in enumerate(collected_snapshots):
        if snap.metadata_bytes is not None:
            rel_meta_key = snap.remote_rel_key or (
                f"iceberg/{snap.table_name or f'table-{idx}'}/metadata/{snap.snapshot_id}.metadata.json"
            )
            _safe_rel_path(rel_meta_key, allow_equals=False)
            remote_key = f"{prefix}/{rel_meta_key}"
            _need(remote_key not in used_remote_keys, f"Duplicate remote key {remote_key!r}")
            used_remote_keys.add(remote_key)
            all_remote_keys.append(remote_key)
            snap_remote_keys_by_loc[snap.metadata_location] = remote_key
            staged_iceberg_artifacts.append((
                {
                    "name": rel_meta_key,
                    "content_type": JSON_CONTENT_TYPE,
                    "size": len(snap.metadata_bytes),
                    "sha256": snap.metadata_sha256,
                    "blake3": blake3(snap.metadata_bytes).hexdigest(),
                    "bytes": snap.metadata_bytes,
                },
                remote_key,
            ))

    for table, members in rel_member_specs:
        cmd_members = []
        man_members = []
        for member, out, rel_key in members:
            is_external = (
                member.preserve_remote_key
                or member.external_url is not None
                or ("completion" not in out)
            )
            remote_key = rel_key if member.preserve_remote_key else f"{prefix}/{rel_key}"
            _need(remote_key not in used_remote_keys, f"Duplicate remote key {remote_key!r}")
            used_remote_keys.add(remote_key)
            all_remote_keys.append(remote_key)
            if is_external:
                external_member_keys.append(remote_key)
            obj_ref = out.get("completion")
            blake3_digest = obj_ref["digest"] if isinstance(obj_ref, Mapping) else out.get("blake3")
            if isinstance(obj_ref, Mapping) and not is_external:
                cmd_members.append({
                    "output_name": member.output_name,
                    "partition_values": dict(member.partition_values),
                    "object": deepcopy(obj_ref),
                    "remote_key": remote_key,
                    "sha256": out["sha256"],
                    "blake3": blake3_digest,
                    "md5": out["md5"],
                    "rows": out["rows"],
                    "size": out["size"],
                    "content_type": member.content_type,
                })
            else:
                cmd_members.append({
                    "output_name": member.output_name,
                    "partition_values": dict(member.partition_values),
                    "remote_key": remote_key,
                    **({"url": member.external_url} if member.external_url else {}),
                    "external": True,
                    "sha256": out["sha256"],
                    **({"blake3": blake3_digest} if blake3_digest else {}),
                    **({"md5": out["md5"]} if out.get("md5") else {}),
                    **({"footer_sha256": member.footer_sha256} if member.footer_sha256 else {}),
                    "rows": out["rows"],
                    "size": out["size"],
                    "content_type": member.content_type,
                })
            man_members.append({
                "output_name": member.output_name,
                "partition_values": dict(member.partition_values),
                "remote_key": remote_key,
                **({"url": member.external_url} if member.external_url else {}),
                **({"external": True} if is_external else {}),
                "sha256": out["sha256"],
                **({"blake3": blake3_digest} if blake3_digest else {}),
                **({"md5": out["md5"]} if out.get("md5") else {}),
                **({"footer_sha256": member.footer_sha256} if member.footer_sha256 else {}),
                "rows": out["rows"],
                "size": out["size"],
            })
        tbl_snap_dict = None
        if table.iceberg_snapshot is not None:
            rk = snap_remote_keys_by_loc.get(table.iceberg_snapshot.metadata_location)
            tbl_snap_dict = table.iceberg_snapshot.to_manifest_dict(remote_key=rk)
        if cmd_members:
            logical_tables_cmd.append({
                "table_name": table.table_name,
                "partition_keys": list(table.partition_keys),
                "members": cmd_members,
                **({"iceberg_snapshot": tbl_snap_dict} if tbl_snap_dict else {}),
            })
        manifest_tables.append({
            "table_name": table.table_name,
            "partition_keys": list(table.partition_keys),
            "members": man_members,
            **({"iceberg_snapshot": tbl_snap_dict} if tbl_snap_dict else {}),
        })

    catalog_dicts = list(staged_iceberg_artifacts)
    manifest_catalog_pins = [
        {
            "name": art_dict["name"],
            "remote_key": r_key,
            "sha256": art_dict["sha256"],
            "blake3": art_dict["blake3"],
            "size": art_dict["size"],
        }
        for art_dict, r_key in staged_iceberg_artifacts
    ]
    for art in frozen_catalog.artifacts:
        _safe_rel_path(art.name, allow_equals=False)
        remote_key = f"{prefix}/catalog/{art.name}"
        _need(remote_key not in used_remote_keys, f"Duplicate remote key {remote_key!r}")
        used_remote_keys.add(remote_key)
        all_remote_keys.append(remote_key)
        catalog_dicts.append((
            {
                "name": art.name,
                "content_type": art.content_type,
                "size": art.size,
                "sha256": art.sha256,
                "blake3": art.blake3,
                "bytes": art.bytes,
            },
            remote_key,
        ))
        manifest_catalog_pins.append({
            "name": art.name,
            "remote_key": remote_key,
            "sha256": art.sha256,
            "blake3": art.blake3,
            "size": art.size,
        })

    manifest_iceberg_snaps = [
        s.to_manifest_dict(remote_key=snap_remote_keys_by_loc.get(s.metadata_location))
        for s in collected_snapshots
    ]
    manifest_doc = {
        "schema_version": POINTER_SCHEMA_VERSION,
        "release_id": release_id,
        "dataset": job_inputs["dataset"],
        "operation": operation,
        "epoch": epoch,
        "selection_revision": selection_rev,
        "catalog_artifacts": manifest_catalog_pins,
        "logical_tables": manifest_tables,
        **({"iceberg_snapshots": manifest_iceberg_snaps} if manifest_iceberg_snaps else {}),
    }
    manifest_bytes = _canonical_json_bytes(manifest_doc)
    manifest_sha = sha256(manifest_bytes).hexdigest()
    manifest_b3 = blake3(manifest_bytes).hexdigest()
    manifest_remote_key = f"{prefix}/catalog/release.manifest.json"
    _need(manifest_remote_key not in used_remote_keys,
          "Frozen catalog artifacts cannot already contain release.manifest.json")

    if compact_pointer:
        used_remote_keys.add(manifest_remote_key)
        all_remote_keys.append(manifest_remote_key)
        catalog_dicts.append((
            {
                "name": "release.manifest.json",
                "content_type": JSON_CONTENT_TYPE,
                "size": len(manifest_bytes),
                "sha256": manifest_sha,
                "blake3": manifest_b3,
                "bytes": manifest_bytes,
            },
            manifest_remote_key,
        ))
        pointer_doc = {
            "schema_version": POINTER_SCHEMA_VERSION,
            "release_id": release_id,
            "dataset": job_inputs["dataset"],
            "operation": operation,
            "epoch": epoch,
            "selection_revision": selection_rev,
            "release_manifest": {
                "remote_key": manifest_remote_key,
                "sha256": manifest_sha,
                "blake3": manifest_b3,
                "size": len(manifest_bytes),
            },
            **({"iceberg_snapshots": manifest_iceberg_snaps} if manifest_iceberg_snaps else {}),
        }
    else:
        pointer_doc = manifest_doc

    pointer_bytes = _canonical_json_bytes(pointer_doc)
    pointer_sha = sha256(pointer_bytes).hexdigest()
    catalog_artifacts_cmd = [
        _stage_artifact_entry(art_dict, remote_key, artifact_staging_dir)
        for art_dict, remote_key in catalog_dicts
    ]

    publish_cmd = {
        "action": "publish",
        "dataset": job_inputs["dataset"],
        "operation": operation,
        "candidate": deepcopy(job_inputs["candidate"]),
        "job_request_digest": job_inputs["job_request_digest"],
        "policy_id": job_inputs["policy_id"],
        "accepted_qualification": deepcopy(job_inputs["accepted_qualification"]),
        "expected_epoch": epoch,
        "expected_selection_revision": selection_rev,
        "destination": destination.to_payload(),
        "release_id": release_id,
        "catalog_artifacts": catalog_artifacts_cmd,
        "logical_tables": logical_tables_cmd,
        "private_outputs": sorted(private_set),
        "expected_pointer": expected_pointer.to_payload(),
        "pointer": {
            "content_type": JSON_CONTENT_TYPE,
            "cache_control": pointer_cache_control,
            "bytes_base64": base64.b64encode(pointer_bytes).decode("ascii"),
        },
    }
    return RemotePublicationPlan(
        release_id=release_id,
        publish_command=publish_cmd,
        pointer_bytes=pointer_bytes,
        pointer_sha256=pointer_sha,
        pointer_size=len(pointer_bytes),
        manifest_bytes=manifest_bytes,
        manifest_sha256=manifest_sha,
        manifest_blake3=manifest_b3,
        remote_keys=tuple(all_remote_keys),
        external_member_keys=tuple(external_member_keys),
    )


class RemotePublisher:
    """Product-agnostic facade executing shared `docspec remote-publication` operations."""

    def __init__(self, adapter, workspace):
        self.adapter = adapter
        self.workspace = Path(workspace).resolve(strict=True)

    def _run(self, action, request, *, secret_env=None, cancel_event=None):
        response = self.adapter.remote_publication(
            self.workspace, request, secret_env=secret_env, cancel_event=cancel_event,
        )
        return validate_remote_publication_receipt(action, response)

    def publish(self, plan, *, secret_env=None, cancel_event=None):
        if isinstance(plan, RemotePublicationPlan):
            if plan.external_member_keys:
                raise CatalogError(
                    "CATALOG-EXTERNAL-PUBLISHER",
                    "RemotePublisher cannot publish plans referencing external Parquet objects",
                )
            cmd = plan.publish_command
        else:
            cmd = plan
        if any(
            m.get("external")
            for t in (cmd.get("logical_tables") or ())
            for m in (t.get("members") or ())
        ):
            raise CatalogError(
                "CATALOG-EXTERNAL-PUBLISHER",
                "RemotePublisher refuses commands containing external Parquet members",
            )
        return self._run("publish", cmd, secret_env=secret_env, cancel_event=cancel_event)

    def reconcile(self, dataset, operation, destination, *, secret_env=None, cancel_event=None):
        dest_payload = destination.to_payload() if isinstance(destination, RemoteDestination) else destination
        validate_remote_destination_config(dest_payload)
        return self._run(
            "reconcile",
            {"action": "reconcile", "dataset": dataset, "operation": operation, "destination": dest_payload},
            secret_env=secret_env,
            cancel_event=cancel_event,
        )

    def inspect(self, dataset, operation):
        return self._run("inspect", {"action": "inspect", "dataset": dataset, "operation": operation})

    def restore(
        self,
        *,
        dataset,
        operation,
        source_operation,
        destination,
        release_id,
        expected_epoch,
        expected_pointer,
        pointer_bytes,
        cache_control=DEFAULT_POINTER_CACHE_CONTROL,
        secret_env=None,
        cancel_event=None,
    ):
        dest_payload = destination.to_payload() if isinstance(destination, RemoteDestination) else destination
        validate_remote_destination_config(dest_payload)
        exp_payload = expected_pointer.to_payload() if isinstance(expected_pointer, ExpectedPointer) else expected_pointer
        return self._run(
            "restore",
            {
                "action": "restore",
                "dataset": dataset,
                "operation": operation,
                "source_operation": source_operation,
                "expected_epoch": expected_epoch,
                "destination": dest_payload,
                "release_id": release_id,
                "expected_pointer": exp_payload,
                "pointer": {
                    "content_type": JSON_CONTENT_TYPE,
                    "cache_control": cache_control,
                    "bytes_base64": base64.b64encode(bytes(pointer_bytes)).decode("ascii"),
                },
            },
            secret_env=secret_env,
            cancel_event=cancel_event,
        )

    def verify_readback(self, destination, *, expected_etag=None, expected_release_id=None,
                        secret_env=None, cancel_event=None):
        dest_payload = destination.to_payload() if isinstance(destination, RemoteDestination) else destination
        validate_remote_destination_config(dest_payload)
        cmd = {"action": "verify_readback", "destination": dest_payload}
        if expected_etag is not None:
            cmd["expected_etag"] = expected_etag
        if expected_release_id is not None:
            cmd["expected_release_id"] = expected_release_id
        return self._run("verify_readback", cmd, secret_env=secret_env, cancel_event=cancel_event)

    def prune_orphans(self, dataset, destination, candidate_keys, *, apply=False, refuse_protected=True,
                      secret_env=None, cancel_event=None):
        dest_payload = destination.to_payload() if isinstance(destination, RemoteDestination) else destination
        validate_remote_destination_config(dest_payload)
        return self._run(
            "prune_orphans",
            {
                "action": "prune_orphans",
                "dataset": dataset,
                "destination": dest_payload,
                "candidate_keys": list(candidate_keys),
                "apply": bool(apply),
                "refuse_protected": bool(refuse_protected),
            },
            secret_env=secret_env,
            cancel_event=cancel_event,
        )


def _norm_etag(etag):
    if etag is None:
        return None
    return etag.strip().strip('"')


def verify_http_consumer_readback(
    fetch_object,
    destination,
    *,
    expected_etag=None,
    expected_release_id=None,
    expected_lock_sha256=None,
    verify_member_bytes=True,
    staged_pointer_bytes=None,
    allow_insecure_http=False,
    declared_schemas: Mapping[str, Any] | None = None,
    schema_check_order: bool = True,
    schema_check_nullability: bool = False,
    schema_readback_mode: str = "auto",
    user_agent: str | None = None,
    timeout: float = 15.0,
):
    """Independently read and verify the live (or staged) pointer, frozen catalog, lock, and Parquet members."""
    if schema_readback_mode not in {"auto", "full", "range"}:
        raise ValueError(
            f"schema_readback_mode must be 'auto', 'full', or 'range', got {schema_readback_mode!r}"
        )
    if declared_schemas is not None and not verify_member_bytes and schema_readback_mode == "full":
        raise ValueError("verify_member_bytes=True is required when schema_readback_mode='full'")
    eff_schema_mode: str | None = None
    if declared_schemas is not None:
        if schema_readback_mode == "auto":
            eff_schema_mode = "full" if verify_member_bytes else "range"
        else:
            eff_schema_mode = schema_readback_mode
    eff_user_agent = (
        (user_agent or "").strip()
        or getattr(fetch_object, "user_agent", None)
        or DEFAULT_HTTP_USER_AGENT
    )

    pointer_key = destination.pointer_key if isinstance(destination, RemoteDestination) else destination["pointer_key"]
    pub_base = (
        (
            destination.properties.get("public_base_url")
            if isinstance(destination, RemoteDestination)
            else (destination.get("properties") or {}).get("public_base_url")
        )
        or ""
    ).rstrip("/")
    if staged_pointer_bytes is not None:
        ptr_bytes = bytes(staged_pointer_bytes)
        live_etag = None
        total_bytes_read = 0
    else:
        ptr_bytes, live_etag = fetch_object(pointer_key)
        total_bytes_read = len(ptr_bytes)
    if expected_etag is not None and _norm_etag(live_etag) != _norm_etag(expected_etag):
        raise ValueError(f"Live CAS pointer ETag {live_etag!r} differs from expected {expected_etag!r}")
    ptr_doc = parse_json(ptr_bytes)
    if not isinstance(ptr_doc, dict) or not isinstance(ptr_doc.get("release_id"), str):
        raise ValueError("Live CAS pointer missing release_id")
    live_release_id = ptr_doc["release_id"]
    if expected_release_id is not None and live_release_id != expected_release_id:
        raise ValueError(f"Live release_id {live_release_id!r} differs from expected {expected_release_id!r}")

    if "release_manifest" in ptr_doc:
        rm = ptr_doc["release_manifest"]
        man_bytes, _ = fetch_object(rm["remote_key"])
        total_bytes_read += len(man_bytes)
        if (len(man_bytes) != rm["size"]
                or sha256(man_bytes).hexdigest() != rm["sha256"]
                or blake3(man_bytes).hexdigest() != rm["blake3"]):
            raise ValueError("Downloaded release.manifest.json failed integrity verification")
        manifest_doc = parse_json(man_bytes)
        if manifest_doc.get("release_id") != live_release_id:
            raise ValueError("Downloaded release.manifest.json release_id disagrees with CAS pointer")
    else:
        manifest_doc = ptr_doc

    catalog_bytes_by_name = {}
    for entry in manifest_doc.get("catalog_artifacts", ()):
        raw, _ = fetch_object(entry["remote_key"])
        total_bytes_read += len(raw)
        if (len(raw) != entry["size"]
                or sha256(raw).hexdigest() != entry["sha256"]
                or blake3(raw).hexdigest() != entry["blake3"]):
            raise ValueError(f"Remote catalog artifact {entry['name']} failed integrity verification")
        catalog_bytes_by_name[entry["name"]] = raw

    lock_info = verify_remote_release_lock_pin(
        catalog_bytes_by_name["catalog.lock.json"],
        manifest_doc,
        expected_lock_sha256=expected_lock_sha256,
    )
    catalog_doc = parse_json(catalog_bytes_by_name["catalog.ddk.json"])
    report_doc = parse_json(catalog_bytes_by_name["catalog.report.json"])
    if report_doc.get("decision") != "passed":
        raise ValueError("Published catalog.report.json does not carry decision='passed'")

    verified_members = []
    member_bytes_by_table: dict[str, list[bytes]] = {}
    member_schemas_by_table: dict[str, list[Any]] = {}
    has_iceberg_only = False
    if verify_member_bytes:
        for table in manifest_doc.get("logical_tables", ()):
            members = table.get("members", ())
            if not members:
                has_iceberg_only = True
                continue
            tbl_bytes = member_bytes_by_table.setdefault(table["table_name"], []) if eff_schema_mode == "full" else None
            for member in members:
                m_url = member.get("url")
                if isinstance(m_url, str) and m_url:
                    _validate_external_http_url(m_url, allow_insecure_http=allow_insecure_http)
                    if pub_base and m_url.startswith(pub_base + "/"):
                        raw, _ = fetch_object(m_url[len(pub_base) + 1 :])
                    elif hasattr(fetch_object, "fetch_url"):
                        raw, _ = fetch_object.fetch_url(m_url)
                    else:
                        raw, _ = _no_redirect_http_get(
                            m_url,
                            allow_insecure_http=allow_insecure_http,
                            timeout=timeout,
                            user_agent=eff_user_agent,
                        )
                else:
                    raw, _ = fetch_object(member["remote_key"])
                total_bytes_read += len(raw)
                if (len(raw) != member["size"]
                        or sha256(raw).hexdigest() != member["sha256"]
                        or (member.get("blake3") is not None and blake3(raw).hexdigest() != member["blake3"])
                        or (member.get("md5") is not None and md5(raw).hexdigest() != member["md5"])):
                    raise ValueError(f"Remote Parquet member {member['remote_key']} failed digest verification")
                if tbl_bytes is not None:
                    tbl_bytes.append(bytes(raw))
                verified_members.append({
                    "table_name": table["table_name"],
                    "output_name": member["output_name"],
                    "partition_values": dict(member["partition_values"]),
                    "remote_key": member["remote_key"],
                    "size": len(raw),
                    "sha256": member["sha256"],
                    "rows": member["rows"],
                })

    if eff_schema_mode == "range":
        import pyarrow.parquet as pq

        from .catalog_access import _HttpRangeParquetFile
        from .catalog_query import compute_parquet_footer_sha256

        for table in manifest_doc.get("logical_tables", ()):
            members = table.get("members", ())
            if not members:
                has_iceberg_only = True
                continue
            tbl_schemas = member_schemas_by_table.setdefault(table["table_name"], [])
            for member in members:
                m_url = member.get("url")
                if isinstance(m_url, str) and m_url:
                    member_url = _validate_external_http_url(m_url, allow_insecure_http=allow_insecure_http)
                elif pub_base:
                    rel_key = member["remote_key"].lstrip("/")
                    _safe_rel_path(rel_key, allow_equals=True)
                    member_url = _validate_external_http_url(
                        f"{pub_base}/{rel_key}",
                        allow_insecure_http=allow_insecure_http,
                    )
                else:
                    raise ValueError(
                        "Range-based schema verification requires member url or destination "
                        f"public_base_url for {member['remote_key']!r}"
                    )
                reader = _HttpRangeParquetFile(
                    member_url,
                    expected_byte_size=member["size"],
                    verify_head_size=True,
                    timeout=timeout,
                    allow_insecure_http=allow_insecure_http,
                    user_agent=eff_user_agent,
                )
                footer_sha = compute_parquet_footer_sha256(reader, reader.size)
                if member.get("footer_sha256") is not None and footer_sha != member["footer_sha256"]:
                    raise CatalogError(
                        "CATALOG-REMOTE-INTEGRITY",
                        f"Remote Parquet member {member['remote_key']} footer SHA-256 {footer_sha} "
                        f"disagrees with expected {member['footer_sha256']}",
                    )
                reader.seek(0)
                try:
                    arrow_schema = pq.ParquetFile(reader).schema_arrow
                except CatalogError:
                    raise
                except Exception as exc:
                    raise _schema_error(
                        f"Could not read remote Parquet schema for {member['remote_key']!r} via Range read: {exc}"
                    ) from exc
                total_bytes_read += reader.bytes_fetched
                tbl_schemas.append(arrow_schema)
                if not verify_member_bytes:
                    verified_members.append({
                        "table_name": table["table_name"],
                        "output_name": member["output_name"],
                        "partition_values": dict(member["partition_values"]),
                        "remote_key": member["remote_key"],
                        "size": reader.size,
                        "sha256": member["sha256"],
                        "footer_sha256": footer_sha,
                        "rows": member["rows"],
                        "verification": "range",
                    })

    verified_schemas = None
    if declared_schemas is not None:
        verified_schemas = verify_parquet_schema_parity(
            declared_schemas,
            member_schemas_by_table if eff_schema_mode == "range" else member_bytes_by_table,
            check_order=schema_check_order,
            check_nullability=schema_check_nullability,
            allow_subset_tables=has_iceberg_only,
        )

    verified_iceberg_snapshots = []
    verified_iceberg_by_loc: dict[str, Mapping[str, Any]] = {}
    for snap in manifest_doc.get("iceberg_snapshots", ()):
        meta_loc = snap.get("metadata_location")
        remote_key = snap.get("remote_key")
        is_http_meta = isinstance(meta_loc, str) and meta_loc.startswith(("http://", "https://"))
        raw_meta: bytes | None = None
        meta_label = meta_loc or remote_key or "<unknown>"

        if is_http_meta:
            _validate_external_http_url(meta_loc, allow_insecure_http=allow_insecure_http)
            if remote_key and pub_base:
                expected_meta_url = f"{pub_base}/{remote_key.lstrip('/')}"
                if meta_loc != expected_meta_url:
                    raise ValueError(
                        f"Remote Iceberg metadata_location {meta_loc!r} disagrees with "
                        f"remote_key URL {expected_meta_url!r}"
                    )
            if pub_base and meta_loc.startswith(pub_base + "/"):
                meta_rel_key = meta_loc[len(pub_base) + 1 :]
                raw_meta = next(
                    (raw for name, raw in catalog_bytes_by_name.items()
                     if any(e.get("name") == name and e.get("remote_key") == meta_rel_key
                            for e in manifest_doc.get("catalog_artifacts", ()))),
                    None,
                )
                if raw_meta is None:
                    fetched_meta, _ = fetch_object(meta_rel_key)
                    raw_meta = bytes(fetched_meta)
                    total_bytes_read += len(raw_meta)
            elif hasattr(fetch_object, "fetch_url"):
                fetched_meta, _ = fetch_object.fetch_url(meta_loc)
                raw_meta = bytes(fetched_meta)
                total_bytes_read += len(raw_meta)
            else:
                fetched_meta, _ = _no_redirect_http_get(
                    meta_loc,
                    allow_insecure_http=allow_insecure_http,
                    timeout=timeout,
                    user_agent=eff_user_agent,
                )
                raw_meta = bytes(fetched_meta)
                total_bytes_read += len(raw_meta)
        elif remote_key:
            raw_meta = next(
                (raw for name, raw in catalog_bytes_by_name.items()
                 if any(e.get("name") == name and e.get("remote_key") == remote_key
                        for e in manifest_doc.get("catalog_artifacts", ()))),
                None,
            )
            if raw_meta is None:
                fetched_meta, _ = fetch_object(remote_key)
                raw_meta = bytes(fetched_meta)
                total_bytes_read += len(raw_meta)

        if raw_meta is not None:
            if sha256(raw_meta).hexdigest() != snap["metadata_sha256"]:
                raise ValueError(f"Remote Iceberg metadata {meta_label} failed SHA-256 verification")
            inspected = inspect_iceberg_table_metadata(raw_meta)
            if (
                inspected["current_snapshot_id"] != snap["snapshot_id"]
                or inspected["current_schema_id"] != snap["schema_id"]
                or inspected["manifest_list"] != snap["manifest_list"]
            ):
                raise ValueError(f"Remote Iceberg metadata {meta_label} disagrees with pinned snapshot")
        if isinstance(meta_loc, str):
            verified_iceberg_by_loc[meta_loc] = snap
        verified_iceberg_snapshots.append(dict(snap))

    for rep in catalog_doc.get("representations", ()):
        if not isinstance(rep, Mapping):
            continue
        cat_ice = rep.get("icebergSnapshot")
        if not isinstance(cat_ice, Mapping):
            continue
        cat_loc = cat_ice.get("metadataLocation")
        matched = verified_iceberg_by_loc.get(cat_loc) if isinstance(cat_loc, str) else None
        if matched is None:
            raise ValueError(
                f"Catalog representation icebergSnapshot metadataLocation {cat_loc!r} "
                "is missing from verified release manifest iceberg_snapshots"
            )
        if (
            cat_ice.get("metadataSha256") != matched.get("metadata_sha256")
            or cat_ice.get("snapshotId") != matched.get("snapshot_id")
            or cat_ice.get("schemaId") != matched.get("schema_id")
            or cat_ice.get("manifestList") != matched.get("manifest_list")
        ):
            raise ValueError(
                f"Catalog representation icebergSnapshot {cat_loc!r} disagrees with release manifest"
            )

    return {
        "release_id": live_release_id,
        "etag": live_etag,
        "catalog": catalog_doc,
        "report": report_doc,
        "lock": lock_info["lock"],
        "lock_sha256": lock_info["lock_sha256"],
        "manifest": manifest_doc,
        "verified_members": verified_members,
        "verified_iceberg_snapshots": verified_iceberg_snapshots,
        "catalog_artifacts": set(catalog_bytes_by_name),
        "public_bytes_read": total_bytes_read,
        **({"verified_schemas": verified_schemas} if verified_schemas is not None else {}),
    }


def odcs_to_iceberg_type(
    prop: Mapping[str, Any],
    *,
    default_integer: str = "int",
    _alloc_id: Any = None,
) -> str | dict[str, Any]:
    """Map an ODCS field definition property to an Apache Iceberg v2 primitive or nested type."""
    logical = str(prop.get("logicalType") or "string").lower()
    physical_raw = str(prop.get("physicalType") or "").strip()
    physical = physical_raw.upper()
    options = prop.get("logicalTypeOptions") or {}
    fmt = str(options.get("format") or "").lower()

    if logical == "integer":
        if "BIGINT" in physical or "INT64" in physical or physical in {"I64", "INT8"} or fmt == "i64":
            return "long"
        if (
            "INT32" in physical
            or physical in {"I32", "INT", "INTEGER", "INT4", "SMALLINT", "TINYINT", "I16", "I8"}
            or fmt in {"i32", "i16", "i8"}
        ):
            return "int"
        return default_integer
    if logical in {"number", "float", "double", "decimal"}:
        dec_match = re.fullmatch(r"(?:DECIMAL(?:128|256)?|NUMERIC)\(\s*(\d+)\s*,\s*(\d+)\s*\)", physical)
        if dec_match:
            return f"decimal({int(dec_match[1])}, {int(dec_match[2])})"
        if isinstance(options.get("precision"), int) and isinstance(options.get("scale"), int):
            return f"decimal({options['precision']}, {options['scale']})"
        if fmt == "f32" or physical in {"FLOAT", "FLOAT32", "REAL", "F32"}:
            return "float"
        return "double"
    if logical == "boolean":
        return "boolean"
    if logical == "date":
        return "date"
    if logical == "timestamp":
        return "timestamptz"
    if logical == "binary" or fmt == "binary" or physical in {"BINARY", "LARGE_BINARY", "BYTEA"} or physical.startswith("FIXED["):
        return "binary"
    if logical == "object":
        alloc = _alloc_id or (lambda _counter=[100]: (_counter.__setitem__(0, _counter[0] + 1) or _counter[0]))
        sub_fields = []
        for sub in prop.get("properties") or ():
            if not isinstance(sub, Mapping) or "name" not in sub:
                continue
            fid = alloc()
            sub_fields.append({
                "id": fid,
                "name": str(sub["name"]),
                "required": bool(sub.get("required", False)),
                "type": odcs_to_iceberg_type(sub, default_integer=default_integer, _alloc_id=alloc),
            })
        return {"type": "struct", "fields": sub_fields}
    if logical == "array" and isinstance(prop.get("items"), Mapping):
        alloc = _alloc_id or (lambda _counter=[100]: (_counter.__setitem__(0, _counter[0] + 1) or _counter[0]))
        elem_id = alloc()
        items = prop["items"]
        return {
            "type": "list",
            "element-id": elem_id,
            "element-required": bool(items.get("required", False)),
            "element": odcs_to_iceberg_type(items, default_integer=default_integer, _alloc_id=alloc),
        }
    return "string"


def synthesize_iceberg_v2_snapshot(
    *,
    table_name: str,
    properties: Sequence[Mapping[str, Any]],
    table_location: str,
    metadata_location: str,
    table_uuid: str,
    snapshot_id: int,
    timestamp_ms: int,
    manifest_list: str,
    partition_keys: Sequence[str] = (),
    summary: Mapping[str, str] | None = None,
    metadata_out_path: Path | None = None,
    remote_rel_key: str | None = None,
    include_bytes: bool = True,
    default_integer: str = "int",
) -> IcebergTableSnapshotSpec:
    """Synthesize, validate, and optionally write an Apache Iceberg v2 table ``metadata.json`` snapshot."""
    next_id = [0]

    def _alloc_id() -> int:
        next_id[0] += 1
        return next_id[0]

    fields: list[dict[str, Any]] = []
    col_id_by_name: dict[str, int] = {}
    for prop in properties:
        col_name = str(prop["name"])
        fid = _alloc_id()
        col_id_by_name[col_name] = fid
        field_entry: dict[str, Any] = {
            "id": fid,
            "name": col_name,
            "required": bool(prop.get("required", False)),
            "type": odcs_to_iceberg_type(prop, default_integer=default_integer, _alloc_id=_alloc_id),
        }
        if prop.get("description"):
            field_entry["doc"] = str(prop["description"])
        fields.append(field_entry)

    part_fields = [
        {
            "source-id": col_id_by_name[pkey],
            "field-id": 1000 + offset,
            "name": pkey,
            "transform": "identity",
        }
        for offset, pkey in enumerate(partition_keys)
        if pkey in col_id_by_name
    ]

    clean_location = table_location.rstrip("/")
    iceberg_doc = {
        "format-version": 2,
        "table-uuid": table_uuid,
        "location": clean_location,
        "last-sequence-number": 1,
        "last-updated-ms": timestamp_ms,
        "last-column-id": next_id[0],
        "current-schema-id": 0,
        "schemas": [
            {
                "type": "struct",
                "schema-id": 0,
                "fields": fields,
            }
        ],
        "default-spec-id": 0,
        "partition-specs": [{"spec-id": 0, "fields": part_fields}],
        "last-partition-id": 999 + len(part_fields),
        "default-sort-order-id": 0,
        "sort-orders": [{"order-id": 0, "fields": []}],
        "current-snapshot-id": snapshot_id,
        "snapshots": [
            {
                "snapshot-id": snapshot_id,
                "sequence-number": 1,
                "timestamp-ms": timestamp_ms,
                "manifest-list": manifest_list,
                "summary": dict(summary) if summary is not None else {"operation": "append"},
                "schema-id": 0,
            }
        ],
    }

    raw_bytes = (json_dumps(iceberg_doc, sort_keys=True) + "\n").encode("utf-8")
    inspect_iceberg_table_metadata(raw_bytes)
    if metadata_out_path is not None:
        metadata_out_path.parent.mkdir(parents=True, exist_ok=True)
        metadata_out_path.write_bytes(raw_bytes)

    return IcebergTableSnapshotSpec.from_metadata(
        raw_bytes,
        metadata_location=metadata_location,
        table_name=table_name,
        include_bytes=include_bytes,
        remote_rel_key=remote_rel_key,
    )


class _ObjectStorageRangeFile(io.RawIOBase):
    """Seekable range-reader over an ``ObjectStoragePort`` for zero-copy Parquet footer reads."""

    def __init__(self, storage: Any, remote_key: str, *, expected_size: int | None = None):
        self.storage = storage
        self.remote_key = remote_key
        if expected_size is not None:
            _need(isinstance(expected_size, int) and not isinstance(expected_size, bool) and expected_size >= 12,
                  f"Invalid Parquet byte size for {remote_key!r}: {expected_size!r}")
            self.size = expected_size
        else:
            head = storage.head_object(remote_key)
            size = head.get("size")
            _need(isinstance(size, int) and not isinstance(size, bool) and size >= 12,
                  f"Remote Parquet object {remote_key!r} missing valid byte size in HEAD response")
            self.size = size
        self.pos = 0
        self._spans: list[tuple[int, int, bytes]] = []

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self.pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if whence == io.SEEK_SET:
            target = offset
        elif whence == io.SEEK_CUR:
            target = self.pos + offset
        elif whence == io.SEEK_END:
            target = self.size + offset
        else:
            raise OSError("Unsupported seek whence")
        if target < 0:
            raise OSError("Negative seek position")
        self.pos = min(target, self.size)
        return self.pos

    def _fetch_span(self, start: int, end_inclusive: int) -> bytes:
        data = self.storage.get_bytes(self.remote_key, byte_range=(start, end_inclusive))
        self._spans.append((start, start + len(data), data))
        return data

    def _read_interval(self, start: int, end_excl: int) -> bytes:
        if start >= end_excl:
            return b""
        for sp_start, sp_end, sp_buf in self._spans:
            if sp_start <= start and end_excl <= sp_end:
                return sp_buf[start - sp_start : end_excl - sp_start]
        fetched = self._fetch_span(start, end_excl - 1)
        return fetched[: end_excl - start]

    def read(self, size: int = -1) -> bytes:
        if self.pos >= self.size or size == 0:
            return b""
        if size is None or size < 0:
            size = self.size - self.pos
        end_excl = min(self.size, self.pos + size)
        out = self._read_interval(self.pos, end_excl)
        self.pos = end_excl
        return out

    def readinto(self, b) -> int:
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n


def _extract_odcs_schema_object(
    odcs_contract_or_schema: Mapping[str, Any] | Path | str,
    *,
    table_name: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Load an ODCS v3.2.0 DataContract (if given) and select one target SchemaObject."""
    if isinstance(odcs_contract_or_schema, (Path, str)):
        doc = read_json(odcs_contract_or_schema).value
    elif isinstance(odcs_contract_or_schema, Mapping):
        doc = deepcopy(dict(odcs_contract_or_schema))
    else:
        raise CatalogError("CATALOG-SCHEMA-PARITY", "ODCS contract or schema must be a mapping or JSON path")

    if isinstance(doc, dict) and doc.get("kind") == "DataContract":
        api_ver = doc.get("apiVersion")
        _need(api_ver == "v3.2.0", f"External generation requires ODCS apiVersion 'v3.2.0', got {api_ver!r}")
        schemas = doc.get("schema")
        _need(isinstance(schemas, list) and bool(schemas), "ODCS DataContract requires a nonempty 'schema' list")
        if table_name is not None:
            matches = [s for s in schemas if isinstance(s, dict) and s.get("name") == table_name]
            if not matches and len(schemas) == 1:
                matches = [schemas[0]]
            _need(len(matches) == 1,
                  f"ODCS DataContract {doc.get('id', '')!r} does not uniquely identify schema object {table_name!r}")
            return deepcopy(matches[0]), doc
        _need(len(schemas) == 1, "ODCS DataContract contains multiple schema objects; supply table_name")
        return deepcopy(schemas[0]), doc

    _need(isinstance(doc, dict) and isinstance(doc.get("properties"), list),
          "Expected an ODCS v3.2.0 DataContract or SchemaObject with 'properties'")
    return doc, None


def _uses_managed_schema_v3(declaration: Mapping[str, Any]) -> bool:
    """Detect declarations authored using MANAGED_SCHEMA_V3 exact physicalType/logicalTypeOptions conventions."""
    v3_formats = {"i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64", "f32", "f64", "binary"}

    def _is_v3_node(node: Mapping[str, Any]) -> bool:
        phys = str(node.get("physicalType") or "").strip().lower()
        opts = node.get("logicalTypeOptions") if isinstance(node.get("logicalTypeOptions"), Mapping) else {}
        logical = str(node.get("logicalType") or "").lower()
        fmt = str(opts.get("format") or "").lower()
        if phys.startswith(("decimal128(", "decimal256(")) or fmt in v3_formats:
            return True
        if logical == "date" and opts.get("format") == "yyyy-MM-dd":
            return True
        if logical == "timestamp" and isinstance(opts.get("timezone"), bool):
            return True
        return False

    def _walk(node: Mapping[str, Any]) -> bool:
        for prop in node.get("properties") or ():
            if not isinstance(prop, Mapping):
                continue
            if _is_v3_node(prop) or _walk(prop):
                return True
        if isinstance(node.get("items"), Mapping):
            item = node["items"]
            if _is_v3_node(item) or _walk(item):
                return True
        return False

    return _walk(declaration)


def _normalize_arrow_type(dtype: Any, decl_node: Mapping[str, Any] | None, pa: Any) -> Any:
    """Opt-in normalization of equivalent external Arrow encodings without loosening actual semantic types."""
    while pa.types.is_dictionary(dtype):
        dtype = dtype.value_type
    if pa.types.is_timestamp(dtype):
        utc_zones = {"UTC", "Etc/UTC", "+00:00"}
        if dtype.tz in utc_zones:
            opts = decl_node.get("logicalTypeOptions") if isinstance(decl_node, Mapping) else None
            decl_tz = opts.get("defaultTimezone") if isinstance(opts, Mapping) else None
            target_tz = decl_tz if decl_tz in utc_zones else "UTC"
            if dtype.tz != target_tz:
                return pa.timestamp(dtype.unit, tz=target_tz)
        return dtype
    if pa.types.is_list(dtype) or pa.types.is_large_list(dtype):
        items_node = decl_node.get("items") if isinstance(decl_node, Mapping) else None
        vf = dtype.value_field
        new_name = (
            "element"
            if vf.name == "item" and isinstance(items_node, Mapping) and "name" not in items_node
            else vf.name
        )
        norm_child = _normalize_arrow_type(vf.type, items_node if isinstance(items_node, Mapping) else None, pa)
        new_vf = pa.field(new_name, norm_child, nullable=vf.nullable, metadata=vf.metadata)
        return pa.large_list(new_vf) if pa.types.is_large_list(dtype) else pa.list_(new_vf)
    if pa.types.is_struct(dtype):
        sub_decls = (
            {
                p["name"]: p
                for p in (decl_node.get("properties") or ())
                if isinstance(p, Mapping) and isinstance(p.get("name"), str)
            }
            if isinstance(decl_node, Mapping)
            else {}
        )
        return pa.struct([
            pa.field(
                f.name,
                _normalize_arrow_type(f.type, sub_decls.get(f.name), pa),
                nullable=f.nullable,
                metadata=f.metadata,
            )
            for f in dtype
        ])
    return dtype


def _normalize_arrow_schema(
    arrow_schema: Any,
    declaration: Mapping[str, Any],
    pa: Any,
    *,
    normalize_arrow_encodings: bool,
    check_column_order: bool,
) -> Any:
    """Apply explicit opt-in encoding normalization and/or root column reordering to an Arrow Schema."""
    fields = list(arrow_schema)
    decl_props = [
        p
        for p in (declaration.get("properties") or ())
        if isinstance(p, Mapping) and isinstance(p.get("name"), str)
    ]
    if normalize_arrow_encodings:
        decl_by_name = {p["name"]: p for p in decl_props}
        fields = [
            pa.field(
                f.name,
                _normalize_arrow_type(f.type, decl_by_name.get(f.name), pa),
                nullable=f.nullable,
                metadata=f.metadata,
            )
            for f in fields
        ]
    if not check_column_order:
        obs_names = [f.name for f in fields]
        decl_names = [p["name"] for p in decl_props]
        if (
            len(obs_names) == len(set(obs_names))
            and len(decl_names) == len(set(decl_names))
            and set(obs_names) == set(decl_names)
        ):
            by_name = {f.name: f for f in fields}
            fields = [by_name[name] for name in decl_names]
    return pa.schema(fields, metadata=arrow_schema.metadata)


def _schema_error(message: str) -> CatalogError:
    return CatalogError("CATALOG-PUBLICATION-SCHEMA", message)


def _resolve_expected_arrow_schema(expected: Any, pa: Any, *, table_name: str | None = None):
    """Normalize a PyArrow Schema, ODCS contract/object dict, or DDK Arrow mapping into ``pa.Schema``."""
    if isinstance(expected, pa.Schema):
        return expected
    if isinstance(expected, Mapping):
        if expected.get("kind") == "DataContract" and "schema" in expected:
            expected, _ = _extract_odcs_schema_object(expected, table_name=table_name)
        if "properties" in expected:
            from .docspec_recipe_gate import UnmappedSchemaError, odcs_schema_to_pyarrow

            try:
                return odcs_schema_to_pyarrow(dict(expected), pa)
            except UnmappedSchemaError as exc:
                raise _schema_error(str(exc)) from exc
        if "fields" in expected:
            from .arrow_mapping import MappingUnavailable, pyarrow_schema

            try:
                return pyarrow_schema(dict(expected), pa)
            except MappingUnavailable as exc:
                raise _schema_error(str(exc)) from exc
    raise _schema_error(
        "Expected declared schema must be a pyarrow.Schema, ODCS object dict ('properties'), "
        "or declared Arrow schema dict ('fields')"
    )


def _resolve_actual_arrow_schema(actual: Any, pa: Any, pq: Any):
    """Read an actual ``pa.Schema`` from a PyArrow Schema, Parquet path, Parquet bytes, or Arrow IPC bytes."""
    if isinstance(actual, pa.Schema):
        return actual
    if isinstance(actual, (str, Path)):
        path = Path(actual)
        if not path.is_file():
            raise _schema_error(f"Parquet file missing for schema parity check: {path}")
        try:
            return pq.read_schema(path)
        except Exception as exc:
            raise _schema_error(f"Could not read Parquet schema from {path}: {exc}") from exc
    if isinstance(actual, (bytes, bytearray, memoryview)):
        raw = bytes(actual)
        try:
            if raw[:4] == b"PAR1":
                return pq.read_schema(pa.BufferReader(raw))
            return pa.ipc.read_schema(pa.py_buffer(raw))
        except Exception as exc:
            raise _schema_error(f"Could not read Arrow/Parquet schema from bytes: {exc}") from exc
    raise _schema_error(f"Unsupported actual schema input type: {type(actual).__name__}")


def _schema_fingerprint(schema: Any) -> str:
    canonical = [[field.name, str(field.type), bool(field.nullable)] for field in schema]
    return sha256(_canonical_json_bytes(canonical)).hexdigest()


def parquet_schema_diff(
    expected: Any,
    actual: Any,
    *,
    check_order: bool = True,
    check_nullability: bool = False,
) -> list[str]:
    """Compare an expected schema contract against an actual Parquet/Arrow schema.

    Returns a list of human-readable drift descriptions, empty when schemas match.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq

    exp_schema = _resolve_expected_arrow_schema(expected, pa)
    act_schema = _resolve_actual_arrow_schema(actual, pa, pq)

    expected_fields = {f.name: f for f in exp_schema}
    actual_fields = {f.name: f for f in act_schema}
    issues: list[str] = []

    if missing := [f.name for f in exp_schema if f.name not in actual_fields]:
        issues.append(f"missing columns {missing}")
    if extra := [f.name for f in act_schema if f.name not in expected_fields]:
        issues.append(f"unexpected columns {extra}")
    if mismatched := [
        f"{f.name} (expected {expected_fields[f.name].type}, got {f.type})"
        for f in act_schema
        if f.name in expected_fields and f.type != expected_fields[f.name].type
    ]:
        issues.append(f"type mismatch on {mismatched}")
    if check_nullability:
        if null_diffs := [
            f"{f.name} (expected nullable={expected_fields[f.name].nullable}, got {f.nullable})"
            for f in act_schema
            if f.name in expected_fields and f.nullable != expected_fields[f.name].nullable
        ]:
            issues.append(f"nullability mismatch on {null_diffs}")
    if not issues and check_order and list(act_schema.names) != list(exp_schema.names):
        issues.append(f"column order differs (expected {list(exp_schema.names)}, got {list(act_schema.names)})")
    return issues


def _normalize_schema_table_map(items: Mapping[str, Any], kind: str) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for raw_name, value in items.items():
        if not isinstance(raw_name, str) or not raw_name:
            raise _schema_error(f"{kind} table name must be a non-empty string")
        table_name = raw_name.removesuffix(".parquet")
        if table_name in normalized:
            raise _schema_error(f"Duplicate {kind} table entry after .parquet normalization: {table_name!r}")
        normalized[table_name] = value
    return normalized


def _expand_schema_candidate_items(table_name: str, candidate: Any) -> list[tuple[str, Any]]:
    if isinstance(candidate, (str, Path)):
        path = Path(candidate)
        if path.is_dir():
            files = sorted(path.rglob("*.parquet"))
            if not files:
                raise _schema_error(
                    f"Partitioned table {table_name!r} directory {path} contains no Parquet member files"
                )
            return [(p.relative_to(path).as_posix(), p) for p in files]
        if not path.is_file():
            raise _schema_error(f"Table {table_name!r} Parquet file is missing: {path}")
        return [(path.name, path)]
    if isinstance(candidate, (bytes, bytearray, memoryview)):
        return [(f"{table_name}[0]", bytes(candidate))]
    if isinstance(candidate, Sequence):
        items = list(candidate)
        if not items:
            raise _schema_error(f"Table {table_name!r} has an empty Parquet candidate sequence")
        expanded: list[tuple[str, Any]] = []
        for idx, item in enumerate(items):
            if isinstance(item, (str, Path)):
                label = str(item)
            else:
                label = f"{table_name}[{idx}]"
            expanded.append((label, item))
        return expanded
    return [(table_name, candidate)]


def _verify_batch_parquet_schema_parity(
    declared_schemas: Mapping[str, Any],
    candidates: Mapping[str, Any],
    *,
    check_order: bool = True,
    check_nullability: bool = False,
    allow_subset_tables: bool = False,
) -> dict[str, dict[str, Any]]:
    """Verify every candidate table/shard strictly matches its declared Arrow or ODCS schema."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    norm_declared = _normalize_schema_table_map(declared_schemas, "declared")
    norm_candidates = _normalize_schema_table_map(candidates, "candidate")

    if unexpected := sorted(set(norm_candidates) - set(norm_declared)):
        raise _schema_error(
            f"Candidate generation declares unexpected table(s) {unexpected!r}; "
            f"declared tables are {sorted(norm_declared)}"
        )
    if not allow_subset_tables:
        if missing_tables := sorted(set(norm_declared) - set(norm_candidates)):
            raise _schema_error(
                f"Candidate generation missing declared table(s): {missing_tables!r}"
            )

    summary: dict[str, dict[str, Any]] = {}
    for table_name in sorted(norm_candidates):
        expected_raw = norm_declared[table_name]
        expected_schema = _resolve_expected_arrow_schema(expected_raw, pa, table_name=table_name)
        items = _expand_schema_candidate_items(table_name, norm_candidates[table_name])
        for label, item in items:
            actual_schema = _resolve_actual_arrow_schema(item, pa, pq)
            if issues := parquet_schema_diff(
                expected_schema,
                actual_schema,
                check_order=check_order,
                check_nullability=check_nullability,
            ):
                raise _schema_error(
                    f"Schema parity check failed for {table_name!r} ({label}): " + "; ".join(issues)
                )
        summary[table_name] = {
            "files_checked": len(items),
            "columns": list(expected_schema.names),
            "schema_sha256": _schema_fingerprint(expected_schema),
        }
    return summary


def verify_parquet_schema_parity(
    parquet_source: Any,
    odcs_contract_or_schema: Mapping[str, Any] | Path | str,
    *,
    table_name: str | None = None,
    profile: str | None = None,
    storage: Any | None = None,
    remote_key: str | None = None,
    expected_size: int | None = None,
    expected_sha256: str | None = None,
    expected_footer_sha256: str | None = None,
    allow_insecure_http: bool = False,
    timeout: float = 15.0,
    user_agent: str | None = None,
    raise_on_error: bool = True,
    normalize_arrow_encodings: bool = False,
    check_column_order: bool | None = None,
    check_order: bool = True,
    check_nullability: bool = False,
    allow_subset_tables: bool = False,
) -> dict[str, Any]:
    """Verify Parquet schema parity against ODCS v3.2.0 or declared batch Arrow schemas.

    Supports both single-table/remote-range parity verification
    ``verify_parquet_schema_parity(parquet_source, odcs_contract_or_schema, ...)``
    and batch mapping verification
    ``verify_parquet_schema_parity(declared_schemas, candidates, ...)``.
    """
    eff_check_order = check_order if check_column_order is None else check_column_order
    if (
        isinstance(parquet_source, Mapping)
        and isinstance(odcs_contract_or_schema, Mapping)
        and storage is None
        and remote_key is None
        and table_name is None
        and profile is None
        and expected_size is None
        and expected_sha256 is None
        and expected_footer_sha256 is None
    ):
        return _verify_batch_parquet_schema_parity(
            parquet_source,
            odcs_contract_or_schema,
            check_order=eff_check_order,
            check_nullability=check_nullability,
            allow_subset_tables=allow_subset_tables,
        )

    import pyarrow as pa
    import pyarrow.parquet as pq

    from .arrow_observation import MANAGED_SCHEMA_V3
    from .catalog_access import _HttpRangeParquetFile
    from .catalog_query import _verify_and_read_schema, compute_parquet_footer_sha256
    from .docspec_job_evidence import interpret_output_schema

    declaration, _ = _extract_odcs_schema_object(odcs_contract_or_schema, table_name=table_name)
    target_name = table_name or declaration.get("name") or "<unknown>"
    eff_profile = profile if profile is not None else (
        MANAGED_SCHEMA_V3 if _uses_managed_schema_v3(declaration) else None
    )

    observed_size: int | None = expected_size
    observed_footer_sha: str | None = None

    if isinstance(parquet_source, pa.Schema):
        arrow_schema = parquet_source
    elif storage is not None and (remote_key is not None or (
        isinstance(parquet_source, str) and not parquet_source.startswith(("http://", "https://"))
    )):
        key = remote_key if remote_key is not None else str(parquet_source)
        reader = _ObjectStorageRangeFile(storage, key, expected_size=None)
        observed_size = reader.size
        if expected_size is not None and observed_size != expected_size:
            raise CatalogError(
                "CATALOG-SCHEMA-PARITY",
                f"Parquet byte size {observed_size} disagrees with expected {expected_size} for {target_name!r}",
            )
        observed_footer_sha = compute_parquet_footer_sha256(reader, reader.size)
        reader.seek(0)
        arrow_schema = pq.ParquetFile(reader).schema_arrow
    elif isinstance(parquet_source, str) and parquet_source.startswith(("http://", "https://")):
        reader = _HttpRangeParquetFile(
            parquet_source,
            expected_byte_size=None,
            timeout=timeout,
            allow_insecure_http=allow_insecure_http,
            user_agent=user_agent,
        )
        observed_size = reader.size
        if expected_size is not None and observed_size != expected_size:
            raise CatalogError(
                "CATALOG-SCHEMA-PARITY",
                f"Parquet byte size {observed_size} disagrees with expected {expected_size} for {target_name!r}",
            )
        observed_footer_sha = compute_parquet_footer_sha256(reader, reader.size)
        reader.seek(0)
        arrow_schema = pq.ParquetFile(reader).schema_arrow
    elif isinstance(parquet_source, (Path, str)):
        local_path = Path(parquet_source)
        observed_size = local_path.stat().st_size
        if expected_size is not None and observed_size != expected_size:
            raise CatalogError(
                "CATALOG-SCHEMA-PARITY",
                f"Parquet byte size {observed_size} disagrees with expected {expected_size} for {target_name!r}",
            )
        if expected_sha256 is not None or expected_footer_sha256 is not None:
            try:
                arrow_schema = _verify_and_read_schema(
                    local_path,
                    observed_size,
                    expected_sha256,
                    pq,
                    footer_sha256=expected_footer_sha256,
                )
            except CatalogError as exc:
                if exc.code == "CATALOG-LOCAL-QUERY":
                    raise CatalogError("CATALOG-SCHEMA-PARITY", str(exc)) from exc
                raise
            observed_footer_sha = compute_parquet_footer_sha256(local_path, observed_size)
        else:
            observed_footer_sha = compute_parquet_footer_sha256(local_path, observed_size)
            arrow_schema = pq.read_schema(local_path)
    else:
        raise CatalogError("CATALOG-SCHEMA-PARITY", f"Unsupported parquet_source type: {type(parquet_source).__name__}")

    if expected_size is not None and observed_size is not None and observed_size != expected_size:
        raise CatalogError(
            "CATALOG-SCHEMA-PARITY",
            f"Parquet byte size {observed_size} disagrees with expected {expected_size} for {target_name!r}",
        )
    if expected_footer_sha256 is not None and observed_footer_sha is not None and observed_footer_sha != expected_footer_sha256:
        raise CatalogError(
            "CATALOG-SCHEMA-PARITY",
            f"Parquet footer SHA-256 {observed_footer_sha} disagrees with expected {expected_footer_sha256} for {target_name!r}",
        )

    if normalize_arrow_encodings or not eff_check_order:
        arrow_schema = _normalize_arrow_schema(
            arrow_schema,
            declaration,
            pa,
            normalize_arrow_encodings=normalize_arrow_encodings,
            check_column_order=eff_check_order,
        )

    sink = pa.BufferOutputStream()
    writer = pa.ipc.new_stream(sink, arrow_schema)
    writer.close()
    schema_ipc_bytes = sink.getvalue().to_pybytes()

    interpreted = interpret_output_schema(schema_ipc_bytes, declaration, profile=eff_profile)
    result = {
        "table_name": target_name,
        "status": interpreted.status,
        "profile": eff_profile,
        "reasons": list(interpreted.reasons),
        "fields": list(interpreted.fields),
        "obligations": list(interpreted.obligations),
        **({"byte_size": observed_size} if observed_size is not None else {}),
        **({"footer_sha256": observed_footer_sha} if observed_footer_sha is not None else {}),
    }
    if interpreted.status != "passed" and raise_on_error:
        detail = "; ".join(interpreted.reasons) if interpreted.reasons else f"status={interpreted.status}"
        raise CatalogError(
            "CATALOG-SCHEMA-PARITY",
            f"Parquet schema parity failed for table {target_name!r} ({interpreted.status}): {detail}",
        )
    return result


def _normalize_dataset_alias(name: str) -> str:
    cleaned = re.sub(r"[^a-z0-9-]+", "-", name.strip().lower()).strip("-")
    _need(bool(cleaned) and bool(_ALIAS_SAFE.fullmatch(cleaned)),
          f"Cannot normalize table name {name!r} to a valid DDK dataset alias")
    return cleaned


@dataclass(frozen=True)
class ExternalParquetObjectSpec:
    """Descriptor for one pre-existing immutable Parquet object referenced without copying."""

    table_name: str
    remote_key: str
    sha256: str
    size: int
    rows: int
    url: str | None = None
    blake3: str | None = None
    md5: str | None = None
    footer_sha256: str | None = None
    etag: str | None = None
    partition_values: Mapping[str, str] = field(default_factory=dict)
    output_name: str | None = None
    content_type: str = PARQUET_CONTENT_TYPE
    allow_insecure_http: bool = False

    def __post_init__(self):
        _need(_SAFE_KEY_PART.fullmatch(self.table_name or ""),
              f"Invalid external table_name: {self.table_name!r}")
        _safe_rel_path(self.remote_key, allow_equals=True)
        _need(isinstance(self.sha256, str) and bool(_HEX64.fullmatch(self.sha256)),
              f"External Parquet object {self.remote_key!r} requires 64-hex lowercase sha256")
        _need(isinstance(self.size, int) and not isinstance(self.size, bool) and self.size > 0,
              f"External Parquet object {self.remote_key!r} requires positive integer size")
        _need(isinstance(self.rows, int) and not isinstance(self.rows, bool) and self.rows >= 0,
              f"External Parquet object {self.remote_key!r} requires non-negative integer rows")
        if self.url is not None:
            object.__setattr__(
                self,
                "url",
                _validate_external_http_url(self.url, allow_insecure_http=self.allow_insecure_http),
            )
        if self.blake3 is not None:
            _need(isinstance(self.blake3, str) and bool(_HEX64.fullmatch(self.blake3)),
                  f"External Parquet object {self.remote_key!r} blake3 must be 64-hex lowercase")
        if self.md5 is not None:
            _need(isinstance(self.md5, str) and bool(_HEX32.fullmatch(self.md5)),
                  f"External Parquet object {self.remote_key!r} md5 must be 32-hex lowercase")
        if self.footer_sha256 is not None:
            _need(isinstance(self.footer_sha256, str) and bool(_HEX64.fullmatch(self.footer_sha256)),
                  f"External Parquet object {self.remote_key!r} footer_sha256 must be 64-hex lowercase")
        _need(isinstance(self.partition_values, Mapping)
              and all(isinstance(k, str) and isinstance(v, str) for k, v in self.partition_values.items()),
              "Partition values must map string partition names to string values")
        object.__setattr__(self, "partition_values", MappingProxyType(dict(self.partition_values)))
        if self.output_name is not None:
            _need(isinstance(self.output_name, str) and bool(self.output_name.strip()),
                  "output_name must be a nonempty string when provided")


@dataclass(frozen=True)
class ExternalTableSpec:
    """Logical table pairing an ODCS v3.2.0 contract with pre-existing immutable Parquet objects."""

    table_name: str
    contract: Mapping[str, Any] | Path | str
    members: tuple[ExternalParquetObjectSpec, ...]
    partition_keys: tuple[str, ...] = ()
    contract_object: str | None = None
    catalog_id: str | None = None
    title: str | None = None
    description: str | None = None
    withheld_columns: tuple[str, ...] = ()
    iceberg_snapshot: IcebergTableSnapshotSpec | None = None
    default_integer: str = "long"
    schema_profile: str | None = None
    normalize_arrow_encodings: bool = False
    check_column_order: bool = True

    def __post_init__(self):
        _need(_SAFE_KEY_PART.fullmatch(self.table_name or ""),
              f"Invalid external table_name: {self.table_name!r}")
        members = tuple(self.members)
        _need(bool(members), f"External table {self.table_name!r} requires at least one Parquet member")
        for m in members:
            _need(isinstance(m, ExternalParquetObjectSpec),
                  f"External table {self.table_name!r} members must be ExternalParquetObjectSpec")
            _need(m.table_name == self.table_name,
                  f"External member table_name {m.table_name!r} disagrees with {self.table_name!r}")
        keys = tuple(self.partition_keys)
        _need(len(keys) == len(set(keys)) and all(_SAFE_KEY_PART.fullmatch(k or "") for k in keys),
              f"Invalid or duplicate partition_keys on {self.table_name!r}")
        if self.iceberg_snapshot is not None:
            _need(isinstance(self.iceberg_snapshot, IcebergTableSnapshotSpec),
                  f"iceberg_snapshot on {self.table_name!r} must be IcebergTableSnapshotSpec")
        object.__setattr__(self, "members", members)
        object.__setattr__(self, "partition_keys", keys)
        object.__setattr__(self, "withheld_columns", tuple(self.withheld_columns))


@dataclass(frozen=True)
class ExternalGenerationBundle:
    """Self-contained DDK catalog + Iceberg v2 + remote CAS publication plan over external Parquet objects."""

    release_id: str
    dataset: str
    operation: str
    destination: RemoteDestination
    catalog_dir: Path
    catalog_release: FrozenCatalogRelease
    plan: RemotePublicationPlan
    tables: tuple[ExternalTableSpec, ...]
    iceberg_snapshots: tuple[IcebergTableSnapshotSpec, ...]
    schema_parity: tuple[Mapping[str, Any], ...]
    lock_sha256: str
    catalog_sha256: str
    expected_prior_release_id: Any = ...
    has_explicit_expected_pointer: bool = False


def _resolve_contract_input(
    raw_contract: Any,
    *,
    contracts_base_dir: Path | None,
) -> Mapping[str, Any] | Path:
    if isinstance(raw_contract, Mapping):
        return dict(raw_contract)
    if isinstance(raw_contract, Path):
        return raw_contract
    if isinstance(raw_contract, str):
        p = Path(raw_contract)
        if not p.is_absolute() and contracts_base_dir is not None:
            p = (contracts_base_dir / p).resolve()
        return p
    raise CatalogError("CATALOG-PUBLICATION", f"Unsupported ODCS contract reference: {raw_contract!r}")


def _format_key_template(template: str, ctx: Mapping[str, Any]) -> str:
    try:
        rendered = template.format(**ctx)
    except KeyError as exc:
        raise CatalogError("CATALOG-PUBLICATION", f"key_template {template!r} missing field {exc}") from exc
    return _safe_rel_path(rendered.lstrip("/"), allow_equals=True)


def normalize_external_generation_descriptor(
    descriptor: Mapping[str, Any] | Path | str,
    *,
    base_url: str | None = None,
    key_template: str | None = None,
    contracts_base_dir: Path | None = None,
    allow_insecure_http: bool = False,
) -> dict[str, Any]:
    """Normalize a generic external-generation descriptor/manifest into canonical ``ExternalTableSpec`` inputs."""
    base_dir = contracts_base_dir
    if isinstance(descriptor, (Path, str)):
        desc_path = Path(descriptor).resolve()
        raw = read_json(desc_path).value
        if base_dir is None:
            base_dir = desc_path.parent
    elif isinstance(descriptor, Mapping):
        raw = deepcopy(dict(descriptor))
    else:
        raise CatalogError("CATALOG-PUBLICATION", "External generation descriptor must be a mapping or JSON file path")

    _need(isinstance(raw, dict), "External generation descriptor must be a JSON object")
    eff_base_url = (base_url or raw.get("base_url") or raw.get("public_base_url") or "").rstrip("/") or None
    eff_template = key_template or raw.get("key_template")
    manifest_ctx = {
        k: v for k, v in raw.items()
        if isinstance(k, str) and isinstance(v, (str, int))
    }

    raw_tables = raw.get("tables")
    if raw_tables is None and isinstance(raw.get("files"), (Mapping, list)):
        contracts_map = raw.get("contracts") or {}
        files_val = raw["files"]
        raw_tables = []
        if isinstance(files_val, Mapping):
            for fname, entry in files_val.items():
                if not isinstance(entry, Mapping):
                    continue
                if not str(fname).endswith(".parquet") and "table_name" not in entry and "table" not in entry:
                    continue
                tname = entry.get("table_name") or entry.get("table") or PurePosixPath(str(fname)).stem
                contract_ref = entry.get("contract") or entry.get("contract_path") or contracts_map.get(tname) or contracts_map.get(str(fname))
                _need(contract_ref is not None, f"Missing ODCS contract mapping for file {fname!r}")
                raw_tables.append({
                    **dict(entry),
                    "table_name": tname,
                    "filename": PurePosixPath(str(fname)).name,
                    "contract": contract_ref,
                })
        else:
            for entry in files_val:
                if not isinstance(entry, Mapping):
                    continue
                fname = entry.get("filename") or entry.get("path") or entry.get("remote_key") or ""
                tname = entry.get("table_name") or entry.get("table") or PurePosixPath(str(fname)).stem
                contract_ref = entry.get("contract") or entry.get("contract_path") or contracts_map.get(tname)
                _need(contract_ref is not None, f"Missing ODCS contract mapping for table {tname!r}")
                raw_tables.append({**dict(entry), "table_name": tname, "contract": contract_ref})

    _need(isinstance(raw_tables, (list, Mapping)) and bool(raw_tables),
          "External generation descriptor requires nonempty 'tables' (or 'files' + 'contracts')")

    if isinstance(raw_tables, Mapping):
        table_entries = [
            {**dict(val), "table_name": val.get("table_name") or key}
            for key, val in raw_tables.items()
        ]
    else:
        table_entries = [dict(item) for item in raw_tables]

    normalized_tables: list[ExternalTableSpec] = []
    for entry in table_entries:
        table_name = entry.get("table_name") or entry.get("table") or entry.get("name")
        _need(isinstance(table_name, str) and bool(table_name), "External table entry requires table_name")
        contract_in = entry.get("contract") or entry.get("contract_path") or entry.get("odcs")
        _need(contract_in is not None, f"External table {table_name!r} requires an ODCS v3.2.0 contract")
        contract = _resolve_contract_input(contract_in, contracts_base_dir=base_dir)
        partition_keys = tuple(entry.get("partition_keys") or ())

        raw_members = entry.get("members") or entry.get("shards")
        if raw_members is None:
            raw_members = [entry]

        table_ctx = {
            **manifest_ctx,
            **{k: v for k, v in entry.items() if isinstance(k, str) and isinstance(v, (str, int))},
            "table": table_name,
            "table_name": table_name,
        }
        if "generation" in table_ctx and isinstance(table_ctx["generation"], str):
            table_ctx["generation_hex"] = table_ctx["generation"].removeprefix("sha256:")

        member_specs: list[ExternalParquetObjectSpec] = []
        for idx, m in enumerate(raw_members):
            m_ctx = {
                **table_ctx,
                **{k: v for k, v in m.items() if isinstance(k, str) and isinstance(v, (str, int))},
            }
            if "generation" in m_ctx and isinstance(m_ctx["generation"], str):
                m_ctx["generation_hex"] = m_ctx["generation"].removeprefix("sha256:")
            m_url = m.get("url")
            m_key = m.get("remote_key") or m.get("key") or m.get("path")
            if m_key is None and eff_template:
                m_key = _format_key_template(eff_template, m_ctx)
            if m_key is None and isinstance(m_url, str) and eff_base_url and m_url.startswith(eff_base_url + "/"):
                m_key = m_url[len(eff_base_url) + 1 :]
            _need(isinstance(m_key, str) and bool(m_key),
                  f"External member #{idx} on table {table_name!r} requires remote_key (or key_template)")
            if m_url is None and eff_base_url:
                clean_base = _validate_external_http_url(eff_base_url, allow_insecure_http=allow_insecure_http).rstrip("/")
                m_url = urljoin(clean_base + "/", m_key.lstrip("/"))
            m_sha = m.get("sha256")
            _need(
                isinstance(m_sha, str) and bool(_HEX64.fullmatch(m_sha)),
                f"External member #{idx} on table {table_name!r} requires 64-hex lowercase sha256",
            )
            m_size = m.get("size") if "size" in m else (m.get("byte_size") if "byte_size" in m else m.get("bytes"))
            m_rows = m.get("rows") if "rows" in m else m.get("row_count")
            out_name = m.get("output_name") or (table_name if len(raw_members) == 1 else f"{table_name}__{idx}")
            member_specs.append(
                ExternalParquetObjectSpec(
                    table_name=table_name,
                    remote_key=m_key,
                    sha256=m_sha,
                    size=m_size,
                    rows=m_rows,
                    url=m_url,
                    blake3=m.get("blake3"),
                    md5=m.get("md5"),
                    footer_sha256=m.get("footer_sha256") or m.get("footerSha256"),
                    etag=m.get("etag"),
                    partition_values=m.get("partition_values") or {},
                    output_name=out_name,
                    allow_insecure_http=allow_insecure_http,
                )
            )

        ice_snap = None
        if entry.get("iceberg_snapshot") is not None:
            raw_snap = entry["iceberg_snapshot"]
            ice_snap = raw_snap if isinstance(raw_snap, IcebergTableSnapshotSpec) else IcebergTableSnapshotSpec(**raw_snap)
        elif entry.get("iceberg_metadata") is not None:
            ice_snap = IcebergTableSnapshotSpec.from_metadata(
                entry["iceberg_metadata"],
                metadata_location=entry.get("iceberg_metadata_location"),
                table_name=table_name,
                remote_rel_key=entry.get("iceberg_remote_key"),
                include_bytes=True,
            )

        normalized_tables.append(
            ExternalTableSpec(
                table_name=table_name,
                contract=contract,
                members=tuple(member_specs),
                partition_keys=partition_keys,
                contract_object=entry.get("contract_object"),
                catalog_id=entry.get("catalog_id"),
                title=entry.get("title"),
                description=entry.get("description"),
                withheld_columns=tuple(entry.get("withheld_columns") or ()),
                iceberg_snapshot=ice_snap,
                default_integer=entry.get("default_integer", "long"),
                schema_profile=entry.get("schema_profile") or entry.get("profile") or raw.get("schema_profile") or raw.get("profile"),
                normalize_arrow_encodings=bool(
                    entry.get("normalize_arrow_encodings", raw.get("normalize_arrow_encodings", False))
                ),
                check_column_order=bool(
                    entry.get("check_column_order", raw.get("check_column_order", True))
                ),
            )
        )

    return {
        "tables": tuple(normalized_tables),
        "dataset": raw.get("dataset"),
        "catalog_id": raw.get("catalog_id"),
        "project_id": raw.get("project_id"),
        "version": raw.get("version"),
        "authority": raw.get("authority"),
        "purpose": raw.get("purpose"),
        "observed_at": raw.get("observed_at"),
        "source_release_id": raw.get("release_id"),
        "audience": raw.get("audience"),
        "relationships": tuple(raw.get("relationships") or ()),
        "product": raw.get("product"),
        "base_url": eff_base_url,
    }


def _default_iceberg_snapshot_for_table(
    table: ExternalTableSpec,
    schema_obj: Mapping[str, Any],
    *,
    catalog_id: str,
    destination: RemoteDestination,
    seed_release_key: str,
    timestamp_ms: int,
    audience: str,
) -> IcebergTableSnapshotSpec:
    public_base = (destination.properties.get("public_base_url") or "").rstrip("/")
    use_https_uris = bool(public_base) and (audience == "public" or public_base.startswith(("http://", "https://")))
    rel_meta_key = f"iceberg/{table.table_name}/metadata/{seed_release_key[:16]}.metadata.json"
    if use_https_uris:
        table_loc = f"{public_base}/{destination.release_prefix}/{seed_release_key}/iceberg/{table.table_name}"
        meta_loc = f"{public_base}/{destination.release_prefix}/{seed_release_key}/{rel_meta_key}"
        manifest_list = f"{table_loc}/metadata/snap-{seed_release_key[:16]}.avro"
    else:
        table_loc = f"{destination.owned_prefix.rstrip('/')}/{destination.release_prefix}/{seed_release_key}/iceberg/{table.table_name}"
        meta_loc = f"{destination.owned_prefix.rstrip('/')}/{destination.release_prefix}/{seed_release_key}/{rel_meta_key}"
        manifest_list = f"{table_loc}/metadata/snap-{seed_release_key[:16]}.avro"

    table_uuid = str(uuid5(NAMESPACE_URL, f"{catalog_id}:{table.table_name}"))
    snapshot_seed = {
        "table": table.table_name,
        "members": [{"remote_key": m.remote_key, "sha256": m.sha256, "size": m.size, "rows": m.rows} for m in table.members],
    }
    snapshot_id = int.from_bytes(sha256(_canonical_json_bytes(snapshot_seed)).digest()[:8], "big") & ((1 << 63) - 1)
    if snapshot_id == 0:
        snapshot_id = 1
    total_rows = sum(m.rows for m in table.members)
    return synthesize_iceberg_v2_snapshot(
        table_name=table.table_name,
        properties=schema_obj.get("properties") or (),
        table_location=table_loc,
        metadata_location=meta_loc,
        table_uuid=table_uuid,
        snapshot_id=snapshot_id,
        timestamp_ms=timestamp_ms,
        manifest_list=manifest_list,
        partition_keys=table.partition_keys,
        summary={
            "operation": "append",
            "total-records": str(total_rows),
            "total-data-files": str(len(table.members)),
            "ddk.external-custody": "immutable-zero-copy",
        },
        remote_rel_key=rel_meta_key,
        include_bytes=True,
        default_integer=table.default_integer,
    )


def build_external_generation_bundle(
    *,
    descriptor: Mapping[str, Any] | Path | str | None = None,
    tables: Sequence[ExternalTableSpec] | None = None,
    destination: RemoteDestination,
    output_dir: Path | str,
    bundle_dir: Path | str | None = None,
    dataset: str | None = None,
    operation: str | None = None,
    expected_pointer: ExpectedPointer | None = None,
    expected_prior_release_id: Any = ...,
    catalog_id: str | None = None,
    project_id: str | None = None,
    version: str | None = None,
    authority: str | None = None,
    purpose: str = "shadow-read",
    observed_at: str | None = None,
    audience: str = "public",
    disclosure_policy: Path | str | Mapping[str, Any] | None = None,
    relationships: Sequence[Mapping[str, Any]] = (),
    product: Mapping[str, Any] | None = None,
    exports: Sequence[str] = ("dcat", "graph"),
    verify_schema_parity: bool = True,
    schema_profile: str | None = None,
    normalize_arrow_encodings: bool = False,
    check_column_order: bool = True,
    synthesize_iceberg: bool = True,
    storage: Any | None = None,
    local_parquet_paths: Mapping[str, Path | str] | None = None,
    base_url: str | None = None,
    key_template: str | None = None,
    allow_insecure_http: bool = False,
    user_agent: str | None = None,
    compact_pointer: bool = True,
    epoch: int = 1,
    selection_revision: int = 1,
) -> ExternalGenerationBundle:
    """Assemble a verified DDK catalog + Iceberg v2 + remote publication bundle over existing immutable Parquet objects.

    Zero Parquet payloads are copied or uploaded: ``catalog.ddk.json``, ``catalog.lock.json``,
    ``discovery.graph.jsonld``, Iceberg v2 snapshots, ``release.manifest.json``, and ``current.json``
    pin directly to the pre-existing immutable Parquet keys/URLs.
    """
    from .catalog import assemble_catalog

    _need(isinstance(destination, RemoteDestination), "destination must be a RemoteDestination")
    _need(audience in {"public", "local"}, f"audience must be 'public' or 'local', got {audience!r}")
    has_explicit_exp_ptr = (expected_pointer is not None) or (expected_prior_release_id is not ...)
    if expected_pointer is not None:
        _need(isinstance(expected_pointer, ExpectedPointer), "expected_pointer must be an ExpectedPointer")
        if expected_prior_release_id is None and expected_pointer.kind != "absent":
            raise CatalogError(
                "CATALOG-REMOTE-CONFLICT",
                "Conflicting CAS preconditions: expected_prior_release_id=None disagrees with present ExpectedPointer",
            )
        if isinstance(expected_prior_release_id, str) and expected_pointer.kind != "present":
            raise CatalogError(
                "CATALOG-REMOTE-CONFLICT",
                f"Conflicting CAS preconditions: expected_prior_release_id={expected_prior_release_id!r} disagrees with absent ExpectedPointer",
            )
    elif expected_prior_release_id is None:
        expected_pointer = ExpectedPointer.absent()
    elif expected_prior_release_id is not ...:
        _need(isinstance(expected_prior_release_id, str) and bool(expected_prior_release_id),
              f"expected_prior_release_id must be a nonempty string or None, got {expected_prior_release_id!r}")
        if storage is not None:
            live_bytes, live_etag = _check_live_pointer_cas(
                storage,
                destination.pointer_key,
                expected_prior_release_id=expected_prior_release_id,
            )
            _need(isinstance(live_etag, str) and bool(live_etag),
                  f"Existing {destination.pointer_key!r} lacks ETag required for CAS ExpectedPointer")
            expected_pointer = ExpectedPointer.present(live_etag, sha256(live_bytes).hexdigest(), len(live_bytes))
        else:
            expected_pointer = ExpectedPointer.absent()
    else:
        expected_pointer = ExpectedPointer.absent()

    parsed_desc: dict[str, Any] = {}
    if descriptor is not None:
        parsed_desc = normalize_external_generation_descriptor(
            descriptor,
            base_url=base_url or destination.properties.get("public_base_url"),
            key_template=key_template,
            allow_insecure_http=allow_insecure_http,
        )
    resolved_tables: tuple[ExternalTableSpec, ...] = tuple(tables) if tables is not None else parsed_desc.get("tables", ())
    _need(bool(resolved_tables), "build_external_generation_bundle requires at least one external table")
    if schema_profile is not None or normalize_arrow_encodings or not check_column_order:
        resolved_tables = tuple(
            ExternalTableSpec(
                table_name=t.table_name,
                contract=t.contract,
                members=t.members,
                partition_keys=t.partition_keys,
                contract_object=t.contract_object,
                catalog_id=t.catalog_id,
                title=t.title,
                description=t.description,
                withheld_columns=t.withheld_columns,
                iceberg_snapshot=t.iceberg_snapshot,
                default_integer=t.default_integer,
                schema_profile=t.schema_profile if t.schema_profile is not None else schema_profile,
                normalize_arrow_encodings=t.normalize_arrow_encodings or normalize_arrow_encodings,
                check_column_order=t.check_column_order and check_column_order,
            )
            for t in resolved_tables
        )

    eff_dataset = dataset or parsed_desc.get("dataset") or "external-catalog"
    eff_version = version or parsed_desc.get("version") or "1.0.0"
    eff_catalog_id = catalog_id or parsed_desc.get("catalog_id") or f"urn:ddk:catalog:{_normalize_dataset_alias(eff_dataset)}"
    eff_project_id = project_id or parsed_desc.get("project_id") or f"urn:ddk:project:{_normalize_dataset_alias(eff_dataset)}"
    eff_authority = authority or parsed_desc.get("authority") or f"urn:ddk:authority:{_normalize_dataset_alias(eff_dataset)}"
    eff_purpose = parsed_desc.get("purpose") or purpose
    eff_observed_at = observed_at or parsed_desc.get("observed_at") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    eff_relationships = list(relationships or parsed_desc.get("relationships") or ())
    eff_product = product or parsed_desc.get("product")
    eff_public_base = (base_url or parsed_desc.get("base_url") or destination.properties.get("public_base_url") or "").rstrip("/") or None

    # Validate unique table names & normalized aliases
    alias_by_table: dict[str, str] = {}
    seen_aliases: set[str] = set()
    for t in resolved_tables:
        _need(t.table_name not in alias_by_table, f"Duplicate external table_name {t.table_name!r}")
        alias = _normalize_dataset_alias(t.table_name)
        _need(alias not in seen_aliases, f"Table {t.table_name!r} collides on normalized alias {alias!r}")
        seen_aliases.add(alias)
        alias_by_table[t.table_name] = alias

    # Resolve public URLs for every member and verify schema parity before building catalog
    resolved_member_urls: dict[tuple[str, str], str] = {}
    schema_objs: dict[str, tuple[dict[str, Any], dict[str, Any] | None]] = {}
    parity_reports: list[dict[str, Any]] = []
    local_paths = dict(local_parquet_paths or {})

    for t in resolved_tables:
        schema_obj, contract_doc = _extract_odcs_schema_object(
            t.contract, table_name=t.contract_object or t.table_name,
        )
        schema_objs[t.table_name] = (schema_obj, contract_doc)
        for m in t.members:
            url = m.url or (f"{eff_public_base}/{m.remote_key.lstrip('/')}" if eff_public_base else None)
            if url is not None and url.startswith(("http://", "https://")):
                url = _validate_external_http_url(url, allow_insecure_http=allow_insecure_http)
            if url is None:
                url = f"{destination.owned_prefix.rstrip('/')}/{m.remote_key.lstrip('/')}"
            resolved_member_urls[(t.table_name, m.remote_key)] = url

            if verify_schema_parity:
                if m.remote_key in local_paths:
                    pq_src = Path(local_paths[m.remote_key])
                    r_storage = None
                    r_key = None
                elif storage is not None:
                    pq_src = m.remote_key
                    r_storage = storage
                    r_key = m.remote_key
                else:
                    _need(url.startswith(("http://", "https://")),
                          f"Schema parity requires storage, local_parquet_paths, or HTTP(S) URL for {m.remote_key!r}")
                    pq_src = url
                    r_storage = None
                    r_key = None
                parity = verify_parquet_schema_parity(
                    pq_src,
                    schema_obj,
                    table_name=t.table_name,
                    profile=t.schema_profile,
                    storage=r_storage,
                    remote_key=r_key,
                    expected_size=m.size,
                    expected_footer_sha256=m.footer_sha256,
                    allow_insecure_http=allow_insecure_http,
                    user_agent=user_agent,
                    normalize_arrow_encodings=t.normalize_arrow_encodings,
                    check_column_order=t.check_column_order,
                )
                parity_reports.append({"remote_key": m.remote_key, **parity})

    # Compute deterministic generation seed before assembling Iceberg metadata + catalog.
    # Commit to every release-shaping input so release_id=seed_hex avoids hash cycles while
    # matching Iceberg metadataLocation == f"{public_base}/{remote_key}" identically.
    eff_exports = tuple(dict.fromkeys(exports))
    policy_digest: str | None = None
    if disclosure_policy is not None:
        if isinstance(disclosure_policy, Mapping):
            policy_digest = sha256(_canonical_json_bytes(dict(disclosure_policy))).hexdigest()
        else:
            policy_digest = sha256(Path(disclosure_policy).resolve().read_bytes()).hexdigest()

    seed_basis = []
    for t in resolved_tables:
        schema_obj, contract_doc = schema_objs[t.table_name]
        contract_digest = sha256(
            _canonical_json_bytes(contract_doc if contract_doc is not None else schema_obj)
        ).hexdigest()
        seed_basis.append({
            "table_name": t.table_name,
            "alias": alias_by_table[t.table_name],
            "catalog_id": t.catalog_id,
            "contract_object": t.contract_object,
            "contract_sha256": contract_digest,
            "partition_keys": list(t.partition_keys),
            "withheld_columns": list(t.withheld_columns),
            "default_integer": t.default_integer,
            **({"iceberg_snapshot": t.iceberg_snapshot.to_manifest_dict()} if t.iceberg_snapshot is not None else {}),
            "members": [
                {
                    "remote_key": m.remote_key,
                    "url": resolved_member_urls[(t.table_name, m.remote_key)],
                    "sha256": m.sha256,
                    "size": m.size,
                    "rows": m.rows,
                    **({"blake3": m.blake3} if m.blake3 else {}),
                    **({"md5": m.md5} if m.md5 else {}),
                    **({"footer_sha256": m.footer_sha256} if m.footer_sha256 else {}),
                    "partition_values": dict(m.partition_values),
                    "output_name": m.output_name,
                    "content_type": m.content_type,
                }
                for m in t.members
            ],
        })
    seed_payload = {
        "dataset": eff_dataset,
        "catalog_id": eff_catalog_id,
        "project_id": eff_project_id,
        "version": eff_version,
        "authority": eff_authority,
        "purpose": eff_purpose,
        "observed_at": eff_observed_at,
        "audience": audience,
        "exports": list(eff_exports),
        "relationships": eff_relationships,
        "product": dict(eff_product) if isinstance(eff_product, Mapping) else eff_product,
        "source_release_id": parsed_desc.get("source_release_id"),
        "disclosure_policy_sha256": policy_digest,
        "synthesize_iceberg": synthesize_iceberg,
        "owned_prefix": destination.owned_prefix,
        "release_prefix": destination.release_prefix,
        "pointer_key": destination.pointer_key,
        "public_base_url": destination.properties.get("public_base_url"),
        "epoch": epoch,
        "selection_revision": selection_revision,
        **({"operation": operation} if operation is not None else {}),
        "tables": seed_basis,
    }
    seed_hex = sha256(_canonical_json_bytes(seed_payload)).hexdigest()
    eff_operation = operation or f"external-{seed_hex[:16]}"
    ts_ms = int(datetime.fromisoformat(eff_observed_at.replace("Z", "+00:00")).timestamp() * 1000)

    iceberg_specs: list[IcebergTableSnapshotSpec] = []
    iceberg_by_table: dict[str, IcebergTableSnapshotSpec] = {}
    for t in resolved_tables:
        if t.iceberg_snapshot is not None:
            snap = t.iceberg_snapshot
            if snap.table_name is None:
                snap = IcebergTableSnapshotSpec(
                    metadata_location=snap.metadata_location,
                    metadata_sha256=snap.metadata_sha256,
                    snapshot_id=snap.snapshot_id,
                    schema_id=snap.schema_id,
                    manifest_list=snap.manifest_list,
                    table_name=t.table_name,
                    table_uuid=snap.table_uuid,
                    metadata_bytes=snap.metadata_bytes,
                    remote_rel_key=snap.remote_rel_key,
                )
            iceberg_specs.append(snap)
            iceberg_by_table[t.table_name] = snap
        elif synthesize_iceberg:
            schema_obj, _ = schema_objs[t.table_name]
            snap = _default_iceberg_snapshot_for_table(
                t,
                schema_obj,
                catalog_id=eff_catalog_id,
                destination=destination,
                seed_release_key=seed_hex,
                timestamp_ms=ts_ms,
                audience=audience,
            )
            iceberg_specs.append(snap)
            iceberg_by_table[t.table_name] = snap

    cat_dir = Path(output_dir).resolve()
    cat_dir.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="ddk-ext-bridge-") as tmp_dir:
        stage = Path(tmp_dir)
        contracts_dir = stage / "contracts"
        contracts_dir.mkdir(parents=True, exist_ok=True)

        artifacts_cfg: dict[str, Any] = {}
        output_ports: list[dict[str, Any]] = []
        catalog_ports: list[dict[str, Any]] = []
        dataset_ids_by_alias: dict[str, str] = {}

        for t in resolved_tables:
            alias = alias_by_table[t.table_name]
            schema_obj, contract_doc = schema_objs[t.table_name]
            contract_id = (
                contract_doc.get("id")
                if isinstance(contract_doc, Mapping) and isinstance(contract_doc.get("id"), str)
                else f"urn:ddk:contract:{alias}"
            )
            contract_version = (
                contract_doc.get("version")
                if isinstance(contract_doc, Mapping) and isinstance(contract_doc.get("version"), str)
                else eff_version
            )
            full_contract = (
                deepcopy(contract_doc)
                if contract_doc is not None
                else {
                    "apiVersion": "v3.2.0",
                    "kind": "DataContract",
                    "id": contract_id,
                    "version": contract_version,
                    "status": "active",
                    "schema": [schema_obj],
                }
            )
            contract_rel = f"contracts/{alias}.odcs.json"
            (stage / contract_rel).write_text(json_dumps(full_contract) + "\n", encoding="utf-8")

            ds_catalog_id = t.catalog_id or f"urn:ddk:dataset:{alias}"
            dataset_ids_by_alias[alias] = ds_catalog_id
            artifacts_cfg[alias] = {
                "kind": "dataset",
                "path": contract_rel,
                "object": schema_obj["name"],
                "catalogId": ds_catalog_id,
                "role": "source_record",
                "origin": "publisher",
            }
            output_ports.append({
                "name": alias,
                "version": contract_version,
                "contractId": contract_id,
            })
            catalog_ports.append({
                "product": "product",
                "direction": "output",
                "port": alias,
                "version": contract_version,
                "dataset": alias,
            })

        product_id = (
            eff_product.get("id")
            if isinstance(eff_product, Mapping) and isinstance(eff_product.get("id"), str)
            else f"urn:ddk:product:{_normalize_dataset_alias(eff_dataset)}"
        )
        product_doc = (
            deepcopy(dict(eff_product))
            if eff_product is not None
            else {
                "apiVersion": "v1.1.0",
                "kind": "DataProduct",
                "id": product_id,
                "version": eff_version,
                "name": eff_dataset,
                "status": "active",
                "outputPorts": output_ports,
            }
        )
        (stage / "product.odps.json").write_text(json_dumps(product_doc) + "\n", encoding="utf-8")
        artifacts_cfg["product"] = {"kind": "product", "path": "product.odps.json"}

        project_doc: dict[str, Any] = {
            "specVersion": "0.1",
            "kind": "project",
            "id": eff_project_id,
            "version": eff_version,
            "artifacts": artifacts_cfg,
            "imports": {},
            "requiredChecks": ["core.documents", "core.references", "core.datasets", "core.policies"],
            "catalog": {
                "id": eff_catalog_id,
                "ports": catalog_ports,
                **({"relationships": eff_relationships} if eff_relationships else {}),
            },
        }
        project_path = stage / "project.ddk.json"
        project_path.write_text(json_dumps(project_doc) + "\n", encoding="utf-8")

        meta_path = stage / "metadata.json"
        meta_rec = {"uri": f"urn:ddk:external-metadata:{seed_hex}"}
        meta_versions: list[dict[str, Any]] = []
        meta_representations: list[dict[str, Any]] = []
        version_ids: list[str] = []
        rep_ids: list[str] = []
        granted_locations: list[str] = []

        for t in resolved_tables:
            alias = alias_by_table[t.table_name]
            total_size = sum(m.size for m in t.members)
            total_rows = sum(m.rows for m in t.members)
            single = len(t.members) == 1
            if single:
                m0 = t.members[0]
                loc = resolved_member_urls[(t.table_name, m0.remote_key)]
                ver_digest = m0.sha256
                ref_val: dict[str, Any] = {
                    "location": loc,
                    "sha256": m0.sha256,
                    "remoteKey": m0.remote_key,
                    **({"footerSha256": m0.footer_sha256} if m0.footer_sha256 else {}),
                }
            else:
                # Multi-shard external table: bind manifest digest of shard inventory
                shard_inv = [[m.remote_key, m.sha256, m.size, m.rows] for m in t.members]
                ver_digest = sha256(_canonical_json_bytes(shard_inv)).hexdigest()
                loc = eff_public_base or destination.owned_prefix
                ref_val = {"location": loc, "sha256": ver_digest}

            granted_locations.append(loc)
            ver_id = f"urn:ddk:version:external:{alias}:{ver_digest[:16]}"
            rep_id = f"urn:ddk:rep:external:{alias}:{ver_digest[:16]}"
            version_ids.append(ver_id)
            rep_ids.append(rep_id)
            meta_versions.append({
                "id": ver_id,
                "dataset": alias,
                "reference": {
                    "scheme": "urn:ddk:version:external-parquet-sha256",
                    "authority": eff_authority,
                    "value": ref_val,
                },
                "retention": "present",
                "scope": f"External immutable Parquet generation for {t.table_name}",
                "record": meta_rec,
                "sources": [],
            })
            rep_entry: dict[str, Any] = {
                "id": rep_id,
                "version": ver_id,
                "kind": "table" if t.table_name in iceberg_by_table else "file",
                "availability": "available",
                "location": loc,
                "mediaType": PARQUET_CONTENT_TYPE,
                "byteSize": total_size,
                "rowCount": total_rows,
                "record": meta_rec,
            }
            if single and t.members[0].footer_sha256:
                rep_entry["footerSha256"] = t.members[0].footer_sha256
            if not single:
                rep_entry["members"] = [
                    {
                        "path": resolved_member_urls[(t.table_name, m.remote_key)],
                        "sha256": m.sha256,
                        "byteSize": m.size,
                        "rowCount": m.rows,
                        **({"footerSha256": m.footer_sha256} if m.footer_sha256 else {}),
                    }
                    for m in t.members
                ]
            if t.table_name in iceberg_by_table:
                rep_entry["icebergSnapshot"] = iceberg_by_table[t.table_name].to_catalog_dict()
            meta_representations.append(rep_entry)

        ext_release_id = f"urn:ddk:release:external:{seed_hex[:24]}"
        metadata_doc = {
            "versions": meta_versions,
            "representations": meta_representations,
            "releases": [{
                "id": ext_release_id,
                "reference": {
                    "scheme": "urn:ddk:external-release",
                    "authority": eff_authority,
                    "value": parsed_desc.get("source_release_id") or seed_hex,
                },
                "members": sorted(version_ids),
                "membership": "complete",
                "record": meta_rec,
            }],
            "selections": [{
                "authority": eff_authority,
                "purpose": eff_purpose,
                "release": ext_release_id,
                "observedAt": eff_observed_at,
                "record": meta_rec,
            }],
        }
        meta_path.write_text(json_dumps(metadata_doc) + "\n", encoding="utf-8")

        policy_path: Path | None = None
        if disclosure_policy is not None:
            if isinstance(disclosure_policy, Mapping):
                policy_path = stage / "disclosure.policy.json"
                policy_path.write_text(json_dumps(dict(disclosure_policy)) + "\n", encoding="utf-8")
            else:
                policy_path = Path(disclosure_policy).resolve()
        elif audience == "public":
            # Synthesize an explicit public disclosure policy granting only disclosed columns & HTTPS locations
            disclosed_defs: dict[str, list[list[dict[str, str]]]] = {}
            extra_aliases: set[str] = set()
            extra_ids: set[str] = set()
            for t in resolved_tables:
                alias = alias_by_table[t.table_name]
                schema_obj, contract_doc = schema_objs[t.table_name]
                extra_aliases.update((alias, schema_obj["name"]))
                if isinstance(contract_doc, Mapping) and isinstance(contract_doc.get("id"), str):
                    extra_ids.add(contract_doc["id"])
                else:
                    extra_ids.add(f"urn:ddk:contract:{alias}")
                withheld = set(t.withheld_columns)
                disclosed_defs[dataset_ids_by_alias[alias]] = [
                    [{"field": prop["name"]}]
                    for prop in (schema_obj.get("properties") or ())
                    if isinstance(prop, Mapping) and isinstance(prop.get("name"), str)
                    and prop["name"] not in withheld
                ]
            for rel in eff_relationships:
                if isinstance(rel, Mapping) and isinstance(rel.get("id"), str):
                    extra_ids.add(rel["id"])
            policy_doc = {
                "identifiers": sorted({
                    eff_catalog_id,
                    eff_project_id,
                    product_id,
                    eff_authority,
                    ext_release_id,
                    *dataset_ids_by_alias.values(),
                    *version_ids,
                    *rep_ids,
                    *extra_ids,
                }),
                "aliases": sorted(extra_aliases),
                "locations": sorted(set(granted_locations)),
                "nativeReferences": sorted({*version_ids, ext_release_id}),
                "definitionFields": disclosed_defs,
                "descriptions": True,
            }
            policy_path = stage / "disclosure.policy.json"
            policy_path.write_text(json_dumps(policy_doc) + "\n", encoding="utf-8")

        has_selection_export = bool({"dcat", "graph", "catalog.dcat", "catalog.graph", "rml", "catalog.rml"} & set(eff_exports))
        assembled = assemble_catalog(
            project_path,
            metadata=meta_path,
            metadata_adapter="local",
            exports=eff_exports,
            output=cat_dir,
            current_selection=(eff_authority, eff_purpose) if has_selection_export else None,
            audience=audience,
            disclosure_policy=policy_path,
            permitted_roots=(stage, *( (policy_path.parent,) if policy_path is not None else () )),
        )
        _need(
            assembled.report.get("decision") == "passed",
            f"External-generation catalog assembly failed: {json_dumps(assembled.report)}",
        )

    if iceberg_specs:
        orig_lock_bytes = (cat_dir / "catalog.lock.json").read_bytes()
        bound_lock_bytes = bind_iceberg_snapshots_to_lock(orig_lock_bytes, iceberg_specs)
        (cat_dir / "catalog.lock.json").write_bytes(bound_lock_bytes)

    frozen_release = export_frozen_catalog_release(cat_dir)

    completed_outputs: dict[str, dict[str, Any]] = {}
    logical_tables: list[LogicalTableSpec] = []
    for t in resolved_tables:
        member_specs: list[LogicalTableMemberSpec] = []
        for idx, m in enumerate(t.members):
            out_name = m.output_name or (t.table_name if len(t.members) == 1 else f"{t.table_name}__{idx}")
            _need(out_name not in completed_outputs, f"Duplicate external output_name {out_name!r}")
            completed_outputs[out_name] = {
                "sha256": m.sha256,
                "size": m.size,
                "rows": m.rows,
                **({"blake3": m.blake3} if m.blake3 else {}),
                **({"md5": m.md5} if m.md5 else {}),
            }
            resolved_url = resolved_member_urls[(t.table_name, m.remote_key)]
            member_specs.append(
                LogicalTableMemberSpec(
                    output_name=out_name,
                    partition_values=m.partition_values,
                    remote_rel_key=m.remote_key,
                    content_type=m.content_type,
                    external_url=resolved_url if resolved_url.startswith(("http://", "https://")) else None,
                    preserve_remote_key=True,
                    footer_sha256=m.footer_sha256,
                    allow_insecure_http=allow_insecure_http,
                )
            )
        logical_tables.append(
            LogicalTableSpec(
                table_name=t.table_name,
                partition_keys=t.partition_keys,
                members=tuple(member_specs),
                iceberg_snapshot=iceberg_by_table.get(t.table_name),
            )
        )

    job_inputs = {
        "dataset": eff_dataset,
        "operation": eff_operation,
        "expected_epoch": epoch,
        "expected_selection_revision": selection_revision,
        "job_request_digest": seed_hex,
        "policy_id": "urn:ddk:policy:external-generation-bridge:1",
        "candidate": {"manifest": {"digest": seed_hex}},
        "accepted_qualification": {"status": "passed", "mode": "external-generation-bridge"},
        "completed_outputs": completed_outputs,
    }
    plan = build_remote_publication_plan(
        job_inputs=job_inputs,
        catalog_release=frozen_release,
        logical_tables=logical_tables,
        destination=destination,
        operation=eff_operation,
        expected_pointer=expected_pointer,
        release_id=seed_hex,
        compact_pointer=compact_pointer,
    )

    if bundle_dir is not None:
        bdir = Path(bundle_dir).resolve()
        bdir.mkdir(parents=True, exist_ok=True)
        (bdir / "current.json").write_bytes(plan.pointer_bytes)
        (bdir / "release.manifest.json").write_bytes(plan.manifest_bytes)
        for snap in iceberg_specs:
            if snap.metadata_bytes is not None and snap.remote_rel_key:
                snap_path = bdir / snap.remote_rel_key
                snap_path.parent.mkdir(parents=True, exist_ok=True)
                snap_path.write_bytes(snap.metadata_bytes)

    return ExternalGenerationBundle(
        release_id=plan.release_id,
        dataset=eff_dataset,
        operation=eff_operation,
        destination=destination,
        catalog_dir=cat_dir,
        catalog_release=frozen_release,
        plan=plan,
        tables=resolved_tables,
        iceberg_snapshots=tuple(iceberg_specs),
        schema_parity=tuple(parity_reports),
        lock_sha256=frozen_release.lock_sha256,
        catalog_sha256=frozen_release.catalog_sha256,
        expected_prior_release_id=expected_prior_release_id,
        has_explicit_expected_pointer=has_explicit_exp_ptr,
    )


def _check_live_pointer_cas(
    storage: Any,
    pointer_key: str,
    *,
    expected_pointer: ExpectedPointer | None = None,
    expected_prior_release_id: Any = ...,
) -> tuple[bytes | None, str | None]:
    """Read live CAS pointer and enforce expected_prior_release_id / ExpectedPointer preconditions."""
    try:
        head = storage.head_object(pointer_key)
        live_bytes = storage.get_bytes(pointer_key)
        live_etag = head.get("etag")
    except CatalogError as exc:
        if exc.code == "CATALOG-OBJECT-MISSING":
            live_bytes, live_etag = None, None
        else:
            raise

    if expected_prior_release_id is not ...:
        if expected_prior_release_id is None:
            if live_bytes is not None:
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: {pointer_key!r} already exists while expected_prior_release_id is None",
                )
        else:
            if live_bytes is None:
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: {pointer_key!r} is absent while expected_prior_release_id={expected_prior_release_id!r}",
                )
            live_doc = parse_json(live_bytes)
            live_rel = live_doc.get("release_id") if isinstance(live_doc, dict) else None
            if live_rel != expected_prior_release_id:
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: live release_id {live_rel!r} differs from expected {expected_prior_release_id!r}",
                )

    if expected_pointer is not None:
        if expected_pointer.kind == "absent":
            if live_bytes is not None:
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: {pointer_key!r} already exists",
                )
        elif expected_pointer.kind == "present":
            if live_bytes is None:
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: {pointer_key!r} is absent",
                )
            if (_norm_etag(live_etag) != _norm_etag(expected_pointer.etag)
                    or len(live_bytes) != expected_pointer.size
                    or sha256(live_bytes).hexdigest() != expected_pointer.sha256):
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"CAS precondition failed: live {pointer_key!r} disagrees with expected_pointer",
                )

    return live_bytes, live_etag


def _resolve_cas_preconditions(
    plan: RemotePublicationPlan,
    bundle: ExternalGenerationBundle | None,
    expected_prior_release_id: Any,
) -> tuple[ExpectedPointer | None, Any]:
    """Reconcile ExpectedPointer and expected_prior_release_id without silently dropping either precondition."""
    expected_ptr_cfg = plan.publish_command["expected_pointer"]
    exp_ptr = (
        ExpectedPointer.absent()
        if expected_ptr_cfg["kind"] == "absent"
        else ExpectedPointer.present(expected_ptr_cfg["etag"], expected_ptr_cfg["sha256"], expected_ptr_cfg["size"])
    )
    bundle_prior = bundle.expected_prior_release_id if bundle is not None else ...
    if bundle_prior is not ... and expected_prior_release_id is not ... and expected_prior_release_id != bundle_prior:
        raise CatalogError(
            "CATALOG-REMOTE-CONFLICT",
            f"Conflicting CAS preconditions: caller expected_prior_release_id={expected_prior_release_id!r} disagrees with bundle {bundle_prior!r}",
        )
    eff_prior = bundle_prior if expected_prior_release_id is ... else expected_prior_release_id

    if bundle is None:
        return exp_ptr, eff_prior

    if exp_ptr.kind == "present":
        if eff_prior is None:
            raise CatalogError(
                "CATALOG-REMOTE-CONFLICT",
                "Conflicting CAS preconditions: present ExpectedPointer disagrees with expected_prior_release_id=None",
            )
        return exp_ptr, eff_prior

    # exp_ptr.kind == "absent"
    if bundle.has_explicit_expected_pointer:
        if bundle.expected_prior_release_id is None:
            if isinstance(eff_prior, str):
                raise CatalogError(
                    "CATALOG-REMOTE-CONFLICT",
                    f"Conflicting CAS preconditions: absent ExpectedPointer disagrees with expected_prior_release_id={eff_prior!r}",
                )
            return exp_ptr, eff_prior
        # Bundle had a string expected_prior_release_id resolved offline without storage
        return None, eff_prior

    if eff_prior is not ...:
        return (exp_ptr if eff_prior is None else None), eff_prior
    return exp_ptr, ...


def _build_anonymous_http_fetcher(
    public_base_url: str,
    *,
    allow_insecure_http: bool = False,
    timeout: float = 15.0,
    user_agent: str | None = None,
):
    clean_base = _validate_external_http_url(
        public_base_url,
        allow_insecure_http=allow_insecure_http,
        allow_query=False,
    ).rstrip("/")
    eff_user_agent = (user_agent or "").strip() or DEFAULT_HTTP_USER_AGENT

    def _fetch(rel_key: str) -> tuple[bytes, str | None]:
        clean_rel = rel_key.lstrip("/")
        _safe_rel_path(clean_rel, allow_equals=True)
        base_with_slash = clean_base + "/"
        url = urljoin(base_with_slash, clean_rel)
        _need(url.startswith(base_with_slash), f"Resolved URL {url!r} escaped base {clean_base!r}")
        return _no_redirect_http_get(
            url,
            allow_insecure_http=allow_insecure_http,
            timeout=timeout,
            user_agent=eff_user_agent,
        )

    def _fetch_url(full_url: str) -> tuple[bytes, str | None]:
        return _no_redirect_http_get(
            full_url,
            allow_insecure_http=allow_insecure_http,
            timeout=timeout,
            user_agent=eff_user_agent,
        )

    setattr(_fetch, "fetch_url", _fetch_url)
    setattr(_fetch, "user_agent", eff_user_agent)
    return _fetch


def _verify_bundle_tables_schema_parity(
    bundle: ExternalGenerationBundle,
    *,
    storage: Any,
    allow_insecure_http: bool = False,
    normalize_arrow_encodings: bool = False,
    check_column_order: bool = True,
) -> list[dict[str, Any]]:
    """Verify Parquet schema parity for all tables/members in an ``ExternalGenerationBundle``."""
    schemas_by_table = {
        t.table_name: _extract_odcs_schema_object(t.contract, table_name=t.contract_object or t.table_name)[0]
        for t in bundle.tables
    }
    parity_results: list[dict[str, Any]] = []
    for t in bundle.tables:
        for m in t.members:
            parity_results.append(
                verify_parquet_schema_parity(
                    m.remote_key,
                    schemas_by_table[t.table_name],
                    table_name=t.table_name,
                    profile=t.schema_profile,
                    storage=storage,
                    remote_key=m.remote_key,
                    expected_size=m.size,
                    expected_footer_sha256=m.footer_sha256,
                    allow_insecure_http=allow_insecure_http,
                    normalize_arrow_encodings=t.normalize_arrow_encodings or normalize_arrow_encodings,
                    check_column_order=t.check_column_order and check_column_order,
                )
            )
    return parity_results


class DryRunObjectStore:
    """Credential-free scratch disk store simulating S3/R2 conditional CAS writes for dry runs."""

    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._objects: dict[str, dict[str, Any]] = {}
        self._calls: list[dict[str, Any]] = []
        self._seq = 0

    def _next_etag(self) -> str:
        self._seq += 1
        return f'"dryrun-etag-{self._seq}"'

    def _resolve_key_path(self, remote_key: str) -> Path:
        _safe_rel_path(remote_key, allow_equals=True)
        target = (self.root / PurePosixPath(remote_key)).resolve()
        try:
            target.relative_to(self.root)
        except ValueError as exc:
            raise CatalogError("CATALOG-PUBLICATION", f"Dry-run key escapes scratch root: {remote_key!r}") from exc
        return target

    @property
    def calls(self) -> tuple[dict[str, Any], ...]:
        return tuple(dict(entry) for entry in self._calls)

    def seed(
        self,
        remote_key: str,
        data: bytes,
        *,
        etag: str | None = None,
        content_type: str = "application/octet-stream",
        cache_control: str | None = None,
    ) -> dict[str, Any]:
        """Seed pre-existing state (e.g. a live CAS pointer) before recording publication writes."""
        raw = bytes(data)
        path = self._resolve_key_path(remote_key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        assigned_etag = etag or self._next_etag()
        meta = {
            "remote_key": remote_key,
            "path": path,
            "size": len(raw),
            "sha256": sha256(raw).hexdigest(),
            "etag": assigned_etag,
            "content_type": content_type,
            "cache_control": cache_control,
        }
        self._objects[remote_key] = meta
        self._calls.append({"method": "seed", "key": remote_key, "bytes": len(raw), "etag": assigned_etag})
        return dict(meta)

    def put(
        self,
        remote_key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        cache_control: str | None = None,
        if_none_match: bool = False,
        if_match: str | None = None,
    ) -> dict[str, Any]:
        """Write an object with S3/R2 ``If-None-Match`` / ``If-Match`` CAS semantics."""
        path = self._resolve_key_path(remote_key)
        existing = self._objects.get(remote_key)
        if if_none_match and existing is not None:
            raise CatalogError(
                "CATALOG-PUBLICATION-PRECONDITION",
                f"Dry-run CAS precondition failed for {remote_key!r}: expected absent, found ETag {existing['etag']!r}",
            )
        if if_match is not None:
            if existing is None or _norm_etag(if_match) != _norm_etag(existing["etag"]):
                raise CatalogError(
                    "CATALOG-PUBLICATION-PRECONDITION",
                    f"Dry-run CAS precondition failed for {remote_key!r}: expected ETag {if_match!r}, "
                    f"found {existing['etag'] if existing else None!r}",
                )
        raw = bytes(data)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        etag = self._next_etag()
        meta = {
            "remote_key": remote_key,
            "path": path,
            "size": len(raw),
            "sha256": sha256(raw).hexdigest(),
            "etag": etag,
            "content_type": content_type,
            "cache_control": cache_control,
        }
        self._objects[remote_key] = meta
        self._calls.append({"method": "put", "key": remote_key, "bytes": len(raw), "etag": etag})
        return dict(meta)

    def get(self, remote_key: str) -> tuple[bytes, str]:
        meta = self._objects.get(remote_key)
        if meta is None:
            raise FileNotFoundError(remote_key)
        return Path(meta["path"]).read_bytes(), str(meta["etag"])

    def fetch_object(self, remote_key: str) -> tuple[bytes, str]:
        return self.get(remote_key)

    def headers(self, remote_key: str) -> tuple[str, str | None] | None:
        meta = self._objects.get(remote_key)
        if meta is None:
            return None
        return str(meta["content_type"]), meta["cache_control"]


def _verify_expected_prior(
    live_pointer_bytes: bytes | None,
    live_pointer_etag: str | None,
    *,
    expected_prior_release_id: str | None = None,
    expected_prior_etag: str | None = None,
    expected_pointer_spec: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Refuse when the live CAS pointer disagrees with declared prior release or CAS preconditions."""
    if expected_pointer_spec is not None:
        kind = expected_pointer_spec.get("kind")
        if kind == "absent" and live_pointer_bytes is not None:
            raise CatalogError(
                "CATALOG-PUBLICATION-PRECONDITION",
                f"Expected absent live CAS pointer, but found live pointer with ETag {live_pointer_etag!r}",
            )
        if kind == "present":
            if live_pointer_bytes is None:
                raise CatalogError(
                    "CATALOG-PUBLICATION-PRECONDITION",
                    "Expected present live CAS pointer, but live pointer is absent",
                )
            exp_etag = expected_pointer_spec.get("etag")
            if exp_etag is not None and _norm_etag(live_pointer_etag) != _norm_etag(exp_etag):
                raise CatalogError(
                    "CATALOG-PUBLICATION-PRECONDITION",
                    f"Live CAS pointer ETag {live_pointer_etag!r} differs from plan precondition {exp_etag!r}",
                )
            live_sha = sha256(live_pointer_bytes).hexdigest()
            exp_sha = expected_pointer_spec.get("sha256")
            if exp_sha is not None and live_sha != exp_sha:
                raise CatalogError(
                    "CATALOG-PUBLICATION-PRECONDITION",
                    f"Live CAS pointer SHA-256 {live_sha!r} differs from plan precondition {exp_sha!r}",
                )
            exp_size = expected_pointer_spec.get("size")
            if exp_size is not None and len(live_pointer_bytes) != exp_size:
                raise CatalogError(
                    "CATALOG-PUBLICATION-PRECONDITION",
                    f"Live CAS pointer size {len(live_pointer_bytes)} differs from plan precondition {exp_size}",
                )

    live_doc = None
    live_release_id = None
    if live_pointer_bytes is not None:
        try:
            live_doc = parse_json(live_pointer_bytes)
        except Exception as exc:
            raise CatalogError("CATALOG-PUBLICATION-PRIOR", f"Live CAS pointer is invalid JSON: {exc}") from exc
        if isinstance(live_doc, Mapping) and isinstance(live_doc.get("release_id"), str):
            live_release_id = live_doc["release_id"]

    if expected_prior_release_id is not None:
        wanted = str(expected_prior_release_id).strip().lower().removeprefix("sha256:")
        if not re.fullmatch(r"[0-9a-f]{8,64}", wanted):
            raise CatalogError(
                "CATALOG-PUBLICATION-PRIOR",
                "expected_prior_release_id must be 8..64 lowercase hexadecimal characters",
            )
        if live_release_id is None or not live_release_id.lower().startswith(wanted):
            raise CatalogError(
                "CATALOG-PUBLICATION-PRIOR",
                f"Live release_id is {live_release_id or 'absent'}, not expected prior {wanted}; "
                "re-read live state before publishing",
            )

    if expected_prior_etag is not None:
        if live_pointer_bytes is None or _norm_etag(live_pointer_etag) != _norm_etag(expected_prior_etag):
            raise CatalogError(
                "CATALOG-PUBLICATION-PRIOR",
                f"Live ETag is {live_pointer_etag or 'absent'}, not expected prior {expected_prior_etag!r}",
            )

    if live_pointer_bytes is None:
        return None
    return {
        "release_id": live_release_id,
        "etag": live_pointer_etag,
        "sha256": sha256(live_pointer_bytes).hexdigest(),
        "size": len(live_pointer_bytes),
    }


def _try_resolve_plan_member_path(
    member_cmd: Mapping[str, Any],
    member_paths: Mapping[str, Path | str] | None,
) -> Path | None:
    output_name = str(member_cmd["output_name"])
    remote_key = str(member_cmd["remote_key"])
    if member_paths is not None:
        if output_name in member_paths:
            return Path(member_paths[output_name])
        if remote_key in member_paths:
            return Path(member_paths[remote_key])
    obj = member_cmd.get("object")
    if isinstance(obj, Mapping):
        cand = obj.get("path") or obj.get("locator")
        if isinstance(cand, (str, Path)) and Path(cand).is_file():
            return Path(cand)
    return None


def _resolve_plan_member_bytes(
    member_cmd: Mapping[str, Any],
    member_paths: Mapping[str, Path | str] | None = None,
) -> bytes:
    output_name = str(member_cmd["output_name"])
    path = _try_resolve_plan_member_path(member_cmd, member_paths)
    if path is None or not path.is_file():
        raise CatalogError(
            "CATALOG-PUBLICATION",
            f"Local Parquet member file missing for {output_name!r}; supply member_paths",
        )
    raw = path.read_bytes()
    if (
        len(raw) != member_cmd["size"]
        or sha256(raw).hexdigest() != member_cmd["sha256"]
        or (member_cmd.get("blake3") is not None and blake3(raw).hexdigest() != member_cmd["blake3"])
        or (member_cmd.get("md5") is not None and md5(raw).hexdigest() != member_cmd["md5"])
    ):
        raise CatalogError(
            "CATALOG-PUBLICATION",
            f"Local Parquet member {output_name!r} ({path}) failed digest/size verification against plan",
        )
    return raw


def _load_plan_catalog_artifact_bytes(art_cmd: Mapping[str, Any]) -> bytes:
    if "bytes_base64" in art_cmd:
        raw = base64.b64decode(art_cmd["bytes_base64"])
    elif "path" in art_cmd:
        raw = Path(art_cmd["path"]).read_bytes()
    else:
        raise CatalogError("CATALOG-PUBLICATION", f"Staged artifact {art_cmd.get('name')!r} lacks bytes or path")
    if (
        len(raw) != art_cmd["size"]
        or sha256(raw).hexdigest() != art_cmd["sha256"]
        or blake3(raw).hexdigest() != art_cmd["blake3"]
    ):
        raise CatalogError(
            "CATALOG-PUBLICATION",
            f"Staged artifact {art_cmd.get('name')!r} failed digest/size verification against plan",
        )
    return raw


def _extract_plan_lock_sha256(plan: RemotePublicationPlan) -> str:
    for art_cmd in plan.publish_command.get("catalog_artifacts", ()):
        if art_cmd.get("name") == "catalog.lock.json":
            return str(art_cmd["sha256"])
    raise CatalogError("CATALOG-PUBLICATION", "Publication plan is missing catalog.lock.json artifact")


def _write_receipt_once(receipt_out_dir: Path | str, filename: str, receipt: Mapping[str, Any]) -> None:
    out_dir = Path(receipt_out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / filename).write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _read_live_pointer_for_publish(
    pointer_key: str,
    *,
    fetch_public_object: Callable[[str], tuple[bytes, str | None]],
    fetch_live_pointer: Callable[[str], tuple[bytes, str | None] | None] | None,
) -> tuple[bytes | None, str | None]:
    if fetch_live_pointer is not None:
        fetched = fetch_live_pointer(pointer_key)
        if fetched is None:
            return None, None
        return bytes(fetched[0]), fetched[1]
    try:
        raw, etag = fetch_public_object(pointer_key)
        return bytes(raw), etag
    except (FileNotFoundError, KeyError):
        return None, None
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return None, None
        raise


def dry_run_remote_publication(
    plan_or_bundle: RemotePublicationPlan | ExternalGenerationBundle,
    *,
    storage: Any = None,
    destination: RemoteDestination | None = None,
    live_pointer_bytes: bytes | None = None,
    live_pointer_etag: str | None = None,
    fetch_live_pointer: Callable[[str], tuple[bytes, str | None] | None] | None = None,
    expected_prior_release_id: Any = ...,
    expected_prior_etag: str | None = None,
    member_paths: Mapping[str, Path | str] | None = None,
    declared_schemas: Mapping[str, Any] | None = None,
    schema_check_order: bool = True,
    schema_check_nullability: bool = False,
    verify_schema_parity: bool = True,
    verify_member_bytes: bool = True,
    receipt_out_dir: Path | None = None,
    allow_insecure_http: bool = False,
    normalize_arrow_encodings: bool = False,
    check_column_order: bool = True,
) -> dict[str, Any]:
    """Rehearse guarded publication against either an ``ObjectStoragePort`` or an isolated scratch disk store."""
    bundle = plan_or_bundle if isinstance(plan_or_bundle, ExternalGenerationBundle) else None
    plan = bundle.plan if bundle is not None else plan_or_bundle
    _need(isinstance(plan, RemotePublicationPlan), "Expected RemotePublicationPlan or ExternalGenerationBundle")

    if storage is not None:
        dest_cfg = plan.publish_command["destination"]
        pointer_key = dest_cfg["pointer_key"]
        use_exp_ptr, eff_prior = _resolve_cas_preconditions(plan, bundle, expected_prior_release_id)
        live_bytes, live_etag = _check_live_pointer_cas(
            storage,
            pointer_key,
            expected_pointer=use_exp_ptr,
            expected_prior_release_id=eff_prior,
        )

        parity_results: list[dict[str, Any]] = []
        if bundle is not None and verify_schema_parity:
            parity_results = _verify_bundle_tables_schema_parity(
                bundle,
                storage=storage,
                allow_insecure_http=allow_insecure_http,
                normalize_arrow_encodings=normalize_arrow_encodings,
                check_column_order=check_column_order,
            )

        external_set = set(plan.external_member_keys)
        parquet_referenced: list[str] = []
        for table in plan.publish_command["logical_tables"]:
            for member in table["members"]:
                rkey = member["remote_key"]
                _need(rkey in external_set,
                      f"Non-external Parquet upload {rkey!r} requires DocSpec RemotePublisher")
                head = storage.head_object(rkey)
                if isinstance(head.get("size"), int) and not isinstance(head.get("size"), bool) and head["size"] != member["size"]:
                    raise CatalogError(
                        "CATALOG-REMOTE-INTEGRITY",
                        f"Existing immutable Parquet object {rkey!r} size {head['size']} disagrees with expected {member['size']}",
                    )
                parquet_referenced.append(rkey)

        catalog_uploads: list[str] = []
        catalog_reused: list[str] = []
        for art in plan.publish_command["catalog_artifacts"]:
            rkey = art["remote_key"]
            try:
                head = storage.head_object(rkey)
                if head.get("size") == art["size"]:
                    catalog_reused.append(rkey)
                    continue
            except CatalogError as exc:
                if exc.code != "CATALOG-OBJECT-MISSING":
                    raise
            catalog_uploads.append(rkey)

        return {
            "action": "dry_run",
            "status": "ok",
            "release_id": plan.release_id,
            "pointer_key": pointer_key,
            "live_pointer_present": live_bytes is not None,
            "live_etag": live_etag,
            "expected_prior_release_id": None if expected_prior_release_id is ... else expected_prior_release_id,
            "catalog_uploads": catalog_uploads,
            "catalog_reused": catalog_reused,
            "parquet_uploads": [],
            "parquet_upload_count": 0,
            "parquet_referenced": parquet_referenced,
            "schema_parity": parity_results,
        }

    eff_destination = destination
    if eff_destination is None:
        raise CatalogError("CATALOG-PUBLICATION", "destination must be a RemoteDestination (or supply storage=)")
    _need(isinstance(eff_destination, RemoteDestination), "destination must be a RemoteDestination")
    if declared_schemas is not None and not verify_member_bytes:
        raise ValueError("verify_member_bytes=True is required when declared_schemas is supplied")
    if receipt_out_dir is not None and Path(receipt_out_dir).exists():
        raise CatalogError(
            "CATALOG-PUBLICATION",
            f"Dry-run receipt output directory already exists: {receipt_out_dir}",
        )

    eff_prior_id = None if expected_prior_release_id is ... else expected_prior_release_id
    if live_pointer_bytes is None and fetch_live_pointer is not None:
        fetched = fetch_live_pointer(eff_destination.pointer_key)
        if fetched is not None:
            live_pointer_bytes, live_pointer_etag = bytes(fetched[0]), fetched[1]

    prior_info = _verify_expected_prior(
        live_pointer_bytes,
        live_pointer_etag,
        expected_prior_release_id=eff_prior_id,
        expected_prior_etag=expected_prior_etag,
        expected_pointer_spec=plan.publish_command["expected_pointer"],
    )

    member_bytes_list: list[tuple[dict[str, Any], bytes]] = []
    member_bytes_by_table: dict[str, list[bytes]] = {}
    has_iceberg_only = False
    if verify_member_bytes:
        for table_cmd in plan.publish_command.get("logical_tables", ()):
            members = table_cmd.get("members", ())
            if not members:
                has_iceberg_only = True
                continue
            tbl_list = member_bytes_by_table.setdefault(table_cmd["table_name"], [])
            for member_cmd in members:
                raw = _resolve_plan_member_bytes(member_cmd, member_paths)
                member_bytes_list.append((member_cmd, raw))
                tbl_list.append(raw)

    pre_schema_parity = None
    if declared_schemas is not None:
        pre_schema_parity = verify_parquet_schema_parity(
            declared_schemas,
            member_bytes_by_table,
            check_order=schema_check_order and check_column_order,
            check_nullability=schema_check_nullability,
            allow_subset_tables=has_iceberg_only,
        )

    temp_parent = Path(receipt_out_dir).resolve().parent if receipt_out_dir is not None else None
    if temp_parent is not None:
        temp_parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=temp_parent, prefix=".ddk-dry-run-store-") as scratch:
        store = DryRunObjectStore(Path(scratch) / "store")
        if live_pointer_bytes is not None:
            store.seed(
                eff_destination.pointer_key,
                live_pointer_bytes,
                etag=live_pointer_etag,
                content_type=JSON_CONTENT_TYPE,
            )
        seed_count = len(store.calls)

        for art_cmd in plan.publish_command.get("catalog_artifacts", ()):
            raw_art = _load_plan_catalog_artifact_bytes(art_cmd)
            store.put(
                art_cmd["remote_key"],
                raw_art,
                content_type=art_cmd.get("content_type", JSON_CONTENT_TYPE),
                cache_control="public, max-age=31536000, immutable",
            )

        for member_cmd, raw_member in member_bytes_list:
            store.put(
                member_cmd["remote_key"],
                raw_member,
                content_type=member_cmd.get("content_type", PARQUET_CONTENT_TYPE),
                cache_control="public, max-age=31536000, immutable",
            )

        exp_ptr = plan.publish_command["expected_pointer"]
        ptr_cmd = plan.publish_command["pointer"]
        ptr_meta = store.put(
            eff_destination.pointer_key,
            plan.pointer_bytes,
            content_type=ptr_cmd.get("content_type", JSON_CONTENT_TYPE),
            cache_control=ptr_cmd.get("cache_control", DEFAULT_POINTER_CACHE_CONTROL),
            if_none_match=exp_ptr.get("kind") == "absent",
            if_match=exp_ptr.get("etag") if exp_ptr.get("kind") == "present" else None,
        )

        readback = verify_http_consumer_readback(
            store.fetch_object,
            eff_destination,
            expected_etag=ptr_meta["etag"],
            expected_release_id=plan.release_id,
            expected_lock_sha256=_extract_plan_lock_sha256(plan),
            verify_member_bytes=verify_member_bytes,
            allow_insecure_http=allow_insecure_http,
            declared_schemas=declared_schemas,
            schema_check_order=schema_check_order and check_column_order,
            schema_check_nullability=schema_check_nullability,
        )

        writes = store.calls[seed_count:]
        receipt = {
            "status": "dry_run_accepted",
            "observed_at": datetime.now(UTC).isoformat(),
            "release_id": plan.release_id,
            "dataset": plan.publish_command["dataset"],
            "operation": plan.publish_command["operation"],
            "pointer_key": eff_destination.pointer_key,
            "pointer_sha256": plan.pointer_sha256,
            "pointer_size": plan.pointer_size,
            "prior": prior_info,
            "schema_parity": readback.get("verified_schemas") or pre_schema_parity,
            "objects_written": len(writes),
            "bytes_written": sum(call["bytes"] for call in writes),
            "lock_sha256": readback["lock_sha256"],
            "verified_members": readback["verified_members"],
            "verified_iceberg_snapshots": readback["verified_iceberg_snapshots"],
            "readback_bytes": readback["public_bytes_read"],
        }

    if receipt_out_dir is not None:
        _write_receipt_once(receipt_out_dir, "dry-run.json", receipt)
    return receipt


def _decode_staged_artifact_bytes(entry: Mapping[str, Any]) -> bytes:
    if "bytes_base64" in entry:
        return base64.b64decode(entry["bytes_base64"])
    if "path" in entry:
        return Path(entry["path"]).read_bytes()
    raise CatalogError("CATALOG-PUBLICATION", f"Staged artifact {entry.get('name')!r} lacks bytes_base64 or path")


def publish_and_verify_remote_publication(
    plan_or_bundle: RemotePublicationPlan | ExternalGenerationBundle,
    *,
    storage: Any = None,
    destination: RemoteDestination | None = None,
    fetch_public_object: Callable[[str], tuple[bytes, str | None]] | None = None,
    publisher: RemotePublisher | None = None,
    publish_fn: Callable[[RemotePublicationPlan], Mapping[str, Any]] | None = None,
    fetch_live_pointer: Callable[[str], tuple[bytes, str | None] | None] | None = None,
    secret_env: Mapping[str, str] | None = None,
    expected_prior_release_id: Any = ...,
    expected_prior_etag: str | None = None,
    require_prior_when_live: bool = True,
    member_paths: Mapping[str, Path | str] | None = None,
    declared_schemas: Mapping[str, Any] | None = None,
    schema_check_order: bool = True,
    schema_check_nullability: bool = False,
    schema_readback_mode: str = "auto",
    anonymous_fetch: Any = None,
    verify_schema_parity: bool = True,
    verify_member_bytes: bool = True,
    run_native_readback: bool = True,
    cancel_event: Any = None,
    receipt_out_dir: Path | None = None,
    allow_insecure_http: bool = False,
    allow_authenticated_readback: bool = False,
    normalize_arrow_encodings: bool = False,
    check_column_order: bool = True,
    user_agent: str | None = None,
) -> dict[str, Any]:
    """Execute guarded CAS publication, enforce schema parity & anonymous HTTP readback before advancing current.json."""
    if schema_readback_mode not in {"auto", "full", "range"}:
        raise ValueError(
            f"schema_readback_mode must be 'auto', 'full', or 'range', got {schema_readback_mode!r}"
        )
    if declared_schemas is not None and not verify_member_bytes and schema_readback_mode == "full":
        raise ValueError("verify_member_bytes=True is required when schema_readback_mode='full'")
    bundle = plan_or_bundle if isinstance(plan_or_bundle, ExternalGenerationBundle) else None
    plan = bundle.plan if bundle is not None else plan_or_bundle
    _need(isinstance(plan, RemotePublicationPlan), "Expected RemotePublicationPlan or ExternalGenerationBundle")

    has_external_members = bool(plan.external_member_keys) or any(
        m.get("external")
        for t in (plan.publish_command.get("logical_tables") or ())
        for m in (t.get("members") or ())
    )
    if publisher is not None and has_external_members:
        raise CatalogError(
            "CATALOG-EXTERNAL-PUBLISHER",
            "External-generation plans cannot run through DocSpec RemotePublisher",
        )

    if storage is not None:
        if publisher is not None or publish_fn is not None:
            raise CatalogError(
                "CATALOG-PUBLICATION",
                "Supply either storage= or publisher=/publish_fn=, not both",
            )
        dest_cfg = plan.publish_command["destination"]
        pointer_key = dest_cfg["pointer_key"]
        use_exp_ptr, eff_prior = _resolve_cas_preconditions(plan, bundle, expected_prior_release_id)

        # 1. Enforce CAS precondition against live current.json before touching anything
        live_bytes, live_etag = _check_live_pointer_cas(
            storage,
            pointer_key,
            expected_pointer=use_exp_ptr,
            expected_prior_release_id=eff_prior,
        )

        # 2. Enforce Parquet schema parity against ODCS contracts
        parity_results: list[dict[str, Any]] = []
        if bundle is not None and verify_schema_parity:
            parity_results = _verify_bundle_tables_schema_parity(
                bundle,
                storage=storage,
                allow_insecure_http=allow_insecure_http,
                normalize_arrow_encodings=normalize_arrow_encodings,
                check_column_order=check_column_order,
            )

        # 3. Verify pre-existing immutable Parquet objects exist remotely — ZERO Parquet uploads!
        external_set = set(plan.external_member_keys)
        referenced_parquet_keys: list[str] = []
        for table in plan.publish_command["logical_tables"]:
            for member in table["members"]:
                rkey = member["remote_key"]
                _need(rkey in external_set,
                      f"External publication refuses to upload Parquet object {rkey!r}")
                head = storage.head_object(rkey)
                if isinstance(head.get("size"), int) and not isinstance(head.get("size"), bool) and head["size"] != member["size"]:
                    raise CatalogError(
                        "CATALOG-REMOTE-INTEGRITY",
                        f"Existing immutable Parquet object {rkey!r} size {head['size']} disagrees with expected {member['size']}",
                    )
                referenced_parquet_keys.append(rkey)

        # 4. Upload immutable DDK catalog, Iceberg metadata, and release.manifest.json objects
        uploaded_keys: list[str] = []
        reused_keys: list[str] = []
        for art in plan.publish_command["catalog_artifacts"]:
            rkey = art["remote_key"]
            raw = _decode_staged_artifact_bytes(art)
            _need(len(raw) == art["size"] and sha256(raw).hexdigest() == art["sha256"],
                  f"Staged catalog artifact {rkey!r} failed local digest check")
            try:
                storage.put_bytes(rkey, raw, content_type=art["content_type"], if_none_match=True)
                uploaded_keys.append(rkey)
            except CatalogError as exc:
                if exc.code != "CATALOG-REMOTE-CONFLICT":
                    raise
                existing = storage.get_bytes(rkey)
                if len(existing) != art["size"] or sha256(existing).hexdigest() != art["sha256"]:
                    raise CatalogError(
                        "CATALOG-REMOTE-CONFLICT",
                        f"Immutable catalog artifact {rkey!r} already exists with different bytes",
                    ) from exc
                reused_keys.append(rkey)

        # 5. Build/select anonymous readback fetcher
        eff_fetch = anonymous_fetch if anonymous_fetch is not None else fetch_public_object
        if eff_fetch is None:
            pub_url = (dest_cfg.get("properties") or {}).get("public_base_url")
            if pub_url:
                eff_fetch = _build_anonymous_http_fetcher(
                    pub_url,
                    allow_insecure_http=allow_insecure_http,
                    user_agent=user_agent,
                )
            else:
                eff_audience = bundle.catalog_release.catalog.get("audience") if bundle is not None else "public"
                if eff_audience == "public" and not allow_authenticated_readback:
                    raise CatalogError(
                        "CATALOG-PUBLICATION",
                        "Public audience publication requires public_base_url or anonymous_fetch (refusing silent authenticated storage fallback)",
                    )

                def _storage_fetch(key: str) -> tuple[bytes, str | None]:
                    return storage.get_bytes(key), storage.head_object(key).get("etag")

                eff_fetch = _storage_fetch

        expected_lock_sha = bundle.lock_sha256 if bundle is not None else None
        eff_order = schema_check_order and check_column_order

        # 6. Pre-commit anonymous HTTP consumer readback BEFORE advancing current.json
        verify_http_consumer_readback(
            eff_fetch,
            dest_cfg,
            expected_release_id=plan.release_id,
            expected_lock_sha256=expected_lock_sha,
            verify_member_bytes=verify_member_bytes,
            staged_pointer_bytes=plan.pointer_bytes,
            allow_insecure_http=allow_insecure_http,
            declared_schemas=declared_schemas,
            schema_check_order=eff_order,
            schema_check_nullability=schema_check_nullability,
            schema_readback_mode=schema_readback_mode,
            user_agent=user_agent,
        )

        # 7. Atomically advance current.json via CAS precondition
        if live_bytes is None:
            put_res = storage.put_bytes(
                pointer_key,
                plan.pointer_bytes,
                content_type=JSON_CONTENT_TYPE,
                if_none_match=True,
            )
        else:
            _need(isinstance(live_etag, str) and bool(live_etag),
                  f"Existing {pointer_key!r} lacks ETag required for CAS update")
            put_res = storage.put_bytes(
                pointer_key,
                plan.pointer_bytes,
                content_type=JSON_CONTENT_TYPE,
                if_match=live_etag,
            )
        committed_etag = put_res.get("etag")

        # 8. Post-commit anonymous HTTP consumer readback against live current.json
        live_readback = verify_http_consumer_readback(
            eff_fetch,
            dest_cfg,
            expected_etag=committed_etag,
            expected_release_id=plan.release_id,
            expected_lock_sha256=expected_lock_sha,
            verify_member_bytes=verify_member_bytes,
            allow_insecure_http=allow_insecure_http,
            declared_schemas=declared_schemas,
            schema_check_order=eff_order,
            schema_check_nullability=schema_check_nullability,
            schema_readback_mode=schema_readback_mode,
            user_agent=user_agent,
        )

        return {
            "action": "publish",
            "status": "committed",
            "release_id": plan.release_id,
            "pointer_key": pointer_key,
            "committed_etag": committed_etag,
            "uploaded_keys": uploaded_keys,
            "reused_keys": reused_keys,
            "parquet_uploads": [],
            "parquet_upload_count": 0,
            "parquet_referenced": referenced_parquet_keys,
            "schema_parity": parity_results,
            "readback": live_readback,
            "lock_sha256": live_readback["lock_sha256"],
        }

    eff_destination = (
        destination
        if destination is not None
        else RemoteDestination(**plan.publish_command["destination"])
    )
    _need(isinstance(eff_destination, RemoteDestination), "destination must be a RemoteDestination")
    if (publisher is None) == (publish_fn is None):
        raise CatalogError("CATALOG-PUBLICATION", "Supply exactly one of publisher or publish_fn (or supply storage=)")
    eff_fetch_public = fetch_public_object if fetch_public_object is not None else anonymous_fetch
    if eff_fetch_public is None:
        raise CatalogError(
            "CATALOG-PUBLICATION",
            "publish_and_verify_remote_publication requires fetch_public_object or anonymous_fetch",
        )
    if declared_schemas is not None and not verify_member_bytes and schema_readback_mode == "full":
        raise ValueError("verify_member_bytes=True is required when schema_readback_mode='full'")
    if receipt_out_dir is not None and Path(receipt_out_dir).exists():
        raise CatalogError(
            "CATALOG-PUBLICATION",
            f"Publication receipt output directory already exists: {receipt_out_dir}",
        )

    eff_prior_id = None if expected_prior_release_id is ... else expected_prior_release_id
    eff_order = schema_check_order and check_column_order

    pre_schema_parity = None
    if declared_schemas is not None:
        local_candidates: dict[str, list[Path]] = {}
        has_iceberg_only = False
        all_local = True
        for table_cmd in plan.publish_command.get("logical_tables", ()):
            members = table_cmd.get("members", ())
            if not members:
                has_iceberg_only = True
                continue
            tbl_paths: list[Path] = []
            for member_cmd in members:
                path = _try_resolve_plan_member_path(member_cmd, member_paths)
                if path is None:
                    all_local = False
                    if member_paths is not None:
                        raise _schema_error(
                            f"Missing local Parquet path for {member_cmd['output_name']!r} in member_paths"
                        )
                    break
                tbl_paths.append(path)
            if not all_local:
                break
            local_candidates[table_cmd["table_name"]] = tbl_paths
        if all_local and (local_candidates or declared_schemas):
            pre_schema_parity = verify_parquet_schema_parity(
                declared_schemas,
                local_candidates,
                check_order=eff_order,
                check_nullability=schema_check_nullability,
                allow_subset_tables=has_iceberg_only,
            )

    live_bytes, live_etag = _read_live_pointer_for_publish(
        eff_destination.pointer_key,
        fetch_public_object=eff_fetch_public,
        fetch_live_pointer=fetch_live_pointer,
    )
    already_live = False
    if live_bytes is not None:
        try:
            live_doc = parse_json(live_bytes)
        except Exception:
            live_doc = None
        if (
            isinstance(live_doc, Mapping)
            and live_doc.get("release_id") == plan.release_id
            and sha256(live_bytes).hexdigest() == plan.pointer_sha256
        ):
            already_live = True

    wrote = not already_live
    prior_info = None
    committed_etag = live_etag

    if wrote:
        if (
            live_bytes is not None
            and require_prior_when_live
            and eff_prior_id is None
            and expected_prior_etag is None
            and plan.publish_command["expected_pointer"].get("kind") != "present"
        ):
            raise CatalogError(
                "CATALOG-PUBLICATION-PRIOR",
                "Live release already exists: pass expected_prior_release_id, expected_prior_etag, "
                "or ExpectedPointer.present(...) before replacing it",
            )
        prior_info = _verify_expected_prior(
            live_bytes,
            live_etag,
            expected_prior_release_id=eff_prior_id,
            expected_prior_etag=expected_prior_etag,
            expected_pointer_spec=plan.publish_command["expected_pointer"],
        )

        if publisher is not None:
            pub_res = publisher.publish(plan, secret_env=secret_env, cancel_event=cancel_event)
        else:
            pub_res = publish_fn(plan)  # type: ignore[misc]
        if isinstance(pub_res, Mapping):
            inner = pub_res.get("result")
            if isinstance(inner, Mapping) and "committed_etag" in inner:
                committed_etag = inner["committed_etag"]
            elif "committed_etag" in pub_res:
                committed_etag = pub_res["committed_etag"]

        if publisher is not None and run_native_readback:
            publisher.verify_readback(
                eff_destination,
                expected_etag=committed_etag,
                expected_release_id=plan.release_id,
                secret_env=secret_env,
                cancel_event=cancel_event,
            )

    readback = verify_http_consumer_readback(
        eff_fetch_public,
        eff_destination,
        expected_etag=committed_etag,
        expected_release_id=plan.release_id,
        expected_lock_sha256=_extract_plan_lock_sha256(plan),
        verify_member_bytes=verify_member_bytes,
        allow_insecure_http=allow_insecure_http,
        declared_schemas=declared_schemas,
        schema_check_order=eff_order,
        schema_check_nullability=schema_check_nullability,
        schema_readback_mode=schema_readback_mode,
        user_agent=user_agent,
    )

    receipt = {
        "status": "published_public_readback" if wrote else "already_published_public_readback",
        "observed_at": datetime.now(UTC).isoformat(),
        "dataset": plan.publish_command["dataset"],
        "operation": plan.publish_command["operation"],
        "release_id": plan.release_id,
        "pointer_key": eff_destination.pointer_key,
        "pointer_sha256": plan.pointer_sha256,
        "pointer_size": plan.pointer_size,
        "etag": readback["etag"],
        "prior": prior_info,
        "wrote": wrote,
        "lock_sha256": readback["lock_sha256"],
        "verified_members": readback["verified_members"],
        "verified_iceberg_snapshots": readback["verified_iceberg_snapshots"],
        "schema_parity": readback.get("verified_schemas") or pre_schema_parity,
        "public_bytes_read": readback["public_bytes_read"],
    }
    if receipt_out_dir is not None:
        _write_receipt_once(receipt_out_dir, "receipt.json", receipt)
    return receipt
