"""Runtime receipt normalization and declared-output Arrow schema comparison."""

import re

from .arrow_mapping import arrow_schema
from .results import diagnostic

_STATEMENT_PREFIX = re.compile(r'^(?:step|output|query) \d+ "(?:[^"\\]|\\.)*": ')


_RESOURCE_CODES = {
    "capacity", "metadata_capacity", "scratch_capacity",
    "DOCSPEC-RECEIPT-LIMIT", "DOCSPEC-DIAGNOSTIC-LIMIT", "DOCSPEC-NATIVE-READ-LIMIT",
}
_RESTRICTED_PLAN_CODES = {"substrait_extensions", "substrait_profile"}
_RESTRICTED_QUERY_MARKERS = (
    "No table named ", "is not supported: function anchor", "unsupported Substrait relation",
    "Substrait reads require", "Substrait scan filters", "Substrait relation extensions",
    "reusable SQL requires immutable functions",
)


_NATIVE_CHECK_CODES = {
    "DOCSPEC-NATIVE-IDENTITY": ("failed", "EXEC-NATIVE-IDENTITY"),
    "no_release": ("not_run", "EXEC-NATIVE-UNAVAILABLE"),
    "release_mismatch": ("not_run", "EXEC-NATIVE-UNAVAILABLE"),
    "DOCSPEC-QUALITY-ACCESS-MISSING": ("not_run", "ADAPTER-QUALITY-ACCESS-MISSING"),
    "qualification_mismatch": ("failed", "EXEC-QUALIFICATION-MISMATCH"),
    "qualification_coverage": ("failed", "EXEC-QUALIFICATION-COVERAGE"),
    "qualification_unknown": ("unknown", "EXEC-QUALIFICATION-UNKNOWN"),
    "qualification_audit_only": ("failed", "EXEC-QUALIFICATION-AUDIT-ONLY"),
    "qualification_failed": ("failed", "EXEC-QUALIFICATION-FAILED"),
    "stale_eligibility": ("failed", "EXEC-SELECTION-STALE"),
    "stale_base": ("failed", "EXEC-SELECTION-STALE"),
    "stale_qualification_authority": ("failed", "EXEC-SELECTION-STALE"),
    "coverage_regression": ("failed", "EXEC-SELECTION-STALE"),
    "operation_conflict": ("failed", "EXEC-REQUEST-CONFLICT"),
    "unsupported_managed_build": ("not_run", "ADAPTER-OPERATION-UNSUPPORTED"),
    "unsupported_managed_update": ("not_run", "ADAPTER-OPERATION-UNSUPPORTED"),
    "DOCSPEC-BACKEND-UNSUPPORTED": ("not_run", "ADAPTER-OPERATION-UNSUPPORTED"),
}


def _record(builder, group, subject, result, *, requirement="DDK-ADAPTER-011", evidence="executed",
            saved_plan=False):
    outcome = result["status"]
    status = {"succeeded": "passed", "not_submitted": "not_run", "error": "unknown"}.get(outcome, outcome)
    reason = result.get("reason") or result.get("error", {}).get("message") or outcome
    core_reason = _STATEMENT_PREFIX.sub("", reason)
    reference = result.get("evidence") or result.get("receipt")
    refs = [] if reference is None else [{"kind": "native-report", "path": reference["path"], "sha256": reference["sha256"]}]
    native_code = result.get("error", {}).get("code")
    resource = native_code in _RESOURCE_CODES or (
        native_code == "query" and "Resources exhausted" in core_reason
    )
    transport = result.get("transport", {})
    resource = resource or any(transport.get(field) for field in ("stdoutTruncated", "stderrTruncated", "drainIncomplete"))
    restricted = saved_plan and (native_code in _RESTRICTED_PLAN_CODES or (
        native_code == "query" and any(marker in reason for marker in _RESTRICTED_QUERY_MARKERS)
    ))
    if native_code == "DOCSPEC-FORMAT-UNAVAILABLE":
        status, code = "not_run", "ADAPTER-EXPORT-UNAVAILABLE"
    elif resource:
        status, code = "not_run", "EXEC-RESOURCE-LIMIT"
        builder.error(diagnostic(code, reason))
    elif restricted:
        status, code = "failed", "EXEC-PLAN-RESTRICTED"
    elif native_code == "DOCSPEC-CANCELLED":
        status, code = "not_run", "EXEC-CANCELLED"
        builder.error(diagnostic(code, reason))
    elif native_code in _NATIVE_CHECK_CODES:
        status, code = _NATIVE_CHECK_CODES[native_code]
        if code == "EXEC-NATIVE-UNAVAILABLE":
            builder.error(diagnostic(code, reason))
    elif native_code == "query" and core_reason.startswith("Error during planning: Invalid function"):
        status, code = "not_run", "ADAPTER-FUNCTION-IMPLEMENTATION-MISSING"
    elif status == "failed" and requirement == "DDK-ADAPTER-007":
        code = "EXEC-FIXTURE-MISMATCH"
    elif outcome == "failed" and result.get("operation", {}).get("mode") == "bounded_job" and result["operation"]["outputs"]:
        status, code = "not_run", "EXEC-JOB-FAILED"
        builder.error(diagnostic(code, reason))
    elif group == "data.odcs" and status in {"unknown", "not_run"} and any(
        check.get("id", "").startswith("ddk:unmapped-quality:")
        for check in result.get("checks", ()) if check.get("status") in {"unknown", "not_run"}
    ):
        status, code = "not_run", "ADAPTER-QUALITY-UNSUPPORTED"
        reason = "A required quality rule has no supported native execution"
    elif status == "unknown" and any(
        item.get("status") in {"unsupported", "unknown"} for item in result.get("mappingCoverage", ())
    ):
        code = "ADAPTER-MAPPING-INCOMPLETE"
    elif native_code in {"DOCSPEC-TIMEOUT", "DOCSPEC-NO-RECEIPT", "DOCSPEC-INVALID-RECEIPT",
                         "DOCSPEC-INPUT-CHANGED"}:
        status, code = "not_run", "EXEC-OUTCOME-UNKNOWN"
        builder.error(diagnostic(code, reason))
    elif native_code == "DOCSPEC-IO":
        status, code = "not_run", "EXEC-OUTCOME-UNKNOWN" if outcome == "unknown" else "ADAPTER-IO"
        builder.error(diagnostic(code, reason))
    elif outcome == "error":
        status, code = "unknown", "ADAPTER-ERROR"
        builder.error(diagnostic(code, reason))
    else:
        code = "ADAPTER-" + status.upper().replace("_", "-")
    builder.add(requirement, group, subject, status, evidence=evidence, reason=reason, evidence_records=refs,
                diagnostics=[] if status == "passed" else [diagnostic(code, reason)])


def _schema_result(expected, observed):
    wanted, coverage = arrow_schema(expected)
    if any(item["status"] != "exact" for item in coverage):
        return {"status": "unknown", "reason": "Output mapping includes an unsupported logical type",
                "mappingCoverage": coverage}
    actual_fields = observed["fields"]
    if [field["name"] for field in actual_fields] != [field["name"] for field in wanted["fields"]]:
        return {"status": "failed", "reason": "Inferred field names or order differ from the declared output"}
    for field, actual in zip(wanted["fields"], actual_fields, strict=True):
        if actual["data_type"] != field["data_type"]:
            return {"status": "failed", "reason": f"Inferred field {field['name']} has a different type"}
        if not field["nullable"] and actual["nullable"]:
            return {"status": "failed", "reason": f"Inferred field {field['name']} is nullable but the output requires a value"}
    return {"status": "passed", "reason": "Inferred names, order, types, and nullability satisfy the declared output"}
