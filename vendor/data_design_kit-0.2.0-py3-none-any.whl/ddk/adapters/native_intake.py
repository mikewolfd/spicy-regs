"""Table Schema mapping and typed Arrow fixture materialization."""

from importlib import metadata

from ddk.arrow_mapping import SCALAR_PROFILE, map_declaration, pyarrow_schema
from ddk.definitions import enum_values
from .native import file_sha256

TYPE_MAP = {"string": "string", "integer": "integer", "number": "number", "boolean": "boolean", "date": "date"}


def table_schema(dataset, *, missing_values=None):
    missing = [""] if missing_values is None else missing_values
    fields, coverage = [], []
    for prop in dataset["properties"]:
        name = prop["name"]
        logical = prop.get("logicalType")
        supported = logical in TYPE_MAP
        field = {"name": name, "type": TYPE_MAP.get(logical, "any"), "constraints": {}}
        coverage.append({"field": name, "facet": "type", "status": "exact" if supported else "unsupported"})
        for key in ("required", "unique"):
            if key in prop:
                field["constraints"][key] = prop[key]
                coverage.append({"field": name, "facet": key, "status": "exact"})
        values = enum_values(prop)
        if values is not None:
            field["constraints"]["enum"] = values
            ambiguous = any(type(x) is bool for x in values) and any(type(x) in (int, float) for x in values)
            empty = "" in values and "" in missing
            coverage.append({"field": name, "facet": "enum", "status": "unknown" if ambiguous or empty else "exact"})
        for key, value in prop.get("logicalTypeOptions", {}).items():
            translated = {"minLength": "minLength", "maxLength": "maxLength", "pattern": "pattern",
                          "minimum": "minimum", "maximum": "maximum"}.get(key)
            if translated:
                field["constraints"][translated] = value
                coverage.append({"field": name, "facet": key, "status": "exact"})
            elif key != "enum":
                coverage.append({"field": name, "facet": key, "status": "unsupported"})
        if prop.get("quality"):
            coverage.append({"field": name, "facet": "quality", "status": "unsupported",
                             "reason": "File intake does not execute quality SQL; select data.odcs separately"})
        fields.append(field)
    schema = {"fields": fields, "missingValues": missing}
    for custom in dataset.get("customProperties", []):
        if custom.get("vendor") == "ddk" and custom.get("property") == "rowIdentity":
            value = custom["value"]
            if isinstance(value, list) and all(isinstance(x, str) for x in value):
                schema["primaryKey"] = value
                coverage.append({"facet": "rowIdentity", "status": "exact"})
            else:
                coverage.append({"facet": "rowIdentity", "status": "unsupported"})
    coverage.append({"facet": "missing-values", "status": "exact", "values": missing})
    return schema, coverage


def fixture_files(request, folder):
    import pyarrow as pa
    import pyarrow.parquet as pq
    outputs = []
    profile = request.get("mappingProfile", SCALAR_PROFILE)
    for name, item in request["inputs"].items():
        if not name.replace("_", "").replace("-", "").isalnum():
            raise ValueError("Fixture table names must be simple identifiers")
        mapping = map_declaration(item["dataset"], profile=profile)
        # One captured declaration supplies both values and schema. This is
        # exact fixture materialization, not execution of ODCS data rules.
        rows = mapping.rows(item["rows"])
        table = pa.Table.from_pylist(rows, schema=pyarrow_schema(mapping.schema, pa))
        path = folder / (name + ".parquet")
        pq.write_table(table, path)
        outputs.append({"name": name, "path": str(path), "sha256": file_sha256(path), "rows": len(table),
                        "schema": mapping.schema})
        if profile != SCALAR_PROFILE:
            outputs[-1].update(mappingProfile=profile, mappingCoverage=mapping.coverage,
                              validationObligations=[entry for entry in mapping.coverage
                                                     if entry.get("meaning") == "validation-needed"])
    result = {"status": "passed", "files": outputs, "tool": {"name": "pyarrow", "version": metadata.version("pyarrow")}}
    if profile != SCALAR_PROFILE:
        result.update(mappingProfile=profile, scope="fixture-materialization-only", dataValidation="not_run")
    return result
