"""DocSpec External Lake Overlay Adapter and Metadata Generation.

Provides client binding for `docspec inspect-external` and generates
`role: "external-observed"` dataset registrations adhering to ADR-016.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Mapping, Sequence


class ExternalOverlayError(RuntimeError):
    """Raised when external inspection or overlay query generation fails."""

    def __init__(self, code: str, message: str, status_code: int = 400):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message
        self.status_code = status_code


class DocSpecOverlayAdapter:
    """Adapter bridging DocSpec's inspect-external CLI with DDK catalog."""

    def __init__(self, docspec_bin: str | Path | None = None):
        self.docspec_bin = str(docspec_bin) if docspec_bin else shutil.which("docspec")

    def inspect_external(
        self,
        target: str,
        etag: str | None = None,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        """Inspect external Parquet schema, footerSha256, and partition bounds."""
        if self.docspec_bin and Path(self.docspec_bin).exists():
            cmd = [self.docspec_bin, "inspect-external", "--path", str(target)]
            if etag:
                cmd.extend(["--etag", str(etag)])
            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    check=False,
                )
                if proc.returncode != 0:
                    err_msg = proc.stderr.strip() or proc.stdout.strip()
                    code = "upstream_mutated" if "412" in err_msg or "upstream_mutated" in err_msg else "inspection_failed"
                    status = 412 if code == "upstream_mutated" else 500
                    raise ExternalOverlayError(code, err_msg, status_code=status)
                return json.loads(proc.stdout)
            except subprocess.TimeoutExpired as exc:
                raise ExternalOverlayError("timeout", f"Inspection timed out after {timeout}s", 504) from exc

        # Pure-python / pyarrow fallback for local testing when docspec binary is not compiled on path
        target_path = Path(target)
        if target_path.exists():
            return self._inspect_local_fallback(target_path, etag=etag)

        raise ExternalOverlayError("missing_engine", f"Cannot inspect {target}: docspec binary not found")

    def _inspect_local_fallback(self, path: Path, etag: str | None = None) -> dict[str, Any]:
        """Fallback local inspection using pyarrow if available."""
        import hashlib

        # Stat signature: size:mtime_ns
        st = path.stat()
        stat_sig = f"{st.st_size}:{st.st_mtime_ns}"

        # Parquet footer sha256 (read length at -8, then footer bytes)
        with path.open("rb") as f:
            f.seek(-8, os.SEEK_END)
            footer_len_bytes = f.read(4)
            footer_len = int.from_bytes(footer_len_bytes, "little")
            f.seek(-(8 + footer_len), os.SEEK_END)
            footer_bytes = f.read(footer_len)
            footer_sha = hashlib.sha256(footer_bytes).hexdigest()

        columns: list[dict[str, str]] = []
        partition_bounds: dict[str, dict[str, str]] = {}
        schema_dict: dict[str, Any] = {"fields": []}

        try:
            import pyarrow.parquet as pq

            pf = pq.ParquetFile(path)
            arrow_schema = pf.schema_arrow
            for field in arrow_schema:
                columns.append({"name": field.name, "type": str(field.type)})
                schema_dict["fields"].append({"name": field.name, "type": str(field.type)})

            # Extract partition keys if path contains key=value segments
            for part in str(path).split("/"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    partition_bounds[k] = {"min": v, "max": v}
        except ImportError:
            pass

        return {
            "schema": schema_dict,
            "footerSha256": footer_sha,
            "statSig": stat_sig,
            "etag": etag or stat_sig,
            "partitionBounds": partition_bounds,
            "columns": columns,
        }

    def build_external_observed_descriptor(
        self,
        target: str,
        name: str | None = None,
        inspect_result: Mapping[str, Any] | None = None,
        etag: str | None = None,
        indexing_fields: Sequence[str] | None = None,
        include_fields: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        """Construct external-observed registration descriptor conforming to ADR-016."""
        if inspect_result is None:
            inspect_result = self.inspect_external(target, etag=etag)

        dataset_name = name or Path(target).stem
        fields_to_index = list(indexing_fields or ["comment_text", "title"])
        fields_to_include = list(include_fields or ["id", "posted_date"])

        descriptor = {
            "role": "external-observed",
            "name": dataset_name,
            "source": str(target),
            "footerSha256": inspect_result.get("footerSha256"),
            "statSig": inspect_result.get("statSig"),
            "etag": inspect_result.get("etag"),
            "partitionBounds": inspect_result.get("partitionBounds", {}),
            "columns": inspect_result.get("columns", []),
            "indexing": {
                "serenedb": {
                    "using": "inverted",
                    "fields": fields_to_index,
                    "include": fields_to_include,
                }
            },
            "contract": {
                "name": dataset_name,
                "role": "external-observed",
                "sourcePath": str(target),
                "footerSha256": inspect_result.get("footerSha256"),
                "indexing": {
                    "serenedb": {
                        "using": "inverted",
                        "fields": fields_to_index,
                        "include": fields_to_include,
                    }
                },
            },
        }
        return descriptor

    @staticmethod
    def classify_shards(
        remote_shards: Sequence[dict[str, Any]],
        local_partition_values: Mapping[str, set[str]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Classify remote shards into disjoint vs overlapping sets.

        A remote shard is disjoint if its partition bounds do not overlap with any
        locally active partition values.
        """
        disjoint: list[dict[str, Any]] = []
        overlap: list[dict[str, Any]] = []

        for shard in remote_shards:
            bounds = shard.get("partitionBounds", {})
            is_disjoint = False
            for col, bound in bounds.items():
                local_vals = local_partition_values.get(col)
                if local_vals:
                    b_min = bound.get("min")
                    b_max = bound.get("max")
                    if b_min is None or b_max is None:
                        continue
                    col_overlaps = False
                    try:
                        min_num = float(b_min) if ("." in str(b_min) or "e" in str(b_min).lower()) else int(b_min)
                        max_num = float(b_max) if ("." in str(b_max) or "e" in str(b_max).lower()) else int(b_max)
                        for lv in local_vals:
                            try:
                                lv_num = float(lv) if ("." in str(lv) or "e" in str(lv).lower()) else int(lv)
                                if min_num <= lv_num <= max_num:
                                    col_overlaps = True
                                    break
                            except (ValueError, TypeError):
                                if str(b_min) <= str(lv) <= str(b_max):
                                    col_overlaps = True
                                    break
                    except (ValueError, TypeError):
                        for lv in local_vals:
                            if str(b_min) <= str(lv) <= str(b_max):
                                col_overlaps = True
                                break

                    if not col_overlaps:
                        is_disjoint = True
                        break
            if is_disjoint:
                disjoint.append(shard)
            else:
                overlap.append(shard)

        return disjoint, overlap

    @staticmethod
    def build_disjoint_overlay_sql(
        table_name: str,
        local_active_table: str,
        remote_shards: Sequence[dict[str, Any]],
        local_keys: Sequence[str] | set[str],
        columns: Sequence[str],
        column_aliases: Mapping[str, str] | None = None,
        tombstone_col: str | None = "is_tombstone",
        key_column: str = "id",
    ) -> str:
        """Construct Dynamic Shard-Scoped Disjoint Union SQL query.

        local_active ∪ remote_disjoint ∪ (remote_overlap \\ local_keys)
        """
        aliases = column_aliases or {}
        local_col_exprs = [f"{col}" for col in columns]
        remote_col_exprs = [
            f"{aliases.get(col, col)} AS {col}" if aliases.get(col, col) != col else col
            for col in columns
        ]

        tombstone_filter = f"WHERE NOT {tombstone_col}" if tombstone_col else ""
        local_sql = f"SELECT {', '.join(local_col_exprs)} FROM {local_active_table} {tombstone_filter}".strip()

        # Classify remote shards (by convention if shard has disjoint=True flag or path)
        disjoint_shards = [s for s in remote_shards if s.get("disjoint", False)]
        overlap_shards = [s for s in remote_shards if not s.get("disjoint", False)]

        parts = [f"({local_sql})"]

        if disjoint_shards:
            disjoint_tables = [s.get("table", f"remote_disjoint_{i}") for i, s in enumerate(disjoint_shards)]
            for dtab in disjoint_tables:
                d_sql = f"SELECT {', '.join(remote_col_exprs)} FROM {dtab}"
                parts.append(f"({d_sql})")

        if overlap_shards:
            overlap_tables = [s.get("table", f"remote_overlap_{i}") for i, s in enumerate(overlap_shards)]
            for otab in overlap_tables:
                remote_key = aliases.get(key_column, key_column)
                o_sql = (
                    f"SELECT {', '.join(remote_col_exprs)} FROM {otab} r "
                    f"LEFT ANTI JOIN (SELECT {key_column} FROM {local_active_table}) l "
                    f"ON r.{remote_key} = l.{key_column}"
                )
                parts.append(f"({o_sql})")

        return "\nUNION ALL\n".join(parts)
