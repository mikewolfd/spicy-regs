"""Source gaps, inventory reconciliation, and compact release-wide availability (ddk-251s).

Pure offline/bounded structures, validators, and DocSpec SQL generators for:
1. Source inventory and checked gap records (expected vs observed), distinguishing
   all 10 canonical gap reasons (not_selected, failed_acquisition, incomplete_acquisition,
   retained_unpublished, publisher_omission, publisher_null, not_requested, unread,
   withheld, deleted) plus unknown denominator and valid empty states. Zero-acquired
   sources maintain clean inventory rows with no fabricated source version.
2. Compact SQL-computed release-wide date and field availability summaries bound
   strictly to (catalog_id, version_id, representation_id, source_version, measured_fields,
   scope, observation_time, total_rows), enforcing exclusive bucket reconciliation
   (placed + unplaced == total_rows), distinct states (missing_field, null_value,
   empty_text, unread_content, unplaceable_date), overlapping percentage refusal,
   and compact size bounds (<= 16 sample missing keys, <= 64 KiB payload).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
import re
from typing import Any, Mapping, Sequence

# Canonical reasons for source/record gaps per ddk-251s and DDK user value review §4
CANONICAL_GAP_REASONS = frozenset({
    "not_selected",
    "failed_acquisition",
    "incomplete_acquisition",
    "retained_unpublished",
    "publisher_omission",
    "publisher_null",
    "not_requested",
    "unread",
    "withheld",
    "deleted",
})

# Complete set of recognized observation statuses
OBSERVED_STATUSES = frozenset({
    "acquired",
    "valid_empty",
    "not_selected",
    "failed_acquisition",
    "incomplete_acquisition",
    "retained_unpublished",
    "publisher_omission",
    "publisher_null",
    "not_requested",
    "unread",
    "withheld",
    "deleted",
})

# Compact sizing limits (WL-SUMMARY-READ and ddk-zxlb workload budgets)
MAX_INLINE_SAMPLE_KEYS = 16
MAX_SUMMARY_PAYLOAD_BYTES = 64 * 1024  # 64 KiB limit for companion summaries


class SourceGapError(ValueError):
    """Base error for source inventory, gap evaluation, and availability checks."""

    def __init__(self, code: str, message: str):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message


class ContinuousCoverageRefusalError(SourceGapError):
    """Raised when continuous or 100% coverage is claimed without discrete enumeration."""


class FabricatedVersionRefusalError(SourceGapError):
    """Raised when an unacquired source row is given a fabricated version identifier."""


class AvailabilityReconciliationError(SourceGapError):
    """Raised when placed + unplaced != total_rows or bucket counts fail reconciliation."""


class OverlappingPercentageRefusalError(SourceGapError):
    """Raised when overlapping bucket counts attempt to masquerade as % of distinct records."""


class SizeBoundExceededError(SourceGapError):
    """Raised when inline key arrays or payload sizes exceed compact workload budgets."""


class UnitsMismatchError(SourceGapError):
    """Raised when expected vs observed counts use non-comparable units."""


def _validate_iso8601_instant(value: str) -> None:
    """Validate that value is a well-formed ISO 8601 UTC timestamp."""
    if not isinstance(value, str) or not value.strip():
        raise SourceGapError("GAP-INSTANT-INVALID", "Observation time must be a non-empty ISO 8601 string.")
    try:
        # Check standard ISO formats (including trailing Z or offsets)
        cleaned = value.strip().replace("Z", "+00:00")
        datetime.fromisoformat(cleaned)
    except Exception as exc:
        raise SourceGapError("GAP-INSTANT-INVALID", f"Invalid ISO 8601 instant: {value!r}") from exc


@dataclass(frozen=True)
class SourceInventoryEntry:
    """Disclosed expectation for a source family, edition, or publication period."""

    source_id: str
    edition_or_period: str
    expectation_source: str
    units: str
    scope: dict[str, Any] = field(default_factory=dict)
    expected_count: int | None = None
    is_denominator_unknown: bool = False
    min_date: str | None = None
    max_date: str | None = None
    claim_continuous_coverage: bool = False

    def __post_init__(self):
        if not self.source_id.strip():
            raise SourceGapError("GAP-SOURCE-ID-EMPTY", "Source identifier must be non-empty.")
        if not self.edition_or_period.strip():
            raise SourceGapError("GAP-EDITION-PERIOD-EMPTY", "Edition or period must be non-empty.")
        if not self.expectation_source.strip():
            raise SourceGapError("GAP-EXPECTATION-SOURCE-EMPTY", "Expectation source must be non-empty.")
        if not self.units.strip():
            raise SourceGapError("GAP-UNITS-EMPTY", "Units description must be non-empty.")

        if self.is_denominator_unknown:
            if self.expected_count is not None:
                raise SourceGapError(
                    "GAP-UNKNOWN-DENOMINATOR-HAS-COUNT",
                    f"Source {self.source_id}: expected_count must be None when denominator is declared unknown.",
                )
        elif self.expected_count is not None and self.expected_count < 0:
            raise SourceGapError("GAP-EXPECTED-COUNT-NEGATIVE", "Expected count cannot be negative.")

        if self.claim_continuous_coverage:
            if self.is_denominator_unknown:
                raise ContinuousCoverageRefusalError(
                    "GAP-UNKNOWN-DENOMINATOR-CONTINUOUS",
                    f"Source {self.source_id}: Continuous coverage cannot be claimed when expected denominator is unknown.",
                )
            if self.min_date is not None or self.max_date is not None:
                raise ContinuousCoverageRefusalError(
                    "GAP-MIN-MAX-NOT-CONTINUOUS",
                    f"Source {self.source_id}: Earliest ({self.min_date}) and latest ({self.max_date}) dates "
                    "cannot establish continuous or release-wide coverage without discrete expectation enumeration.",
                )


@dataclass(frozen=True)
class SourceObservation:
    """Observed acquisition, processing, or publication record for a source edition."""

    source_id: str
    edition_or_period: str
    observed_status: str
    observed_count: int = 0
    source_version: str | None = None
    units: str = "records"
    observation_time: str = ""
    content_digest: str | None = None
    evidence_uri: str | None = None
    receipt_id: str | None = None
    next_route: str | None = None

    def __post_init__(self):
        if not self.source_id.strip():
            raise SourceGapError("GAP-SOURCE-ID-EMPTY", "Source identifier must be non-empty.")
        if not self.edition_or_period.strip():
            raise SourceGapError("GAP-EDITION-PERIOD-EMPTY", "Edition or period must be non-empty.")
        if self.observed_status not in OBSERVED_STATUSES:
            raise SourceGapError(
                "GAP-OBSERVED-STATUS-INVALID",
                f"Observed status {self.observed_status!r} not in approved statuses: {sorted(OBSERVED_STATUSES)}",
            )
        if self.observed_count < 0:
            raise SourceGapError("GAP-OBSERVED-COUNT-NEGATIVE", "Observed count cannot be negative.")

        # STRICT INVARIANT: Sources with 0 acquired count must stay clean inventory rows with NO fabricated version.
        if self.observed_count == 0 and self.source_version is not None:
            raise FabricatedVersionRefusalError(
                "GAP-FABRICATED-SOURCE-VERSION",
                f"Source {self.source_id} edition {self.edition_or_period} has 0 acquired records "
                f"and must stay clean inventory rows without fabricated source version, refusing fabricated version {self.source_version!r}.",
            )

        if self.observation_time:
            _validate_iso8601_instant(self.observation_time)


@dataclass(frozen=True)
class SourceGapRecord:
    """A reconciled gap record representing expected vs observed holdings."""

    source_id: str
    edition_or_period: str
    reason: str
    expected_count: int | None
    observed_count: int
    units: str
    expectation_source: str
    observation_time: str
    evidence: str | None = None
    next_route: str | None = None
    scope: dict[str, Any] = field(default_factory=dict)
    is_denominator_unknown: bool = False
    is_valid_empty: bool = False

    def __post_init__(self):
        allowed_reasons = CANONICAL_GAP_REASONS | {"unknown_denominator", "valid_empty"}
        if self.reason not in allowed_reasons:
            raise SourceGapError(
                "GAP-REASON-INVALID",
                f"Gap reason {self.reason!r} not recognized. Must be one of {sorted(allowed_reasons)}",
            )
        if self.is_denominator_unknown and self.expected_count is not None:
            raise SourceGapError(
                "GAP-UNKNOWN-DENOMINATOR-HAS-COUNT",
                "Expected count must be None when denominator is unknown.",
            )
        if self.is_valid_empty and self.observed_count != 0:
            raise SourceGapError(
                "GAP-VALID-EMPTY-NONZERO",
                f"Valid empty record must have observed_count == 0, got {self.observed_count}.",
            )
        if self.observation_time:
            _validate_iso8601_instant(self.observation_time)


def compute_source_gaps(
    expected: Sequence[SourceInventoryEntry],
    observed: Sequence[SourceObservation],
) -> list[SourceGapRecord]:
    """Reconcile expected inventory against observed records without fabrication.

    Returns checked gap records detailing exact canonical reasons for any disparity.
    """
    observed_map: dict[tuple[str, str], SourceObservation] = {}
    for obs in observed:
        key = (obs.source_id, obs.edition_or_period)
        if key in observed_map:
            raise SourceGapError("GAP-DUPLICATE-OBSERVATION", f"Duplicate observation for key: {key}")
        observed_map[key] = obs

    gap_records: list[SourceGapRecord] = []

    for exp in expected:
        key = (exp.source_id, exp.edition_or_period)
        obs = observed_map.get(key)
        now_iso = datetime.now(timezone.utc).isoformat()

        if exp.is_denominator_unknown:
            gap_records.append(
                SourceGapRecord(
                    source_id=exp.source_id,
                    edition_or_period=exp.edition_or_period,
                    reason="unknown_denominator",
                    expected_count=None,
                    observed_count=obs.observed_count if obs else 0,
                    units=exp.units,
                    expectation_source=exp.expectation_source,
                    observation_time=obs.observation_time if (obs and obs.observation_time) else now_iso,
                    evidence=obs.evidence_uri if obs else None,
                    next_route=obs.next_route if obs else None,
                    scope=exp.scope,
                    is_denominator_unknown=True,
                )
            )
            continue

        if obs is None:
            # Expected source edition had no observation recorded -> not_selected
            gap_records.append(
                SourceGapRecord(
                    source_id=exp.source_id,
                    edition_or_period=exp.edition_or_period,
                    reason="not_selected",
                    expected_count=exp.expected_count,
                    observed_count=0,
                    units=exp.units,
                    expectation_source=exp.expectation_source,
                    observation_time=now_iso,
                    scope=exp.scope,
                )
            )
            continue

        # Check unit consistency
        if exp.units != obs.units:
            raise UnitsMismatchError(
                "GAP-UNITS-MISMATCH",
                f"Cannot compare source {exp.source_id} expected units {exp.units!r} with observed units {obs.units!r}.",
            )

        if obs.observed_status == "valid_empty":
            gap_records.append(
                SourceGapRecord(
                    source_id=exp.source_id,
                    edition_or_period=exp.edition_or_period,
                    reason="valid_empty",
                    expected_count=exp.expected_count,
                    observed_count=0,
                    units=exp.units,
                    expectation_source=exp.expectation_source,
                    observation_time=obs.observation_time or now_iso,
                    evidence=obs.evidence_uri,
                    next_route=obs.next_route,
                    scope=exp.scope,
                    is_valid_empty=True,
                )
            )
        elif obs.observed_status in CANONICAL_GAP_REASONS:
            gap_records.append(
                SourceGapRecord(
                    source_id=exp.source_id,
                    edition_or_period=exp.edition_or_period,
                    reason=obs.observed_status,
                    expected_count=exp.expected_count,
                    observed_count=obs.observed_count,
                    units=exp.units,
                    expectation_source=exp.expectation_source,
                    observation_time=obs.observation_time or now_iso,
                    evidence=obs.evidence_uri,
                    next_route=obs.next_route,
                    scope=exp.scope,
                )
            )
        elif obs.observed_status == "acquired":
            # If acquired count is less than expected count, record shortfall
            if exp.expected_count is not None and obs.observed_count < exp.expected_count:
                gap_records.append(
                    SourceGapRecord(
                        source_id=exp.source_id,
                        edition_or_period=exp.edition_or_period,
                        reason="incomplete_acquisition",
                        expected_count=exp.expected_count,
                        observed_count=obs.observed_count,
                        units=exp.units,
                        expectation_source=exp.expectation_source,
                        observation_time=obs.observation_time or now_iso,
                        evidence=obs.evidence_uri,
                        next_route=obs.next_route,
                        scope=exp.scope,
                    )
                )

    return gap_records


# ---------------------------------------------------------------------------
# Release-Wide Date & Field Availability Summaries
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FieldAvailabilityCounts:
    """Exact field availability counts with mutually exclusive unplaced categorization."""

    field_name: str
    total_rows: int
    placed_rows: int
    unplaced_rows: int
    null_value_count: int = 0
    empty_text_count: int = 0
    unread_content_count: int = 0
    missing_field_count: int = 0
    unplaceable_date_count: int = 0

    def __post_init__(self):
        if self.total_rows < 0 or self.placed_rows < 0 or self.unplaced_rows < 0:
            raise AvailabilityReconciliationError("AVAILABILITY-COUNT-NEGATIVE", "Counts cannot be negative.")

        # Reconcile placed + unplaced == total_rows
        if self.placed_rows + self.unplaced_rows != self.total_rows:
            raise AvailabilityReconciliationError(
                "AVAILABILITY-RECONCILIATION-FAILED",
                f"Field {self.field_name}: placed ({self.placed_rows}) + unplaced ({self.unplaced_rows}) "
                f"!= total ({self.total_rows}).",
            )

        # Reconcile unplaced sub-categories
        sub_total = (
            self.null_value_count
            + self.empty_text_count
            + self.unread_content_count
            + self.missing_field_count
            + self.unplaceable_date_count
        )
        if sub_total != self.unplaced_rows:
            raise AvailabilityReconciliationError(
                "AVAILABILITY-UNPLACED-RECONCILIATION-FAILED",
                f"Field {self.field_name}: unplaced breakdown sum ({sub_total}) != unplaced_rows ({self.unplaced_rows}).",
            )


@dataclass(frozen=True)
class DateAvailabilityDimension:
    """Bucketed temporal or categorical availability dimension."""

    dimension_id: str
    date_field: str
    granularity: str  # "month", "year", "season", "category"
    total_rows: int
    placed_rows: int
    unplaced_rows: int
    buckets: dict[str, int]
    overlapping: bool = False
    unplaceable_date_count: int = 0
    notes: list[str] = field(default_factory=list)

    def __post_init__(self):
        if self.total_rows < 0 or self.placed_rows < 0 or self.unplaced_rows < 0:
            raise AvailabilityReconciliationError("AVAILABILITY-COUNT-NEGATIVE", "Counts cannot be negative.")

        if self.placed_rows + self.unplaced_rows != self.total_rows:
            raise AvailabilityReconciliationError(
                "AVAILABILITY-RECONCILIATION-FAILED",
                f"Dimension {self.dimension_id}: placed ({self.placed_rows}) + unplaced ({self.unplaced_rows}) "
                f"!= total ({self.total_rows}).",
            )

        bucket_sum = sum(self.buckets.values())

        if not self.overlapping:
            # For exclusive buckets, sum of buckets MUST equal placed_rows exactly
            if bucket_sum != self.placed_rows:
                raise AvailabilityReconciliationError(
                    "AVAILABILITY-BUCKET-SUM-MISMATCH",
                    f"Dimension {self.dimension_id}: sum of exclusive buckets ({bucket_sum}) "
                    f"!= placed rows ({self.placed_rows}).",
                )
        else:
            # In overlapping buckets, cell counts may sum to >= placed_rows, but each bucket <= total_rows
            for bucket_key, count in self.buckets.items():
                if count > self.total_rows:
                    raise AvailabilityReconciliationError(
                        "AVAILABILITY-BUCKET-OVERFLOW",
                        f"Dimension {self.dimension_id} bucket {bucket_key} count ({count}) exceeds total rows ({self.total_rows}).",
                    )

    def distinct_record_percentage(self) -> float:
        """Return percentage of placed distinct records.

        Refuses if overlapping is True, preventing overlapping counts from masquerading as %.
        """
        if self.overlapping:
            bucket_sum = sum(self.buckets.values())
            raise OverlappingPercentageRefusalError(
                "AVAILABILITY-OVERLAPPING-PERCENTAGE-REFUSED",
                f"Dimension {self.dimension_id} has overlapping counts: sum of overlapping buckets ({bucket_sum}) "
                "cannot masquerade as a % of distinct records.",
            )
        if self.total_rows == 0:
            return 0.0
        return round(100.0 * self.placed_rows / self.total_rows, 2)


@dataclass(frozen=True)
class AvailabilitySummary:
    """Strictly-bound release-wide date and field availability summary companion."""

    catalog_id: str
    version_id: str
    representation_id: str
    source_version: str | None
    measured_fields: tuple[str, ...]
    scope: dict[str, Any]
    observation_time: str
    total_rows: int
    field_availability: dict[str, FieldAvailabilityCounts] = field(default_factory=dict)
    date_dimensions: dict[str, DateAvailabilityDimension] = field(default_factory=dict)
    sample_missing_keys: tuple[str, ...] = ()

    def __post_init__(self):
        if not self.catalog_id.strip():
            raise SourceGapError("AVAILABILITY-CATALOG-ID-EMPTY", "Catalog identifier required.")
        if not self.version_id.strip():
            raise SourceGapError("AVAILABILITY-VERSION-ID-EMPTY", "Version identifier required.")
        if not self.representation_id.strip():
            raise SourceGapError("AVAILABILITY-REPRESENTATION-ID-EMPTY", "Representation identifier required.")
        if self.total_rows < 0:
            raise AvailabilityReconciliationError("AVAILABILITY-TOTAL-NEGATIVE", "Total rows cannot be negative.")

        _validate_iso8601_instant(self.observation_time)

        # Enforce compact sizing: inline missing keys array bounded to at most MAX_INLINE_SAMPLE_KEYS
        if len(self.sample_missing_keys) > MAX_INLINE_SAMPLE_KEYS:
            raise SizeBoundExceededError(
                "AVAILABILITY-BOUND-EXCEEDED",
                f"Sample missing keys length ({len(self.sample_missing_keys)}) exceeds compact limit "
                f"of {MAX_INLINE_SAMPLE_KEYS}. Large raw missing-key arrays must not be dumped inline.",
            )

        # Enforce compact JSON payload size <= 64 KiB
        payload = json.dumps(self.to_dict())
        if len(payload.encode("utf-8")) > MAX_SUMMARY_PAYLOAD_BYTES:
            raise SizeBoundExceededError(
                "AVAILABILITY-BOUND-EXCEEDED",
                f"Summary serialized size ({len(payload.encode('utf-8'))} bytes) exceeds "
                f"compact companion budget of {MAX_SUMMARY_PAYLOAD_BYTES} bytes.",
            )

    def to_dict(self) -> dict[str, Any]:
        """Convert summary to a canonical dictionary representation."""
        return {
            "catalog_id": self.catalog_id,
            "version_id": self.version_id,
            "representation_id": self.representation_id,
            "source_version": self.source_version,
            "measured_fields": list(self.measured_fields),
            "scope": self.scope,
            "observation_time": self.observation_time,
            "total_rows": self.total_rows,
            "field_availability": {k: asdict(v) for k, v in self.field_availability.items()},
            "date_dimensions": {
                k: {
                    "dimension_id": v.dimension_id,
                    "date_field": v.date_field,
                    "granularity": v.granularity,
                    "total_rows": v.total_rows,
                    "placed_rows": v.placed_rows,
                    "unplaced_rows": v.unplaced_rows,
                    "buckets": v.buckets,
                    "overlapping": v.overlapping,
                    "unplaceable_date_count": v.unplaceable_date_count,
                    "notes": v.notes,
                }
                for k, v in self.date_dimensions.items()
            },
            "sample_missing_keys": list(self.sample_missing_keys),
        }


def generate_field_availability_sql(
    table_name: str,
    fields: Sequence[str],
    scope_predicate: str | None = None,
) -> str:
    """Generate bounded DataFusion/DocSpec SQL to compute field availability states.

    Computes placed (usable non-empty values), null_value, empty_text, and total_rows.
    Follows AGENTS.md pushdown and bounding rules.
    """
    if not table_name.strip():
        raise SourceGapError("SQL-TABLE-NAME-EMPTY", "Table name must be provided.")
    if not fields:
        raise SourceGapError("SQL-FIELDS-EMPTY", "At least one field must be measured.")

    select_parts = ["COUNT(*) AS total_rows"]
    for f in fields:
        # placed = count of values that are not NULL and not empty string
        select_parts.append(
            f"COUNT(CASE WHEN {f} IS NOT NULL AND CAST({f} AS VARCHAR) != '' THEN 1 END) AS {f}_placed"
        )
        select_parts.append(f"COUNT(CASE WHEN {f} IS NULL THEN 1 END) AS {f}_null")
        select_parts.append(
            f"COUNT(CASE WHEN {f} IS NOT NULL AND CAST({f} AS VARCHAR) = '' THEN 1 END) AS {f}_empty_text"
        )

    where_clause = f"\nWHERE {scope_predicate}" if scope_predicate else ""
    return f"SELECT\n  " + ",\n  ".join(select_parts) + f"\nFROM {table_name}{where_clause}"


def generate_date_availability_sql(
    table_name: str,
    date_column: str,
    granularity: str = "month",
    scope_predicate: str | None = None,
) -> str:
    """Generate bounded DataFusion/DocSpec SQL to compute date availability buckets.

    Computes period bucket counts and unplaceable date rows without unbounded scans.
    """
    if not table_name.strip():
        raise SourceGapError("SQL-TABLE-NAME-EMPTY", "Table name must be provided.")
    if not date_column.strip():
        raise SourceGapError("SQL-DATE-COLUMN-EMPTY", "Date column must be provided.")

    if granularity == "year":
        period_expr = f"SUBSTR(CAST({date_column} AS VARCHAR), 1, 4)"
    elif granularity == "month":
        period_expr = f"SUBSTR(CAST({date_column} AS VARCHAR), 1, 7)"
    else:
        period_expr = f"CAST({date_column} AS VARCHAR)"

    where_parts = [f"{date_column} IS NOT NULL", f"CAST({date_column} AS VARCHAR) != ''"]
    if scope_predicate:
        where_parts.append(f"({scope_predicate})")
    where_clause = " AND ".join(where_parts)

    return (
        f"SELECT\n"
        f"  {period_expr} AS period,\n"
        f"  COUNT(*) AS row_count\n"
        f"FROM {table_name}\n"
        f"WHERE {where_clause}\n"
        f"GROUP BY 1\n"
        f"ORDER BY 1"
    )
