"""Offline checking of project declarations."""

from collections import defaultdict

from .capabilities import discover_capabilities
from .documents import DocumentError, RegistryError, ResourceLimit, json_pointer, resolve_path, schema_registry
from .inventory import ProjectInventory
from .policies import check_policy, record_definition_uses
from .results import CORE_GROUPS, diagnostic

RETIRED_DESIGN_GROUPS = frozenset({"core.graph", "core.calls"})


def _reference_sites(artifact):
    value = artifact.value
    if artifact.kind == "job":
        for group in ("inputs", "outputs"):
            for name, reference in sorted(value[group].items()):
                yield (group, name), reference, "dataset"
        for name, binding in sorted(value.get("qualityQueries", {}).items()):
            yield ("qualityQueries", name, "dataset"), binding["dataset"], "dataset"
    elif artifact.kind == "policy":
        for index, rule in enumerate(value["rules"]):
            for key in ("artifact", "dataset"):
                if key in rule:
                    yield ("rules", index, key), rule[key], "dataset" if key == "dataset" else None
            for position, reference in enumerate(rule.get("datasets", ())):
                yield ("rules", index, "datasets", position), reference, "dataset"
            for position, reference in enumerate(rule.get("artifacts", ())):
                yield ("rules", index, "artifacts", position), reference, None
            for position, entry in enumerate(rule.get("exceptions", ())):
                yield ("rules", index, "exceptions", position, "artifact"), entry["artifact"], None


def _catalog_dependencies(inventory):
    # These authored relations are useful to impact. Resolution and catalog
    # diagnostics belong to an explicitly invoked catalog profile.
    for namespace, doc in inventory.projects.items():
        configuration = doc.value.get("catalog", {})
        for binding in configuration.get("ports", []):
            owner = inventory.scoped(binding["product"], namespace)
            inventory.dependency(owner, inventory.scoped(binding["dataset"], namespace))
        for group, items in (("recipe", configuration.get("recipes", [])),
                             ("relationship", configuration.get("relationships", []))):
            for item in items:
                if group == "recipe":
                    references = [ref for ref in item["inputs"].values() if isinstance(ref, str)]
                    peer_refs = [ref["catalog"] for ref in item["inputs"].values()
                                 if isinstance(ref, dict) and "catalog" in ref]
                    if "resultDataset" in item:
                        references.append(item["resultDataset"])
                else:
                    references = [endpoint["dataset"] for endpoint in (item["source"], item["target"])
                                  if "dataset" in endpoint and "catalog" not in endpoint]
                    peer_refs = [endpoint["catalog"] for endpoint in (item["source"], item["target"])
                                 if "catalog" in endpoint]
                for reference in references:
                    inventory.dependency(item["id"], inventory.scoped(reference, namespace))
                for peer_alias in peer_refs:
                    inventory.dependency(item["id"], f"peer-catalog:{peer_alias}")
                for relationship in (*item.get("relationships", ()), *item.get("contextualRelationships", ())):
                    inventory.dependency(item["id"], relationship)


def _prepare_references(inventory):
    for alias, artifact in sorted(inventory.artifacts.items()):
        for parts, reference, kind in _reference_sites(artifact):
            pointer = json_pointer(parts)
            try:
                inventory.dependency(alias, inventory.scoped(reference, artifact.namespace), artifact.path, pointer)
                inventory.resolve(reference, artifact.namespace, kind)
            except DocumentError as exc:
                invalid = exc.code == "DOC-PREREQUISITE-INVALID"
                inventory.report.add("DDK-REF-001", "core.references", f"{alias}{pointer}",
                                     "not_run" if invalid else "failed", reason=str(exc) if invalid else None,
                                     diagnostics=[diagnostic(exc.code, str(exc), path=inventory.display_path(artifact.path),
                                                             pointer=pointer)])
        if artifact.kind == "job":
            pointer = "/jobSpec"
            try:
                spec_path = resolve_path(artifact.path, artifact.value["jobSpec"], inventory.permitted_roots)
                spec_doc = inventory.read(spec_path)
                if not isinstance(spec_doc.value, dict):
                    raise DocumentError("DOC-SYNTAX-JSON", "DocSpec JobSpec must be a JSON object.", pointer)
                inventory.add_file(spec_doc, "implementation", owner=alias)
                inventory.dependency(alias, f"implementation:{inventory.display_path(spec_path)}", artifact.path, pointer)
            except DocumentError as exc:
                inventory.report.add("DDK-REF-001", "core.references", f"{alias}{pointer}", "failed",
                                     diagnostics=[diagnostic(exc.code, str(exc), path=inventory.display_path(artifact.path),
                                                             pointer=pointer)])
            except OSError:
                msg = "The referenced DocSpec JobSpec file could not be read."
                inventory.report.error(diagnostic("DOC-UNREADABLE", msg, path=inventory.display_path(artifact.path), pointer=pointer))
                inventory.report.add("DDK-REF-001", "core.references", f"{alias}{pointer}", "not_run", reason=msg,
                                     diagnostics=[diagnostic("DOC-UNREADABLE", msg, path=inventory.display_path(artifact.path),
                                                             pointer=pointer)])


def _resource_error(inventory, exc):
    record = diagnostic("EXEC-RESOURCE-LIMIT", str(exc), path=inventory.display_path(inventory.path))
    inventory.report.error(record)
    inventory.report.add("DDK-SAFE-003", "core.documents", "project-resource-limit", "not_run",
                         reason=str(exc), diagnostics=[record])


def load_project(path, permitted_roots=(), limits=None):
    inventory = ProjectInventory(path, permitted_roots, limits)
    try:
        schema_registry.cache_clear()
        inventory.visit(inventory.path)
        if inventory.import_aliases:
            inventory.report.metadata["importAliases"] = dict(sorted(inventory.import_aliases.items()))
        for alias, (namespace, project, entry) in sorted(inventory.registrations.items()):
            inventory.index(alias, namespace, project, entry)
        inventory.resolve_definitions()
        _prepare_references(inventory)
        _catalog_dependencies(inventory)
    except ResourceLimit as exc:
        _resource_error(inventory, exc)
    except RegistryError as exc:
        record = diagnostic("DOC-SCHEMA-REGISTRY", str(exc), path=inventory.display_path(inventory.path))
        inventory.report.error(record)
        inventory.report.add("DDK-SYNTAX-002", "core.documents", "schema-registry", "not_run",
                             reason=str(exc), diagnostics=[record])
    inventory.report.scope = inventory.scope
    inventory.freeze_inputs()
    return inventory


def _select(inventory, selection):
    if not selection:
        return set(inventory.registrations), set()
    filters = (selection,) if isinstance(selection, str) else tuple(selection)
    selected = set()
    for entry in filters:
        try:
            key, namespace = inventory.scoped(entry), inventory.scoped(entry, whole=True)
        except DocumentError:
            key = namespace = ""
        matches = {alias for alias in inventory.registrations if key and (alias == key or alias.startswith(f"{namespace}/"))}
        if not matches:
            inventory.report.add("DDK-CHECK-002", "core.references", f"selection:{entry}", "failed",
                                 diagnostics=[diagnostic("REF-SELECTION-MISSING", "The requested selection did not match an artifact or namespace.",
                                                         path=inventory.display_path(inventory.path))])
        selected.update(matches)
    # Policies that gate any selected target travel with that target.
    pending = list(selected)
    reverse_policies = defaultdict(set)
    for alias, artifact in inventory.artifacts.items():
        if artifact.kind == "policy":
            for prerequisite in inventory.dependencies.get(alias, ()):
                reverse_policies[prerequisite].add(alias)
    while pending:
        alias = pending.pop()
        related = inventory.dependencies.get(alias, set()) | reverse_policies[alias]
        for prerequisite in related & inventory.registrations.keys() - selected:
            selected.add(prerequisite)
            pending.append(prerequisite)
    return selected, set(inventory.registrations) - selected


def _selection_scope(inventory, selection, excluded):
    report = inventory.report
    selected = inventory.selected_aliases
    namespaces = {""}
    for alias in selected:
        namespace = inventory.registrations[alias][0]
        while namespace:
            namespaces.add(namespace)
            namespace = namespace.rpartition("/")[0]

    def owner(subject):
        while subject:
            if subject in inventory.registrations:
                return subject
            subject = subject.rpartition("/")[0]
        return None

    def checked(subject):
        if subject.startswith("project:"):
            namespace = subject.removeprefix("project:")
            return namespace == "/" or namespace in namespaces
        return owner(subject) not in excluded

    report.checks[:] = [item for item in report.checks if checked(item["subject"])]
    paths = {inventory.display_path(path) for subject, path in inventory.source_paths.items() if checked(subject)}
    excluded_paths = {inventory.display_path(path) for subject, path in inventory.source_paths.items() if not checked(subject)}
    report.operational_errors[:] = [item for item in report.operational_errors
                                    if item["location"]["path"] not in excluded_paths - paths]
    report.metadata["selection"] = [selection] if isinstance(selection, str) else list(selection)
    return namespaces


def _inventory_unavailable(inventory, handled_groups):
    report = inventory.report
    for group in report.required_groups:
        if group in CORE_GROUPS or group in handled_groups:
            continue
        report.missing_capabilities.add(group)
        reason = "The requested check group has no explicitly selected adapter."
        report.add(
            "DDK-ADAPTER-001", group, "project", "not_run", evidence="declared",
            reason=reason,
            diagnostics=[diagnostic("ADAPTER-CAPABILITY-MISSING", reason, path=inventory.display_path(inventory.path),
                                    severity="warning")],
        )


def check_inventory(inventory, required_groups=(), *, selection=None, handled_groups=(), lock=None, locked=False,
                    adapter_manifests=(), verified_release=None):
    """Check one freshly loaded inventory. Adapters can fill explicitly handled groups."""
    report = inventory.report
    from .locks import tool_identities

    report.tools = tool_identities()
    inventory.selected_aliases, excluded = _select(inventory, selection)
    namespaces = _selection_scope(inventory, selection, excluded) if selection else inventory.projects.keys()
    report.scope = inventory.scope
    report.scope["excludedConsumers"] = sorted(excluded)
    requested = [
        group
        for namespace, doc in inventory.projects.items()
        if namespace in namespaces
        for group in doc.value["requiredChecks"]
        if group not in RETIRED_DESIGN_GROUPS
    ]
    report.required_groups = list(dict.fromkeys([*CORE_GROUPS, *requested, *required_groups]))
    try:
        if adapter_manifests:
            discover_capabilities(inventory, adapter_manifests, verified_release)
        if locked or lock is not None:
            from .locks import verify_lock
            verify_lock(inventory, lock, locked=locked)
        for alias in sorted(inventory.selected_aliases):
            artifact = inventory.artifacts.get(alias)
            if artifact and artifact.kind == "policy":
                check_policy(inventory, artifact)
        record_definition_uses(inventory, inventory.selected_aliases)
    except ResourceLimit as exc:
        _resource_error(inventory, exc)
    _inventory_unavailable(inventory, handled_groups)
    report.scope["followedReferences"] = inventory.scope["followedReferences"]
    if not report.operational_errors and all(
        item["status"] == "passed" or not item["applicable"] or not item["required"]
        for item in report.checks if item["group"] in CORE_GROUPS
    ):
        report.completed_profiles.add("core")
    return report.build()


def check_project(path, required_groups=(), permitted_roots=(), lock=None, locked=False, selection=None, limits=None,
                  *, adapter_manifests=(), verified_release=None):
    inventory = load_project(path, permitted_roots, limits)
    return check_inventory(inventory, required_groups, selection=selection, lock=lock, locked=locked,
                           adapter_manifests=adapter_manifests, verified_release=verified_release)
