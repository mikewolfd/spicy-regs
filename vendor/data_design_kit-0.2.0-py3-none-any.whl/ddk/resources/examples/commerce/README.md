# Commerce example

These declarations and rows are an independently authored example. They describe orders, customers and a daily revenue calculation; they are not business records.

## What goes in

- `orders` contains six orders, including one cancellation and one unmatched customer (`data/orders.csv`).
- `customers` contains three customer-to-region records (`data/customers.csv`).
- `summarize` (`transforms/summarize.ddk.json` and `transforms/summarize.job.json`) declares the DocSpec job production consuming `orders` and `customers` via `transforms/revenue.sql` to emit `daily_revenue`.
- `amount-cents` is a shared ODCS property definition carrying a quality declaration.

*Note: archived pre-cutover `components/`, `designs/`, and `bindings.ddk.json` artifacts are preserved in [conformance/archive/examples/commerce/](../../conformance/archive/examples/commerce/).*

## What happens

The authored SQL excludes cancelled orders, matches each remaining order to a customer, and sums integer amounts by date and region. An order without a matching customer is excluded. Duplicate customer keys can multiply totals while preserving a valid output shape. The shared amount definition specifies minor currency units; currency, scale, tax treatment and gross or net basis are unspecified. Region labels do not define geographic boundaries.

The DocSpec `JobSpec` (`transforms/summarize.job.json`) and catalog recipe (`project.ddk.json`) identify the SQL calculation and output schema. Execution tests compile SQL into saved Substrait bytes (`plan.docspec-sql`), execute SQL and saved Substrait jobs directly against staged Parquet tables from `data/*.csv` (`execute.docspec-job`), and bind execution plus pinned `stepPlans` receipts into `ddk catalog`. Managed dataset selection qualifies separately.

## What comes out

| Day | Region | Amount in minor currency units |
| --- | --- | ---: |
| 2026-01-05 | north | 1700 |
| 2026-01-05 | south | 500 |
| 2026-01-06 | north | 250 |

Expected rows in the fixture were specified independently. The documentation checker verifies these totals using the authored SQL in an in-memory SQLite database. That is example sanity checking, not Substrait execution or native-adapter conformance.

## Verification status

The maintained connected workflow test checks actual staging, saved Substrait execution, output quality and a catalog-bound read when the required native tools are explicitly supplied. Its retained receipts establish only the exact files and definitions they name. Changing a description changes definition bytes; an older receipt must not silently become evidence for the revised definition. Catalog metadata checks and native execution remain separate results.

See the [catalog example](catalog/README.md) for ODPS ports, exact version and release records, DCAT discovery, and OpenLineage events.
