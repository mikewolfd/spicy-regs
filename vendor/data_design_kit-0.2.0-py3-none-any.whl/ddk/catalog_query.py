"""Bounded SQL over explicitly bound versions of one pinned catalog.

This module owns catalog artifact admission, nested/flat Parquet directory
verification, streaming digest/schema verification, disclosure column enforcement,
and bounded execution via the native DocSpec worker runtime.
"""

import atexit
import base64
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tempfile
import threading
from urllib.parse import unquote, urlsplit

from .catalog_access import CatalogError
from .catalog_delivery import load_catalog_artifacts
from .catalog_metadata import FILE_SCHEME
from .docspec_file_inputs import DIRECTORY_SCHEME
from .documents import ResourceLimit, json_dumps, parse_json


_WORKER_POOL_LOCK = threading.Lock()
_WORKER_POOL = {}
DEFAULT_MAX_INPUT_BYTES = 4 << 30
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")


def _require(condition, message):
    if not condition:
        raise CatalogError("CATALOG-LOCAL-QUERY", message)


def _local_path(uri, permitted_roots):
    parts = urlsplit(uri)
    _require(parts.scheme == "file" and not parts.netloc and not parts.query and not parts.fragment,
             "Local query requires an exact local file URI")
    path = Path(unquote(parts.path))
    _require(path.is_absolute() and not path.is_symlink(), "Data input must be an absolute unlinked path")
    resolved = path.resolve(strict=True)
    _require(any(resolved.is_relative_to(root) for root in permitted_roots), "Data input is outside permitted roots")
    return resolved


def disclosed_dataset_columns(catalog, dataset):
    """Return disclosed top-level column names for ``dataset`` or raise if withheld."""
    if dataset.get("disclosure") == "withheld":
        raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                           f"Dataset {dataset.get('alias')!r} is withheld in this catalog")
    assembly = (catalog.get("extensions") or {}).get("urn:ddk:catalog:assembly") or {}
    defs = assembly.get("datasetDefinitions")
    disclosed_paths = assembly.get("disclosedDefinitionPaths")
    alias = dataset.get("alias")
    withheld = set(dataset.get("withheldColumns") or ())

    if catalog.get("audience") == "public":
        if isinstance(disclosed_paths, dict):
            if alias not in disclosed_paths:
                raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                                   f"Dataset {alias!r} fields are withheld in this public catalog")
            cols = [
                item[0]["field"]
                for item in disclosed_paths[alias]
                if isinstance(item, list) and len(item) == 1
                and isinstance(item[0], dict) and isinstance(item[0].get("field"), str)
            ]
            defn = defs.get(alias) if isinstance(defs, dict) else None
            if isinstance(defn, dict) and isinstance(defn.get("properties"), list):
                prop_names = {
                    p["name"] for p in defn["properties"]
                    if isinstance(p, dict) and isinstance(p.get("name"), str)
                }
                cols = [c for c in cols if c in prop_names and c not in withheld]
            if not cols:
                raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                                   f"Dataset {alias!r} has no disclosed fields in this public catalog")
            return cols
        if isinstance(defs, dict):
            if alias not in defs:
                raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                                   f"Dataset {alias!r} definition is withheld in this public catalog")
            defn = defs[alias]
            if isinstance(defn, dict):
                withheld.update(defn.get("withheldColumns") or ())
                if isinstance(defn.get("properties"), list):
                    cols = [
                        p["name"] for p in defn["properties"]
                        if isinstance(p, dict) and isinstance(p.get("name"), str)
                        and p["name"] not in withheld
                    ]
                    if not cols:
                        raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                                           f"Dataset {alias!r} has no disclosed fields in this public catalog")
                    return cols

    if isinstance(defs, dict) and alias in defs and isinstance(defs[alias], dict):
        defn = defs[alias]
        withheld.update(defn.get("withheldColumns") or ())
        if withheld and isinstance(defn.get("properties"), list):
            return [
                p["name"] for p in defn["properties"]
                if isinstance(p, dict) and isinstance(p.get("name"), str)
                and p["name"] not in withheld
            ]
    return None


def resolve_directory_members(root, members, *, max_members=128):
    """Verify flat or nested partitioned Parquet directory membership without hashing payloads."""
    _require(root.is_dir() and bool(members), "Directory input needs complete member metadata")
    expected_members = {}
    expected_parent_dirs = set()
    for member in members:
        rel_str = member.get("path")
        _require(isinstance(rel_str, str) and bool(rel_str) and "\\" not in rel_str,
                 "Invalid Parquet directory member path")
        relative = PurePosixPath(rel_str)
        _require(not relative.is_absolute() and relative.as_posix() == rel_str
                 and not any(part in {"", ".", ".."} for part in relative.parts)
                 and rel_str.endswith(".parquet"),
                 "Unsafe or non-Parquet directory member path")
        _require(rel_str not in expected_members, "Invalid member inventory")
        byte_size = member.get("byteSize")
        _require(type(byte_size) is int and byte_size > 0, "Member byte size must be a positive integer")
        digest = member.get("sha256")
        _require(isinstance(digest, str) and bool(re.fullmatch(r"[a-f0-9]{64}", digest)),
                 "Member sha256 must be a 64-character lowercase hex digest")
        expected_members[rel_str] = member
        parent = relative.parent
        while str(parent) not in {".", ""}:
            expected_parent_dirs.add(parent.as_posix())
            parent = parent.parent
    _require(len(expected_members) <= max_members, "Invalid member inventory")

    observed = set()
    entry_limit = max(2048, max_members * 8)
    visited = 0
    stack = [(root, PurePosixPath("."))]
    while stack:
        cur_dir, rel_prefix = stack.pop()
        with os.scandir(cur_dir) as entries:
            for entry in entries:
                visited += 1
                _require(visited <= entry_limit, "Directory entry count exceeds the local query allocation")
                _require(not entry.is_symlink(), "Only unlinked directories and Parquet members are admitted")
                rel_path = entry.name if str(rel_prefix) == "." else f"{rel_prefix.as_posix()}/{entry.name}"
                if entry.is_dir(follow_symlinks=False):
                    _require(rel_path in expected_parent_dirs,
                             "Only flat or declared partitioned Parquet directories are admitted")
                    stack.append((Path(entry.path), PurePosixPath(rel_path)))
                elif entry.name.lower().endswith(".parquet"):
                    _require(entry.is_file(follow_symlinks=False) and rel_path in expected_members,
                             "Unexpected directory member")
                    observed.add(rel_path)
                else:
                    _require(entry.is_file(follow_symlinks=False), "Special files are forbidden in Parquet directories")
    _require(observed == set(expected_members), "The complete directory membership differs from the catalog")

    resolved = []
    for member in members:
        relative = PurePosixPath(member["path"])
        member_path = root.joinpath(*relative.parts)
        _require(not member_path.is_symlink() and member_path.resolve(strict=True).is_relative_to(root),
                 "Member escapes its directory")
        info = member_path.stat()
        _require(stat.S_ISREG(info.st_mode) and info.st_size == member["byteSize"],
                 "Member byte size differs from the selected version")
        resolved.append((member_path, member["byteSize"], member["sha256"]))
    return resolved


def compute_parquet_footer_sha256(stream_or_path, file_size=None):
    """Read and SHA-256 hash only the Parquet FileMetaData footer bytes (matching docspec)."""
    if isinstance(stream_or_path, (str, Path)):
        p = Path(stream_or_path)
        size = p.stat().st_size if file_size is None else file_size
        with p.open("rb") as f:
            return compute_parquet_footer_sha256(f, size)
    stream = stream_or_path
    if file_size is None:
        cur = stream.tell()
        stream.seek(0, os.SEEK_END)
        file_size = stream.tell()
        stream.seek(cur)
    _require(file_size >= 12, "Input Parquet file is too small to contain a valid footer")
    stream.seek(0)
    head_magic = stream.read(4)
    _require(head_magic == b"PAR1", "Input file is missing Parquet header magic")
    stream.seek(file_size - 8)
    tail = stream.read(8)
    _require(len(tail) == 8 and tail[4:] == b"PAR1", "Input file is missing Parquet footer magic")
    footer_len = int.from_bytes(tail[:4], "little")
    _require(0 < footer_len <= file_size - 12, "Input Parquet footer length is invalid")
    stream.seek(file_size - 8 - footer_len)
    footer_bytes = stream.read(footer_len)
    _require(len(footer_bytes) == footer_len, "Truncated Parquet footer bytes")
    return sha256(footer_bytes).hexdigest()


def _verify_and_read_schema(file_path, expected_size, expected_sha256, pq_module, *,
                            footer_sha256=None, admitted_version=False, iceberg_snapshot=None):
    """Verify Parquet file admission and read its footer schema.

    When ``footer_sha256`` + ``expected_size`` (or ``admitted_version`` / ``iceberg_snapshot``)
    verifies the file, only the Parquet header/footer is hashed instead of streaming
    100% of a multi-gigabyte file's payload bytes on cold query. When only ``expected_sha256``
    is pinned without fast footer/snapshot admission, full streaming SHA-256 verification runs.
    """
    fd = os.open(file_path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        _require(stat.S_ISREG(before.st_mode) and before.st_size == expected_size,
                 "Input bytes changed before schema admission")
        if footer_sha256 is not None:
            _require(isinstance(footer_sha256, str) and bool(_HEX64_RE.fullmatch(footer_sha256)),
                     "Expected footerSha256 must be a 64-character lowercase hex digest")
            observed_footer = compute_parquet_footer_sha256(stream, expected_size)
            _require(observed_footer == footer_sha256, "Input Parquet footer changed before schema admission")
        elif admitted_version or iceberg_snapshot is not None:
            compute_parquet_footer_sha256(stream, expected_size)
        elif expected_sha256 is not None:
            observed_sha = file_digest(stream, "sha256").hexdigest()
            _require(observed_sha == expected_sha256, "Input bytes changed before schema admission")
        else:
            compute_parquet_footer_sha256(stream, expected_size)
        after = os.fstat(stream.fileno())
        _require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                 == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
                 "Input bytes changed during schema admission")
        stream.seek(0)
        return pq_module.read_schema(stream)


def decode_exact_value(value):
    """Decode one ``ddk-exact-json-v1`` value into an exact Python object."""
    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, list):
        return [decode_exact_value(item) for item in value]
    if isinstance(value, dict):
        if "$number" in value and len(value) == 1:
            lex = value["$number"]
            if isinstance(lex, str) and re.fullmatch(r"-?(?:0|[1-9]\d*)", lex):
                return int(lex)
            return Decimal(str(lex))
        if "$object" in value and len(value) == 1:
            return {str(k): decode_exact_value(v) for k, v in value["$object"]}
        if set(value) == {"type", "encoding", "value"} and value["type"] == "binary" and value["encoding"] == "base64":
            return base64.b64decode(value["value"])
        if set(value) == {"type", "days"} and value["type"] == "date":
            days_val = decode_exact_value(value["days"])
            return date(1970, 1, 1) + timedelta(days=int(days_val))
        if set(value) == {"type", "unit", "value"} and value["type"] == "timestamp":
            unit = value["unit"]
            raw = int(decode_exact_value(value["value"]))
            if unit == "s":
                return datetime.fromtimestamp(raw, tz=timezone.utc)
            if unit == "ms":
                sec, rem = divmod(raw, 1_000)
                return datetime.fromtimestamp(sec, tz=timezone.utc).replace(microsecond=rem * 1_000)
            if unit == "us":
                sec, rem = divmod(raw, 1_000_000)
                return datetime.fromtimestamp(sec, tz=timezone.utc).replace(microsecond=rem)
            if unit == "ns":
                sec, rem_ns = divmod(raw, 1_000_000_000)
                if rem_ns % 1_000 == 0:
                    return datetime.fromtimestamp(sec, tz=timezone.utc).replace(microsecond=rem_ns // 1_000)
                dt = datetime.fromtimestamp(sec, tz=timezone.utc)
                return f"{dt.strftime('%Y-%m-%dT%H:%M:%S')}.{rem_ns:09d}Z"
        return {k: decode_exact_value(v) for k, v in value.items()}
    return value


def decode_exact_row(row):
    """Decode one ``ddk-exact-json-v1`` row object preserving column order."""
    decoded = decode_exact_value(row)
    if not isinstance(decoded, dict):
        raise CatalogError("CATALOG-LOCAL-QUERY", "Decoded exact row must be an object")
    return decoded


class _PersistentOwnerWorker:
    """Reusable stdio JSON-RPC client for ``docspec owner-worker``."""

    def __init__(self, key, executable, init_params, timeout):
        self.key = key
        self.executable = str(executable)
        self.timeout = timeout
        self.lock = threading.Lock()
        self.next_id = 1
        self.proc = subprocess.Popen(
            [self.executable, "owner-worker"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            bufsize=1,
        )
        try:
            self._call_locked("init", init_params)
        except Exception:
            self.close()
            raise

    def is_alive(self):
        return self.proc.poll() is None

    def _call_locked(self, method, params):
        if self.proc.poll() is not None:
            raise CatalogError("CATALOG-LOCAL-QUERY", "Native owner worker exited unexpectedly")
        req_id = self.next_id
        self.next_id += 1
        line = json_dumps({"id": req_id, "method": method, "params": params}) + "\n"
        self.proc.stdin.write(line)
        self.proc.stdin.flush()
        raw_line = self.proc.stdout.readline()
        if not raw_line:
            stderr_tail = (self.proc.stderr.read() or "")[-2048:]
            raise CatalogError("CATALOG-LOCAL-QUERY",
                               f"Native owner worker returned EOF{(': ' + stderr_tail.strip()) if stderr_tail else ''}")
        try:
            response = parse_json(raw_line.encode("utf-8"))
        except (ValueError, ResourceLimit) as exc:
            raise CatalogError("CATALOG-LOCAL-QUERY", f"Malformed owner worker response: {exc}") from exc
        if not isinstance(response, dict) or response.get("id") != req_id:
            raise CatalogError("CATALOG-LOCAL-QUERY", "Owner worker returned mismatched JSON-RPC id")
        return response

    def call(self, method, params):
        with self.lock:
            return self._call_locked(method, params)

    def close(self):
        try:
            if self.proc.stdin:
                self.proc.stdin.close()
        except OSError:
            pass
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=1.0)


def _close_all_workers():
    with _WORKER_POOL_LOCK:
        workers = list(_WORKER_POOL.values())
        _WORKER_POOL.clear()
    for worker in workers:
        worker.close()


atexit.register(_close_all_workers)


def _get_owner_worker(executable, directory, expected_lock_sha256, limits, roots, timeout, receipts_dir):
    key = (
        str(executable),
        str(Path(directory).resolve()),
        expected_lock_sha256,
        json.dumps(dict(limits), sort_keys=True),
        tuple(str(r) for r in roots),
        str(receipts_dir) if receipts_dir else "",
    )
    init_params = {
        "catalogPath": str(Path(directory).resolve() / "catalog.ddk.json"),
        "lockPath": str(Path(directory).resolve() / "catalog.lock.json"),
        "expectedLockSha256": expected_lock_sha256,
        "permittedRoots": [str(r) for r in roots],
        "limits": dict(limits),
        "queryTimeoutMs": max(100, int(timeout * 1000)),
        **({"retainReceiptsDir": str(receipts_dir)} if receipts_dir else {}),
    }
    with _WORKER_POOL_LOCK:
        existing = _WORKER_POOL.get(key)
        if existing is not None and existing.is_alive():
            return existing
        if existing is not None:
            existing.close()
            _WORKER_POOL.pop(key, None)
        worker = _PersistentOwnerWorker(key, executable, init_params, timeout)
        if len(_WORKER_POOL) >= 8:
            oldest_key = next(iter(_WORKER_POOL))
            _WORKER_POOL.pop(oldest_key).close()
        _WORKER_POOL[key] = worker
        return worker


def _can_use_owner_worker(adapter, exact_json):
    if exact_json is False or adapter is None:
        return False
    if getattr(adapter, "use_owner_worker", True) is False:
        return False
    if not (hasattr(adapter, "executable") and hasattr(adapter, "limits") and hasattr(adapter, "execute")):
        return False
    from .adapters import docspec as docspec_mod
    from .adapters import native as native_mod
    if docspec_mod.run_bounded is not native_mod.run_bounded:
        return False
    adapter_exec = getattr(type(adapter), "execute", None)
    if adapter_exec is not docspec_mod.DocSpecAdapter.execute:
        return False
    # Instance monkeypatch check
    if "execute" in getattr(adapter, "__dict__", {}):
        return False
    return Path(adapter.executable).is_file()


def execute_catalog_sql(directory, *, expected_lock_sha256, bindings, sql, adapter,
                        scratch, permitted_roots, max_rows=100, max_input_bytes=DEFAULT_MAX_INPUT_BYTES,
                        max_members=128, audience="local", columns_by_binding=None,
                        admitted_version=False, explain=False, exact_json=None):
    """Return native evidence and at most max_rows, refusing truncated answers.

    bindings maps SQL table names to exact catalog version IDs. No latest lookup,
    implicit release selection, query rewriting, or data
    quality assertion occurs. Empty results remain successful empty results.
    The native adapter must provide bounded execution and exact input admission.
    """
    _require(isinstance(expected_lock_sha256, str) and bool(re.fullmatch(r"[a-f0-9]{64}", expected_lock_sha256)),
             "Data access requires an external catalog lock SHA-256")
    _require(all(type(value) is int and value > 0 for value in (max_rows, max_input_bytes, max_members)),
             "Query limits must be positive integers")
    _require(isinstance(sql, str) and 0 < len(sql.encode()) <= 64 << 10, "SQL must be bounded nonempty text")
    _require(isinstance(bindings, dict) and 0 < len(bindings) <= max_members, "Explicit input version bindings are required")
    _require(audience in (None, "local", "public"), "Invalid catalog audience scope")
    roots = tuple(Path(root).resolve(strict=True) for root in permitted_roots)
    _require(bool(roots), "Explicit data roots are required")
    captured = load_catalog_artifacts(directory, expected_lock_sha256=expected_lock_sha256, audience=audience)
    catalog = captured.catalog
    datasets_by_alias = {ds["alias"]: ds for ds in catalog.get("datasets", ()) if "alias" in ds}
    inputs, pins, footer_pins, iceberg_pins, total, members_count, schema_files = [], {}, {}, {}, 0, 0, {}
    worker_inputs = {}
    columns_map = dict(columns_by_binding or {})
    for name, version_id in bindings.items():
        _require(isinstance(name, str) and len(name) <= 128 and bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", name)),
                 "SQL input names require letters, digits, underscores or hyphens; quote hyphenated names in SQL")
        versions = [v for v in catalog["versions"] if v["id"] == version_id]
        _require(len(versions) == 1, "Each binding must resolve to one exact catalog version")
        version = versions[0]
        _require(version.get("referenceDisclosure") != "withheld",
                 "The exact version reference is withheld; no data reader may resolve it")
        dataset = datasets_by_alias.get(version.get("dataset"))
        disclosed_cols = disclosed_dataset_columns(catalog, dataset) if dataset else None
        requested_cols = columns_map.get(name)
        if requested_cols is not None:
            _require(isinstance(requested_cols, (list, tuple)) and bool(requested_cols)
                     and all(isinstance(c, str) and c for c in requested_cols),
                     f"Columns filter for {name!r} must be a non-empty list of column names")
            if disclosed_cols is not None:
                disclosed_set = set(disclosed_cols)
                if any(c not in disclosed_set for c in requested_cols):
                    raise CatalogError("CATALOG-DISCLOSURE-WITHHELD",
                                       f"Requested columns for {name!r} include undisclosed fields")
            effective_cols = list(requested_cols)
        else:
            effective_cols = disclosed_cols

        reference = version.get("reference", {})
        _require(version.get("retention") == "present" and reference.get("scheme") in {FILE_SCHEME, DIRECTORY_SCHEME},
                 "Unsupported or unavailable local version reference")
        representations = [r for r in catalog["representations"] if r["version"] == version_id]
        _require(len(representations) == 1, "Each local version needs one unambiguous representation")
        representation = representations[0]
        value = reference.get("value", {})
        _require(representation.get("kind") == "file" and representation.get("availability") == "available"
                 and representation.get("mediaType") == "application/vnd.apache.parquet"
                 and representation.get("location") == value.get("location"),
                 "Representation must match the exact available Parquet reference")
        path = _local_path(value["location"], roots)
        members = representation.get("members", ())
        iceberg_snap = representation.get("icebergSnapshot") or value.get("icebergSnapshot")
        schema_files[name] = []
        if reference["scheme"] == DIRECTORY_SCHEME:
            member_footer_by_rel = {
                m["path"]: m.get("footerSha256")
                for m in members if isinstance(m, dict) and isinstance(m.get("path"), str)
            }
            resolved_members = resolve_directory_members(path, members, max_members=max_members)
            shards_spec = []
            for member_path, member_size, member_sha in resolved_members:
                _require(str(member_path) not in pins, "Duplicate input member")
                pins[str(member_path)] = member_sha
                rel_key = member_path.relative_to(path).as_posix()
                footer_pins[str(member_path)] = member_footer_by_rel.get(rel_key)
                iceberg_pins[str(member_path)] = iceberg_snap
                schema_files[name].append((member_path, member_size))
                shards_spec.append({"path": str(member_path), "sha256": member_sha, "byteSize": member_size})
                total += member_size
                members_count += 1
            worker_inputs[name] = {
                "versionId": version_id,
                "shards": shards_spec,
                **({"columns": effective_cols} if effective_cols is not None else {}),
                **({"admittedVersion": bool(admitted_version)} if admitted_version else {}),
            }
        else:
            _require(path.is_file() and not members, "Single-file input cannot carry directory members")
            size = path.stat().st_size
            _require(size == representation.get("byteSize"), "File byte size differs from its selected version")
            total += size
            members_count += 1
            schema_files[name].append((path, size))
            pins[str(path)] = value["sha256"]
            footer_pins[str(path)] = representation.get("footerSha256") or value.get("footerSha256")
            iceberg_pins[str(path)] = iceberg_snap
            worker_inputs[name] = {
                "versionId": version_id,
                "path": str(path),
                "sha256": value["sha256"],
                "byteSize": size,
                **({"columns": effective_cols} if effective_cols is not None else {}),
                **({"admittedVersion": bool(admitted_version)} if admitted_version else {}),
            }
        _require(total <= max_input_bytes and members_count <= max_members, "Input exceeds the admitted query allocation")
        inputs.append({"kind": "parquet", "name": name, "path": str(path)})

    sql_sha = sha256(sql.encode()).hexdigest()
    common = {
        "catalogLockSha256": captured.lock_sha256,
        "bindings": dict(bindings),
        "sqlSha256": sql_sha,
        "admittedInputBytes": total,
        "admittedInputMembers": members_count,
    }

    if _can_use_owner_worker(adapter, exact_json):
        # Validate member schema equivalence without reading file contents into Python memory
        # when multi-member inputs exist, unless already admitted.
        if not admitted_version and any(len(files) > 1 for files in schema_files.values()):
            import pyarrow.parquet as pq
            for name, files in schema_files.items():
                if len(files) <= 1:
                    continue
                schemas = [
                    _verify_and_read_schema(
                        file_path, size, pins[str(file_path)], pq,
                        footer_sha256=footer_pins.get(str(file_path)),
                        admitted_version=bool(admitted_version),
                        iceberg_snapshot=iceberg_pins.get(str(file_path)),
                    )
                    for file_path, size in files
                ]
                _require(all(schema.equals(schemas[0], check_metadata=True) for schema in schemas),
                         "All members require the same exact Arrow schema for local query admission")

        evidence_dir = Path(getattr(adapter, "evidence_dir", scratch)).resolve()
        receipts_dir = evidence_dir / "worker-receipts"
        receipts_dir.mkdir(parents=True, exist_ok=True)
        worker = _get_owner_worker(
            adapter.executable,
            directory,
            expected_lock_sha256,
            adapter.limits,
            roots,
            getattr(adapter, "timeout", 30),
            receipts_dir,
        )
        rpc_params = {
            "sql": sql,
            "inputs": worker_inputs,
            "limit": max_rows,
            "wrapLimit": False,
            "explain": bool(explain),
            **({"admittedVersion": bool(admitted_version)} if admitted_version else {}),
        }
        try:
            rpc_resp = worker.call("run_sql", rpc_params)
        except CatalogError:
            with _WORKER_POOL_LOCK:
                _WORKER_POOL.pop(worker.key, None)
            worker.close()
            raise
        if not rpc_resp.get("ok"):
            err = rpc_resp.get("error") or {}
            msg = err.get("message") or "No complete answer was established"
            code = err.get("code") or "refused"
            status_val = "unknown" if code in {"native_read_unknown", "owner_unavailable"} else "refused"
            return {**common, "status": status_val, "reason": msg, "receipt": {"status": status_val, "error": err}}

        res = rpc_resp["result"]
        exact_rows = res.get("rows", [])
        receipt = {
            "status": "succeeded",
            "engine": res.get("engine"),
            "sqlSha256": res.get("sqlSha256", sql_sha),
            "elapsedMs": res.get("elapsedMs"),
            **({"record": res["record"]} if "record" in res else {}),
        }
        if len(exact_rows) > max_rows or res.get("hasMore"):
            return {
                **common,
                "status": "refused",
                "reason": "Answer exceeds the selected row limit; refine the query",
                "receipt": receipt,
            }
        decoded_rows = [decode_exact_row(r) for r in exact_rows]
        columns = list(decoded_rows[0].keys()) if decoded_rows else []
        return {
            **common,
            "status": "succeeded",
            "rows": decoded_rows,
            "exactRows": exact_rows,
            "columns": columns,
            "receipt": receipt,
            **({"plan": res["plan"]} if "plan" in res and res["plan"] is not None else {}),
        }

    # Legacy adapter / monkeypatch path (e.g. older pre-rtdp runtimes without lossless owner-worker)
    query_identity = sha256(json_dumps({"lock": captured.lock_sha256, "bindings": bindings, "sql": sql,
                                       "max_rows": max_rows}).encode()).hexdigest()
    request = {"id": f"urn:ddk:local-query:{query_identity}", "scratch": str(Path(scratch).resolve()),
               "inputs": inputs, "steps": [], "outputs": [],
               "queries": [{"name": "answer", "sql": sql}]}

    import pyarrow as pa
    import pyarrow.parquet as pq
    from .docspec_recipe_gate import encode_ipc_schema_base64, decode_ipc_schema_base64

    declared = []
    for name, files in schema_files.items():
        schemas = [
            _verify_and_read_schema(
                file_path, size, pins[str(file_path)], pq,
                footer_sha256=footer_pins.get(str(file_path)),
                admitted_version=bool(admitted_version),
                iceberg_snapshot=iceberg_pins.get(str(file_path)),
            )
            for file_path, size in files
        ]
        _require(all(schema.equals(schemas[0], check_metadata=True) for schema in schemas),
                 "All members require the same exact Arrow schema for local query admission")
        declared.append({"name": name, "schema_ipc_base64": encode_ipc_schema_base64(schemas[0])})

    folder = Path(tempfile.mkdtemp(prefix="catalog-query-schema-", dir=adapter.evidence_dir))
    job_path = folder / "job.json"
    job_bytes = json_dumps(request).encode()
    job_path.write_bytes(job_bytes)
    preparation = adapter.prepare_job({"job": {"path": str(job_path), "sha256": sha256(job_bytes).hexdigest()}, "inputs": declared})
    if preparation["status"] != "succeeded":
        return {**common, "status": preparation["status"], "stage": "schema_preparation", "receipt": preparation}
    prepared = preparation["result"]
    queries = prepared.get("queries", ())
    _require(len(queries) == 1 and queries[0]["name"] == "answer", "Native preparation omitted the query schema")
    output_schema = decode_ipc_schema_base64(prepared["schemas"][queries[0]["schema_sha256"]])
    if exact_json is False:
        unsupported = [field.name for field in output_schema if not (
            pa.types.is_integer(field.type) or pa.types.is_boolean(field.type) or pa.types.is_null(field.type)
            or pa.types.is_string(field.type) or pa.types.is_large_string(field.type) or pa.types.is_string_view(field.type))]
        if unsupported:
            return {**common, "status": "refused", "stage": "output_type_admission", "receipt": preparation,
                    "reason": "Legacy pre-exact SQL mode returns only scalar text, integers, booleans and nulls. "
                              "Unsupported output fields: " + ", ".join(unsupported) + "."}
    response = adapter.execute(request, input_digests=pins)
    result = {**common, "status": response["status"], "receipt": response, "preparation": preparation}
    if response["status"] == "succeeded":
        queries = response.get("result", {}).get("queries", ())
        _require(len(queries) == 1 and queries[0]["name"] == "answer" and isinstance(queries[0]["data"], list),
                 "Native query returned an incomplete answer inventory")
        rows = queries[0]["data"]
        if len(rows) > max_rows:
            result.update(status="refused", reason="Answer exceeds the selected row limit; refine the query")
        else:
            result.update(rows=rows, columns=list(queries[0]["columns"]))
    return result
