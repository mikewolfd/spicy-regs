"""Dependency Injection (DI) Ports and Cloudflare-Default Platform Container (ADR-009).

Defaults infrastructure bindings to **Cloudflare** (Cloudflare R2 object storage +
Cloudflare R2 Data Catalog Iceberg REST) and **SereneDB** (``spicyengine`` running on
a remote VM such as a DigitalOcean Droplet behind HTTPS / Cloudflare Tunnel), while
allowing callers and tests to inject local filesystem or mock implementations cleanly
at the composition root.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import os
from pathlib import Path
from typing import Any, Callable, Protocol, runtime_checkable
import urllib.error
from urllib.parse import quote, urlsplit
import urllib.request

from .catalog_access import CatalogError
from .documents import json_dumps, parse_json
from .publication import IcebergTableSnapshotSpec, inspect_iceberg_table_metadata
from .serenedb import HttpTransport, SereneDbConfig, SereneDbSearchAdapter, default_serenedb_http_transport


@runtime_checkable
class ObjectStoragePort(Protocol):
    """Port for reading and conditionally writing immutable/pointer objects."""

    def get_bytes(
        self,
        key: str,
        *,
        byte_range: tuple[int, int] | None = None,
        if_match: str | None = None,
    ) -> bytes: ...

    def head_object(self, key: str) -> dict[str, Any]: ...

    def put_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        if_match: str | None = None,
        if_none_match: bool = False,
    ) -> dict[str, Any]: ...


@runtime_checkable
class IcebergCatalogPort(Protocol):
    """Port for resolving Apache Iceberg v2 table snapshots."""

    def list_tables(self, namespace: str) -> list[str]: ...

    def load_table_snapshot(self, namespace: str, table: str) -> IcebergTableSnapshotSpec: ...


@runtime_checkable
class SearchEnginePort(Protocol):
    """Port for full-text / BM25 + hybrid search (default: SereneDB / ``spicyengine``)."""

    def catalogs(self) -> dict[str, Any]: ...

    def search(
        self,
        request: dict[str, Any],
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]: ...

    def facets(
        self,
        request: dict[str, Any],
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]: ...

    def record(
        self,
        record_id: str,
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]: ...


@runtime_checkable
class SearchHostPort(Protocol):
    """Port for the compute/VM host running SereneDB (default: DigitalOcean Droplet)."""

    provider: str

    def describe_host(self) -> dict[str, Any]: ...

    def resolve_endpoint(self) -> str | None: ...

    def build_rollout_plan(
        self,
        serenedb_export: dict[str, Any],
        *,
        lock_sha256: str,
        rebuild: bool = False,
    ) -> dict[str, Any]: ...


def cloudflare_r2_endpoint(account_id: str) -> str:
    acct = (account_id or "").strip()
    if not acct or "/" in acct or " " in acct:
        raise CatalogError("CATALOG-CLOUDFLARE-CONFIG", "Cloudflare account_id must be a valid non-empty identifier.")
    return f"https://{acct}.r2.cloudflarestorage.com"


def cloudflare_r2_data_catalog_uri(account_id: str, warehouse: str) -> str:
    acct = (account_id or "").strip()
    wh = (warehouse or "").strip().strip("/")
    if not acct or not wh:
        raise CatalogError("CATALOG-CLOUDFLARE-CONFIG", "Cloudflare R2 Data Catalog requires account_id and warehouse.")
    return f"https://catalog.cloudflarestorage.com/{quote(acct, safe='')}/{quote(wh, safe='_-')}"


class CloudflareR2StorageAdapter:
    """Default ``ObjectStoragePort`` targeting Cloudflare R2 (HTTPS / S3-compatible / public custom domain)."""

    def __init__(
        self,
        *,
        bucket: str,
        account_id: str | None = None,
        public_base_url: str | None = None,
        bearer_token: str | None = None,
        timeout_seconds: float = 15.0,
        http_transport: HttpTransport | None = None,
    ) -> None:
        if not bucket or "/" in bucket:
            raise CatalogError("CATALOG-CLOUDFLARE-CONFIG", f"Invalid Cloudflare R2 bucket name {bucket!r}.")
        self.bucket = bucket
        self.account_id = account_id or os.environ.get("CLOUDFLARE_ACCOUNT_ID") or "cloudflare-r2"
        if public_base_url:
            parsed = urlsplit(public_base_url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise CatalogError("CATALOG-CLOUDFLARE-CONFIG", "public_base_url must be http:// or https://")
            self.base_url = public_base_url.rstrip("/")
        else:
            self.base_url = f"{cloudflare_r2_endpoint(self.account_id)}/{quote(bucket, safe='')}"
        self._bearer_token = bearer_token or os.environ.get("CLOUDFLARE_R2_BEARER_TOKEN")
        self._timeout = timeout_seconds
        self._transport = http_transport or default_serenedb_http_transport

    def _url_for(self, key: str) -> str:
        clean_key = key.lstrip("/")
        if not clean_key or ".." in clean_key.split("/"):
            raise CatalogError("CATALOG-STORAGE-KEY", f"Invalid R2 object key {key!r}")
        return f"{self.base_url}/{quote(clean_key, safe='/-_.=')}"

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        h: dict[str, str] = {}
        if self._bearer_token:
            h["Authorization"] = f"Bearer {self._bearer_token}"
        if extra:
            h.update(extra)
        return h

    def get_bytes(
        self,
        key: str,
        *,
        byte_range: tuple[int, int] | None = None,
        if_match: str | None = None,
    ) -> bytes:
        extra: dict[str, str] = {}
        if byte_range is not None:
            start, end_inclusive = byte_range
            if start < 0 or end_inclusive < start:
                raise CatalogError("CATALOG-STORAGE-RANGE", f"Invalid byte_range {byte_range!r}")
            extra["Range"] = f"bytes={start}-{end_inclusive}"
        if if_match:
            extra["If-Match"] = if_match
        status, _, body = self._transport("GET", self._url_for(key), self._headers(extra), None, self._timeout)
        if status == 412:
            raise CatalogError("CATALOG-UPSTREAM-MUTATED", f"R2 object {key!r} ETag precondition failed (HTTP 412).")
        if status == 404:
            raise CatalogError("CATALOG-OBJECT-MISSING", f"R2 object {key!r} not found (HTTP 404).")
        if status not in {200, 206}:
            raise CatalogError("CATALOG-STORAGE-IO", f"Cloudflare R2 GET {key!r} failed with HTTP {status}.")
        return body

    def head_object(self, key: str) -> dict[str, Any]:
        status, headers, _ = self._transport("HEAD", self._url_for(key), self._headers(), None, self._timeout)
        if status == 404:
            raise CatalogError("CATALOG-OBJECT-MISSING", f"R2 object {key!r} not found (HTTP 404).")
        if status != 200:
            raise CatalogError("CATALOG-STORAGE-IO", f"Cloudflare R2 HEAD {key!r} failed with HTTP {status}.")
        return {
            "key": key,
            "etag": headers.get("etag"),
            "size": int(headers["content-length"]) if "content-length" in headers else None,
            "contentType": headers.get("content-type"),
        }

    def put_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        if_match: str | None = None,
        if_none_match: bool = False,
    ) -> dict[str, Any]:
        extra = {"Content-Type": content_type}
        if if_match is not None:
            extra["If-Match"] = if_match
        if if_none_match:
            extra["If-None-Match"] = "*"
        status, headers, _ = self._transport("PUT", self._url_for(key), self._headers(extra), data, self._timeout)
        if status == 412:
            raise CatalogError("CATALOG-REMOTE-CONFLICT", f"Cloudflare R2 conditional PUT conflict on {key!r} (HTTP 412).")
        if status not in {200, 201, 204}:
            raise CatalogError("CATALOG-STORAGE-IO", f"Cloudflare R2 PUT {key!r} failed with HTTP {status}.")
        return {
            "key": key,
            "etag": headers.get("etag"),
            "sha256": sha256(data).hexdigest(),
            "bytes": len(data),
        }


class CloudflareR2DataCatalogAdapter:
    """Default ``IcebergCatalogPort`` speaking Cloudflare R2 Data Catalog's Apache Iceberg REST v1 API."""

    def __init__(
        self,
        *,
        account_id: str | None = None,
        warehouse: str = "default",
        catalog_uri: str | None = None,
        prefix: str = "",
        bearer_token: str | None = None,
        timeout_seconds: float = 15.0,
        http_transport: HttpTransport | None = None,
    ) -> None:
        acct = account_id or os.environ.get("CLOUDFLARE_ACCOUNT_ID") or "cloudflare-r2"
        self.catalog_uri = (catalog_uri or cloudflare_r2_data_catalog_uri(acct, warehouse)).rstrip("/")
        self.prefix = prefix.strip("/")
        self._token = bearer_token or os.environ.get("CLOUDFLARE_R2_CATALOG_TOKEN") or os.environ.get("CLOUDFLARE_API_TOKEN")
        self._timeout = timeout_seconds
        self._transport = http_transport or default_serenedb_http_transport

    def _v1_path(self, suffix: str) -> str:
        pfx = f"/{quote(self.prefix, safe='_-')}" if self.prefix else ""
        return f"{self.catalog_uri}/v1{pfx}/{suffix.lstrip('/')}"

    def _headers(self) -> dict[str, str]:
        h = {"Accept": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def list_tables(self, namespace: str) -> list[str]:
        url = self._v1_path(f"namespaces/{quote(namespace, safe='')}/tables")
        status, _, raw = self._transport("GET", url, self._headers(), None, self._timeout)
        if status != 200:
            raise CatalogError("CATALOG-ICEBERG-REST", f"R2 Data Catalog list_tables({namespace!r}) returned HTTP {status}.")
        doc = parse_json(raw)
        return [item["name"] for item in (doc.get("identifiers") or ()) if isinstance(item, dict) and "name" in item]

    def load_table_snapshot(self, namespace: str, table: str) -> IcebergTableSnapshotSpec:
        url = self._v1_path(f"namespaces/{quote(namespace, safe='')}/tables/{quote(table, safe='')}")
        status, _, raw = self._transport("GET", url, self._headers(), None, self._timeout)
        if status == 404:
            raise CatalogError("CATALOG-ICEBERG-MISSING", f"Iceberg table {namespace}.{table} not found in R2 Data Catalog.")
        if status != 200:
            raise CatalogError("CATALOG-ICEBERG-REST", f"R2 Data Catalog load_table({namespace}.{table}) returned HTTP {status}.")
        doc = parse_json(raw)
        meta_loc = doc.get("metadata-location") or doc.get("metadataLocation")
        metadata = doc.get("metadata")
        if not isinstance(meta_loc, str) or not isinstance(metadata, dict):
            raise CatalogError("CATALOG-ICEBERG-REST", "Iceberg REST response missing metadata-location or metadata object.")
        meta_bytes = json_dumps(metadata, sort_keys=True).encode("utf-8")
        return IcebergTableSnapshotSpec.from_metadata(
            meta_bytes,
            metadata_location=meta_loc,
            table_name=f"{namespace}.{table}",
        )


class LocalFilesystemStorageAdapter:
    """Injectable local-disk ``ObjectStoragePort`` for offline development and unit tests."""

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._etags: dict[str, str] = {}

    def _resolve(self, key: str) -> Path:
        clean = key.lstrip("/")
        candidate = (self.root / clean).resolve()
        if not candidate.is_relative_to(self.root):
            raise CatalogError("CATALOG-STORAGE-KEY", f"Local storage key escapes root: {key!r}")
        return candidate

    def _etag(self, path: Path) -> str:
        return f'"{sha256(path.read_bytes()).hexdigest()}"'

    def get_bytes(
        self,
        key: str,
        *,
        byte_range: tuple[int, int] | None = None,
        if_match: str | None = None,
    ) -> bytes:
        path = self._resolve(key)
        if not path.is_file():
            raise CatalogError("CATALOG-OBJECT-MISSING", f"Local object {key!r} not found.")
        if if_match and self._etag(path) != if_match:
            raise CatalogError("CATALOG-UPSTREAM-MUTATED", f"Local object {key!r} ETag mismatch.")
        raw = path.read_bytes()
        if byte_range is not None:
            start, end_inclusive = byte_range
            return raw[start : end_inclusive + 1]
        return raw

    def head_object(self, key: str) -> dict[str, Any]:
        path = self._resolve(key)
        if not path.is_file():
            raise CatalogError("CATALOG-OBJECT-MISSING", f"Local object {key!r} not found.")
        return {"key": key, "etag": self._etag(path), "size": path.stat().st_size, "contentType": "application/octet-stream"}

    def put_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        if_match: str | None = None,
        if_none_match: bool = False,
    ) -> dict[str, Any]:
        path = self._resolve(key)
        exists = path.is_file()
        if if_none_match and exists:
            raise CatalogError("CATALOG-REMOTE-CONFLICT", f"Object {key!r} already exists.")
        if if_match is not None and (not exists or self._etag(path) != if_match):
            raise CatalogError("CATALOG-REMOTE-CONFLICT", f"ETag mismatch writing {key!r}.")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        etag = f'"{sha256(data).hexdigest()}"'
        return {"key": key, "etag": etag, "sha256": sha256(data).hexdigest(), "bytes": len(data)}


class DigitalOceanDropletSearchHostAdapter:
    """Default search-compute host adapter managing a SereneDB DigitalOcean Droplet via DO API v2."""

    provider = "digitalocean"

    def __init__(
        self,
        *,
        droplet_id: int | str | None = None,
        droplet_tag: str | None = None,
        api_token: str | None = None,
        explicit_url: str | None = None,
        network_scope: str | None = None,
        scheme: str | None = None,
        port: int | None = None,
        state_dir: str = "/var/lib/spicyengine/runtime",
        data_mount_dir: str = "/var/lib/spicyengine/data",
        api_base_url: str = "https://api.digitalocean.com/v2",
        timeout_seconds: float = 10.0,
        http_transport: HttpTransport | None = None,
    ) -> None:
        raw_id = droplet_id if droplet_id is not None else os.environ.get("DO_DROPLET_ID")
        self.droplet_id = str(raw_id).strip() if raw_id is not None and str(raw_id).strip() else None
        self.droplet_tag = (droplet_tag or os.environ.get("DO_DROPLET_TAG") or "ddk-serenedb").strip()
        self.api_token = (api_token or os.environ.get("DIGITALOCEAN_TOKEN") or "").strip() or None
        self.explicit_url = (
            explicit_url
            or os.environ.get("DDK_SERENEDB_URL")
            or os.environ.get("SERENEDB_URL")
            or ""
        ).strip().rstrip("/") or None
        self.network_scope = (network_scope or os.environ.get("DO_NETWORK_SCOPE") or "public").strip().lower()
        if self.network_scope not in {"public", "private"}:
            raise CatalogError("CATALOG-DO-CONFIG", f"DO_NETWORK_SCOPE must be 'public' or 'private', got {self.network_scope!r}.")
        self.scheme = (scheme or os.environ.get("DO_SERENEDB_SCHEME") or "https").strip().lower()
        if self.scheme not in {"http", "https"}:
            raise CatalogError("CATALOG-DO-CONFIG", f"DO_SERENEDB_SCHEME must be 'http' or 'https', got {self.scheme!r}.")
        raw_port = port if port is not None else os.environ.get("DO_SERENEDB_PORT")
        self.port = int(raw_port) if raw_port is not None and str(raw_port).strip() else (443 if self.scheme == "https" else 8090)
        self.state_dir = state_dir
        self.data_mount_dir = data_mount_dir
        self.api_base_url = api_base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self._transport = http_transport or default_serenedb_http_transport

    def _scrub(self, text: str) -> str:
        if self.api_token and self.api_token in text:
            return text.replace(self.api_token, "[REDACTED]")
        return text

    def describe_host(self) -> dict[str, Any]:
        if not self.api_token:
            return {
                "provider": "digitalocean",
                "configured": False,
                "dropletId": self.droplet_id,
                "dropletTag": self.droplet_tag,
                "explicitEndpoint": self.explicit_url,
            }
        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.api_token}",
        }
        path = (
            f"/droplets/{quote(self.droplet_id, safe='')}"
            if self.droplet_id
            else f"/droplets?tag_name={quote(self.droplet_tag, safe='')}&per_page=20"
        )
        url = f"{self.api_base_url}{path}"
        try:
            status, _, raw = self._transport("GET", url, headers, None, self.timeout_seconds)
        except Exception as exc:
            raise CatalogError(
                "CATALOG-DO-UNAVAILABLE",
                f"DigitalOcean API v2 request failed: {self._scrub(str(exc))}",
            ) from exc
        if status == 404:
            raise CatalogError("CATALOG-DO-NOT-FOUND", "DigitalOcean Droplet was not found.")
        if status != 200:
            raise CatalogError("CATALOG-DO-ERROR", f"DigitalOcean API v2 returned HTTP {status}.")
        payload = parse_json(raw)
        if not isinstance(payload, dict):
            raise CatalogError("CATALOG-DO-ERROR", "DigitalOcean API v2 returned invalid JSON.")
        if self.droplet_id:
            droplet = payload.get("droplet")
        else:
            droplets = payload.get("droplets")
            active = [d for d in (droplets or []) if isinstance(d, dict) and d.get("status") == "active"]
            droplet = active[0] if active else ((droplets or [None])[0])
        if not isinstance(droplet, dict):
            raise CatalogError("CATALOG-DO-NOT-FOUND", f"No DigitalOcean Droplet matched tag {self.droplet_tag!r}.")

        v4_entries = (droplet.get("networks") or {}).get("v4") or []
        public_ipv4 = next((n.get("ip_address") for n in v4_entries if isinstance(n, dict) and n.get("type") == "public"), None)
        private_ipv4 = next((n.get("ip_address") for n in v4_entries if isinstance(n, dict) and n.get("type") == "private"), None)
        region = droplet.get("region")
        return {
            "provider": "digitalocean",
            "configured": True,
            "dropletId": str(droplet.get("id")),
            "name": droplet.get("name"),
            "status": droplet.get("status"),
            "region": region.get("slug") if isinstance(region, dict) else region,
            "sizeSlug": droplet.get("size_slug"),
            "publicIpv4": public_ipv4,
            "privateIpv4": private_ipv4,
            "tags": list(droplet.get("tags") or []),
        }

    def resolve_endpoint(self) -> str | None:
        if self.explicit_url:
            return self.explicit_url
        if not self.api_token:
            return None
        info = self.describe_host()
        ip = info.get("privateIpv4") if self.network_scope == "private" else info.get("publicIpv4")
        if not ip:
            return None
        default_port = (self.scheme == "https" and self.port == 443) or (self.scheme == "http" and self.port == 80)
        return f"{self.scheme}://{ip}" if default_port else f"{self.scheme}://{ip}:{self.port}"

    def build_rollout_plan(
        self,
        serenedb_export: dict[str, Any],
        *,
        lock_sha256: str,
        rebuild: bool = False,
    ) -> dict[str, Any]:
        datasets = serenedb_export.get("datasets") if isinstance(serenedb_export, dict) else []
        publish_flag = " --rebuild" if rebuild else ""
        return {
            "provider": "digitalocean",
            "lockSha256": lock_sha256,
            "dropletId": self.droplet_id,
            "dropletTag": self.droplet_tag,
            "stateDir": self.state_dir,
            "dataMountDir": self.data_mount_dir,
            "datasetCount": len(datasets) if isinstance(datasets, list) else 0,
            "commands": [
                f"spicyengine start --mount {self.data_mount_dir}",
                f"spicyengine publish {self.state_dir}/dataset.json{publish_flag}",
                "spicyengine status",
            ],
            "readinessProbe": "/v1/catalogs",
            "egressModel": "cloudflare-r2-zero-egress",
        }


class LocalSearchHostAdapter:
    """Local DI search-host adapter for laptop preview and CI container tests."""

    provider = "local"

    def __init__(
        self,
        *,
        host: str = "127.0.0.1",
        port: int = 8090,
        state_dir: Path | str = "/tmp/spicyengine-local",
        data_mount_dir: Path | str | None = None,
        explicit_url: str | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.state_dir = str(state_dir)
        self.data_mount_dir = str(data_mount_dir) if data_mount_dir else f"{self.state_dir}/data"
        self.explicit_url = explicit_url.rstrip("/") if explicit_url else None

    def describe_host(self) -> dict[str, Any]:
        return {
            "provider": "local",
            "configured": True,
            "host": self.host,
            "port": self.port,
            "stateDir": self.state_dir,
        }

    def resolve_endpoint(self) -> str | None:
        return self.explicit_url or f"http://{self.host}:{self.port}"

    def build_rollout_plan(
        self,
        serenedb_export: dict[str, Any],
        *,
        lock_sha256: str,
        rebuild: bool = False,
    ) -> dict[str, Any]:
        datasets = serenedb_export.get("datasets") if isinstance(serenedb_export, dict) else []
        publish_flag = " --rebuild" if rebuild else ""
        return {
            "provider": "local",
            "lockSha256": lock_sha256,
            "stateDir": self.state_dir,
            "dataMountDir": self.data_mount_dir,
            "datasetCount": len(datasets) if isinstance(datasets, list) else 0,
            "commands": [
                f"spicyengine start --mount {self.data_mount_dir}",
                f"spicyengine publish {self.state_dir}/dataset.json{publish_flag}",
                f"spicyengine serve --port {self.port}",
            ],
            "readinessProbe": "/v1/catalogs",
        }


@dataclass(frozen=True)
class PlatformContainer:
    """Composition-root container holding injected ports (defaults: Cloudflare storage/edge + DigitalOcean SereneDB)."""

    provider: str
    storage: ObjectStoragePort
    search_host_provider: str = "digitalocean"
    search_host: SearchHostPort | None = None
    iceberg_catalog: IcebergCatalogPort | None = None
    search_engine: SearchEnginePort | None = None


def create_platform_container(
    *,
    provider: str | None = None,
    search_host_provider: str | None = None,
    account_id: str | None = None,
    bucket: str = "ddk-catalog",
    warehouse: str = "default",
    public_base_url: str | None = None,
    local_root: Path | str | None = None,
    droplet_id: int | str | None = None,
    droplet_tag: str | None = None,
    digitalocean_token: str | None = None,
    serenedb_url: str | None = None,
    serenedb_config: SereneDbConfig | None = None,
    storage: ObjectStoragePort | None = None,
    search_host: SearchHostPort | None = None,
    iceberg_catalog: IcebergCatalogPort | None = None,
    search_engine: SearchEnginePort | None = None,
    http_transport: HttpTransport | None = None,
) -> PlatformContainer:
    """Composition root constructing platform ports, **defaulting to Cloudflare + DigitalOcean SereneDB**."""
    selected = (provider or os.environ.get("DDK_PLATFORM") or "cloudflare").strip().lower()
    if selected not in {"cloudflare", "local"}:
        raise CatalogError("CATALOG-PLATFORM-UNKNOWN", f"Unsupported platform provider {selected!r}; expected 'cloudflare' or 'local'.")

    default_host = "local" if selected == "local" else "digitalocean"
    selected_host = (search_host_provider or os.environ.get("DDK_SEARCH_HOST") or default_host).strip().lower()
    if selected_host not in {"digitalocean", "local"}:
        raise CatalogError(
            "CATALOG-SEARCH-HOST-UNKNOWN",
            f"Unsupported search_host_provider {selected_host!r}; expected 'digitalocean' or 'local'.",
        )

    if storage is None:
        if selected == "local":
            if local_root is None:
                raise CatalogError("CATALOG-PLATFORM-CONFIG", "local platform provider requires local_root or an explicit storage adapter.")
            storage = LocalFilesystemStorageAdapter(local_root)
        else:
            storage = CloudflareR2StorageAdapter(
                bucket=bucket,
                account_id=account_id,
                public_base_url=public_base_url,
                http_transport=http_transport,
            )

    if search_host is None:
        if selected_host == "local":
            search_host = LocalSearchHostAdapter(
                state_dir=(Path(local_root) / "serenedb") if local_root else "/tmp/spicyengine-local",
                explicit_url=serenedb_url,
            )
        else:
            search_host = DigitalOceanDropletSearchHostAdapter(
                droplet_id=droplet_id,
                droplet_tag=droplet_tag,
                api_token=digitalocean_token,
                explicit_url=serenedb_url,
                http_transport=http_transport,
            )

    if iceberg_catalog is None and selected == "cloudflare":
        iceberg_catalog = CloudflareR2DataCatalogAdapter(
            account_id=account_id,
            warehouse=warehouse,
            http_transport=http_transport,
        )

    if search_engine is None:
        effective_url = serenedb_url
        if effective_url is None and selected_host == "digitalocean":
            # Resolve explicit URL or DigitalOcean API v2 Droplet IP when token + droplet are provided
            effective_url = search_host.resolve_endpoint()
        cfg = serenedb_config or SereneDbConfig.from_env(effective_url)
        if cfg is not None:
            search_engine = SereneDbSearchAdapter(cfg, http_transport=http_transport)

    return PlatformContainer(
        provider=selected,
        storage=storage,
        search_host_provider=selected_host,
        search_host=search_host,
        iceberg_catalog=iceberg_catalog,
        search_engine=search_engine,
    )
