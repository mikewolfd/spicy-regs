"""Capture standard catalog artifacts and verify their private/public pairing.

This module reads metadata only. A passed delivery check establishes the exact
artifact set, not data quality, row authorization, or native availability.
"""

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
import os
from pathlib import Path, PurePosixPath
import stat
from types import MappingProxyType

from blake3 import blake3

from .catalog_access import CatalogError
from .documents import freeze_json, parse_json, validate_document


OUTPUT_SET = "urn:ddk:catalog:output-set"
PAIRED_VIEW = "urn:ddk:catalog:paired-public-view:1"


@dataclass(frozen=True)
class CatalogArtifacts:
    directory: Path
    catalog: dict
    report: dict
    lock: dict
    lock_sha256: str
    companions: Mapping[str, bytes]
    artifacts: Mapping[str, bytes]
    externally_pinned: bool


def _need(condition, message):
    if not condition:
        raise CatalogError("CATALOG-DELIVERY", message)


def _read(root, name, maximum):
    _need(isinstance(name, str) and bool(name), "Artifact path must be a nonempty string")
    relative = PurePosixPath(name)
    _need(relative.as_posix() == name and not relative.is_absolute()
          and not any(part in {"", ".", ".."} for part in relative.parts) and "\\" not in name,
          "Unsafe standard artifact path")
    path = root.joinpath(*relative.parts)
    _need(path.resolve().is_relative_to(root), "Catalog artifact escapes its selected directory")
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        _need(stat.S_ISREG(info.st_mode) and info.st_size <= maximum,
              "Catalog artifact is not a bounded regular file")
        data = stream.read(maximum + 1)
    _need(len(data) <= maximum, "Catalog artifact exceeded its byte allocation")
    return data


def load_catalog_artifacts(directory, *, expected_lock_sha256=None, audience=None,
                           max_artifact_bytes=64 << 20, max_total_bytes=128 << 20,
                           max_lock_bytes=2 << 20, max_files=4096):
    """Capture one exact output set without reopening definitions or data.

    An external lock pin remains mandatory for data access or pairing. Optional
    unpinned loading supports local inspection only. All budgets are finite.
    """
    for value in (max_artifact_bytes, max_total_bytes, max_lock_bytes, max_files):
        _need(type(value) is int and value > 0, "Catalog delivery budgets must be positive integers")
    root = Path(directory).resolve(strict=True)
    _need(root.is_dir(), "Catalog output must be a directory")
    lock_bytes = _read(root, "catalog.lock.json", min(max_lock_bytes, max_total_bytes))
    digest = sha256(lock_bytes).hexdigest()
    _need(expected_lock_sha256 is None or digest == expected_lock_sha256,
          "Catalog lock differs from its selected external pin")
    lock = parse_json(lock_bytes)
    _need(not validate_document(lock, "lock"), "Invalid standard catalog lock")
    inventory = lock.get("extensions", {}).get(OUTPUT_SET)
    _need(isinstance(inventory, list) and len(inventory) <= max_files,
          "Missing or oversized standard output-set inventory")
    _need(all(isinstance(row, dict) and set(row) == {"path", "sha256", "role"}
              and all(type(row[key]) is str for key in row) for row in inventory),
          "Invalid output-set inventory entry")
    expected = {row["path"]: row for row in inventory}
    _need(len(expected) == len(inventory) and {"catalog.ddk.json", "catalog.report.json"} <= expected.keys()
          and "catalog.lock.json" not in expected, "Incomplete or duplicate standard artifact membership")
    remaining, content = max_total_bytes - len(lock_bytes), {}
    for name, row in expected.items():
        _need(remaining >= 0, "Catalog artifact set exceeded its total byte allocation")
        body = _read(root, name, min(max_artifact_bytes, remaining))
        _need(sha256(body).hexdigest() == row["sha256"], "Catalog artifact differs from its exact lock digest")
        remaining -= len(body)
        content[name] = body
    actual = set()
    for count, path in enumerate(root.rglob("*"), 1):
        _need(count <= max_files * 2, "Catalog directory exceeded its entry allocation")
        _need(not path.is_symlink(), "Catalog delivery cannot contain symbolic links")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
        else:
            _need(path.is_dir(), "Catalog delivery cannot contain special files")
    _need(actual == set(expected) | {"catalog.lock.json"}, "Catalog directory differs from its complete membership")
    catalog, report = parse_json(content["catalog.ddk.json"]), parse_json(content["catalog.report.json"])
    _need(not validate_document(catalog, "catalog") and not validate_document(report, "report"),
          "Invalid standard catalog or checking report")
    companions = {name: body for name, body in content.items() if name != "catalog.ddk.json"}
    catalog_files = {row["path"]: row for row in catalog["files"]}
    _need(len(catalog_files) == len(catalog["files"]) and set(catalog_files) == set(companions)
          and all(catalog_files[name] == expected[name] for name in companions),
          "Catalog and lock disagree on complete companion membership")
    _need(report["decision"] == "passed", "Stored artifact set does not carry a passed checking report")
    _need(audience is None or catalog["audience"] == audience, "Catalog audience differs from the requested boundary")
    _need(_read(root, "catalog.lock.json", max_lock_bytes) == lock_bytes,
          "Catalog directory changed while its artifact set was captured")
    return CatalogArtifacts(root, freeze_json(catalog), freeze_json(report), freeze_json(lock), digest, MappingProxyType(companions),
                            MappingProxyType({**content, "catalog.lock.json": lock_bytes}),
                            expected_lock_sha256 is not None)


def paired_view_record(public_catalog, local_catalog, public_lock_bytes):
    """Record the exact public output belonging to this admitted local view.

    Call only within shared assembly, before any private output is delivered.
    This association does not grant access to private fields or recipes.
    """
    _need(public_catalog["audience"] == "public" and local_catalog["audience"] == "local",
          "Catalog pairing requires explicit public and local views")
    local = {row["id"]: row for row in local_catalog["datasets"]}
    _need(len(local) == len(local_catalog["datasets"])
          and len({row["alias"] for row in local_catalog["datasets"]}) == len(local),
          "Local dataset identities and aliases must be unique")
    _need(len({row["id"] for row in public_catalog["datasets"]}) == len(public_catalog["datasets"])
          and len({row["alias"] for row in public_catalog["datasets"]}) == len(public_catalog["datasets"]),
          "Public dataset identities and aliases must be unique")
    datasets = []
    for row in public_catalog["datasets"]:
        _need(row["id"] in local, "Public dataset is outside the local assembly")
        datasets.append({"id": row["id"], "publicAlias": row["alias"], "localAlias": local[row["id"]]["alias"]})
    return {"catalog": public_catalog["id"], "publicLockSha256": sha256(public_lock_bytes).hexdigest(),
            "datasets": datasets}


def verify_catalog_pair(public, local):
    """Verify the two externally pinned views; return explicit alias bindings.

    Consumers must separately enforce public field authorization against the
    observed native schema. A private definition is never that authorization.
    """
    _need(public.externally_pinned and local.externally_pinned, "Both catalog views need external lock pins")
    p, q = public.catalog, local.catalog
    _need(p["audience"] == "public" and q["audience"] == "local" and p["id"] == q["id"]
          and p["project"] == q["project"], "Catalog views have different identity or audience")
    expected = paired_view_record(p, q, public.artifacts["catalog.lock.json"])
    _need(local.lock.get("extensions", {}).get(PAIRED_VIEW) == expected,
          "Private lock does not identify this exact public view and dataset mapping")
    aliases = {row["publicAlias"]: row["localAlias"] for row in expected["datasets"]}
    local_details = q.get("extensions", {}).get("urn:ddk:catalog:assembly", {})
    peer_public_to_local = {}
    for peer_alias, pub_imp in (p.get("imports") or {}).items():
        _need(peer_alias in (q.get("imports") or {}), "Public import is outside the paired local catalog")
        loc_imp = q["imports"][peer_alias]
        _need(pub_imp["audience"] == "public" and pub_imp["id"] == loc_imp["id"],
              "Paired import changed its audience or peer identity")
        peer_info = local_details.get("peerCatalogs", {}).get(peer_alias, {})
        if loc_imp["audience"] == "public":
            _need(pub_imp["lockSha256"] == loc_imp["lockSha256"], "Paired public import changed its lockSha256")
            peer_public_to_local[peer_alias] = {ds: ds for ds in peer_info.get("datasets", {})}
        else:
            paired_pub = peer_info.get("pairedPublic")
            _need(paired_pub is not None and pub_imp["lockSha256"] == paired_pub["lockSha256"],
                  "Paired import does not match the peer's paired public lock")
            peer_public_to_local[peer_alias] = {r["publicAlias"]: r["localAlias"] for r in paired_pub["datasets"]}
    datasets = {row["id"]: row for row in q["datasets"]}
    for row in p["datasets"]:
        source = datasets[row["id"]]
        _need(all(row["definition"].get(key) == source["definition"].get(key) for key in ("contractId", "version"))
              and row["definition"]["source"].get("sha256") == source["definition"]["source"].get("sha256"),
              "Paired dataset changed its source definition identity")
    relationships = {row["id"]: row for row in q["relationships"]}
    _need(len(relationships) == len(q["relationships"]), "Private relationship identities must be unique")
    for row in p["relationships"]:
        normalized = deepcopy(row)
        for side in ("source", "target"):
            if "catalog" in normalized[side]:
                peer_alias = normalized[side]["catalog"]
                _need(peer_alias in peer_public_to_local
                      and normalized[side]["dataset"] in peer_public_to_local[peer_alias],
                      "Paired cross-catalog relationship references an undisclosed peer dataset")
                normalized[side]["dataset"] = peer_public_to_local[peer_alias][normalized[side]["dataset"]]
            elif "dataset" in normalized[side]:
                normalized[side]["dataset"] = aliases[normalized[side]["dataset"]]
        orig = relationships.get(row["id"])
        if orig is not None and "joinMetrics" in normalized and "joinMetrics" in orig:
            pub_rec = normalized["joinMetrics"]["record"]
            loc_rec = orig["joinMetrics"]["record"]
            expected_redacted = {
                **loc_rec,
                "uri": f"urn:ddk:sha256:{loc_rec['sha256']}" if "sha256" in loc_rec else "urn:ddk:withheld",
            }
            if pub_rec == expected_redacted:
                normalized["joinMetrics"]["record"] = deepcopy(loc_rec)
        _need(orig == normalized,
              "Paired relationship changed its endpoint, matching, scope or resolution meaning")
    public_versions = {row["id"] for row in p["versions"]}
    for section in ("versions", "representations", "recipes", "releases"):
        private = {row["id"]: row for row in q[section]}
        _need(len(private) == len(q[section]) and len({row["id"] for row in p[section]}) == len(p[section]),
              "Access record identities must be unique in each catalog view")
        for row in p[section]:
            _need(row["id"] in private, "Public access record is outside the paired local catalog")
            source = private[row["id"]]
            if section == "versions":
                _need(aliases[row["dataset"]] == source["dataset"] and row["retention"] == source["retention"]
                      and ("reference" not in row or row["reference"] == source["reference"]),
                      "Paired version changed its dataset, retention or native identity")
            elif section == "representations":
                _need(all(row.get(key) == source.get(key)
                          for key in ("version", "kind", "availability", "location", "mediaType", "byteSize", "rowCount"))
                      and ("members" not in row or row["members"] == source.get("members")),
                      "Paired representation changed its exact access meaning")
            elif section == "releases":
                members = [member for member in source["members"] if member in public_versions]
                membership = source["membership"]
                if len(members) != len(source["members"]) and membership == "complete":
                    membership = "partial"
                _need(row["members"] == members and row["membership"] == membership
                      and ("reference" not in row or row["reference"] == source["reference"]),
                      "Paired release changed its membership, completeness or native identity")
            else:
                mapped_inputs = {}
                for key, val in row["inputs"].items():
                    if isinstance(val, str):
                        mapped_inputs[key] = aliases[val]
                    else:
                        peer_alias = val["catalog"]
                        _need(peer_alias in peer_public_to_local
                              and val["dataset"] in peer_public_to_local[peer_alias],
                              "Paired recipe references an undisclosed peer dataset")
                        mapped_inputs[key] = {"catalog": peer_alias,
                                              "dataset": peer_public_to_local[peer_alias][val["dataset"]]}
                _need(mapped_inputs == source["inputs"],
                      "Paired recipe changed its named input mapping")
                _need(("resultDataset" not in row or aliases[row["resultDataset"]] == source.get("resultDataset"))
                      and all(row.get(key) == source.get(key) for key in ("sql", "dialect", "parameters", "parameterOrder", "relationships", "resultGrain"))
                      and public.companions[row["sql"]] == local.companions[source["sql"]],
                      "Paired recipe changed its SQL or parameter meaning")
    selection_keys = ("authority", "purpose", "release", "observedAt")
    for row in p["selections"]:
        matches = [source for source in q["selections"]
                   if all(row.get(key) == source.get(key) for key in selection_keys)]
        _need(len(matches) == 1, "Paired selection changed its authority, purpose, release or observation")
    _verify_paired_concepts(p, q, aliases, peer_public_to_local)
    if "series" in p:
        local_series = {s["id"]: s for s in q.get("series", ())}
        for row in p["series"]:
            _need(row["id"] in local_series, "Paired series missing in local catalog")
            source = local_series[row["id"]]
            mapped_members = [{"dataset": aliases[m["dataset"]], "edition": m["edition"]}
                              for m in source["members"] if m["dataset"] in aliases]
            _need(row["members"] == mapped_members, "Paired series members changed")
    _need(p.get("currentSelection") == q.get("currentSelection"),
          "Paired catalogs request different current selections")
    return deepcopy(aliases)


def _verify_paired_concepts(public_catalog, local_catalog, aliases, peer_public_to_local=None):
    from .catalog_graph import child_iri

    peer_public_to_local = peer_public_to_local or {}
    peer_local_to_public = {
        peer_alias: {loc_ds: pub_ds for pub_ds, loc_ds in mapping.items()}
        for peer_alias, mapping in peer_public_to_local.items()
    }
    details = public_catalog.get("extensions", {}).get("urn:ddk:catalog:assembly", {})
    disclosed_paths = details.get("disclosedDefinitionPaths", {})
    peer_summaries = details.get("peerCatalogs", {})
    inverse_aliases = {local_alias: public_alias for public_alias, local_alias in aliases.items()}
    local_concepts = local_catalog.get("concepts", ())
    public_concepts = public_catalog.get("concepts", ())
    _need(len({row["concept"] for row in local_concepts}) == len(local_concepts)
          and len({row["concept"] for row in public_concepts}) == len(public_concepts),
          "Concept identities must be unique in each catalog view")
    matched_local = set()
    for row in public_concepts:
        candidates = [
            source for source in local_concepts
            if row["definition"] in {source["definition"], "public-" + sha256(source["definition"].encode()).hexdigest()}
        ]
        _need(len(candidates) == 1, "Public concept does not match one shared definition in the local catalog")
        source = candidates[0]
        matched_local.add(source["definition"])
        expected_local = [
            {"dataset": inverse_aliases[field["dataset"]], "path": field["path"]}
            for field in source["fields"]
            if "catalog" not in field and field["dataset"] in inverse_aliases
            and field["path"] in disclosed_paths.get(inverse_aliases[field["dataset"]], ())
        ]
        expected_peer = []
        for field in source["fields"]:
            if "catalog" not in field:
                continue
            peer_alias = field["catalog"]
            mapping = peer_local_to_public.get(peer_alias, {})
            if field["dataset"] not in mapping:
                continue
            pub_ds = mapping[field["dataset"]]
            peer_summary = peer_summaries.get(peer_alias, {})
            if ("disclosedDefinitionPaths" in peer_summary
                    and field["path"] not in peer_summary["disclosedDefinitionPaths"].get(pub_ds, ())):
                continue
            expected_peer.append({"catalog": peer_alias, "dataset": pub_ds, "path": field["path"]})
        expected_fields = [*expected_local, *expected_peer]
        minted = child_iri(public_catalog["id"], "concept", row["definition"])
        _need(row["concept"] in {source["concept"], minted}
              and row.get("conceptKind") == source.get("conceptKind")
              and ("iriTemplate" not in row or row["iriTemplate"] == source.get("iriTemplate"))
              and list(row["fields"]) == expected_fields and bool(expected_local)
              and ("description" not in row or row["description"] == source.get("description"))
              and all(set(row.get(key, ())) <= set(source.get(key, ()))
                      for key in ("exactMatch", "closeMatch", "canonicalUrls")),
              "Paired concept changed its identity, kind, carrier fields or vocabulary links")
    for source in local_concepts:
        has_disclosed_field = any(
            "catalog" not in field and field["dataset"] in inverse_aliases
            and field["path"] in disclosed_paths.get(inverse_aliases[field["dataset"]], ())
            for field in source["fields"]
        )
        _need(not has_disclosed_field or source["definition"] in matched_local,
              "Paired public catalog omits a concept carried by a disclosed field")


_DEFAULT_ARTIFACT_CONTENT_TYPES = {
    ".json": "application/json",
    ".sql": "text/sql",
    ".md": "text/markdown",
    ".txt": "text/plain",
}
_REQUIRED_RELEASE_ARTIFACTS = frozenset({"catalog.ddk.json", "catalog.lock.json", "catalog.report.json"})


@dataclass(frozen=True)
class FrozenCatalogArtifact:
    name: str
    content_type: str
    size: int
    sha256: str
    blake3: str
    bytes: bytes


@dataclass(frozen=True)
class FrozenCatalogRelease:
    directory: Path
    catalog: dict
    report: dict
    lock: dict
    lock_sha256: str
    catalog_sha256: str
    artifacts: tuple[FrozenCatalogArtifact, ...]


def _artifact_content_type(name, overrides=None):
    if overrides and name in overrides:
        return overrides[name]
    suffix = PurePosixPath(name).suffix.lower()
    return _DEFAULT_ARTIFACT_CONTENT_TYPES.get(suffix, "application/octet-stream")


def export_frozen_catalog_release(directory_or_artifacts, *, expected_lock_sha256=None, audience=None,
                                  content_types=None):
    """Pin an exact delivered catalog directory into immutable remote-release artifact specs."""
    if isinstance(directory_or_artifacts, CatalogArtifacts):
        captured = directory_or_artifacts
        _need(expected_lock_sha256 is None or captured.lock_sha256 == expected_lock_sha256,
              "Catalog lock differs from its selected external pin")
        _need(captured.report.get("decision") == "passed",
              "Stored artifact set does not carry a passed checking report")
        _need(audience is None or captured.catalog.get("audience") == audience,
              "Catalog audience differs from the requested boundary")
    else:
        captured = load_catalog_artifacts(
            directory_or_artifacts,
            expected_lock_sha256=expected_lock_sha256,
            audience=audience,
        )
    _need(_REQUIRED_RELEASE_ARTIFACTS <= set(captured.artifacts),
          "Frozen catalog release requires catalog.ddk.json, catalog.lock.json, and catalog.report.json")
    inventory = captured.lock.get("extensions", {}).get(OUTPUT_SET, ())
    expected_digests = {row["path"]: row["sha256"] for row in inventory}
    expected_digests["catalog.lock.json"] = captured.lock_sha256
    pinned = []
    for name in sorted(captured.artifacts):
        body = captured.artifacts[name]
        digest = sha256(body).hexdigest()
        _need(expected_digests.get(name) == digest,
              f"Catalog artifact {name} differs from its pinned lock digest")
        ctype = _artifact_content_type(name, content_types)
        _need(isinstance(ctype, str) and bool(ctype), "Artifact content type must be a nonempty string")
        pinned.append(FrozenCatalogArtifact(
            name=name,
            content_type=ctype,
            size=len(body),
            sha256=digest,
            blake3=blake3(body).hexdigest(),
            bytes=body,
        ))
    catalog_entry = next(item for item in pinned if item.name == "catalog.ddk.json")
    return FrozenCatalogRelease(
        directory=captured.directory,
        catalog=captured.catalog,
        report=captured.report,
        lock=captured.lock,
        lock_sha256=captured.lock_sha256,
        catalog_sha256=catalog_entry.sha256,
        artifacts=tuple(pinned),
    )
