"""Data Design Kit: offline checks and explicitly selected integrations."""

__version__ = "0.2.0"
