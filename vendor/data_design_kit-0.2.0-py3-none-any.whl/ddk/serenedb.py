"""SereneDB (spicyengine) manifest compiler, index DDL generator, and remote search adapter.

Integrates DDK evidence-bound catalogs with a dedicated SereneDB / ``spicyengine``
service (typically running on a dedicated VM such as a DigitalOcean Droplet behind
Cloudflare Tunnel or HTTPS reverse proxy while reading Parquet/Iceberg inputs from
Cloudflare R2 at zero egress).
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
import json
import os
import re
from typing import Any
import urllib.error
from urllib.parse import quote, urlencode, urlsplit
import urllib.request

from .catalog_access import DEFAULT_HTTP_USER_AGENT, CatalogError, row_identity_names
from .documents import json_dumps, parse_json

SERENEDB_ADAPTER = {"id": "ddk.catalog.serenedb", "version": "0.1.0"}
SEGMENT_MEMORY_BYTES = 32 * 1024**2
INDEX_ROW_GROUP_ROWS = 16 * 1024
DICTIONARY_NAME = "spicy_english"
FRAGMENTS_NAME = "spicy_fragments"
INDEX_NAME = "spicy_inverted_idx"
VIEW_NAME = "search_input"
_SOURCE_ID_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_SQL_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")

DICTIONARY_SQL = (
    f"CREATE TEXT SEARCH DICTIONARY {DICTIONARY_NAME} AS "
    "split_text(case => 'lower') | stem_words('en_US.UTF-8') WITH (frequency, norm, position, offset); "
    f"CREATE TEXT SEARCH DICTIONARY {FRAGMENTS_NAME} AS "
    r"split_by_pattern('\p{L}+|\p{N}+', group := 0) | normalize_tokens(case := 'lower') WITH (frequency, norm)"
)

HttpTransport = Callable[[str, str, dict[str, str], bytes | None, float], tuple[int, dict[str, str], bytes]]


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Refuse HTTP redirects so service auth headers never leave the configured SereneDB origin."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "Redirects are refused on SereneDB transport", headers, fp)


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _quote_literal(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def normalize_serenedb_source_id(dataset_alias: str) -> str:
    """Map a DDK dataset alias (e.g. ``source/regulations-comments``) to a valid SereneDB ``source_id``."""
    cleaned = re.sub(r"[^a-z0-9_-]+", "-", dataset_alias.lower().replace("/", "--")).strip("-_")
    if not cleaned or not cleaned[0].isalpha():
        cleaned = "ds-" + cleaned
    cleaned = cleaned[:64].rstrip("-_")
    if not _SOURCE_ID_RE.fullmatch(cleaned):
        raise CatalogError("CATALOG-SERENEDB-SOURCE-ID", f"Cannot derive valid SereneDB source_id from {dataset_alias!r}")
    return cleaned


def _validate_input_source(input_source: dict[str, Any]) -> tuple[str, str]:
    if not isinstance(input_source, dict) or len(input_source) != 1 or not set(input_source) <= {"parquet", "iceberg", "table"}:
        raise CatalogError(
            "CATALOG-SERENEDB-INPUT",
            "SereneDB input must name exactly one of 'parquet', 'iceberg', or 'table'.",
        )
    kind, location = next(iter(input_source.items()))
    if not isinstance(location, str) or not location or len(location) > 4096:
        raise CatalogError("CATALOG-SERENEDB-INPUT", "SereneDB input location must be 1..4096 characters.")
    if kind == "table":
        parts = location.split(".")
        if len(parts) != 3 or any(not _SQL_IDENT_RE.fullmatch(part) for part in parts):
            raise CatalogError("CATALOG-SERENEDB-INPUT", "Native SereneDB table input must be catalog.schema.table.")
    else:
        parsed = urlsplit(location)
        if not (location.startswith("/") or parsed.scheme in {"https", "s3"}):
            raise CatalogError("CATALOG-SERENEDB-INPUT", "SereneDB file/table location must be an absolute path or https/s3 URL.")
        if parsed.scheme and (parsed.username or parsed.password or parsed.query or parsed.fragment):
            raise CatalogError("CATALOG-SERENEDB-CREDENTIALS", "Keep credentials out of SereneDB input URLs.")
    return kind, location


def _custom_search_role(prop: dict[str, Any]) -> str | None:
    for item in prop.get("customProperties") or ():
        if isinstance(item, dict) and item.get("vendor") == "ddk" and item.get("property") == "searchRole":
            val = item.get("value")
            if isinstance(val, str):
                return val
    return None


def infer_serenedb_fields(odcs_schema: dict[str, Any], *, field_overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    """Infer or validate ``spicyengine`` field roles from an ODCS 3.x object definition."""
    props = [p for p in (odcs_schema.get("properties") or ()) if isinstance(p, dict) and isinstance(p.get("name"), str)]
    by_name = {p["name"]: p for p in props}
    overrides = dict(field_overrides or {})

    title_col: str | None = overrides.get("title")
    text_cols: list[str] = list(overrides.get("text") or [])
    url_col: str | None = overrides.get("url")
    ident_col: str | None = overrides.get("identifiers")
    date_col: str | None = overrides.get("date_default")
    embedding_cfg = overrides.get("embedding")

    for p in props:
        name = p["name"]
        role = _custom_search_role(p)
        if role == "exclude":
            continue
        if role == "title" and not title_col:
            title_col = name
        elif role == "text" and name not in text_cols:
            text_cols.append(name)
        elif role == "url" and not url_col:
            url_col = name
        elif role == "identifiers" and not ident_col:
            ident_col = name
        elif role == "date_default" and not date_col:
            date_col = name

    string_cols = [
        p["name"]
        for p in props
        if p.get("logicalType") == "string"
        and "[]" not in str(p.get("physicalType", ""))
        and _custom_search_role(p) != "exclude"
    ]
    if not title_col:
        for candidate in ("title", "caption", "subject", "heading", "name", "official_title", "short_title", "summary"):
            if candidate in string_cols:
                title_col = candidate
                break
    if not text_cols:
        for p in props:
            n = p["name"]
            if n not in string_cols or n == title_col:
                continue
            if any(tok in n for tok in ("body", "text", "markdown", "content", "transcript", "abstract", "description", "summary", "statement", "question", "comment")):
                text_cols.append(n)
    if not url_col:
        for candidate in ("source_url", "url", "html_url", "download_url", "govinfo_url", "document_url"):
            if candidate in string_cols:
                url_col = candidate
                break
    if not ident_col:
        for p in props:
            if p.get("logicalType") == "array" or "[]" in str(p.get("physicalType", "")):
                if p["name"] in {"identifiers", "docket_ids", "rins", "cfr_references", "bill_ids"}:
                    ident_col = p["name"]
                    break
    if not date_col:
        for p in props:
            if p.get("logicalType") in {"date", "timestamp"} or str(p.get("physicalType", "")).upper() in {"DATE", "TIMESTAMP", "TIMESTAMPTZ"}:
                date_col = p["name"]
                break

    # Fall back to title_col as searchable text when a table only has title/heading text
    if not text_cols and title_col:
        text_cols = [title_col]

    fields: dict[str, Any] = {}
    if title_col and title_col in by_name:
        fields["title"] = title_col
    if text_cols:
        fields["text"] = [c for c in text_cols if c in by_name]
    if url_col and url_col in by_name:
        fields["url"] = url_col
    if ident_col and ident_col in by_name:
        fields["identifiers"] = ident_col
    if date_col and date_col in by_name:
        fields["date_default"] = date_col
    if embedding_cfg is not None:
        fields["embedding"] = deepcopy(embedding_cfg)
    return fields


def compile_serenedb_dataset_manifest(
    dataset_entry: dict[str, Any],
    odcs_schema: dict[str, Any],
    *,
    input_source: dict[str, Any],
    field_overrides: dict[str, Any] | None = None,
    facet_labels: dict[str, dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Compile a DDK dataset + ODCS schema into a valid ``spicyengine`` ``dataset.json`` manifest."""
    _validate_input_source(input_source)
    fields = infer_serenedb_fields(odcs_schema, field_overrides=field_overrides)
    if not fields.get("text"):
        raise CatalogError(
            "CATALOG-SERENEDB-NO-TEXT",
            f"Dataset {dataset_entry.get('alias') or dataset_entry.get('id')!r} has no searchable text columns for SereneDB.",
        )
    raw_label = str(dataset_entry.get("title") or odcs_schema.get("name") or dataset_entry.get("alias") or "Search dataset").strip()
    label = raw_label[:200] if raw_label else "Search dataset"
    manifest: dict[str, Any] = {
        "input": deepcopy(input_source),
        "label": label,
        "fields": fields,
    }
    if facet_labels:
        manifest["facet_labels"] = deepcopy(facet_labels)
    return manifest


def compile_serenedb_index_sql(
    dataset_alias: str,
    odcs_schema: dict[str, Any],
    *,
    input_source: dict[str, Any],
    field_overrides: dict[str, Any] | None = None,
) -> dict[str, str]:
    """Compile SereneDB preparation view SQL and ``USING inverted (...) INCLUDE (...)`` index DDL."""
    kind, location = _validate_input_source(input_source)
    if kind == "table":
        scan_sql = ".".join(_quote_ident(part) for part in location.split("."))
    else:
        fn = "read_parquet" if kind == "parquet" else "iceberg_scan"
        scan_sql = f"{fn}({_quote_literal(location)})"

    props = [p for p in (odcs_schema.get("properties") or ()) if isinstance(p, dict) and isinstance(p.get("name"), str)]
    prop_names = [p["name"] for p in props]
    pk_names = row_identity_names(odcs_schema) or []
    if not pk_names:
        raise CatalogError("CATALOG-SERENEDB-KEY", f"Dataset {dataset_alias!r} requires a primary key for SereneDB member_key.")

    source_id = normalize_serenedb_source_id(dataset_alias)
    select_exprs: list[str] = []
    if "source_id" not in prop_names:
        select_exprs.append(f"{_quote_literal(source_id)} AS {_quote_ident('source_id')}")
    if "member_key" not in prop_names:
        if len(pk_names) == 1:
            mk_expr = f"CAST({_quote_ident(pk_names[0])} AS VARCHAR)"
        else:
            parts = " || ':' || ".join(f"CAST({_quote_ident(k)} AS VARCHAR)" for k in pk_names)
            mk_expr = f"({parts})"
        select_exprs.append(f"{mk_expr} AS {_quote_ident('member_key')}")
    select_exprs.extend(_quote_ident(n) for n in prop_names)
    view_sql = f"CREATE OR REPLACE VIEW {VIEW_NAME} AS SELECT {', '.join(select_exprs)} FROM {scan_sql}"

    fields = infer_serenedb_fields(odcs_schema, field_overrides=field_overrides)
    text_cols = list(fields.get("text") or ())
    if not text_cols:
        raise CatalogError("CATALOG-SERENEDB-NO-TEXT", f"Dataset {dataset_alias!r} has no text columns to index.")

    idx_cols: list[str] = [_quote_ident("member_key"), _quote_ident("source_id")]
    if fields.get("identifiers"):
        idx_cols.append(_quote_ident(fields["identifiers"]))
    for tc in text_cols:
        idx_cols.append(f"{_quote_ident(tc)} {DICTIONARY_NAME}")
    if fields.get("title") and fields["title"] not in text_cols:
        idx_cols.append(f"({_quote_ident(fields['title'])}) {FRAGMENTS_NAME}")

    for p in props:
        n = p["name"]
        if n in {"source_id", "member_key", fields.get("identifiers")}:
            continue
        if p.get("logicalType") == "array" or "[]" in str(p.get("physicalType", "")):
            idx_cols.append(_quote_ident(n))
        elif p.get("logicalType") in {"date", "timestamp"} or str(p.get("physicalType", "")).upper() in {"DATE", "TIMESTAMP", "TIMESTAMPTZ"}:
            idx_cols.append(_quote_ident(n))

    stored_cols = ["source_id", "member_key", *[n for n in prop_names if n not in {"source_id", "member_key"}]]
    emb = fields.get("embedding")
    if isinstance(emb, dict) and isinstance(emb.get("column"), str):
        vec_col = emb["column"]
        idx_cols.append(f"{_quote_ident(vec_col)} hnsw (metric='cosine')")
        if vec_col in stored_cols:
            stored_cols.remove(vec_col)

    index_sql = (
        f"CREATE OR REPLACE INDEX {INDEX_NAME} ON {VIEW_NAME} "
        f"USING inverted ({', '.join(idx_cols)}) "
        f"INCLUDE ({', '.join(_quote_ident(c) for c in stored_cols)}) "
        f"WITH (optimize_top_k = 'bm25(1.2, 0.75)', "
        f"segment_memory_max = {SEGMENT_MEMORY_BYTES}, row_group_size = {INDEX_ROW_GROUP_ROWS})"
    )
    return {
        "sourceId": source_id,
        "dictionarySql": DICTIONARY_SQL,
        "viewSql": view_sql,
        "indexSql": index_sql,
    }


def compile_serenedb_corpus_sql(
    entries: Sequence[Mapping[str, Any]],
    *,
    defs: Mapping[str, Any] | None = None,
) -> str:
    """Compile a DataFusion ``UNION ALL`` query unifying all disclosed searchable datasets into ``spicyengine``'s schema."""
    if not entries:
        return ""
    selects: list[str] = []
    for entry in entries:
        alias = str(entry["dataset"])
        source_id = str(entry["sourceId"])
        pk = list(entry.get("primaryKey") or ())
        manifest = entry["manifest"]
        input_spec = manifest["input"]
        kind, location = _validate_input_source(input_spec)
        if kind == "table":
            scan_sql = ".".join(_quote_ident(part) for part in location.split("."))
        else:
            fn = "read_parquet" if kind == "parquet" else "iceberg_scan"
            scan_sql = f"{fn}({_quote_literal(location)})"

        fields = manifest.get("fields") or {}
        schema_props = {
            p["name"]: p
            for p in ((defs or {}).get(alias) or {}).get("properties", ())
            if isinstance(p, dict) and isinstance(p.get("name"), str)
        }

        if len(pk) == 1:
            mk_expr = f"CAST({_quote_ident(pk[0])} AS VARCHAR)"
        else:
            mk_expr = "(" + " || ':' || ".join(f"CAST({_quote_ident(k)} AS VARCHAR)" for k in pk) + ")"

        text_cols = [c for c in (fields.get("text") or ()) if isinstance(c, str) and c]
        title_col = fields.get("title") or (text_cols[0] if text_cols else None)
        title_expr = (
            f"COALESCE(CAST({_quote_ident(title_col)} AS VARCHAR), '')"
            if title_col
            else "CAST(NULL AS VARCHAR)"
        )
        if len(text_cols) == 1:
            body_expr = f"COALESCE(CAST({_quote_ident(text_cols[0])} AS VARCHAR), '')"
        elif len(text_cols) > 1:
            cols_sql = ", ".join(f"CAST({_quote_ident(c)} AS VARCHAR)" for c in text_cols)
            body_expr = f"CONCAT_WS(' ', {cols_sql})"
        else:
            body_expr = "''"

        url_col = fields.get("url")
        url_expr = f"CAST({_quote_ident(url_col)} AS VARCHAR)" if url_col else "CAST(NULL AS VARCHAR)"

        ident_col = fields.get("identifiers")
        if ident_col:
            prop_meta = schema_props.get(ident_col) or {}
            is_arr = prop_meta.get("logicalType") == "array" or "[]" in str(prop_meta.get("physicalType", ""))
            ident_expr = (
                _quote_ident(ident_col)
                if is_arr or not schema_props
                else f"make_array(CAST({_quote_ident(ident_col)} AS VARCHAR))"
            )
        else:
            ident_expr = "CAST(NULL AS VARCHAR[])"

        date_col = fields.get("date_default")
        pub_expr = f"CAST({_quote_ident(date_col)} AS TIMESTAMP)" if date_col else "CAST(NULL AS TIMESTAMP)"

        tags_expr = f"make_array({_quote_literal(alias)}, {_quote_literal(source_id)})"
        cols = [
            f"{_quote_literal(source_id)} AS {_quote_ident('source_id')}",
            f"{mk_expr} AS {_quote_ident('member_key')}",
            f"{title_expr} AS {_quote_ident('title')}",
            f"{body_expr} AS {_quote_ident('body')}",
            f"{url_expr} AS {_quote_ident('source_url')}",
            f"{ident_expr} AS {_quote_ident('identifiers')}",
            f"{pub_expr} AS {_quote_ident('published')}",
            f"{tags_expr} AS {_quote_ident('dataset_tags')}",
        ]
        selects.append(f"SELECT {', '.join(cols)} FROM {scan_sql}")
    return "\nUNION ALL\n".join(selects)


def serenedb_catalog_document(
    catalog: dict[str, Any],
    *,
    r2_base_url: str | None = None,
) -> dict[str, Any]:
    """Build a ``serenedb.search.json`` export bundle for all text-searchable datasets in ``catalog``."""
    ext = ((catalog.get("extensions") or {}).get("urn:ddk:catalog:assembly") or {})
    defs = ext.get("datasetDefinitions") or {}
    disclosed_paths = ext.get("disclosedDefinitionPaths") or {}
    base = (r2_base_url or "s3://ddk-catalog").rstrip("/")

    entries: list[dict[str, Any]] = []
    filtered_defs: dict[str, Any] = {}
    for ds in catalog.get("datasets") or ():
        alias = ds["alias"]
        schema = defs.get(alias)
        if not isinstance(schema, dict):
            continue
        # Respect public disclosure field filtering if present
        filtered_schema = deepcopy(schema)
        if catalog.get("audience") == "public" and alias in disclosed_paths:
            allowed = {
                kp[0]["field"]
                for kp in disclosed_paths[alias]
                if isinstance(kp, list) and len(kp) == 1 and "field" in kp[0]
            }
            filtered_schema["properties"] = [
                p for p in (filtered_schema.get("properties") or ()) if p.get("name") in allowed
            ]
        pk = row_identity_names(filtered_schema)
        fields = infer_serenedb_fields(filtered_schema)
        if not pk or not fields.get("text"):
            continue
        filtered_defs[alias] = filtered_schema
        input_source = {"parquet": f"{base}/{alias}/*.parquet"}
        manifest = compile_serenedb_dataset_manifest(ds, filtered_schema, input_source=input_source)
        ddl = compile_serenedb_index_sql(alias, filtered_schema, input_source=input_source)
        entries.append({
            "dataset": alias,
            "datasetId": ds["id"],
            "sourceId": ddl["sourceId"],
            "primaryKey": pk,
            "manifest": manifest,
            "ddl": ddl,
        })

    doc: dict[str, Any] = {
        "schemaVersion": "ddk-serenedb-export-v1",
        "catalogId": catalog["id"],
        "catalogVersion": catalog["version"],
        "audience": catalog["audience"],
        "adapter": SERENEDB_ADAPTER,
        "datasets": entries,
    }
    if entries:
        corpus_parquet_uri = f"{base}/_serenedb/corpus.parquet"
        corpus_label = str(catalog.get("title") or catalog.get("id") or "Search corpus").strip()[:200] or "Search corpus"
        doc["corpus"] = {
            "parquetUri": corpus_parquet_uri,
            "sql": compile_serenedb_corpus_sql(entries, defs=filtered_defs),
            "sources": [entry["sourceId"] for entry in entries],
            "manifest": {
                "input": {"parquet": corpus_parquet_uri},
                "label": corpus_label,
                "fields": {
                    "title": "title",
                    "text": ["body"],
                    "url": "source_url",
                    "identifiers": "identifiers",
                    "date_default": "published",
                },
            },
        }
    return doc


def decode_member_key(member_key: str, pk_fields: list[tuple[str, str | None]]) -> dict[str, Any]:
    """Decode a SereneDB ``member_key`` back into a typed DDK primary-key mapping."""
    if not pk_fields:
        return {"member_key": member_key}
    if len(pk_fields) == 1:
        name, ltype = pk_fields[0]
        if ltype == "integer":
            try:
                return {name: int(member_key)}
            except ValueError:
                return {name: member_key}
        return {name: member_key}
    parts = member_key.split(":", maxsplit=len(pk_fields) - 1)
    result: dict[str, Any] = {}
    for idx, (name, ltype) in enumerate(pk_fields):
        raw = parts[idx] if idx < len(parts) else ""
        if ltype == "integer":
            try:
                result[name] = int(raw)
                continue
            except ValueError:
                pass
        result[name] = raw
    return result


def default_serenedb_http_transport(
    method: str,
    url: str,
    headers: dict[str, str],
    body: bytes | None,
    timeout: float,
) -> tuple[int, dict[str, str], bytes]:
    """Default stdlib HTTP/HTTPS transport refusing redirects so auth headers never leave the origin."""
    opener = urllib.request.build_opener(_NoRedirectHandler)
    req_headers = dict(headers)
    if not any(k.lower() == "user-agent" for k in req_headers):
        req_headers["User-Agent"] = DEFAULT_HTTP_USER_AGENT
    req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
    try:
        with opener.open(req, timeout=timeout) as resp:
            status = getattr(resp, "status", 200)
            resp_headers = {k.lower(): v for k, v in resp.headers.items()}
            return status, resp_headers, resp.read()
    except urllib.error.HTTPError as exc:
        resp_headers = {k.lower(): v for k, v in (exc.headers.items() if exc.headers else ())}
        payload = exc.read() if exc.fp is not None else b""
        return exc.code, resp_headers, payload


@dataclass
class SereneDbConfig:
    """Connection configuration for a remote SereneDB / ``spicyengine`` instance (e.g. DigitalOcean Droplet)."""

    base_url: str
    bearer_token: str | None = None
    cf_access_client_id: str | None = None
    cf_access_client_secret: str | None = None
    timeout_seconds: float = 10.0

    @classmethod
    def from_env(cls, base_url: str | None = None) -> SereneDbConfig | None:
        resolved_url = (base_url or os.environ.get("DDK_SERENEDB_URL") or os.environ.get("SERENEDB_URL") or "").strip()
        if not resolved_url:
            return None
        return cls(
            base_url=resolved_url,
            bearer_token=(os.environ.get("DDK_SERENEDB_TOKEN") or "").strip() or None,
            cf_access_client_id=(os.environ.get("CF_ACCESS_CLIENT_ID") or "").strip() or None,
            cf_access_client_secret=(os.environ.get("CF_ACCESS_CLIENT_SECRET") or "").strip() or None,
            timeout_seconds=float(os.environ.get("DDK_SERENEDB_TIMEOUT_SECONDS") or "10.0"),
        )


class SereneDbSearchAdapter:
    """Authoritative ``SearchEnginePort`` client speaking ``spicyengine``'s ``/v1/*`` HTTP protocol."""

    def __init__(
        self,
        config: SereneDbConfig | str,
        *,
        http_transport: HttpTransport | None = None,
    ) -> None:
        if isinstance(config, str):
            config = SereneDbConfig(base_url=config)
        parsed = urlsplit(config.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise CatalogError("CATALOG-SERENEDB-URL", "SereneDB base_url must be an explicit http:// or https:// URL.")
        if parsed.username or parsed.password:
            raise CatalogError("CATALOG-SERENEDB-CREDENTIALS", "Pass SereneDB tokens via headers/env, never in base_url.")
        self._config = config
        self._base_url = config.base_url.rstrip("/")
        self._transport = http_transport or default_serenedb_http_transport
        self._cached_config_version: str | None = None

    @property
    def base_url(self) -> str:
        return self._base_url

    def _scrub_secrets(self, text: str) -> str:
        out = str(text)
        for secret in (
            self._config.bearer_token,
            self._config.cf_access_client_id,
            self._config.cf_access_client_secret,
        ):
            if secret:
                out = out.replace(secret, "[REDACTED]")
        return out

    def _auth_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self._config.bearer_token:
            headers["Authorization"] = f"Bearer {self._config.bearer_token}"
        if self._config.cf_access_client_id and self._config.cf_access_client_secret:
            headers["CF-Access-Client-Id"] = self._config.cf_access_client_id
            headers["CF-Access-Client-Secret"] = self._config.cf_access_client_secret
        return headers

    def _request_json(self, method: str, path: str, payload: dict[str, Any] | None = None) -> tuple[int, Any]:
        url = f"{self._base_url}{path}"
        headers = self._auth_headers()
        body = None
        if payload is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
            body = json_dumps(payload).encode("utf-8")
        try:
            status, _, raw = self._transport(method, url, headers, body, self._config.timeout_seconds)
        except Exception as exc:
            safe_msg = self._scrub_secrets(f"SereneDB endpoint unreachable ({type(exc).__name__}): {exc}")
            raise CatalogError("CATALOG-SEARCH-UNAVAILABLE", safe_msg, status="unknown") from None

        if status in {301, 302, 303, 307, 308}:
            raise CatalogError("CATALOG-SEARCH-REDIRECT-REFUSED", "SereneDB transport refused an unexpected HTTP redirect.", status="unknown")
        if status in {502, 503, 504} or status >= 500:
            raise CatalogError(
                "CATALOG-SEARCH-UNAVAILABLE",
                f"SereneDB origin returned HTTP {status}; search is temporarily unavailable while R2 catalog access remains online.",
                status="unknown",
            )
        parsed_body: Any = None
        if raw:
            try:
                parsed_body = parse_json(raw)
            except Exception:
                parsed_body = {"error": self._scrub_secrets(raw.decode("utf-8", errors="replace")[:256])}
        return status, parsed_body

    def catalogs(self) -> dict[str, Any]:
        status, data = self._request_json("GET", "/v1/catalogs")
        if status != 200 or not isinstance(data, dict):
            raise CatalogError("CATALOG-SEARCH-ERROR", f"SereneDB /v1/catalogs failed with HTTP {status}")
        if isinstance(data.get("configVersion"), str):
            self._cached_config_version = data["configVersion"]
        return data

    def _catalog_index_maps(
        self,
        catalog: dict[str, Any] | None,
        audience: str,
    ) -> tuple[dict[str, str], dict[str, list[tuple[str, str | None]]], dict[str, set[str] | None], dict[str, str]]:
        """Build (source_id -> alias, alias -> pk_fields, alias -> allowed_cols_or_None, alias -> active_version_id)."""
        if not isinstance(catalog, dict):
            return {}, {}, {}, {}
        ext = ((catalog.get("extensions") or {}).get("urn:ddk:catalog:assembly") or {})
        defs = ext.get("datasetDefinitions") or {}
        disclosed_paths = ext.get("disclosedDefinitionPaths") or {}
        eff_audience = audience or catalog.get("audience", "public")

        source_to_alias: dict[str, str] = {}
        pk_by_alias: dict[str, list[tuple[str, str | None]]] = {}
        allowed_by_alias: dict[str, set[str] | None] = {}
        version_by_alias: dict[str, str] = {}

        versions = catalog.get("versions") or ()
        releases = catalog.get("releases") or ()
        active_members = set(releases[-1].get("members") or ()) if releases else {v["id"] for v in versions}
        for v in versions:
            if v["id"] in active_members and v["dataset"] not in version_by_alias:
                version_by_alias[v["dataset"]] = v["id"]

        for ds in catalog.get("datasets") or ():
            alias = ds["alias"]
            sid = normalize_serenedb_source_id(alias)
            source_to_alias[sid] = alias
            source_to_alias[alias] = alias
            schema = defs.get(alias) or {}
            prop_types = {
                p["name"]: p.get("logicalType")
                for p in (schema.get("properties") or ())
                if isinstance(p, dict) and isinstance(p.get("name"), str)
            }
            pk_names = row_identity_names(schema) or []
            pk_by_alias[alias] = [(k, prop_types.get(k)) for k in pk_names]
            if eff_audience == "public" and alias in disclosed_paths:
                allowed_by_alias[alias] = {
                    kp[0]["field"]
                    for kp in disclosed_paths[alias]
                    if isinstance(kp, list) and len(kp) == 1 and "field" in kp[0]
                }
            else:
                allowed_by_alias[alias] = None

        return source_to_alias, pk_by_alias, allowed_by_alias, version_by_alias

    @staticmethod
    def _release_disclosures(catalog: dict[str, Any] | None) -> dict[str, Any]:
        if not isinstance(catalog, dict):
            return {}
        ext = catalog.get("extensions") or {}
        disclosures: dict[str, Any] = {}
        if "urn:ddk:source-gaps" in ext:
            disclosures["sourceGaps"] = deepcopy(ext["urn:ddk:source-gaps"])
        if "urn:ddk:availability" in ext:
            disclosures["availability"] = deepcopy(ext["urn:ddk:availability"])
        return disclosures

    def _normalize_search_request(self, request: dict[str, Any], *, dataset_filter_sid: str | None = None) -> dict[str, Any]:
        limit = int(request.get("limit", 25))
        if not 1 <= limit <= 100:
            raise CatalogError("CATALOG-SEARCH-ARGUMENTS", "Search limit must be between 1 and 100.")
        page = int(request.get("page", 1))
        if page < 1:
            raise CatalogError("CATALOG-SEARCH-ARGUMENTS", "Search page must be >= 1.")
        filters = deepcopy(request.get("filters") or {})
        if dataset_filter_sid:
            filters.setdefault("source_id", [dataset_filter_sid])
        payload: dict[str, Any] = {
            "query": str(request.get("query") or ""),
            "identifier": request.get("identifier"),
            "limit": limit,
            "page": page,
            "sort": str(request.get("sort") or "relevance"),
            "must": list(request.get("must") or ()),
            "matching": str(request.get("matching") or "all"),
            "date_from": request.get("date_from"),
            "date_to": request.get("date_to"),
            "filters": filters,
        }
        for optional_key in ("date_field", "include_descendants", "missing_filters", "hybrid"):
            if optional_key in request and request[optional_key] is not None:
                payload[optional_key] = deepcopy(request[optional_key])
        if request.get("configVersion"):
            payload["configVersion"] = request["configVersion"]
        elif self._cached_config_version:
            payload["configVersion"] = self._cached_config_version
        return payload

    def search(
        self,
        request: dict[str, Any],
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]:
        source_to_alias, pk_by_alias, allowed_by_alias, version_by_alias = self._catalog_index_maps(catalog, audience)
        ds_filter_sid: str | None = None
        requested_ds = request.get("dataset")
        if isinstance(requested_ds, str) and requested_ds:
            if catalog is not None and requested_ds not in allowed_by_alias:
                raise CatalogError("CATALOG-DATASET-UNKNOWN", f"Unknown or undisclosed dataset {requested_ds!r}.")
            ds_filter_sid = normalize_serenedb_source_id(requested_ds)

        caller_pinned_cv = bool(request.get("configVersion"))
        wire_req = self._normalize_search_request(request, dataset_filter_sid=ds_filter_sid)
        status, data = self._request_json("POST", "/v1/search", wire_req)
        if status == 409 and not caller_pinned_cv:
            # Refresh stale configVersion once transparently per spicyengine README
            self._cached_config_version = None
            self.catalogs()
            wire_req = self._normalize_search_request(request, dataset_filter_sid=ds_filter_sid)
            status, data = self._request_json("POST", "/v1/search", wire_req)

        if status == 400:
            msg = data.get("error", "Invalid search request") if isinstance(data, dict) else "Invalid search request"
            raise CatalogError("CATALOG-SEARCH-ARGUMENTS", str(msg))
        if status != 200 or not isinstance(data, dict):
            raise CatalogError("CATALOG-SEARCH-ERROR", f"SereneDB /v1/search returned HTTP {status}")

        if isinstance(data.get("configVersion"), str):
            self._cached_config_version = data["configVersion"]

        redacted_hits: list[dict[str, Any]] = []
        for raw_hit in data.get("results") or ():
            if not isinstance(raw_hit, dict):
                continue
            hit = deepcopy(raw_hit)
            sid = str(hit.get("source_id") or "")
            mk = str(hit.get("member_key") or "")
            if catalog is not None:
                alias = source_to_alias.get(sid)
                if alias is None:
                    # Undisclosed or foreign dataset in shared SereneDB instance
                    continue
                allowed = allowed_by_alias.get(alias)
                if allowed is not None:
                    if isinstance(hit.get("facets"), dict):
                        hit["facets"] = {k: v for k, v in hit["facets"].items() if k in allowed}
                    if isinstance(hit.get("dates"), dict):
                        hit["dates"] = {k: v for k, v in hit["dates"].items() if k in allowed}
                    snip = hit.get("snippet")
                    if isinstance(snip, dict) and isinstance(snip.get("field"), str) and snip["field"] not in allowed:
                        hit["snippet"] = {"text": "", "highlights": [], "redacted": True}
                pk_map = decode_member_key(mk, pk_by_alias.get(alias, []))
                hit["locator"] = {
                    "dataset": alias,
                    "primaryKey": pk_map,
                    "versionId": version_by_alias.get(alias),
                }
            redacted_hits.append(hit)

        return {
            "status": "succeeded",
            "engine": {"id": "serenedb", "endpoint": self._base_url, "configVersion": data.get("configVersion")},
            "request": data.get("request", wire_req),
            "results": redacted_hits,
            "hasMore": bool(data.get("hasMore", False)),
            "pageLimitReached": bool(data.get("pageLimitReached", False)),
            "configVersion": data.get("configVersion"),
            **self._release_disclosures(catalog),
        }

    def facets(
        self,
        request: dict[str, Any],
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]:
        _, _, allowed_by_alias, _ = self._catalog_index_maps(catalog, audience)
        ds_filter_sid: str | None = None
        requested_ds = request.get("dataset")
        if isinstance(requested_ds, str) and requested_ds:
            if catalog is not None and requested_ds not in allowed_by_alias:
                raise CatalogError("CATALOG-DATASET-UNKNOWN", f"Unknown or undisclosed dataset {requested_ds!r}.")
            ds_filter_sid = normalize_serenedb_source_id(requested_ds)

        caller_pinned_cv = bool(request.get("configVersion"))
        wire_req = self._normalize_search_request(request, dataset_filter_sid=ds_filter_sid)
        status, data = self._request_json("POST", "/v1/facets", wire_req)
        if status == 409 and not caller_pinned_cv:
            self._cached_config_version = None
            self.catalogs()
            wire_req = self._normalize_search_request(request, dataset_filter_sid=ds_filter_sid)
            status, data = self._request_json("POST", "/v1/facets", wire_req)
        if status != 200 or not isinstance(data, dict):
            raise CatalogError("CATALOG-SEARCH-ERROR", f"SereneDB /v1/facets returned HTTP {status}")

        out = deepcopy(data)
        if catalog is not None and requested_ds and allowed_by_alias.get(requested_ds) is not None:
            allowed = allowed_by_alias[requested_ds] or set()
            if isinstance(out.get("facets"), dict):
                out["facets"] = {k: v for k, v in out["facets"].items() if k in allowed}
        out["status"] = "succeeded"
        out.update(self._release_disclosures(catalog))
        return out

    def record(
        self,
        record_id: str,
        *,
        catalog: dict[str, Any] | None = None,
        audience: str = "public",
    ) -> dict[str, Any]:
        if ":" not in record_id:
            raise CatalogError("CATALOG-SEARCH-RECORD-ID", "SereneDB record ID must have shape 'source_id:member_key'.")
        sid, mk = record_id.split(":", 1)
        source_to_alias, pk_by_alias, allowed_by_alias, version_by_alias = self._catalog_index_maps(catalog, audience)
        alias: str | None = None
        if catalog is not None:
            alias = source_to_alias.get(sid)
            if alias is None:
                raise CatalogError("CATALOG-DATASET-UNKNOWN", f"Record {record_id!r} belongs to an undisclosed dataset.")

        qs = urlencode({"id": record_id})
        status, data = self._request_json("GET", f"/v1/record?{qs}")
        if status == 404:
            return {"status": "missing", "id": record_id, **self._release_disclosures(catalog)}
        if status != 200 or not isinstance(data, dict):
            raise CatalogError("CATALOG-SEARCH-ERROR", f"SereneDB /v1/record returned HTTP {status}")

        out = deepcopy(data)
        if catalog is not None and alias is not None:
            allowed = allowed_by_alias.get(alias)
            if allowed is not None and isinstance(out.get("values"), dict):
                out["values"] = {k: v for k, v in out["values"].items() if k in allowed}
            elif allowed is not None and isinstance(out.get("record"), dict):
                out["record"] = {k: v for k, v in out["record"].items() if k in allowed}
            out["locator"] = {
                "dataset": alias,
                "primaryKey": decode_member_key(mk, pk_by_alias.get(alias, [])),
                "versionId": version_by_alias.get(alias),
            }
        out["status"] = "succeeded"
        out.update(self._release_disclosures(catalog))
        return out
