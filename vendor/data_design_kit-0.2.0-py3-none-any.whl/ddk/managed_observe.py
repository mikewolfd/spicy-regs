"""Managed observe command handler for external-observed lakes (ADR-016)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .adapters.docspec_overlay import DocSpecOverlayAdapter, ExternalOverlayError


def managed_observe(
    target: str,
    name: str | None = None,
    docspec_bin: str | None = None,
    output_path: str | Path | None = None,
    etag: str | None = None,
    indexing_fields: list[str] | None = None,
    include_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Execute observation of an external lake target and construct registration."""
    if not target:
        raise ValueError("Target path or URL is required for managed observe")

    adapter = DocSpecOverlayAdapter(docspec_bin=docspec_bin)
    try:
        descriptor = adapter.build_external_observed_descriptor(
            target=target,
            name=name,
            etag=etag,
            indexing_fields=indexing_fields,
            include_fields=include_fields,
        )
    except ExternalOverlayError as exc:
        return {
            "command": "managed observe",
            "decision": "error",
            "status": "error",
            "checks": [],
            "operationalErrors": [
                {
                    "code": exc.code,
                    "message": exc.message,
                    "severity": "error",
                    "statusCode": exc.status_code,
                }
            ],
            "error": {
                "code": exc.code,
                "message": exc.message,
                "statusCode": exc.status_code,
            },
        }

    report = {
        "command": "managed observe",
        "decision": "passed",
        "status": "passed",
        "checks": [],
        "operationalErrors": [],
        "role": "external-observed",
        "dataset": descriptor["name"],
        "source": descriptor["source"],
        "footerSha256": descriptor["footerSha256"],
        "statSig": descriptor["statSig"],
        "etag": descriptor["etag"],
        "partitionBounds": descriptor["partitionBounds"],
        "columns": descriptor["columns"],
        "indexing": descriptor["indexing"],
        "registration": descriptor,
    }

    if output_path:
        out_file = Path(output_path)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_file = out_file.with_suffix(f"{out_file.suffix}.tmp")
        with tmp_file.open("w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        tmp_file.replace(out_file)

    return report


def observe_external_parquet(
    target: str | Path,
    *,
    docspec_bin: str | Path,
    name: str | None = None,
    output_path: str | Path | None = None,
    etag: str | None = None,
    indexing_fields: list[str] | None = None,
    include_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Observe external Parquet partitions without copying corpora (ADR-016 Stage 1)."""
    return managed_observe(
        target=str(target),
        name=name,
        docspec_bin=str(docspec_bin),
        output_path=output_path,
        etag=etag,
        indexing_fields=indexing_fields,
        include_fields=include_fields,
    )
