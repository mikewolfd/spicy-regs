"""Typed compound-key row actions, provenance, and join explanations (ddk-pi9u).

Pure validators and builders for version-scoped rowActions:
1. Typed compound-key parameter binding (integer, number/Decimal, string, date, boolean)
   with composite scope requirements (e.g. congress + session + roll_call or docket_id + document_id),
   exact-number representation ({"$number": ...} preserving large integers > 2^53 - 1 such
   as 9007199254740993), refusing missing keys or stale context rather than broadening queries.
2. Action targets:
   - inspect_row: point lookup by primary/compound key.
   - related_rows: parameterized recipe lookup targeting related datasets.
   - open_source_witness: bound to exact source URI, source version, SHA-256 digest,
     and locator semantics (strictly distinguishing PDF text offsets vs PDF byte offsets
     vs XML/Clerk pointers).
   - explain_join: exposing contributing record identities, matching rule ID/expression,
     and explicit decision/uncertainty rather than claiming a shared hash or concept alone
     proves a join.
3. Outcome classification (singular, multiple, missing, unresolved, interrupted, withheld, refused).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from decimal import Decimal, InvalidOperation
import json
import re
from typing import Any, Literal, Mapping, Sequence

# JavaScript Number.MAX_SAFE_INTEGER (2^53 - 1)
MAX_SAFE_INTEGER = 9007199254740991
MIN_SAFE_INTEGER = -9007199254740991

SUPPORTED_PARAMETER_TYPES = frozenset({"integer", "number", "string", "date", "boolean"})
SUPPORTED_ACTION_KINDS = frozenset({"inspect_row", "related_rows", "open_source_witness", "explain_join"})
SUPPORTED_LOCATOR_KINDS = frozenset({
    "pdf_text_offset",
    "pdf_byte_offset",
    "xml_element_pointer",
    "clerk_pointer",
    "json_pointer",
    "text_span",
})
SUPPORTED_RENDITIONS = frozenset({"pdf", "xml", "html", "json", "text"})
OUTCOME_STATUSES = frozenset({
    "singular",
    "multiple",
    "missing",
    "unresolved",
    "interrupted",
    "withheld",
    "refused",
})
JOIN_DECISIONS = frozenset({"confirmed", "inferred", "uncertain", "ambiguous", "refused"})

DATE_PATTERN = re.compile(r"^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$")
SHA256_HEX_PATTERN = re.compile(r"^[a-f0-9]{64}$", re.IGNORECASE)


class RowActionError(ValueError):
    """Base error for row action validation, binding, and execution."""

    def __init__(self, code: str, message: str):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message


class MissingCompositeScopeError(RowActionError):
    """Raised when an action is missing required composite scope keys."""


class StaleContextRefusalError(RowActionError):
    """Raised when an action is invoked in an incompatible or changed version/release context."""


class ExactTypeMismatchError(RowActionError):
    """Raised when a parameter cannot be validated or coerced to the declared type."""


class LocatorSemanticsError(RowActionError):
    """Raised when locator semantics are confused (e.g. PDF text offset vs PDF byte offset)."""


class JoinProvenanceRefusalError(RowActionError):
    """Raised when a join explanation lacks explicit rule provenance or relies solely on shared hash/concept."""


class DiscriminatorMismatchError(RowActionError):
    """Raised when a row fails an endpoint or row-action `when` discriminator predicate."""


def _validate_when_spec(when: Mapping[str, Any] | None, *, label: str = "when") -> dict[str, Any] | None:
    if when is None:
        return None
    if not isinstance(when, Mapping) or set(when.keys()) != {"field", "equals"}:
        raise RowActionError("ACTION-WHEN-INVALID", f"{label} must be a mapping with exact keys 'field' and 'equals'.")
    field_name = when["field"]
    equals_val = when["equals"]
    if not isinstance(field_name, str) or not field_name.strip():
        raise RowActionError("ACTION-WHEN-INVALID", f"{label}.field must be a non-empty string.")
    if not isinstance(equals_val, (str, int, bool)):
        raise RowActionError("ACTION-WHEN-INVALID", f"{label}.equals must be a string, integer, or boolean.")
    return {"field": field_name, "equals": equals_val}


def row_matches_when(row: Mapping[str, Any], when: Mapping[str, Any] | None) -> bool:
    """Return True when *row* matches the optional endpoint discriminator ``when``."""
    if not when:
        return True
    val = row.get(when["field"])
    expected = when["equals"]
    if isinstance(expected, bool) or isinstance(val, bool):
        return type(val) is type(expected) and val == expected
    return val == expected


# ---------------------------------------------------------------------------
# Exact Number Helpers
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExactNumber:
    """Exact JSON number wrapper preserving arbitrary-precision numeric strings."""

    number: str

    def __post_init__(self):
        cleaned = self.number.strip()
        if not re.fullmatch(r"-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?", cleaned):
            raise ExactTypeMismatchError("ACTION-EXACT-NUMBER-INVALID", f"Invalid numeric string: {self.number!r}")
        object.__setattr__(self, "number", cleaned)

    @property
    def value(self) -> int | Decimal:
        return parse_exact_number(self.number)

    def to_dict(self) -> dict[str, str]:
        return {"$number": self.number}


def is_exact_number(value: Any) -> bool:
    """Return True if value is an exact number wrapper: {"$number": string} or ExactNumber."""
    if isinstance(value, ExactNumber):
        return True
    return (
        isinstance(value, dict)
        and list(value.keys()) == ["$number"]
        and isinstance(value["$number"], str)
    )


def parse_exact_number(value: Any) -> int | Decimal:
    """Parse an exact integer or decimal value without IEEE 754 precision loss."""
    if isinstance(value, ExactNumber):
        return value.value
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, Decimal):
        return value
    if is_exact_number(value):
        raw = value["$number"]
        try:
            if re.fullmatch(r"-?[0-9]+", raw):
                return int(raw)
            return Decimal(raw)
        except (InvalidOperation, ValueError) as exc:
            raise ExactTypeMismatchError(
                "ACTION-EXACT-NUMBER-INVALID",
                f"Invalid exact number lexeme in wrapper: {raw!r}",
            ) from exc
    if isinstance(value, str):
        cleaned = value.strip()
        try:
            if re.fullmatch(r"-?[0-9]+", cleaned):
                return int(cleaned)
            return Decimal(cleaned)
        except (InvalidOperation, ValueError) as exc:
            raise ExactTypeMismatchError(
                "ACTION-EXACT-NUMBER-INVALID",
                f"Invalid numeric string for exact number: {value!r}",
            ) from exc
    raise ExactTypeMismatchError(
        "ACTION-EXACT-NUMBER-INVALID",
        f"Cannot interpret {type(value).__name__} as exact number: {value!r}",
    )


def format_exact_number(value: int | Decimal | str | ExactNumber) -> dict[str, str]:
    """Format an exact number as a canonical DDK exact-number object {"$number": lexeme}."""
    if isinstance(value, ExactNumber):
        return value.to_dict()
    if isinstance(value, int) and not isinstance(value, bool):
        return {"$number": str(value)}
    if isinstance(value, Decimal):
        return {"$number": str(value)}
    if isinstance(value, str):
        if not re.fullmatch(r"-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?", value.strip()):
            raise ExactTypeMismatchError(
                "ACTION-EXACT-NUMBER-INVALID",
                f"Invalid numeric lexeme string: {value!r}",
            )
        return {"$number": value.strip()}
    raise ExactTypeMismatchError(
        "ACTION-EXACT-NUMBER-INVALID",
        f"Cannot format {type(value).__name__} as exact number: {value!r}",
    )


# ---------------------------------------------------------------------------
# Scope & Parameter Declarations
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RowActionContext:
    """Strictly-bound release and version context for a row action."""

    dataset_id: str
    version_id: str
    representation_id: str
    release_id: str | None = None

    def __post_init__(self):
        if not self.dataset_id.strip():
            raise RowActionError("ACTION-CONTEXT-INVALID", "dataset_id cannot be empty.")
        if not self.version_id.strip():
            raise RowActionError("ACTION-CONTEXT-INVALID", "version_id cannot be empty.")
        if not self.representation_id.strip():
            raise RowActionError("ACTION-CONTEXT-INVALID", "representation_id cannot be empty.")

    def matches(self, other: RowActionContext) -> bool:
        """Check whether another context matches this context exactly."""
        if (
            self.dataset_id != other.dataset_id
            or self.version_id != other.version_id
            or self.representation_id != other.representation_id
        ):
            return False
        if self.release_id is not None and other.release_id is not None:
            return self.release_id == other.release_id
        return True


@dataclass(frozen=True)
class ParameterDeclaration:
    """Declaration of a typed parameter required by a row action."""

    name: str
    type: Literal["integer", "number", "string", "date", "boolean"]
    required: bool = True
    description: str = ""

    def __post_init__(self):
        if not self.name.strip():
            raise RowActionError("ACTION-PARAM-NAME-EMPTY", "Parameter name must be non-empty.")
        if self.type not in SUPPORTED_PARAMETER_TYPES:
            raise RowActionError(
                "ACTION-PARAM-TYPE-INVALID",
                f"Parameter {self.name}: type {self.type!r} not supported. Must be one of {sorted(SUPPORTED_PARAMETER_TYPES)}",
            )


@dataclass(frozen=True)
class CompositeScopeRequirement:
    """A set of tightly-coupled composite fields that must all be present together."""

    name: str
    required_keys: tuple[str, ...]
    description: str = ""

    def __post_init__(self):
        if not self.name.strip():
            raise RowActionError("ACTION-SCOPE-NAME-EMPTY", "Scope name must be non-empty.")
        if len(self.required_keys) < 2:
            raise RowActionError(
                "ACTION-SCOPE-KEYS-TOO-FEW",
                f"Composite scope {self.name} must declare at least 2 required keys.",
            )
        if len(set(self.required_keys)) != len(self.required_keys):
            raise RowActionError(
                "ACTION-SCOPE-KEYS-DUPLICATE",
                f"Composite scope {self.name} contains duplicate keys: {self.required_keys}",
            )


# ---------------------------------------------------------------------------
# Locators & Provenance
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SourceLocator:
    """Precise source locator distinguishing text vs byte offsets and structural pointers."""

    kind: Literal[
        "pdf_text_offset",
        "pdf_byte_offset",
        "xml_element_pointer",
        "clerk_pointer",
        "json_pointer",
        "text_span",
    ]
    rendition: Literal["pdf", "xml", "html", "json", "text"]
    start_char: int | None = None
    end_char: int | None = None
    start_byte: int | None = None
    end_byte: int | None = None
    xpath: str | None = None
    element_id: str | None = None
    pointer: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.kind not in SUPPORTED_LOCATOR_KINDS:
            raise LocatorSemanticsError(
                "ACTION-LOCATOR-KIND-INVALID",
                f"Locator kind {self.kind!r} not recognized. Must be one of {sorted(SUPPORTED_LOCATOR_KINDS)}",
            )
        if self.rendition not in SUPPORTED_RENDITIONS:
            raise LocatorSemanticsError(
                "ACTION-RENDITION-INVALID",
                f"Rendition {self.rendition!r} not recognized. Must be one of {sorted(SUPPORTED_RENDITIONS)}",
            )

        # STRICT INVARIANT: PDF text offsets are NOT PDF byte offsets!
        if self.kind == "pdf_text_offset":
            if self.start_byte is not None or self.end_byte is not None:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-SEMANTICS-CONFUSION",
                    "kind='pdf_text_offset' indexes character spans in extracted UTF-8 text, "
                    "not byte positions in raw PDF bytes. start_byte/end_byte must be None.",
                )
            if self.start_char is None or self.end_char is None:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-OFFSETS-MISSING",
                    "pdf_text_offset requires start_char and end_char.",
                )
            if self.start_char < 0 or self.end_char < self.start_char:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-OFFSETS-INVALID",
                    f"Invalid character offset span: [{self.start_char}, {self.end_char}]",
                )

        elif self.kind == "pdf_byte_offset":
            if self.start_char is not None or self.end_char is not None:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-SEMANTICS-CONFUSION",
                    "kind='pdf_byte_offset' indexes raw file byte positions, not character offsets. "
                    "start_char/end_char must be None.",
                )
            if self.start_byte is None or self.end_byte is None:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-BYTES-MISSING",
                    "pdf_byte_offset requires start_byte and end_byte.",
                )
            if self.start_byte < 0 or self.end_byte < self.start_byte:
                raise LocatorSemanticsError(
                    "ACTION-LOCATOR-BYTES-INVALID",
                    f"Invalid byte offset span: [{self.start_byte}, {self.end_byte}]",
                )

        elif self.kind == "clerk_pointer":
            if not self.details.get("vote_id") or not self.details.get("member_id"):
                raise LocatorSemanticsError(
                    "ACTION-CLERK-POINTER-INCOMPLETE",
                    "clerk_pointer requires 'vote_id' and 'member_id' in details.",
                )


@dataclass(frozen=True)
class ContributingRecord:
    """Contributing record identifier in a cross-source join or lineage relationship."""

    dataset_id: str
    version_id: str
    record_key: dict[str, Any]

    def __post_init__(self):
        if not self.dataset_id.strip():
            raise RowActionError("ACTION-CONTRIBUTING-DATASET-EMPTY", "dataset_id required.")
        if not self.version_id.strip():
            raise RowActionError("ACTION-CONTRIBUTING-VERSION-EMPTY", "version_id required.")
        if not self.record_key:
            raise RowActionError("ACTION-CONTRIBUTING-KEY-EMPTY", "record_key must be non-empty.")


@dataclass(frozen=True)
class JoinExplanation:
    """Explicit join explanation exposing contributing records and matching rule provenance."""

    contributing_records: tuple[ContributingRecord, ...]
    rule_id: str
    rule_expression: str
    decision: Literal["confirmed", "inferred", "uncertain", "ambiguous", "refused"]
    uncertainty_reason: str | None = None
    shared_concept: str | None = None
    shared_hash: str | None = None

    def __post_init__(self):
        # STRICT INVARIANT: A shared hash or shared concept alone does NOT explain a join!
        if not self.rule_id or not self.rule_id.strip():
            raise JoinProvenanceRefusalError(
                "ACTION-JOIN-RULE-REQUIRED",
                "A shared hash or shared concept alone does not explain a join; an explicit rule_id is required.",
            )
        if not self.rule_expression or not self.rule_expression.strip():
            raise JoinProvenanceRefusalError(
                "ACTION-JOIN-RULE-EXPRESSION-REQUIRED",
                "A shared hash or shared concept alone does not explain a join; an explicit rule_expression is required.",
            )
        if self.decision not in JOIN_DECISIONS:
            raise JoinProvenanceRefusalError(
                "ACTION-JOIN-DECISION-INVALID",
                f"decision {self.decision!r} not in approved decisions: {sorted(JOIN_DECISIONS)}",
            )
        if self.decision in {"uncertain", "ambiguous", "refused"} and not self.uncertainty_reason:
            raise JoinProvenanceRefusalError(
                "ACTION-JOIN-UNCERTAINTY-REASON-REQUIRED",
                f"Join decision {self.decision!r} requires an explicit uncertainty_reason.",
            )
        if not self.contributing_records:
            raise JoinProvenanceRefusalError(
                "ACTION-JOIN-CONTRIBUTORS-EMPTY",
                "Join explanation must reference at least one contributing record.",
            )


# ---------------------------------------------------------------------------
# Row Action Definitions & Outcomes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RowActionDefinition:
    """Configured row action definition bound to an exact version context."""

    id: str
    label: str
    kind: Literal["inspect_row", "related_rows", "open_source_witness", "explain_join"]
    context: RowActionContext
    parameters: tuple[ParameterDeclaration, ...] = ()
    composite_scopes: tuple[CompositeScopeRequirement, ...] = ()
    recipe_id: str | None = None
    source_uri: str | None = None
    source_version: str | None = None
    content_digest: str | None = None
    locator: SourceLocator | None = None
    when: Mapping[str, Any] | None = None
    target_when: Mapping[str, Any] | None = None

    def __post_init__(self):
        if not self.id.strip():
            raise RowActionError("ACTION-ID-EMPTY", "Action id must be non-empty.")
        if not self.label.strip():
            raise RowActionError("ACTION-LABEL-EMPTY", "Action label must be non-empty.")
        if self.kind not in SUPPORTED_ACTION_KINDS:
            raise RowActionError(
                "ACTION-KIND-INVALID",
                f"kind {self.kind!r} not supported. Must be one of {sorted(SUPPORTED_ACTION_KINDS)}",
            )
        if self.when is not None:
            object.__setattr__(self, "when", _validate_when_spec(self.when, label="when"))
        if self.target_when is not None:
            object.__setattr__(self, "target_when", _validate_when_spec(self.target_when, label="target_when"))

        if self.kind == "related_rows" and not self.recipe_id:
            raise RowActionError("ACTION-RECIPE-REQUIRED", "related_rows action requires a recipe_id.")

        if self.kind == "open_source_witness":
            if not self.source_uri:
                raise RowActionError("ACTION-WITNESS-URI-REQUIRED", "open_source_witness requires source_uri.")
            if not self.content_digest:
                raise RowActionError("ACTION-WITNESS-DIGEST-REQUIRED", "open_source_witness requires content_digest.")
            cleaned_digest = self.content_digest.lower().removeprefix("sha256:")
            if not SHA256_HEX_PATTERN.fullmatch(cleaned_digest):
                raise RowActionError(
                    "ACTION-WITNESS-DIGEST-INVALID",
                    f"content_digest must be a valid 64-character SHA-256 hex string, got {self.content_digest!r}",
                )


@dataclass(frozen=True)
class RowActionOutcome:
    """Structured result of executing or resolving a row action."""

    status: Literal["singular", "multiple", "missing", "unresolved", "interrupted", "withheld", "refused"]
    records: list[dict[str, Any]] = field(default_factory=list)
    cursor: str | int | None = None
    refusal_code: str | None = None
    refusal_reason: str | None = None
    source_witness: dict[str, Any] | None = None
    join_explanation: JoinExplanation | None = None

    def __post_init__(self):
        if self.status not in OUTCOME_STATUSES:
            raise RowActionError(
                "ACTION-OUTCOME-STATUS-INVALID",
                f"Outcome status {self.status!r} not in {sorted(OUTCOME_STATUSES)}",
            )

        # Invariant checks for outcome states
        if self.status == "singular" and len(self.records) != 1:
            raise RowActionError(
                "ACTION-OUTCOME-SINGULAR-COUNT",
                f"status='singular' requires exactly 1 record, got {len(self.records)}.",
            )
        if self.status == "multiple" and len(self.records) <= 1:
            raise RowActionError(
                "ACTION-OUTCOME-MULTIPLE-COUNT",
                f"status='multiple' requires >1 matching records, got {len(self.records)}.",
            )
        if self.status == "missing" and len(self.records) != 0:
            raise RowActionError(
                "ACTION-OUTCOME-MISSING-COUNT",
                f"status='missing' requires 0 records, got {len(self.records)}.",
            )
        if self.status == "refused":
            if not self.refusal_code or not self.refusal_reason:
                raise RowActionError(
                    "ACTION-OUTCOME-REFUSED-DETAILS",
                    "status='refused' requires both refusal_code and refusal_reason.",
                )
        if self.status == "withheld" and not self.refusal_reason:
            raise RowActionError(
                "ACTION-OUTCOME-WITHHELD-REASON",
                "status='withheld' requires a refusal_reason explaining the withholding.",
            )


# ---------------------------------------------------------------------------
# Parameter Binding & Validation Engine
# ---------------------------------------------------------------------------


def bind_row_action_parameters(
    action: RowActionDefinition,
    row_values: Mapping[str, Any],
    invocation_context: RowActionContext | None = None,
) -> dict[str, Any]:
    """Validate and bind row values to an action's declared parameters.

    Enforces:
    1. Exact context match: refuses stale or mismatched version context.
    2. Composite scope completeness: refuses if any required scope key is missing
       (never broadens queries!).
    3. Type validation and large integer preservation: preserves numbers > 2^53 - 1
       as exact {"$number": ...} or Decimal/int representations.
    """
    # 1. Stale or mismatched context check
    if invocation_context is not None and not action.context.matches(invocation_context):
        raise StaleContextRefusalError(
            "ACTION-STALE-CONTEXT",
            f"Action {action.id} bound to version ({action.context.dataset_id}, {action.context.version_id}) "
            f"cannot be executed in context ({invocation_context.dataset_id}, {invocation_context.version_id}). "
            "Refusing stale/mismatched release context.",
        )

    # 1b. Endpoint discriminator check
    if action.when is not None and not row_matches_when(row_values, action.when):
        raise DiscriminatorMismatchError(
            "ACTION-WHEN-MISMATCH",
            f"Action {action.id} requires {action.when['field']!r} == {action.when['equals']!r}, "
            f"got {row_values.get(action.when['field'])!r}.",
        )

    # 2. Composite scope requirements
    for comp in action.composite_scopes:
        missing = [
            k for k in comp.required_keys
            if k not in row_values or row_values[k] is None or (isinstance(row_values[k], str) and not row_values[k].strip())
        ]
        if missing:
            raise MissingCompositeScopeError(
                "ACTION-COMPOSITE-SCOPE-MISSING",
                f"Action {action.id} requires complete composite scope {comp.name!r} ({list(comp.required_keys)}), "
                f"but missing key(s): {missing}. A missing key must not broaden a query.",
            )

    # 3. Typed parameter binding
    bound_params: dict[str, Any] = {}
    for param in action.parameters:
        if param.name not in row_values or row_values[param.name] is None:
            if param.required:
                raise MissingCompositeScopeError(
                    "ACTION-REQUIRED-PARAM-MISSING",
                    f"Action {action.id} missing required parameter: {param.name!r}",
                )
            continue

        raw = row_values[param.name]
        bound_val = _coerce_and_validate_parameter(param.name, param.type, raw)
        bound_params[param.name] = bound_val

    return bound_params


def _coerce_and_validate_parameter(name: str, expected_type: str, value: Any) -> Any:
    """Coerce and validate a single parameter value against its declared type."""
    if expected_type == "string":
        if not isinstance(value, str):
            raise ExactTypeMismatchError(
                "ACTION-PARAM-TYPE-MISMATCH",
                f"Parameter {name} expected string, got {type(value).__name__}: {value!r}",
            )
        return value

    if expected_type == "boolean":
        if not isinstance(value, bool):
            raise ExactTypeMismatchError(
                "ACTION-PARAM-TYPE-MISMATCH",
                f"Parameter {name} expected boolean, got {type(value).__name__}: {value!r}",
            )
        return value

    if expected_type == "date":
        if not isinstance(value, str) or not DATE_PATTERN.fullmatch(value.strip()):
            raise ExactTypeMismatchError(
                "ACTION-PARAM-TYPE-MISMATCH",
                f"Parameter {name} expected ISO 8601 date (YYYY-MM-DD), got {value!r}",
            )
        return value.strip()

    if expected_type == "integer":
        if isinstance(value, bool):
            raise ExactTypeMismatchError("ACTION-PARAM-TYPE-MISMATCH", f"Parameter {name} cannot be a boolean.")
        num = parse_exact_number(value)
        if isinstance(num, Decimal) and num % 1 != 0:
            raise ExactTypeMismatchError("ACTION-PARAM-TYPE-MISMATCH", f"Parameter {name} is not an integer: {value!r}")
        int_val = int(num)

        # Large integer preservation: if outside JavaScript safe integer range, preserve wrapper
        if int_val > MAX_SAFE_INTEGER or int_val < MIN_SAFE_INTEGER:
            return format_exact_number(int_val)
        return int_val

    if expected_type == "number":
        if isinstance(value, bool):
            raise ExactTypeMismatchError("ACTION-PARAM-TYPE-MISMATCH", f"Parameter {name} cannot be a boolean.")
        num = parse_exact_number(value)
        if isinstance(num, int) and (num > MAX_SAFE_INTEGER or num < MIN_SAFE_INTEGER):
            return format_exact_number(num)
        return num

    raise ExactTypeMismatchError("ACTION-PARAM-TYPE-UNSUPPORTED", f"Unsupported type: {expected_type}")


# ---------------------------------------------------------------------------
# High-Level Action Builders
# ---------------------------------------------------------------------------


def build_house_roll_call_witness_action(
    context: RowActionContext,
    congress: int,
    session: int,
    roll_number: int,
    member_key: str,
    source_uri: str,
    content_digest: str,
    vote_position: str,
    source_version: str = "2026-03-25",
) -> tuple[RowActionDefinition, SourceLocator]:
    """Build a version-scoped action for House roll-call vote source witness (e.g. roll 99)."""
    vote_id = f"{congress}-house-{session}-{roll_number}"
    locator = SourceLocator(
        kind="clerk_pointer",
        rendition="xml",
        details={
            "vote_id": vote_id,
            "member_id": member_key,
            "action": vote_position,
            "clerk_url": f"https://clerk.house.gov/evs/{2024 + (congress - 118)*2}/roll{roll_number:03d}.xml",
        },
    )
    action = RowActionDefinition(
        id=f"witness-roll-{vote_id}-{member_key}",
        label=f"Inspect Clerk Original for Vote {vote_id} ({member_key})",
        kind="open_source_witness",
        context=context,
        parameters=(
            ParameterDeclaration(name="congress", type="integer"),
            ParameterDeclaration(name="session", type="integer"),
            ParameterDeclaration(name="roll_number", type="integer"),
            ParameterDeclaration(name="member_key", type="string"),
        ),
        composite_scopes=(
            CompositeScopeRequirement(
                name="roll_call_scope",
                required_keys=("congress", "session", "roll_number"),
            ),
        ),
        source_uri=source_uri,
        source_version=source_version,
        content_digest=content_digest,
        locator=locator,
    )
    return action, locator


def build_comment_to_document_action(
    context: RowActionContext,
    recipe_id: str,
) -> RowActionDefinition:
    """Build a related_rows action linking a public comment to its parent docket document."""
    return RowActionDefinition(
        id="related-docket-document",
        label="View Related Docket Document",
        kind="related_rows",
        context=context,
        recipe_id=recipe_id,
        parameters=(
            ParameterDeclaration(name="docket_id", type="string"),
            ParameterDeclaration(name="document_id", type="string"),
        ),
        composite_scopes=(
            CompositeScopeRequirement(
                name="docket_document_scope",
                required_keys=("docket_id", "document_id"),
            ),
        ),
    )


def is_row_action_applicable(action: RowActionDefinition, row_values: Mapping[str, Any]) -> bool:
    """Return True if *row_values* satisfies the action's optional `when` discriminator."""
    return row_matches_when(row_values, action.when)


def evaluate_relationship_row_action(
    relationship: Mapping[str, Any],
    source_row: Mapping[str, Any],
    target_rows: Sequence[Mapping[str, Any]],
) -> RowActionOutcome:
    """Evaluate a declared catalog relationship for *source_row* against *target_rows*, honoring `when` on source & target."""
    source = relationship.get("source") or {}
    target = relationship.get("target") or {}
    if not row_matches_when(source_row, source.get("when")):
        return RowActionOutcome(status="missing", records=[])

    src_paths = source.get("paths") or ()
    tgt_paths = target.get("paths") or ()
    if not src_paths or len(src_paths) != len(tgt_paths):
        raise RowActionError("ACTION-RELATIONSHIP-PATHS", "Relationship endpoints must declare equal-length key paths.")

    nulls = relationship.get("nulls", "skip")
    src_vals = []
    for path in src_paths:
        if len(path) != 1 or "field" not in path[0]:
            raise RowActionError("ACTION-RELATIONSHIP-PATHS", "Row action relationship evaluation requires top-level scalar paths.")
        src_vals.append(source_row.get(path[0]["field"]))

    if any(v is None for v in src_vals):
        if nulls == "reject":
            return RowActionOutcome(
                status="refused",
                refusal_code="ACTION-KEY-NULL",
                refusal_reason="Source row contains a rejected null key component.",
            )
        if nulls == "skip":
            return RowActionOutcome(status="missing", records=[])

    tgt_when = target.get("when")
    tgt_fields = [p[0]["field"] for p in tgt_paths]
    matched: list[dict[str, Any]] = []
    for t_row in target_rows:
        if not row_matches_when(t_row, tgt_when):
            continue
        t_vals = [t_row.get(f) for f in tgt_fields]
        if any(v is None for v in t_vals):
            if nulls == "reject":
                return RowActionOutcome(
                    status="refused",
                    refusal_code="ACTION-KEY-NULL",
                    refusal_reason="Target row contains a rejected null key component.",
                )
            if nulls == "skip":
                continue
        if all(
            (type(sv) is type(tv) and sv == tv) if (isinstance(sv, bool) or isinstance(tv, bool)) else (sv == tv)
            for sv, tv in zip(src_vals, t_vals)
        ):
            matched.append(dict(t_row))

    if not matched:
        return RowActionOutcome(status="missing", records=[])
    if len(matched) == 1:
        return RowActionOutcome(status="singular", records=matched)
    return RowActionOutcome(status="multiple", records=matched)


def build_join_explanation(
    contributing_records: Sequence[ContributingRecord],
    rule_id: str,
    rule_expression: str,
    decision: Literal["confirmed", "inferred", "uncertain", "ambiguous", "refused"] = "confirmed",
    uncertainty_reason: str | None = None,
    shared_concept: str | None = None,
    shared_hash: str | None = None,
) -> JoinExplanation:
    """Build an explicit join explanation with required rule provenance."""
    return JoinExplanation(
        contributing_records=tuple(contributing_records),
        rule_id=rule_id,
        rule_expression=rule_expression,
        decision=decision,
        uncertainty_reason=uncertainty_reason,
        shared_concept=shared_concept,
        shared_hash=shared_hash,
    )
