"""Shared MCP server / tool dispatcher over admitted DDK catalogs (`ddk-citj`).

Integrates with the official Python ``mcp`` SDK (``create_mcp_server`` returning
an ``mcp.server.Server`` instance) while preserving ``CatalogMcpServer`` for
synchronous in-process / JSON-RPC 2.0 callers. Supports human-friendly dataset
aliases (auto-resolving to the active selection or sole release's version and
Parquet representation) and recipe IDs alongside explicit version/representation IDs.
"""

from __future__ import annotations

from hashlib import sha256
import inspect
from pathlib import Path
from typing import Any

from . import __version__
from .catalog_access import (
    CatalogError,
    _encode_exact_json_value,
    follow_catalog_relationship,
    resolve_active_dataset_version,
    resolve_catalog_dataset,
    serve_catalog_browse,
    serve_catalog_query,
    serve_catalog_read,
)
from .catalog_delivery import load_catalog_artifacts
from .documents import DocumentError, ResourceLimit, json_dumps, parse_json
from .row_actions import (
    CompositeScopeRequirement,
    ParameterDeclaration,
    RowActionContext,
    RowActionDefinition,
    RowActionError,
    bind_row_action_parameters,
)


def _load_mcp_tool_schemas() -> tuple[tuple[dict[str, Any], ...], tuple[dict[str, Any], ...]]:
    schema_path = Path(__file__).with_name("schemas") / "mcp-tools.schema.json"
    doc = parse_json(schema_path.read_bytes())
    return tuple(doc["core"]), tuple(doc["search"])


MCP_TOOLS, SEARCH_MCP_TOOLS = _load_mcp_tool_schemas()


def _wire_payload(payload: Any) -> Any:
    """Strip Python-decoded ``rows`` when ``exactRows`` is present so JSON output preserves lossless ddk-exact-json-v1."""
    if isinstance(payload, dict) and "exactRows" in payload:
        return {k: v for k, v in payload.items() if k != "rows"}
    return payload


def _logical_to_action_param_type(logical_type: str | None) -> str:
    if logical_type in {"integer", "number", "string", "date", "boolean"}:
        return logical_type
    return "string"


class CatalogMcpServer:
    """In-process & JSON-RPC 2.0 MCP dispatcher bound to one pinned catalog root."""

    def __init__(self, directory, *, expected_lock_sha256: str | None = None, permitted_roots=(), adapter=None,
                 scratch=None, audience=None, cursor_secret=None, allow_insecure_http=False, search_engine=None):
        self.directory = Path(directory).resolve(strict=True)
        if expected_lock_sha256 is None:
            lock_path = self.directory / "catalog.lock.json"
            if not lock_path.is_file():
                raise CatalogError("CATALOG-LOCK-MISSING", f"Missing catalog.lock.json in {self.directory}")
            expected_lock_sha256 = sha256(lock_path.read_bytes()).hexdigest()
        self.expected_lock_sha256 = expected_lock_sha256
        self.permitted_roots = tuple(permitted_roots) or (self.directory,)
        self.adapter = adapter
        self.scratch = scratch or (self.directory.parent / "scratch")
        self.audience = audience
        self.cursor_secret = cursor_secret
        self.allow_insecure_http = allow_insecure_http
        if search_engine is None:
            from .serenedb import SereneDbConfig, SereneDbSearchAdapter
            cfg = SereneDbConfig.from_env()
            if cfg is not None:
                search_engine = SereneDbSearchAdapter(cfg)
        self.search_engine = search_engine

    def list_tools(self):
        if self.search_engine is not None:
            return [*MCP_TOOLS, *SEARCH_MCP_TOOLS]
        return list(MCP_TOOLS)

    def _handle_row_action(self, args: dict[str, Any]) -> dict[str, Any]:
        row_values = dict(args.get("row") or args.get("parameters") or {})
        rel_id = args.get("relationshipId")
        rec_id = args.get("recipeId") or args.get("recipe")
        raw_action = args.get("action")
        when_spec = args.get("when")
        if isinstance(raw_action, dict):
            kind = raw_action.get("kind")
            rel_id = rel_id or raw_action.get("relationshipId")
            rec_id = rec_id or raw_action.get("recipeId") or raw_action.get("recipe")
            act_params = raw_action.get("parameters")
            if isinstance(act_params, dict):
                row_values = {**act_params, **row_values}
            if when_spec is None:
                when_spec = raw_action.get("when")
        else:
            kind = raw_action
        if kind is None:
            if rel_id:
                kind = "follow_relationship"
            elif rec_id:
                kind = "related_rows"
            else:
                kind = "inspect_row"

        if kind == "follow_relationship":
            if not rel_id:
                raise CatalogError("CATALOG-MCP-ARGUMENTS", "follow_relationship requires relationshipId")
            res = follow_catalog_relationship(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                relationship_id=rel_id,
                source_row=row_values,
                target_version_id=args.get("versionId"),
                target_representation_id=args.get("representationId"),
                columns=args.get("columns"),
                limit=args.get("limit", 25),
                audience=self.audience,
                permitted_roots=self.permitted_roots,
                allow_insecure_http=self.allow_insecure_http,
            )
            count = res.get("returned", 0)
            action_status = "missing" if count == 0 else ("singular" if count == 1 else "multiple")
            return {
                **res,
                "action": "follow_relationship",
                "actionStatus": action_status,
            }

        if kind == "related_rows":
            if not rec_id:
                raise CatalogError("CATALOG-MCP-ARGUMENTS", "related_rows requires recipeId or recipe")
            if self.adapter is None:
                raise CatalogError("CATALOG-QUERY-UNAVAILABLE", "No query adapter configured for this catalog server")
            q_res = serve_catalog_query(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                adapter=self.adapter,
                scratch=self.scratch,
                permitted_roots=self.permitted_roots,
                recipe_id=rec_id,
                parameters=row_values,
                limit=args.get("limit", 25),
                audience=self.audience,
            )
            if q_res.get("status") != "succeeded":
                return {**q_res, "action": "related_rows", "actionStatus": "refused"}
            exact_rows = q_res.get("exactRows", [])
            action_status = "missing" if not exact_rows else ("singular" if len(exact_rows) == 1 else "multiple")
            return {**q_res, "action": "related_rows", "actionStatus": action_status}

        if kind != "inspect_row":
            raise CatalogError("CATALOG-MCP-ARGUMENTS", f"Unsupported row action {kind!r}")

        ds_ref = args.get("dataset") or args.get("datasetId")
        if not ds_ref:
            raise CatalogError("CATALOG-MCP-ARGUMENTS", "inspect_row requires dataset or datasetId")

        captured = load_catalog_artifacts(self.directory, expected_lock_sha256=self.expected_lock_sha256, audience=self.audience)
        catalog = captured.catalog
        ds_rec = resolve_catalog_dataset(catalog, ds_ref)
        alias = ds_rec["alias"]
        ver_rec = resolve_active_dataset_version(catalog, alias, version_id=args.get("versionId"))

        reps = [r for r in catalog.get("representations", ()) if r.get("version") == ver_rec["id"]]
        rep_id = args.get("representationId") or (reps[0]["id"] if reps else "urn:ddk:representation:auto")

        # Determine key fields from catalog identities or row_values keys
        key_identities = [
            item for item in catalog.get("identities", ())
            if item.get("dataset") == alias and item.get("kind") == "key"
        ]
        defs = ((catalog.get("extensions") or {}).get("urn:ddk:catalog:assembly") or {}).get("datasetDefinitions") or {}
        ds_schema = defs.get(alias) if isinstance(defs, dict) else None
        prop_types = {
            p["name"]: p.get("logicalType")
            for p in ((ds_schema or {}).get("properties") or ())
            if isinstance(p, dict) and isinstance(p.get("name"), str)
        }

        if key_identities:
            key_fields = [
                f["path"][0]["field"]
                for f in key_identities[0].get("fields", ())
                if len(f.get("path", ())) == 1 and "field" in f["path"][0]
            ]
        else:
            key_fields = list(row_values.keys())

        if not key_fields:
            raise CatalogError("CATALOG-MCP-ARGUMENTS", "inspect_row requires non-empty key values in 'row' or 'parameters'")

        context = RowActionContext(
            dataset_id=ds_rec["id"],
            version_id=ver_rec["id"],
            representation_id=rep_id,
        )
        param_decls = tuple(
            ParameterDeclaration(name=k, type=_logical_to_action_param_type(prop_types.get(k)))
            for k in key_fields
        )
        comp_scopes = (
            (CompositeScopeRequirement(name=f"{alias}_pk", required_keys=tuple(key_fields)),)
            if len(key_fields) >= 2
            else ()
        )
        action_def = RowActionDefinition(
            id=f"inspect-{alias}",
            label=f"Inspect {alias}",
            kind="inspect_row",
            context=context,
            parameters=param_decls,
            composite_scopes=comp_scopes,
            when=when_spec,
        )
        bound = bind_row_action_parameters(action_def, row_values)
        filters = [{"column": k, "op": "eq", "value": bound[k]} for k in key_fields]
        read_res = serve_catalog_read(
            self.directory,
            expected_lock_sha256=self.expected_lock_sha256,
            dataset_id=ds_rec["id"],
            version_id=ver_rec["id"],
            representation_id=args.get("representationId"),
            columns=args.get("columns"),
            filters=filters,
            limit=2,
            point_lookup=True,
            cursor_secret=self.cursor_secret,
            audience=self.audience,
            permitted_roots=self.permitted_roots,
            allow_insecure_http=self.allow_insecure_http,
        )
        if read_res.get("status") == "ambiguous":
            action_status = "ambiguous"
        elif read_res.get("returned", 0) == 1:
            action_status = "singular"
        elif read_res.get("returned", 0) == 0:
            action_status = "missing"
        else:
            action_status = read_res.get("status", "unresolved")
        return {
            **read_res,
            "action": "inspect_row",
            "actionStatus": action_status,
            "boundKey": {k: _encode_exact_json_value(v) if not isinstance(v, dict) else v for k, v in bound.items()},
        }

    def call_tool(self, name, arguments=None):
        args = dict(arguments or {})
        if name == "catalog_browse":
            aud = args.get("audience", self.audience)
            if self.audience is not None and aud != self.audience:
                raise CatalogError("CATALOG-AUDIENCE-REFUSED", "Requested audience exceeds server scope")
            return serve_catalog_browse(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                audience=aud,
            )

        if name == "catalog_read":
            ds_ref = args.get("datasetId") if args.get("datasetId") is not None else args.get("dataset")
            if ds_ref is None:
                raise CatalogError("CATALOG-MCP-ARGUMENTS", "catalog_read requires 'dataset' or 'datasetId'")
            base_filters = list(args.get("filters") or ())
            raw_point = args.get("pointLookup", False)
            is_point_lookup = False
            if isinstance(raw_point, dict):
                if not 1 <= len(raw_point) <= 16:
                    raise CatalogError("CATALOG-MCP-ARGUMENTS", "pointLookup mapping must have 1 to 16 key fields")
                is_point_lookup = True
                for k, v in raw_point.items():
                    if not isinstance(k, str) or not k or len(k) > 128:
                        raise CatalogError("CATALOG-MCP-ARGUMENTS", "pointLookup key name must be a nonempty string <= 128 chars")
                    base_filters.append({"column": k, "op": "eq", "value": v})
            else:
                is_point_lookup = bool(raw_point)
            return serve_catalog_read(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                dataset_id=ds_ref,
                version_id=args.get("versionId"),
                representation_id=args.get("representationId"),
                columns=args.get("columns"),
                filters=base_filters or None,
                sort=args.get("sort"),
                limit=args.get("limit", 25),
                offset=args.get("offset", 0),
                cursor=args.get("cursor"),
                point_lookup=is_point_lookup,
                cursor_secret=self.cursor_secret,
                audience=self.audience,
                permitted_roots=self.permitted_roots,
                allow_insecure_http=self.allow_insecure_http,
            )

        if name == "catalog_query":
            if self.adapter is None:
                raise CatalogError("CATALOG-QUERY-UNAVAILABLE", "No query adapter configured for this catalog server")
            rec_id = args.get("recipeId") if args.get("recipeId") is not None else args.get("recipe")
            return serve_catalog_query(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                adapter=self.adapter,
                scratch=self.scratch,
                permitted_roots=self.permitted_roots,
                sql=args.get("sql"),
                recipe_id=rec_id,
                bindings=args.get("bindings"),
                parameters=args.get("parameters"),
                columns_by_binding=args.get("columnsByBinding"),
                limit=args.get("limit", 100),
                audience=self.audience,
                explain=bool(args.get("explain", False)),
            )

        if name == "catalog_row_action":
            return self._handle_row_action(args)

        if name in {"catalog_search", "catalog_facets"}:
            if self.search_engine is None:
                raise CatalogError("CATALOG-SEARCH-UNAVAILABLE", "No SereneDB search engine configured for this catalog server")
            captured = load_catalog_artifacts(
                self.directory,
                expected_lock_sha256=self.expected_lock_sha256,
                audience=self.audience,
            )
            eff_audience = self.audience or captured.catalog.get("audience", "public")
            if name == "catalog_search":
                return self.search_engine.search(args, catalog=captured.catalog, audience=eff_audience)
            return self.search_engine.facets(args, catalog=captured.catalog, audience=eff_audience)

        raise CatalogError("CATALOG-MCP-UNKNOWN-TOOL", f"Unknown MCP tool {name!r}")

    def handle_rpc(self, request):
        if isinstance(request, (bytes, str)):
            raw = request.encode("utf-8") if isinstance(request, str) else request
            request = parse_json(raw)
        if not isinstance(request, dict) or request.get("jsonrpc") != "2.0" or "method" not in request:
            return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid JSON-RPC request"}}
        req_id = request.get("id")
        method = request["method"]
        params = request.get("params") or {}
        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "serverInfo": {"name": "ddk-catalog-mcp", "version": __version__},
                    "capabilities": {"tools": {}},
                }
            elif method == "tools/list":
                result = {"tools": self.list_tools()}
            elif method == "tools/call":
                tool_name = params.get("name")
                tool_args = params.get("arguments") or {}
                payload = self.call_tool(tool_name, tool_args)
                wire_payload = _wire_payload(payload)
                result = {
                    "content": [{"type": "text", "text": json_dumps(wire_payload)}],
                    "structuredContent": parse_json(json_dumps(wire_payload).encode("utf-8")),
                }
            else:
                return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}
            return {"jsonrpc": "2.0", "id": req_id, "result": result}
        except (CatalogError, RowActionError, DocumentError, ResourceLimit, KeyError, TypeError, ValueError) as exc:
            code = getattr(exc, "code", "CATALOG-MCP-ERROR")
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32000, "message": str(exc), "data": {"ddkCode": code}},
            }


def create_mcp_server(
    catalog_dir,
    *,
    expected_lock_sha256: str | None = None,
    permitted_roots=(),
    adapter=None,
    scratch=None,
    audience=None,
    cursor_secret=None,
    allow_insecure_http=False,
    search_engine=None,
    server_name: str = "ddk-catalog-mcp",
):
    """Create an official ``mcp.server.Server`` bound to an admitted DDK catalog directory."""
    import mcp
    from mcp import types
    from mcp.server import Server

    dispatcher = CatalogMcpServer(
        catalog_dir,
        expected_lock_sha256=expected_lock_sha256,
        permitted_roots=permitted_roots,
        adapter=adapter,
        scratch=scratch,
        audience=audience,
        cursor_secret=cursor_secret,
        allow_insecure_http=allow_insecure_http,
        search_engine=search_engine,
    )

    tool_schemas_by_name = {t["name"]: t["inputSchema"] for t in (*MCP_TOOLS, *SEARCH_MCP_TOOLS)}

    def _build_sdk_tools() -> list[types.Tool]:
        sdk_tools = []
        for spec in dispatcher.list_tools():
            # Support both mcp 2.x (input_schema) and mcp 1.x (inputSchema)
            if "input_schema" in types.Tool.model_fields:
                sdk_tools.append(types.Tool(
                    name=spec["name"],
                    description=spec["description"],
                    input_schema=spec["inputSchema"],
                ))
            else:
                sdk_tools.append(types.Tool(
                    name=spec["name"],
                    description=spec["description"],
                    inputSchema=spec["inputSchema"],
                ))
        return sdk_tools

    def _invoke_tool(name: str, arguments: dict[str, Any] | None):
        try:
            payload = dispatcher.call_tool(name, arguments or {})
            wire_payload = _wire_payload(payload)
            structured = parse_json(json_dumps(wire_payload).encode("utf-8"))
            text_block = types.TextContent(type="text", text=json_dumps(wire_payload))
            if "structured_content" in types.CallToolResult.model_fields:
                return types.CallToolResult(
                    content=[text_block],
                    structured_content=structured if isinstance(structured, dict) else {"result": structured},
                )
            return types.CallToolResult(
                content=[text_block],
                structuredContent=structured if isinstance(structured, dict) else {"result": structured},
            )
        except (CatalogError, RowActionError, DocumentError, ResourceLimit, KeyError, TypeError, ValueError) as exc:
            code = getattr(exc, "code", "CATALOG-MCP-ERROR")
            mcp_error_cls = getattr(mcp, "MCPError", None)
            if mcp_error_cls is not None:
                raise mcp_error_cls(code=-32000, message=str(exc), data={"ddkCode": code}) from exc
            raise

    init_params = inspect.signature(Server.__init__).parameters
    if "on_list_tools" in init_params:
        async def _on_list_tools(_ctx, _params):
            return types.ListToolsResult(tools=_build_sdk_tools())

        async def _on_call_tool(_ctx, params):
            return _invoke_tool(params.name, params.arguments)

        server = Server(
            server_name,
            version=__version__,
            on_list_tools=_on_list_tools,
            on_call_tool=_on_call_tool,
            get_tool_input_schema=lambda name: tool_schemas_by_name.get(name),
        )
    else:
        server = Server(server_name)

        @server.list_tools()
        async def _legacy_list_tools():
            return _build_sdk_tools()

        @server.call_tool()
        async def _legacy_call_tool(name: str, arguments: dict[str, Any] | None):
            return _invoke_tool(name, arguments)

    server.ddk_catalog_server = dispatcher  # type: ignore[attr-defined]
    return server
