"""DDK command-line composition root; optional engines load only on invocation."""

import argparse
import re
from pathlib import Path
import sys
import tempfile

from .core import check_inventory, check_project, load_project
from .documents import DocumentError, ResourceLimit, json_dumps, read_json
from .impact import impact_projects
from .locks import write_json_atomic
from .results import ReportBuilder, diagnostic, exit_code


class UsageError(ValueError):
    pass


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise UsageError(message)


def _parser():
    parser = Parser(prog="ddk", description="Check evidence-bound catalogs offline; explicitly select native integrations.")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("check", "impact", "catalog", "managed"):
        command = commands.add_parser(name)
        if name != "impact":
            command.add_argument("project")
        else:
            command.add_argument("--base", required=True)
            command.add_argument("--candidate", required=True)
            command.add_argument("--non-weakening", action="store_true")
            command.add_argument("--base-catalog")
            command.add_argument("--candidate-catalog")
            command.add_argument("--require-complete-scope", action="store_true")
        command.add_argument("--format", choices=("json", "human"), default="human")
        command.add_argument("--progress", action="store_true", help="Send command progress to standard error")
        command.add_argument("--severity", choices=("error", "warning", "info"), action="append",
                             help="Display only these diagnostic severities in human output")
        command.add_argument("--require", action="append", default=[])
        command.add_argument("--permit-root", action="append", default=[])
        command.add_argument("--select", action="append")
        command.add_argument("--output")
        if name != "catalog":  # catalog writes catalog.lock.json every build but verifies no prior lock (DDK-CATALOG-007)
            command.add_argument("--lock")
            command.add_argument("--locked", action="store_true")
        if name == "check":
            command.add_argument("--adapter-manifest", action="append", default=[])
        if name in ("check", "managed", "catalog"):
            command.add_argument("--tool-python")
            command.add_argument("--timeout", type=float, default=120)
            command.add_argument("--docspec")
            command.add_argument("--limits")
        if name == "catalog":
            command.add_argument("--docspec-limits")
        if name in ("catalog", "impact"):
            command.add_argument("--peer-catalog", metavar="ALIAS=DIR", action="append", default=[],
                                 help="Bind an imported peer catalog output directory")
        if name == "catalog":
            command.add_argument("--metadata")
            command.add_argument("--metadata-adapter")
            command.add_argument("--current-selection", nargs=2, metavar=("AUTHORITY", "PURPOSE"))
            command.add_argument("--disclosure-policy")
            command.add_argument("--export", action="append", default=[])
        if name == "managed":
            command.add_argument("target", nargs="?", default=None, help="Target path or URL for managed observe")
            command.add_argument("--workspace")
            command.add_argument("--backend", default="local-iceberg")
            command.add_argument("--request")
            command.add_argument("--prior", help="Retained managed receipt or report for reconciliation")
            command.add_argument("--name", help="Dataset name for managed observe")
            command.add_argument("--etag", help="Expected ETag for managed observe")
    mcp_cmd = commands.add_parser("mcp", help="Run stdio MCP server for a compiled catalog directory")
    mcp_cmd.add_argument("catalog_dir", help="Path to directory containing catalog.lock.json")
    mcp_cmd.add_argument("--lock-sha256")
    mcp_cmd.add_argument("--audience", choices=("public", "local"))
    mcp_cmd.add_argument("--permit-root", action="append", default=[])
    mcp_cmd.add_argument("--docspec")
    mcp_cmd.add_argument("--limits")
    mcp_cmd.add_argument("--timeout", type=float, default=120)
    mcp_cmd.add_argument("--allow-insecure-http", action="store_true")
    mcp_cmd.add_argument("--jsonl", action="store_true", help="Serve raw newline-delimited JSON-RPC 2.0 on stdin/stdout")
    mcp_cmd.add_argument("--format", choices=("json", "human"), default="json")
    mcp_cmd.add_argument("--severity", choices=("error", "warning", "info"), action="append")

    ext_cmd = commands.add_parser(
        "publish-external",
        help="Assemble and optionally CAS-publish a DDK release bundle over external immutable Parquet objects",
    )
    ext_cmd.add_argument("descriptor", help="Path to external generation descriptor JSON manifest")
    ext_cmd.add_argument("-o", "--output", required=True, help="Output directory for compiled catalog artifacts")
    ext_cmd.add_argument("--bundle-dir", help="Optional output directory for staged remote publication artifacts")
    ext_cmd.add_argument("--destination", help="Path to RemoteDestination JSON config")
    ext_cmd.add_argument("--owned-prefix", help="Target remote S3/R2 owned prefix (s3://bucket/prefix)")
    ext_cmd.add_argument("--public-base-url", help="Public HTTPS/HTTP base URL for anonymous consumer readback")
    ext_cmd.add_argument("--release-prefix", help="Remote release prefix under owned_prefix (default: releases)")
    ext_cmd.add_argument("--pointer-key", help="Remote live pointer key (default: current.json)")
    ext_cmd.add_argument("--key-template", help="Optional key template for normalizing descriptor entries")
    ext_cmd.add_argument("--storage-root", help="Local directory root for LocalFilesystemStorageAdapter")
    ext_cmd.add_argument("--r2-endpoint-url", help="Override HTTP/S3 endpoint base URL for CloudflareR2StorageAdapter")
    ext_cmd.add_argument("--r2-bucket", help="Bucket name override for CloudflareR2StorageAdapter")
    ext_cmd.add_argument("--r2-bearer-token-env", help="Env var name holding R2/S3 bearer token")
    ext_cmd.add_argument(
        "--expected-prior-release-id",
        help="CAS precondition: expected live release_id, or 'absent' if pointer must not exist",
    )
    ext_cmd.add_argument("--dataset", help="Override dataset identifier")
    ext_cmd.add_argument("--catalog-id", help="Override catalog URN")
    ext_cmd.add_argument("--project-id", help="Override project URN")
    ext_cmd.add_argument("--version", help="Override catalog/release version")
    ext_cmd.add_argument("--authority", help="Override catalog authority")
    ext_cmd.add_argument("--purpose", default="shadow-read", help="Catalog selection purpose (default: shadow-read)")
    ext_cmd.add_argument("--audience", choices=("public", "local"), default="public")
    ext_mode = ext_cmd.add_mutually_exclusive_group()
    ext_mode.add_argument("--dry-run", action="store_true", help="Verify CAS and parity against storage without uploads")
    ext_mode.add_argument("--publish", action="store_true", help="Upload DDK metadata, verify readback, and advance pointer")
    ext_cmd.add_argument("--skip-schema-parity", action="store_true", help="Skip Parquet footer schema parity check")
    ext_cmd.add_argument("--skip-member-bytes", action="store_true", help="Skip full-body member byte downloads during readback")
    ext_cmd.add_argument("--allow-insecure-http", action="store_true")
    ext_cmd.add_argument("--format", choices=("json", "human"), default="json")
    ext_cmd.add_argument("--severity", choices=("error", "warning", "info"), action="append")
    return parser


def _native(args, folder):
    runtime = tools = None
    if args.docspec:
        if not args.limits:
            raise UsageError("--docspec requires explicit --limits")
        from .adapters.docspec import DocSpecAdapter
        runtime = DocSpecAdapter(args.docspec, read_json(args.limits).value, timeout=args.timeout,
                                 evidence_dir=folder / "docspec")
    if args.tool_python:
        from .adapters.native import NativeTools
        tools = NativeTools(args.tool_python, output=folder / "native", timeout=args.timeout)
    return runtime, tools


def _peer_catalogs(args):
    peers = {}
    for argument in getattr(args, "peer_catalog", ()):
        alias, separator, directory = argument.partition("=")
        if not separator or not re.fullmatch(r"[a-z][a-z0-9-]*", alias) or not directory:
            raise UsageError("--peer-catalog requires ALIAS=DIR")
        if alias in peers:
            raise UsageError(f"Duplicate --peer-catalog binding for {alias!r}")
        peers[alias] = directory
    return peers


def _execute(args):
    shared = {"required_groups": args.require, "permitted_roots": args.permit_root}
    if args.command == "impact":
        return impact_projects(args.base, args.candidate, non_weakening=args.non_weakening, selection=args.select,
                               base_catalog=args.base_catalog, candidate_catalog=args.candidate_catalog,
                               require_complete_scope=args.require_complete_scope,
                               peer_catalogs=_peer_catalogs(args) or None, **shared)
    if args.command == "catalog":
        from .catalog import build_catalog
        if not args.output:
            raise UsageError("catalog requires --output")
        docspec_evidence = None
        if args.docspec:
            evidence_root = Path(args.output).resolve()
            evidence_root = evidence_root.with_name(evidence_root.name + ".evidence")
            evidence_root.mkdir(parents=True, exist_ok=True)
            docspec_evidence = Path(tempfile.mkdtemp(prefix="evidence-", dir=evidence_root))
        limits_arg = args.docspec_limits or args.limits
        report = build_catalog(
            args.project, metadata=args.metadata, metadata_adapter=args.metadata_adapter,
            exports=args.export, output=args.output, current_selection=args.current_selection,
            disclosure_policy=args.disclosure_policy, docspec=args.docspec,
            docspec_limits=read_json(limits_arg).value if limits_arg else None,
            docspec_evidence_dir=docspec_evidence, timeout=args.timeout,
            peer_catalogs=_peer_catalogs(args) or None, **shared,
        )
        if docspec_evidence is not None and docspec_evidence.exists() and not any(docspec_evidence.iterdir()):
            docspec_evidence.rmdir()
            if not any(docspec_evidence.parent.iterdir()):
                docspec_evidence.parent.rmdir()
        return report
    if args.command == "check" and not args.tool_python:
        return check_project(args.project, lock=args.lock, locked=args.locked, selection=args.select,
                             adapter_manifests=args.adapter_manifest, **shared)
    if args.command == "managed" and args.project == "observe":
        if not args.target:
            raise UsageError("managed observe requires a target path or URL")
        from .managed_observe import managed_observe
        return managed_observe(
            target=args.target,
            name=getattr(args, "name", None),
            docspec_bin=args.docspec,
            output_path=args.output,
            etag=getattr(args, "etag", None),
        )
    if args.command == "managed" and (not args.workspace or not args.request):
        raise UsageError("the following arguments are required: --workspace, --request")
    if args.output and args.command == "managed":
        retained = Path(args.output).resolve()
        retained = retained.with_name(retained.name + ".evidence")
        retained.mkdir(parents=True, exist_ok=True)
        folder = Path(tempfile.mkdtemp(prefix="evidence-", dir=retained))
    else:
        folder = Path(tempfile.mkdtemp(prefix="ddk-command-"))
    runtime, tools = _native(args, folder)
    if args.command == "check":
        from .quality import dataset_rules
        inventory = load_project(args.project, permitted_roots=args.permit_root)
        check_inventory(inventory, required_groups=args.require, handled_groups=("odcs.lint",), selection=args.select,
                        lock=args.lock, locked=args.locked, adapter_manifests=args.adapter_manifest)
        from .execution import _record
        if "odcs.lint" in inventory.report.required_groups:
            if inventory.report.build()["decision"] in ("failed", "error"):
                return inventory.report.build()
            datasets = [(alias, artifact) for alias, artifact in inventory.artifacts.items() if artifact.kind == "dataset"]
            if datasets:
                batch = tools.invoke(
                    "odcs-lint",
                    {"documents": [{"alias": alias, **dataset_rules(artifact)} for alias, artifact in datasets]},
                )
                if batch.get("status") in {"passed", "failed", "unknown", "not_run"} and isinstance(batch.get("results"), dict):
                    receipt = batch.get("receipt")
                    for alias, _ in datasets:
                        item = batch["results"][alias]
                        _record(
                            inventory.report, "odcs.lint", alias,
                            {**item, **({"receipt": receipt} if receipt else {})},
                            requirement="DDK-ADAPTER-003",
                        )
                else:
                    for alias, _ in datasets:
                        _record(inventory.report, "odcs.lint", alias, batch, requirement="DDK-ADAPTER-003")
        return inventory.report.build()
    from .execution import _record
    group = "runtime.managed"
    groups = [group, *args.require]
    inventory = load_project(args.project, permitted_roots=args.permit_root)
    check_inventory(inventory, required_groups=groups, handled_groups=(group,), lock=args.lock, locked=args.locked)
    if inventory.report.build()["decision"] in ("failed", "error"):
        return inventory.report.build()
    request = read_json(args.request).value
    if runtime is None:
        inventory.report.add("DDK-CLI-004", group, "managed", "not_run", reason="Explicit DocSpec executable is required")
        return inventory.report.build()
    prior = None
    if args.prior:
        prior = read_json(args.prior).value
        if isinstance(prior, dict) and prior.get("kind") == "report":
            prior = prior.get("metadata", {}).get("managed")
        if not isinstance(prior, dict) or "operationContext" not in prior:
            raise DocumentError("EXEC-RECONCILIATION-RECEIPT", "Expected a managed receipt with original operation scope")
    try:
        result = runtime.managed(args.workspace, request, prior=prior, backend=args.backend)
    except ValueError as exc:
        if prior is None:
            raise
        raise DocumentError("EXEC-RECONCILIATION-SCOPE", str(exc)) from exc
    _record(inventory.report, group, args.command, result)
    inventory.report.metadata[args.command] = result
    report = inventory.report.build(**({"operations": [result["operation"]]} if result.get("operation") else {}))
    if args.output:
        if report["decision"] == "passed" or not Path(args.output).exists():
            write_json_atomic(args.output, report)
    return report


def _render_human(report, severities):
    print("DDK " + report["decision"])
    for item in report["checks"]:
        visible = [record for record in item["diagnostics"]
                   if not severities or record["severity"] in severities]
        for record in visible:
            print(f"  {record['code']}: {record['message']}")
        if (not item["diagnostics"] and item["status"] != "passed" and item["applicable"]
                and not severities):
            print(f"  {item['group']}: {item['status']} — {item.get('reason', item['subject'])}")
    for record in report["operationalErrors"]:
        if not severities or record["severity"] in severities:
            print(f"  {record['code']}: {record['message']}")


def _run_mcp_cli(args) -> int:
    from .catalog_mcp import CatalogMcpServer, create_mcp_server

    adapter = None
    if args.docspec:
        if not args.limits:
            raise UsageError("--docspec requires explicit --limits")
        from .adapters.docspec import DocSpecAdapter
        adapter = DocSpecAdapter(args.docspec, read_json(args.limits).value, timeout=args.timeout)

    if args.jsonl:
        srv = CatalogMcpServer(
            args.catalog_dir,
            expected_lock_sha256=args.lock_sha256,
            permitted_roots=args.permit_root,
            adapter=adapter,
            audience=args.audience,
            allow_insecure_http=args.allow_insecure_http,
        )
        for line in sys.stdin:
            stripped = line.strip()
            if not stripped:
                continue
            sys.stdout.write(json_dumps(srv.handle_rpc(stripped)) + "\n")
            sys.stdout.flush()
        return 0

    import asyncio
    from mcp.server.stdio import stdio_server

    server = create_mcp_server(
        args.catalog_dir,
        expected_lock_sha256=args.lock_sha256,
        permitted_roots=args.permit_root,
        adapter=adapter,
        audience=args.audience,
        allow_insecure_http=args.allow_insecure_http,
    )

    async def _serve():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(_serve())
    return 0


def _run_publish_external_cli(args):
    import os
    from urllib.parse import urlsplit

    from .catalog_access import CatalogError
    from .platform import CloudflareR2StorageAdapter, LocalFilesystemStorageAdapter
    from .publication import (
        RemoteDestination,
        build_external_generation_bundle,
        dry_run_remote_publication,
        publish_and_verify_remote_publication,
    )

    builder = ReportBuilder("urn:ddk:command:publish-external", required_groups=("catalog.publication",))
    try:
        desc_path = Path(args.descriptor).resolve()
        desc_doc = read_json(desc_path).value
        if not isinstance(desc_doc, dict):
            raise UsageError("External generation descriptor must be a JSON object")

        dest_cfg = {}
        if args.destination:
            loaded_dest = read_json(Path(args.destination).resolve()).value
            if not isinstance(loaded_dest, dict):
                raise UsageError("--destination file must contain a JSON object")
            dest_cfg = dict(loaded_dest)
        elif isinstance(desc_doc.get("destination"), dict):
            dest_cfg = dict(desc_doc["destination"])

        owned_prefix = args.owned_prefix or dest_cfg.get("owned_prefix") or desc_doc.get("owned_prefix")
        if not owned_prefix:
            raise UsageError("publish-external requires --owned-prefix or --destination with owned_prefix")

        props = dict(dest_cfg.get("properties") or {})
        pub_url = args.public_base_url or props.get("public_base_url") or desc_doc.get("public_base_url") or desc_doc.get("base_url")
        if pub_url:
            props["public_base_url"] = str(pub_url).rstrip("/")

        destination = RemoteDestination(
            owned_prefix=owned_prefix,
            properties=props,
            secret_env=dict(dest_cfg.get("secret_env") or {}),
            release_prefix=args.release_prefix or dest_cfg.get("release_prefix") or "releases",
            pointer_key=args.pointer_key or dest_cfg.get("pointer_key") or "current.json",
        )

        storage = None
        if args.storage_root:
            storage = LocalFilesystemStorageAdapter(args.storage_root)
        elif args.r2_endpoint_url or props.get("public_base_url") or args.dry_run or args.publish:
            parsed_owned = urlsplit(owned_prefix)
            bucket = args.r2_bucket or parsed_owned.netloc
            token = os.environ.get(args.r2_bearer_token_env) if args.r2_bearer_token_env else None
            endpoint = args.r2_endpoint_url or props.get("public_base_url")
            if endpoint or bucket:
                storage = CloudflareR2StorageAdapter(
                    bucket=bucket,
                    public_base_url=endpoint,
                    bearer_token=token,
                )

        if (args.dry_run or args.publish) and storage is None:
            raise UsageError("--dry-run and --publish require --storage-root, --r2-endpoint-url, or --public-base-url")

        has_prior_arg = args.expected_prior_release_id is not None
        if has_prior_arg:
            exp_prior = None if args.expected_prior_release_id == "absent" else args.expected_prior_release_id
        elif "expected_prior_release_id" in desc_doc:
            exp_prior = desc_doc["expected_prior_release_id"]
        else:
            exp_prior = ...

        bundle = build_external_generation_bundle(
            descriptor=desc_path,
            destination=destination,
            output_dir=args.output,
            bundle_dir=args.bundle_dir,
            dataset=args.dataset,
            expected_prior_release_id=exp_prior,
            catalog_id=args.catalog_id,
            project_id=args.project_id,
            version=args.version,
            authority=args.authority,
            purpose=args.purpose,
            audience=args.audience,
            verify_schema_parity=not args.skip_schema_parity,
            storage=storage,
            base_url=props.get("public_base_url"),
            key_template=args.key_template,
            allow_insecure_http=args.allow_insecure_http,
        )

        if args.dry_run:
            action_res = dry_run_remote_publication(
                bundle,
                storage=storage,
                expected_prior_release_id=exp_prior,
                verify_schema_parity=not args.skip_schema_parity,
                allow_insecure_http=args.allow_insecure_http,
            )
        elif args.publish:
            action_res = publish_and_verify_remote_publication(
                bundle,
                storage=storage,
                expected_prior_release_id=exp_prior,
                verify_schema_parity=not args.skip_schema_parity,
                verify_member_bytes=not args.skip_member_bytes,
                allow_insecure_http=args.allow_insecure_http,
            )
        else:
            action_res = {
                "action": "bundle",
                "status": "staged",
                "release_id": bundle.release_id,
                "parquet_upload_count": 0,
                "parquet_referenced": list(bundle.plan.external_member_keys),
                "catalog_dir": str(bundle.catalog_dir),
                "lock_sha256": bundle.lock_sha256,
                "catalog_sha256": bundle.catalog_sha256,
            }

        summary_action = dict(action_res)
        if isinstance(summary_action.get("readback"), dict):
            rb = summary_action["readback"]
            summary_action["readback"] = {
                "release_id": rb.get("release_id"),
                "etag": rb.get("etag"),
                "lock_sha256": rb.get("lock_sha256"),
                "catalog_artifacts": sorted(rb.get("catalog_artifacts") or ()),
                "verified_members": rb.get("verified_members", []),
                "verified_iceberg_snapshots": rb.get("verified_iceberg_snapshots", []),
            }

        builder.add("DDK-PUBLICATION-001", "catalog.publication", "publish-external", "passed")
        builder.metadata["publish_external"] = {
            **summary_action,
            "release_id": bundle.release_id,
            "dataset": bundle.dataset,
            "catalog_dir": str(bundle.catalog_dir),
            "lock_sha256": bundle.lock_sha256,
            "catalog_sha256": bundle.catalog_sha256,
            "schema_parity": [dict(item) for item in bundle.schema_parity],
            "iceberg_tables": [snap.table_name for snap in bundle.iceberg_snapshots],
        }
        return builder.build()
    except (CatalogError, ValueError) as exc:
        err_code = exc.code if isinstance(exc, CatalogError) else "DDK-PUBLICATION-001"
        builder.add(
            "DDK-PUBLICATION-001",
            "catalog.publication",
            "publish-external",
            "failed",
            diagnostics=[diagnostic(err_code, str(exc))],
        )
        return builder.build()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    code = None
    severities = ()
    json_output = any(argv[i:i+2] == ["--format", "json"] for i in range(len(argv))) or "--format=json" in argv
    try:
        args = _parser().parse_args(argv)
        severities = args.severity or ()
        if args.command == "mcp":
            return _run_mcp_cli(args)
        if getattr(args, "progress", False):
            print(f"DDK {args.command} started", file=sys.stderr)
        if args.command == "publish-external":
            report = _run_publish_external_cli(args)
        else:
            report = _execute(args)
        if args.output and (args.command in ("check", "impact") or (args.command == "managed" and getattr(args, "project", None) == "observe")) and (
            report["decision"] == "passed" or not Path(args.output).exists()
        ):
            write_json_atomic(args.output, report)
        code = exit_code(report)
    except (UsageError, DocumentError, OSError, ResourceLimit, ValueError) as exc:
        builder = ReportBuilder("urn:ddk:command")
        if isinstance(exc, UsageError):
            code = 64
        if isinstance(exc, DocumentError):
            builder.add("DDK-SYNTAX-002", "core.documents", "command", "failed",
                        diagnostics=[diagnostic(exc.code, str(exc), pointer=exc.pointer)])
        else:
            builder.error(diagnostic("CLI-USAGE" if isinstance(exc, UsageError) else "CLI-ERROR", str(exc)))
        report = builder.build()
        code = code if code is not None else exit_code(report)
    if json_output:
        print(json_dumps(report))
    else:
        _render_human(report, severities)
    return code
