"""Relationship semantics and checked access to catalog versions."""

import base64
from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import hashlib
from hashlib import sha256
import hmac
import http.client
import io
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import stat
from urllib.parse import unquote, urlsplit

from . import __version__
from .documents import (
    DEFAULT_LIMITS, DocumentError, ResourceLimit, json_dumps, parse_json,
    read_json, resolve_path, schema_validator, validate_document,
)

DEFAULT_HTTP_USER_AGENT = f"data-design-kit/{__version__}"


class CatalogError(DocumentError):
    def __init__(self, code, message, pointer="", *, status="failed", related=(), step=None):
        super().__init__(code, message, pointer)
        self.status = status
        self.related = tuple(related)
        self.step = step


def field_at(schema, path):
    field = schema
    for segment in path:
        if "each" in segment:
            if field.get("logicalType") != "array" or "items" not in field:
                return None
            field = field["items"]
        else:
            matches = [item for item in field.get("properties", ()) if item["name"] == segment["field"]]
            if len(matches) != 1:
                return None
            field = matches[0]
    return field


def row_identity_paths(schema):
    """Read the one ordered ODCS row identity for catalog and data-check owners."""
    declared = [item for item in schema.get("customProperties", ())
                if item.get("vendor") == "ddk" and item.get("property") == "rowIdentity"]
    if not declared:
        return None
    names = declared[0]["value"]
    if (len(declared) != 1 or not isinstance(names, list) or not names
            or any(not isinstance(name, str) for name in names) or len(set(names)) != len(names)):
        raise CatalogError("CATALOG-KEY-INCOMPLETE", "An ODCS row identity needs unique ordered field names.")
    paths = [[{"field": name}] for name in names]
    for name, path in zip(names, paths):
        if field_at(schema, path) is None:
            raise CatalogError("CATALOG-KEY-PATH", f"Declared identity field {name!r} is missing.")
    return paths


def row_identity_names(schema):
    """The object's ordered row identity: its DDK rowIdentity annotation, else its ODCS primaryKey properties."""
    paths = row_identity_paths(schema)
    if paths is not None:
        return [path[0]["field"] for path in paths]
    primary = [field for field in schema.get("properties", ()) if field.get("primaryKey") is True]
    if not primary:
        return None
    positions = [field.get("primaryKeyPosition", -1) for field in primary]
    if len(primary) > 1 and (any(position < 1 for position in positions) or len(set(positions)) != len(positions)):
        raise CatalogError("CATALOG-KEY-INCOMPLETE", "A composite ODCS key needs unambiguous positions.")
    return [field["name"] for field in sorted(primary, key=lambda field: field.get("primaryKeyPosition", -1))]


def field_type(field):
    """The initial equality profile recognizes only native bytes and supported logical scalars."""
    logical = field.get("logicalType")
    physical = field.get("physicalType", "").lower()
    if physical in {"binary", "bytes", "bytea", "blob", "varbinary", "fixed_size_binary"}:
        return "binary"
    if logical == "string" and field.get("logicalTypeOptions", {}).get("format") in {"byte", "binary"}:
        return None
    if logical == "date":
        calendars = [item["value"] for item in field.get("customProperties", ())
                     if item.get("vendor") == "ddk" and item.get("property") == "calendar"]
        if calendars and calendars != ["gregorian"]:
            return None
    if logical in {"integer", "string", "date"}:
        return logical
    return None


def compare_equal(source_key, target_key, types, nulls):
    """Compare one ordered key pair under the shared exact equality rule."""
    if not types or len(source_key) != len(target_key) or len(source_key) != len(types):
        raise CatalogError("CATALOG-KEY-INCOMPLETE", "Both keys must supply every ordered component.")
    validators = {"integer": int, "string": str, "binary": bytes, "date": date}
    if nulls not in {"skip", "reject", "match"} or any(kind not in validators for kind in types):
        return {"status": "unknown", "reason": "The equality profile does not support this type or null policy."}
    if any(value is None for value in (*source_key, *target_key)):
        if nulls == "reject":
            raise CatalogError("CATALOG-KEY-NULL", "A rejected null occurred in the comparison key.")
        if nulls == "skip":
            return {"status": "passed", "matched": False}
    for left, right, kind in zip(source_key, target_key, types):
        if any(value is not None and type(value) is not validators[kind] for value in (left, right)):
            raise CatalogError("CATALOG-KEY-TYPE", "A key value has a different type from its definition.")
    return {"status": "passed", "matched": tuple(source_key) == tuple(target_key)}


def endpoint_matches_row(endpoint, row):
    """Return True when *row* satisfies an endpoint's optional ``when`` discriminator."""
    when = endpoint.get("when") if isinstance(endpoint, dict) else None
    if not when:
        return True
    if not isinstance(row, dict):
        return False
    val = row.get(when["field"])
    expected = when["equals"]
    if isinstance(expected, bool) or isinstance(val, bool):
        return type(val) is type(expected) and val == expected
    return val == expected


def relationship_keys(row, paths, *, when=None):
    """Return keys with list positions so components from separate occurrences remain distinguishable."""
    if isinstance(paths, dict):
        if when is None:
            when = paths.get("when")
        paths = paths["paths"]
    if when is not None and not endpoint_matches_row({"when": when}, row):
        return []

    def occurrences(value, path, prefix=(), positions=()):
        if not path:
            yield value, positions
            return
        segment, *tail = path
        if "field" in segment:
            name = segment["field"]
            if not isinstance(value, dict) or name not in value:
                raise CatalogError("CATALOG-KEY-PATH", "A key path is missing from the row.", status="unknown")
            yield from occurrences(value[name], tail, (*prefix, ("field", name)), positions)
        elif isinstance(value, (list, tuple)):
            prefix = (*prefix, ("each",),)
            for index, member in enumerate(value):
                yield from occurrences(member, tail, prefix, (*positions, (prefix, index)))
        else:
            raise CatalogError("CATALOG-KEY-PATH", "A key path requires a list.", status="unknown")

    keys = [((), {})]
    for path in paths:
        next_keys = []
        for value, positions in occurrences(row, path):
            for components, context in keys:
                if all(context.get(prefix, index) == index for prefix, index in positions):
                    next_keys.append(((*components, value), {**context, **dict(positions)}))
        keys = next_keys
    return keys


def match_relationship_rows(relationship, source_rows, target_rows, *, types=None):
    """Match *source_rows* to *target_rows* under ``relationship``, honoring ``when`` on source and target."""
    source = relationship["source"]
    target = relationship["target"]
    nulls = relationship.get("nulls", "skip")
    matches = []
    eligible_targets = [
        (t_idx, t_row, relationship_keys(t_row, target))
        for t_idx, t_row in enumerate(target_rows)
        if endpoint_matches_row(target, t_row)
    ]
    for s_idx, s_row in enumerate(source_rows):
        if not endpoint_matches_row(source, s_row):
            continue
        for s_key, s_pos in relationship_keys(s_row, source):
            eff_types = types
            if eff_types is None:
                eff_types = tuple(
                    "integer" if (isinstance(v, int) and not isinstance(v, bool))
                    else "binary" if isinstance(v, bytes)
                    else "date" if (isinstance(v, date) and not isinstance(v, datetime))
                    else "string"
                    for v in s_key
                )
            for t_idx, t_row, t_keys in eligible_targets:
                for t_key, t_pos in t_keys:
                    cmp_res = compare_equal(s_key, t_key, eff_types, nulls)
                    if cmp_res.get("matched"):
                        matches.append({
                            "sourceIndex": s_idx,
                            "targetIndex": t_idx,
                            "sourceRow": s_row,
                            "targetRow": t_row,
                            "sourcePositions": s_pos,
                            "targetPositions": t_pos,
                        })
    return matches


def _record(records, identity, role):
    candidates = [item for item in records if item["id"] == identity]
    if len(candidates) != 1:
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", f"Expected one {role} for {identity!r}.")
    return candidates[0]


def _peer_catalog_doc(peer):
    from .catalog_delivery import CatalogArtifacts

    if isinstance(peer, CatalogArtifacts):
        if not peer.externally_pinned:
            raise CatalogError("CATALOG-EXTERNAL-PIN", "Captured peer catalog access requires an external lock pin.")
        return peer.catalog
    if isinstance(peer, dict):
        return peer
    raise CatalogError("CATALOG-BINDING-UNRESOLVED", "Supply a CatalogArtifacts or catalog mapping for peer binding.",
                       status="unknown")


def _version_binding(catalog, aliases, *, release=None, selection=None, versions=None, peer_catalogs=None):
    local_aliases = {name: alias for name, alias in aliases.items() if isinstance(alias, str)}
    peer_aliases = {name: alias for name, alias in aliases.items() if isinstance(alias, dict)}
    if peer_aliases and versions is None:
        raise CatalogError("CATALOG-BINDING-UNRESOLVED",
                           "Cross-catalog bindings require explicit version mappings across catalogs.")
    if (release is not None) + (selection is not None) + (versions is not None) != 1:
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", "Supply one exact release, selection, or version mapping.")
    versions_by_id = {item["id"]: item for item in catalog["versions"]}
    if len(versions_by_id) != len(catalog["versions"]):
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", "Dataset version identifiers are ambiguous.")
    if any(set(item["members"]) - versions_by_id.keys() for item in catalog["releases"]):
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", "A release includes an unresolved version.")
    chosen = None
    if selection is not None:
        if not isinstance(selection, dict) or set(selection) - {"authority", "purpose", "release", "record"}:
            raise CatalogError("CATALOG-BINDING-UNRESOLVED", "The selection needs its authority and purpose.")
        if not {"authority", "purpose"} <= selection.keys():
            raise CatalogError("CATALOG-BINDING-UNRESOLVED", "The selection needs its authority and purpose.")
        matches = [item for item in catalog["selections"] if all(item[key] == value for key, value in selection.items())]
        matches = [item for item in matches if set(local_aliases.values()) <= {
            versions_by_id[member]["dataset"]
            for member in _record(catalog["releases"], item["release"], "release")["members"]
        }]
        if len(matches) != 1:
            raise CatalogError("CATALOG-BINDING-UNRESOLVED", "Expected one selection that covers every required input.")
        chosen = matches[0]
        release = chosen["release"]
    release_record = _record(catalog["releases"], release, "release") if release is not None else None
    if versions is not None and (not isinstance(versions, dict) or set(versions) != set(aliases)):
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", "Supply an exact version for every required input.")
    bound = {}
    for name, alias in local_aliases.items():
        if release_record is not None:
            candidates = [versions_by_id[key] for key in release_record["members"]
                          if versions_by_id[key]["dataset"] == alias]
            if len(candidates) != 1:
                raise CatalogError("CATALOG-BINDING-UNRESOLVED",
                                   f"Release {release!r} needs one version of {alias!r}.")
            version = candidates[0]
        else:
            version = _record(catalog["versions"], versions[name], "dataset version")
            if version["dataset"] != alias:
                raise CatalogError("CATALOG-VERSION-MISMATCH", f"Version {version['id']!r} does not bind {alias!r}.")
        bound[name] = version
    for name, target in peer_aliases.items():
        peer_alias, peer_ds = target["catalog"], target["dataset"]
        if not peer_catalogs or peer_alias not in peer_catalogs:
            raise CatalogError("CATALOG-BINDING-UNRESOLVED",
                               f"Peer catalog {peer_alias!r} is required to bind {name!r}.", status="unknown")
        peer_doc = _peer_catalog_doc(peer_catalogs[peer_alias])
        version = _record(peer_doc["versions"], versions[name], "peer dataset version")
        if version["dataset"] != peer_ds:
            raise CatalogError("CATALOG-VERSION-MISMATCH",
                               f"Version {version['id']!r} does not bind peer dataset {peer_ds!r}.")
        bound[name] = version
    result = {"inputs": bound}
    if release_record is not None:
        result["release"] = release_record
    if chosen is not None:
        result["selection"] = chosen
    return deepcopy(result)


def resolve_relationship(catalog, relationship_id, *, release=None, selection=None, versions=None, peer_catalogs=None):
    relationship = _record(catalog["relationships"], relationship_id, "relationship")
    if "external" in relationship["target"] or relationship["scope"] == "declared":
        raise CatalogError("CATALOG-BINDING-UNRESOLVED", "This relationship needs a project-specific scope resolver.",
                           status="unknown")
    if relationship["scope"] == "same_release" and release is None and selection is None:
        raise CatalogError("CATALOG-RELEASE-SCOPE", "Both endpoints must bind to one exact release.")
    aliases = {
        side: ({"catalog": relationship[side]["catalog"], "dataset": relationship[side]["dataset"]}
               if "catalog" in relationship[side] else relationship[side]["dataset"])
        for side in ("source", "target")
    }
    return _version_binding(catalog, aliases, release=release, selection=selection, versions=versions,
                            peer_catalogs=peer_catalogs)


def resolve_query(catalog, recipe_id, *, release=None, selection=None, versions=None, parameters=None,
                  peer_catalogs=None):
    recipe = _record(catalog["recipes"], recipe_id, "query recipe")
    parameters = {} if parameters is None else parameters
    errors = list(schema_validator(recipe["parameters"]).iter_errors(parameters))
    if errors:
        raise CatalogError("CATALOG-QUERY-PARAMETERS", errors[0].message)
    binding = _version_binding(catalog, recipe["inputs"], release=release, selection=selection, versions=versions,
                               peer_catalogs=peer_catalogs)
    for relationship_id in recipe["relationships"]:
        relationship = _record(catalog["relationships"], relationship_id, "relationship")
        if relationship["scope"] == "same_release" and "release" not in binding:
            raise CatalogError("CATALOG-RELEASE-SCOPE", "The recipe needs one exact release for its relationship.")
        if relationship["scope"] in {"external", "declared"}:
            raise CatalogError("CATALOG-BINDING-UNRESOLVED", "The recipe uses a relationship with unsupported scope.",
                               status="unknown")
    return {"recipe": recipe_id, "dialect": recipe["dialect"], "parameters": deepcopy(parameters),
            **({"parameterOrder": list(recipe["parameterOrder"])} if "parameterOrder" in recipe else {}), **binding}


def run_checked_query(catalog_path, recipe_id, reader, **binding_args):
    """Use a path or one externally pinned CatalogArtifacts capture for the read."""
    from .catalog_delivery import CatalogArtifacts

    captured = catalog_path if isinstance(catalog_path, CatalogArtifacts) else None
    if captured is not None:
        if not captured.externally_pinned:
            raise CatalogError("CATALOG-EXTERNAL-PIN", "Captured data access requires an externally pinned catalog.")
        catalog = captured.catalog
    else:
        document = read_json(catalog_path)
        issues = validate_document(document.value, "catalog")
        if issues:
            raise CatalogError(issues[0].code, issues[0].message, issues[0].pointer)
        catalog = document.value
    binding = resolve_query(catalog, recipe_id, **binding_args)
    recipe = _record(catalog["recipes"], recipe_id, "query recipe")
    candidates = [item for item in catalog["files"] if item["path"] == recipe["sql"] and item["role"] == "recipe"]
    if len(candidates) != 1:
        raise CatalogError("CATALOG-RECIPE-INTEGRITY", "The SQL has no unique companion inventory entry.")
    if any("reference" not in item for item in binding["inputs"].values()):
        raise CatalogError("CATALOG-VERSION-WITHHELD", "The exact native reference is unavailable in this catalog view.",
                           status="unknown")
    if captured is not None:
        sql = captured.companions.get(recipe["sql"])
        if not isinstance(sql, bytes):
            raise CatalogError("CATALOG-RECIPE-INTEGRITY", "The selected capture omits its exact SQL companion bytes.")
    else:
        sql_path = resolve_path(document.path, recipe["sql"], (document.path.parent,))
        with sql_path.open("rb") as stream:
            sql = stream.read(DEFAULT_LIMITS["maxDocumentBytes"] + 1)
    if len(sql) > DEFAULT_LIMITS["maxDocumentBytes"]:
        raise ResourceLimit("The recipe exceeds the default document byte limit.")
    if sha256(sql).hexdigest() != candidates[0]["sha256"]:
        raise CatalogError("CATALOG-RECIPE-INTEGRITY", "The SQL bytes differ from their catalog digest.")
    request = deepcopy(binding)
    request["sql"] = sql
    result = reader(request)
    if not isinstance(result, dict) or not result.get("receipt") or "result" not in result:
        raise CatalogError("CATALOG-READ-RECEIPT", "The reader must return a result and its native read receipt.",
                           status="unknown")
    return {**result, "binding": binding, "sqlSha256": candidates[0]["sha256"]}


_SHARED_CURSOR_SECRET = secrets.token_bytes(32)


def _encode_exact_json_value(value):
    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return {"$number": str(value)}
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise CatalogError("CATALOG-UNSUPPORTED-VALUE", "Non-finite floats cannot be encoded losslessly")
        return {"$number": "-0" if (value == 0.0 and str(value).startswith("-")) else repr(value)}
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise CatalogError("CATALOG-UNSUPPORTED-VALUE", "Non-finite decimals cannot be encoded losslessly")
        return {"$number": format(value, "f") if "E" not in str(value) and "e" not in str(value) else str(value)}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"type": "binary", "encoding": "base64", "value": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, datetime):
        utc = value.astimezone(timezone.utc) if value.tzinfo else value.replace(tzinfo=timezone.utc)
        epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)
        delta = utc - epoch
        micros = (delta.days * 86400 + delta.seconds) * 1_000_000 + delta.microseconds
        return {"type": "timestamp", "unit": "us", "value": {"$number": str(micros)}}
    if isinstance(value, date):
        days = (value - date(1970, 1, 1)).days
        return {"type": "date", "days": {"$number": str(days)}}
    if isinstance(value, (list, tuple)):
        return [_encode_exact_json_value(item) for item in value]
    if isinstance(value, dict):
        items = [(str(k), _encode_exact_json_value(v)) for k, v in value.items()]
        if any(k in {"$number", "$object"} for k, _ in items):
            return {"$object": items}
        return dict(items)
    return str(value)


def _b64u_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_decode(text: str) -> bytes:
    pad = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + pad)


def _canonical_scope_bytes(scope: dict) -> bytes:
    return json_dumps(scope, sort_keys=True).encode("utf-8")


def bind_continuation_cursor(scope: dict, *, offset: int, last_key=None, secret: bytes | None = None) -> str:
    """Create an HMAC-bound continuation token tied to exact query/read scope."""
    key = secret or _SHARED_CURSOR_SECRET
    payload = {
        "v": 1,
        "scopeHash": sha256(_canonical_scope_bytes(scope)).hexdigest(),
        "offset": offset,
        **({"lastKey": _encode_exact_json_value(last_key)} if last_key is not None else {}),
    }
    encoded = _b64u_encode(json_dumps(payload, sort_keys=True).encode("utf-8"))
    sig = _b64u_encode(hmac.new(key, encoded.encode("ascii"), hashlib.sha256).digest())
    return f"{encoded}.{sig}"


def verify_continuation_cursor(cursor: str, expected_scope: dict, *, secret: bytes | None = None) -> dict:
    """Verify cursor integrity and exact binding to (catalogSha256, datasetId, versionId, representationId, filters, sort)."""
    if not isinstance(cursor, str) or "." not in cursor:
        raise CatalogError("CATALOG-CURSOR-INVALID", "Malformed continuation cursor")
    parts = cursor.split(".")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise CatalogError("CATALOG-CURSOR-INVALID", "Malformed continuation cursor")
    encoded, sig = parts
    key = secret or _SHARED_CURSOR_SECRET
    expected_sig = _b64u_encode(hmac.new(key, encoded.encode("ascii"), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, expected_sig):
        raise CatalogError("CATALOG-CURSOR-INVALID", "Continuation cursor signature failed verification")
    try:
        payload = parse_json(_b64u_decode(encoded))
    except (ValueError, ResourceLimit, Exception) as exc:
        raise CatalogError("CATALOG-CURSOR-INVALID", f"Invalid continuation cursor payload: {exc}") from exc
    if not isinstance(payload, dict) or payload.get("v") != 1:
        raise CatalogError("CATALOG-CURSOR-INVALID", "Unsupported continuation cursor version")
    expected_hash = sha256(_canonical_scope_bytes(expected_scope)).hexdigest()
    if payload.get("scopeHash") != expected_hash:
        raise CatalogError("CATALOG-CURSOR-MISMATCH",
                           "Continuation cursor is bound to a different catalog, version, filters, or sort")
    offset = payload.get("offset")
    if type(offset) is not int or offset < 0:
        raise CatalogError("CATALOG-CURSOR-INVALID", "Invalid continuation cursor offset")
    return payload


def _validate_remote_parquet_url(url: str, *, allow_insecure_http: bool = False):
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"} or not parts.hostname:
        raise CatalogError("CATALOG-REMOTE-URL", "Remote Parquet location must be an http(s) URL with a host")
    if parts.username or parts.password:
        raise CatalogError("CATALOG-REMOTE-URL", "Remote Parquet URLs must not contain embedded credentials")
    if parts.fragment:
        raise CatalogError("CATALOG-REMOTE-URL", "Remote Parquet URLs must not contain fragments")
    host = parts.hostname.lower()
    is_loopback = host in {"localhost", "127.0.0.1", "::1"}
    if not is_loopback:
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            ip = None
        if ip is not None:
            if ip.is_loopback:
                is_loopback = True
            elif ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_private or ip.is_reserved:
                raise CatalogError("CATALOG-REMOTE-URL", "Remote Parquet host address is not permitted")
    if parts.scheme == "http" and not (is_loopback or allow_insecure_http):
        raise CatalogError("CATALOG-REMOTE-URL", "Insecure http:// is allowed only for loopback test servers unless configured")
    return parts


class _HttpRangeParquetFile(io.RawIOBase):
    """Seekable, bounded HTTP Range reader for Parquet footer + row-group pruning."""

    def __init__(self, url: str, *, expected_byte_size: int | None = None, timeout: float = 15.0,
                 max_requests: int = 64, max_bytes_fetched: int = 16 << 20,
                 tail_preload_bytes: int = 65536, allow_insecure_http: bool = False,
                 user_agent: str | None = None, verify_head_size: bool = False):
        self.url = url
        self.parts = _validate_remote_parquet_url(url, allow_insecure_http=allow_insecure_http)
        self.expected_byte_size = expected_byte_size
        self.verify_head_size = verify_head_size
        self.timeout = timeout
        self.max_requests = max_requests
        self.max_bytes_fetched = max_bytes_fetched
        self.tail_preload_bytes = tail_preload_bytes
        self.user_agent = (user_agent or "").strip() or DEFAULT_HTTP_USER_AGENT
        self.pos = 0
        self.size = 0
        self.range_requests = 0
        self.bytes_fetched = 0
        self.ranges_log: list[tuple[int, int]] = []
        self._spans: list[tuple[int, int, bytes]] = []
        self._initialize_size_and_tail()

    def _connect(self):
        port = self.parts.port or (443 if self.parts.scheme == "https" else 80)
        cls = http.client.HTTPSConnection if self.parts.scheme == "https" else http.client.HTTPConnection
        return cls(self.parts.hostname, port, timeout=self.timeout)

    def _target_path(self) -> str:
        path = self.parts.path or "/"
        return f"{path}?{self.parts.query}" if self.parts.query else path

    def _fetch_range(self, start: int, end: int) -> tuple[bytes, int]:
        if start > end or start < 0:
            raise CatalogError("CATALOG-REMOTE-INCOMPLETE", "Invalid HTTP byte range requested", status="incomplete")
        requested_len = end - start + 1
        if self.range_requests >= self.max_requests:
            raise CatalogError("CATALOG-REMOTE-BUDGET", "Remote Parquet request budget exceeded", status="incomplete")
        if self.bytes_fetched + requested_len > self.max_bytes_fetched:
            raise CatalogError("CATALOG-REMOTE-BUDGET", "Remote Parquet byte budget exceeded", status="incomplete")
        self.range_requests += 1
        self.ranges_log.append((start, end))
        conn = self._connect()
        try:
            conn.request("GET", self._target_path(), headers={
                "Range": f"bytes={start}-{end}",
                "Accept-Encoding": "identity",
                "User-Agent": self.user_agent,
            })
            resp = conn.getresponse()
            if resp.status in (301, 302, 303, 307, 308):
                raise CatalogError("CATALOG-REMOTE-REDIRECT", "Remote Parquet redirects are refused", status="incomplete")
            body = resp.read(self.max_bytes_fetched - self.bytes_fetched + 1)
        except CatalogError:
            raise
        except (TimeoutError, OSError, http.client.HTTPException) as exc:
            raise CatalogError("CATALOG-READ-INTERRUPTED", f"Remote Parquet Range read interrupted: {exc}",
                               status="interrupted") from exc
        finally:
            conn.close()

        if len(body) > requested_len and resp.status == 206:
            raise CatalogError("CATALOG-REMOTE-INCOMPLETE", "Remote server returned more bytes than requested",
                               status="incomplete")
        total_size = None
        if resp.status == 206:
            cr = resp.getheader("Content-Range") or ""
            m = re.fullmatch(r"bytes\s+(\d+)-(\d+)/(\d+)", cr.strip())
            if not m or int(m.group(1)) != start or int(m.group(2)) != start + len(body) - 1:
                raise CatalogError("CATALOG-REMOTE-INCOMPLETE", f"Invalid Content-Range header: {cr!r}",
                                   status="incomplete")
            total_size = int(m.group(3))
            if len(body) != requested_len:
                raise CatalogError("CATALOG-READ-INTERRUPTED", "Truncated HTTP Range response", status="interrupted")
        elif resp.status == 200 and start == 0:
            cl = resp.getheader("Content-Length")
            if cl and cl.isdigit():
                total_size = int(cl)
            else:
                total_size = len(body)
            if len(body) > self.max_bytes_fetched:
                raise CatalogError("CATALOG-REMOTE-BUDGET", "Remote Parquet response exceeded byte budget",
                                   status="incomplete")
            body_end = min(end, len(body) - 1)
            body = body[: body_end + 1]
        else:
            raise CatalogError("CATALOG-REMOTE-INCOMPLETE", f"Remote Parquet Range request failed with HTTP {resp.status}",
                               status="incomplete")

        self.bytes_fetched += len(body)
        if self.expected_byte_size is not None and total_size != self.expected_byte_size:
            raise CatalogError("CATALOG-REMOTE-INTEGRITY",
                               f"Remote Parquet size ({total_size}) differs from pinned byteSize ({self.expected_byte_size})",
                               status="incomplete")
        self._spans.append((start, start + len(body), body))
        return body, total_size

    def _head_size(self) -> int:
        if self.range_requests >= self.max_requests:
            raise CatalogError("CATALOG-REMOTE-BUDGET", "Remote Parquet request budget exceeded", status="incomplete")
        self.range_requests += 1
        conn = self._connect()
        try:
            conn.request("HEAD", self._target_path(), headers={
                "Accept-Encoding": "identity",
                "User-Agent": self.user_agent,
            })
            resp = conn.getresponse()
            resp.read()
        except (TimeoutError, OSError, http.client.HTTPException) as exc:
            raise CatalogError("CATALOG-READ-INTERRUPTED", f"Remote Parquet HEAD interrupted: {exc}",
                               status="interrupted") from exc
        finally:
            conn.close()
        if resp.status in (301, 302, 303, 307, 308):
            raise CatalogError("CATALOG-REMOTE-REDIRECT", "Remote Parquet redirects are refused", status="incomplete")
        if resp.status not in (200, 206):
            raise CatalogError("CATALOG-REMOTE-INCOMPLETE", f"Remote Parquet HEAD failed with HTTP {resp.status}",
                               status="incomplete")
        cl = resp.getheader("Content-Length")
        if not cl or not cl.isdigit() or int(cl) < 12:
            raise CatalogError("CATALOG-REMOTE-INCOMPLETE", "Remote Parquet missing valid Content-Length",
                               status="incomplete")
        return int(cl)

    def _initialize_size_and_tail(self):
        if self.expected_byte_size is not None:
            if type(self.expected_byte_size) is not int or self.expected_byte_size < 12:
                raise CatalogError("CATALOG-REMOTE-INTEGRITY", "Invalid pinned byteSize for remote Parquet")
            if self.verify_head_size:
                head_total = self._head_size()
                if head_total != self.expected_byte_size:
                    raise CatalogError(
                        "CATALOG-REMOTE-INTEGRITY",
                        f"Remote Parquet HEAD Content-Length ({head_total}) differs from pinned byteSize ({self.expected_byte_size})",
                        status="incomplete",
                    )
            total = self.expected_byte_size
        else:
            total = self._head_size()
        self.size = total
        tail_len = min(self.tail_preload_bytes, total)
        start = total - tail_len
        self._fetch_range(start, total - 1)

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self.pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if whence == io.SEEK_SET:
            target = offset
        elif whence == io.SEEK_CUR:
            target = self.pos + offset
        elif whence == io.SEEK_END:
            target = self.size + offset
        else:
            raise OSError("Unsupported seek whence")
        if target < 0:
            raise OSError("Negative seek position")
        self.pos = min(target, self.size)
        return self.pos

    def read(self, size: int = -1) -> bytes:
        if self.pos >= self.size or size == 0:
            return b""
        if size is None or size < 0:
            size = self.size - self.pos
        end_excl = min(self.size, self.pos + size)
        out = self._read_interval(self.pos, end_excl)
        self.pos = end_excl
        return out

    def readinto(self, b) -> int:
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    def _read_interval(self, start: int, end_excl: int) -> bytes:
        if start >= end_excl:
            return b""
        # Check if already completely covered by one cached span
        for sp_start, sp_end, sp_buf in self._spans:
            if sp_start <= start and end_excl <= sp_end:
                return sp_buf[start - sp_start : end_excl - sp_start]
        # Fetch missing exact span (or assemble across gaps)
        result = bytearray()
        cursor = start
        ordered = sorted(self._spans, key=lambda item: (item[0], -item[1]))
        for sp_start, sp_end, sp_buf in ordered:
            if sp_end <= cursor:
                continue
            if sp_start >= end_excl:
                break
            if sp_start > cursor:
                fetched, _ = self._fetch_range(cursor, sp_start - 1)
                result.extend(fetched)
                cursor = sp_start
            take_end = min(sp_end, end_excl)
            result.extend(sp_buf[cursor - sp_start : take_end - sp_start])
            cursor = take_end
        if cursor < end_excl:
            fetched, _ = self._fetch_range(cursor, end_excl - 1)
            result.extend(fetched)
        return bytes(result)


def _coerce_comparable(val, arrow_type):
    import pyarrow as pa

    if val is None:
        return None
    if isinstance(val, dict) and "$number" in val:
        val = val["$number"]
    if pa.types.is_integer(arrow_type):
        return int(val)
    if pa.types.is_floating(arrow_type):
        return float(val)
    if pa.types.is_decimal(arrow_type):
        return Decimal(str(val))
    if pa.types.is_boolean(arrow_type):
        if isinstance(val, bool):
            return val
        if isinstance(val, str) and val.lower() in {"true", "false"}:
            return val.lower() == "true"
        return bool(val)
    if pa.types.is_string(arrow_type) or pa.types.is_large_string(arrow_type) or pa.types.is_string_view(arrow_type):
        return str(val)
    if pa.types.is_binary(arrow_type) or pa.types.is_large_binary(arrow_type) or pa.types.is_fixed_size_binary(arrow_type):
        if isinstance(val, bytes):
            return val
        if isinstance(val, dict) and val.get("type") == "binary" and val.get("encoding") == "base64":
            return base64.b64decode(val["value"])
        if isinstance(val, str):
            return val.encode("utf-8")
    if pa.types.is_date(arrow_type):
        if isinstance(val, date) and not isinstance(val, datetime):
            return val
        return date.fromisoformat(str(val))
    if pa.types.is_timestamp(arrow_type):
        if isinstance(val, datetime):
            return val
        return datetime.fromisoformat(str(val).replace("Z", "+00:00"))
    return val


def _normalize_filter_specs(filters, disclosed_cols):
    if filters is None:
        return []
    if not isinstance(filters, list):
        raise CatalogError("CATALOG-INVALID-FILTER", "Filters must be a list of column predicates")
    disclosed_set = set(disclosed_cols) if disclosed_cols is not None else None
    out = []
    for item in filters:
        if not isinstance(item, dict) or not isinstance(item.get("column"), str) or not item["column"]:
            raise CatalogError("CATALOG-INVALID-FILTER", "Each filter requires a column name")
        col = item["column"]
        if disclosed_set is not None and col not in disclosed_set:
            raise CatalogError("CATALOG-DISCLOSURE-WITHHELD", f"Filter column {col!r} is withheld or undisclosed")
        op = item.get("op", "eq")
        if op not in {"eq", "ne", "lt", "lte", "gt", "gte", "in"}:
            raise CatalogError("CATALOG-INVALID-FILTER", f"Unsupported filter operator {op!r}")
        if "value" not in item:
            raise CatalogError("CATALOG-INVALID-FILTER", f"Filter on {col!r} requires a value")
        out.append({"column": col, "op": op, "value": item["value"]})
    return out


def _normalize_sort_specs(sort_spec, disclosed_cols):
    if sort_spec is None:
        return []
    if not isinstance(sort_spec, list):
        raise CatalogError("CATALOG-INVALID-SORT", "Sort must be a list of {column, direction} entries")
    disclosed_set = set(disclosed_cols) if disclosed_cols is not None else None
    out = []
    for item in sort_spec:
        if isinstance(item, str):
            col, direction = item, "asc"
        elif isinstance(item, dict) and isinstance(item.get("column"), str) and item["column"]:
            col = item["column"]
            direction = item.get("direction", "asc")
        else:
            raise CatalogError("CATALOG-INVALID-SORT", "Invalid sort specification entry")
        if direction not in {"asc", "desc"}:
            raise CatalogError("CATALOG-INVALID-SORT", f"Invalid sort direction {direction!r}")
        if disclosed_set is not None and col not in disclosed_set:
            raise CatalogError("CATALOG-DISCLOSURE-WITHHELD", f"Sort column {col!r} is withheld or undisclosed")
        out.append({"column": col, "direction": direction})
    return out


def _row_group_might_match(rg_meta, arrow_schema, filters) -> bool:
    if not filters:
        return True
    name_to_idx = {arrow_schema.field(i).name: i for i in range(len(arrow_schema))}
    for f in filters:
        col = f["column"]
        if col not in name_to_idx:
            raise CatalogError("CATALOG-UNKNOWN-COLUMN", f"Filter column {col!r} is absent from Parquet schema")
        col_idx = name_to_idx[col]
        field = arrow_schema.field(col_idx)
        col_meta = rg_meta.column(col_idx)
        stats = col_meta.statistics
        if stats is None or not stats.has_min_max:
            continue
        try:
            mn = stats.min
            mx = stats.max
            op = f["op"]
            if op == "in":
                targets = [_coerce_comparable(v, field.type) for v in f["value"]]
                if not any((t is not None and mn <= t <= mx) for t in targets):
                    return False
                continue
            target = _coerce_comparable(f["value"], field.type)
            if target is None:
                continue
            if op == "eq" and (target < mn or target > mx):
                return False
            if op == "gt" and mx <= target:
                return False
            if op == "gte" and mx < target:
                return False
            if op == "lt" and mn >= target:
                return False
            if op == "lte" and mn > target:
                return False
        except TypeError:
            continue
    return True


def _coerce_arrow_scalar(val, arrow_type, pa):
    coerced = _coerce_comparable(val, arrow_type)
    if coerced is None:
        return None
    if pa.types.is_timestamp(arrow_type) and isinstance(coerced, datetime):
        if arrow_type.tz is None and coerced.tzinfo is not None:
            coerced = coerced.astimezone(timezone.utc).replace(tzinfo=None)
        elif arrow_type.tz is not None and coerced.tzinfo is None:
            coerced = coerced.replace(tzinfo=timezone.utc)
    return pa.scalar(coerced, type=arrow_type)


def _build_arrow_filter_expression(arrow_schema, filters, pa, pc):
    """Compile normalized filter specifications into one vectorized ``pyarrow.compute.Expression``."""
    if not filters:
        return None
    expr = None
    for f in filters:
        col = f["column"]
        idx = arrow_schema.get_field_index(col)
        if idx < 0:
            raise CatalogError("CATALOG-UNKNOWN-COLUMN", f"Filter column {col!r} is absent from Parquet schema")
        field = arrow_schema.field(idx)
        col_expr = pc.field(col)
        op = f["op"]
        if op == "in":
            raw_vals = f["value"]
            if not isinstance(raw_vals, (list, tuple)):
                raise CatalogError("CATALOG-INVALID-FILTER", f"'in' filter on {col!r} requires a list of values")
            scalars = [_coerce_arrow_scalar(v, field.type, pa) for v in raw_vals]
            has_null = any(s is None for s in scalars)
            non_null_py = [s.as_py() for s in scalars if s is not None]
            if non_null_py:
                value_set = pa.array(non_null_py, type=field.type)
                clause = pc.is_in(col_expr, value_set=value_set)
                if has_null:
                    clause = pc.or_kleene(clause, pc.is_null(col_expr))
            elif has_null:
                clause = pc.is_null(col_expr)
            else:
                clause = pa.scalar(False, type=pa.bool_())
        else:
            lit = _coerce_arrow_scalar(f["value"], field.type, pa)
            if lit is None:
                if op == "eq":
                    clause = pc.is_null(col_expr)
                elif op == "ne":
                    clause = pc.is_valid(col_expr)
                else:
                    clause = pa.scalar(False, type=pa.bool_())
            elif op == "eq":
                clause = pc.equal(col_expr, lit)
            elif op == "ne":
                clause = pc.or_kleene(pc.is_null(col_expr), pc.not_equal(col_expr, lit))
            elif op == "lt":
                clause = pc.less(col_expr, lit)
            elif op == "lte":
                clause = pc.less_equal(col_expr, lit)
            elif op == "gt":
                clause = pc.greater(col_expr, lit)
            elif op == "gte":
                clause = pc.greater_equal(col_expr, lit)
            else:
                raise CatalogError("CATALOG-INVALID-FILTER", f"Unsupported filter operator {op!r}")
        expr = clause if expr is None else pc.and_kleene(expr, clause)
    return expr


def _normalize_arrow_table_rows(table, arrow_schema):
    """Convert a sliced PyArrow Table page into Python row dicts with UTC-normalized timestamps."""
    import pyarrow as pa

    rows = table.to_pylist()
    naive_ts_cols = [
        field.name for field in table.schema
        if pa.types.is_timestamp(field.type) and field.type.tz is None
    ]
    if naive_ts_cols:
        for r in rows:
            for col in naive_ts_cols:
                v = r.get(col)
                if isinstance(v, datetime) and v.tzinfo is None:
                    r[col] = v.replace(tzinfo=timezone.utc)
    return rows


def resolve_catalog_dataset(catalog, dataset_ref):
    """Resolve a dataset record by exact catalog ``id`` or human-friendly ``alias``."""
    if not isinstance(dataset_ref, str) or not dataset_ref.strip():
        raise CatalogError("CATALOG-BINDING-MISMATCH", "Dataset identifier or alias is required")
    datasets = [d for d in catalog.get("datasets", ()) if isinstance(d, dict)]
    by_id = [d for d in datasets if d.get("id") == dataset_ref]
    if len(by_id) == 1:
        return by_id[0]
    cleaned = dataset_ref.lstrip("/")
    by_alias = [d for d in datasets if d.get("alias") == dataset_ref or d.get("alias") == cleaned]
    if len(by_alias) == 1:
        return by_alias[0]
    if len(by_id) > 1 or len(by_alias) > 1:
        raise CatalogError("CATALOG-AMBIGUOUS", f"Ambiguous dataset reference {dataset_ref!r}", status="ambiguous")
    raise CatalogError("CATALOG-BINDING-MISMATCH", f"Unknown dataset {dataset_ref!r}")


def resolve_active_dataset_version(catalog, dataset_alias, version_id=None):
    """Resolve explicit ``version_id`` or auto-select from the active selection / sole release / sole version."""
    all_versions = [v for v in catalog.get("versions", ()) if isinstance(v, dict)]
    versions_by_id = {v["id"]: v for v in all_versions if "id" in v}
    cand_versions = [
        v for v in all_versions
        if v.get("dataset") == dataset_alias and (version_id is None or v.get("id") == version_id)
    ]
    if version_id is not None or len(cand_versions) <= 1:
        if len(cand_versions) > 1:
            raise CatalogError("CATALOG-AMBIGUOUS", f"Multiple versions match dataset {dataset_alias!r}", status="ambiguous")
        if not cand_versions:
            raise CatalogError("CATALOG-BINDING-MISMATCH", f"No matching version for dataset {dataset_alias!r}")
        return cand_versions[0]

    releases_by_id = {r["id"]: r for r in catalog.get("releases", ()) if isinstance(r, dict) and "id" in r}

    # 1. Active selection(s) covering dataset_alias
    selected_version_ids = set()
    for sel in catalog.get("selections", ()) or ():
        rel = releases_by_id.get(sel.get("release"))
        if rel:
            for member_vid in rel.get("members", ()):
                ver = versions_by_id.get(member_vid)
                if ver and ver.get("dataset") == dataset_alias:
                    selected_version_ids.add(member_vid)
    if len(selected_version_ids) == 1:
        chosen_id = next(iter(selected_version_ids))
        return versions_by_id[chosen_id]

    # 2. Sole release covering dataset_alias
    release_version_ids = set()
    for rel in releases_by_id.values():
        for member_vid in rel.get("members", ()):
            ver = versions_by_id.get(member_vid)
            if ver and ver.get("dataset") == dataset_alias:
                release_version_ids.add(member_vid)
    if len(release_version_ids) == 1:
        chosen_id = next(iter(release_version_ids))
        return versions_by_id[chosen_id]

    raise CatalogError(
        "CATALOG-AMBIGUOUS",
        f"Multiple versions match dataset {dataset_alias!r}; supply explicit version_id",
        status="ambiguous",
    )


def serve_catalog_browse(directory, *, expected_lock_sha256, audience=None):
    """Browse datasets, disclosed definitions/columns, versions, representations and recipes."""
    from .catalog_delivery import load_catalog_artifacts
    from .catalog_query import disclosed_dataset_columns

    captured = load_catalog_artifacts(directory, expected_lock_sha256=expected_lock_sha256, audience=audience)
    catalog = captured.catalog
    datasets = []
    for ds in catalog.get("datasets", ()):
        if ds.get("disclosure") == "withheld":
            continue
        try:
            cols = disclosed_dataset_columns(catalog, ds)
        except CatalogError:
            cols = []
        datasets.append({
            "id": ds["id"],
            "alias": ds["alias"],
            "disclosedColumns": cols,
            **({"description": ds["description"]} if "description" in ds else {}),
        })
    versions = []
    for v in catalog.get("versions", ()):
        withheld = v.get("referenceDisclosure") == "withheld" or "reference" not in v
        versions.append({
            "id": v["id"],
            "dataset": v["dataset"],
            "retention": v.get("retention"),
            "withheld": withheld,
            **({} if withheld or catalog.get("audience") == "public" else {"referenceScheme": v.get("reference", {}).get("scheme")}),
        })
    representations = []
    for r in catalog.get("representations", ()):
        ver = next((v for v in catalog.get("versions", ()) if v["id"] == r["version"]), None)
        withheld = ver is None or ver.get("referenceDisclosure") == "withheld"
        loc = r.get("location")
        is_remote = isinstance(loc, str) and (loc.startswith("http://") or loc.startswith("https://"))
        entry = {
            "id": r["id"],
            "version": r["version"],
            "kind": r.get("kind"),
            "availability": r.get("availability"),
            "mediaType": r.get("mediaType"),
            "memberCount": len(r.get("members", ())) or (1 if loc else 0),
        }
        if not withheld and (catalog.get("audience") != "public" or is_remote):
            entry["location"] = loc
        representations.append(entry)
    return {
        "catalogId": catalog["id"],
        "audience": catalog["audience"],
        "catalogSha256": sha256(captured.artifacts["catalog.ddk.json"]).hexdigest(),
        "lockSha256": captured.lock_sha256,
        "datasets": datasets,
        "versions": versions,
        "representations": representations,
        "recipes": [{"id": rec["id"], "inputs": dict(rec.get("inputs", {})), "dialect": rec.get("dialect")}
                    for rec in catalog.get("recipes", ())],
    }


def _resolve_representation_sources(directory, captured, dataset_id, version_id, representation_id,
                                    *, permitted_roots=(), allow_insecure_http=False):
    from .catalog_metadata import FILE_SCHEME
    from .catalog_query import disclosed_dataset_columns, resolve_directory_members
    from .docspec_file_inputs import DIRECTORY_SCHEME

    catalog = captured.catalog
    dataset = resolve_catalog_dataset(catalog, dataset_id)
    disclosed_cols = disclosed_dataset_columns(catalog, dataset)

    version = resolve_active_dataset_version(catalog, dataset.get("alias"), version_id=version_id)
    if version.get("referenceDisclosure") == "withheld":
        raise CatalogError("CATALOG-VERSION-WITHHELD", "The exact version reference is withheld")
    if version.get("retention") != "present":
        raise CatalogError("CATALOG-UNAVAILABLE", "Selected version is not retained")

    cand_reps = [r for r in catalog.get("representations", ())
                 if r.get("version") == version["id"]
                 and (representation_id is None or r.get("id") == representation_id)]
    if len(cand_reps) > 1 and representation_id is None:
        parquet_reps = [
            r for r in cand_reps
            if r.get("availability") == "available" and r.get("mediaType") == "application/vnd.apache.parquet"
        ]
        if len(parquet_reps) == 1:
            cand_reps = parquet_reps
    if len(cand_reps) > 1:
        raise CatalogError("CATALOG-AMBIGUOUS", "Multiple representations match; supply explicit representation_id",
                           status="ambiguous")
    if not cand_reps:
        raise CatalogError("CATALOG-BINDING-MISMATCH", "No matching representation for version")
    rep = cand_reps[0]
    if rep.get("availability") != "available" or rep.get("mediaType") != "application/vnd.apache.parquet":
        raise CatalogError("CATALOG-UNAVAILABLE", "Selected representation is not an available Parquet dataset")

    ref = version.get("reference") or {}
    scheme = ref.get("scheme")
    ref_val = ref.get("value") if isinstance(ref.get("value"), dict) else {}
    location = rep.get("location") or ref_val.get("location")
    if not isinstance(location, str) or not location:
        raise CatalogError("CATALOG-REMOTE-INCOMPLETE", "Representation lacks a verifiable location", status="incomplete")

    iceberg_snap = rep.get("icebergSnapshot") or ref_val.get("icebergSnapshot")
    members = rep.get("members") or ()
    sources = []
    if location.startswith("http://") or location.startswith("https://"):
        base_parts = _validate_remote_parquet_url(location, allow_insecure_http=allow_insecure_http)
        base_origin = (
            base_parts.scheme.lower(),
            (base_parts.hostname or "").lower(),
            base_parts.port or (443 if base_parts.scheme == "https" else 80),
        )
        if members:
            base = location.rstrip("/")
            for m in members:
                raw_member_path = m.get("path")
                if not isinstance(raw_member_path, str) or not raw_member_path:
                    raise CatalogError("CATALOG-REMOTE-URL", "Remote representation member path must be a nonempty string")
                if raw_member_path.startswith(("http://", "https://")):
                    m_parts = _validate_remote_parquet_url(raw_member_path, allow_insecure_http=allow_insecure_http)
                    m_origin = (
                        m_parts.scheme.lower(),
                        (m_parts.hostname or "").lower(),
                        m_parts.port or (443 if m_parts.scheme == "https" else 80),
                    )
                    if m_origin != base_origin:
                        raise CatalogError(
                            "CATALOG-REMOTE-URL",
                            f"Remote representation member origin differs from catalog location: {raw_member_path!r}",
                        )
                    member_url = raw_member_path
                else:
                    if "?" in raw_member_path or "#" in raw_member_path or "\\" in raw_member_path:
                        raise CatalogError("CATALOG-REMOTE-URL", f"Unsafe remote member path: {raw_member_path!r}")
                    rel = PurePosixPath(raw_member_path)
                    if rel.is_absolute() or rel.as_posix() != raw_member_path or any(
                        part in {"", ".", ".."} for part in rel.parts
                    ):
                        raise CatalogError("CATALOG-REMOTE-URL", f"Unsafe remote member path: {raw_member_path!r}")
                    member_url = f"{base}/{raw_member_path}"
                    _validate_remote_parquet_url(member_url, allow_insecure_http=allow_insecure_http)
                sources.append({"kind": "remote", "url": member_url,
                                "byteSize": m.get("byteSize"), "sha256": m.get("sha256"),
                                "footerSha256": m.get("footerSha256"), "icebergSnapshot": iceberg_snap})
        else:
            sources.append({"kind": "remote", "url": location,
                            "byteSize": rep.get("byteSize") or ref_val.get("byteSize"),
                            "sha256": ref_val.get("sha256"),
                            "footerSha256": rep.get("footerSha256") or ref_val.get("footerSha256"),
                            "icebergSnapshot": iceberg_snap})
    else:
        roots = tuple(Path(r).resolve(strict=True) for r in (permitted_roots or (directory,)))
        parts = urlsplit(location)
        raw_path = unquote(parts.path) if parts.scheme == "file" else location
        local_path = Path(raw_path)
        if not local_path.is_absolute():
            local_path = Path(directory).resolve() / local_path
        resolved = local_path.resolve(strict=True)
        if not any(resolved.is_relative_to(r) for r in roots):
            raise CatalogError("CATALOG-LOCAL-QUERY", "Data input is outside permitted roots")
        if scheme == DIRECTORY_SCHEME or members:
            member_footer_by_rel = {
                m["path"]: m.get("footerSha256")
                for m in members if isinstance(m, dict) and isinstance(m.get("path"), str)
            }
            resolved_members = resolve_directory_members(resolved, members, max_members=max(128, len(members)))
            for m_path, m_size, m_sha in resolved_members:
                rel_key = m_path.relative_to(resolved).as_posix()
                sources.append({
                    "kind": "local", "path": m_path, "byteSize": m_size, "sha256": m_sha,
                    "footerSha256": member_footer_by_rel.get(rel_key), "icebergSnapshot": iceberg_snap,
                })
        elif scheme == FILE_SCHEME or resolved.is_file():
            sources.append({
                "kind": "local", "path": resolved,
                "byteSize": rep.get("byteSize"), "sha256": ref_val.get("sha256"),
                "footerSha256": rep.get("footerSha256") or ref_val.get("footerSha256"),
                "icebergSnapshot": iceberg_snap,
            })
        else:
            raise CatalogError("CATALOG-UNAVAILABLE", "Unsupported representation location scheme")

    return dataset, version, rep, disclosed_cols, sources


def _sort_arrow_table(tbl, norm_sort, pa):
    pa_major = int(pa.__version__.split(".", 1)[0])
    if pa_major >= 25:
        sort_keys = [
            *((s["column"], "ascending" if s["direction"] == "asc" else "descending", "at_end") for s in norm_sort),
            ("__ddk_shard__", "ascending", "at_end"),
            ("__ddk_row__", "ascending", "at_end"),
        ]
        return tbl.sort_by(sort_keys)
    sort_keys = [
        *((s["column"], "ascending" if s["direction"] == "asc" else "descending") for s in norm_sort),
        ("__ddk_shard__", "ascending"),
        ("__ddk_row__", "ascending"),
    ]
    return tbl.sort_by(sort_keys, null_placement="at_end")


def _read_parquet_representation(sources, *, requested_cols, norm_filters, norm_sort,
                                 effective_offset, limit, point_lookup,
                                 timeout, max_requests, max_bytes_fetched, allow_insecure_http):
    """Stream-bounded PyArrow Parquet reader with metadata RG offset-skip, O(limit) filter windowing, and top-K sort."""
    from .catalog_query import _verify_and_read_schema
    import pyarrow as pa
    import pyarrow.compute as pc
    import pyarrow.parquet as pq

    telemetry = {
        "rangeRequests": 0,
        "bytesFetched": 0,
        "fileBytes": 0,
        "rowGroupsTotal": 0,
        "rowGroupsScanned": 0,
        "rowGroupsPruned": 0,
        "shardsRead": 0,
    }
    shard_tables: list[pa.Table] = []
    matched_count = 0
    schema_cols: list[str] | None = None
    first_arrow_schema = None

    unfiltered_slice_mode = not norm_filters and not norm_sort and not point_lookup
    filtered_window_mode = bool(norm_filters) and not norm_sort and not point_lookup
    top_k = max(2 if point_lookup else 0, effective_offset + limit + 1)
    trim_threshold = max(top_k * 2, 4096)

    global_row = 0
    collected_window = 0
    more_exist = False
    early_exited = False
    single_shard_total_rows: int | None = None
    buffered_rows = 0

    for shard_idx, src in enumerate(sources):
        if src["kind"] == "remote":
            reader = _HttpRangeParquetFile(
                src["url"],
                expected_byte_size=src.get("byteSize"),
                timeout=timeout,
                max_requests=max(1, max_requests - telemetry["rangeRequests"]),
                max_bytes_fetched=max(1, max_bytes_fetched - telemetry["bytesFetched"]),
                allow_insecure_http=allow_insecure_http,
            )
            try:
                pf = pq.ParquetFile(reader)
                arrow_schema = pf.schema_arrow
                telemetry["fileBytes"] += reader.size
            except CatalogError:
                raise
            except Exception as exc:
                raise CatalogError("CATALOG-REMOTE-INCOMPLETE", f"Invalid remote Parquet metadata: {exc}",
                                   status="incomplete") from exc
        else:
            local_path = src["path"]
            if src.get("byteSize") is not None and (src.get("sha256") or src.get("footerSha256") or src.get("icebergSnapshot")):
                arrow_schema = _verify_and_read_schema(
                    local_path, src["byteSize"], src.get("sha256"), pq,
                    footer_sha256=src.get("footerSha256"),
                    iceberg_snapshot=src.get("icebergSnapshot"),
                )
            pf = pq.ParquetFile(local_path)
            arrow_schema = pf.schema_arrow
            telemetry["fileBytes"] += local_path.stat().st_size
            reader = None

        if first_arrow_schema is None:
            first_arrow_schema = arrow_schema
        telemetry["shardsRead"] += 1
        all_names = [arrow_schema.field(i).name for i in range(len(arrow_schema))]
        all_names_set = set(all_names)
        proj_cols = list(requested_cols) if requested_cols is not None else all_names
        missing_proj = [c for c in proj_cols if c not in all_names_set]
        if missing_proj:
            raise CatalogError("CATALOG-UNKNOWN-COLUMN", f"Projected column(s) missing: {', '.join(missing_proj)}")
        for s in norm_sort:
            if s["column"] not in all_names_set:
                raise CatalogError("CATALOG-UNKNOWN-COLUMN", f"Sort column {s['column']!r} is absent from Parquet schema")
        if schema_cols is None:
            schema_cols = proj_cols

        filter_expr = _build_arrow_filter_expression(arrow_schema, norm_filters, pa, pc)
        needed_cols = list(dict.fromkeys([
            *proj_cols,
            *(f["column"] for f in norm_filters),
            *(s["column"] for s in norm_sort),
        ]))

        num_rgs = pf.metadata.num_row_groups
        telemetry["rowGroupsTotal"] += num_rgs
        if len(sources) == 1:
            single_shard_total_rows = pf.metadata.num_rows

        matching_rgs: list[int] = []
        for rg_idx in range(num_rgs):
            rg_meta = pf.metadata.row_group(rg_idx)
            if not _row_group_might_match(rg_meta, arrow_schema, norm_filters):
                telemetry["rowGroupsPruned"] += 1
            else:
                matching_rgs.append(rg_idx)

        row_base = 0
        if unfiltered_slice_mode:
            needed_end = effective_offset + limit + 1
            for rg_idx in matching_rgs:
                rg_rows = pf.metadata.row_group(rg_idx).num_rows
                if global_row + rg_rows <= effective_offset:
                    telemetry["rowGroupsPruned"] += 1
                    global_row += rg_rows
                    continue
                if global_row >= needed_end:
                    early_exited = True
                    break
                telemetry["rowGroupsScanned"] += 1
                tbl = pf.read_row_group(rg_idx, columns=proj_cols)
                local_start = max(0, effective_offset - global_row)
                local_end = min(tbl.num_rows, needed_end - global_row)
                if local_end > local_start:
                    sliced = tbl.slice(local_start, local_end - local_start)
                    take = min(sliced.num_rows, max(0, limit - collected_window))
                    if take > 0:
                        shard_tables.append(sliced.slice(0, take))
                    collected_window += sliced.num_rows
                    matched_count += sliced.num_rows
                global_row += rg_rows
                if collected_window >= limit + 1:
                    more_exist = True
                    early_exited = True
                    break
        elif matching_rgs:
            if point_lookup and not norm_sort:
                for rg_idx in matching_rgs:
                    telemetry["rowGroupsScanned"] += 1
                    tbl = pf.read_row_group(rg_idx, columns=needed_cols)
                    if filter_expr is not None and tbl.num_rows > 0:
                        tbl = tbl.filter(filter_expr)
                    if tbl.num_rows > 0:
                        shard_tables.append(tbl.select(proj_cols))
                        matched_count += tbl.num_rows
                        if matched_count >= 2:
                            early_exited = True
                            break
            elif filtered_window_mode:
                needed_end = effective_offset + limit + 1
                for rg_idx in matching_rgs:
                    telemetry["rowGroupsScanned"] += 1
                    tbl = pf.read_row_group(rg_idx, columns=needed_cols)
                    if filter_expr is not None and tbl.num_rows > 0:
                        tbl = tbl.filter(filter_expr)
                    rg_matches = tbl.num_rows
                    if rg_matches > 0:
                        win_start = max(0, effective_offset - matched_count)
                        win_end = min(rg_matches, needed_end - matched_count)
                        if win_end > win_start:
                            sliced = tbl.select(proj_cols).slice(win_start, win_end - win_start)
                            take = min(sliced.num_rows, max(0, limit - collected_window))
                            if take > 0:
                                shard_tables.append(sliced.slice(0, take))
                            collected_window += sliced.num_rows
                        matched_count += rg_matches
                        if matched_count >= needed_end:
                            more_exist = True
                            early_exited = True
                            break
            else:
                for rg_idx in matching_rgs:
                    telemetry["rowGroupsScanned"] += 1
                    rg_rows = pf.metadata.row_group(rg_idx).num_rows
                    tbl = pf.read_row_group(rg_idx, columns=needed_cols)
                    if tbl.num_rows > 0:
                        if norm_sort:
                            tbl = tbl.append_column("__ddk_shard__", pa.repeat(pa.scalar(shard_idx, pa.int32()), tbl.num_rows))
                            tbl = tbl.append_column("__ddk_row__", pa.arange(row_base, row_base + tbl.num_rows))
                        if filter_expr is not None:
                            tbl = tbl.filter(filter_expr)
                        if tbl.num_rows > 0:
                            shard_tables.append(tbl)
                            matched_count += tbl.num_rows
                            buffered_rows += tbl.num_rows
                            if norm_sort and buffered_rows > trim_threshold:
                                trimmed = _sort_arrow_table(
                                    shard_tables[0] if len(shard_tables) == 1 else pa.concat_tables(shard_tables),
                                    norm_sort,
                                    pa,
                                ).slice(0, top_k)
                                shard_tables = [trimmed]
                                buffered_rows = trimmed.num_rows
                    row_base += rg_rows

        if reader is not None:
            telemetry["rangeRequests"] += reader.range_requests
            telemetry["bytesFetched"] += reader.bytes_fetched
        if early_exited:
            break

    proj_cols = schema_cols or (requested_cols or [])
    if point_lookup and matched_count > 1:
        return "ambiguous", [], proj_cols, matched_count, telemetry

    if not shard_tables or matched_count == 0:
        if unfiltered_slice_mode and single_shard_total_rows is not None:
            return "ok", [], proj_cols, single_shard_total_rows, telemetry
        return "ok", [], proj_cols, 0, telemetry

    combined = shard_tables[0] if len(shard_tables) == 1 else pa.concat_tables(shard_tables)
    if norm_sort:
        combined = _sort_arrow_table(combined, norm_sort, pa)
        total_matched = matched_count
        page_table = combined.select(proj_cols).slice(effective_offset, limit)
    elif unfiltered_slice_mode:
        page_table = combined.select(proj_cols).slice(0, limit)
        if single_shard_total_rows is not None:
            total_matched = single_shard_total_rows
        elif early_exited or more_exist:
            total_matched = effective_offset + page_table.num_rows + 1
        else:
            total_matched = global_row
    elif filtered_window_mode:
        page_table = combined.select(proj_cols).slice(0, limit)
        total_matched = matched_count
    else:
        total_matched = combined.num_rows
        page_table = combined.select(proj_cols).slice(effective_offset, limit)

    page_rows = _normalize_arrow_table_rows(page_table, first_arrow_schema) if page_table.num_rows > 0 else []
    return "ok", page_rows, proj_cols, total_matched, telemetry


def serve_catalog_read(directory, *, expected_lock_sha256, dataset_id=None, dataset=None,
                       version_id=None, representation_id=None,
                       columns=None, filters=None, sort=None, limit=25, offset=0, cursor=None,
                       point_lookup=False, cursor_secret=None, audience=None, permitted_roots=(),
                       max_requests=64, max_bytes_fetched=16 << 20, timeout=15.0,
                       allow_insecure_http=False):
    """Bounded shared read / compound-key remote lookup / typed filtering / deterministic paging."""
    from .catalog_delivery import load_catalog_artifacts

    target_dataset_ref = dataset_id if dataset_id is not None else dataset
    if target_dataset_ref is None:
        raise CatalogError("CATALOG-BINDING-MISMATCH", "Supply dataset_id or dataset alias")

    if type(limit) is not int or not 1 <= limit <= 100:
        raise CatalogError("CATALOG-INVALID-LIMIT", "Read limit must be an integer between 1 and 100")
    if type(offset) is not int or offset < 0:
        raise CatalogError("CATALOG-INVALID-OFFSET", "Read offset must be a non-negative integer")

    captured = load_catalog_artifacts(directory, expected_lock_sha256=expected_lock_sha256, audience=audience)
    catalog_sha = sha256(captured.artifacts["catalog.ddk.json"]).hexdigest()
    dataset_rec, version, rep, disclosed_cols, sources = _resolve_representation_sources(
        directory, captured, target_dataset_ref, version_id, representation_id,
        permitted_roots=permitted_roots, allow_insecure_http=allow_insecure_http,
    )

    if columns is not None:
        if not isinstance(columns, (list, tuple)) or not columns or any(not isinstance(c, str) or not c for c in columns):
            raise CatalogError("CATALOG-INVALID-COLUMNS", "columns must be a non-empty list of column names")
        if disclosed_cols is not None and any(c not in set(disclosed_cols) for c in columns):
            raise CatalogError("CATALOG-DISCLOSURE-WITHHELD", "Requested projection includes undisclosed columns")
        requested_cols = list(dict.fromkeys(columns))
    else:
        requested_cols = list(disclosed_cols) if disclosed_cols is not None else None

    norm_filters = _normalize_filter_specs(filters, disclosed_cols)
    norm_sort = _normalize_sort_specs(sort, disclosed_cols)

    scope = {
        "catalogSha256": catalog_sha,
        "datasetId": dataset_rec["id"],
        "versionId": version["id"],
        "representationId": rep["id"],
        "columns": requested_cols,
        "filters": norm_filters,
        "sort": norm_sort,
    }
    effective_offset = offset
    if cursor is not None:
        cursor_payload = verify_continuation_cursor(cursor, scope, secret=cursor_secret)
        effective_offset = cursor_payload["offset"]

    try:
        read_status, page_rows, proj_cols, total_matched, telemetry = _read_parquet_representation(
            sources,
            requested_cols=requested_cols,
            norm_filters=norm_filters,
            norm_sort=norm_sort,
            effective_offset=effective_offset,
            limit=limit,
            point_lookup=point_lookup,
            timeout=timeout,
            max_requests=max_requests,
            max_bytes_fetched=max_bytes_fetched,
            allow_insecure_http=allow_insecure_http,
        )
    except CatalogError as exc:
        if exc.status in {"incomplete", "interrupted"}:
            return {
                "status": exc.status,
                "outcome": exc.status,
                "reason": str(exc),
                "rows": [],
                "exactRows": [],
                "columns": requested_cols or [],
                "returned": 0,
                "hasMore": False,
                "nextCursor": None,
                "telemetry": {
                    "rangeRequests": 0, "bytesFetched": 0, "fileBytes": 0,
                    "rowGroupsTotal": 0, "rowGroupsScanned": 0, "rowGroupsPruned": 0, "shardsRead": 0,
                },
                "consumed": {"datasetId": dataset_rec["id"], "versionId": version["id"], "representationId": rep["id"]},
            }
        raise

    if read_status == "ambiguous":
        return {
            "status": "ambiguous",
            "outcome": "ambiguous",
            "reason": "Compound-key point lookup matched more than one row",
            "rows": [],
            "exactRows": [],
            "columns": proj_cols,
            "returned": 0,
            "hasMore": False,
            "nextCursor": None,
            "telemetry": telemetry,
            "consumed": {"datasetId": dataset_rec["id"], "versionId": version["id"], "representationId": rep["id"]},
        }

    has_more = (effective_offset + len(page_rows)) < total_matched
    next_cursor = (
        bind_continuation_cursor(
            scope,
            offset=effective_offset + len(page_rows),
            secret=cursor_secret,
        )
        if has_more
        else None
    )
    if not page_rows:
        outcome = "exhausted_empty"
    elif has_more:
        outcome = "more"
    else:
        outcome = "complete"
    return {
        "status": "ok",
        "outcome": outcome,
        "rows": page_rows,
        "exactRows": [_encode_exact_json_value(r) for r in page_rows],
        "columns": proj_cols,
        "returned": len(page_rows),
        "total": total_matched,
        "hasMore": has_more,
        "nextCursor": next_cursor,
        "telemetry": telemetry,
        "consumed": {"datasetId": dataset_rec["id"], "versionId": version["id"], "representationId": rep["id"]},
    }


def follow_catalog_relationship(directory, *, expected_lock_sha256, relationship_id, source_row,
                                target_version_id=None, target_representation_id=None,
                                columns=None, limit=25, audience=None, permitted_roots=(),
                                allow_insecure_http=False):
    """Follow a declared catalog relationship from ``source_row``, honoring ``when`` discriminators."""
    from .catalog_delivery import load_catalog_artifacts

    captured = load_catalog_artifacts(directory, expected_lock_sha256=expected_lock_sha256, audience=audience)
    catalog = captured.catalog
    relationship = _record(catalog.get("relationships", ()), relationship_id, "relationship")
    source = relationship["source"]
    target = relationship["target"]
    if "external" in target or "catalog" in target:
        raise CatalogError("CATALOG-BINDING-UNRESOLVED",
                           "Following external or cross-catalog relationships requires peer catalog resolution",
                           status="unknown")
    if not endpoint_matches_row(source, source_row):
        return {
            "status": "ok",
            "outcome": "exhausted_empty",
            "relationshipId": relationship_id,
            "rows": [],
            "exactRows": [],
            "columns": list(columns) if columns else [],
            "returned": 0,
            "total": 0,
            "hasMore": False,
            "nextCursor": None,
        }
    src_paths = source.get("paths") or ()
    tgt_paths = target.get("paths") or ()
    if not src_paths or len(src_paths) != len(tgt_paths):
        raise CatalogError("CATALOG-KEY-INCOMPLETE", "Relationship endpoints must declare matching key paths")
    nulls = relationship.get("nulls", "skip")
    filters = []
    for sp, tp in zip(src_paths, tgt_paths):
        if len(sp) != 1 or "field" not in sp[0] or len(tp) != 1 or "field" not in tp[0]:
            raise CatalogError("CATALOG-KEY-PATH", "Relationship lookup requires top-level scalar field paths")
        s_val = source_row.get(sp[0]["field"])
        if s_val is None:
            if nulls == "reject":
                raise CatalogError("CATALOG-KEY-NULL", "A rejected null occurred in the source relationship key")
            if nulls == "skip":
                return {
                    "status": "ok",
                    "outcome": "exhausted_empty",
                    "relationshipId": relationship_id,
                    "rows": [],
                    "exactRows": [],
                    "columns": list(columns) if columns else [],
                    "returned": 0,
                    "total": 0,
                    "hasMore": False,
                    "nextCursor": None,
                }
        filters.append({"column": tp[0]["field"], "op": "eq", "value": s_val})
    tgt_when = target.get("when")
    if tgt_when:
        filters.append({"column": tgt_when["field"], "op": "eq", "value": tgt_when["equals"]})
    res = serve_catalog_read(
        directory,
        expected_lock_sha256=expected_lock_sha256,
        dataset=target["dataset"],
        version_id=target_version_id,
        representation_id=target_representation_id,
        columns=columns,
        filters=filters,
        limit=limit,
        audience=audience,
        permitted_roots=permitted_roots,
        allow_insecure_http=allow_insecure_http,
    )
    return {**res, "relationshipId": relationship_id}


def _resolve_bindings_or_aliases(catalog, raw_bindings):
    """Allow binding values to be either exact version IDs or human-friendly dataset aliases/IDs."""
    if not raw_bindings:
        return raw_bindings
    version_ids = {v["id"] for v in catalog.get("versions", ()) if isinstance(v, dict) and "id" in v}
    resolved = {}
    for name, ref in raw_bindings.items():
        if ref in version_ids:
            resolved[name] = ref
        else:
            try:
                ds = resolve_catalog_dataset(catalog, ref)
                ver = resolve_active_dataset_version(catalog, ds["alias"])
                resolved[name] = ver["id"]
            except CatalogError:
                # Preserve exact original ref so downstream validation reports canonical error code
                resolved[name] = ref
    return resolved


def serve_catalog_query(directory, *, expected_lock_sha256, adapter, scratch, permitted_roots,
                        sql=None, recipe_id=None, bindings=None, parameters=None,
                        columns_by_binding=None, limit=100, audience=None,
                        admitted_version=False, explain=False, max_input_bytes=4 << 30,
                        max_members=128):
    """Unified shared query handler for both prepared recipes and bounded read-only SELECT/WITH SQL."""
    from .catalog_delivery import load_catalog_artifacts
    from .catalog_query import execute_catalog_sql

    captured = load_catalog_artifacts(directory, expected_lock_sha256=expected_lock_sha256, audience=audience)
    catalog = captured.catalog
    if bindings is not None and isinstance(bindings, dict):
        bindings = _resolve_bindings_or_aliases(catalog, bindings)
    if recipe_id is not None:
        # Support matching recipe by exact ID or unique short suffix/name
        recipes = catalog.get("recipes", ()) or ()
        if not any(r.get("id") == recipe_id for r in recipes):
            suffix_matches = [
                r for r in recipes
                if isinstance(r.get("id"), str) and (
                    r["id"].endswith(f":{recipe_id}") or r["id"].endswith(f"/{recipe_id}")
                )
            ]
            if len(suffix_matches) == 1:
                recipe_id = suffix_matches[0]["id"]
        recipe = _record(recipes, recipe_id, "query recipe")
        effective_versions = bindings
        if effective_versions is None:
            effective_versions = {}
            for input_name, input_ref in (recipe.get("inputs") or {}).items():
                if isinstance(input_ref, str):
                    ver = resolve_active_dataset_version(catalog, input_ref)
                    effective_versions[input_name] = ver["id"]
        resolved = resolve_query(catalog, recipe_id, parameters=parameters or {},
                                 versions=(effective_versions or None))
        sql_path_rel = recipe["sql"]
        sql_bytes = captured.companions.get(sql_path_rel)
        if sql_bytes is None:
            comp_path = resolve_path(Path(directory).resolve() / "catalog.ddk.json", sql_path_rel, (Path(directory).resolve(),))
            sql_bytes = comp_path.read_bytes()
        recipe_sql = sql_bytes.decode("utf-8")
        # Pass recipe SQL + parameter values using execute_catalog_sql or DocSpec owner-worker run_query
        version_bindings = {name: info["id"] for name, info in resolved["inputs"].items()}
        if parameters:
            # Delegate parameterized recipe to DocSpec owner-worker run_query cleanly
            from .catalog_query import _get_owner_worker
            worker = _get_owner_worker(
                adapter.executable, directory, expected_lock_sha256,
                adapter.limits, [Path(r).resolve(strict=True) for r in permitted_roots],
                getattr(adapter, "timeout", 30), Path(scratch).resolve(),
            )
            worker_inputs = {name: {"versionId": vid, **({"admittedVersion": True} if admitted_version else {})}
                             for name, vid in version_bindings.items()}
            resp = worker.call("run_query", {
                "recipeId": recipe_id,
                "expectedSqlSha256": sha256(sql_bytes).hexdigest(),
                "versions": version_bindings,
                "inputs": worker_inputs,
                "parameters": dict(parameters),
                "limit": limit,
                "wrapLimit": False,
                **({"admittedVersion": True} if admitted_version else {}),
            })
            if not resp.get("ok"):
                err = resp.get("error") or {}
                return {"status": "refused", "reason": err.get("message", "Recipe execution refused"), "error": err}
            res = resp["result"]
            from .catalog_query import decode_exact_row
            exact_rows = res.get("rows", [])
            decoded = [decode_exact_row(r) for r in exact_rows]
            return {
                "status": "succeeded",
                "recipeId": recipe_id,
                "rows": decoded,
                "exactRows": exact_rows,
                "columns": list(decoded[0].keys()) if decoded else [],
                "sqlSha256": res.get("sqlSha256"),
                "receipt": res.get("record") or {"status": "succeeded"},
            }
        sql = recipe_sql
        bindings = version_bindings

    if not sql or not bindings:
        raise CatalogError("CATALOG-LOCAL-QUERY", "Supply either recipe_id or sql with explicit version bindings")
    return execute_catalog_sql(
        directory,
        expected_lock_sha256=expected_lock_sha256,
        bindings=bindings,
        sql=sql,
        adapter=adapter,
        scratch=scratch,
        permitted_roots=permitted_roots,
        max_rows=limit,
        max_input_bytes=max_input_bytes,
        max_members=max_members,
        audience=audience,
        columns_by_binding=columns_by_binding,
        admitted_version=admitted_version,
        explain=explain,
    )

