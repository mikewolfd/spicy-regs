"""IRS Form 990 filing-index, downloads-page, and streaming XML readers, without financial interpretation."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import struct
import sys
import zlib
from array import array
from collections import Counter
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import date
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from typing import Any, NamedTuple
from urllib.parse import urljoin
from zipfile import ZIP_BZIP2, ZIP_DEFLATED, ZIP_LZMA, ZIP_STORED, BadZipFile, ZipFile, ZipInfo

import inflate64

from spicy_docs.reading.xml import parse_xml, scan_xml

BASE_URL = "https://apps.irs.gov/pub/epostcard/990/xml/"
DOWNLOADS_PAGE_URL = "https://www.irs.gov/charities-non-profits/form-990-series-downloads"
NAMESPACE = "http://www.irs.gov/efile"
_NS_PREFIX = f"{{{NAMESPACE}}}"
MAX_INDEX_BYTES = 512 * 1024**2
MAX_ARCHIVE_BYTES = 5 * 1024**3
MAX_RETURN_BYTES = 32 * 1024**2
MAX_DOWNLOADS_PAGE_BYTES = 8 * 1024**2
MAX_INDEX_ROWS = 5_000_000
MAX_ARCHIVE_MEMBERS = 1_000_000
MAX_SELECTED = 100
REQUIRED_COLUMNS = frozenset(
    {
        "RETURN_ID",
        "FILING_TYPE",
        "EIN",
        "TAX_PERIOD",
        "SUB_DATE",
        "TAXPAYER_NAME",
        "RETURN_TYPE",
        "DLN",
        "OBJECT_ID",
    }
)
FORM_NODES: dict[str, str] = {
    "990": "IRS990",
    "990EZ": "IRS990EZ",
    "990PF": "IRS990PF",
    "990T": "IRS990T",
}
_FORM_TAGS: dict[str, str] = {f"{_NS_PREFIX}{tag}": tag for tag in FORM_NODES.values()}

_URL_RE = re.compile(
    re.escape(BASE_URL)
    + r"(?P<dir_year>20\d{2})/(?P<filename>"
    + r"index_(?P<index_year>20\d{2})\.csv"
    + r"|(?P<teos_year>20\d{2})_TEOS_XML_(?:\d{2}[A-Z]|CT\d+)\.zip"
    + r"|download990xml_(?P<dl_year>20\d{2})_\d+\.zip"
    + r")",
    re.ASCII,
)
_OID_RE = re.compile(r"\d{18}", re.ASCII)
_EIN_RE = re.compile(r"\d{9}", re.ASCII)
_TAX_PERIOD_RE = re.compile(r"\d{6}", re.ASCII)
_ISO_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}", re.ASCII)

_HEADER_SCALAR_TAGS: dict[str, str] = {
    f"{_NS_PREFIX}ReturnTypeCd": "ReturnTypeCd",
    f"{_NS_PREFIX}TaxPeriodEndDt": "TaxPeriodEndDt",
    f"{_NS_PREFIX}TaxPeriodBeginDt": "TaxPeriodBeginDt",
    f"{_NS_PREFIX}TaxYr": "TaxYr",
}
_FORM990_SCALAR_TAGS: dict[str, str] = {
    f"{_NS_PREFIX}AmendedReturnInd": "AmendedReturnInd",
    f"{_NS_PREFIX}CYTotalRevenueAmt": "CYTotalRevenueAmt",
    f"{_NS_PREFIX}CYTotalExpensesAmt": "CYTotalExpensesAmt",
    f"{_NS_PREFIX}CYGrantsAndSimilarPaidAmt": "CYGrantsAndSimilarPaidAmt",
}
_FORM990_NESTED_SCALARS: dict[str, tuple[str, str, str]] = {
    f"{_NS_PREFIX}TotalRevenueGrp": (
        "TotalRevenueGrp",
        f"{_NS_PREFIX}TotalRevenueColumnAmt",
        "TotalRevenueGrp/TotalRevenueColumnAmt",
    ),
    f"{_NS_PREFIX}TotalFunctionalExpensesGrp": (
        "TotalFunctionalExpensesGrp",
        f"{_NS_PREFIX}TotalAmt",
        "TotalFunctionalExpensesGrp/TotalAmt",
    ),
}


class IRS990Error(ValueError):
    """The selected IRS original cannot establish the requested filing identity."""


class IRS990DownloadLink(NamedTuple):
    """One verified official TEOS annual index or bulk XML archive link."""

    year: int
    kind: str
    url: str


@dataclass(frozen=True, slots=True)
class IRS990ParsedReturn:
    """One streamed and identity-verified XML return from an official TEOS archive."""

    record: dict[str, Any]
    member_name: str
    object_id: str
    return_type: str
    return_version: str


@dataclass(frozen=True, slots=True)
class IRS990Anomaly:
    """One bounded per-member anomaly encountered while streaming a TEOS archive."""

    member_name: str
    object_id: str | None
    reason: str
    detail: str
    archive_sha256: str
    return_type: str | None = None
    member_sha256: str | None = None


@dataclass(frozen=True, slots=True)
class IRS990SkippedMember:
    """One ZIP member explicitly skipped without XML parsing (excluded type or directory)."""

    member_name: str
    object_id: str | None
    return_type: str | None
    reason: str


@dataclass
class ArchiveDisposition:
    """Complete per-archive accounting so 100% of ZIP entries have an explicit disposition."""

    archive_sha256: str
    total_entries: int = 0
    parsed_returns: int = 0
    skipped_excluded_return_type: int = 0
    skipped_directories: int = 0
    anomalies: int = 0
    parsed_by_return_type: Counter[str] = field(default_factory=Counter)
    parsed_by_version: Counter[str] = field(default_factory=Counter)
    document_cnt_status_counts: Counter[str] = field(default_factory=Counter)
    excluded_by_return_type: Counter[str] = field(default_factory=Counter)
    anomalies_by_reason: Counter[str] = field(default_factory=Counter)

    @property
    def accounted_entries(self) -> int:
        return self.parsed_returns + self.skipped_excluded_return_type + self.skipped_directories + self.anomalies

    def to_dict(self) -> dict[str, Any]:
        return {
            "archive_sha256": self.archive_sha256,
            "total_entries": self.total_entries,
            "accounted_entries": self.accounted_entries,
            "parsed_returns": self.parsed_returns,
            "skipped_excluded_return_type": self.skipped_excluded_return_type,
            "skipped_directories": self.skipped_directories,
            "anomalies": self.anomalies,
            "parsed_by_return_type": dict(sorted(self.parsed_by_return_type.items())),
            "parsed_by_version": dict(sorted(self.parsed_by_version.items())),
            "document_cnt_status_counts": dict(sorted(self.document_cnt_status_counts.items())),
            "excluded_by_return_type": dict(sorted(self.excluded_by_return_type.items())),
            "anomalies_by_reason": dict(sorted(self.anomalies_by_reason.items())),
        }


def validate_url(url: str) -> str:
    """Validate an official apps.irs.gov TEOS annual index CSV or XML archive ZIP URL."""
    if not isinstance(url, str):
        raise IRS990Error("IRS URL must select an official annual index or XML archive")
    match = _URL_RE.fullmatch(url)
    if match is None:
        raise IRS990Error("IRS URL must select an official annual index or XML archive")
    dir_year = match.group("dir_year")
    file_year = match.group("index_year") or match.group("teos_year") or match.group("dl_year")
    if dir_year != file_year:
        raise IRS990Error("IRS URL year differs from its file")
    return url


class _DownloadsLinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.hrefs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        for name, value in attrs:
            if name.lower() == "href" and value:
                self.hrefs.append(value.strip())
                break


def parse_downloads_page(html_bytes: bytes) -> list[IRS990DownloadLink]:
    """Extract verified official (year, kind, url) descriptors from the IRS Form 990 downloads page."""
    if not isinstance(html_bytes, bytes) or not 0 < len(html_bytes) <= MAX_DOWNLOADS_PAGE_BYTES:
        raise IRS990Error("IRS downloads page must be nonempty bytes within its size bound")
    try:
        html_text = html_bytes.decode("utf-8")
    except UnicodeDecodeError as error:
        raise IRS990Error("IRS downloads page is not valid UTF-8") from error
    parser = _DownloadsLinkParser()
    parser.feed(html_text)
    parser.close()
    seen: set[str] = set()
    links: list[IRS990DownloadLink] = []
    for href in parser.hrefs:
        candidate = urljoin(DOWNLOADS_PAGE_URL, href)
        match = _URL_RE.fullmatch(candidate)
        if match is None:
            continue
        dir_year = match.group("dir_year")
        file_year = match.group("index_year") or match.group("teos_year") or match.group("dl_year")
        if dir_year != file_year or candidate in seen:
            continue
        seen.add(candidate)
        kind = "index" if candidate.endswith(".csv") else "archive"
        links.append(IRS990DownloadLink(year=int(dir_year), kind=kind, url=candidate))
    if not links:
        raise IRS990Error("IRS downloads page lists no official Form 990 index or XML archive URLs")
    return links


def acquire_original(acquirer, url, *, store, expected_size, etag):
    """Capture one caller-selected official original through the shared downloader."""
    validate_url(url)
    bound = MAX_INDEX_BYTES if url.endswith(".csv") else MAX_ARCHIVE_BYTES
    if type(expected_size) is not int or not 0 < expected_size <= bound or not etag:
        raise IRS990Error("IRS acquisition requires a bounded size and selected ETag")
    return acquirer.download(url, store=store, max_bytes=bound, expected_size=expected_size, etag=etag)


def _validate_submission_year(submission_year: int) -> int:
    if type(submission_year) is not int or not 2011 <= submission_year <= 2099:
        raise IRS990Error("IRS index requires its explicit submission year")
    return submission_year


def _object_ids(values):
    values = tuple(values)
    if (
        not 0 < len(values) <= MAX_SELECTED
        or len(set(values)) != len(values)
        or any(not isinstance(value, str) or _OID_RE.fullmatch(value) is None for value in values)
    ):
        raise IRS990Error("Select unique IRS object IDs within the filing bound")
    return values


class _BoundedIndex(io.RawIOBase):
    def __init__(self, stream):
        self.stream, self.size = stream, 0

    def readable(self):
        return True

    def readinto(self, buffer):
        chunk = self.stream.read(min(len(buffer), MAX_INDEX_BYTES - self.size + 1))
        self.size += len(chunk)
        if self.size > MAX_INDEX_BYTES:
            raise IRS990Error("IRS index exceeds its byte bound")
        buffer[: len(chunk)] = chunk
        return len(chunk)


def _open_index_reader(stream) -> tuple[tuple[str, ...], Any]:
    text = io.TextIOWrapper(io.BufferedReader(_BoundedIndex(stream)), encoding="utf-8-sig", newline="")
    reader = csv.reader(text, strict=True)
    try:
        header = next(reader, None)
    except (UnicodeError, csv.Error) as error:
        raise IRS990Error("IRS filing index is malformed") from error
    if not header or len(set(header)) != len(header) or not REQUIRED_COLUMNS <= set(header):
        raise IRS990Error("IRS filing-index header changed")
    return tuple(header), reader


def iter_index_rows(stream, *, submission_year: int) -> Iterator[dict[str, Any]]:
    """Stream every row of a retained IRS annual filing index, validating header and identity columns."""
    _validate_submission_year(submission_year)
    fieldnames, reader = _open_index_reader(stream)
    return _iter_validated_index_rows(reader, fieldnames=fieldnames, submission_year=submission_year)


def _iter_validated_index_rows(
    reader: Any,
    *,
    fieldnames: tuple[str, ...],
    submission_year: int,
) -> Iterator[dict[str, Any]]:
    col_count = len(fieldnames)
    oid_idx = fieldnames.index("OBJECT_ID")
    ein_idx = fieldnames.index("EIN")
    period_idx = fieldnames.index("TAX_PERIOD")
    ordinal = 0
    try:
        for raw_row in reader:
            if not raw_row:
                continue
            ordinal += 1
            if ordinal > MAX_INDEX_ROWS or len(raw_row) != col_count:
                raise IRS990Error("IRS filing-index row shape or population bound differs")
            oid = raw_row[oid_idx]
            if (
                _OID_RE.fullmatch(oid) is None
                or _EIN_RE.fullmatch(raw_row[ein_idx]) is None
                or _TAX_PERIOD_RE.fullmatch(raw_row[period_idx]) is None
            ):
                raise IRS990Error("IRS index object ID, EIN or tax period is malformed")
            yield {
                "object_id": oid,
                "submission_year": submission_year,
                "index_row": ordinal,
                "native_index": dict(zip(fieldnames, raw_row, strict=True)),
            }
    except (UnicodeError, csv.Error) as error:
        raise IRS990Error("IRS filing index is malformed") from error


def _pack_index_row(raw_row: list[str]) -> bytes:
    if any("\x00" in value for value in raw_row):
        return b"\x01" + json.dumps(raw_row, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return b"\x00" + "\x00".join(raw_row).encode("utf-8")


def _unpack_index_row(packed: bytes | bytearray) -> list[str]:
    if packed[:1] == b"\x01":
        return json.loads(bytes(packed[1:]).decode("utf-8"))
    return bytes(packed[1:]).decode("utf-8").split("\x00")


class IRS990IndexMap(Mapping[str, dict[str, Any]]):
    """Compact in-memory lookup of an annual IRS filing index keyed by OBJECT_ID."""

    __slots__ = (
        "_buffer",
        "_index_rows",
        "_offsets",
        "_oid_to_slot",
        "_return_types",
        "duplicate_identical_rows",
        "fieldnames",
        "submission_year",
        "total_rows",
    )

    def __init__(
        self,
        *,
        submission_year: int,
        fieldnames: tuple[str, ...],
        oid_to_slot: dict[str, int],
        index_rows: array,
        return_types: list[str],
        offsets: array,
        buffer: bytes | bytearray,
        total_rows: int,
        duplicate_identical_rows: int = 0,
    ) -> None:
        self.submission_year = submission_year
        self.fieldnames = fieldnames
        self.total_rows = total_rows
        self.duplicate_identical_rows = duplicate_identical_rows
        self._oid_to_slot = oid_to_slot
        self._index_rows = index_rows
        self._return_types = return_types
        self._offsets = offsets
        self._buffer = buffer

    def __len__(self) -> int:
        return len(self._oid_to_slot)

    def __iter__(self) -> Iterator[str]:
        return iter(self._oid_to_slot)

    def __contains__(self, key: object) -> bool:
        return key in self._oid_to_slot

    def __getitem__(self, oid: str) -> dict[str, Any]:
        slot = self._oid_to_slot[oid]
        values = _unpack_index_row(self._buffer[self._offsets[slot] : self._offsets[slot + 1]])
        return {
            "object_id": oid,
            "submission_year": self.submission_year,
            "index_row": self._index_rows[slot],
            "native_index": dict(zip(self.fieldnames, values, strict=True)),
        }

    def return_type(self, oid: str) -> str | None:
        slot = self._oid_to_slot.get(oid)
        return self._return_types[slot] if slot is not None else None


def load_index_map(
    stream,
    *,
    submission_year: int,
    allow_duplicate_identical: bool = True,
) -> IRS990IndexMap:
    """Load an entire IRS annual filing index into a compact OBJECT_ID lookup map."""
    _validate_submission_year(submission_year)
    fieldnames, reader = _open_index_reader(stream)
    col_count = len(fieldnames)
    oid_idx = fieldnames.index("OBJECT_ID")
    ein_idx = fieldnames.index("EIN")
    period_idx = fieldnames.index("TAX_PERIOD")
    rtype_idx = fieldnames.index("RETURN_TYPE")

    oid_to_slot: dict[str, int] = {}
    index_rows = array("I")
    return_types: list[str] = []
    offsets = array("Q", [0])
    buf = bytearray()
    ordinal = 0
    duplicate_identical = 0
    try:
        for raw_row in reader:
            if not raw_row:
                continue
            ordinal += 1
            if ordinal > MAX_INDEX_ROWS or len(raw_row) != col_count:
                raise IRS990Error("IRS filing-index row shape or population bound differs")
            oid = raw_row[oid_idx]
            if (
                _OID_RE.fullmatch(oid) is None
                or _EIN_RE.fullmatch(raw_row[ein_idx]) is None
                or _TAX_PERIOD_RE.fullmatch(raw_row[period_idx]) is None
            ):
                raise IRS990Error("IRS index object ID, EIN or tax period is malformed")
            packed = _pack_index_row(raw_row)
            existing_slot = oid_to_slot.get(oid)
            if existing_slot is not None:
                existing_bytes = buf[offsets[existing_slot] : offsets[existing_slot + 1]]
                if allow_duplicate_identical and existing_bytes == packed:
                    duplicate_identical += 1
                    continue
                raise IRS990Error("IRS index contains duplicate object ID")
            oid_to_slot[oid] = len(return_types)
            index_rows.append(ordinal)
            return_types.append(sys.intern(raw_row[rtype_idx]))
            buf.extend(packed)
            offsets.append(len(buf))
    except (UnicodeError, csv.Error) as error:
        raise IRS990Error("IRS filing index is malformed") from error

    return IRS990IndexMap(
        submission_year=submission_year,
        fieldnames=fieldnames,
        oid_to_slot=oid_to_slot,
        index_rows=index_rows,
        return_types=return_types,
        offsets=offsets,
        buffer=buf,
        total_rows=ordinal,
        duplicate_identical_rows=duplicate_identical,
    )


def read_index(stream, *, submission_year, object_ids):
    """Scan the whole retained annual index once, proving selected membership and uniqueness.

    Unknown columns and literal values survive in ``native_index``. This proves
    selected membership, never completeness of the publisher's filing population.
    """
    object_ids = _object_ids(object_ids)
    selected = set(object_ids)
    _validate_submission_year(submission_year)
    text = io.TextIOWrapper(io.BufferedReader(_BoundedIndex(stream)), encoding="utf-8-sig", newline="")
    rows = csv.DictReader(text, strict=True)
    if (
        not rows.fieldnames
        or len(set(rows.fieldnames)) != len(rows.fieldnames)
        or not REQUIRED_COLUMNS <= set(rows.fieldnames)
    ):
        raise IRS990Error("IRS filing-index header changed")
    found = {}
    try:
        for ordinal, row in enumerate(rows, 1):
            if ordinal > MAX_INDEX_ROWS or None in row or any(value is None for value in row.values()):
                raise IRS990Error("IRS filing-index row shape or population bound differs")
            oid = row["OBJECT_ID"]
            if oid not in selected:
                continue
            if oid in found:
                raise IRS990Error("IRS selected object ID is duplicated in the index")
            if _EIN_RE.fullmatch(row["EIN"]) is None or _TAX_PERIOD_RE.fullmatch(row["TAX_PERIOD"]) is None:
                raise IRS990Error("IRS selected EIN or tax period is malformed")
            found[oid] = {
                "object_id": oid,
                "submission_year": submission_year,
                "index_row": ordinal,
                "native_index": dict(row),
            }
    except (UnicodeError, csv.Error) as error:
        raise IRS990Error("IRS filing index is malformed") from error
    if set(found) != selected:
        raise IRS990Error("IRS selected object ID is missing from the retained index")
    return [found[oid] for oid in object_ids]


def _node(element, xpath):
    return {
        "tag": element.tag,
        "attributes": dict(element.attrib),
        "text": element.text,
        "source_xpath": xpath,
        "tail": element.tail,
        "children": [_node(child, f"{xpath}/*[{i}]") for i, child in enumerate(element, 1)],
    }


def child(node, name):
    """One immediate IRS-namespace child; ambiguous repeats refuse rather than choose a value."""
    matches = [entry for entry in node["children"] if entry["tag"] == f"{_NS_PREFIX}{name}"]
    if len(matches) > 1:
        raise IRS990Error(f"IRS singleton element repeats: {name}")
    return matches[0] if matches else None


def text_at(node, *path):
    for name in path:
        node = child(node, name) if node is not None else None
    return node["text"] if node is not None else None


def scan_form990_return(body: bytes, *, filing: Mapping[str, Any], locator: Mapping[str, Any]) -> dict[str, Any]:
    """Stream-parse an IRS return XML via Expat without retaining a whole-document DOM.

    Proves root namespace/version, ReturnHeader identity against ``filing``,
    single main-form uniqueness, and ``ReturnData/@documentCnt`` accounting while
    emitting exact positional XPaths on captured Part VII and Schedule I subtrees.
    """
    return_version: str | None = None
    header_seen = 0
    data_seen = 0
    in_header = False
    in_filer = False
    in_data = False
    in_irs990 = False
    in_schedule_i = False
    nested_container: tuple[str, str, str] | None = None
    declared_doc_cnt_raw: str | None = None
    observed_doc_cnt = 0
    main_form_counts: dict[str, int] = {name: 0 for name in FORM_NODES.values()}
    schedule_i_count = 0

    header_fields: dict[str, str | None] = {}
    form_fields: dict[str, str | None] = {}
    seen_header_keys: set[str] = set()
    seen_form_keys: set[str] = set()
    seen_containers: set[str] = set()
    filer_seen = 0

    part_vii_entries: list[dict[str, Any]] = []
    schedule_i_grants: list[dict[str, Any]] = []

    depth = 0
    child_counts: list[int] = [0]
    pos_stack: list[int] = []
    in_tail = False

    # Active scalar text capture: (target_dict, key, target_depth, chunks)
    active_scalar: tuple[dict[str, str | None], str, int, list[str]] | None = None

    # Active captured subtree stack (for Form990PartVIISectionAGrp or RecipientTable)
    subtree_target: list[dict[str, Any]] | None = None
    subtree_stack: list[dict[str, Any]] = []
    active_node_text_chunks: list[str] = []
    tail_target_node: dict[str, Any] | None = None
    tail_chunks: list[str] = []

    def _flush_node_text() -> None:
        if subtree_stack and active_node_text_chunks:
            subtree_stack[-1]["text"] = "".join(active_node_text_chunks)
            active_node_text_chunks.clear()

    def _flush_tail() -> None:
        nonlocal tail_target_node
        if tail_target_node is not None:
            if tail_chunks:
                tail_target_node["tail"] = "".join(tail_chunks)
                tail_chunks.clear()
            tail_target_node = None

    def _start_scalar(
        target: dict[str, str | None],
        seen: set[str],
        key: str,
        label_name: str,
        at_depth: int,
    ) -> None:
        nonlocal active_scalar
        if key in seen:
            raise IRS990Error(f"IRS singleton element repeats: {label_name}")
        seen.add(key)
        active_scalar = (target, key, at_depth, [])

    def start(tag: str, attributes: dict[str, str]) -> None:
        nonlocal depth, in_tail, return_version
        nonlocal header_seen, data_seen, in_header, in_filer, in_data, in_irs990, in_schedule_i
        nonlocal nested_container, declared_doc_cnt_raw, observed_doc_cnt, schedule_i_count, filer_seen
        nonlocal subtree_target

        _flush_tail()
        if subtree_stack:
            _flush_node_text()

        child_counts[-1] += 1
        sibling_index = child_counts[-1]
        pos_stack.append(sibling_index)
        child_counts.append(0)
        depth += 1
        in_tail = False

        if subtree_stack:
            parent_node = subtree_stack[-1]
            node = {
                "tag": tag,
                "attributes": dict(attributes),
                "text": None,
                "source_xpath": f"{parent_node['source_xpath']}/*[{sibling_index}]",
                "tail": None,
                "children": [],
            }
            parent_node["children"].append(node)
            subtree_stack.append(node)
            return

        if depth == 1:
            if tag != f"{_NS_PREFIX}Return" or not attributes.get("returnVersion"):
                raise IRS990Error("IRS XML root, namespace or returnVersion differs")
            return_version = attributes["returnVersion"]
            return

        if depth == 2:
            if tag == f"{_NS_PREFIX}ReturnHeader":
                header_seen += 1
                if header_seen > 1:
                    raise IRS990Error("IRS singleton element repeats: ReturnHeader")
                in_header = True
            elif tag == f"{_NS_PREFIX}ReturnData":
                data_seen += 1
                if data_seen > 1:
                    raise IRS990Error("IRS singleton element repeats: ReturnData")
                in_data = True
                declared_doc_cnt_raw = attributes.get("documentCnt")
            return

        if in_header:
            if depth == 3:
                scalar_key = _HEADER_SCALAR_TAGS.get(tag)
                if scalar_key is not None:
                    _start_scalar(header_fields, seen_header_keys, scalar_key, scalar_key, depth)
                elif tag == f"{_NS_PREFIX}Filer":
                    filer_seen += 1
                    if filer_seen > 1:
                        raise IRS990Error("IRS singleton element repeats: Filer")
                    in_filer = True
            elif in_filer and depth == 4 and tag == f"{_NS_PREFIX}EIN":
                _start_scalar(header_fields, seen_header_keys, "EIN", "EIN", depth)
            return

        if in_data:
            if depth == 3:
                observed_doc_cnt += 1
                form_name = _FORM_TAGS.get(tag)
                if form_name is not None:
                    main_form_counts[form_name] += 1
                    if main_form_counts[form_name] > 1:
                        raise IRS990Error(f"IRS singleton element repeats: {form_name}")
                    if form_name == "IRS990":
                        in_irs990 = True
                elif tag == f"{_NS_PREFIX}IRS990ScheduleI":
                    schedule_i_count += 1
                    if schedule_i_count > 1:
                        raise IRS990Error("IRS singleton element repeats: IRS990ScheduleI")
                    in_schedule_i = True
                return

            if in_irs990:
                if depth == 4:
                    if tag == f"{_NS_PREFIX}Form990PartVIISectionAGrp":
                        xpath = "".join(f"/*[{p}]" for p in pos_stack)
                        node = {
                            "tag": tag,
                            "attributes": dict(attributes),
                            "text": None,
                            "source_xpath": xpath,
                            "tail": None,
                            "children": [],
                        }
                        subtree_target = part_vii_entries
                        subtree_stack.append(node)
                        return
                    scalar_key = _FORM990_SCALAR_TAGS.get(tag)
                    if scalar_key is not None:
                        _start_scalar(form_fields, seen_form_keys, scalar_key, scalar_key, depth)
                        return
                    nested = _FORM990_NESTED_SCALARS.get(tag)
                    if nested is not None:
                        container_name = nested[0]
                        if container_name in seen_containers:
                            raise IRS990Error(f"IRS singleton element repeats: {container_name}")
                        seen_containers.add(container_name)
                        nested_container = nested
                elif depth == 5 and nested_container is not None and tag == nested_container[1]:
                    leaf_label = nested_container[2].split("/", 1)[1]
                    _start_scalar(form_fields, seen_form_keys, nested_container[2], leaf_label, depth)
                return

            if in_schedule_i and depth == 4 and tag == f"{_NS_PREFIX}RecipientTable":
                xpath = "".join(f"/*[{p}]" for p in pos_stack)
                node = {
                    "tag": tag,
                    "attributes": dict(attributes),
                    "text": None,
                    "source_xpath": xpath,
                    "tail": None,
                    "children": [],
                }
                subtree_target = schedule_i_grants
                subtree_stack.append(node)

    def data(chunk: str) -> None:
        if tail_target_node is not None and in_tail:
            tail_chunks.append(chunk)
            return
        if subtree_stack:
            if not in_tail:
                active_node_text_chunks.append(chunk)
            return
        if active_scalar is not None and depth == active_scalar[2] and not in_tail:
            active_scalar[3].append(chunk)

    def end(tag: str) -> None:
        nonlocal depth, in_tail
        nonlocal in_header, in_filer, in_data, in_irs990, in_schedule_i
        nonlocal nested_container, active_scalar, subtree_target, tail_target_node

        _flush_tail()

        if subtree_stack:
            _flush_node_text()
            closed = subtree_stack.pop()
            if not subtree_stack:
                assert subtree_target is not None
                subtree_target.append(closed)
                subtree_target = None
            tail_target_node = closed
        else:
            if active_scalar is not None and depth == active_scalar[2]:
                target_dict, key, _target_depth, chunks = active_scalar
                target_dict[key] = "".join(chunks) if chunks else None
                active_scalar = None
            if in_header:
                if depth == 3 and in_filer:
                    in_filer = False
                elif depth == 2:
                    in_header = False
            elif in_data:
                if depth == 4 and nested_container is not None:
                    nested_container = None
                elif depth == 3:
                    if in_irs990:
                        in_irs990 = False
                    if in_schedule_i:
                        in_schedule_i = False
                elif depth == 2:
                    in_data = False

        child_counts.pop()
        pos_stack.pop()
        depth -= 1
        in_tail = True

    scan_xml(
        body,
        start=start,
        end=end,
        data=data,
        max_bytes=MAX_RETURN_BYTES,
        error_type=IRS990Error,
        label="IRS return XML",
        max_depth=64,
    )
    _flush_tail()

    if return_version is None or header_seen != 1 or data_seen != 1:
        raise IRS990Error("IRS return header or data is missing")

    if declared_doc_cnt_raw is None:
        declared_doc_cnt: int | None = None
        document_cnt_status = "absent"
    elif not (declared_doc_cnt_raw.isascii() and declared_doc_cnt_raw.isdigit()):
        raise IRS990Error("IRS declared return document count is malformed")
    else:
        declared_doc_cnt = int(declared_doc_cnt_raw)
        if observed_doc_cnt > declared_doc_cnt:
            raise IRS990Error("IRS observed return document count exceeds declared documentCnt")
        document_cnt_status = "matched" if observed_doc_cnt == declared_doc_cnt else "redacted_fewer"

    index = filing["native_index"]
    form_type = header_fields.get("ReturnTypeCd")
    end_date = header_fields.get("TaxPeriodEndDt")
    if (
        header_fields.get("EIN") != index["EIN"]
        or form_type != index["RETURN_TYPE"]
        or not end_date
        or _ISO_DATE_RE.fullmatch(end_date) is None
        or end_date[:7].replace("-", "") != index["TAX_PERIOD"]
    ):
        raise IRS990Error("IRS XML EIN, return type or tax period differs from the index")
    try:
        date.fromisoformat(end_date)
    except ValueError as error:
        raise IRS990Error("IRS XML tax period end is not a calendar date") from error
    if form_type not in FORM_NODES or main_form_counts[FORM_NODES[form_type]] != 1:
        raise IRS990Error("IRS form body differs from its return type")
    if sum(main_form_counts.values()) != 1:
        raise IRS990Error("IRS XML has conflicting main return forms")

    return {
        **filing,
        "return_version": return_version,
        "return_type": form_type,
        "document_cnt_declared": declared_doc_cnt,
        "document_cnt_observed": observed_doc_cnt,
        "document_cnt_status": document_cnt_status,
        "header": header_fields,
        "form_fields": form_fields,
        "part_vii_entries": part_vii_entries,
        "schedule_i_present": schedule_i_count == 1,
        "schedule_i_grants": schedule_i_grants,
        "source_locator": {**locator, "member_sha256": "sha256:" + hashlib.sha256(body).hexdigest()},
    }


def parse_return(body, *, filing, locator):
    """Keep native XML fields and positional paths; prove EIN/form/period against the selected index row."""
    root = parse_xml(body, max_bytes=MAX_RETURN_BYTES, error_type=IRS990Error, label="IRS return XML", max_depth=64)
    if root.tag != f"{_NS_PREFIX}Return" or not root.get("returnVersion"):
        raise IRS990Error("IRS XML root, namespace or returnVersion differs")
    native = _node(root, "/*[1]")
    header, data = child(native, "ReturnHeader"), child(native, "ReturnData")
    if header is None or data is None:
        raise IRS990Error("IRS return header or data is missing")
    declared = data["attributes"].get("documentCnt")
    if declared is not None and (
        not (declared.isascii() and declared.isdigit()) or int(declared) != len(data["children"])
    ):
        raise IRS990Error("IRS declared return document count differs from observed XML")
    index = filing["native_index"]
    form = text_at(header, "ReturnTypeCd")
    end = text_at(header, "TaxPeriodEndDt")
    if (
        text_at(header, "Filer", "EIN") != index["EIN"]
        or form != index["RETURN_TYPE"]
        or not end
        or _ISO_DATE_RE.fullmatch(end) is None
        or end[:7].replace("-", "") != index["TAX_PERIOD"]
    ):
        raise IRS990Error("IRS XML EIN, return type or tax period differs from the index")
    try:
        date.fromisoformat(end)
    except ValueError as error:
        raise IRS990Error("IRS XML tax period end is not a calendar date") from error
    if form not in FORM_NODES or child(data, FORM_NODES[form]) is None:
        raise IRS990Error("IRS form body differs from its return type")
    if sum(child(data, name) is not None for name in FORM_NODES.values()) != 1:
        raise IRS990Error("IRS XML has conflicting main return forms")
    return {
        **filing,
        "return_version": root.get("returnVersion"),
        "native_xml": native,
        "source_locator": {**locator, "member_sha256": "sha256:" + hashlib.sha256(body).hexdigest()},
    }


def _is_safe_zip_member_name(filename: str, *, is_dir: bool = False) -> bool:
    if not isinstance(filename, str) or not filename or filename.startswith("/") or "\\" in filename:
        return False
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in filename):
        return False
    trimmed = filename[:-1] if is_dir and filename.endswith("/") else filename
    if not trimmed or trimmed.endswith("/"):
        return False
    raw_parts = trimmed.split("/")
    if any(part in {"", ".", ".."} for part in raw_parts):
        return False
    posix_parts = PurePosixPath(trimmed).parts
    return bool(posix_parts) and not any(part in {".", "..", "/"} for part in posix_parts)


_STDLIB_ZIP_METHODS = frozenset({ZIP_STORED, ZIP_DEFLATED, ZIP_BZIP2, ZIP_LZMA})
_ZIP_DEFLATE64 = 9
_ZIP_LOCAL_HEADER_SIG = b"PK\x03\x04"
_ZIP_LOCAL_HEADER_STRUCT = struct.Struct("<4sHHHHHIIIHH")
_ZIP_FLAG_ENCRYPTED = 0x0001
_ZIP_FLAG_COMPRESSED_PATCH = 0x0020
_ZIP_FLAG_STRONG_ENCRYPTION = 0x0040
_ZIP_FLAG_UTF8 = 0x0800
_DEFLATE64_CHUNK_BYTES = 65_536


def _read_deflate64_member(archive: ZipFile, entry: ZipInfo, *, max_bytes: int) -> bytes:
    """Stream-decode a PKZIP method-9 (Deflate64 / Enhanced Deflate) member with strict bounds."""
    fp = archive.fp
    if fp is None:
        raise BadZipFile("ZIP archive is closed")
    if entry.flag_bits & _ZIP_FLAG_ENCRYPTED:
        raise BadZipFile("ZIP member is encrypted")
    if entry.flag_bits & _ZIP_FLAG_COMPRESSED_PATCH:
        raise NotImplementedError("compressed patched data (flag bit 5)")
    if entry.flag_bits & _ZIP_FLAG_STRONG_ENCRYPTION:
        raise NotImplementedError("strong encryption (flag bit 6)")
    if entry.header_offset < 0 or entry.compress_size < 0 or entry.file_size < 0:
        raise BadZipFile("ZIP member header offsets or sizes are negative")

    fp.seek(entry.header_offset)
    local_header = fp.read(_ZIP_LOCAL_HEADER_STRUCT.size)
    if len(local_header) != _ZIP_LOCAL_HEADER_STRUCT.size:
        raise BadZipFile("Truncated local file header")
    (
        sig,
        _ver,
        local_flags,
        local_method,
        _mtime,
        _mdate,
        _local_crc,
        _local_csize,
        _local_usize,
        filename_len,
        extra_len,
    ) = _ZIP_LOCAL_HEADER_STRUCT.unpack(local_header)
    if sig != _ZIP_LOCAL_HEADER_SIG:
        raise BadZipFile("Bad magic number for local file header")
    if local_flags & _ZIP_FLAG_ENCRYPTED:
        raise BadZipFile("Local ZIP header marks member as encrypted")
    if local_flags & _ZIP_FLAG_COMPRESSED_PATCH:
        raise NotImplementedError("compressed patched data (flag bit 5)")
    if local_flags & _ZIP_FLAG_STRONG_ENCRYPTION:
        raise NotImplementedError("strong encryption (flag bit 6)")
    if local_method != _ZIP_DEFLATE64:
        raise BadZipFile("Local ZIP header compression method differs from central directory")

    local_fname = fp.read(filename_len)
    if len(local_fname) != filename_len:
        raise BadZipFile("Truncated local file header filename")
    metadata_encoding = getattr(archive, "metadata_encoding", None) or "cp437"
    encoding = "utf-8" if (local_flags & _ZIP_FLAG_UTF8) else metadata_encoding
    try:
        local_fname_str = local_fname.decode(encoding)
    except UnicodeDecodeError as error:
        raise BadZipFile("Local ZIP header filename cannot be decoded") from error
    orig_filename = getattr(entry, "orig_filename", entry.filename)
    if local_fname_str != orig_filename:
        raise BadZipFile("File name in central directory and local header differ")

    if extra_len:
        extra_field = fp.read(extra_len)
        if len(extra_field) != extra_len:
            raise BadZipFile("Truncated local file header extra field")

    payload_start = fp.tell()
    end_offset = getattr(entry, "_end_offset", None)
    if (
        end_offset is not None
        and end_offset != entry.header_offset
        and payload_start + entry.compress_size > end_offset
    ):
        raise BadZipFile("Overlapped ZIP archive entries")

    inflater = inflate64.Inflater()
    out = bytearray()
    crc = 0
    remaining = entry.compress_size
    limit = max_bytes + 1

    while remaining > 0:
        to_read = min(_DEFLATE64_CHUNK_BYTES, remaining)
        compressed_chunk = fp.read(to_read)
        if len(compressed_chunk) != to_read:
            raise BadZipFile("Truncated Deflate64 member payload")
        remaining -= to_read

        try:
            decompressed = inflater.inflate(compressed_chunk, limit - len(out))
        except ValueError as error:
            raise BadZipFile("Corrupted Deflate64 member payload") from error

        if decompressed:
            out.extend(decompressed)
            if len(out) > max_bytes:
                # Mirror stdlib ZipFile.open(entry).read(max_bytes + 1): stop immediately
                # at the byte cap without buffering unbounded RAM so the caller reports
                # oversized_member (IRS990ArchiveStream) or refuses (read_selected_returns).
                return bytes(out)
            crc = zlib.crc32(decompressed, crc)

        if inflater.eof and remaining > 0:
            raise BadZipFile("Unexpected trailing compressed bytes after Deflate64 stream end")

    if not inflater.eof:
        raise BadZipFile("Truncated or incomplete Deflate64 stream")
    if len(out) != entry.file_size:
        raise BadZipFile("Deflate64 decompressed size does not match ZIP header")
    if (crc & 0xFFFFFFFF) != entry.CRC:
        raise BadZipFile("Bad CRC-32 for Deflate64 member")
    return bytes(out)


def _read_zip_member(archive: ZipFile, entry: ZipInfo, *, max_bytes: int) -> bytes:
    """Read one ZIP member bounded to ``max_bytes + 1`` bytes, supporting stdlib methods and Deflate64."""
    if entry.compress_type in _STDLIB_ZIP_METHODS:
        with archive.open(entry) as original:
            return original.read(max_bytes + 1)
    if entry.compress_type == _ZIP_DEFLATE64:
        return _read_deflate64_member(archive, entry, max_bytes=max_bytes)
    raise IRS990Error(f"IRS archive uses unsupported ZIP compression method {entry.compress_type}")


def _check_archive_size(source: str | Path | Any) -> None:
    if isinstance(source, (str, Path)):
        try:
            archive_size = Path(source).stat().st_size
        except OSError as error:
            raise IRS990Error("IRS archive is malformed or incomplete") from error
    else:
        try:
            pos = source.tell()
            try:
                source.seek(0, io.SEEK_END)
                archive_size = source.tell()
            finally:
                source.seek(pos)
        except (AttributeError, OSError, io.UnsupportedOperation) as error:
            raise IRS990Error("IRS archive stream must be seekable") from error
    if archive_size > MAX_ARCHIVE_BYTES:
        raise IRS990Error("IRS archive exceeds its byte bound")


class IRS990ArchiveStream(Iterable[IRS990ParsedReturn | IRS990Anomaly | IRS990SkippedMember]):
    """Single-pass streaming reader over an official TEOS ZIP with complete entry disposition."""

    def __init__(
        self,
        zip_path_or_stream: str | Path | Any,
        *,
        index_by_oid: Mapping[str, dict[str, Any]],
        archive_sha256: str,
        return_types: Iterable[str] = ("990",),
        on_anomaly: str = "yield",
        yield_skipped: bool = False,
    ) -> None:
        allowed = frozenset(return_types)
        if not allowed or not allowed <= set(FORM_NODES):
            raise IRS990Error("IRS archive return_types must select supported TEOS form types")
        if on_anomaly not in {"yield", "raise"}:
            raise IRS990Error("IRS archive on_anomaly must be 'yield' or 'raise'")
        self._source = zip_path_or_stream
        self._index_by_oid = index_by_oid
        self._archive_sha256 = archive_sha256
        self._return_types = allowed
        self._on_anomaly = on_anomaly
        self._yield_skipped = yield_skipped
        self._consumed = False
        self.disposition = ArchiveDisposition(archive_sha256=archive_sha256)

    def _emit_anomaly(
        self,
        *,
        member_name: str,
        object_id: str | None,
        reason: str,
        detail: str,
        return_type: str | None = None,
        member_sha256: str | None = None,
    ) -> IRS990Anomaly:
        self.disposition.anomalies += 1
        self.disposition.anomalies_by_reason[reason] += 1
        if self._on_anomaly == "raise":
            raise IRS990Error(f"{reason}: {detail}")
        return IRS990Anomaly(
            member_name=member_name,
            object_id=object_id,
            reason=reason,
            detail=detail,
            archive_sha256=self._archive_sha256,
            return_type=return_type,
            member_sha256=member_sha256,
        )

    def __iter__(self) -> Iterator[IRS990ParsedReturn | IRS990Anomaly | IRS990SkippedMember]:
        if self._consumed:
            raise IRS990Error("IRS archive stream can only be iterated once")
        self._consumed = True

        _check_archive_size(self._source)

        index_map = self._index_by_oid
        fast_index = isinstance(index_map, IRS990IndexMap)
        seen_oids: set[str] = set()

        try:
            archive = ZipFile(self._source)
        except (BadZipFile, OSError, EOFError, zlib.error, NotImplementedError) as error:
            raise IRS990Error("IRS archive is malformed or incomplete") from error

        with archive:
            try:
                entries = archive.infolist()
            except (BadZipFile, OSError, EOFError, zlib.error) as error:
                raise IRS990Error("IRS archive is malformed or incomplete") from error
            if len(entries) > MAX_ARCHIVE_MEMBERS:
                raise IRS990Error("IRS archive exceeds its member bound")
            self.disposition.total_entries = len(entries)

            for entry in entries:
                if not _is_safe_zip_member_name(entry.filename, is_dir=entry.is_dir()):
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=None,
                        reason="unsafe_member_path",
                        detail="ZIP member path contains unsafe traversal, absolute, or control characters",
                    )
                    continue

                if entry.is_dir():
                    self.disposition.skipped_directories += 1
                    if self._yield_skipped:
                        yield IRS990SkippedMember(
                            member_name=entry.filename,
                            object_id=None,
                            return_type=None,
                            reason="directory",
                        )
                    continue

                basename = PurePosixPath(entry.filename).name
                oid = basename.removesuffix("_public.xml")
                if basename != oid + "_public.xml" or _OID_RE.fullmatch(oid) is None:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=None,
                        reason="non_public_member",
                        detail="ZIP member does not match <18-digit OBJECT_ID>_public.xml",
                    )
                    continue

                if oid in seen_oids:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=oid,
                        reason="duplicate_member_oid",
                        detail="Duplicate OBJECT_ID member within the same archive",
                    )
                    continue
                seen_oids.add(oid)

                if fast_index:
                    rtype = index_map.return_type(oid)
                    if rtype is None:
                        yield self._emit_anomaly(
                            member_name=entry.filename,
                            object_id=oid,
                            reason="unindexed_member",
                            detail="Archive OBJECT_ID is absent from the annual filing index",
                        )
                        continue
                else:
                    if oid not in index_map:
                        yield self._emit_anomaly(
                            member_name=entry.filename,
                            object_id=oid,
                            reason="unindexed_member",
                            detail="Archive OBJECT_ID is absent from the annual filing index",
                        )
                        continue
                    rtype = index_map[oid]["native_index"]["RETURN_TYPE"]

                if rtype not in self._return_types:
                    if rtype not in FORM_NODES:
                        yield self._emit_anomaly(
                            member_name=entry.filename,
                            object_id=oid,
                            reason="unknown_return_type",
                            detail=f"Unrecognized IRS index return type: {rtype}",
                            return_type=rtype,
                        )
                        continue
                    self.disposition.skipped_excluded_return_type += 1
                    self.disposition.excluded_by_return_type[rtype] += 1
                    if self._yield_skipped:
                        yield IRS990SkippedMember(
                            member_name=entry.filename,
                            object_id=oid,
                            return_type=rtype,
                            reason="excluded_return_type",
                        )
                    continue

                if entry.flag_bits & 1:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=oid,
                        reason="encrypted_member",
                        detail="ZIP member is encrypted",
                        return_type=rtype,
                    )
                    continue

                if entry.file_size > MAX_RETURN_BYTES:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=oid,
                        reason="oversized_member",
                        detail=f"ZIP member exceeds {MAX_RETURN_BYTES} bytes",
                        return_type=rtype,
                    )
                    continue

                try:
                    body = _read_zip_member(archive, entry, max_bytes=MAX_RETURN_BYTES)
                except (BadZipFile, OSError, EOFError, zlib.error, NotImplementedError, RuntimeError) as error:
                    raise IRS990Error("IRS archive is malformed or incomplete") from error

                if len(body) > MAX_RETURN_BYTES:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=oid,
                        reason="oversized_member",
                        detail=f"Decompressed XML exceeds {MAX_RETURN_BYTES} bytes",
                        return_type=rtype,
                    )
                    continue

                filing = index_map[oid]
                try:
                    record = scan_form990_return(
                        body,
                        filing=filing,
                        locator={
                            "archive_sha256": self._archive_sha256,
                            "member_name": entry.filename,
                            "index_row": filing["index_row"],
                        },
                    )
                except IRS990Error as error:
                    yield self._emit_anomaly(
                        member_name=entry.filename,
                        object_id=oid,
                        reason="parse_error",
                        detail=str(error),
                        return_type=rtype,
                        member_sha256="sha256:" + hashlib.sha256(body).hexdigest(),
                    )
                    continue

                self.disposition.parsed_returns += 1
                self.disposition.parsed_by_return_type[rtype] += 1
                self.disposition.parsed_by_version[record["return_version"]] += 1
                self.disposition.document_cnt_status_counts[record["document_cnt_status"]] += 1
                yield IRS990ParsedReturn(
                    record=record,
                    member_name=entry.filename,
                    object_id=oid,
                    return_type=rtype,
                    return_version=record["return_version"],
                )


def iter_archive_returns(
    zip_path_or_stream: str | Path | Any,
    *,
    index_by_oid: Mapping[str, dict[str, Any]],
    archive_sha256: str,
    return_types: Iterable[str] = ("990",),
    on_anomaly: str = "yield",
    yield_skipped: bool = False,
) -> IRS990ArchiveStream:
    """Stream an official TEOS ZIP member-by-member without extracting to disk.

    Fast-skips excluded return types (such as 990EZ, 990PF, 990T) via ``index_by_oid``
    while recording complete entry counts in ``stream.disposition``.
    """
    return IRS990ArchiveStream(
        zip_path_or_stream,
        index_by_oid=index_by_oid,
        archive_sha256=archive_sha256,
        return_types=return_types,
        on_anomaly=on_anomaly,
        yield_skipped=yield_skipped,
    )


def read_selected_returns(stream, *, filings, archive_sha256):
    """Read only explicitly selected XML members; no archive extraction or unrelated return parsing."""
    filings = list(filings)
    ids = set(_object_ids(row["object_id"] for row in filings))
    _check_archive_size(stream)
    try:
        with ZipFile(stream) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_ARCHIVE_MEMBERS:
                raise IRS990Error("IRS archive exceeds its member bound")
            selected = {}
            for entry in entries:
                if not _is_safe_zip_member_name(entry.filename, is_dir=entry.is_dir()):
                    raise IRS990Error("IRS archive contains an unsafe member path")
                basename = PurePosixPath(entry.filename).name
                oid = basename.removesuffix("_public.xml")
                if oid in ids and basename == oid + "_public.xml":
                    if oid in selected or entry.is_dir() or entry.flag_bits & 1 or entry.file_size > MAX_RETURN_BYTES:
                        raise IRS990Error("IRS selected XML member is ambiguous, encrypted or oversized")
                    selected[oid] = entry
            if set(selected) != ids:
                raise IRS990Error("IRS selected XML member is missing from the archive")
            result = []
            for filing in filings:
                entry = selected[filing["object_id"]]
                body = _read_zip_member(archive, entry, max_bytes=MAX_RETURN_BYTES)
                result.append(
                    parse_return(
                        body,
                        filing=filing,
                        locator={
                            "archive_sha256": archive_sha256,
                            "member_name": entry.filename,
                            "index_row": filing["index_row"],
                        },
                    )
                )
            return result
    except (BadZipFile, OSError, EOFError, zlib.error, NotImplementedError, RuntimeError) as error:
        raise IRS990Error("IRS archive is malformed or incomplete") from error
