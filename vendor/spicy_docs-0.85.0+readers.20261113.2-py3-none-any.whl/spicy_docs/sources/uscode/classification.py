"""OLRC per-Congress classification tables: which Code sections each new public law touched.

For the current Congress, OLRC publishes one fixed-width ``<PRE>`` table per
session in two orders, by public law (``tbl{congress}pl_{session}.htm``) and by
Code citation (``tbl{congress}cd_{session}.htm``), linked from
``classification/tables.html``; the column offsets are read from the page's own
header line and the page column from where its statviewer links start, never
assumed. This is the per-Congress view of a new law's
sections, where Table III (``spicy_docs.sources.uscode``) is the historical
per-act view. Both readers prove the identity the page states before taking a
row -- the index's own ``<title>``, the table's Congress-and-session caption --
and refuse a page with no table links, no rows, or not exactly one ``<PRE>``
block, because a truncated, replaced or cut-off page has the same shape.
"""

from __future__ import annotations

import html
import re
from collections import Counter
from dataclasses import dataclass
from typing import Literal
from urllib.parse import parse_qs, urlsplit

from spicy_docs.sources.uscode.core import (
    DEFAULT_MAX_ENTRIES_PER_PAGE,
    DEFAULT_MAX_PAGE_BYTES,
    OLRC,
    UsCodeSourceError,
    _body,
    _count,
    _limit,
)

CLASSIFICATION_INDEX_URL = f"{OLRC}/classification/tables.html"
INDEX_TITLE = "UNITED STATES CODE CLASSIFICATION TABLES"

type TableOrder = Literal["public-law", "code"]

#: The publisher's own file-name grammar, read from the index's hrefs.
_ORDER_CODES: dict[TableOrder, str] = {"public-law": "pl", "code": "cd"}
_SESSION_CODES = {1: "1st", 2: "2nd"}
_TABLE_FILE = re.compile(r"tbl(?P<congress>[1-9][0-9]{0,2})(?P<order>pl|cd)_(?P<session>1st|2nd)\.html?")
_HREF = re.compile(r'href="([^"]+)"')
_TITLE = re.compile(r"<title>\s*(.*?)\s*</title>", re.DOTALL | re.IGNORECASE)
_CENTER = re.compile(r"<CENTER>(.*?)</CENTER>", re.DOTALL | re.IGNORECASE)
_TAG = re.compile(r"<[^>]+>")
_PRE = re.compile(r"<PRE[^>]*>(.*?)</PRE>", re.DOTALL | re.IGNORECASE)
_FONT = re.compile(r"</?FONT[^>]*>", re.IGNORECASE)
_CAPTION = re.compile(
    r"(?P<congress>[1-9][0-9]{0,2})(?:st|nd|rd|th) Congress, (?P<session>1st|2nd) Session\s*"
    r"\((?P<laws>Public Law[^)]*)\)"
)
_HEADINGS: dict[TableOrder, str] = {
    "public-law": "TABLE OF CLASSIFICATIONS FOR PUBLIC LAWS",
    "code": "TABLE OF SECTIONS AMENDED, ENACTED, OMITTED, REPEALED, OR TRANSFERRED",
}
_PREPARED = re.compile(
    r"Prepared by\s+Office of the Law Revision Counsel\s+U\.S\. House of Representatives\s+(?P<date>[^<]+?)\s*$"
)
_VOLUME_HEADER = re.compile(r"(?P<volume>[0-9]+) Stat\.")
_LAW_NUMBER = re.compile(r"(?P<congress>[1-9][0-9]{0,2})-(?P<number>[1-9][0-9]*)")
_STAT_LINK = re.compile(r'<a href="(?P<href>/statviewer\.htm\?[^"]*)">(?P<text>[^<]*)</a>', re.IGNORECASE)
_STATED_RANGE = re.compile(r"(?P<first>[1-9][0-9]{0,2}-[1-9][0-9]*)(?: through (?P<last>[1-9][0-9]{0,2}-[1-9][0-9]*))?")
_COLUMNS = ("Title", "Section", "Description", "Pub. L.", "Sec.")


def _session_code(session: object) -> str:
    if session not in _SESSION_CODES:
        raise UsCodeSourceError("session must be 1 or 2")
    return _SESSION_CODES[session]  # type: ignore[index]


def _congress(congress: object) -> int:
    if type(congress) is not int or not 1 <= congress <= 999:
        raise UsCodeSourceError("congress must be an integer from 1 to 999")
    return congress  # type: ignore[return-value]


def classification_table_file_name(congress: int, session: int, order: TableOrder = "public-law") -> str:
    """``tbl119pl_2nd.htm``: the grammar every ``tbl`` href on the index follows (four of four, 2026-09-19)."""
    if order not in _ORDER_CODES:
        raise UsCodeSourceError("order must be 'public-law' or 'code'")
    return f"tbl{_congress(congress)}{_ORDER_CODES[order]}_{_session_code(session)}.html"


def classification_table_locator(congress: int, session: int, order: TableOrder = "public-law") -> str:
    return f"{OLRC}/classification/{classification_table_file_name(congress, session, order)}"


@dataclass(frozen=True, slots=True)
class ClassificationTableLink:
    """One session table the index links, as the index spells it."""

    congress: int
    session: int
    order: TableOrder
    href: str

    @property
    def url(self) -> str:
        return f"{OLRC}/classification/{self.href}"


@dataclass(frozen=True, slots=True)
class ClassificationIndex:
    """The index page's title and every session table it links, in page order."""

    source: Literal["classification-index"]
    title: str
    tables: tuple[ClassificationTableLink, ...]
    identity_basis: tuple[str, ...] = ("title:native",)


def parse_classification_index(body: bytes, *, max_bytes: int = DEFAULT_MAX_PAGE_BYTES) -> ClassificationIndex:
    """Read ``tables.html``: prove its title, then list every ``tbl`` link it carries.

    A page with the right title and no table links is refused rather than read
    as "no tables exist": the index has linked four since it was first
    measured, and zero is the shape of a truncated or replaced page.
    """
    _limit(max_bytes)
    text = _text(_body(body, max_bytes, "classification index"), "classification index")
    title = _TITLE.search(text)
    stated = html.unescape(re.sub(r"\s+", " ", title[1])) if title else ""
    if stated not in {INDEX_TITLE, "Classification Tables - US Code"}:
        raise UsCodeSourceError("classification index does not state the expected title")
    tables: list[ClassificationTableLink] = []
    for href in _HREF.findall(text):
        match = _TABLE_FILE.fullmatch(href.rsplit("/", 1)[-1])
        if match is None:
            continue
        order: TableOrder = "public-law" if match["order"] == "pl" else "code"
        session = 1 if match["session"] == "1st" else 2
        tables.append(ClassificationTableLink(int(match["congress"]), session, order, href))
    if not tables:
        raise UsCodeSourceError("classification index links no session tables")
    return ClassificationIndex("classification-index", stated, tuple(tables))


@dataclass(frozen=True, slots=True)
class ClassificationRecord:
    """One line of the table: a Code place, what happened to it, and the law section that did it.

    ``description`` is column 3 verbatim and ``None`` where the page left it
    blank, which the page's own legend reads as "amended"; that reading is
    the consumer's. ``statutes_at_large_page`` is the printed column text --
    one page, or a span like ``637, 638`` -- and the two ``link_*`` fields are
    the ``statviewer`` link's own volume and page where the row carries one.
    """

    seq: int
    usc_title: str
    usc_section: str
    description: str | None
    law_number: str
    act_section: str | None
    statutes_at_large_page: str | None
    link_volume: str | None = None
    link_page: str | None = None


@dataclass(frozen=True, slots=True)
class ClassificationTable:
    """One session table, with the Congress, session, law range and currency the page states itself."""

    source: Literal["classification-table"]
    congress: int
    session: int
    order: TableOrder
    heading: str
    stated_laws: str
    stated_law_numbers: tuple[str, ...]
    statutes_at_large_volume: str | None
    prepared_date: str | None
    records: tuple[ClassificationRecord, ...]
    identity_basis: tuple[str, ...] = ("congress:native", "session:native")


def _text(data: bytes, label: str) -> str:
    if b"</html>" not in data[-4096:]:
        raise UsCodeSourceError(f"{label} is not closed by </html>; the publisher truncated it")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise UsCodeSourceError(f"{label} is not the UTF-8 the publisher declares") from error


def _visible(fragment: str) -> str:
    return html.unescape(re.sub(r"\s+", " ", _TAG.sub(" ", fragment))).strip()


def _stated_law_numbers(stated: str) -> tuple[str, ...]:
    """Expand ``Public Law 119-70 and Public Laws 119-74 through 119-110`` to every number it names."""
    numbers: list[str] = []
    for match in _STATED_RANGE.finditer(stated):
        first, last = match["first"], match["last"]
        if last is None:
            numbers.append(first)
            continue
        first_law, last_law = _LAW_NUMBER.fullmatch(first), _LAW_NUMBER.fullmatch(last)
        if first_law is None or last_law is None or first_law["congress"] != last_law["congress"]:
            raise UsCodeSourceError("classification table states a law range across two Congresses")
        congress = first_law["congress"]
        numbers.extend(f"{congress}-{n}" for n in range(int(first_law["number"]), int(last_law["number"]) + 1))
    return tuple(numbers)


def _offsets(header: str) -> tuple[dict[str, int], str | None]:
    offsets: dict[str, int] = {}
    for column in _COLUMNS:
        position = header.find(column)
        if position < 0:
            raise UsCodeSourceError(f"classification table header lacks the {column!r} column")
        offsets[column] = position
    volume = _VOLUME_HEADER.search(header)
    if volume is None:
        raise UsCodeSourceError("classification table header lacks the Statutes at Large column")
    offsets["Stat."] = volume.start()
    if list(offsets.values()) != sorted(offsets.values()):
        raise UsCodeSourceError("classification table header columns are out of order")
    return offsets, volume["volume"]


def _page_column(lines: list[str], label_column: int) -> int:
    """Where the page cell starts on a row with no link of its own: the column the table's links usually start at.

    OLRC prints the ``139 Stat.`` label three columns left of the pages it heads (67 against 70 on every linked row
    of both archived 119th session tables, 2025-12-28 and 2026-02-19), so an act section of 23 characters or more
    reaches past the label and slicing there cut it. A table with no links keeps the label's column.
    """
    starts = Counter(link.start() for line in lines if (link := _STAT_LINK.search(line)) is not None)
    return starts.most_common(1)[0][0] if starts else label_column


def _record(line: str, seq: int, offsets: dict[str, int], congress: int) -> ClassificationRecord:
    """One data line; the page cell starts where the row's own statviewer link does, else at ``offsets["Stat."]``.

    The link is the publisher's own mark of where the page is: a 26- or 27-character act section pushes it past
    the usual column (Pub. L. 119-60 §7201(c), 71 and 72), and a 25-character one touches it with no space.
    """
    link_volume = link_page = None
    page_column = offsets["Stat."]
    link = _STAT_LINK.search(line)
    if link is not None:
        query = parse_qs(urlsplit(link["href"]).query, keep_blank_values=True)
        link_volume = (query.get("volume") or [""])[0] or None
        link_page = (query.get("page") or [""])[0] or None
        page_column = link.start()
        line = line[: link.start()] + link["text"] + line[link.end() :]
    if "<" in line:
        raise UsCodeSourceError(f"classification table row {seq} carries markup other than a statviewer link")
    if page_column <= offsets["Sec."]:
        raise UsCodeSourceError(f"classification table row {seq} has a statviewer link left of the act-section column")
    stops = [offsets[name] for name in _COLUMNS] + [page_column, len(line)]
    cells = [html.unescape(line[stops[i] : stops[i + 1]]).strip() for i in range(len(stops) - 1)]
    title, section, description, law_number, act_section, page = cells
    law = _LAW_NUMBER.fullmatch(law_number)
    if law is None:
        raise UsCodeSourceError(f"classification table row {seq} states no public law number")
    if int(law["congress"]) != congress:
        raise UsCodeSourceError(f"classification table row {seq} names a law of another Congress")
    if not title or not section:
        raise UsCodeSourceError(f"classification table row {seq} lacks a Code title or section")
    return ClassificationRecord(
        seq=seq,
        usc_title=title,
        usc_section=section,
        description=description or None,
        law_number=law_number,
        act_section=act_section or None,
        statutes_at_large_page=page or None,
        link_volume=link_volume,
        link_page=link_page,
    )


def parse_classification_table(
    body: bytes,
    *,
    congress: int,
    session: int,
    order: TableOrder = "public-law",
    max_bytes: int = DEFAULT_MAX_PAGE_BYTES,
    max_rows: int = DEFAULT_MAX_ENTRIES_PER_PAGE,
) -> ClassificationTable:
    """Read one session table, proving the Congress and session it states are the ones requested.

    The caption is proved before the ``<PRE>`` block is looked at, so a page
    for another session, an index page, or a challenge page served with
    status 200 is refused by name. Zero rows is likewise a refusal: every
    session table measured carries hundreds, and an empty block is the shape
    of a cut-off page, not of a session that classified nothing.
    """
    classification_table_file_name(congress, session, order)
    _limit(max_bytes)
    _count(max_rows, "max_rows")
    text = _text(_body(body, max_bytes, "classification table"), "classification table")
    captions = [_visible(fragment) for fragment in _CENTER.findall(text)]
    caption = next((c for c in captions if _HEADINGS[order] in c), None)
    if caption is None:
        raise UsCodeSourceError("classification table page states no table heading")
    stated = _CAPTION.search(caption)
    if stated is None:
        raise UsCodeSourceError("classification table page states no Congress and session")
    if (int(stated["congress"]), stated["session"]) != (congress, _session_code(session)):
        raise UsCodeSourceError("classification table page states another Congress or session than the request")
    prepared = next((m["date"] for c in captions if (m := _PREPARED.search(c)) is not None), None)
    blocks = _PRE.findall(text)
    if len(blocks) != 1:
        raise UsCodeSourceError("classification table page must carry exactly one <PRE> block")
    lines = [line.rstrip() for line in _FONT.sub("", blocks[0]).split("\n")]
    header_index = next((i for i, line in enumerate(lines) if "Title" in line and "Stat." in line), None)
    if header_index is None:
        raise UsCodeSourceError("classification table lacks its column header line")
    offsets, volume = _offsets(lines[header_index])
    offsets["Stat."] = _page_column(lines[header_index + 1 :], offsets["Stat."])
    records: list[ClassificationRecord] = []
    for line in lines[header_index + 1 :]:
        if not line.strip() or set(line.strip()) <= {"-", " "}:
            continue
        if len(records) >= max_rows:
            raise UsCodeSourceError("classification table states more rows than max_rows")
        records.append(_record(line, len(records), offsets, congress))
    if not records:
        raise UsCodeSourceError("classification table states no rows")
    return ClassificationTable(
        "classification-table",
        congress,
        session,
        order,
        _HEADINGS[order],
        stated["laws"],
        _stated_law_numbers(stated["laws"]),
        volume,
        prepared,
        tuple(records),
    )


__all__ = [
    "CLASSIFICATION_INDEX_URL",
    "INDEX_TITLE",
    "ClassificationIndex",
    "ClassificationRecord",
    "ClassificationTable",
    "ClassificationTableLink",
    "TableOrder",
    "classification_table_file_name",
    "classification_table_locator",
    "parse_classification_index",
    "parse_classification_table",
]
