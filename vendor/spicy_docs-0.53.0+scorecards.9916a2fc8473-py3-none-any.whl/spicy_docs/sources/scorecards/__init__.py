"""Publisher-specific third-party congressional scorecard readers."""

from importlib import import_module

from spicy_docs.sources.scorecards.common import (
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    validate_scorecard_bundle,
)

ADAPTERS = ("lcv", "afl_cio", "heritage_action", "humane_world_action", "nea", "c4ip", "afp", "ijm")


def get_adapter(name: str):
    if name not in ADAPTERS:
        raise ScorecardSourceError("Unknown scorecard publisher adapter")
    module = "humane" if name == "humane_world_action" else name
    return import_module(f"spicy_docs.sources.scorecards.{module}")


__all__ = [
    "ADAPTERS",
    "ScorecardAcquisition",
    "ScorecardContext",
    "ScorecardEdition",
    "ScorecardSourceError",
    "get_adapter",
    "validate_scorecard_bundle",
]
