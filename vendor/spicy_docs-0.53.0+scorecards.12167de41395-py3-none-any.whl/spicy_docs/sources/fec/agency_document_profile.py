"""Additional retained agency document representations, keeping existing native-report release pins stable."""

from __future__ import annotations

import hashlib
import io
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import replace
from functools import cache
from urllib.parse import urlsplit

from rulespec_artifacts import schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage
from spicy_docs.sources.agency_reports.flat_opc import parse_word_flat_opc
from spicy_docs.sources.agency_reports.foia import parse_foia_annual_report
from spicy_docs.sources.fec import agency_profile as native
from spicy_docs.sources.fec.catalog import official_url
from spicy_docs.sources.fec.delimited import selected_stream
from spicy_docs.sources.fec.originals import original_capture

SCHEMA_NAME = "fec-agency-document-record"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
SCOPE_ID = "fec-retained-agency-documents"
MAX_MEMBERS = 256


def _foia_url(url):
    if not isinstance(url, str) or len(url) > 16 * 1024:
        raise ValueError("FOIA archive URL is invalid")
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "www.foia.gov"
        or parsed.port not in (None, 443)
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("FOIA archive requires its credential-free official HTTPS URL")
    return url


def agency_document_scope(
    capture,
    *,
    format,
    member=None,
    max_records_per_page=1000,
    max_record_bytes=native.MAX_RECORD_BYTES,
    max_decoded_bytes=native.MAX_DECODED_BYTES,
):
    """Select either one FOIA.gov ZIP member or a distinct FEC Word Flat OPC original."""
    if format not in {"foia-zip-member", "word-flat-opc"}:
        raise ValueError("select a supported agency document format")
    capture = original_capture(capture, validate_url=_foia_url if format == "foia-zip-member" else official_url)
    for value, maximum in (
        (max_records_per_page, 1000),
        (max_record_bytes, native.MAX_RECORD_BYTES),
        (max_decoded_bytes, native.MAX_DECODED_BYTES),
    ):
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError("FEC agency document parsing bound is invalid")
    if capture["byteSize"] > max_decoded_bytes:
        raise ValueError("FEC agency document exceeds its byte bound")
    if format == "foia-zip-member":
        if (
            capture["representation"] != "zip"
            or not isinstance(member, Mapping)
            or set(member) != {"ordinal", "name"}
            or type(member["ordinal"]) is not int
            or not 0 <= member["ordinal"] < MAX_MEMBERS
            or not isinstance(member["name"], str)
            or not member["name"]
            or len(member["name"].encode()) > 65535
        ):
            raise ValueError("FOIA ZIP document requires an exact member ordinal and name")
        member = dict(member)
    elif capture["representation"] != "opaque" or member is not None:
        raise ValueError("Word Flat OPC requires an opaque original without a ZIP member")
    return {
        "capture": capture,
        "format": format,
        "member": member,
        "max_records_per_page": max_records_per_page,
        "max_record_bytes": max_record_bytes,
        "max_decoded_bytes": max_decoded_bytes,
    }


def _scope(value):
    if not isinstance(value, Mapping) or set(value) != {
        "capture",
        "format",
        "member",
        "max_records_per_page",
        "max_record_bytes",
        "max_decoded_bytes",
    }:
        raise ValueError("FEC agency document scope fields differ")
    return agency_document_scope(**dict(value))


def iter_retained_agency_documents(scope, *, blob_source):
    capture = _scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, native._key(0), capture["responseSha256"], capture["byteSize"], blob_source, "application/octet-stream"
    )


def _records(raw, scope):
    capture = scope["capture"]
    if scope["format"] == "foia-zip-member":
        with selected_stream(
            io.BytesIO(raw),
            capture=capture,
            member=scope["member"],
            max_members=MAX_MEMBERS,
            max_decoded_bytes=scope["max_decoded_bytes"],
        ) as (stream, member, digest):
            decoded = stream.read(scope["max_decoded_bytes"] + 1)
        if "sha256:" + hashlib.sha256(decoded).hexdigest() != digest:
            raise ValueError("FOIA selected member digest differs")
        parsed = parse_foia_annual_report(decoded, max_bytes=scope["max_decoded_bytes"])
        yield {
            "kind": "foia-report",
            "report": {"source": parsed["source"], "metadata": parsed["metadata"]},
            "archive": {"sha256": capture["responseSha256"], "member": member},
        }
        for ordinal, element in enumerate(parsed["elements"]):
            yield {"kind": "foia-element", "ordinal_in_report": ordinal, "element": element}
    else:
        parsed = parse_word_flat_opc(raw, max_bytes=scope["max_decoded_bytes"])
        yield {"kind": "word-report", "report": {"source": parsed["source"], "metadata": parsed["metadata"]}}
        for label, values in (("part", parsed["parts"]), ("element", parsed["elements"]), ("body", parsed["bodies"])):
            for ordinal, value in enumerate(values):
                yield {"kind": "word-" + label, "ordinal_in_report": ordinal, label: value}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = _scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        native._key(0),
        capture["responseSha256"],
        capture["byteSize"],
        "application/octet-stream",
    ):
        raise ValueError("FEC agency document differs from the selected capture")
    raw = stream.read(scope["max_decoded_bytes"] + 1)
    if len(raw) != byte_size or "sha256:" + hashlib.sha256(raw).hexdigest() != evidence_ref:
        raise ValueError("FEC agency document bytes differ from the selected capture")
    yield from native._record_pages(
        _records(raw, scope),
        scope=scope,
        evidence_ref=evidence_ref,
        identity_prefix=_identity_prefix(scope),
        member=scope["member"],
    )


def _identity_prefix(scope):
    prefix = scope["capture"]["responseSha256"]
    return prefix + f"/member/{scope['member']['ordinal']:06d}" if scope["member"] is not None else prefix


def _validate_record(record, *, query_scope, page_window):
    if (
        record["format"] != query_scope["format"]
        or record["id"] != f"{_identity_prefix(query_scope)}/{record['ordinal']:020d}"
        or record.get("member") != query_scope["member"]
    ):
        raise ValueError("FEC agency document coordinates differ from selected original/member")


_SCHEMA = deepcopy(native._SCHEMA)
_SCHEMA["$id"] = f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0"
_SCHEMA["properties"]["format"]["enum"] = ["foia-zip-member", "word-flat-opc"]
_SCHEMA["properties"]["member"] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["ordinal", "name"],
    "properties": {"ordinal": {"type": "integer", "minimum": 0}, "name": {"type": "string"}},
}


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


FEC_AGENCY_DOCUMENT_PROFILE = replace(
    native.FEC_AGENCY_REPORT_PROFILE,
    name="Retained FEC agency document representations",
    source_system_id="urn:spicy-docs:source:fec-agency-documents",
    acquisition_policy_id="urn:spicy-docs:acquisition:fec-agency-documents",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="fec-agency-document-record",
    validate_query_scope=_scope,
    parse_file_stream=_parse_file,
    validate_record_scope=_validate_record,
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "maxPageBytes": native.MAX_PAGE_BYTES,
        "coverageLimits": [
            "One selected retained original/member; no archive-wide or current agency coverage.",
            "FOIA ZIP membership is selected by exact ordinal and name after complete bounded archive verification.",
            "Word Flat OPC retains every XML element, part and native text/control token; it is not NIEM FOIA statistics or rendered Word content.",
            "No relationships, revisions, totals or visual fidelity are inferred; linked originals are never fetched.",
        ],
    },
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": row["id"],
    },
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
)

__all__ = ["FEC_AGENCY_DOCUMENT_PROFILE", "agency_document_scope", "iter_retained_agency_documents"]
