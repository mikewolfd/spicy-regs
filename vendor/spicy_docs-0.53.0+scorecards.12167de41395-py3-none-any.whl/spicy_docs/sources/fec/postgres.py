"""Decode one retained FEC committee-history archive through PostgreSQL's pg_restore.

The tool only writes SQL text. No SQL is executed and no database is opened.
Native COPY fields and decoded text/null values survive independently; arrays and
SQL scalar types remain publisher text rather than inferred Python values.
"""

from __future__ import annotations

import hashlib
import re
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory, TemporaryFile

from spicy_docs.sources.fec.originals import original_capture

TABLE = "disclosure.ofec_committee_history"
MAX_SQL_BYTES = 2 * 1024**3
MAX_METADATA_BYTES = 1024**2
MAX_RECORD_BYTES = 128 * 1024
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
_IDENTIFIER = re.compile(r"[a-z_][a-z_0-9]*")
_TYPE = re.compile(
    r"(?:bigint|integer|boolean|text|tsvector|date|timestamp without time zone|numeric\(\d+,\d+\)|character varying(?:\(\d+\))?)(?:\[\])?"
)


def _pin(path):
    digest, size = hashlib.sha256(), 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024**2):
            digest.update(chunk)
            size += len(chunk)
    return {"sha256": "sha256:" + digest.hexdigest(), "byteSize": size}


def postgres_capture(capture):
    """Require the selected native table's exact official object route."""
    capture = original_capture(capture)
    suffix = "/bulk-downloads/data-dump/schedules/ofec_committee_history.dump"
    if capture["representation"] != "opaque" or not capture["requestUrl"].endswith(suffix):
        raise ValueError("FEC PostgreSQL reader requires the committee-history dump")
    if capture.get("resolvedUrl", capture["requestUrl"]) != capture["requestUrl"]:
        raise ValueError("FEC PostgreSQL resolved object differs from its selection")
    return capture


def _run(arguments, output, *, limit):
    # A bounded pipe avoids loading the SQL in memory or expanding it past the
    # selected disk budget. stderr uses a file so it cannot deadlock stdout.
    with TemporaryFile() as errors:
        process = subprocess.Popen(["pg_restore", *arguments], stdout=subprocess.PIPE, stderr=errors)
        try:
            size = 0
            with output.open("xb") as target:
                while chunk := process.stdout.read(1024**2):
                    size += len(chunk)
                    if size > limit:
                        raise ValueError("FEC PostgreSQL decoded output exceeds its byte bound")
                    target.write(chunk)
            if process.wait() != 0:
                raise ValueError("pg_restore refused the retained FEC archive")
            errors.seek(0)
            if errors.read(1):
                raise ValueError("pg_restore reported diagnostics for the retained FEC archive")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            process.stdout.close()


def schema_columns(raw):
    """Read only the simple native table declaration emitted for the supported archive.

    This is a deliberately narrow pg_restore-output reader, not a SQL parser.
    Constraints, expressions and types outside the supported native shape refuse.
    """
    if len(raw) > MAX_METADATA_BYTES:
        raise ValueError("FEC PostgreSQL schema exceeds its byte bound")
    text = raw.decode("utf-8")
    starts = re.findall(r"^CREATE TABLE (\S+) \($", text, re.MULTILINE)
    if starts != [TABLE]:
        raise ValueError("FEC PostgreSQL schema does not contain the one selected table")
    match = re.search(r"^CREATE TABLE " + re.escape(TABLE) + r" \(\n(.*?)\n\);$", text, re.MULTILINE | re.DOTALL)
    if match is None:
        raise ValueError("FEC PostgreSQL table declaration is incomplete")
    columns = []
    for line in match[1].splitlines():
        name, separator, sql_type = line.strip().removesuffix(",").partition(" ")
        if not separator or _IDENTIFIER.fullmatch(name) is None or _TYPE.fullmatch(sql_type) is None:
            raise ValueError("FEC PostgreSQL column declaration is unsupported")
        columns.append({"name": name, "sql_type": sql_type})
    if not columns or len(columns) > 1000 or len({x["name"] for x in columns}) != len(columns):
        raise ValueError("FEC PostgreSQL column names are empty or repeated")
    return columns


def decoder_arguments(original_sha256):
    """The one non-executing pg_restore command selection for this supported table."""
    common = [
        "--no-owner",
        "--no-privileges",
        "--strict-names",
        "--schema=disclosure",
        "--table=ofec_committee_history",
        "--restrict-key=" + original_sha256.removeprefix("sha256:"),
        "--file=-",
    ]
    return {"toc": ["--list"], "schema": ["--schema-only", *common], "data": ["--data-only", *common]}


def derive_postgres_table(stream, *, capture, output_directory, max_decoded_bytes=MAX_SQL_BYTES):
    """Retain deterministic schema, TOC and SQL outputs with exact original/tool pins.

    ``output_directory`` must be a new directory. The original is copied only to
    temporary scratch for pg_restore; its digest and complete size are checked
    before invoking the tool. A failed directory is evidence, not a completed
    derivation. Only a returned receipt establishes completion.
    """
    capture = postgres_capture(capture)
    if type(max_decoded_bytes) is not int or not 1 <= max_decoded_bytes <= MAX_SQL_BYTES:
        raise ValueError("FEC PostgreSQL decoded byte bound is invalid")
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=False)
    version = (
        subprocess.run(["pg_restore", "--version"], check=True, capture_output=True, timeout=30).stdout.decode().strip()
    )
    if not version.startswith("pg_restore (PostgreSQL) ") or len(version) > 1024:
        raise ValueError("FEC PostgreSQL decoder version is unrecognized")
    with TemporaryDirectory() as temporary:
        archive = Path(temporary) / "original.dump"
        digest, size = hashlib.sha256(), 0
        with archive.open("xb") as target:
            while chunk := stream.read(min(1024**2, capture["byteSize"] - size + 1)):
                size += len(chunk)
                if size > capture["byteSize"]:
                    raise ValueError("FEC PostgreSQL original exceeds its captured size")
                digest.update(chunk)
                target.write(chunk)
        if size != capture["byteSize"] or "sha256:" + digest.hexdigest() != capture["responseSha256"]:
            raise ValueError("FEC PostgreSQL original differs from its captured bytes")
        # pg_restore normally randomizes a psql guard token. A source-derived
        # token makes retained text reproducible; the output is never executed.
        commands = decoder_arguments(capture["responseSha256"])
        pins = {}
        for kind, arguments in commands.items():
            path = output / (kind + (".txt" if kind == "toc" else ".sql"))
            _run([*arguments, str(archive)], path, limit=max_decoded_bytes if kind == "data" else MAX_METADATA_BYTES)
            pins[kind] = _pin(path)
    columns = schema_columns((output / "schema.sql").read_bytes())
    return {
        "table": TABLE,
        "toolVersion": version,
        "arguments": commands,
        "originalSha256": capture["responseSha256"],
        "outputs": pins,
        "columns": columns,
    }


def validate_derivation(value, *, capture):
    """Validate the small reproducibility receipt carried by the selected scope."""
    if not isinstance(value, dict) or set(value) != {
        "table",
        "toolVersion",
        "arguments",
        "originalSha256",
        "outputs",
        "columns",
    }:
        raise ValueError("FEC PostgreSQL derivation fields differ")
    if value["arguments"] != decoder_arguments(capture["responseSha256"]):
        raise ValueError("FEC PostgreSQL decoder arguments differ")
    if value["table"] != TABLE or value["originalSha256"] != capture["responseSha256"]:
        raise ValueError("FEC PostgreSQL derivation differs from its selected original/table")
    if (
        not isinstance(value["toolVersion"], str)
        or not value["toolVersion"].startswith("pg_restore (PostgreSQL) ")
        or len(value["toolVersion"]) > 1024
    ):
        raise ValueError("FEC PostgreSQL tool version is invalid")
    if not isinstance(value["outputs"], dict) or set(value["outputs"]) != {"toc", "schema", "data"}:
        raise ValueError("FEC PostgreSQL derived output pins differ")
    for name, pin in value["outputs"].items():
        bound = MAX_SQL_BYTES if name == "data" else MAX_METADATA_BYTES
        if (
            not isinstance(pin, dict)
            or set(pin) != {"sha256", "byteSize"}
            or not isinstance(pin["sha256"], str)
            or _DIGEST.fullmatch(pin["sha256"]) is None
            or type(pin["byteSize"]) is not int
            or not 0 < pin["byteSize"] <= bound
        ):
            raise ValueError("FEC PostgreSQL derived output pin is invalid")
    columns = value["columns"]
    if not isinstance(columns, list) or not 1 <= len(columns) <= 1000:
        raise ValueError("FEC PostgreSQL native column list is invalid")
    for column in columns:
        if (
            not isinstance(column, dict)
            or set(column) != {"name", "sql_type"}
            or not isinstance(column["name"], str)
            or _IDENTIFIER.fullmatch(column["name"]) is None
            or not isinstance(column["sql_type"], str)
            or _TYPE.fullmatch(column["sql_type"]) is None
        ):
            raise ValueError("FEC PostgreSQL native column is invalid")
    if len({x["name"] for x in columns}) != len(columns):
        raise ValueError("FEC PostgreSQL native column names repeat")
    return value


def decode_copy_field(raw):
    """Decode PostgreSQL COPY text escapes, preserving NULL separately from empty text."""
    if raw == b"\\N":
        return None
    output = bytearray()
    index = 0
    escapes = {ord(k): v for k, v in zip("bfnrtv", (8, 12, 10, 13, 9, 11), strict=True)}
    while index < len(raw):
        char = raw[index]
        index += 1
        if char != 92:
            output.append(char)
            continue
        if index == len(raw):
            raise ValueError("FEC PostgreSQL COPY field ends with an incomplete escape")
        char = raw[index]
        index += 1
        if char in b"01234567":
            digits = bytes([char])
            while len(digits) < 3 and index < len(raw) and raw[index] in b"01234567":
                digits += bytes([raw[index]])
                index += 1
            output.append(int(digits, 8) & 255)
        elif char == ord("x") and index < len(raw) and raw[index] in b"0123456789abcdefABCDEF":
            digits = bytes([raw[index]])
            index += 1
            if index < len(raw) and raw[index] in b"0123456789abcdefABCDEF":
                digits += bytes([raw[index]])
                index += 1
            output.append(int(digits, 16))
        else:
            output.append(escapes.get(char, char))
    if 0 in output:
        raise ValueError("FEC PostgreSQL text field contains a NUL byte")
    return output.decode("utf-8")


def postgres_copy_rows(stream, *, derivation, max_record_bytes=MAX_RECORD_BYTES):
    """Read one complete pinned pg_restore text stream; exhaust to establish success.

    The raw fields keep COPY escapes. Values decode only those escapes and SQL
    NULL; arrays, dates, numbers, booleans and tsvector values stay text. Coordinates
    refer to the derived SQL bytes, whose pin is distinct from the archive's pin.
    """
    if type(max_record_bytes) is not int or not 1 <= max_record_bytes <= MAX_RECORD_BYTES:
        raise ValueError("FEC PostgreSQL row byte bound is invalid")
    names = [x["name"] for x in derivation["columns"]]
    expected_header = f"COPY {TABLE} ({', '.join(names)}) FROM stdin;\n".encode()
    pin = derivation["outputs"]["data"]
    digest, offset, active, ended, utf8 = hashlib.sha256(), 0, False, False, False
    while line := stream.readline(max_record_bytes + 1):
        start = offset
        offset += len(line)
        if len(line) > max_record_bytes or offset > pin["byteSize"]:
            raise ValueError("FEC PostgreSQL SQL stream exceeds its byte bound")
        digest.update(line)
        if not line.endswith(b"\n"):
            raise ValueError("FEC PostgreSQL SQL stream ends with an incomplete line")
        if not active:
            if line.startswith(b"COPY "):
                if ended or not utf8 or line != expected_header:
                    raise ValueError("FEC PostgreSQL COPY table, columns or encoding differ")
                active = True
            elif line.startswith(b"SET client_encoding"):
                if line != b"SET client_encoding = 'UTF8';\n" or utf8:
                    raise ValueError("FEC PostgreSQL COPY encoding differs")
                utf8 = True
            continue
        if line == b"\\.\n":
            active, ended = False, True
            continue
        raw = line[:-1].split(b"\t")
        if len(raw) != len(names):
            raise ValueError("FEC PostgreSQL COPY row width differs from native schema")
        yield {
            "kind": "postgres-copy",
            "fields": [cell.decode("utf-8") for cell in raw],
            "values": [decode_copy_field(cell) for cell in raw],
            "source": {
                "sha256": pin["sha256"],
                "byte_offset": start,
                "byte_length": len(line),
                "encoding": "utf-8",
                "table": TABLE,
                "original_sha256": derivation["originalSha256"],
            },
        }
    if not ended or active:
        raise ValueError("FEC PostgreSQL COPY stream is missing or unterminated")
    if offset != pin["byteSize"] or "sha256:" + digest.hexdigest() != pin["sha256"]:
        raise ValueError("FEC PostgreSQL derived SQL differs from its retained pin")
