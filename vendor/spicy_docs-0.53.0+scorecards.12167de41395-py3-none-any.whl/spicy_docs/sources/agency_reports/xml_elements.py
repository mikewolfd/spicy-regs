"""Literal XML element observations shared by agency report and document readers."""

from spicy_docs.reading.xml import scan_xml


def xml_elements(body, *, max_bytes, max_elements, error_type, label, validate_root=None):
    """Preserve ordered expanded names, attributes, namespace declarations, text and tails."""
    if type(max_elements) is not int or max_elements <= 0:
        raise error_type("max_elements must be a positive integer")
    rows: list[dict] = []
    stack: list[dict] = []
    declarations: dict[str, str] = {}

    def start(tag: str, attributes: dict[str, str]) -> None:
        if len(rows) >= max_elements:
            raise error_type(f"{label} exceeds max_elements")
        parent = stack[-1] if stack else None
        if parent is None and validate_root is not None:
            validate_root(tag)
        path = [] if parent is None else [*rows[parent["index"]]["child_indices"], parent["children"]]
        if parent is not None:
            parent["children"] += 1
        index = len(rows)
        rows.append(
            {
                "child_indices": path,
                "parent": None if parent is None else parent["index"],
                "tag": tag,
                "attributes": attributes,
                "namespace_declarations": dict(declarations),
                "text": [],
                "tail": [],
            }
        )
        declarations.clear()
        stack.append({"index": index, "children": 0, "last_child": None})

    def end(_tag: str) -> None:
        frame = stack.pop()
        if stack:
            stack[-1]["last_child"] = frame["index"]

    def data(text: str) -> None:
        if stack:
            frame = stack[-1]
            child = frame["last_child"]
            rows[frame["index"] if child is None else child]["text" if child is None else "tail"].append(text)

    scan_xml(
        body,
        start=start,
        end=end,
        data=data,
        namespace=declarations.__setitem__,
        max_bytes=max_bytes,
        max_depth=64,
        error_type=error_type,
        label=label,
    )
    for row in rows:
        for key in ("text", "tail"):
            row[key] = "".join(row[key]) if row[key] else None
    return rows
