"""AFSCME's original app data, read as literals without executing JavaScript.

The source defines chamber-specific items, including nominations and a combined
vote item. It supplies Bioguide IDs but no roll numbers or explicit Congress.
"""

import json
import re
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
    validate_url,
)

parser_version = "afscme-app-literals/1"
INDEX = "https://scorecard.afscme.org/"
HOSTS = ("scorecard.afscme.org",)
EDITION = ScorecardEdition("afscme", "2025-2026", INDEX, "AFSCME Legislative Scorecard", chamber="both")
CHAMBERS = ("House", "Senate")
ITEM_FIELDS = {"slug", "nickname", "title", "excerpt", "description", "outcome", "date", "afscme", "class"}
MEMBER_FIELDS = {"firstName", "lastName", "state", "party", "score", "bioguide_id", "fotoUrl"}
JSON_DECODER = json.JSONDecoder()


def _unique_fields(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ScorecardSourceError("AFSCME literal repeats an object field")
        result[name] = value
    return result


def _json(text):
    try:
        return json.loads(text, object_pairs_hook=_unique_fields)
    except ScorecardSourceError:
        raise
    except ValueError as error:
        raise ScorecardSourceError("AFSCME embedded JSON is incomplete") from error


def _single_string(text, start):
    """Decode the observed JS string syntax only; no source code evaluation."""
    if text[start] != "'":
        raise ScorecardSourceError("AFSCME member export string syntax changed")
    result, position = [], start + 1
    escapes = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "v": "\v"}
    while position < len(text):
        character = text[position]
        if character == "'":
            return "".join(result), position + 1
        if character in "\r\n":
            raise ScorecardSourceError("AFSCME member string contains a source line break")
        if character != "\\":
            result.append(character)
            position += 1
            continue
        position += 1
        if position >= len(text):
            break
        escape = text[position]
        if escape in "'\"\\/":
            result.append(escape)
        elif escape in escapes:
            result.append(escapes[escape])
        elif escape in {"x", "u"}:
            size = 2 if escape == "x" else 4
            digits = text[position + 1 : position + 1 + size]
            if len(digits) != size or not re.fullmatch(r"[0-9A-Fa-f]+", digits):
                raise ScorecardSourceError("AFSCME member string has an invalid Unicode escape")
            result.append(chr(int(digits, 16)))
            position += size
        else:
            raise ScorecardSourceError("AFSCME member string introduces an unsupported escape")
        position += 1
    raise ScorecardSourceError("AFSCME member export does not close its string")


def _items(text, variable):
    starts = list(re.finditer(r"\b" + variable + r"\s*=\s*\[", text))
    if len(starts) != 1:
        raise ScorecardSourceError("AFSCME item array is missing or reassigned")
    position = starts[0].end()
    converted, depth = ["["], 1
    while position < len(text) and depth:
        character = text[position]
        if character == '"':
            try:
                value, end = JSON_DECODER.raw_decode(text[position:])
            except ValueError as error:
                raise ScorecardSourceError("AFSCME item text is not a complete JSON string") from error
            if not isinstance(value, str):
                raise ScorecardSourceError("AFSCME item string changed type")
            converted.append(text[position : position + end])
            position += end
            continue
        if character.isalpha() or character == "_":
            field = re.match(r"[A-Za-z_][A-Za-z_0-9]*", text[position:])
            if field is None or text[position + len(field[0]) :].lstrip()[:1] != ":":
                raise ScorecardSourceError("AFSCME item contains executable or unsupported syntax")
            converted.append(json.dumps(field[0]))
            position += len(field[0])
            continue
        if character == "[":
            depth += 1
        elif character == "]":
            depth -= 1
        if character not in "[]{}:, \r\n\t":
            raise ScorecardSourceError("AFSCME item contains a nonliteral value")
        converted.append(character)
        position += 1
    if depth:
        raise ScorecardSourceError("AFSCME item array does not close")
    items = _json("".join(converted))
    if not isinstance(items, list) or not items:
        raise ScorecardSourceError("AFSCME item array is empty or changed type")
    identifiers = set()
    for item in items:
        if (
            not isinstance(item, dict)
            or set(item) != ITEM_FIELDS
            or any(not isinstance(value, str) or not value for value in item.values())
            or item["afscme"] not in {"Y", "N"}
            or item["slug"] in identifiers
        ):
            raise ScorecardSourceError("AFSCME item fields or identities changed")
        identifiers.add(item["slug"])
    return items


def _index(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("AFSCME index does not reach HTML EOF")
    html = soup(document)
    if html.title is None or html.title.get_text(strip=True) != EDITION.title:
        raise ScorecardSourceError("AFSCME index title changed")
    scripts = [
        urljoin(INDEX, node["src"])
        for node in html.select("script[src]")
        if re.fullmatch(r"(?:\./)?dist/index-bundle\.[\d.]+\.js", node["src"])
    ]
    if len(scripts) != 1:
        raise ScorecardSourceError("AFSCME index does not select one original app bundle")
    validate_url(scripts[0], HOSTS)
    paragraphs = [node.get_text(" ", strip=True) for node in html.select(".header-intro > p")]
    paragraphs = [text for text in paragraphs if text]
    if len(paragraphs) != 2 or not paragraphs[0].startswith("AFSCME selects a few roll-call votes"):
        raise ScorecardSourceError("AFSCME selection methodology changed or is missing")
    states = [node["id"] for node in html.select("#change-state option[id]")]
    if not states or len(set(states)) != len(states) or any(not re.fullmatch(r"[A-Z]{2}", state) for state in states):
        raise ScorecardSourceError("AFSCME state selectors changed or repeat an identity")
    return scripts[0], paragraphs, set(states)


def _app(document, states):
    try:
        text = document.body.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ScorecardSourceError("AFSCME app is not UTF-8") from error
    if not text.rstrip().endswith("]);") or "a=i(7),n=i(8)" not in text:
        raise ScorecardSourceError("AFSCME app module closure or chamber binding changed")
    if not re.search(r'\.html\([A-Za-z_$][\w$]*\.score\+"%"\)', text):
        raise ScorecardSourceError("AFSCME app no longer states percent score presentation")
    exports = list(re.finditer(r"function\(t\)\{t\.exports=JSON\.parse\(", text))
    if len(exports) != 2:
        raise ScorecardSourceError("AFSCME app member module count changed")
    result, identifiers = {}, set()
    for chamber, export in zip(CHAMBERS, exports, strict=True):
        items = _items(text, chamber.lower() + "Votes")
        literal, end = _single_string(text, export.end())
        if text[end : end + 2] != ")}":
            raise ScorecardSourceError("AFSCME member module does not close after its literal")
        members = _json(literal)
        if not isinstance(members, list) or not members:
            raise ScorecardSourceError("AFSCME member array is empty or changed type")
        fields = MEMBER_FIELDS | {item["slug"] for item in items} | ({"district"} if chamber == "House" else set())
        for member in members:
            if (
                not isinstance(member, dict)
                or set(member) != fields
                or any(not isinstance(value, str) or not value for value in member.values())
                or not re.fullmatch(r"[A-Z]\d{6}", member["bioguide_id"])
                or member["bioguide_id"] in identifiers
                # The source app roster includes Puerto Rico although the
                # app's state selector omits it. Keep that explicit source row.
                or member["state"] not in states | {"PR"}
                or member["score"] != "--"
                and decimal_text(member["score"]) is None
                or any(member[item["slug"]] not in {"Y", "N", "DNV", "NIO"} for item in items)
                or chamber == "House"
                and not re.fullmatch(r"\d+", member["district"])
            ):
                raise ScorecardSourceError("AFSCME member identity, score or complete item grid changed")
            identifiers.add(member["bioguide_id"])
        result[chamber] = (items, members)
    years = {year for items, _ in result.values() for item in items for year in re.findall(r"\b20\d\d\b", item["date"])}
    if years != {"2025", "2026"}:
        raise ScorecardSourceError("AFSCME app source item years changed; select a reviewed edition scope")
    return result


def _references(item, path):
    references = []
    for field in ("slug", "title"):
        for index, match in enumerate(re.finditer(r"\b(?:H\.R\.|S\.)\s*\d+\b", item[field])):
            references.append(
                {
                    "occurrence_id": key(field, str(index)),
                    "kind": "bill",
                    "citation_text": match[0],
                    "bill_citation_text": match[0],
                    "source_path": path + "." + field,
                }
            )
    # One source-defined score includes two actions; neither is expanded into a
    # fabricated roll call. Retain the two literal date occurrences separately.
    if item["slug"] == "S.3012":
        for index, match in enumerate(re.finditer(r"October 23|November 7, 2025", item["description"])):
            references.append(
                {
                    "occurrence_id": key("action-date", str(index)),
                    "kind": "action_date",
                    "citation_text": match[0],
                    "source_path": path + ".description",
                }
            )
    return references


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    index = context.read(INDEX, stage="scorecards:afscme:listing", hosts=HOSTS)
    url, _, states = _index(index)
    _app(context.read(url, stage="scorecards:afscme:listing-app", hosts=HOSTS), states)
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("AFSCME reader supports the reviewed 2025-2026 app source set")
    index = context.read(INDEX, stage="scorecards:afscme:index", hosts=HOSTS)
    url, methods, states = _index(index)
    primary = context.read(url, stage="scorecards:afscme:app", hosts=HOSTS)
    source = _app(primary, states)
    repeated_index = context.read(INDEX, stage="scorecards:afscme:index-reread", hosts=HOSTS)
    if _index(repeated_index) != (url, methods, states):
        raise ScorecardSourceError("AFSCME index facts changed during acquisition")
    repeated = context.read(url, stage="scorecards:afscme:app-reread", hosts=HOSTS)
    if _app(repeated, states) != source:
        raise ScorecardSourceError("AFSCME member scores or item definitions changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="American Federation of State, County and Municipal Employees",
        parser_version=parser_version,
        rendition_rule="afscme-original-linked-app-literals/1",
        homepage="https://www.afscme.org/",
    )
    bundle.use(primary, "members_scores_items_and_results")
    bundle.use(repeated, "edition", "members_scores_items_and_results", role="corroboration")
    bundle.use(index, "selection_methodology")
    bundle.use(repeated_index, "selection_methodology", role="corroboration")
    bundle.tables["scorecards"][0].update(publisher_edition_key=None, edition_label_text=None)
    for position, method in enumerate(methods, 1):
        bundle.add(
            "scorecard_methodologies",
            index,
            f"(//div[contains(concat(' ', normalize-space(@class), ' '), ' header-intro ')]/p[normalize-space(translate(., '\u00a0', ' '))])[{position}]",
            methodology_id=key("selection", str(position)),
            methodology_text=method,
            methodology_url=INDEX,
            disclosure_status="partial",
        )
    for export, (chamber, (items, members)) in enumerate(source.items()):
        metric_id = key(chamber, "score")
        bundle.metric(
            primary,
            metric_id,
            "score",
            path=f"JavaScript/JSON.parse-export[{export}]/$[*].score",
            chamber=chamber,
            unit="percent",
        )
        bundle.tables["scorecard_metrics"][-1]["methodology_id"] = "selection:1"
        for position, item in enumerate(items):
            path = f"JavaScript/{chamber.lower()}Votes[{position}]"
            item_id = key(chamber, item["slug"])
            methodology_id = key(item_id, "source-definition")
            citation = item["slug"] if re.fullmatch(r"(?:H\.R\.|S\.)\d+", item["slug"]) else None
            # The frozen item table has no description/outcome fields. This
            # source-located definition retains every literal presentation
            # field alongside the item's participation rule.
            bundle.add(
                "scorecard_methodologies",
                primary,
                path,
                methodology_id=methodology_id,
                methodology_text=json_column(item),
                methodology_url=url,
                disclosure_status="partial",
            )
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=item_id,
                publisher_item_id=item["slug"],
                title=item["title"],
                item_kind_text="Nomination" if "Nomination" in item["title"] else "roll-call votes",
                item_date_text=item["date"],
                chamber_text=chamber,
                bill_citation_text=citation,
                publisher_position_text=item["afscme"],
                position_basis="explicit",
                position_source_path=path + ".afscme",
                references_json=json_column(_references(item, path)),
            )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id=metric_id,
                item_id=item_id,
                participation_id="app-column",
                methodology_id=methodology_id,
                counts_toward_metric="true",
                publisher_position_text=item["afscme"],
                position_basis="explicit",
            )
        for position, member in enumerate(members):
            path = f"JavaScript/JSON.parse-export[{export}]/$[{position}]"
            identifier = key(chamber, member["bioguide_id"])
            bundle.add(
                "scorecard_members",
                primary,
                path,
                publisher_member_key=identifier,
                member_name=member["firstName"] + " " + member["lastName"],
                state=member["state"],
                district=member.get("district"),
                party=member["party"],
                chamber_text=chamber,
                identifiers_json=json_column([{"scheme": "bioguide", "value": member["bioguide_id"]}]),
                notes_text=json_column({field: member[field] for field in ("firstName", "lastName", "fotoUrl")}),
            )
            bundle.add(
                "scorecard_member_ratings",
                primary,
                path + '["score"]',
                metric_id=metric_id,
                publisher_member_key=identifier,
                value_text=member["score"],
                value_number=decimal_text(member["score"]),
            )
            for item in items:
                bundle.add(
                    "scorecard_member_item_results",
                    primary,
                    path + "[" + json.dumps(item["slug"]) + "]",
                    item_id=key(chamber, item["slug"]),
                    publisher_member_key=identifier,
                    result_id="app-column",
                    metric_id=metric_id,
                    participation_id="app-column",
                    result_text=member[item["slug"]],
                    action_text=member[item["slug"]],
                )
    result = bundle.finish(
        "Original HTML and linked app reach EOF; both complete JSON member exports and every item literal parsed; "
        "Bioguide identities unique; every member has every chamber item result; state identifiers checked, "
        "including the publisher roster's Puerto Rico row outside its state selector; "
        "full index and app facts agree on stable reread",
        declared={
            "member_array_lengths": {chamber: len(members) for chamber, (_, members) in source.items()},
            "item_array_lengths": {chamber: len(items) for chamber, (items, _) in source.items()},
            "count_basis": "complete original app arrays, not an inferred official roster",
            "roster_states_outside_selector": sorted(
                {member["state"] for _, members in source.values() for member in members} - states
            ),
        },
    )
    result.tables["scorecard_snapshots"][0]["identity_rule_version"] = parser_version + ":observed-item-years-edition/1"
    return result
