"""Alliance for Retired Americans' complete 2025 congressional voting record."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "ara-2025-qualified-semantic/1"
HOSTS = ("retiredamericans.org",)
URL = "https://retiredamericans.org/wp-content/uploads/2026/03/2025-Congressional-Voting-Record.pdf"
SOURCE_SHA256 = "6fba0764b41272875fc1561c81d8131297a0e967cf857fef02e9bec281a2720c"
QUALIFIED_SHA256 = "7f5c48baebd21cf8e668060edd9ab1171c45f9f744987ecb4b9b7bde2be9a6a7"
EDITION = ScorecardEdition(
    "ara",
    "119-2025",
    URL,
    "Congressional Voting Record: 119th Congress, 1st Session",
    congress="119",
    year="2025",
    chamber="both",
)
PAGE_MEMBERS = {4: 48, 5: 52, 7: 82, 8: 85, 9: 79, 10: 89, 11: 87, 12: 13}
ITEM_KEYS = tuple(str(i) for i in range(1, 11))
TOKENS = {"✓", "✗", "?", "O", "S", "P", "—", "–", ""}


@dataclass(frozen=True, slots=True)
class ARAReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:ara:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("ARA qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "ara-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 12
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            chamber = "Senate" if page < 6 else "House"
            if (
                page not in counts
                or page < previous
                or not all(
                    isinstance(record[f], str) and record[f] for f in ("member_name_text", "state_text", "party_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or (chamber == "House" and re.fullmatch(r"AL|\d+", record["district_text"] or "") is None)
                or set(record["results"]) != set(ITEM_KEYS)
                or any(v not in TOKENS for v in record["results"].values())
                or any(
                    re.fullmatch(r"\d{1,3}", record[f]) is None or int(record[f]) > 100
                    for f in ("annual_score_text", "lifetime_score_text")
                )
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        if counts != PAGE_MEMBERS or [m["evidence"]["physical_page"] for m in data["methodology"]] != [2, 12]:
            raise ValueError
        expected = {(c, k) for c in ("Senate", "House") for k in ITEM_KEYS}
        if (
            len(data["items"]) != 20
            or {(e["chamber"], e["record"]["publisher_item_key_text"]) for e in data["items"]} != expected
        ):
            raise ValueError
        for entry in data["items"]:
            item = entry["record"]
            if (
                not item["title_text"]
                or not item["item_kind_text"]
                or not item["item_date_text"]
                or item["publisher_position_text"]
                not in {"A YES vote is the pro-retiree vote.", "A NO vote is the pro-retiree vote."}
                or re.fullmatch(r"\d+", item["roll_number_text"]) is None
                or not item["source_pages"]
                or any(p not in (3, 4, 6, 7) for p in item["source_pages"])
            ):
                raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("ARA semantic facts fail the complete qualified edition shape") from None


def _references(item, loc):
    """Retain each literal amendment in a chain rather than selecting one."""
    occurrences = []
    for kind, field_name, pattern in (
        ("bill", "bill_citation_text", r".+"),
        ("amendment", "amendment_citation_text", r"[SH]\.\s*Amdt\.\s*\d+"),
    ):
        for match in re.finditer(pattern, item[field_name] or ""):
            text = match.group()
            nomination = kind == "bill" and re.fullmatch(r"PN\s+\d+(?:-\d+)?", text) is not None
            occurrence = {
                "occurrence_id": str(len(occurrences)),
                "citation_text": text,
                "kind": "nomination" if nomination else kind,
                "source_path": loc + "/" + field_name,
            }
            if not nomination:
                occurrence[field_name] = text
            occurrences.append(occurrence)
    return json.dumps(occurrences, ensure_ascii=False)


def acquire_scorecard(edition, context: ScorecardContext, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("ARA edition requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:ara:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="ara:qualified-2025",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Alliance for Retired Americans",
        parser_version=parser_version,
        rendition_rule="ara-complete-source-member-actions-and-scores/1",
        homepage="https://retiredamericans.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        record = entry["record"]
        text = (
            record["methodology_text"]
            + "\n"
            + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in record["legend"])
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}/record"),
            methodology_id=f"source-page-{entry['evidence']['physical_page']}",
            methodology_text=text,
            methodology_url=URL,
            disclosure_status="partial: published result legend and position headers",
        )
    for chamber, page in (("Senate", 4), ("House", 7)):
        for metric, label, period in (
            ("annual", "Pro-Retiree Score ’25", "January 2025 — December 2025"),
            ("lifetime", "Lifetime Score", "Lifetime"),
        ):
            bundle.add(
                "scorecard_metrics",
                source,
                path(page, "/score-headings"),
                metric_id=key(chamber, metric),
                name=label,
                chamber_text=chamber,
                period_text=period,
                value_unit_text="percent",
                is_primary="true" if metric == "annual" else "false",
            )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        item_id = key(chamber, item["publisher_item_key_text"])
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=item["publisher_item_key_text"],
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=chamber,
            congress_text="119",
            session_text="1",
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=None
            if (item["bill_citation_text"] or "").startswith("PN ")
            else item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "annual"),
            item_id=item_id,
            participation_id="annual-2025",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-2",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "Senate" if page < 6 else "House"
        identity = key(
            chamber, record["state_text"], record["member_name_text"], record["district_text"] or "no-district"
        )
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            party=record["party_text"],
            district=record["district_text"],
            chamber_text=chamber,
        )
        for metric in ("annual", "lifetime"):
            value = record[f"{metric}_score_text"]
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + f"/{metric}_score_text",
                metric_id=key(chamber, metric),
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value),
            )
        for action, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + action,
                item_id=key(chamber, action),
                metric_id=key(chamber, "annual"),
                participation_id="annual-2025",
                publisher_member_key=identity,
                result_id="published-chart",
                result_text=value,
            )
    return bundle.finish(
        "Complete original 2025 report: exact source/observation hashes and every member-page count reconcile; all annual/lifetime scores and ten actions per member match the original. Source surname-only identities, eligibility and missed-vote glyphs remain literal. The contradictory final House preferred-position header is retained; item targets use explicit source narratives. No lifetime item ledger or universal reproduction formula is invented."
    )
