"""Complete original Club for Growth HTML ratings; PDF item details are separate."""

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "club-for-growth-complete-html/1"
INDEX = "https://www.clubforgrowth.org/scorecards/"
METHOD = INDEX + "2025-scorecard-methodology/"
HOSTS = ("www.clubforgrowth.org",)
CHAMBERS = {"house": ("H", "House"), "senate": ("S", "Senate")}
EDITION = ScorecardEdition(
    "club_for_growth", "2025", INDEX, "Club for Growth Foundation Scorecard", year="2025", chamber="both"
)
URLS = {
    name: INDEX + f"app/?party=all&chamber={letter}&yr=2025&state=all&rep" for name, (letter, _) in CHAMBERS.items()
}
PDFS = {
    name: "https://www.clubforgrowth.org/wp-content/uploads/securepdfs/2026/06/2025-U.S.-"
    + title
    + "-Scorecard-Final.pdf"
    for name, (_, title) in CHAMBERS.items()
}
HEADERS = ["State", "Dist", "Party", "Name", "Rank", "Score", "Lifetime", "Details"]
WEIGHT_PARSER_VERSION = "club-for-growth-html-and-qualified-weights/1"
CROSSWALK_SHA256 = "cf572fdea261673a3e97b83019dc2e7388c80b5acb4a47b70929f8a056aed12b"
SOURCE_SHA256 = {
    "house": "bb0d7682816427d77caa7c22f266c82d121dbb5ee2ee53c3be1cd5a183b5524a",
    "senate": "7aeda6a4b22062fbc9667c3c0258773ba7d4c65747c4a41aedec5e2c25b3464d",
}
OBSERVATIONS_SHA256 = {
    "house": "289c4d79cee04f8e9e352b6f283aee90f8d2b9cabbd310407c4ee094a942b9a4",
    "senate": "893c7dddf67136ad4ab8789f0b4b48488d26e506193f95379cf1cd51abead378",
}


@dataclass(frozen=True, slots=True)
class ClubForGrowthReader:
    """Host-injected reviewed PDF weights plus an exact, privately retained source mapping."""

    parser_version: ClassVar[str] = WEIGHT_PARSER_VERSION
    qualified_items: dict[str, bytes] = field(repr=False)
    qualified_crosswalk: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        return list_scorecards(context)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        return acquire_scorecard(
            edition,
            context,
            qualified_items=self.qualified_items,
            qualified_crosswalk=self.qualified_crosswalk,
            retain_observations=self.retain_observations,
        )


def _qualified_weights(assets, crosswalk):
    if (
        not isinstance(crosswalk, bytes)
        or sha256(crosswalk).hexdigest() != CROSSWALK_SHA256
        or not isinstance(assets, dict)
        or set(assets) != set(CHAMBERS)
    ):
        raise ScorecardSourceError(
            "Club for Growth reviewed source crosswalk or item assets do not match qualification pins"
        )
    data = json.loads(crosswalk)
    result = {}
    for chamber, body in assets.items():
        if not isinstance(body, bytes) or sha256(body).hexdigest() != OBSERVATIONS_SHA256[chamber]:
            raise ScorecardSourceError("Club for Growth reviewed PDF item observations changed")
        observed = json.loads(body)
        if (
            observed["format_version"] != "club-for-growth-qualified-header-facts/1"
            or observed["source_sha256"] != SOURCE_SHA256[chamber]
        ):
            raise ScorecardSourceError("Club for Growth PDF item scope changed")
        rows = [row for row in data["rows"] if row["chamber"] == chamber]
        if len(rows) != len(observed["items"]) or [row["html_ordinal"] for row in rows] != list(
            range(1, len(rows) + 1)
        ):
            raise ScorecardSourceError("Club for Growth reviewed item mapping is incomplete")
        result[chamber] = [(row, observed["items"][row["pdf_ordinal"] - 1]) for row in rows]
    return result


def _html(document):
    if re.search(rb"</html>\s*(?:<!--.*?-->\s*)*$", document.body, flags=re.IGNORECASE | re.DOTALL) is None:
        raise ScorecardSourceError("Club for Growth HTML does not reach document end")
    return soup(document)


def _index(document):
    html = _html(document)
    hrefs = {urljoin(INDEX, node["href"]) for node in html.select("a[href]")}
    if not {METHOD, *URLS.values(), *PDFS.values()} <= hrefs:
        raise ScorecardSourceError("Club for Growth original current scorecard links changed")
    return sorted(hrefs & {METHOD, *URLS.values(), *PDFS.values()})


def _methods(document):
    nodes = _html(document).select("main article .entry-content")
    if len(nodes) != 1:
        raise ScorecardSourceError("Club for Growth methodology section changed")
    text = nodes[0].get_text("\n", strip=True)
    match = re.search(r"included (\d+) House votes and (\d+) Senate votes", text)
    if (
        "LEGISLATIVE ACTIONS CONSIDERED IN 2025" not in text
        or match is None
        or "Lifetime Score" not in text
        or "relative importance" not in text
        or "not applicable" not in text
    ):
        raise ScorecardSourceError("Club for Growth year, weighting or lifetime methodology changed")
    return text, {"house": int(match[1]), "senate": int(match[2])}


def _members(document, chamber):
    html = _html(document)
    letter, _ = CHAMBERS[chamber]
    for name, expected in (("yr", "2025"), ("chamber", letter)):
        options = html.select(f"select[name='{name}'] option[selected]")
        if len(options) != 1 or options[0].get("value") != expected:
            raise ScorecardSourceError("Club for Growth selected year or chamber changed")
    for name in ("party", "state"):
        options = html.select(f"select[name='{name}'] option")
        selected = [option for option in options if option.has_attr("selected")] or options[:1]
        if len(selected) != 1 or selected[0].get("value") != "all":
            raise ScorecardSourceError("Club for Growth member population is filtered")
    tables = html.select("table.full-scorecard")
    if len(tables) != 1:
        raise ScorecardSourceError("Club for Growth full rating table is missing or repeated")
    table = tables[0]
    header = table.find("thead", recursive=False)
    if header is None or [cell.get_text(" ", strip=True) for cell in header.select("th")] != HEADERS:
        raise ScorecardSourceError("Club for Growth rating columns changed")
    body = table.find("tbody", recursive=False)
    if body is None or "scorecard-body" not in body.get("class", []):
        raise ScorecardSourceError("Club for Growth complete table body is absent")
    source_rows = body.find_all("tr", recursive=False)
    if not source_rows or len(source_rows) % 2:
        raise ScorecardSourceError("Club for Growth member/detail row pairs are incomplete")
    rows, identifiers = [], set()
    for offset in range(0, len(source_rows), 2):
        row, expanded = source_rows[offset : offset + 2]
        if "scorecard-row" not in row.get("class", []) or "expanded-data" not in expanded.get("class", []):
            raise ScorecardSourceError("Club for Growth member/detail boundaries changed")
        cells = row.find_all("td", recursive=False)
        if len(cells) != len(HEADERS):
            raise ScorecardSourceError("Club for Growth member row is truncated")
        fields = [cell.get_text("", strip=True) for cell in cells]
        profile = cells[3].select("a[href]")
        if len(profile) != 1:
            raise ScorecardSourceError("Club for Growth exact member profile identity is missing")
        match = re.fullmatch(r"/scorecards/legislator/([A-Z]\d{6})/[^/?#]+", profile[0]["href"])
        details = expanded.select("h3.member-name a[href]")
        grids = expanded.select("table.member-scorecard tbody")
        if (
            match is None
            or match[1] in identifiers
            or len(details) != 1
            or details[0]["href"] != profile[0]["href"]
            or details[0].get_text("", strip=True) != fields[3]
            or len(grids) != 1
            or grids[0].select("tr")
        ):
            raise ScorecardSourceError(
                "Club for Growth member identity repeats, differs or gained undisclosed history rows"
            )
        if (
            not re.fullmatch(r"[A-Z]{2}", fields[0])
            or not re.fullmatch(r"\d{2}" if chamber == "house" else r"\d{2}|", fields[1])
            or not re.fullmatch(r"[A-Z]", fields[2])
            or not fields[3]
            or not re.fullmatch(r"\d+", fields[4])
            or fields[7]
        ):
            raise ScorecardSourceError("Club for Growth member identity or rank shape changed")
        for value in fields[5:7]:
            if value != "n.a." and re.fullmatch(r"\d+(?:\.\d+)?%", value) is None:
                raise ScorecardSourceError("Club for Growth literal score form changed")
        identifiers.add(match[1])
        rows.append(
            {
                "bioguide": match[1],
                "fields": fields,
                "profile_href": profile[0]["href"],
                "lifetime_icon_classes": [" ".join(icon.get("class", [])) for icon in cells[6].select("i")],
                "source_position": offset + 1,
            }
        )
    return rows


def _signature(item):
    return item["title"], item["description"], item["position"]


def _profile(document, member, maximum):
    html = _html(document)
    names = html.select("article.candidate-profile h1.name")
    labels = [node.get_text("", strip=True) for node in html.select("dl.about-candidate dt")]
    values = [node.get_text("", strip=True) for node in html.select("dl.about-candidate dd")]
    if (
        len(names) != 1
        or names[0].get_text("", strip=True) != member["fields"][3]
        or labels != ["2025 Score:", "lifetime:", "Rank:", "District:"]
        or len(values) != 4
    ):
        raise ScorecardSourceError("Club for Growth member profile identity or current score labels changed")
    if values[:3] != [
        value.removesuffix("%") for value in (member["fields"][5], member["fields"][6], member["fields"][4])
    ]:
        raise ScorecardSourceError("Club for Growth member profile ratings differ from the source roster")
    panels = [
        panel
        for panel in html.select("section.vote-scorecard .vote-year")
        if panel.select_one(".year") and panel.select_one(".year").get_text("", strip=True) == "2025"
    ]
    if (
        len(panels) != 1
        or panels[0].select_one(".score") is None
        or panels[0].select_one(".score").get_text("", strip=True) != member["fields"][5]
    ):
        raise ScorecardSourceError("Club for Growth member current year panel is missing or differs")
    tables = panels[0].select("table.vote-table")
    if len(tables) != 1 or [node.get_text("", strip=True) for node in tables[0].select("thead th")] != [
        "Title",
        "Description",
        "Club Position",
        "Rep. Position",
    ]:
        raise ScorecardSourceError("Club for Growth member action table columns changed")
    rows = tables[0].select("tbody > tr")
    if len(rows) > maximum:
        raise ScorecardSourceError("Club for Growth member action count exceeds the disclosed edition item count")
    result = []
    for ordinal, row in enumerate(rows, 1):
        cells = row.find_all("td", recursive=False)
        if len(cells) != 4:
            raise ScorecardSourceError("Club for Growth member action row is incomplete")
        fields = [cell.get_text("", strip=False).strip() for cell in cells]
        if not fields[0] or not fields[1] or fields[2] not in {"Y", "N"} or not fields[3]:
            raise ScorecardSourceError("Club for Growth member action or preferred position is missing")
        result.append(
            {
                "title": fields[0],
                "description": fields[1],
                "position": fields[2],
                "action": fields[3],
                "ordinal": ordinal,
            }
        )
    if len({_signature(item) for item in result}) != len(result):
        raise ScorecardSourceError("Club for Growth repeats an indistinguishable publisher action")
    return {"profile_values": values, "items": result}


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="scorecards:club:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_items: dict[str, bytes] | None = None,
    qualified_crosswalk: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION:
        raise ScorecardSourceError("Club for Growth reader supports the original 2025 HTML rendition")
    with_weights = qualified_items is not None or qualified_crosswalk is not None or retain_observations is not None
    if with_weights and (qualified_items is None or qualified_crosswalk is None or not callable(retain_observations)):
        raise ScorecardSourceError("Club for Growth reviewed PDF weights require private observation retention")
    weights = _qualified_weights(qualified_items, qualified_crosswalk) if with_weights else None
    index = context.read(INDEX, stage="scorecards:club:index", hosts=HOSTS)
    links = _index(index)
    method = context.read(METHOD, stage="scorecards:club:methodology", hosts=HOSTS)
    method_text, declared_items = _methods(method)
    documents = {
        chamber: context.read(url, stage="scorecards:club:" + chamber, hosts=HOSTS) for chamber, url in URLS.items()
    }
    members = {chamber: _members(document, chamber) for chamber, document in documents.items()}
    bundle = Bundle(
        edition,
        context,
        documents["house"],
        publisher_name="Club for Growth Foundation",
        parser_version=WEIGHT_PARSER_VERSION if with_weights else parser_version,
        rendition_rule="club-original-html-ratings-actions-reviewed-pdf-weights/1"
        if with_weights
        else "club-original-complete-html-ratings-pdf-details-pending/1",
        homepage="https://www.clubforgrowth.org/",
    )
    bundle.use(index, "edition_links")
    bundle.use(method, "methodology")
    bundle.add(
        "scorecard_methodologies",
        method,
        "//main//article//div[contains(@class,'entry-content')]",
        methodology_id="published-methodology",
        methodology_text=method_text,
        methodology_url=METHOD,
        disclosure_status="partial",
    )
    declared = {"methodology_declared_" + chamber + "_items": count for chamber, count in declared_items.items()}
    declared["item_count_basis"] = "Source methodology and complete original HTML item grids; " + (
        "exact reviewed PDF item weights included" if with_weights else "PDF weights pending separate qualification"
    )
    profiles = {}
    for chamber, (_, title) in CHAMBERS.items():
        document = documents[chamber]
        rows = members[chamber]
        bundle.use(document, chamber + "_members_and_ratings")
        declared[chamber + "_members"] = len(rows)
        declared[chamber + "_ratings"] = len(rows) * 2
        bundle.add(
            "scorecard_methodologies",
            index,
            f"(//a[@href='{PDFS[chamber]}'])[1]",
            methodology_id=key(chamber, "vote-description-link"),
            methodology_text=PDFS[chamber],
            methodology_url=PDFS[chamber],
            disclosure_status="partial",
        )
        for metric, label, position in (("annual", "Score", 6), ("lifetime", "Lifetime", 7)):
            bundle.metric(
                document,
                key(chamber, metric),
                label,
                path=f"//table[contains(@class,'full-scorecard')]/thead/tr/th[{position}]",
                chamber=title,
                unit="percent",
                primary=metric == "annual",
            )
            bundle.tables["scorecard_metrics"][-1].update(
                methodology_id="published-methodology",
                periods_json=json_column(
                    [
                        {
                            "occurrence_id": metric,
                            "kind": "explicit" if metric == "annual" else "relative",
                            "period_text": "2025" if metric == "annual" else "Lifetime",
                            "source_path": "//select[@name='yr']/option[@selected]"
                            if metric == "annual"
                            else "//table[contains(@class,'full-scorecard')]/thead/tr/th[7]",
                        }
                    ]
                ),
            )
        for row in rows:
            fields = row["fields"]
            path = f"//table[contains(@class,'full-scorecard')]/tbody/tr[{row['source_position']}]"
            member_key = key(chamber, row["bioguide"])
            bundle.add(
                "scorecard_members",
                document,
                path,
                publisher_member_key=member_key,
                member_name=fields[3],
                chamber_text=title,
                state=fields[0],
                district=fields[1],
                party=fields[2],
                identifiers_json=json_column([{"scheme": "bioguide", "value": row["bioguide"]}]),
                notes_text=json_column(
                    {"profile_href": row["profile_href"], "lifetime_icon_classes": row["lifetime_icon_classes"]}
                ),
            )
            for metric, position in (("annual", 5), ("lifetime", 6)):
                value = fields[position]
                bundle.add(
                    "scorecard_member_ratings",
                    document,
                    path + f"/td[{position + 1}]",
                    publisher_member_key=member_key,
                    metric_id=key(chamber, metric),
                    value_text=value,
                    value_number=decimal_text(value),
                    rank_text=fields[4] if metric == "annual" else None,
                )
        for member in rows:
            url = urljoin(INDEX, member["profile_href"]) + "/"
            profile = context.read(url, stage="scorecards:club:profile:" + member["bioguide"], hosts=HOSTS)
            facts = _profile(profile, member, declared_items[chamber])
            profiles[chamber, member["bioguide"]] = (profile, member, facts)
            bundle.use(profile, key(chamber, member["bioguide"], "item_actions"))
        complete = [
            (profile, facts)
            for (source_chamber, _), (profile, _, facts) in profiles.items()
            if source_chamber == chamber and len(facts["items"]) == declared_items[chamber]
        ]
        if not complete:
            raise ScorecardSourceError("Club for Growth full member item grid cannot reconcile with methodology count")
        definition_source, definition_facts = complete[0]
        items = definition_facts["items"]
        by_signature = {_signature(item): ordinal for ordinal, item in enumerate(items, 1)}
        declared[chamber + "_items"] = len(items)
        pdf = None
        observation_id = None
        if weights is not None:
            assert qualified_items is not None and qualified_crosswalk is not None and retain_observations is not None
            pdf = context.read(PDFS[chamber], stage="scorecards:club:pdf-weights:" + chamber, hosts=HOSTS)
            observation_id = retain_qualified(
                pdf,
                qualified_items[chamber],
                retain_observations,
                source_sha256=SOURCE_SHA256[chamber],
                observations_sha256=OBSERVATIONS_SHA256[chamber],
                stage="scorecards:club:qualified-weights:" + chamber,
            )
            retain_qualified(
                pdf,
                qualified_crosswalk,
                retain_observations,
                source_sha256=SOURCE_SHA256[chamber],
                observations_sha256=CROSSWALK_SHA256,
                stage="scorecards:club:qualified-source-crosswalk:" + chamber,
            )
            bundle.use(pdf, chamber + "_item_weights")
            if len(weights[chamber]) != len(items):
                raise ScorecardSourceError("Club for Growth reviewed weights do not cover the complete HTML item set")
        for ordinal, item in enumerate(items, 1):
            item_id = key(chamber, "2025", str(ordinal))
            path = f"(//div[contains(@class,'vote-year')][.//span[@class='year' and normalize-space(.)='2025']]//table/tbody/tr)[{item['ordinal']}]"
            references = (
                [
                    {
                        "occurrence_id": "publisher-title",
                        "kind": "bill",
                        "citation_text": item["title"],
                        "bill_citation_text": item["title"],
                        "source_path": path + "/td[1]",
                    }
                ]
                if re.fullmatch(r"(?:HR|HJR|HCR|SJR|SB)\d+", item["title"])
                else []
            )
            for occurrence, match in enumerate(
                re.finditer(
                    r"\b(?:H\.\s*R\.|H\.\s*J\.\s*Res\.|H\.\s*Con\.\s*Res\.|S\.\s*J\.\s*Res\.|S\.)\s*\d+\b",
                    item["description"],
                )
            ):
                references.append(
                    {
                        "occurrence_id": key("description", str(occurrence)),
                        "kind": "bill",
                        "citation_text": match[0],
                        "bill_citation_text": match[0],
                        "source_path": path + "/td[2]",
                    }
                )
            for occurrence, match in enumerate(re.finditer(r"\b(?:Amendment|Amdt\.?)\s+\d+\b", item["description"])):
                references.append(
                    {
                        "occurrence_id": key("amendment", str(occurrence)),
                        "kind": "amendment",
                        "citation_text": match[0],
                        "amendment_citation_text": match[0],
                        "source_path": path + "/td[2]",
                    }
                )
            bundle.add(
                "scorecard_items",
                definition_source,
                path,
                item_id=item_id,
                item_kind_text="Votes",
                title=item["title"],
                chamber_text=title,
                bill_citation_text=item["title"] if references and references[0]["kind"] == "bill" else None,
                references_json=json_column(references),
                publisher_position_text=item["position"],
                position_basis="explicit",
                position_source_path=path + "/td[3]",
            )
            methodology_id = key(item_id, "narrative")
            bundle.add(
                "scorecard_methodologies",
                definition_source,
                path + "/td[2]",
                methodology_id=methodology_id,
                methodology_text=item["description"],
                disclosure_status="partial",
            )
            weight_source, weight_path, weight_text, weight_number = definition_source, path, None, None
            if weights is not None:
                assert pdf is not None
                mapping, observed = weights[chamber][ordinal - 1]
                literal = observed["record"]
                if (
                    (item["title"], item["description"], item["position"])
                    != (
                        mapping["html_title_text"],
                        mapping["raw_html_description_text"].strip(),
                        mapping["publisher_position_text"],
                    )
                    or literal["publisher_position_text"] != item["position"]
                    or literal["title_text"] != mapping["pdf_title_text"]
                    or literal["weight_text"] != mapping["pdf_points_text"]
                ):
                    raise ScorecardSourceError(
                        "Club for Growth named HTML action differs from the reviewed exact PDF weight mapping"
                    )
                weight_source = pdf
                weight_path = f"pdf:page={observed['evidence']['physical_page']};observation={observation_id};/items/{mapping['pdf_ordinal'] - 1}/record"
                weight_text, weight_number = literal["weight_text"], literal["weight_number_text"]
                bundle.add(
                    "scorecard_methodologies",
                    pdf,
                    weight_path + "/title_text",
                    methodology_id=key(item_id, "pdf-title"),
                    methodology_text=literal["title_text"],
                    methodology_url=PDFS[chamber],
                    disclosure_status="partial",
                )
            bundle.add(
                "scorecard_metric_items",
                weight_source,
                weight_path,
                metric_id=key(chamber, "annual"),
                item_id=item_id,
                participation_id="publisher-item",
                methodology_id=methodology_id,
                publisher_position_text=item["position"],
                position_basis="explicit",
                counts_toward_metric="true",
                weight_text=weight_text,
                weight_number=weight_number,
            )
        for (source_chamber, _), (profile, member, facts) in profiles.items():
            if source_chamber != chamber:
                continue
            declared[key(chamber, member["bioguide"], "actions")] = len(facts["items"])
            for item in facts["items"]:
                ordinal = by_signature.get(_signature(item))
                if ordinal is None:
                    raise ScorecardSourceError(
                        "Club for Growth member item differs from the exact published action definitions"
                    )
                path = f"(//div[contains(@class,'vote-year')][.//span[@class='year' and normalize-space(.)='2025']]//table/tbody/tr)[{item['ordinal']}]"
                bundle.add(
                    "scorecard_member_item_results",
                    profile,
                    path,
                    publisher_member_key=key(chamber, member["bioguide"]),
                    item_id=key(chamber, "2025", str(ordinal)),
                    metric_id=key(chamber, "annual"),
                    participation_id="publisher-item",
                    result_id="source-action",
                    result_text=item["action"],
                    action_text=item["action"],
                )
    for chamber, url in URLS.items():
        repeat = context.read(url, stage="scorecards:club:reread:" + chamber, hosts=HOSTS)
        if _members(repeat, chamber) != members[chamber]:
            raise ScorecardSourceError("Club for Growth member ratings changed during acquisition")
        bundle.use(repeat, chamber + "_members_and_ratings", role="corroboration")
    for (chamber, identifier), (profile, member, facts) in profiles.items():
        repeated = context.read(
            profile.response.requested_url, stage="scorecards:club:reread:profile:" + identifier, hosts=HOSTS
        )
        if _profile(repeated, member, declared_items[chamber]) != facts:
            raise ScorecardSourceError("Club for Growth member action facts changed during acquisition")
        bundle.use(repeated, key(chamber, identifier, "item_actions"), role="corroboration")
    repeat_method = context.read(METHOD, stage="scorecards:club:reread:methodology", hosts=HOSTS)
    repeat_index = context.read(INDEX, stage="scorecards:club:reread:index", hosts=HOSTS)
    if _methods(repeat_method) != (method_text, declared_items) or _index(repeat_index) != links:
        raise ScorecardSourceError("Club for Growth methodology or source links changed during acquisition")
    bundle.use(repeat_method, "methodology", role="corroboration")
    bundle.use(repeat_index, "edition_links", role="corroboration")
    return bundle.finish(
        "Complete unfiltered original HTML rosters and every linked current member action table reached document EOF; literal annual/lifetime/rank values retained; exact profile IDs and member item definitions reconcile; full item grids reconcile with methodology item counts; all source HTML facts agree on stable reread. "
        + (
            "Exact reviewed PDF weights and source-title crosswalk retained privately and bound to original PDF digests."
            if with_weights
            else "PDF item weight rendition remains pending separate qualification."
        ),
        declared=declared,
    )
