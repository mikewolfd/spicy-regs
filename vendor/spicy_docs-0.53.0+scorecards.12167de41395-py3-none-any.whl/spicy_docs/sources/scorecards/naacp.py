"""NAACP's qualified 115th final ratings/items rendition; action grid remains pending."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "naacp-115-final-ratings-items-qualified-semantic/1"
HOSTS = ("naacp.org",)
URL = "https://naacp.org/sites/default/files/documents/115th-Final-Report-Card.pdf"
SOURCE_SHA256 = "e571b214912658cb2bb60a6cf68b2550ba04fb5bc305b99db03da791b20dfb63"
QUALIFIED_SHA256 = "a23303c7e5c9038267c3e68a9bfebe9c08e9b33bb39a2b75e3404458a533abb2"
EDITION = ScorecardEdition(
    "naacp",
    "115-final-ratings-items",
    URL,
    "115th Congress, FINAL — published ratings and narrative items",
    congress="115",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    11: 23,
    12: 20,
    13: 20,
    14: 22,
    15: 21,
    25: 49,
    26: 47,
    27: 50,
    28: 39,
    29: 44,
    30: 34,
    31: 42,
    32: 45,
    33: 55,
    34: 45,
}
ROLLS = {
    "Senate": (
        "54",
        "59",
        "61",
        "64",
        "68",
        "71",
        "81",
        "84",
        "87",
        "93",
        "111",
        "168",
        "221",
        "248",
        "249",
        "298",
        "309",
        "323",
        "33",
        "54",
        "76",
        "82",
        "134",
        "160",
        "176",
        "223",
        "230",
        "231",
        "237",
        "255",
        "259",
        "271",
    ),
    "House": (
        "76",
        "84",
        "97",
        "148",
        "169",
        "256",
        "265",
        "299",
        "337",
        "342",
        "344",
        "412",
        "419",
        "452",
        "495",
        "520",
        "521",
        "554",
        "663",
        "692",
        "32",
        "80",
        "138",
        "171",
        "216",
        "243",
        "282",
        "359",
        "362",
        "385",
        "434",
        "448",
    ),
}
ITEM_PAGES = {
    "Senate": (4,) * 6 + (5,) * 4 + (6,) * 5 + (7,) * 4 + (8,) * 5 + (9,) * 5 + (10,) * 3,
    "House": (17,) * 4 + (18,) * 4 + (19,) * 5 + (20,) * 4 + (21,) * 4 + (22,) * 5 + (23,) * 4 + (24,) * 2,
}


@dataclass(frozen=True, slots=True)
class NAACPReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:naacp:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("NAACP qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "naacp-qualified-ratings-items/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 34
            or data["rendition"] != "published-ratings-and-narrative-items"
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
            or data["unsupported_shapes"][0]["shape"] != "member-level action grid"
            or data["unsupported_shapes"][0]["status"] != "pending qualification"
        ):
            raise ValueError
        counts, identities, previous, ratings, vp_count = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0, 0, 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            name, score, grade = record["member_name_text"], record["score_text"], record["grade_text"]
            chamber = "Senate" if page < 16 else "House"
            vp = name == "VICE PRESIDENT MIKE PENCE"
            if (
                page not in counts
                or page < previous
                or not isinstance(name, str)
                or not name
                or "actions" in record
                or "results" in record
                or record["party_text"] is not None
                or (chamber == "Senate" and record["district_text"] is not None)
                or (not vp and not record["state_text"])
                or (not vp and grade not in {"A", "B", "C", "D", "F", "I", "S"})
                or (
                    score is not None
                    and score not in {"I", "S"}
                    and (re.fullmatch(r"\d{1,3}%", score) is None or int(score[:-1]) > 100)
                )
                or (vp and (page != 15 or score is not None or grade is not None or record["state_text"] is not None))
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], name)
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
            ratings += int(score is not None) + int(grade is not None)
            vp_count += int(vp)
        if counts != PAGE_MEMBERS or ratings != 1108 or vp_count != 1 or len(data["items"]) != 64:
            raise ValueError
        seen = set()
        for entry in data["items"]:
            item, chamber = entry["record"], entry["chamber"]
            ordinal = int(item["publisher_item_key_text"])
            identity = (chamber, ordinal)
            if (
                identity in seen
                or ordinal not in range(1, 33)
                or item["roll_number_text"] != ROLLS[chamber][ordinal - 1]
                or item["source_pages"] != [ITEM_PAGES[chamber][ordinal - 1]]
                or not item["title_text"]
                or not item["methodology_text"]
                or re.fullmatch(r"[A-Z][a-z]+ \d{1,2}, 201[78]", item["item_date_text"] or "") is None
                or not item["publisher_position_text"].startswith(("THE NAACP SUPPORTED", "THE NAACP OPPOSED"))
            ):
                raise ValueError
            seen.add(identity)
        if seen != {(c, n) for c in ROLLS for n in range(1, 33)} or [
            e["evidence"]["physical_page"] for e in data["methodology"]
        ] != [3]:
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError, IndexError):
        raise ScorecardSourceError(
            "NAACP semantic facts fail the complete qualified ratings/items rendition shape"
        ) from None


def _references(item, loc):
    occurrences = []
    for i, ref in enumerate(item["references"]):
        kind = ref["kind"]
        occurrence = {
            "occurrence_id": str(i),
            "citation_text": ref["citation_text"],
            "kind": kind,
            "source_path": loc + f"/references/{i}",
        }
        if kind in {"bill", "amendment"}:
            occurrence["amendment_citation_text" if kind == "amendment" else "bill_citation_text"] = ref[
                "citation_text"
            ]
        occurrences.append(occurrence)
    return json.dumps(occurrences, ensure_ascii=False)


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("NAACP rendition requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:naacp:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="naacp:qualified-115-final-ratings-items",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="NAACP",
        parser_version=parser_version,
        rendition_rule="naacp-published-ratings-and-narrative-items-only/1",
        homepage="https://naacp.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    method = data["methodology"][0]["record"]
    bundle.add(
        "scorecard_methodologies",
        source,
        path(3, "/methodology/0/record"),
        methodology_id="source-page-3",
        methodology_text=method["methodology_text"]
        + "\n"
        + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in method["legend"]),
        methodology_url=URL,
        disclosure_status="explicit grading scale and tenure/Speaker/VP rules; action grid pending qualification and omitted",
    )
    for chamber, page in (("Senate", 11), ("House", 25)):
        for metric, name, unit in (("percent", "%", "percent"), ("grade", "published letter grade", "grade")):
            bundle.add(
                "scorecard_metrics",
                source,
                path(page, "/rating-heading/" + metric),
                metric_id=key(chamber, metric),
                name=name,
                chamber_text=chamber,
                period_text="115th Congress, FINAL; January 3, 2017 - January 3, 2019",
                value_unit_text=unit,
                is_primary="true" if metric == "percent" else "false",
                methodology_id="source-page-3",
            )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        ordinal = item["publisher_item_key_text"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=key(chamber, ordinal),
            publisher_item_id=ordinal,
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            congress_text="115",
            chamber_text=chamber,
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "percent"),
            item_id=key(chamber, ordinal),
            participation_id="115-final",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-3",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc + "/methodology_text",
            methodology_id=key(chamber, "item", ordinal),
            methodology_text=item["methodology_text"],
            methodology_url=URL,
            disclosure_status="publisher item narrative from retained scanned source OCR and qualified semantic facts",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "Senate" if page < 16 else "House"
        identity = key(
            chamber,
            record["state_text"] or "unstated-state",
            record["member_name_text"],
            record["district_text"] or "unstated-district",
        )
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            chamber_text=chamber,
            notes_text=record["notes_text"] or None,
        )
        for metric, value_field in (("percent", "score_text"), ("grade", "grade_text")):
            value = record[value_field]
            if value is not None:
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    loc + "/" + value_field,
                    metric_id=key(chamber, metric),
                    publisher_member_key=identity,
                    value_text=value,
                    value_number=decimal_text(value) if metric == "percent" else None,
                    notes_text=record["notes_text"] or None,
                )
    return bundle.finish(
        "Complete named ratings/items rendition: all source member pages, printed percent/grade fields, source tenure notes, VP row and dated narrative items. The member action grid is pending qualification and has no published rows; this snapshot does not claim a complete full scorecard. Independent OCR and original images reconcile ratings and item metadata; all candidates, corrections and refusals stay retained. No invented grades, scores, missing districts, party text, sessions or official member actions."
    )
