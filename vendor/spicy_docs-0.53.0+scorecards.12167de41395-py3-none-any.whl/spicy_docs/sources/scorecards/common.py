"""Shared mechanics for explicit scorecard readers; publisher meaning stays in each adapter."""

from __future__ import annotations

import json
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote, urlsplit
from uuid import UUID, uuid4

from spicy_docs.schemas.scorecard_tables import SCORECARD_OPTIONAL_REFERENCES, SCORECARD_TABLES
from spicy_docs.schemas.tables import Row, TableContractError, json_column
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.credentials import CredentialRefusedError


class ScorecardSourceError(ValueError):
    """A source cannot establish a complete supported edition; preserve prior rows."""


@dataclass(frozen=True, slots=True)
class ScorecardEdition:
    publisher_id: str
    edition_id: str
    source_url: str
    title: str
    year: str | None = None
    congress: str | None = None
    chamber: str | None = None
    is_current: bool = True

    @property
    def scorecard_id(self) -> str:
        return key(self.publisher_id, self.edition_id)


@dataclass(frozen=True, slots=True)
class SourceDocument:
    capture_id: str
    response: CapturedBodyResponse = field(repr=False)

    @property
    def url(self) -> str:
        return self.response.resolved_url

    @property
    def body(self) -> bytes:
        return self.response.body


@dataclass(slots=True)
class ScorecardContext:
    """Injected bounded acquisition and public evidence writer; no output directory or body spool.

    ``fetch`` must bound transport time, redirects and streamed bytes before returning.
    This context rechecks the final body and request budget, and records even refused HTTP
    responses. ``capture(response, stage=...)`` must return its opaque ``capture_id``.
    Reader source URLs never contain credentials. PDF readers additionally require an existing
    ``extraction.Extractor`` as ``pdf_extractor`` and a private callback
    ``retain_extraction(source_document, page_result, stage=...)`` returning a unique
    opaque ``extraction_id``. Never send this callback to a public evidence writer:
    page results include source renderings and full model responses. Exact source
    hashes bind private extraction inputs, including with public metadata_only policy;
    neither those hashes nor raw extraction output are returned in table rows.
    """

    fetch: Callable[[str], CapturedBodyResponse]
    capture: Callable[..., Mapping[str, object]]
    evidence_policy: str = "hash_only"
    max_bytes: int = 20 * 1024 * 1024
    max_requests: int = 2000
    pdf_extractor: Any = None
    retain_extraction: Callable[..., Mapping[str, object]] | None = None
    fetch_request: Callable[..., CapturedBodyResponse] | None = None
    _requests: int = field(default=0, init=False)
    _capture_ids: set[str] = field(default_factory=set, init=False, repr=False)

    def read(self, url: str, *, stage: str, hosts: tuple[str, ...]) -> SourceDocument:
        return self.read_request(url, method="GET", content=None, stage=stage, hosts=hosts)

    def read_request(
        self,
        url: str,
        *,
        method: str,
        content: bytes | None,
        stage: str,
        hosts: tuple[str, ...],
        allow_http: bool = False,
        request_headers: Mapping[str, str] | None = None,
    ) -> SourceDocument:
        """Capture a publisher-selected request, including read-only GraphQL POSTs.

        The publisher reader owns query meaning. A POST uses an injected request
        callback, preserves its exact body, and consumes the same budget as GET.
        ``allow_http`` is only for a reader's explicitly observed public endpoint.
        Source-selected headers use the same request callback. Their values stay
        outside the public capture; normal browser bootstrap credentials belong
        only to the configured publisher endpoint.
        """
        if self.evidence_policy not in {"full", "hash_only", "metadata_only"}:
            raise ScorecardSourceError("Unknown public evidence policy")
        if method not in {"GET", "POST"} or (content is not None) != (method == "POST"):
            raise ScorecardSourceError("Scorecard request must be GET without a body or POST with a body")
        if content is not None and (not isinstance(content, bytes) or not content or len(content) > self.max_bytes):
            raise ScorecardSourceError("Scorecard request body is empty or exceeds the byte bound")
        if request_headers is not None and (
            not isinstance(request_headers, Mapping)
            or any(
                not isinstance(name, str)
                or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name)
                or not isinstance(value, str)
                or not value
                or "\r" in value
                or "\n" in value
                for name, value in request_headers.items()
            )
        ):
            raise ScorecardSourceError("Scorecard request headers must contain valid single-line text")
        validate_url(url, hosts, allow_http=allow_http)
        if self.max_bytes <= 0 or self._requests >= self.max_requests:
            raise ScorecardSourceError("Scorecard acquisition budget exhausted")
        self._requests += 1
        try:
            if method == "GET" and not request_headers:
                response = self.fetch(url)
            else:
                request = self.fetch_request or getattr(self.fetch, "request", None)
                if request is None:
                    raise ScorecardSourceError("Publisher headers or POST require an injected request capture")
                options = {"request_headers": dict(request_headers)} if request_headers else {}
                response = request(url, method=method, content=content, **options)
        except CredentialRefusedError:
            raise
        except Exception as error:
            # Do not expose arbitrary transport exception text or credential-bearing URLs.
            raise ScorecardSourceError(f"Scorecard transport failed at {stage}") from error
        receipt = self.capture(response, stage=stage)
        capture_id = receipt.get("capture_id")
        if not isinstance(capture_id, str) or not capture_id or capture_id in self._capture_ids:
            raise ScorecardSourceError("Evidence callback must issue a unique opaque capture_id per observation")
        self._capture_ids.add(capture_id)
        validate_url(response.resolved_url, hosts, allow_http=allow_http)
        if response.requested_url != url or response.method != method or response.request_body != content:
            raise ScorecardSourceError("Scorecard capture does not match the selected request")
        if response.status_code != 200:
            raise ScorecardSourceError(f"Scorecard source answered HTTP {response.status_code} at {stage}")
        if not response.body or len(response.body) > self.max_bytes:
            raise ScorecardSourceError(f"Scorecard source is empty or exceeds the byte bound at {stage}")
        return SourceDocument(capture_id, response)


def validate_url(url: str, hosts: tuple[str, ...], *, allow_http: bool = False) -> None:
    parsed = urlsplit(url)
    schemes = {"https", "http"} if allow_http else {"https"}
    if (
        parsed.scheme not in schemes
        or parsed.hostname not in hosts
        or parsed.username
        or parsed.password
        or parsed.port
    ):
        raise ScorecardSourceError("Scorecard URL is outside the selected public publisher")


def key(*parts: str) -> str:
    """Versioned reversible key of literal source identifiers, independent of response ordering."""
    if not parts or any(not isinstance(part, str) or not part for part in parts):
        raise ScorecardSourceError("Source identity contains an empty component")
    return ":".join(quote(part, safe="") for part in parts)


def decimal_text(value: str | None) -> str | None:
    """Only an explicit decimal, optionally followed by a percent sign; no grade conversion."""
    if value is not None and re.fullmatch(r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)%?", value):
        return value.removesuffix("%")
    return None


def soup(document: SourceDocument):
    try:
        from bs4 import BeautifulSoup
    except ImportError as error:
        raise ScorecardSourceError("Scorecard HTML readers require spicy-docs[html]") from error
    return BeautifulSoup(document.body, "html.parser")


def _invalid_json_constant(value: str):
    raise ValueError("Nonstandard JSON constant")


def _unique_json_fields(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("Duplicate JSON field")
        result[name] = value
    return result


def json_data(document: SourceDocument) -> Any:
    try:
        return json.loads(
            document.body, parse_constant=_invalid_json_constant, parse_float=str, object_pairs_hook=_unique_json_fields
        )
    except (ValueError, UnicodeError) as error:
        raise ScorecardSourceError("Publisher JSON is malformed") from error


def pdf(document: SourceDocument, context: ScorecardContext | None = None, *, expected_pages: int | None = None):
    """Read only through the host's existing structured extraction pipeline."""
    if not document.body.startswith(b"%PDF-") or b"%%EOF" not in document.body[-1024:]:
        raise ScorecardSourceError("Publisher PDF is missing its header or final trailer")
    from spicy_docs.sources.scorecards.pdf_observations import extract_pdf

    return extract_pdf(document, context, expected_pages=expected_pages)


@dataclass(frozen=True, slots=True)
class ScorecardAcquisition:
    scorecard_id: str
    snapshot_id: str
    tables: dict[str, list[Row]]
    capture_ids: tuple[str, ...]
    completeness_rule: str


class Bundle:
    """Build one edition's full rows with explicit source locators; close only after publisher checks."""

    def __init__(
        self,
        edition: ScorecardEdition,
        context: ScorecardContext,
        primary: SourceDocument,
        *,
        publisher_name: str,
        parser_version: str,
        rendition_rule: str,
        homepage: str,
    ) -> None:
        self.edition = edition
        self.context = context
        self.snapshot_id = "scorecard-snapshot:" + str(uuid4())
        self.parser_version = parser_version
        self.rendition_rule = rendition_rule
        self.primary = primary
        self.tables: dict[str, list[Row]] = {name: [] for name in SCORECARD_TABLES}
        self.documents: dict[str, SourceDocument] = {}
        self.roles: dict[str, dict[str, object]] = {}
        self.use(primary, "edition")
        self.add(
            "scorecard_publishers",
            primary,
            "/",
            publisher_id=edition.publisher_id,
            name=publisher_name,
            homepage_url=homepage,
            scorecard_index_url=edition.source_url,
            observed_at=primary.response.observed_at,
            aliases_json="[]",
        )
        self.add(
            "scorecards",
            primary,
            "/",
            publisher_id=edition.publisher_id,
            series_id=edition.publisher_id,
            publisher_edition_key=edition.edition_id,
            publisher_name_text=publisher_name,
            title=edition.title,
            edition_label_text=edition.edition_id,
            year_text=edition.year,
            congress_text=edition.congress,
            chamber_scope_text=edition.chamber,
            observed_at=primary.response.observed_at,
            periods_json="[]",
        )

    def use(self, document: SourceDocument, *groups: str, role: str = "primary") -> None:
        self.documents[document.capture_id] = document
        existing = self.roles.get(document.capture_id)
        if existing:
            if existing["role"] != role:
                raise ScorecardSourceError("A selected capture has conflicting roles")
            existing["field_groups"] = sorted(set(existing["field_groups"]) | set(groups))
        else:
            self.roles[document.capture_id] = {
                "capture_id": document.capture_id,
                "role": role,
                "field_groups": list(groups),
            }

    def add(self, table: str, document: SourceDocument, path: str, **values: str | None) -> Row:
        contract = SCORECARD_TABLES[table]
        row: Row = dict.fromkeys(contract.columns)
        defaults = {
            "scorecard_id": self.edition.scorecard_id,
            "snapshot_id": self.snapshot_id,
            "capture_id": document.capture_id,
            "source_url": document.url,
            "source_path": path,
        }
        row.update({name: value for name, value in defaults.items() if name in row})
        row.update(values)
        try:
            contract.checked(row)
        except TableContractError as error:
            raise ScorecardSourceError(str(error)) from error
        self.tables[table].append(row)
        return row

    def metric(
        self,
        document: SourceDocument,
        metric_id: str,
        name: str,
        *,
        path: str,
        chamber: str | None = None,
        unit: str | None = None,
        primary: bool = True,
    ) -> None:
        self.add(
            "scorecard_metrics",
            document,
            path,
            metric_id=metric_id,
            name=name,
            value_unit_text=unit,
            chamber_text=chamber,
            is_primary="true" if primary else "false",
        )

    def finish(self, rule: str, *, declared: Mapping[str, object] | None = None) -> ScorecardAcquisition:
        if not rule or not self.tables["scorecard_members"]:
            raise ScorecardSourceError("Empty edition or missing source completeness proof")
        self.add(
            "scorecard_snapshots",
            self.primary,
            "/",
            observed_at=self.primary.response.observed_at,
            capture_ids_json=json_column(list(self.documents)),
            parser_version=self.parser_version,
            completeness_status="complete",
            completeness_rule=rule,
            source_declared_counts_json=json_column(dict(declared or {})),
            parsed_counts_json=json_column(
                {name: 1 if name == "scorecard_snapshots" else len(rows) for name, rows in self.tables.items()}
            ),
            evidence_policy=self.context.evidence_policy,
            capture_roles_json=json_column(list(self.roles.values())),
            rendition_selection_rule=self.rendition_rule,
            identity_rule_version=self.parser_version + ":identity-1",
        )
        validate_scorecard_bundle(self.tables)
        return ScorecardAcquisition(
            self.edition.scorecard_id, self.snapshot_id, self.tables, tuple(self.documents), rule
        )


def validate_scorecard_bundle(tables: Mapping[str, list[Row]]) -> None:
    """Validate closed whole-edition rows independently of any publisher parser or research checkout."""
    if set(tables) != set(SCORECARD_TABLES):
        raise ScorecardSourceError("Scorecard bundle must supply every frozen table")
    indices: dict[str, set[tuple[str, ...]]] = {}
    for name, contract in SCORECARD_TABLES.items():
        keys: set[tuple[str, ...]] = set()
        for row in tables[name]:
            try:
                contract.checked(row)
                identity = contract.key(row)
            except TableContractError as error:
                raise ScorecardSourceError(str(error)) from error
            if any(not part for part in identity) or identity in keys:
                raise ScorecardSourceError(f"{name}: duplicate or empty source identity")
            keys.add(identity)
            for field_name in ("capture_id", "source_url", "source_path"):
                if not row[field_name]:
                    raise ScorecardSourceError(f"{name}: missing {field_name}")
            if (
                name == "scorecard_items"
                and row["publisher_position_text"] is not None
                and (not row["position_basis"] or not row["position_source_path"])
            ):
                raise ScorecardSourceError("Item target needs source basis and locator")
            for flag in ("is_primary", "counts_toward_metric"):
                if row.get(flag) not in {None, "true", "false"}:
                    raise ScorecardSourceError(f"{name}: {flag} must be true, false or NULL")
            for field_name, raw in row.items():
                if raw is None:
                    continue
                if field_name.endswith("_json"):
                    try:
                        parsed = json.loads(raw, parse_constant=_invalid_json_constant)
                    except ValueError as error:
                        raise ScorecardSourceError(f"{name}: invalid {field_name}") from error
                    if field_name in {"parsed_counts_json", "source_declared_counts_json"} and not isinstance(
                        parsed, dict
                    ):
                        raise ScorecardSourceError("Snapshot counts must be a JSON object")
                    if field_name in {"periods_json", "references_json"}:
                        if not isinstance(parsed, list):
                            raise ScorecardSourceError(f"{name}: expected occurrence array")
                        seen = set()
                        for occurrence in parsed:
                            literal = "period_text" if field_name == "periods_json" else "citation_text"
                            mandatory = {"occurrence_id", literal, "source_path", "kind"}
                            contexts = {"congress_text", "chamber_text", "session_text"}
                            contexts |= (
                                {"year_text"}
                                if field_name == "periods_json"
                                else {"roll_number_text", "bill_citation_text", "amendment_citation_text"}
                            )
                            if (
                                not isinstance(occurrence, dict)
                                or not mandatory <= set(occurrence) <= mandatory | contexts
                                or not all(v is None or isinstance(v, str) for v in occurrence.values())
                                or not occurrence.get("occurrence_id")
                                or not occurrence.get(literal)
                                or not occurrence.get("source_path")
                                or not occurrence.get("kind")
                                or occurrence["occurrence_id"] in seen
                            ):
                                raise ScorecardSourceError(f"{name}: incomplete or duplicate source occurrence")
                            if field_name == "periods_json" and occurrence["kind"] not in {"explicit", "relative"}:
                                raise ScorecardSourceError("Unknown source period kind")
                            seen.add(occurrence["occurrence_id"])
                    if field_name == "identifiers_json" and (
                        not isinstance(parsed, list)
                        or any(
                            not isinstance(value, dict)
                            or set(value) != {"scheme", "value"}
                            or any(not isinstance(part, str) or not part for part in value.values())
                            for value in parsed
                        )
                    ):
                        raise ScorecardSourceError("Source identifiers need literal scheme and value pairs")
                    if field_name == "aliases_json" and (
                        not isinstance(parsed, list) or any(not isinstance(value, str) or not value for value in parsed)
                    ):
                        raise ScorecardSourceError("Publisher aliases must be literal strings")
                if field_name in {"value_number", "weight_number", "contribution_number"} and not re.fullmatch(
                    r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)", raw
                ):
                    raise ScorecardSourceError(f"{name}: numerical field is not exact decimal text")
        indices[name] = keys
    for name, contract in SCORECARD_TABLES.items():
        for row in tables[name]:
            for ref in contract.references:
                parts = tuple(row[c] for c in ref.child_columns)
                # Composite optional FKs can have shared mandatory scorecard_id/item_id columns.
                optional_parts = [row[c] for c in ref.child_columns if c not in {"scorecard_id", "item_id"}]
                if (
                    (name, ref.child_columns, ref.parent_table) in SCORECARD_OPTIONAL_REFERENCES
                    and optional_parts
                    and all(part is None for part in optional_parts)
                ):
                    continue
                if parts not in indices[ref.parent_table]:
                    raise ScorecardSourceError(f"{name}: unresolved source reference to {ref.parent_table}")
    snapshots = {row["snapshot_id"]: row for row in tables["scorecard_snapshots"]}
    editions = {row["scorecard_id"]: row for row in tables["scorecards"]}
    if not editions or len(editions) != len(snapshots):
        raise ScorecardSourceError("Exactly one accepted snapshot is required per edition")
    for snapshot_id, row in snapshots.items():
        if row["completeness_status"] != "complete" or not row["completeness_rule"]:
            raise ScorecardSourceError("An incomplete edition cannot produce table rows")
        for required in ("parser_version", "identity_rule_version", "rendition_selection_rule"):
            if not row[required]:
                raise ScorecardSourceError(f"Snapshot missing {required}")
        if row["evidence_policy"] not in {"full", "hash_only", "metadata_only"}:
            raise ScorecardSourceError("Snapshot has unknown evidence policy")
        ids = json.loads(row["capture_ids_json"] or "null")
        roles = json.loads(row["capture_roles_json"] or "null")
        if (
            not isinstance(ids, list)
            or not ids
            or any(not isinstance(x, str) or not x for x in ids)
            or len(ids) != len(set(ids))
            or not isinstance(roles, list)
        ):
            raise ScorecardSourceError("Snapshot capture selection is malformed")
        groups: dict[str, int] = {}
        selected = []
        for role in roles:
            if not isinstance(role, dict) or set(role) != {"capture_id", "role", "field_groups"}:
                raise ScorecardSourceError("Snapshot capture attribution is malformed")
            selected.append(role["capture_id"])
            if (
                not isinstance(role["capture_id"], str)
                or not role["capture_id"]
                or role["role"] not in {"primary", "corroboration", "discovery", "methodology"}
            ):
                raise ScorecardSourceError("Snapshot capture role is unknown")
            if not isinstance(role["field_groups"], list):
                raise ScorecardSourceError("Snapshot field groups must be an array")
            for group in role["field_groups"]:
                if not isinstance(group, str) or not group:
                    raise ScorecardSourceError("Snapshot field group is empty")
                groups.setdefault(group, 0)
                groups[group] += int(role["role"] == "primary")
            if len(set(role["field_groups"])) != len(role["field_groups"]):
                raise ScorecardSourceError("Snapshot repeats a field group")
        if not groups or set(selected) != set(ids) or len(selected) != len(ids) or any(n != 1 for n in groups.values()):
            raise ScorecardSourceError("Every field group needs exactly one primary capture")
        if editions[row["scorecard_id"]]["snapshot_id"] != snapshot_id:
            raise ScorecardSourceError("Edition names a different accepted snapshot")
        if row["evidence_policy"] == "metadata_only" and row["methodology_digest"] is not None:
            raise ScorecardSourceError("Metadata-only snapshot must not expose source byte hashes")
        if row["evidence_policy"] == "metadata_only":
            try:
                parsed_id = UUID(snapshot_id.removeprefix("scorecard-snapshot:"))
            except ValueError as error:
                raise ScorecardSourceError("Metadata-only snapshot needs an opaque UUID4") from error
            if not snapshot_id.startswith("scorecard-snapshot:") or parsed_id.version != 4:
                raise ScorecardSourceError("Metadata-only snapshot needs an opaque UUID4")
    for name, rows in tables.items():
        if name == "scorecard_publishers":
            continue
        for row in rows:
            selected = snapshots.get(row["snapshot_id"])
            if (
                selected is None
                or selected["scorecard_id"] != row["scorecard_id"]
                or row["capture_id"] not in json.loads(selected["capture_ids_json"])
            ):
                raise ScorecardSourceError(f"{name}: source row is outside selected snapshot")
    graph: dict[tuple[str | None, str | None], list[tuple[str | None, str | None]]] = {}
    for row in tables["scorecard_metric_components"]:
        parent = (row["scorecard_id"], row["parent_metric_id"])
        graph.setdefault(parent, []).append((row["scorecard_id"], row["component_metric_id"]))

    def walk(node, visiting):
        if node in visiting:
            raise ScorecardSourceError("Metric components contain a cycle")
        for child in graph.get(node, []):
            walk(child, visiting | {node})

    for node in graph:
        walk(node, set())
