"""NFIB's named federal PDF editions, from reviewed original semantic facts."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "nfib-named-qualified-rendered-pdf/1"
HOSTS = ("www.nfib.com",)
INDEX = "https://www.nfib.com/how-congress-voted/"
SPECS: dict[str, dict[str, Any]] = {
    "119-pre-election": {
        "url": "https://www.nfib.com/wp-content/uploads/2026/09/HCV-119-Pre-Election-Digital.pdf",
        "source_sha256": "d01bbe9e2c4f2cbbbf22373ddd381f79aca2f5fd4705452182ed249ea23ad63b",
        "qualified_sha256": "1c3957d92f4dc3a3b0bf6d4b751e8e7db88383602d802f883fc976a389c8f204",
        "congress": "119",
        "prior_congress": "118",
        "year": "2026",
        "label": "119TH PRE-ELECTION REPORT",
        "period": "January 3, 2025, to August 30, 2026",
        "current_label": "119th Pre-Election %",
        "prior_label": "118th %",
        "page_count": 40,
        "member_counts": {"House": 442, "Senate": 102},
        "item_counts": {"House": 10, "Senate": 5},
        "page_counts": {
            8: 11,
            9: 24,
            10: 28,
            11: 25,
            12: 24,
            13: 22,
            14: 23,
            15: 21,
            16: 23,
            17: 23,
            18: 19,
            19: 21,
            20: 26,
            21: 24,
            22: 22,
            23: 21,
            24: 26,
            25: 25,
            26: 23,
            27: 11,
            30: 8,
            31: 14,
            32: 14,
            33: 14,
            34: 14,
            35: 15,
            36: 15,
            37: 8,
        },
        "target_codes": {"House": [], "Senate": []},
    },
    "118-final": {
        "url": "https://www.nfib.com/wp-content/uploads/2025/06/HCV-118-Final-Report-Half-Letter-.pdf",
        "source_sha256": "fc32840610b37f40e1879c1c6833fc3508de4c91a1efd87aa8dbc83156fd65c2",
        "qualified_sha256": "33f7003c5211691f4c9cf7a0a2cf61b3d7d8e7638a362d58b0fbd0dabd33aa73",
        "congress": "118",
        "prior_congress": "117",
        "year": "2025",
        "label": "118TH CONGRESS FINAL REPORT",
        "period": "January 3, 2023 to January 3, 2025",
        "current_label": "118th %",
        "prior_label": "117th %",
        "page_count": 36,
        "member_counts": {"House": 443, "Senate": 103},
        "item_counts": {"House": 9, "Senate": 6},
        "page_counts": {
            8: 10,
            9: 29,
            10: 31,
            11: 26,
            12: 28,
            13: 28,
            14: 26,
            15: 27,
            16: 28,
            17: 25,
            18: 30,
            19: 28,
            20: 27,
            21: 26,
            22: 31,
            23: 26,
            24: 17,
            30: 8,
            31: 20,
            32: 20,
            33: 19,
            34: 20,
            35: 16,
        },
        "target_codes": {"House": ["Y"] * 9, "Senate": ["Y"] * 5 + ["N"]},
    },
}
EDITIONS = {
    identifier: ScorecardEdition(
        "nfib",
        identifier,
        spec["url"],
        "HOW CONGRESS VOTED — " + spec["label"],
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )
    for identifier, spec in SPECS.items()
}
GLYPHS = {"Y", "N", "?", "S", "I"}


def _spec(identifier):
    if identifier not in SPECS:
        raise ScorecardSourceError("NFIB PDF reader requires a reviewed named edition")
    return SPECS[identifier]


def _source(document, spec):
    if document.url != spec["url"] or sha256(document.body).hexdigest() != spec["source_sha256"]:
        raise ScorecardSourceError("NFIB PDF differs from the reviewed original named edition")


@dataclass(frozen=True, slots=True)
class NFIBPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError("NFIB PDF observations must identify a reviewed named edition") from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["url"], stage=f"nfib-pdf:{self.edition_key}:list", hosts=HOSTS), spec)
        return (EDITIONS[self.edition_key],)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != EDITIONS.get(self.edition_key):
            raise ScorecardSourceError("NFIB PDF reader requires its configured reviewed named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value, spec):
    if (
        not value["physical_pages"]
        or any(type(p) is not int or not 1 <= p <= spec["page_count"] for p in value["physical_pages"])
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or value["schema_version"]
        not in {
            "nfib-pdf-member-facts/1",
            "nfib-pdf-full-row-correction/1",
            "nfib-pdf-item-facts/1",
            "nfib-pdf-front-facts/1",
        }
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("NFIB PDF observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "nfib-qualified-pdf/1"
            or data["edition_key"] != identifier
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["page_count"]
            or data["member_counts"] != spec["member_counts"]
            or data["item_counts"] != spec["item_counts"]
            or data["member_page_counts"] != {str(p): n for p, n in spec["page_counts"].items()}
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["uncertainties"]
            or front["title_text"] != "HOW CONGRESS VOTED"
            or front["edition_label_text"] != spec["label"]
            or front["period_text"] != spec["period"]
            or front["congress_text"] != spec["congress"] + "th Congress"
            or front["current_metric_label"] != spec["current_label"]
            or front["prior_metric_label"] != spec["prior_label"]
            or not front["report_methodology_text"]
            or not front["source_front_text"]
            or any(front[c.lower() + "_item_target_codes"] != spec["target_codes"][c] for c in spec["item_counts"])
        ):
            raise ValueError
        for chamber in spec["item_counts"]:
            legend = front[chamber.lower() + "_legend"]
            symbols = [r["symbol_text"] for r in legend]
            if len(symbols) != len(set(symbols)) or any(not r["meaning_text"] for r in legend):
                raise ValueError
            if identifier == "118-final" and not GLYPHS - ({"S"} if chamber == "Senate" else set()) <= set(symbols):
                raise ValueError
        items = set()
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            n = r["item_number_text"]
            if (
                chamber not in spec["item_counts"]
                or not isinstance(n, str)
                or not n.isdigit()
                or n != (f"{int(n):02}" if identifier == "119-pre-election" else str(int(n)))
                or not 1 <= int(n) <= spec["item_counts"][chamber]
                or (chamber, n) in items
                or any(not r[f] for f in ["title_text", "description_text", "position_text", "research_basis_text"])
                or r["roll_number_text"] is not None
                or any(not isinstance(c, str) or not c for f in ["bill_citations", "amendment_citations"] for c in r[f])
                or (not r["bill_citations"] and not r["nomination_text"])
            ):
                raise ValueError
            items.add((chamber, n))
        if dict(Counter(c for c, _ in items)) != spec["item_counts"]:
            raise ValueError
        identities, counts, pages = set(), Counter(), Counter()
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            page = e["evidence"]["physical_pages"]
            results = r["item_results"]
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or not isinstance(r["state_text"], str)
                or not r["state_text"]
                or type(r["guardian_award"]) is not bool
                or type(r["nfib_member"]) is not bool
                or (r["member_footnotes_text"] is not None and not re.fullmatch(r"[*#]+", r["member_footnotes_text"]))
                or any(
                    not re.fullmatch(r"(?:\d+|N/A|-)[*#]*", r[f]) for f in ["current_value_text", "prior_value_text"]
                )
                or (chamber == "Senate" and r["district_text"] is not None)
                or (
                    chamber == "House"
                    and (
                        r["district_text"] != r["publisher_row_text"] or not re.fullmatch(r"\d+|AL", r["district_text"])
                    )
                )
                or len(page) != 1
                or page[0] not in spec["page_counts"]
                or (identifier == "119-pre-election" and results is not None)
                or (
                    identifier == "118-final"
                    and (
                        not isinstance(results, dict)
                        or set(results) != {n for c, n in items if c == chamber}
                        or any(v not in GLYPHS - ({"S"} if chamber == "Senate" else set()) for v in results.values())
                    )
                )
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[page[0]] += 1
        if dict(counts) != spec["member_counts"] or dict(pages) != spec["page_counts"]:
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError("NFIB PDF facts no longer establish a complete reviewed named edition") from error


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != EDITIONS[edition.edition_id]:
        raise ScorecardSourceError("NFIB PDF reader requires the exact reviewed named edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("NFIB PDF requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    document = context.read(spec["url"], stage=f"nfib-pdf:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"nfib-pdf:{edition.edition_id}:qualified-observations",
    )

    def path(group, index=None, suffix=""):
        e = data[group]["evidence"] if index is None else data[group][index]["evidence"]
        selected = f"/{group}" + ("" if index is None else f"/{index}")
        return f"pdf:pages={','.join(str(p) for p in e['physical_pages'])};observation={observation};{selected}/record{suffix}"

    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="National Federation of Independent Business",
        parser_version=parser_version,
        rendition_rule="complete named original federal PDF; reviewed data-shaped page outcomes reconciled with original encoded text, font/color glyphs, source page populations and identical original reread",
        homepage="https://www.nfib.com/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        title=front["title_text"],
        edition_label_text=front["edition_label_text"],
        methodology_url=spec["url"],
        timespan_text=front["period_text"],
    )
    for chamber in spec["member_counts"]:
        methodology = key(chamber, "report")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front"),
            methodology_id=methodology,
            chamber_text=chamber,
            methodology_url=spec["url"],
            disclosure_status="explicit",
            methodology_text=json_column(
                {
                    "report_methodology_text": front["report_methodology_text"],
                    "legend": front[chamber.lower() + "_legend"],
                }
            ),
        )
        for period, label in [
            ("current", front["current_metric_label"]),
            ("prior", front["prior_metric_label"]),
        ]:
            bundle.add(
                "scorecard_metrics",
                document,
                path("front"),
                metric_id=key(chamber, period),
                name=label,
                value_unit_text="%",
                chamber_text=chamber,
                period_text=label,
                methodology_id=methodology,
                is_primary="true" if period == "current" else "false",
            )
    for i, e in enumerate(data["items"]):
        r, chamber = e["record"], e["chamber"]
        location, n = path("items", i), r["item_number_text"]
        identifier, methodology = key(chamber, n), key(chamber, "item", n)
        references = [
            {
                "occurrence_id": f"{kind}:{j}",
                "citation_text": citation,
                "kind": kind,
                "source_path": location + f"/{field_name}/{j}",
                "congress_text": spec["congress"],
                "chamber_text": chamber,
                output_field: citation,
            }
            for kind, field_name, output_field in [
                ("bill", "bill_citations", "bill_citation_text"),
                ("amendment", "amendment_citations", "amendment_citation_text"),
            ]
            for j, citation in enumerate(r[field_name])
        ]
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=methodology,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(r),
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            publisher_item_id=n,
            item_kind_text="Key Vote",
            title=r["title_text"],
            item_date_text=r["date_text"],
            chamber_text=chamber,
            congress_text=spec["congress"],
            bill_citation_text=next(iter(r["bill_citations"]), None),
            amendment_citation_text=next(iter(r["amendment_citations"]), None),
            references_json=json_column(references),
            publisher_position_text=r["position_text"],
            position_basis="explicit",
            position_source_path=location + "/position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id=key(chamber, "current"),
            item_id=identifier,
            participation_id="printed-key-vote",
            methodology_id=methodology,
            publisher_position_text=r["position_text"],
            position_basis="explicit",
        )
    for i, e in enumerate(data["members"]):
        r, chamber = e["record"], e["chamber"]
        location = path("members", i)
        member_key = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            period_text=front["period_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    k: r[k]
                    for k in [
                        "member_footnotes_text",
                        "publisher_row_text",
                        "guardian_award",
                        "nfib_member",
                    ]
                }
            ),
        )
        for period in ["current", "prior"]:
            value = r[period + "_value_text"]
            bundle.add(
                "scorecard_member_ratings",
                document,
                location + "/" + period + "_value_text",
                publisher_member_key=member_key,
                metric_id=key(chamber, period),
                value_text=value,
                value_number=decimal_text(value),
                value_status_text=value if value in {"N/A", "-"} else None,
            )
        meanings = {v["symbol_text"]: v["meaning_text"] for v in front[chamber.lower() + "_legend"]}
        for n, glyph in (r["item_results"] or {}).items():
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + "/item_results/" + n,
                result_id="printed-cell",
                publisher_member_key=member_key,
                item_id=key(chamber, n),
                metric_id=key(chamber, "current"),
                participation_id="printed-key-vote",
                result_text=glyph,
                reason_text=meanings[glyph],
            )
    repeated = context.read(spec["url"], stage=f"nfib-pdf:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete named original PDF; every printed member and source-defined key vote, current/prior score, footnote and available member glyph reconciles independent original observations; stable source reread",
        declared={
            "physical_pages": spec["page_count"],
            "members_by_chamber": spec["member_counts"],
            "members_by_physical_page": spec["page_counts"],
            "items_by_chamber": spec["item_counts"],
            "member_item_results_available": edition.edition_id == "118-final",
            "source_counts_basis": "complete original printed source grids, including former members and nonnumeric values",
        },
    )
