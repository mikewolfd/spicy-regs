"""Bounded public Quorum sheet inputs; publisher meaning remains in explicit readers."""

import csv
import io
import re
from dataclasses import dataclass
from urllib.parse import urlparse

from spicy_docs.sources.scorecards.common import (
    ScorecardContext,
    ScorecardSourceError,
    SourceDocument,
    json_data,
    soup,
)

HOSTS = ("www.quorum.us",)


def external_slug(document: SourceDocument) -> str:
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Publisher sheet wrapper does not reach HTML end")
    frames = soup(document).select("iframe")
    links = [frame.get("data-src") or frame.get("src") for frame in frames]
    selected = [urlparse(link) for link in links if link and "/spreadsheet/external/" in link]
    if len(selected) != 1:
        raise ScorecardSourceError("Publisher must select exactly one public Quorum sheet")
    link = selected[0]
    match = re.fullmatch("/spreadsheet/external/([A-Za-z]{10,80})/", link.path)
    if link.scheme != "https" or link.netloc != "www.quorum.us" or link.query or link.fragment or match is None:
        raise ScorecardSourceError("Publisher sheet is outside the reviewed public Quorum route")
    return match[1]


def json_url(slug: str) -> str:
    return "https://www.quorum.us/api/sheet/" + slug + "/?fetch_cache=true&archived=false"


def csv_url(slug: str) -> str:
    return "https://www.quorum.us/api/sheet/" + slug + "/?format=csv&archived=false&is_public_sheet_download=true"


def _positive_id(value):
    return type(value) is int and value > 0


@dataclass(frozen=True)
class PublicSheet:
    json_document: SourceDocument
    csv_document: SourceDocument
    data: dict
    columns: tuple[dict, ...]
    header: tuple[str, ...]
    csv_rows: tuple[tuple[str, ...], ...]


def decode(json_document: SourceDocument, csv_document: SourceDocument, slug: str) -> PublicSheet:
    data = json_data(json_document)
    if (
        not isinstance(data, dict)
        or data.get("is_public") is not True
        or data.get("public_password") is not None
        or data.get("archived") is not False
        or data.get("can_fit_in_memory") is not True
        or data.get("data_type") != "person"
        or data.get("public_slug") != slug
        or not _positive_id(data.get("id"))
        or not _positive_id(data.get("row_count"))
        or not isinstance(data.get("row_data"), list)
        or len(data["row_data"]) != data["row_count"]
        or not isinstance(data.get("rows"), dict)
        or not isinstance(data.get("name"), str)
        or not data["name"]
        or not isinstance(data.get("columns"), list)
        or not data["columns"]
    ):
        raise ScorecardSourceError("Quorum public sheet population or complete-cache shape changed")
    identities, names = set(), set()
    for member in data["row_data"]:
        if (
            not isinstance(member, dict)
            or not _positive_id(member.get("id"))
            or member["id"] in identities
            or not all(
                isinstance(member.get(field), str) and member[field] for field in ("firstname", "lastname", "name")
            )
            or member["name"] in names
        ):
            raise ScorecardSourceError("Quorum source member population repeats or lacks exact identity")
        identities.add(member["id"])
        names.add(member["name"])
    column_ids, orders = set(), set()
    for column in data["columns"]:
        if (
            not isinstance(column, dict)
            or not _positive_id(column.get("id"))
            or column["id"] in column_ids
            or type(column.get("order")) is not int
            or column["order"] < 0
            or column["order"] in orders
            or not isinstance(column.get("name"), str)
            or not column["name"]
            or type(column.get("should_hide_column_on_public")) is not bool
            or column.get("archived") is not False
            or not isinstance(column.get("data"), dict)
            or not isinstance(column.get("source_columns"), list)
        ):
            raise ScorecardSourceError("Quorum source column identity, ordering, cache or visibility changed")
        for identifier, value in column["data"].items():
            if not re.fullmatch("[1-9][0-9]*", identifier) or not (
                value is None or type(value) is int or isinstance(value, str)
            ):
                raise ScorecardSourceError("Quorum column cache contains an unreviewed cell shape")
        column_ids.add(column["id"])
        orders.add(column["order"])
    columns = tuple(sorted(data["columns"], key=lambda column: column["order"]))
    expected_header = [data["name"]] + [c["name"] for c in columns if not c["should_hide_column_on_public"]]
    try:
        rows = list(csv.reader(io.StringIO(csv_document.body.decode("utf-8-sig"), newline=""), strict=True))
    except (UnicodeError, csv.Error) as error:
        raise ScorecardSourceError("Quorum source CSV is malformed") from error
    if (
        not rows
        or rows[0] != expected_header
        or len(rows) != data["row_count"] + 1
        or any(len(row) != len(expected_header) for row in rows)
        or any(row[0] != member["name"] for row, member in zip(rows[1:], data["row_data"], strict=True))
    ):
        raise ScorecardSourceError("Quorum CSV edition, visible columns or complete member order differs from JSON")
    return PublicSheet(
        json_document, csv_document, data, columns, tuple(rows[0]), tuple(tuple(row) for row in rows[1:])
    )


def acquire(context: ScorecardContext, slug: str, stage: str) -> PublicSheet:
    document = context.read(json_url(slug), stage=stage + ":json", hosts=HOSTS)
    exported = context.read(csv_url(slug), stage=stage + ":csv", hosts=HOSTS)
    return decode(document, exported, slug)


def semantic_facts(sheet: PublicSheet):
    # Cache maintenance updates these transport metadata timestamps independently
    # of source values. They remain retained in the original captures.
    def stable(value):
        if isinstance(value, dict):
            return {key: stable(item) for key, item in value.items() if key not in {"created", "updated"}}
        if isinstance(value, list):
            return [stable(item) for item in value]
        return value

    return stable(sheet.data), sheet.header, sheet.csv_rows


def member_context(member, sheet: PublicSheet, csv_row):
    match = re.search(r"\(([A-Za-z]+)-([A-Z]{2})(?:-(.+))?\)$", member["name"])
    if match is None:
        raise ScorecardSourceError("Quorum publisher member display identity changed")
    values = dict(zip(sheet.header, csv_row, strict=True))
    state = values.get("State", values.get("State Abbreviation"))
    if state != match[2]:
        raise ScorecardSourceError("Quorum source state fields disagree")
    return {
        "name": member["firstname"] + " " + member["lastname"],
        "display_name": member["name"],
        "party": values.get("Party", match[1]),
        "state": state,
        "district": values.get("District Number", match[3]),
        "csv_values": values,
    }


def column_metadata(column: dict, roster_ids: set[str]):
    return {
        **{field: value for field, value in column.items() if field != "data"},
        "cache_outside_selected_roster": {
            identifier: value for identifier, value in column["data"].items() if identifier not in roster_ids
        },
    }


def append_measurements(
    bundle, sheet: PublicSheet, chamber: str, selected_types: set[str], primary_ids: set[int], units: dict[int, str]
):
    """Copy caller-selected numeric columns and source formula links; never evaluate them."""
    from spicy_docs.schemas.tables import json_column
    from spicy_docs.sources.scorecards.common import decimal_text, key

    document = sheet.json_document
    roster_ids = {str(member["id"]) for member in sheet.data["row_data"]}
    positions = {column["id"]: position for position, column in enumerate(sheet.data["columns"])}
    visible = {
        column["id"]: position
        for position, column in enumerate((c for c in sheet.columns if not c["should_hide_column_on_public"]), 1)
    }
    metrics = {
        column["id"]: key(chamber, str(column["id"]))
        for column in sheet.columns
        if column["column_type"] in selected_types
    }
    for column in sheet.columns:
        if column["id"] not in metrics:
            continue
        path = "$.columns[" + str(positions[column["id"]]) + "]"
        methodology_id = key(chamber, "quorum-column", str(column["id"]))
        metadata = column_metadata(column, roster_ids)
        metadata["cache_null_member_ids"] = [
            identifier for identifier, value in column["data"].items() if value is None and identifier in roster_ids
        ]
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=methodology_id,
            chamber_text=chamber,
            methodology_text=json_column(metadata),
            disclosure_status="explicit",
        )
        bundle.metric(
            document,
            metrics[column["id"]],
            column["name"],
            path=path,
            chamber=chamber,
            unit=units.get(column["id"]),
            primary=column["id"] in primary_ids,
        )
        bundle.tables["scorecard_metrics"][-1].update(methodology_id=methodology_id, period_text=sheet.data["name"])
        for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True), 2):
            identifier = str(member["id"])
            if column["id"] in visible:
                value = row[visible[column["id"]]]
                source = sheet.csv_document
                locator = f"CSV/row={ordinal}/column={visible[column['id']] + 1}"
                if value == "":
                    continue
            else:
                native = column["data"].get(identifier)
                if native is None:
                    continue
                value = str(native)
                source = document
                locator = path + ".data[" + repr(identifier) + "]"
            if decimal_text(value) is None:
                raise ScorecardSourceError("Selected Quorum numeric measurement contains a nondecimal source value")
            bundle.add(
                "scorecard_member_ratings",
                source,
                locator,
                publisher_member_key=key(chamber, identifier),
                metric_id=metrics[column["id"]],
                value_text=value,
                value_number=decimal_text(value),
            )
    for column in sheet.columns:
        if column["id"] not in metrics:
            continue
        dependencies = [("source_columns", ref) for ref in column["source_columns"]]
        dependencies += [(field, column.get(field)) for field in ("first_column", "second_column") if column.get(field)]
        observed = set()
        for field, reference in dependencies:
            match = re.fullmatch("/api/column/([1-9][0-9]*)/", reference)
            if match is None or int(match[1]) not in metrics or int(match[1]) in observed:
                raise ScorecardSourceError("Quorum formula references an unreviewed or repeated measurement dependency")
            observed.add(int(match[1]))
            bundle.add(
                "scorecard_metric_components",
                document,
                "$.columns[" + str(positions[column["id"]]) + "]." + field,
                parent_metric_id=metrics[column["id"]],
                component_metric_id=metrics[int(match[1])],
                combination_rule_text=json_column(
                    {"column_type": column["column_type"], "source_field": field, "reference": reference}
                ),
            )
    return metrics
