"""Humane World Action Fund's complete final 2025 PDF, both chamber charts.

The injected Docling pipeline reads displayed symbols. Raw font extraction tokens
are refused; they cannot be silently converted into publisher results. Complete
chamber charts are checked against retained, visually qualified page boundaries.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    pdf,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "humane-final-2025-docling-displayed-glyphs/2"
SEMANTIC_PARSER_VERSION = "humane-final-2025-qualified-semantic/3"
SOURCE_SHA256 = "fee179fb27e7200434c9c2c547faaa6dd666367fa8429609a3ef2d747f9e1498"
QUALIFIED_SHA256 = "562aa0c35383d352c77afdea274b2cd2203e9df7f9784213fba65f13dcbd955e"
HOSTS = ("humaneaction.org",)
URL = "https://humaneaction.org/sites/default/files/2026-02/FINAL%20humane-scorecard-2025.pdf"
EDITION = ScorecardEdition(
    "humane_world_action", "2025-final", URL, "2025 Humane Scorecard", year="2025", chamber="both"
)
HEADERS = {
    "Senate": ("AWA enforcement co-sponsor", "Leader", "Score"),
    "House": (
        "AWA enforcement co-sponsor",
        "Puppy mills co-sponsor",
        "Horse slaughter co-sponsor",
        "Endangered species vote",
        "Wolves vote",
        "USDA/FDA animal welfare letter",
        "Horse slaughter defund letter",
        "Animal Protection Caucus",
        "Leader",
        "Score",
    ),
}
KINDS = {
    "co-sponsor": "cosponsorship",
    "vote": "roll call",
    "letter": "letter",
    "Caucus": "caucus membership",
    "Leader": "leadership",
}
RAW_FONT_TOKENS = frozenset({"ü", "ê", "\x02", "\uf0fc", "\uf0ab"})
TOKENS = {"", "✓", "★", "SP", "X", "NV", "NV*", "•", "••", "•••", "#", "##", "###"}
REASONS = {
    "NV": "Did not vote due to absence or abstention",
    "NV*": "Put statement in Congressional Record (and notified us) indicating missed vote but would have voted pro-animal",
    "#": "Filled seat during term",
    "##": "Resigned during term",
    "###": "Passed away during term",
    "••": "The top leaders of each party typically don't co-sponsor bills and the Speaker of the House doesn't vote, so they have no numerical scores",
    "•": "Delegates from U.S. territories and the District of Columbia cannot vote on bills or amendments on the House floor unless they are taken in the Committee of the Whole",
}
# Reviewed final-2025 report chart boundaries; private qualification receipt 2026-10-03.
PAGE_MEMBERS = {6: 34, 7: 32, 8: 34, 12: 62, 13: 61, 14: 58, 15: 56, 16: 60, 17: 54, 18: 63, 19: 30}
MEMBER = re.compile(r"^(.+) \(([RDI])(?:-(.+))?\)$")
RESULT_KEYS = {
    "Senate": ("awa", "leader"),
    "House": (
        "awa",
        "puppy",
        "horse",
        "endangered_species",
        "wolves",
        "usda_fda_letter",
        "horse_letter",
        "caucus",
        "leader",
    ),
}


@dataclass(frozen=True, slots=True)
class HumaneReader:
    """Reviewed semantic facts, retained privately and pinned to their original PDF."""

    parser_version: ClassVar[str] = SEMANTIC_PARSER_VERSION
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        source = context.read(URL, stage="scorecards:humane:listing", hosts=HOSTS)
        if sha256(source.body).hexdigest() != SOURCE_SHA256:
            raise ScorecardSourceError("Humane qualified final PDF changed; source requalification required")
        return (EDITION,)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _semantic_charts(data: dict, observation_id: str) -> dict:
    """Check member/action facts without converting them into a visual table."""
    try:
        if (
            data["format_version"] != "humane-qualified-final-2025/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 20
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
            or [entry["evidence"]["physical_page"] for entry in data["methodology"]] != [5, 9, 10, 11]
        ):
            raise ValueError
        observed = dict.fromkeys(PAGE_MEMBERS, 0)
        charts = {"Senate": [], "House": []}
        previous_page = 0
        for position, entry in enumerate(data["members"]):
            record, evidence = entry["record"], entry["evidence"]
            page = evidence["physical_page"]
            chamber = "Senate" if page <= 8 else "House"
            if (
                page not in observed
                or page < previous_page
                or entry["chamber"] != chamber
                or not all(
                    isinstance(record[f], str) and record[f]
                    for f in ("member_name_text", "state_text", "party_text", "score_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or (
                    chamber == "House" and (not isinstance(record["district_text"], str) or not record["district_text"])
                )
                or set(record["results"]) != set(RESULT_KEYS[chamber])
                or re.fullmatch(r"(?:\d+\+?|••|#{1,3})", record["score_text"]) is None
                or any(not isinstance(v, str) or decode_result(v) not in TOKENS for v in record["results"].values())
                or any(
                    re.fullmatch(r"[a-f0-9]{64}", evidence[f]) is None for f in ("outcome_sha256", "observation_sha256")
                )
                or re.fullmatch(r"/members/\d+", evidence["json_pointer"]) is None
            ):
                raise ValueError
            observed[page] += 1
            previous_page = page
            path = f"pdf:page={page};observation={observation_id};/members/{position}/record"
            charts[chamber].append(
                (
                    path,
                    record["state_text"],
                    (record["member_name_text"], record["party_text"], record["district_text"]),
                    [record["results"][k] for k in RESULT_KEYS[chamber]],
                    record["score_text"],
                )
            )
        if observed != PAGE_MEMBERS:
            raise ValueError
        for rows in charts.values():
            if len({(state, member[0], member[2]) for _, state, member, _, _ in rows}) != len(rows):
                raise ValueError
        methods = data["methodology"]
        if any(
            not isinstance(m["record"], str)
            or not m["record"]
            or re.fullmatch(r"[a-f0-9]{64}", m["evidence"]["observation_sha256"]) is None
            for m in methods
        ):
            raise ValueError
        return {
            chamber: (
                charts[chamber],
                "\n".join(methods[i]["record"] for i in positions),
                ";".join(
                    f"pdf:page={methods[i]['evidence']['physical_page']};observation={observation_id};/methodology/{i}/record"
                    for i in positions
                ),
                f"pdf:page={6 if chamber == 'Senate' else 12};observation={observation_id}",
            )
            for chamber, positions in (("Senate", (0,)), ("House", (1, 2, 3)))
        }
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("Humane reviewed semantic records fail the qualified edition shape") from None


def _item_fields(chamber: str, header: str, method: str) -> dict[str, str]:
    """Literal source citations and positions; no inferred roll-call identifiers."""
    citations = {
        ("Senate", "AWA enforcement co-sponsor"): "S. 1538",
        ("House", "AWA enforcement co-sponsor"): "H.R. 3112",
        ("House", "Puppy mills co-sponsor"): "H.R. 2253",
        ("House", "Horse slaughter co-sponsor"): "H.R. 1661",
        ("House", "Endangered species vote"): "H.R. 3838",
        ("House", "Wolves vote"): "H.R. 845",
    }
    fields = {}
    citation = citations.get((chamber, header))
    if citation is not None:
        if citation not in method:
            raise ScorecardSourceError("Humane disclosed bill citation changed")
        fields["bill_citation_text"] = citation
        paragraph = next((p for p in method.split("\n\n") if p.startswith("A ✓ indicates") and citation in p), None)
        if paragraph is None:
            raise ScorecardSourceError("Humane disclosed preferred action changed")
        fields["publisher_position_text"] = paragraph
    if header == "Endangered species vote":
        if "floor amendment (#29)" not in method:
            raise ScorecardSourceError("Humane disclosed amendment citation changed")
        fields["amendment_citation_text"] = "floor amendment (#29)"
    return fields


def _identity(document):
    if (
        document.page_count != 20
        or "The 119th Congress, First Session" not in document[0].text
        or "Humane" not in document[0].text
    ):
        raise ScorecardSourceError("Humane PDF is not the qualified final 2025 edition")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    source = context.read(URL, stage="scorecards:humane:listing", hosts=HOSTS)
    with pdf(source, context, expected_pages=20) as document:
        _identity(document)
    return (EDITION,)


def decode_result(raw: str) -> str:
    """Only displayed symbols are accepted from OCR; font-code guessing is refused."""
    if any(code in raw for code in RAW_FONT_TOKENS):
        raise ScorecardSourceError("Humane extraction contains undecoded font tokens")
    return raw


def parse_chart(document, chamber):
    pages = range(5, 8) if chamber == "Senate" else range(11, 19)
    rows = []
    state = None
    for page_index in pages:
        page = document[page_index]
        source_text = " ".join(page.text.split())
        if (
            any(header not in source_text for header in HEADERS[chamber])
            or f"Key to {chamber} Chart" not in source_text
        ):
            raise ScorecardSourceError("Humane chart headers or legend changed")
        selected = [
            (i, table)
            for i, table in enumerate(page.tables, 1)
            if any(row and row[0] and MEMBER.fullmatch(row[0]) for row in table.cells)
        ]
        if len(selected) != 1:
            raise ScorecardSourceError("Humane chart is no longer one complete recognized table")
        table_index, table = selected[0]
        page_members = []
        for index, cells in enumerate(table.cells, 1):
            if len(cells) != len(HEADERS[chamber]) + 1 or not cells[0]:
                raise ScorecardSourceError("Humane chart cell geometry changed")
            # A model-stated column header is not a member or state; exact source
            # headings keep the parser from treating an arbitrary row as a header.
            if tuple(" ".join((cell or "").split()) for cell in cells[1:]) == HEADERS[chamber]:
                continue
            match = MEMBER.fullmatch(cells[0])
            if match is None:
                if any(cells[1:]) or "\n" in cells[0] or "(" in cells[0]:
                    raise ScorecardSourceError("Humane chart has an unrecognized member/state row")
                state = cells[0]
                continue
            if state is None or any(cell is None for cell in cells):
                raise ScorecardSourceError("Humane member lacks source state or a chart cell")
            page_members.append(cells[0])
            decoded = [decode_result(value) for value in cells[1:-1]]
            if set(decoded) - TOKENS or not re.fullmatch(r"(?:\d+\+?|••|#{1,3})", cells[-1]):
                raise ScorecardSourceError("Humane chart introduced an unknown result or score marker")
            rows.append((page.path(table=table_index, row=index), state, match.groups(), decoded, cells[-1]))
        if len(page_members) != PAGE_MEMBERS[page.number]:
            raise ScorecardSourceError("Humane recognized chart is truncated or repeats source members")
    identities = [(state, name[0], name[2]) for _, state, name, _, _ in rows]
    if len(set(identities)) != len(rows) or not rows:
        raise ScorecardSourceError("Humane chart repeats source member identities")
    return rows


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION:
        raise ScorecardSourceError("Humane reader supports only the final 2025 PDF layout")
    source = context.read(URL, stage="scorecards:humane:final-pdf", hosts=HOSTS)
    semantic = qualified_observations is not None or retain_observations is not None
    if semantic:
        if qualified_observations is None or retain_observations is None:
            raise ScorecardSourceError("Humane semantic records require an explicit private retention callback")
        observation_id = retain_qualified(
            source,
            qualified_observations,
            retain_observations,
            source_sha256=SOURCE_SHA256,
            observations_sha256=QUALIFIED_SHA256,
            stage="humane:qualified-final-2025",
        )
        chambers = _semantic_charts(json.loads(qualified_observations), observation_id)
    else:
        chambers = {}
        with pdf(source, context, expected_pages=20) as document:
            _identity(document)
            for chamber in ("Senate", "House"):
                pages = [4] if chamber == "Senate" else [8, 9, 10]
                chambers[chamber] = (
                    parse_chart(document, chamber),
                    "\n".join(document[i].text for i in pages),
                    ";".join(document[i].path() for i in pages),
                    document[5 if chamber == "Senate" else 11].path(),
                )
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Humane World Action Fund",
        parser_version=SEMANTIC_PARSER_VERSION if semantic else parser_version,
        rendition_rule="humane-reviewed-final-semantic-facts/1" if semantic else "humane-final-pdf-displayed-glyphs/1",
        homepage="https://humaneaction.org",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    for chamber, (chart, method, method_path, header_path) in chambers.items():
        metric_id = chamber.lower() + ":score"
        method_id = chamber.lower() + ":method"
        bundle.add(
            "scorecard_methodologies",
            source,
            method_path,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_text=method,
            methodology_url=URL,
            disclosure_status="partial",
        )
        bundle.metric(source, metric_id, "Score", path=header_path + "/heading[Score]", chamber=chamber)
        for column, header in enumerate(HEADERS[chamber][:-1], 1):
            item_id = key(chamber, header)
            kind = next((value for suffix, value in KINDS.items() if header.endswith(suffix)), "other")
            path = header_path + f"/chart/column[{column + 1}]/heading"
            source_fields = _item_fields(chamber, header, method) if semantic else {}
            if source_fields.get("publisher_position_text"):
                source_fields.update(position_basis="explicit", position_source_path=method_path)
            bundle.add(
                "scorecard_items",
                source,
                path,
                item_id=item_id,
                item_kind_text=kind,
                title=header,
                chamber_text=chamber,
                **source_fields,
            )
            bundle.add(
                "scorecard_metric_items",
                source,
                path,
                metric_id=metric_id,
                item_id=item_id,
                participation_id="chart",
                methodology_id=method_id,
                publisher_position_text=source_fields.get("publisher_position_text"),
                position_basis=source_fields.get("position_basis"),
            )
        for path, state, member, results, score in chart:
            name, party, district = member
            member_id = key(chamber, state, name, district) if district else key(chamber, state, name)
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=member_id,
                member_name=name,
                state=state,
                party=party,
                district=district,
                chamber_text=chamber,
                eligibility_text=REASONS.get(score),
            )
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/Score",
                metric_id=metric_id,
                publisher_member_key=member_id,
                value_text=score,
                value_number=decimal_text(score),
                notes_text=REASONS.get(score),
            )
            for column, (header, result) in enumerate(zip(HEADERS[chamber][:-1], results, strict=True), 1):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + f"/column[{column + 1}]",
                    item_id=key(chamber, header),
                    metric_id=metric_id,
                    participation_id="chart",
                    publisher_member_key=member_id,
                    result_id="chart",
                    result_text=result,
                    reason_text=REASONS.get(result),
                )
    return bundle.finish(
        "Final PDF has all expected pages, chamber methods, chart headers and legends; every "
        "qualified page boundary on all Senate and House charts reconciles to its member rows. Every "
        "published chart cell, including blank and excluded results, is retained as displayed. "
        "Semantic source observations, reviewed corrections and processing identity are retained "
        "privately when selected; undecoded font tokens refuse."
    )
