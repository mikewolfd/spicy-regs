"""AFL-CIO's official 2025 workbooks and publisher item pages.

Repeated H.R. 4 columns are matched using Mark Amodei's publisher-reported result
at the two dated item URLs. An ambiguous witness refuses the complete edition.
"""

from __future__ import annotations

import io
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict
from urllib.parse import urlencode, urljoin

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
    soup,
)
from spicy_docs.transport.captured import CapturedBodyResponse

parser_version = "afl-cio-2025-workbooks/1"
HOSTS = ("aflcio.org",)
BASE = "https://aflcio.org"
INDEX = BASE + "/scorecard/votes"
WITNESS = BASE + "/scorecard/legislators/mark-amodei"
EDITION = ScorecardEdition(
    "afl_cio", "2025", BASE + "/scorecard", "AFL-CIO Legislative Scorecard 2025", year="2025", chamber="both"
)
NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
GLYPHS = {"Right": "✓", "Wrong": "ｘ", "Absent": "◯"}


def _column(number):
    value = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        value = chr(65 + remainder) + value
    return value


def parse_workbook(body: bytes, chamber: str):
    try:
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            infos = archive.infolist()
            if (
                len(infos) > 1000
                or sum(info.file_size for info in infos) > 100 * 1024 * 1024
                or len({info.filename for info in infos}) != len(infos)
            ):
                raise ScorecardSourceError("AFL workbook exceeds expanded bounds or repeats ZIP members")
            if archive.testzip() is not None:
                raise ScorecardSourceError("AFL workbook ZIP integrity failed")

            def xml(path):
                data = archive.read(path)
                if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
                    raise ScorecardSourceError("AFL workbook XML contains unsupported declarations")
                return ET.fromstring(data)

            if len(xml("xl/workbook.xml").findall("x:sheets/x:sheet", NS)) != 1:
                raise ScorecardSourceError("AFL workbook has an unexpected worksheet set")
            strings = ["".join(e.itertext()) for e in xml("xl/sharedStrings.xml")]
            sheet = xml("xl/worksheets/sheet1.xml")
            dimension = sheet.find("x:dimension", NS)
            if dimension is None:
                raise ScorecardSourceError("AFL workbook does not declare a complete cell range")
            rows = []
            for index, row in enumerate(sheet.findall("x:sheetData/x:row", NS), 1):
                if row.get("r") != str(index):
                    raise ScorecardSourceError("AFL workbook row coordinates are discontinuous")
                values = []
                for column, cell in enumerate(row.findall("x:c", NS), 1):
                    if cell.get("r") != _column(column) + str(index) or cell.find("x:f", NS) is not None:
                        raise ScorecardSourceError("AFL workbook cells moved or contain an unhandled formula")
                    value = cell.find("x:v", NS)
                    raw = value.text if value is not None and value.text is not None else ""
                    if cell.get("t") == "s":
                        raw = strings[int(raw)]
                    elif cell.get("t") not in {None, "n"}:
                        raise ScorecardSourceError("AFL workbook cell encoding changed")
                    values.append(raw)
                rows.append(values)
    except (zipfile.BadZipFile, KeyError, IndexError, ET.ParseError, ValueError) as error:
        if isinstance(error, ScorecardSourceError):
            raise
        raise ScorecardSourceError("AFL workbook cannot be read completely") from error
    prefix = ["Name", "State"] + (["District"] if chamber == "House" else []) + ["Party", "Score", "Lifetime Score"]
    if (
        len(rows) < 2
        or rows[0][: len(prefix)] != prefix
        or len(rows[0]) <= len(prefix)
        or any(len(row) != len(rows[0]) for row in rows)
        or dimension.get("ref") != f"A1:{_column(len(rows[0]))}{len(rows)}"
    ):
        raise ScorecardSourceError("AFL workbook header, cell rectangle or declared dimension changed")
    if any(value not in {"✓", "ｘ", "◯", ""} for row in rows[1:] for value in row[len(prefix) :]):
        raise ScorecardSourceError("AFL workbook introduced an unknown member result glyph")
    return rows, len(prefix)


def _fold(value):
    return " ".join(value.split())


def _base_title(value):
    return _fold(re.sub(r"\s+\((?:H\.|S\.|PN)\S*.*\)$", "", value))


def _links(html, chamber):
    links = {}
    for row in html.select("table tbody tr"):
        anchor = row.select_one("td.views-field-title a[href]")
        if anchor is None:
            raise ScorecardSourceError("AFL item index row lacks its source item link")
        url = urljoin(BASE, anchor["href"])
        if f"/scorecard/votes/2025/{chamber.lower()}/" not in url:
            raise ScorecardSourceError("AFL key-vote index contains a different edition")
        links[url] = _fold(anchor.get_text(" ", strip=True))
    if not links or html.select(".pager__item--next, .pager-next"):
        raise ScorecardSourceError("AFL key-vote index is empty or not terminal")
    return links


def _index(context):
    source = context.read(INDEX, stage="scorecards:afl:index", hosts=HOSTS)
    html = soup(source)
    selected = html.select_one("select.scorecard-year option")
    if selected is None or selected.get("value") != "2025":
        raise ScorecardSourceError("AFL current index year changed")
    return source, html


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context)
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("AFL reader supports only the qualified 2025 export layout")
    index, html = _index(context)
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="AFL-CIO",
        parser_version=parser_version,
        rendition_rule="afl-workbook-literal-ratings-results-item-pages-methods/1",
        homepage=BASE,
    )
    house_links = _links(html, "House")
    view = html.select_one(".view-scorecard-key-votes")
    dom_ids = (
        [c.removeprefix("js-view-dom-id-") for c in view.get("class", []) if c.startswith("js-view-dom-id-")]
        if view
        else []
    )
    if len(dom_ids) != 1:
        raise ScorecardSourceError("AFL public view identity changed")
    query = urlencode(
        {
            "view_name": "scorecard_key_votes",
            "view_display_id": "votes_list",
            "view_args": "2025/Senate",
            "view_path": "/node/4341",
            "view_dom_id": dom_ids[0],
            "pager_element": "0",
            "_wrapper_format": "drupal_ajax",
        }
    )
    senate_index = context.read(BASE + "/views/ajax?" + query, stage="scorecards:afl:senate-index", hosts=HOSTS)
    try:
        parts = [
            row["data"]
            for row in json.loads(senate_index.body)
            if isinstance(row.get("data"), str) and "<table" in row["data"]
        ]
    except (ValueError, TypeError) as error:
        raise ScorecardSourceError("AFL public Senate view is malformed") from error
    if len(parts) != 1:
        raise ScorecardSourceError("AFL public Senate view contains an unexpected table set")
    rendered = SourceDocument(
        senate_index.capture_id,
        CapturedBodyResponse(
            senate_index.url, senate_index.url, 200, "text/html", senate_index.response.observed_at, parts[0].encode()
        ),
    )
    senate_links = _links(soup(rendered), "Senate")
    bundle.use(index, "House_item_catalog")
    bundle.use(senate_index, "Senate_item_catalog")
    witness = context.read(WITNESS, stage="scorecards:afl:duplicate-column-witness", hosts=HOSTS)
    witness_html = soup(witness)
    if witness_html.select_one("h1").get_text(" ", strip=True) != "Rep. Mark Amodei":
        raise ScorecardSourceError("AFL repeated-column witness member changed")
    witness_results = {}
    for row in witness_html.select("table tbody tr"):
        anchor = row.select_one("td.views-field-title a[href]")
        result = row.select_one("td.views-field-right-wrong span")
        if anchor and result:
            witness_results[urljoin(BASE, anchor["href"])] = GLYPHS.get(result.get_text(strip=True))
    bundle.use(witness, "repeated_item_identity")
    for chamber, links in (("House", house_links), ("Senate", senate_links)):
        source = context.read(
            BASE + f"/scorecard/export/2025/{chamber.lower()}?_format=xlsx",
            stage="scorecards:afl:workbook",
            hosts=HOSTS,
        )
        bundle.use(source, chamber + "_members_ratings_results")
        rows, offset = parse_workbook(source.body, chamber)
        if len(rows[0]) - offset != len(links):
            raise ScorecardSourceError("AFL item listing and workbook column counts disagree")
        for metric in ("annual", "lifetime"):
            bundle.metric(
                source,
                chamber.lower() + ":" + metric,
                rows[0][offset - (2 if metric == "annual" else 1)],
                path=f"xlsx/sheet1/row1/{metric}",
                chamber=chamber,
                unit="%",
                primary=metric == "annual",
            )
        by_title = defaultdict(list)
        for url, title in links.items():
            by_title[title].append(url)
        probe = next((row for row in rows[1:] if row[0] == "Rep. Mark Amodei" and row[1] == "NV"), None)
        item_ids = []
        used_urls = set()
        for column, header in enumerate(rows[0][offset:], offset):
            candidates = by_title.get(_base_title(header), [])
            if len(candidates) > 1 and probe:
                candidates = [url for url in candidates if witness_results.get(url) == probe[column]]
            if len(candidates) != 1 or candidates[0] in used_urls:
                raise ScorecardSourceError("AFL workbook item-to-URL crosswalk is ambiguous")
            url = candidates[0]
            used_urls.add(url)
            item_id = key(chamber, url.rsplit("/", 1)[-1])
            item_ids.append(item_id)
            detail = context.read(url, stage="scorecards:afl:item", hosts=HOSTS)
            bundle.use(detail, "item:" + item_id)
            page = soup(detail)
            title = page.select_one("h1.scorecard-title")
            subtitle = page.select_one("h6.scorecard-title")
            if title is None or subtitle is None or _fold(title.get_text(" ", strip=True)) != links[url]:
                raise ScorecardSourceError("AFL item page identity changed")
            date_and_bill = subtitle.get_text(" ", strip=True).split("|", 1)
            position_node = page.select_one(".scorecard_vote .col-md-8")
            description = position_node.get_text(" ", strip=True) if position_node else ""
            target = re.search(r"Working people (supported|opposed)", description)
            if target is None:
                raise ScorecardSourceError("AFL item page lacks its publisher position")
            kind = (
                "letter"
                if header.startswith("Letter ")
                else "nomination"
                if header.startswith("Nomination ")
                else "legislative action"
            )
            bundle.add(
                "scorecard_items",
                detail,
                "h1.scorecard-title + h6.scorecard-title",
                item_id=item_id,
                publisher_item_id=url,
                item_kind_text=kind,
                title=title.get_text(" ", strip=True),
                item_date_text=date_and_bill[0].strip(),
                chamber_text=chamber,
                bill_citation_text=date_and_bill[1].strip() if len(date_and_bill) > 1 else None,
                publisher_position_text=target.group(1),
                position_basis="explicit",
                position_source_path=".scorecard_vote .col-md-8",
            )
            methodology_id = item_id + ":method"
            bundle.add(
                "scorecard_methodologies",
                detail,
                ".scorecard_vote .col-md-8",
                methodology_id=methodology_id,
                chamber_text=chamber,
                methodology_text=description,
                methodology_url=url,
                disclosure_status="partial",
            )
            bundle.add(
                "scorecard_metric_items",
                detail,
                "h1.scorecard-title",
                metric_id=chamber.lower() + ":annual",
                item_id=item_id,
                participation_id="workbook",
                methodology_id=methodology_id,
                publisher_position_text=target.group(1),
                position_basis="explicit",
            )
        for position, row in enumerate(rows[1:], 2):
            member_id = key(chamber, *row[: offset - 3])
            path = f"xlsx/xl/worksheets/sheet1.xml/row[{position}]"
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=member_id,
                member_name=row[0],
                state=row[1],
                district=row[2] if chamber == "House" else None,
                party=row[offset - 3],
                chamber_text=chamber,
            )
            for metric, value in zip(("annual", "lifetime"), row[offset - 2 : offset], strict=True):
                if not re.fullmatch(r"\d+%", value):
                    raise ScorecardSourceError("AFL workbook introduced an unknown rating representation")
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    path + "/" + metric,
                    metric_id=chamber.lower() + ":" + metric,
                    publisher_member_key=member_id,
                    value_text=value,
                    value_number=decimal_text(value),
                )
            for column, (item_id, value) in enumerate(zip(item_ids, row[offset:], strict=True), offset + 1):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + f"/cell[{_column(column)}{position}]",
                    metric_id=chamber.lower() + ":annual",
                    item_id=item_id,
                    participation_id="workbook",
                    publisher_member_key=member_id,
                    result_id="workbook",
                    result_text=value,
                )
    return bundle.finish(
        "Both official XLSX exports pass ZIP integrity, single-sheet identity and their complete "
        "declared cell rectangles; every item column reconciles to the terminal publisher item "
        "catalog. The repeated H.R.4 columns are uniquely matched by Mark Amodei's dated source "
        "results. Every rating and every result cell, including blanks, is retained."
    )
