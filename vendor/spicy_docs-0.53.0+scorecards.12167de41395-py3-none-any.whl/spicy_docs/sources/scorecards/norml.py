"""NORML's original continuing federal-incumbent grades and disclosed supporting actions."""

import re
from hashlib import sha256
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "norml-current-federal-html/1"
INDEX = "https://vote.norml.org/"
ABOUT = INDEX + "about"
HOSTS = ("vote.norml.org",)
EDITION = ScorecardEdition("norml", "federal-incumbents", INDEX, "NORML's Smoke the Vote", chamber="both")
GRADE = re.compile(r"(?:[ABCDF][+-]?|\?)")
OFFICE = re.compile(r"U\.S\. House District (\d+|Delegate|At-Large)")
# The original discovery page and Massachusetts guide use these distinct spellings.
# Keep the discovery literal; permit only this observed publisher cross-page alias.
GUIDE_LABEL_ALIASES = {("MA", "Massachussetts"): "Massachusetts"}


def _html(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("NORML source does not reach HTML document end")
    return soup(document)


def _index(document):
    html = _html(document)
    links = html.select("ul.state-list a[href]")
    if not links:
        raise ScorecardSourceError("NORML complete state guide list is missing")
    result = []
    for link in links:
        match = re.fullmatch(r"states/([A-Z]{2})", link["href"])
        name = link.get_text("", strip=True)
        if match is None or not name:
            raise ScorecardSourceError("NORML state guide discovery link changed")
        result.append((match[1], name, urljoin(INDEX, link["href"])))
    if len({row[0] for row in result}) != len(result):
        raise ScorecardSourceError("NORML repeats a state guide identity")
    return result


def _methods(document):
    nodes = _html(document).select("#main .padded-container")
    if len(nodes) != 1:
        raise ScorecardSourceError("NORML federal grading methodology is missing")
    text = nodes[0].get_text(" ", strip=True)
    grades = [li.get_text("", strip=True) for li in nodes[0].select("li")]
    if (
        "For Federal Incumbents, they are graded as:" not in text
        or len(grades) != 5
        or any(
            not grade.startswith(("An" if letter in "AF" else "A") + " '" + letter + "' letter grade")
            for letter, grade in zip("ABCDF", grades, strict=True)
        )
    ):
        raise ScorecardSourceError("NORML federal incumbent grading rubric changed")
    return text, grades


def _guide(document, state, state_name):
    html = _html(document)
    titles = html.select("#main-container .huge-title-inner")
    elected = html.select("#bg-container > #elected")
    if (
        len(titles) != 1
        or titles[0].get_text("", strip=True) != GUIDE_LABEL_ALIASES.get((state, state_name), state_name) + " Guide"
        or len(elected) != 1
        or elected[0].get_text("", strip=True) != "Your Elected Officials"
    ):
        raise ScorecardSourceError("NORML elected guide scope or state label changed")
    rows = []
    identities = set()
    excluded = 0
    positions = {
        id(node): position for position, node in enumerate(html.select("#bg-container .race-container .candidate"), 1)
    }
    for race in elected[0].find_next_siblings("div"):
        if "race-container" not in race.get("class", []):
            continue
        labels = race.select(".race-title")
        if len(labels) != 1:
            raise ScorecardSourceError("NORML current officeholder race label is missing")
        office = labels[0].get_text("", strip=True)
        match = OFFICE.fullmatch(office)
        if office != "U.S. Senate" and match is None:
            if office.startswith("U.S."):
                raise ScorecardSourceError("NORML acquired an unreviewed federal office shape")
            excluded += len(race.select(".candidate"))
            continue
        candidates = race.select(".candidate")
        if not candidates:
            raise ScorecardSourceError("NORML federal incumbent race has no disclosed member")
        for candidate in candidates:
            anchors = candidate.select(".candidate-name > a[href]")
            scores = candidate.select(".candidate-score")
            parties = candidate.select(".candidate-name > span")
            identifier = re.fullmatch(r"/politicians/(\d+)", anchors[0]["href"]) if len(anchors) == 1 else None
            if identifier is None or len(scores) != 1 or len(parties) != 1 or identifier[1] in identities:
                raise ScorecardSourceError("NORML source member identity repeats or is incomplete")
            name = anchors[0].get_text("", strip=True)
            score = scores[0].get_text("", strip=True)
            party = re.fullmatch(r"\(([A-Z]+)\)", parties[0].get_text("", strip=True))
            if not name or not GRADE.fullmatch(score) or party is None:
                raise ScorecardSourceError("NORML literal member grade or party form changed")
            identities.add(identifier[1])
            ordinal = positions[id(candidate)]
            rows.append(
                {
                    "id": identifier[1],
                    "name": name,
                    "score": score,
                    "party": party[1],
                    "state": state,
                    "office": office,
                    "chamber": "House" if match else "Senate",
                    "district": match[1] if match else None,
                    "source_position": ordinal,
                    "tags": [tag.get_text("", strip=True) for tag in candidate.select(".tags .tag")],
                    "text": " ".join(
                        node.get_text("", strip=False).strip() for node in candidate.select(".candidate-text")
                    ),
                    "url": urljoin(INDEX, anchors[0]["href"]),
                }
            )
    if not rows:
        raise ScorecardSourceError("NORML state guide contains no federal incumbent observations")
    return rows, excluded


def _profile(document, member):
    html = _html(document)
    names = html.select("#politician-name")
    offices = html.select("#info-container .extra-info")
    if len(names) != 1 or len(offices) != 1:
        raise ScorecardSourceError("NORML member profile identity or office is missing")
    scores = names[0].select(".candidate-score")
    fragments = names[0].find_all("span", recursive=False)
    if len(scores) != 1 or len(fragments) != 2 or scores[0].get_text("", strip=True) != member["score"]:
        raise ScorecardSourceError("NORML member grade differs between complete guide and profile")
    name = fragments[1].get_text("", strip=True)
    if (
        name != member["name"] + " (" + member["party"] + " - " + member["state"] + ")"
        or offices[0].get_text(" ", strip=True) != "Holds office " + member["office"]
    ):
        raise ScorecardSourceError("NORML profile identity or current office differs from state guide")
    items = []
    contexts = []
    sections = html.select("#main > .section")
    for section_ordinal, section in enumerate(sections, 1):
        labels = section.select(".section-title")
        if len(labels) != 1:
            raise ScorecardSourceError("NORML profile section label changed")
        label = labels[0].get_text("", strip=True)
        section_path = (
            f"(//*[@id='main']/div[contains(concat(' ',normalize-space(@class),' '),' section ')])[{section_ordinal}]"
        )
        if label in {"Address"} or label.startswith("Contact "):
            continue
        links = [{"href": a["href"], "text": a.get_text("", strip=False).strip()} for a in section.select("a[href]")]
        contexts.append(
            {
                "label": label,
                "text": section.get_text("", strip=False).strip(),
                "links": links,
                "source_path": section_path,
            }
        )
        if label in {"Co-sponsored Legislation", "Sponsored Legislation"}:
            # Publisher-authored blocks mix paragraphs, divs and bare text. A block
            # can cite multiple bills; preserve the compound source occurrence.
            items.append(
                {
                    "section": label,
                    "title": label,
                    "result": label,
                    "href": None,
                    "references_text": contexts[-1]["text"],
                    "links": links,
                    "source_path": section_path,
                    "ordinal": section_ordinal,
                }
            )
            continue
        if label not in {"Votes", "Vote Smart Key Votes"}:
            if label not in {
                "Comments",
                "Biography",
                "Position on Marijuana Legalization",
                "Position on Marijuana Decriminalization",
                "Position on Medical Marijuana",
            }:
                raise ScorecardSourceError("NORML member profile contains an unreviewed supporting source section")
            continue
        grids = section.select(".vote-section")
        if len(grids) != 1:
            raise ScorecardSourceError("NORML supporting vote section is missing or repeated")
        for ordinal, row in enumerate(grids[0].select(".vote-row"), 1):
            titles = row.select(".vote-name")
            results = row.select(".vote-result")
            if len(titles) != 1 or len(results) != 1:
                raise ScorecardSourceError("NORML disclosed vote observation is incomplete")
            title = titles[0].get_text("", strip=False).strip()
            result = results[0].get_text("", strip=True)
            vote_links = [
                {"href": a["href"], "text": a.get_text("", strip=False).strip()} for a in titles[0].select("a[href]")
            ]
            if (
                not title
                or not result
                or len(vote_links) > 1
                or label == "Vote Smart Key Votes"
                and (
                    len(vote_links) != 1
                    or re.fullmatch(r"https://votesmart\.org/bill/\d+", vote_links[0]["href"]) is None
                )
            ):
                raise ScorecardSourceError("NORML disclosed vote title, action or source link changed")
            items.append(
                {
                    "section": label,
                    "title": title,
                    "result": result,
                    "href": vote_links[0]["href"] if vote_links else None,
                    "links": vote_links,
                    "references_text": title,
                    "source_path": section_path + f"//div[@class='vote-row'][{ordinal}]",
                    "ordinal": ordinal,
                }
            )
    blurbs = html.select("#info-container #blurb")
    if len(blurbs) != 1:
        raise ScorecardSourceError("NORML profile position summary is missing or repeated")
    return {
        "items": items,
        "contexts": contexts,
        "blurb": blurbs[0].get_text("", strip=False).strip(),
        "tags": [tag.get_text("", strip=True) for tag in names[0].select(".tags .tag")],
    }


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="scorecards:norml:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("NORML reader supports its continuing current federal-incumbent source series")
    index = context.read(INDEX, stage="scorecards:norml:index", hosts=HOSTS)
    states = _index(index)
    method = context.read(ABOUT, stage="scorecards:norml:methodology", hosts=HOSTS)
    methods = _methods(method)
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="NORML",
        parser_version=parser_version,
        rendition_rule="norml-complete-current-federal-guides-and-profiles/1",
        homepage="https://norml.org/",
    )
    bundle.use(index, "state_guide_universe")
    bundle.use(method, "grading_methodology")
    periods = json_column(
        [
            {
                "occurrence_id": "current-officeholders",
                "period_text": "Your Elected Officials",
                "kind": "relative",
                "source_path": states[0][2] + "#//*[@id='elected']",
            }
        ]
    )
    bundle.tables["scorecards"][0].update(publisher_edition_key=None, edition_label_text=None, periods_json=periods)
    bundle.metric(
        method,
        "federal_grade",
        "Federal Incumbent Grade",
        path="//*[@id='main']//div[@class='padded-container']",
        chamber="both",
        unit="grade",
    )
    bundle.tables["scorecard_metrics"][-1]["methodology_id"] = "federal-grading-rubric"
    bundle.tables["scorecard_metrics"][-1]["periods_json"] = periods
    bundle.add(
        "scorecard_methodologies",
        method,
        "//*[@id='main']//div[@class='padded-container']",
        methodology_id="federal-grading-rubric",
        methodology_text=methods[0],
        methodology_url=ABOUT,
        disclosure_status="partial",
    )
    guides, profiles, items, identities = {}, {}, {}, set()
    declared = {
        "state_guides": len(states),
        "source_scope": "Publisher-linked state guide federal incumbents; continuing current-officeholder series",
        "state_discovery_labels": {state: name for state, name, _ in states},
    }
    for state, name, url in states:
        document = context.read(url, stage="scorecards:norml:guide:" + state, hosts=HOSTS)
        rows, excluded = _guide(document, state, name)
        guides[state] = (document, name, rows, excluded)
        declared[state + ":federal_members"] = len(rows)
        declared[state + ":excluded_nonfederal_officials"] = excluded
        bundle.use(document, key(state, "federal_members_and_ratings"))
        for member in rows:
            if member["id"] in identities:
                raise ScorecardSourceError("NORML repeats a federal incumbent across source state guides")
            identities.add(member["id"])
            member_key = key(state, member["chamber"], member["id"])
            path = f"(//*[@id='bg-container']//div[contains(concat(' ',normalize-space(@class),' '),' candidate ')])[{member['source_position']}]"
            bundle.add(
                "scorecard_members",
                document,
                path,
                publisher_member_key=member_key,
                publisher_member_id=member["id"],
                member_name=member["name"],
                state=state,
                district=member["district"],
                party=member["party"],
                chamber_text=member["chamber"],
                period_text="Your Elected Officials",
                notes_text=json_column(
                    {
                        "office": member["office"],
                        "policy_tags": member["tags"],
                        "publisher_comment": member["text"],
                        "profile_url": member["url"],
                    }
                ),
            )
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + "//span[@class='candidate-score']",
                publisher_member_key=member_key,
                metric_id="federal_grade",
                value_text=member["score"],
            )
            profile = context.read(member["url"], stage="scorecards:norml:profile:" + member["id"], hosts=HOSTS)
            facts = _profile(profile, member)
            profiles[member_key] = (profile, member, facts)
            bundle.use(profile, key(member_key, "supporting_actions"))
            for item in facts["items"]:
                identity = (member["id"], item["section"], item["source_path"])
                item_id = key(member["chamber"], item["section"], sha256(json_column(identity).encode()).hexdigest())
                item_path = item["source_path"]
                if item_id not in items:
                    references = []
                    for occurrence, match in enumerate(
                        re.finditer(
                            r"\b(?:H\.?\s*R\.?|H\.?\s*J\.?\s*R\.?|H\.?\s*C\.?\s*R\.?|S\.?\s*J\.?\s*R\.?|S\.?\s*C\.?\s*R\.?|S\.?|H\s+Amdt)\s*\d+\b",
                            item["references_text"],
                        )
                    ):
                        kind = "amendment" if "Amdt" in match[0] else "bill"
                        references.append(
                            {
                                "occurrence_id": key("title", str(occurrence)),
                                "kind": kind,
                                "citation_text": match[0],
                                kind + "_citation_text": match[0],
                                "source_path": item_path,
                            }
                        )
                    for link_ordinal, link in enumerate(item["links"], 1):
                        official = re.match(
                            r"https://www\.congress\.gov/bill/(\d+)\w*-congress/([a-z-]+)/(\d+)(?:/|\?|$)", link["href"]
                        )
                        references.append(
                            {
                                "occurrence_id": key("source-link", str(link_ordinal)),
                                "kind": "bill" if official else "external",
                                "citation_text": link["href"],
                                **(
                                    {"bill_citation_text": link["text"], "congress_text": official[1]}
                                    if official
                                    else {}
                                ),
                                "source_path": f"({item_path}//a)[{link_ordinal}]/@href",
                            }
                        )
                    year = re.match(r"(20\d\d):", item["title"])
                    bundle.add(
                        "scorecard_items",
                        profile,
                        item_path,
                        item_id=item_id,
                        item_kind_text=item["section"],
                        title=item["title"],
                        item_date_text=year[1] if year else None,
                        chamber_text=member["chamber"],
                        references_json=json_column(references),
                        position_basis="absent",
                    )
                    items[item_id] = identity
                elif items[item_id] != identity:
                    raise ScorecardSourceError("NORML derived source item identity collided")
                bundle.add(
                    "scorecard_member_item_results",
                    profile,
                    item_path,
                    item_id=item_id,
                    publisher_member_key=member_key,
                    result_id="publisher-disclosed",
                    result_text=item["result"],
                    action_text=item["result"],
                    reason_text=item["section"],
                )
            if facts["contexts"] or facts["blurb"] or facts["tags"]:
                bundle.add(
                    "scorecard_methodologies",
                    profile,
                    "//*[@id='main']",
                    methodology_id=key(member_key, "publisher-context"),
                    methodology_text=json_column(
                        {"sections": facts["contexts"], "summary": facts["blurb"], "policy_tags": facts["tags"]}
                    ),
                    disclosure_status="partial",
                )
    for state, (document, name, rows, excluded) in guides.items():
        repeated = context.read(
            document.response.requested_url, stage="scorecards:norml:reread:guide:" + state, hosts=HOSTS
        )
        if _guide(repeated, state, name) != (rows, excluded):
            raise ScorecardSourceError("NORML current federal guide facts changed during acquisition")
        bundle.use(repeated, key(state, "federal_members_and_ratings"), role="corroboration")
    for member_key, (document, member, facts) in profiles.items():
        repeated = context.read(
            document.response.requested_url, stage="scorecards:norml:reread:profile:" + member["id"], hosts=HOSTS
        )
        if _profile(repeated, member) != facts:
            raise ScorecardSourceError("NORML federal member profile facts changed during acquisition")
        bundle.use(repeated, key(member_key, "supporting_actions"), role="corroboration")
    repeated_index = context.read(INDEX, stage="scorecards:norml:reread:index", hosts=HOSTS)
    repeated_method = context.read(ABOUT, stage="scorecards:norml:reread:methodology", hosts=HOSTS)
    if _index(repeated_index) != states or _methods(repeated_method) != methods:
        raise ScorecardSourceError(
            "NORML source state guide universe or grading methodology changed during acquisition"
        )
    bundle.use(repeated_index, "state_guide_universe", role="corroboration")
    bundle.use(repeated_method, "grading_methodology", role="corroboration")
    return bundle.finish(
        "Every publisher-linked state guide reached document EOF; all source federal current-officeholder cards parsed with unique IDs; grade/identity/office corroborates in every original profile; disclosed votes, compound sponsorship/cosponsorship blocks and qualitative profile context preserved with no inferred grading participation or target positions; full guide/profile/methodology facts agree on stable reread",
        declared=declared,
    )
