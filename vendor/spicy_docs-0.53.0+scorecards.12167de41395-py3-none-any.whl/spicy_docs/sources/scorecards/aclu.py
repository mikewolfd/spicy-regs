"""ACLU's original federal scorecard HTML bootstrap and publisher display rules."""

import base64
import binascii
import re
from dataclasses import replace
from math import floor
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    json_data,
    key,
    soup,
)

parser_version = "aclu-federal-bootstrap/1"
INDEX = "https://www.aclu.org/congressional-scorecards"
HOSTS = ("www.aclu.org",)
EDITION = ScorecardEdition("aclu", "119", INDEX, "Congressional Scorecards", congress="119", chamber="both")
APP = "#aclu-scorecards-app/@data-legislators:base64-json"
MEMBER_FIELDS = {
    "id",
    "quorum_id",
    "name",
    "lastname",
    "state",
    "party",
    "role",
    "district",
    "photo",
    "phone",
    "current",
    "number_of_terms",
    "aligned_votes",
    "total_votes",
}
ITEM_FIELDS = {
    "id",
    "quorum_id",
    "title",
    "label",
    "aclu_description_short",
    "aclu_description",
    "aclu_position_summary",
    "aclu_position",
    "issues",
    "is_amendment",
    "status_text",
    "status_date",
}
VOTE_FIELDS = {"bill_id", "vote", "aligned", "issues", "title", "status_text", "status_date", "aclu_description"}
NAME = re.compile(r"(?:Commish\.|Del\.|Leader|Rep\.|Sen\.|Speaker|Whip) (.+) \(([A-Z]+)-([A-Z]{2})(?:-(\d+))?\)")
CITATION = re.compile(r"(?:H\.(?:R\.|Con\.Res\.|J\.Res\.|Res\.)|S\.(?:Amdt\.|J\.Res\.|Con\.Res\.|Res\.)?)\s*\d+")
ROLE = {"1": "Senate", "2": "House"}
POSITION = {"0": "ACLU Opposed", "1": "ACLU Supported"}
VOTE_ALIGNMENTS = {
    ("yea", "aligned"),
    ("nay", "aligned"),
    ("yea", "not aligned"),
    ("nay", "not aligned"),
    ("other", "did not vote"),
}
DISPLAY_RULES = (
    'zs={1:"Senator",2:"Representative"}',
    '3747:"US 119th Congress (2025-2026)"',
    "Js=3747",
    'r.legislator.total_votes?(x(),O("h2",',
    'Math.floor(r.legislator.aligned_votes/r.legislator.total_votes*100))+"% ",',
    "votes have aligned with ACLU values during the 119th Congress",
    "r.bill.aclu_position==0?",
    '" ACLU Opposed "',
    "r.bill.aclu_position==1?",
    '" ACLU Supported "',
    'r.vote.vote=="other"?',
    '" Not counted in scorecard. "',
)


def _html(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("ACLU HTML document is incomplete")
    return soup(document)


def _bootstrap(document):
    html = _html(document)
    apps = html.select("#aclu-scorecards-app[data-legislators]")
    if len(apps) != 1:
        raise ScorecardSourceError("ACLU source bootstrap is missing or repeated")
    try:
        decoded = base64.b64decode(apps[0]["data-legislators"], validate=True)
    except (ValueError, binascii.Error) as error:
        raise ScorecardSourceError("ACLU source bootstrap is invalid base64") from error
    data = json_data(SourceDocument(document.capture_id, replace(document.response, body=decoded)))
    if (
        not isinstance(data, dict)
        or set(data) != {"legislators", "bills"}
        or not isinstance(data["legislators"], list)
        or not data["legislators"]
        or not isinstance(data["bills"], list)
        or not data["bills"]
    ):
        raise ScorecardSourceError("ACLU complete member and item arrays are missing")
    for item in data["bills"]:
        if (
            not isinstance(item, dict)
            or set(item) != ITEM_FIELDS
            or any(not isinstance(value, str) for value in item.values())
            or not re.fullmatch(r"[1-9]\d*", item["id"])
            or not re.fullmatch(r"[1-9]\d*", item["quorum_id"])
            or not item["title"]
            or not item["label"]
            or item["is_amendment"] not in {"0", "1"}
            or item["aclu_position"] not in POSITION
            or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", item["status_date"])
        ):
            raise ScorecardSourceError("ACLU publisher item fields changed")
    for field in ("id", "quorum_id"):
        if len({row[field] for row in data["bills"]}) != len(data["bills"]):
            raise ScorecardSourceError("ACLU publisher item identity repeats")
    return html, data


def _script_url(html):
    scripts = [
        urljoin(INDEX, node["src"])
        for node in html.select("script[src]")
        if "/wp-content/plugins/aclu-scorecards/dist/assets/js/main.js" in node["src"]
    ]
    if len(scripts) != 1:
        raise ScorecardSourceError("ACLU publisher scorecard renderer is missing or repeated")
    return scripts[0]


def _renderer(document):
    try:
        text = document.body.decode("utf-8")
    except UnicodeError as error:
        raise ScorecardSourceError("ACLU publisher renderer is not UTF-8") from error
    if any(rule not in text for rule in DISPLAY_RULES):
        raise ScorecardSourceError("ACLU publisher percentage, Congress, position or exclusion display rule changed")
    return DISPLAY_RULES


def _member(row, *, detail=False):
    expected = MEMBER_FIELDS | ({"votes"} if detail else set())
    if detail and isinstance(row, dict) and row.get("role") == "2":
        expected |= {"district_name"}
    if not isinstance(row, dict) or set(row) != expected:
        raise ScorecardSourceError("ACLU member identity fields changed")
    for name in MEMBER_FIELDS - {"aligned_votes", "total_votes", "district"}:
        if not isinstance(row[name], str):
            raise ScorecardSourceError("ACLU member literal field is not text")
    match = NAME.fullmatch(row["name"])
    if (
        match is None
        or row["role"] not in ROLE
        or row["current"] != "1"
        or not re.fullmatch(r"[1-9]\d*", row["id"])
        or not re.fullmatch(r"[1-9]\d*", row["quorum_id"])
        or (
            row["district"] is not None
            and (not isinstance(row["district"], str) or not re.fullmatch(r"[1-9]\d*", row["district"]))
        )
        or (row["role"] == "1") != (match[3] is not None and match[4] is None)
    ):
        raise ScorecardSourceError("ACLU federal current member context changed")
    if detail and row["role"] == "2" and not isinstance(row["district_name"], str):
        raise ScorecardSourceError("ACLU publisher geographic district label changed")
    for field in ("aligned_votes", "total_votes"):
        value = row[field]
        if detail:
            valid = type(value) is int and value >= 0
        else:
            valid = value is None or (isinstance(value, str) and re.fullmatch(r"\d+", value))
        if not valid:
            raise ScorecardSourceError("ACLU source counter is invalid")
    if detail and (not isinstance(row["votes"], list) or row["aligned_votes"] > row["total_votes"]):
        raise ScorecardSourceError("ACLU detail votes or counters changed")
    return match[1], match[2], match[3], match[4]


def _roster(data):
    for row in data["legislators"]:
        _member(row)
    for field in ("id", "quorum_id"):
        if len({row[field] for row in data["legislators"]}) != len(data["legislators"]):
            raise ScorecardSourceError("ACLU complete roster repeats a source member identity")
    return data["legislators"]


def _detail(data, roster, items):
    if data["bills"] != items or len(data["legislators"]) != 1:
        raise ScorecardSourceError("ACLU detail item catalog or member scope differs from complete index")
    row = data["legislators"][0]
    _member(row, detail=True)
    for field in MEMBER_FIELDS:
        if field in {"aligned_votes", "total_votes"}:
            # The publisher index gives non-voting delegates null counters; detail gives 0.
            if not (roster[field] is None and row[field] == 0) and str(row[field]) != str(roster[field]):
                raise ScorecardSourceError("ACLU index and member detail counters disagree")
        elif row[field] != roster[field]:
            raise ScorecardSourceError("ACLU index and member detail identity disagree")
    catalog = {item["quorum_id"]: item for item in items}
    seen = set()
    for vote in row["votes"]:
        if (
            not isinstance(vote, dict)
            or set(vote) != VOTE_FIELDS
            or any(not isinstance(value, str) for value in vote.values())
            or vote["bill_id"] not in catalog
            or vote["bill_id"] in seen
            or (vote["vote"], vote["aligned"]) not in VOTE_ALIGNMENTS
        ):
            raise ScorecardSourceError("ACLU member vote identity, action or alignment changed")
        seen.add(vote["bill_id"])
        if any(
            vote[field] != catalog[vote["bill_id"]][field] for field in VOTE_FIELDS - {"bill_id", "vote", "aligned"}
        ):
            raise ScorecardSourceError("ACLU member vote description differs from complete item catalog")
    if (
        sum(vote["aligned"] == "aligned" for vote in row["votes"]) != row["aligned_votes"]
        or sum(vote["vote"] != "other" for vote in row["votes"]) != row["total_votes"]
    ):
        raise ScorecardSourceError("ACLU source counters do not reconcile to complete disclosed member results")
    return row


def list_scorecards(context: ScorecardContext):
    document = context.read(INDEX, stage="aclu-discovery", hosts=HOSTS)
    html, data = _bootstrap(document)
    _roster(data)
    script = context.read(_script_url(html), stage="aclu-discovery-renderer", hosts=HOSTS)
    _renderer(script)
    return [EDITION]


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("ACLU reader only accepts the publisher-stated current 119th Congress")
    index = context.read(INDEX, stage="aclu-index", hosts=HOSTS)
    html, data = _bootstrap(index)
    roster = _roster(data)
    script_url = _script_url(html)
    script = context.read(script_url, stage="aclu-publisher-renderer", hosts=HOSTS)
    _renderer(script)
    documents = []
    members = []
    for member in roster:
        document = context.read(INDEX + "?legislator=" + member["id"], stage="aclu-member-" + member["id"], hosts=HOSTS)
        _, detail = _bootstrap(document)
        documents.append(document)
        members.append(_detail(detail, member, data["bills"]))
    for original, member in zip(documents[:], members, strict=True):
        repeat = context.read(original.response.requested_url, stage="aclu-stable-member-" + member["id"], hosts=HOSTS)
        _, detail = _bootstrap(repeat)
        if detail["legislators"] != [member] or detail["bills"] != data["bills"]:
            raise ScorecardSourceError("ACLU member or item source changed during acquisition")
        documents.append(repeat)
    repeat_index = context.read(INDEX, stage="aclu-stable-index", hosts=HOSTS)
    repeat_html, repeat_data = _bootstrap(repeat_index)
    repeat_script = context.read(script_url, stage="aclu-stable-renderer", hosts=HOSTS)
    if repeat_data != data or _script_url(repeat_html) != script_url or repeat_script.body != script.body:
        raise ScorecardSourceError("ACLU current source population or display rule changed during acquisition")

    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="American Civil Liberties Union",
        parser_version=parser_version,
        rendition_rule="complete embedded index and every member bootstrap; publisher-owned renderer; all repeat stably",
        homepage="https://www.aclu.org/",
    )
    bundle.use(index, "roster", "items")
    bundle.use(script, "publisher-display-rules")
    bundle.use(repeat_index, "roster", "items", role="corroboration")
    bundle.use(repeat_script, "publisher-display-rules", role="corroboration")
    period = "US 119th Congress (2025-2026)"
    periods = json_column(
        [
            {
                "occurrence_id": "selected-congress",
                "period_text": period,
                "kind": "explicit",
                "congress_text": "119",
                "source_path": "script/Gs/3747;Js",
            }
        ]
    )
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None, edition_label_text=period, periods_json=periods, methodology_url=script.url
    )
    method = "publisher-display"
    bundle.add(
        "scorecard_methodologies",
        script,
        "script/publisher-display",
        methodology_id=method,
        methodology_text=json_column(
            {
                "source_display_expressions": list(DISPLAY_RULES),
                "percentage": "Publisher-rendered Math.floor(aligned_votes/total_votes*100)%, shown only for positive detail total_votes.",
                "scope": "Current source roster includes members without results. Missing member/item rows are not generated.",
                "dates": "status_date is the native item status date, not an identified roll-call date; browser date formatting may differ.",
                "identities": "state, party, role and district are publisher/Quorum enum or geographic IDs; printed name context is retained separately.",
                "methodology": "Underlying vote selection and counter construction are not disclosed in this rendition.",
            }
        ),
        methodology_url=script.url,
        disclosure_status="partial",
    )
    for identifier, name, unit, primary in (
        ("alignment-percent", "votes have aligned with ACLU values during the 119th Congress", "%", True),
        ("aligned-votes", "aligned_votes", None, False),
        ("total-votes", "total_votes", None, False),
    ):
        bundle.metric(
            script, identifier, name, path="script/publisher-display/" + identifier, unit=unit, primary=primary
        )
        bundle.tables["scorecard_metrics"][-1].update(methodology_id=method, period_text=period, periods_json=periods)
    item_ids = {}
    for ordinal, item in enumerate(data["bills"]):
        path = APP + "/bills/" + str(ordinal)
        item_id = key(edition.scorecard_id, "item", item["id"])
        item_ids[item["quorum_id"]] = item_id
        references = []
        for occurrence, match in enumerate(CITATION.finditer(item["label"])):
            literal = match[0]
            amendment = literal.startswith("S.Amdt.")
            references.append(
                {
                    "occurrence_id": str(occurrence + 1),
                    "citation_text": literal,
                    "kind": "amendment" if amendment else "bill",
                    "source_path": path + "/label",
                    "amendment_citation_text": literal if amendment else None,
                    "bill_citation_text": None if amendment else literal,
                }
            )
        bills = [row["bill_citation_text"] for row in references if row["bill_citation_text"]]
        amendments = [row["amendment_citation_text"] for row in references if row["amendment_citation_text"]]
        bundle.add(
            "scorecard_items",
            index,
            path,
            item_id=item_id,
            publisher_item_id=item["id"],
            item_kind_text="amendment" if item["is_amendment"] == "1" else "bill",
            title=item["title"],
            item_date_text=item["status_date"],
            bill_citation_text=bills[0] if len(bills) == 1 else None,
            amendment_citation_text=amendments[0] if len(amendments) == 1 else None,
            references_json=json_column(references),
            publisher_position_text=POSITION[item["aclu_position"]],
            position_basis="explicit publisher bootstrap code, labeled by publisher renderer",
            position_source_path=path + "/aclu_position;script/aclu_position",
        )
        bundle.add(
            "scorecard_methodologies",
            index,
            path,
            methodology_id=key("item", item["id"]),
            methodology_text=json_column(item),
            methodology_url=INDEX,
            disclosure_status="partial",
        )
        bundle.add(
            "scorecard_metric_items",
            index,
            path,
            metric_id="alignment-percent",
            item_id=item_id,
            participation_id="published-catalog",
            methodology_id=method,
            publisher_position_text=POSITION[item["aclu_position"]],
            position_basis="explicit publisher bootstrap code, labeled by publisher renderer",
            counts_toward_metric=None,
        )
    cell_count = 0
    observed_items = set()
    for ordinal, (member, roster_member) in enumerate(zip(members, roster, strict=True)):
        document = documents[ordinal]
        repeat = documents[len(members) + ordinal]
        group = "member-" + member["id"]
        bundle.use(document, group)
        bundle.use(repeat, group, role="corroboration")
        path = APP + "/legislators/0"
        name, party, state, district = _member(member, detail=True)
        member_key = key(edition.scorecard_id, "member", member["id"])
        bundle.add(
            "scorecard_members",
            document,
            path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            identifiers_json=json_column([{"scheme": "quorum", "value": member["quorum_id"]}]),
            member_name=name,
            chamber_text=ROLE[member["role"]],
            party=party,
            state=state,
            district=district,
            period_text=period,
            eligibility_text="current=" + member["current"],
            notes_text=json_column(
                {
                    "index": roster_member,
                    "detail_context": {field: value for field, value in member.items() if field != "votes"},
                    "percentage_available": member["total_votes"] > 0,
                }
            ),
        )
        for metric_id, field in (("aligned-votes", "aligned_votes"), ("total-votes", "total_votes")):
            value = str(member[field])
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + "/" + field,
                metric_id=metric_id,
                publisher_member_key=member_key,
                value_text=value,
                value_number=value,
                notes_text="Literal member-detail counter; complete-index counter is retained in member notes.",
            )
        if member["total_votes"]:
            # Preserve the publisher JavaScript's binary64 division/multiplication order.
            value = str(floor(member["aligned_votes"] / member["total_votes"] * 100))
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + ";script/publisher-display/alignment-percent",
                metric_id="alignment-percent",
                publisher_member_key=member_key,
                value_text=value + "%",
                value_number=value,
                notes_text="Publisher-owned display expression, independently qualified against original rendered member views; not a replacement score calculation.",
            )
        for vote_ordinal, vote in enumerate(member["votes"]):
            cell_count += 1
            observed_items.add(vote["bill_id"])
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + "/votes/" + str(vote_ordinal),
                result_id="source-vote",
                metric_id="alignment-percent",
                item_id=item_ids[vote["bill_id"]],
                participation_id="published-catalog",
                publisher_member_key=member_key,
                action_text=vote["vote"],
                result_text=vote["aligned"],
                counts_toward_metric="false" if vote["vote"] == "other" else "true",
                eligibility_text="Not counted in scorecard." if vote["vote"] == "other" else None,
            )
    return bundle.finish(
        "Complete HTML EOF; unique complete bootstrap roster and catalog; every roster member detail loaded; catalogs/identities/counters reconcile; all member facts, roster and publisher renderer repeat stably. Only disclosed member/item rows are retained.",
        declared={
            "bootstrap_members": len(roster),
            "bootstrap_items": len(data["bills"]),
            "detail_members": len(members),
            "disclosed_member_item_results": cell_count,
            "items_with_disclosed_results": len(observed_items),
            "items_without_disclosed_results": [
                item["id"] for item in data["bills"] if item["quorum_id"] not in observed_items
            ],
            "members_without_published_percentage": sum(member["total_votes"] == 0 for member in members),
        },
    )
