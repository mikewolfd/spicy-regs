"""Americans for Prosperity's current federal scorecard; original public API literals."""

from .rds_bt50 import Publisher, acquire_current, list_current

parser_version = "afp-rds-bt50-current-api/1"
PUBLISHER = Publisher(
    "afp",
    "Americans for Prosperity",
    "https://americansforprosperity.org/",
    "https://americansforprosperity.org/national-scorecard/",
    3933,
    "119th Congressional Scorecard",
    parser_version,
)
EDITION = PUBLISHER.edition


def list_scorecards(context):
    return list_current(context, PUBLISHER)


def acquire_scorecard(edition, context):
    return acquire_current(edition, context, PUBLISHER)
