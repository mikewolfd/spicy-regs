"""AEA's publisher-selected DataTables API: complete Congress members and actions."""

import re
from urllib.parse import urlencode

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "aea-original-datatables/1"
INDEX = "https://www.americanenergyalliance.org/american-energy-scorecard/"
ABOUT = "https://www.americanenergyalliance.org/about-the-energy-scorecard/"
API = "https://www.americanenergyalliance.org/wp-admin/admin-ajax.php"
SENATE = INDEX + "?spage=senate"
HOSTS = ("www.americanenergyalliance.org",)
EDITION = ScorecardEdition(
    "american_energy_alliance", "119", INDEX, "The American Energy Scorecard", congress="119", chamber="both"
)
CHAMBERS = {"house": "House", "senate": "Senate"}
PAGE_SIZE = 500
FIELDS = {
    "house": ("state", "district", "name", "party", "score"),
    "senate": ("state", "senate_class", "name", "party", "score", "full_term_score"),
    "chamber-votes": ("roll_call", "vote_title", "description", "position", "id"),
    "chamber-bills": ("billNumber", "short_title", "description", "position"),
    "member-votes": ("roll_call", "vote_title", "description", "position", "repPosition"),
    "member-co-sponsorship": ("billNumber", "short_title", "description", "position", "repPosition"),
}


def request_parameters(table, *, start=0, **selection):
    if table not in FIELDS:
        raise ScorecardSourceError("AEA request table is outside the reviewed publisher API")
    params = {
        "action": "aea_datatable_action",
        "table": table,
        "congress": "119",
        "draw": "1",
        "start": str(start),
        "length": str(PAGE_SIZE),
        "search[value]": "",
        "search[regex]": "false",
        "order[0][column]": "0",
        "order[0][dir]": "asc",
        **selection,
    }
    for position, field in enumerate(FIELDS[table]):
        for suffix, value in {
            "data": field,
            "name": "",
            "searchable": "true",
            "orderable": "true",
            "search[value]": "",
            "search[regex]": "false",
        }.items():
            params[f"columns[{position}][{suffix}]"] = value
    return urlencode(params).encode()


def _count(value):
    if type(value) is int and value >= 0:
        return value
    if isinstance(value, str) and re.fullmatch(r"\d+", value):
        return int(value)
    raise ScorecardSourceError("AEA source count is not a nonnegative integer")


def _pages(context, table, *, stage, **selection):
    rows, documents, total, identities = [], [], None, set()
    for start in range(0, 20_000, PAGE_SIZE):
        document = context.read_request(
            API,
            method="POST",
            content=request_parameters(table, start=start, **selection),
            request_headers={"Content-Type": "application/x-www-form-urlencoded"},
            stage="scorecards:aea:" + stage + ":" + str(start),
            hosts=HOSTS,
        )
        value = json_data(document)
        if (
            not isinstance(value, dict)
            or set(value) != {"draw", "recordsTotal", "recordsFiltered", "data"}
            or type(value["draw"]) is not int
            or value["draw"] != 1
        ):
            raise ScorecardSourceError("AEA DataTables response is malformed or refers to another request")
        observed = _count(value["recordsTotal"])
        if observed != _count(value["recordsFiltered"]) or total is not None and total != observed:
            raise ScorecardSourceError("AEA unfiltered source counts disagree or change across pages")
        total = observed
        data = value["data"]
        if total >= 20_000 or not isinstance(data, list) or len(data) != min(PAGE_SIZE, total - start):
            raise ScorecardSourceError("AEA DataTables page does not reconcile with its declared total")
        documents.append(document)
        required = set(FIELDS[table]) | ({"congID"} if table in CHAMBERS else {"id"})
        for offset, row in enumerate(data):
            if not isinstance(row, dict) or set(row) != required:
                raise ScorecardSourceError("AEA row fields changed")
            identifier = row["congID"] if table in CHAMBERS else row["id"]
            if not isinstance(identifier, str) or not identifier or identifier in identities:
                raise ScorecardSourceError("AEA page repeats or omits a source identity")
            if any(not isinstance(v, str) for k, v in row.items() if k != "full_term_score"):
                raise ScorecardSourceError("AEA text field changed type")
            identities.add(identifier)
            rows.append((document, offset, row))
        if len(rows) == total:
            return rows, documents, total
    raise ScorecardSourceError("AEA pagination exceeds the reviewed record bound")


def _index(document):
    if re.search(rb"</html>\s*(?:<!--.*?-->\s*)*$", document.body, flags=re.IGNORECASE | re.DOTALL) is None:
        raise ScorecardSourceError("AEA index is incomplete HTML")
    html = soup(document)
    options = html.select("#session option[value='119']")
    text = " ".join(node.get_text() for node in html.select("script:not([src])") if "ajax_object" in node.get_text())
    if (
        len(options) != 1
        or options[0].get_text(" ", strip=True) != "2025 - 2026"
        or API not in text
        or "aea_datatable_action" not in text
    ):
        raise ScorecardSourceError("AEA Congress selection or publisher-selected API changed")
    return options[0].get_text(" ", strip=True)


def _methods(document):
    if re.search(rb"</html>\s*(?:<!--.*?-->\s*)*$", document.body, flags=re.IGNORECASE | re.DOTALL) is None:
        raise ScorecardSourceError("AEA methodology is incomplete HTML")
    nodes = soup(document).select("div.default-content")
    if len(nodes) != 1:
        raise ScorecardSourceError("AEA methodology container changed")
    texts = [node.get_text(" ", strip=True) for node in nodes[0].select("p")]
    if not any(text.startswith("The American Energy Scorecard includes two different components") for text in texts):
        raise ScorecardSourceError("AEA scoring methodology is absent")
    return texts


def _senate(document):
    _index(document)
    headings = [node.get_text(" ", strip=True).split(" ")[0:3] for node in soup(document).select("thead th")]
    if ["6", "YEAR", "SCORE"] not in headings:
        raise ScorecardSourceError("AEA Senate six-year score heading changed")
    return "6 YEAR SCORE"


def _use_pages(bundle, documents, group, *, role="primary"):
    for position, document in enumerate(documents):
        bundle.use(document, key(group, "page", str(position)), role=role)


def _facts(rows):
    return sorted((row for _, _, row in rows), key=lambda row: row.get("congID") or row["id"])


def _roll(row):
    match = re.fullmatch(r"(?:Roll Call\s+)?([HS])(\d+)-(20\d\d)", row["roll_call"], re.IGNORECASE)
    if match is None or match[3] not in {"2025", "2026"}:
        raise ScorecardSourceError("AEA roll-call citation is outside the selected Congress source dates")
    return match[1].upper(), match[2], match[3]


def _member(row, chamber):
    if (
        not re.fullmatch(r"[A-Z]\d{6}", row["congID"])
        or not re.fullmatch(r"[A-Z]{2}", row["state"])
        or decimal_text(row["score"]) is None
    ):
        raise ScorecardSourceError("AEA member identity or score changed")
    if chamber == "senate" and (type(row["full_term_score"]) is not int or row["full_term_score"] < 0):
        raise ScorecardSourceError("AEA six-year score changed from a literal nonnegative integer")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="scorecards:aea:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("AEA reader supports the explicit 119th Congress source selection")
    index = context.read(INDEX, stage="scorecards:aea:index", hosts=HOSTS)
    label = _index(index)
    method_source = context.read(ABOUT, stage="scorecards:aea:methodology", hosts=HOSTS)
    methods = _methods(method_source)
    senate_source = context.read(SENATE, stage="scorecards:aea:senate-heading", hosts=HOSTS)
    six_year_label = _senate(senate_source)
    captured = {}
    for chamber in CHAMBERS:
        for table in (chamber, "chamber-votes", "chamber-bills"):
            captured[chamber, table] = _pages(context, table, stage=chamber + ":" + table, chamber=chamber)
        if not captured[chamber, chamber][0]:
            raise ScorecardSourceError("AEA chamber member population is empty")
    primary = captured["house", "house"][1][0]
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="American Energy Alliance",
        parser_version=parser_version,
        rendition_rule="aea-original-congress-datatables/1",
        homepage="https://www.americanenergyalliance.org/",
    )
    bundle.use(index, "congress_period")
    bundle.use(method_source, "methodology")
    bundle.use(senate_source, "senate_heading")
    periods = [
        {
            "occurrence_id": "selected-congress",
            "kind": "explicit",
            "period_text": label,
            "congress_text": "119",
            "source_path": "//select[@id='session']/option[@value='119']",
        }
    ]
    bundle.tables["scorecards"][0].update(edition_label_text=label, periods_json=json_column(periods))
    for position, text in enumerate(methods):
        if text:
            bundle.add(
                "scorecard_methodologies",
                method_source,
                f"//div[contains(@class,'default-content')]/p[{position + 1}]",
                methodology_id=key("paragraph", str(position)),
                methodology_text=text,
                methodology_url=ABOUT,
                disclosure_status="partial",
            )
    method_position = next(
        position
        for position, text in enumerate(methods)
        if text.startswith("The American Energy Scorecard includes two different components")
    )
    methodology_id = key("paragraph", str(method_position))
    definitions, member_results, declared = {}, {}, {}
    for chamber, chamber_name in CHAMBERS.items():
        score_metric = key(chamber, "current_congress")
        document = captured[chamber, chamber][1][0]
        bundle.metric(
            document,
            score_metric,
            "Current Congress Score",
            path="$.data[*].score",
            chamber=chamber_name,
            unit="percent",
        )
        bundle.tables["scorecard_metrics"][-1].update(methodology_id=methodology_id, periods_json=json_column(periods))
        for component, title in (("votes", "roll call votes"), ("bills", "co-sponsorships")):
            component_id = key(chamber, component)
            bundle.metric(
                method_source,
                component_id,
                title,
                path=f"//div[contains(@class,'default-content')]/p[{method_position + 1}]",
                chamber=chamber_name,
                primary=False,
            )
            bundle.add(
                "scorecard_metric_components",
                method_source,
                f"//div[contains(@class,'default-content')]/p[{method_position + 1}]",
                parent_metric_id=score_metric,
                component_metric_id=component_id,
                combination_rule_text=methods[method_position],
            )
        if chamber == "senate":
            bundle.metric(
                senate_source,
                "senate:six_year",
                six_year_label,
                path="//thead/tr/th[contains(.,'6 YEAR SCORE')]",
                chamber=chamber_name,
                unit="percent",
                primary=False,
            )
            bundle.tables["scorecard_metrics"][-1]["periods_json"] = json_column(
                [
                    {
                        "occurrence_id": "six-year",
                        "kind": "relative",
                        "period_text": six_year_label,
                        "source_path": "//thead/tr/th[contains(.,'6 YEAR SCORE')]",
                    }
                ]
            )
        for table in (chamber, "chamber-votes", "chamber-bills"):
            rows, documents, total = captured[chamber, table]
            declared[chamber + ":" + table] = total
            _use_pages(bundle, documents, chamber + ":" + table)
            if table == chamber:
                for document, offset, row in rows:
                    _member(row, chamber)
                    member_key = key(chamber, row["congID"])
                    path = f"$.data[{offset}]"
                    bundle.add(
                        "scorecard_members",
                        document,
                        path,
                        publisher_member_key=member_key,
                        member_name=row["name"],
                        state=row["state"],
                        district=row.get("district"),
                        party=row["party"],
                        chamber_text=chamber_name,
                        identifiers_json=json_column([{"scheme": "bioguide", "value": row["congID"]}]),
                        notes_text=json_column({"senate_class": row.get("senate_class")}),
                    )
                    bundle.add(
                        "scorecard_member_ratings",
                        document,
                        path + ".score",
                        publisher_member_key=member_key,
                        metric_id=score_metric,
                        value_text=row["score"],
                        value_number=decimal_text(row["score"]),
                    )
                    if chamber == "senate":
                        bundle.add(
                            "scorecard_member_ratings",
                            document,
                            path + ".full_term_score",
                            publisher_member_key=member_key,
                            metric_id="senate:six_year",
                            value_text=str(row["full_term_score"]),
                            value_number=str(row["full_term_score"]),
                        )
                continue
            component = "votes" if table == "chamber-votes" else "bills"
            for document, offset, row in rows:
                path = f"$.data[{offset}]"
                if row["position"] not in {"Yes", "No"}:
                    raise ScorecardSourceError("AEA preferred action changed")
                roll = _roll(row) if component == "votes" else None
                if roll and roll[0] != chamber_name[0]:
                    raise ScorecardSourceError("AEA roll-call row names another chamber")
                identifier = key(chamber, component, row["id"])
                references = (
                    [
                        {
                            "occurrence_id": "roll",
                            "kind": "roll_call",
                            "citation_text": row["roll_call"],
                            "source_path": path + ".roll_call",
                            "congress_text": "119",
                            "chamber_text": chamber_name,
                            "roll_number_text": roll[1],
                        }
                    ]
                    if roll
                    else []
                )
                for field in ("vote_title", "description", "billNumber"):
                    for occurrence, match in enumerate(
                        re.finditer(
                            r"\b(?:H\.\s*(?:R\.|J\.\s*Res\.|Con\.\s*Res\.|Res\.)|S\.\s*(?:J\.\s*Res\.|Con\.\s*Res\.|Res\.)?)\s*\d+\b",
                            row.get(field, ""),
                            re.IGNORECASE,
                        )
                    ):
                        references.append(
                            {
                                "occurrence_id": key(field, str(occurrence)),
                                "kind": "bill",
                                "citation_text": match[0],
                                "bill_citation_text": match[0],
                                "source_path": path + "." + field,
                            }
                        )
                bundle.add(
                    "scorecard_items",
                    document,
                    path,
                    item_id=identifier,
                    publisher_item_id=row["id"],
                    item_kind_text="roll call" if roll else "co-sponsorship",
                    title=row.get("vote_title") or row["short_title"],
                    congress_text="119",
                    chamber_text=chamber_name,
                    roll_number_text=roll[1] if roll else None,
                    bill_citation_text=row.get("billNumber"),
                    references_json=json_column(references),
                    publisher_position_text=row["position"],
                    position_basis="explicit",
                    position_source_path=path + ".position",
                )
                definition_id = key(identifier, "definition")
                bundle.add(
                    "scorecard_methodologies",
                    document,
                    path,
                    methodology_id=definition_id,
                    methodology_text=json_column(row),
                    methodology_url=API,
                    disclosure_status="partial",
                )
                bundle.add(
                    "scorecard_metric_items",
                    document,
                    path,
                    metric_id=key(chamber, component),
                    item_id=identifier,
                    participation_id="source-item",
                    methodology_id=definition_id,
                    publisher_position_text=row["position"],
                    position_basis="explicit",
                    counts_toward_metric="true",
                    contribution_rule_text=methods[method_position],
                )
                definitions[chamber, component, row["id"]] = row
        for _, _, member in captured[chamber, chamber][0]:
            for component, table in (("votes", "member-votes"), ("bills", "member-co-sponsorship")):
                if not captured[chamber, "chamber-" + component][0]:
                    continue
                rows, documents, total = _pages(
                    context, table, stage=chamber + ":" + member["congID"] + ":" + table, congID=member["congID"]
                )
                member_results[chamber, member["congID"], table] = rows
                declared[key(chamber, member["congID"], table)] = total
                _use_pages(bundle, documents, key(chamber, member["congID"], table))
                for document, offset, row in rows:
                    definition = definitions.get((chamber, component, row["id"]))
                    if (
                        definition is None
                        or row["position"] != definition["position"]
                        or component == "votes"
                        and _roll(row) != _roll(definition)
                    ):
                        raise ScorecardSourceError("AEA member action cannot reconcile with its source item")
                    bundle.add(
                        "scorecard_member_item_results",
                        document,
                        f"$.data[{offset}]",
                        item_id=key(chamber, component, row["id"]),
                        publisher_member_key=key(chamber, member["congID"]),
                        result_id="source-item",
                        metric_id=key(chamber, component),
                        participation_id="source-item",
                        result_text=row["repPosition"],
                        action_text=row["repPosition"],
                        reason_text=json_column(row),
                    )
    # Reconcile a second complete read of all lists and each disclosed member
    # result set. A per-member count need not equal the chamber item count: the
    # publisher may omit inapplicable results, and those are never fabricated.
    for (chamber, table), (rows, _, _) in captured.items():
        repeat, documents, _ = _pages(context, table, stage="reread:" + chamber + ":" + table, chamber=chamber)
        if _facts(repeat) != _facts(rows):
            raise ScorecardSourceError("AEA source member or item facts changed during acquisition")
        _use_pages(bundle, documents, chamber + ":" + table, role="corroboration")
    for (chamber, member, table), rows in member_results.items():
        repeat, documents, _ = _pages(
            context, table, stage="reread:" + chamber + ":" + member + ":" + table, congID=member
        )
        if _facts(repeat) != _facts(rows):
            raise ScorecardSourceError("AEA member item results changed during acquisition")
        _use_pages(bundle, documents, key(chamber, member, table), role="corroboration")
    repeated_index = context.read(INDEX, stage="scorecards:aea:reread:index", hosts=HOSTS)
    repeated_method = context.read(ABOUT, stage="scorecards:aea:reread:methodology", hosts=HOSTS)
    repeated_senate = context.read(SENATE, stage="scorecards:aea:reread:senate-heading", hosts=HOSTS)
    if (
        _index(repeated_index) != label
        or _methods(repeated_method) != methods
        or _senate(repeated_senate) != six_year_label
    ):
        raise ScorecardSourceError("AEA period, score heading or methodology changed during acquisition")
    bundle.use(repeated_index, "congress_period", role="corroboration")
    bundle.use(repeated_method, "methodology", role="corroboration")
    bundle.use(repeated_senate, "senate_heading", role="corroboration")
    return bundle.finish(
        "Every publisher-declared DataTables count reconciles through complete pagination; both chamber populations and item lists retained; all disclosed member results link to exact source items; full source facts agree on stable reread",
        declared=declared,
    )
