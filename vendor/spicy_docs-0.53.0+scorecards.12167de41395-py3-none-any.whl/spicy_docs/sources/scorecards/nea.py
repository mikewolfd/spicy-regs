"""NEA's published 119th Congress (2025) grades and disclosed scored-vote list.

Grades are authoritative source observations. Undisclosed leadership and access inputs
are not invented as member item results, and the state's literal ``NES`` is preserved.
"""

from __future__ import annotations

import re
from collections import Counter

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    pdf,
    soup,
)

parser_version = "nea-119-2025-docling/2"
HOSTS = ("www.nea.org",)
BASE = "https://www.nea.org"
INDEX = BASE + "/advocating-for-change/action-center/nea-in-congress/report-card"
GRADES = BASE + "/sites/default/files/2026-01/nea-legislative-report-card-for-the-119th-congress-2025-1.pdf"
VOTES = BASE + "/sites/default/files/2026-01/119th-congress-session-1-scored-votes.pdf"
EDITION = ScorecardEdition(
    "nea",
    "119-2025",
    INDEX,
    "NEA Legislative Report Card for the 119th Congress (2025)",
    year="2025",
    congress="119",
    chamber="both",
)
HEADERS = (
    ("State", "Senator", "119th Congressional Grade"),
    ("State", "District", "Representative", "119th Congressional Grade"),
)


def _index(document):
    html = soup(document)
    tables = html.select("table")
    if len(tables) != 2 or {GRADES, VOTES} - {a.get("href") for a in html.select("a[href]")}:
        raise ScorecardSourceError("NEA current edition files or chamber tables changed")
    rows = []
    for index, table in enumerate(tables):
        header = tuple(cell.get_text(" ", strip=True) for cell in table.select("thead th"))
        if header != HEADERS[index]:
            raise ScorecardSourceError("NEA grade table header changed")
        chamber = ("Senate", "House")[index]
        chamber_rows = table.select("tbody tr")
        if not chamber_rows:
            raise ScorecardSourceError("NEA grade table is empty")
        for position, node in enumerate(chamber_rows):
            values = tuple(cell.get_text(" ", strip=True) for cell in node.select("td"))
            if len(values) != len(header) or values[-1] not in {"A", "B", "C", "D", "F"}:
                raise ScorecardSourceError("NEA grade row has an unsupported shape")
            rows.append((chamber, position + 1, values))
    return html, rows


def citation_fragment(block):
    return block.strip().splitlines()[0]


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="scorecards:nea:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("NEA reader supports only the qualified 119th Congress 2025 edition")
    primary = context.read(INDEX, stage="scorecards:nea:grades-html", hosts=HOSTS)
    html, rows = _index(primary)
    grades = context.read(GRADES, stage="scorecards:nea:grades-pdf", hosts=HOSTS)
    votes = context.read(VOTES, stage="scorecards:nea:scored-votes", hosts=HOSTS)
    pdf_rows = []
    with pdf(grades, context, expected_pages=13) as document:
        if document.page_count != 13 or "119th Congress (2025)" not in document[0].text:
            raise ScorecardSourceError("NEA grade PDF edition or page boundary changed")
        for page in document:
            tables = page.tables
            if len(tables) != 1:
                raise ScorecardSourceError("NEA PDF grade page has a different table layout")
            for row in tables[0].cells:
                if row and row[-1] in {"A", "B", "C", "D", "F"}:
                    pdf_rows.append(tuple(row))
                elif row and not any(
                    "Grade" in (cell or "")
                    or "NEA Legislative Report Card for the 119th Congress (2025)" in (cell or "")
                    for cell in row
                ):
                    raise ScorecardSourceError("NEA PDF has an unrecognized grade row")
    if Counter(pdf_rows) != Counter(values for _, _, values in rows):
        raise ScorecardSourceError("NEA full HTML and PDF membership or literal grades disagree")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="National Education Association",
        parser_version=parser_version,
        rendition_rule="nea-html-literal-grades-pdf-exact-reconciliation/1",
        homepage=BASE,
    )
    bundle.use(primary, "members_and_grades", "methodology")
    bundle.use(grades, "members_and_grades", role="corroboration")
    bundle.use(votes, "scored_items")
    method_node = html.select_one("main")
    if method_node is None:
        raise ScorecardSourceError("NEA source methodology container changed")
    method = method_node.get_text(" ", strip=True).split("Section with embed")[0]
    bundle.add(
        "scorecard_methodologies",
        primary,
        "main before grade tables",
        methodology_id="published-method",
        methodology_text=method,
        methodology_url=INDEX,
        disclosure_status="partial",
    )
    for chamber in ("Senate", "House"):
        metric_id = chamber.lower() + ":grade"
        bundle.metric(
            primary,
            metric_id,
            "119th Congressional Grade",
            path=f"{chamber}/table/thead",
            chamber=chamber,
            unit="grade",
        )
    for chamber, position, values in rows:
        path = f"table[{1 if chamber == 'Senate' else 2}]/tbody/tr[{position}]"
        state, member_name, grade = values[0], values[-2], values[-1]
        district = values[1] if chamber == "House" else None
        member_id = key(chamber, state, district or "", member_name) if district else key(chamber, state, member_name)
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=member_id,
            member_name=member_name,
            state=state,
            district=district,
            chamber_text=chamber,
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + "/td[last()]",
            metric_id=chamber.lower() + ":grade",
            publisher_member_key=member_id,
            value_text=grade,
        )
    with pdf(votes, context, expected_pages=2) as document:
        if document.page_count != 2:
            raise ScorecardSourceError("NEA scored-vote document page boundary changed")
        source = "\n".join(page.text for page in document)
        vote_pages = tuple(document)
    if re.search(r"first session of the 119(?:th| \$\^\{th\}\$) Congress \(2025\)", source) is None:
        raise ScorecardSourceError("NEA scored-vote document is a different edition")
    blocks = re.split(r"(?:•|(?m:^[-*] ))", source)[1:]
    if len(blocks) != 12:
        raise ScorecardSourceError("NEA qualified scored-vote list changed")
    for position, block in enumerate(blocks):
        matches = list(re.finditer(r"\((House|Senate) Vote (1-\s*\d+)\)", block))
        if len(matches) != 1:
            raise ScorecardSourceError("NEA scored item has ambiguous roll-call occurrence")
        match = matches[0]
        chamber, reference = match.groups()
        page = next((page for page in vote_pages if citation_fragment(block) in page.text), None)
        if page is None:
            raise ScorecardSourceError("NEA scored item crosses unqualified page boundaries")
        path = page.path() + f"/scored-item[{position + 1}]"
        citation = match.group(0)
        item_id = key(chamber, re.sub(r"\s+", "", reference))
        target = re.search(r"NEA\s+(supported|opposed)", block)
        if target is None:
            raise ScorecardSourceError("NEA scored item lacks its expected publisher position")
        text = block[: match.end()].strip()
        citations = [
            {
                "occurrence_id": "roll",
                "citation_text": citation,
                "kind": "roll call",
                "source_path": path,
                "chamber_text": chamber,
                "session_text": "1",
                "roll_number_text": reference.split("-", 1)[1],
            }
        ]
        for i, cited in enumerate(re.finditer(r"(?:S\.Amdt\.|H\.R\.|S\.|H\.\s*Con\.\s*Res\.)\s*\d+", text)):
            citations.append(
                {
                    "occurrence_id": f"citation-{i + 1}",
                    "citation_text": cited.group(0),
                    "kind": "amendment" if "Amdt" in cited.group(0) else "bill",
                    "source_path": path,
                }
            )
        bundle.add(
            "scorecard_items",
            votes,
            path,
            item_id=item_id,
            item_kind_text="roll call",
            title=text,
            chamber_text=chamber,
            session_text="1",
            roll_number_text=reference.split("-", 1)[1],
            references_json=json_column(citations),
            publisher_position_text=target.group(1),
            position_basis="explicit",
            position_source_path=path,
        )
        bundle.add(
            "scorecard_metric_items",
            votes,
            path,
            metric_id=chamber.lower() + ":grade",
            item_id=item_id,
            participation_id="reported",
            methodology_id="published-method",
            publisher_position_text=target.group(1),
            position_basis="explicit",
        )
    return bundle.finish(
        "Both complete published HTML chamber tables reconcile cell-for-cell with every grade "
        "table across the official PDF; the complete two-page disclosed scored-vote list is read. "
        "The publisher discloses additional qualitative inputs without member ledgers."
    )
