"""Foreign Policy for America's issue-based 118th scorecard, including composites."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "fp4a-118-qualified-semantic/1"
HOSTS = ("www.fp4america.org",)
URL = "https://www.fp4america.org/wp-content/uploads/2025/04/FP4A-118th-Congress-Legislative-Scorecard.pdf"
SOURCE_SHA256 = "c1d7608c2ce8b633fd60de0ce3b5d0c3584fdaf098e64d4db1b9fc7bf3f96746"
QUALIFIED_SHA256 = "f9b062cb2dffabb5c5e425e4569d1f38434b18dd8201730de7f28515c3c88524"
EDITION = ScorecardEdition(
    "foreign_policy_america",
    "118",
    URL,
    "118th Congress Legislative Scorecard",
    congress="118",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    11: 15,
    12: 14,
    13: 16,
    14: 14,
    15: 15,
    16: 14,
    17: 14,
    21: 18,
    22: 22,
    23: 23,
    24: 21,
    25: 19,
    26: 23,
    27: 19,
    28: 22,
    29: 19,
    30: 20,
    31: 22,
    32: 19,
    33: 21,
    34: 23,
    35: 20,
    36: 21,
    37: 20,
    38: 20,
    39: 22,
    40: 22,
    41: 19,
    42: 16,
}
ITEM_KEYS = {"Senate": tuple(str(i) for i in range(1, 10)), "House": tuple(str(i) for i in range(1, 16))}
TOKENS = {"✓", "✗", "N/A"}
COMPOSITES = {("Senate", "4"): 3, ("House", "7"): 6}


@dataclass(frozen=True, slots=True)
class ForeignPolicyAmericaReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:foreign_policy_america:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("FP4A qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "fp4a-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 44
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            chamber = "Senate" if page < 18 else "House"
            if (
                page not in counts
                or page < previous
                or not all(
                    isinstance(record[f], str) and record[f] for f in ("member_name_text", "state_text", "party_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or (chamber == "House" and re.fullmatch(r"AL|\d+", record["district_text"] or "") is None)
                or set(record["results"]) != set(ITEM_KEYS[chamber])
                or any(v not in TOKENS for v in record["results"].values())
                or any(
                    re.fullmatch(r"\d{1,3}|N/A", record[f]) is None or (record[f] != "N/A" and int(record[f]) > 100)
                    for f in ("congress_score_text", "lifetime_score_text")
                )
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        expected = {(c, k) for c, keys in ITEM_KEYS.items() for k in keys}
        if (
            counts != PAGE_MEMBERS
            or len(data["items"]) != len(expected)
            or {(e["chamber"], e["record"]["publisher_item_key_text"]) for e in data["items"]} != expected
            or [e["evidence"]["physical_page"] for e in data["methodology"]] != [8, 11, 13, 21]
        ):
            raise ValueError
        for entry in data["items"]:
            item = entry["record"]
            shape = (entry["chamber"], item["publisher_item_key_text"])
            if (
                not item["title_text"]
                or not item["publisher_position_text"]
                or not item["methodology_text"]
                or item["roll_number_text"] is not None
                or not item["source_pages"]
                or any(p not in (9, 10, 11, 18, 19, 20, 21) for p in item["source_pages"])
                or not item["references"]
                or any(not r["citation_text"] or not r["kind"] for r in item["references"])
            ):
                raise ValueError
            if shape in COMPOSITES and (
                item["bill_citation_text"] is not None
                or item["amendment_citation_text"] is not None
                or item["item_kind_text"] != "cosponsorship"
                or len(item["references"]) != COMPOSITES[shape]
                or any(r["kind"] != "bill" for r in item["references"])
            ):
                raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("FP4A semantic facts fail the complete qualified edition shape") from None


def _references(item, loc):
    occurrences = []
    for i, ref in enumerate(item["references"]):
        kind = "amendment" if ref["kind"] == "amendment" else "bill"
        occurrences.append(
            {
                "occurrence_id": str(i),
                "citation_text": ref["citation_text"],
                "kind": kind,
                "source_path": loc + f"/references/{i}",
                "amendment_citation_text" if kind == "amendment" else "bill_citation_text": ref["citation_text"],
            }
        )
    return json.dumps(occurrences, ensure_ascii=False)


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("FP4A edition requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:foreign_policy_america:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="fp4a:qualified-118",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Foreign Policy for America",
        parser_version=parser_version,
        rendition_rule="fp4a-complete-source-issue-composite-and-score-facts/1",
        homepage="https://www.fp4america.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        record = entry["record"]
        text = (
            record["methodology_text"]
            + "\n"
            + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in record["legend"])
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}/record"),
            methodology_id=f"source-page-{entry['evidence']['physical_page']}",
            methodology_text=text,
            methodology_url=URL,
            disclosure_status="explicit: equal issue weights, composites, tenure and leadership exclusions",
        )
    for chamber, page in (("Senate", 11), ("House", 21)):
        for metric, label, period in (
            ("118", "118th Congress (%)", "2023–2024"),
            ("lifetime", "Lifetime Score (%)", "Lifetime"),
        ):
            bundle.add(
                "scorecard_metrics",
                source,
                path(page, "/score-headings"),
                metric_id=key(chamber, metric),
                name=label,
                chamber_text=chamber,
                period_text=period,
                value_unit_text="percent",
                is_primary="true" if metric == "118" else "false",
            )
    item_shapes = {}
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        ordinal = item["publisher_item_key_text"]
        item_shapes[(chamber, ordinal)] = item["item_kind_text"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=key(chamber, ordinal),
            publisher_item_id=ordinal,
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=chamber,
            congress_text="118",
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "118"),
            item_id=key(chamber, ordinal),
            participation_id="congress-118",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-8",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc + "/methodology_text",
            methodology_id=key(chamber, "issue", ordinal),
            methodology_text=item["methodology_text"],
            methodology_url=URL,
            disclosure_status="explicit: literal publisher issue narrative",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "Senate" if page < 18 else "House"
        identity = key(
            chamber, record["state_text"], record["member_name_text"], record["district_text"] or "no-district"
        )
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            party=record["party_text"],
            district=record["district_text"],
            chamber_text=chamber,
        )
        for metric, field_name in (("118", "congress_score_text"), ("lifetime", "lifetime_score_text")):
            value = record[field_name]
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + "/" + field_name,
                metric_id=key(chamber, metric),
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value),
            )
        for ordinal, value in record["results"].items():
            excluded = (
                value == "N/A"
                or "***" in record["member_name_text"]
                or ("**" in record["member_name_text"] and item_shapes[(chamber, ordinal)] == "cosponsorship")
            )
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "118"),
                participation_id="congress-118",
                publisher_member_key=identity,
                result_id="published-chart",
                result_text=value,
                counts_toward_metric="false" if excluded else "true",
            )
    return bundle.finish(
        "Complete original 118th report: every Senate, House and delegate member page, current/lifetime score and issue action reconciles to original source counts and cells. Composite cosponsorship items retain all bill references and thresholds; explicit leadership, delegate and N/A exclusions remain per-member facts. No invented roll numbers, lifetime action ledger or score reproduction."
    )
