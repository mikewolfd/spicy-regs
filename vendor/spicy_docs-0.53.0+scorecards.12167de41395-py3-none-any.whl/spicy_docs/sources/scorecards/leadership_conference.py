"""Leadership Conference's published 118th scores and scored-vote descriptions."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "leadership-conference-118-qualified-semantic/1"
HOSTS = ("civilrights.org",)
URL = "https://civilrights.org/wp-content/uploads/2024/10/Voting-Record-118th-Congress.pdf"
SOURCE_SHA256 = "c6d1d992154a5686ef7b88ebc623a25cf362ab56c61925d3f37668427f42cee9"
QUALIFIED_SHA256 = "76142993141d4d005a55a26fee28c9eb15a3e03317f9560fd522d0be8266816e"
EDITION = ScorecardEdition(
    "leadership_conference",
    "118",
    URL,
    "Voting Record: 118th Congress",
    congress="118",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    31: 31,
    32: 39,
    33: 35,
    34: 34,
    35: 33,
    36: 29,
    37: 32,
    38: 30,
    39: 38,
    40: 30,
    41: 31,
    42: 37,
    43: 33,
    44: 11,
    46: 23,
    47: 22,
    48: 23,
    49: 22,
    50: 12,
}
PAGE_ITEMS = {
    7: 4,
    8: 3,
    9: 2,
    10: 3,
    11: 3,
    12: 2,
    13: 2,
    15: 3,
    16: 2,
    17: 3,
    18: 3,
    19: 3,
    20: 3,
    21: 2,
    22: 2,
    23: 3,
    24: 2,
    25: 4,
    26: 4,
    27: 2,
    28: 3,
    29: 2,
}


@dataclass(frozen=True, slots=True)
class LeadershipConferenceReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:leadership-conference:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("Leadership Conference qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "leadership_conference-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 51
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
            or len(data["items"]) != sum(PAGE_ITEMS.values())
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            chamber = "House" if page < 45 else "Senate"
            if (
                page not in counts
                or page < previous
                or not all(
                    isinstance(record[f], str) and record[f]
                    for f in ("first_name_text", "last_name_text", "state_text", "party_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or re.fullmatch(r"\d+", record["district_text"]) is None
                or re.fullmatch(r"\d{1,3}%", record["score_text"]) is None
                or int(record["score_text"][:-1]) > 100
            ):
                raise ValueError
            identity = (
                chamber,
                record["state_text"],
                record["district_text"],
                record["first_name_text"],
                record["last_name_text"],
            )
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        if counts != PAGE_MEMBERS or [m["evidence"]["physical_page"] for m in data["methodology"]] != [3]:
            raise ValueError
        counts, identities = dict.fromkeys(PAGE_ITEMS, 0), set()
        for entry in data["items"]:
            item, chamber, page = entry["record"], entry["chamber"], entry["evidence"]["physical_page"]
            if (
                page not in counts
                or chamber != ("House" if page < 14 else "Senate")
                or item["publisher_item_key_text"] is not None
                or not item["title_text"]
                or not item["item_kind_text"]
                or re.fullmatch(r"\d+", item["roll_number_text"]) is None
                or re.fullmatch(r"[A-Za-z]+ \d{1,2}, 202[34]", item["item_date_text"]) is None
                or re.fullmatch(r"(?:YES|NO)(?: IS THE PRO-CIVIL RIGHTS VOTE\.?)?", item["publisher_position_text"])
                is None
                or not item["source_pages"]
                or any(p < 7 or p > 29 for p in item["source_pages"])
            ):
                raise ValueError
            identity = (chamber, item["item_date_text"], item["roll_number_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
        if counts != PAGE_ITEMS:
            raise ValueError
        if "available upon request" not in data["methodology"][0]["record"]["methodology_text"]:
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "Leadership Conference semantic facts fail the complete qualified edition shape"
        ) from None


def acquire_scorecard(edition, context: ScorecardContext, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Leadership Conference edition requires reviewed semantic facts and private retention"
        )
    source = context.read(URL, stage="scorecards:leadership-conference:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="leadership-conference:qualified-118",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="The Leadership Conference on Civil and Human Rights",
        parser_version=parser_version,
        rendition_rule="leadership-conference-complete-published-scores-and-vote-descriptions/1",
        homepage="https://civilrights.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    method = data["methodology"][0]["record"]
    text = (
        method["methodology_text"]
        + "\n"
        + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in method["legend"])
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        path(3, "/methodology/0/record"),
        methodology_id="source-page-3",
        methodology_text=text,
        methodology_url=URL,
        disclosure_status="partial: member vote charts available upon request; missed/present exclusions explicit",
    )
    for chamber, page in (("House", 31), ("Senate", 46)):
        bundle.add(
            "scorecard_metrics",
            source,
            path(page, "/score-heading"),
            metric_id=key(chamber, "118"),
            name="SCORE",
            chamber_text=chamber,
            period_text="118th Congress",
            value_unit_text="percent",
            is_primary="true",
            methodology_id="source-page-3",
        )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        item_id = key(chamber, item["item_date_text"], item["roll_number_text"])
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=chamber,
            congress_text="118",
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "118"),
            item_id=item_id,
            participation_id="published-scored-vote",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-3",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "House" if page < 45 else "Senate"
        name = record["first_name_text"] + " " + record["last_name_text"]
        identity = key(chamber, record["state_text"], name, record["district_text"])
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=name,
            state=record["state_text"],
            party=record["party_text"],
            district=record["district_text"],
            chamber_text=chamber,
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            loc + "/score_text",
            metric_id=key(chamber, "118"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
    return bundle.finish(
        "Complete original 118th report: exact source/observation hashes, all House/Senate score pages and every scored-vote narrative reconcile. Published district labels and former/successor footnotes remain literal, including the publisher's Cloud district 26. The publisher says supplementary member vote charts are available upon request; no public member-item results or undisclosed reproduction ledger is invented."
    )
