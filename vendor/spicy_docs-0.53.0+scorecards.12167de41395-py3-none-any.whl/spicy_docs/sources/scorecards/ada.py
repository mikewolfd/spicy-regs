"""Americans for Democratic Action's complete source-defined 2023 voting record."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "ada-2023-qualified-semantic/1"
HOSTS = ("adaction.org",)
URL = "https://adaction.org/wp-content/uploads/2024/09/2023.pdf"
SOURCE_SHA256 = "100b1f71a16560d95ff6154e32f9d7b4b08456105764e806bbad4a35d3402b62"
QUALIFIED_SHA256 = "d68c7383a919e00ef7165aa2282c37b4717670cb268f91e39a5f2a6ca5a5e712"
EDITION = ScorecardEdition(
    "ada", "2023", URL, "2023 Congressional Voting Record", year="2023", chamber="both", is_current=False
)
PAGE_MEMBERS = {
    7: 23,
    8: 33,
    9: 31,
    10: 30,
    11: 30,
    12: 28,
    13: 29,
    14: 29,
    15: 27,
    16: 32,
    17: 30,
    18: 29,
    19: 30,
    20: 31,
    21: 29,
    22: 4,
    27: 19,
    28: 22,
    29: 22,
    30: 22,
    31: 17,
}
ITEM_KEYS = {
    "House": (
        "25",
        "29",
        "30",
        "98",
        "106",
        "118",
        "150",
        "182",
        "188",
        "209",
        "211",
        "216",
        "227",
        "234",
        "237",
        "277",
        "470",
        "503",
        "511",
        "577",
    ),
    "Senate": (
        "49",
        "61",
        "73",
        "75",
        "80",
        "90",
        "99",
        "109",
        "126",
        "130",
        "132",
        "135",
        "141",
        "146",
        "162",
        "164",
        "165",
        "190",
        "212",
        "310",
    ),
}
TOKENS = {"", "+", "-", "(+)", "(-)", "X", "P", "S", "I"}


@dataclass(frozen=True, slots=True)
class ADAReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:ada:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("ADA qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "ada-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 31
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
        ):
            raise ValueError
        counts, identities, previous = dict.fromkeys(PAGE_MEMBERS, 0), set(), 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            chamber = "House" if page < 23 else "Senate"
            if (
                page not in counts
                or page < previous
                or not all(
                    isinstance(record[f], str) and record[f] for f in ("member_name_text", "state_text", "party_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or set(record["results"]) != {str(i) for i in range(1, 21)}
                or any(v not in TOKENS for v in record["results"].values())
                or re.fullmatch(r"\d{1,3}%", record["score_text"]) is None
                or int(record["score_text"][:-1]) > 100
            ):
                raise ValueError
            if (
                chamber == "House"
                and re.fullmatch(r"AL|\d+", record["district_text"] or "") is None
                and not (
                    record["district_text"] is None
                    and record["score_text"] == "0%"
                    and all(v == "" for v in record["results"].values())
                )
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        expected = {(c, k) for c, keys in ITEM_KEYS.items() for k in keys}
        if (
            counts != PAGE_MEMBERS
            or len(data["items"]) != 40
            or {(e["chamber"], e["record"]["publisher_item_key_text"]) for e in data["items"]} != expected
            or [e["evidence"]["physical_page"] for e in data["methodology"]] != [2]
        ):
            raise ValueError
        for entry in data["items"]:
            item = entry["record"]
            if (
                not item["title_text"]
                or not item["methodology_text"]
                or item["publisher_position_text"] not in {"Y", "N"}
                or item["roll_number_text"] != item["publisher_item_key_text"]
                or re.fullmatch(r"[A-Z][a-z]+ \d{2}, 2023", item["item_date_text"] or "") is None
                or not item["source_pages"]
                or any(p not in (3, 4, 5, 6, 23, 24, 25, 26) for p in item["source_pages"])
            ):
                raise ValueError
            if (
                entry["chamber"] == "House"
                and item["publisher_item_key_text"] == "216"
                and item["bill_citation_text"] is not None
            ):
                raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("ADA semantic facts fail the complete qualified edition shape") from None


def _references(item, loc):
    occurrences = []
    for i, ref in enumerate(item["references"]):
        kind = ref["kind"]
        occurrence = {
            "occurrence_id": str(i),
            "citation_text": ref["citation_text"],
            "kind": kind,
            "source_path": loc + f"/references/{i}",
        }
        if kind in {"bill", "amendment"}:
            occurrence["amendment_citation_text" if kind == "amendment" else "bill_citation_text"] = ref[
                "citation_text"
            ]
        occurrences.append(occurrence)
    return json.dumps(occurrences, ensure_ascii=False)


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("ADA edition requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:ada:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="ada:qualified-2023",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Americans for Democratic Action",
        parser_version=parser_version,
        rendition_rule="ada-complete-source-roll-action-and-annual-score-facts/1",
        homepage="https://adaction.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    method = data["methodology"][0]["record"]
    text = (
        method["methodology_text"]
        + "\n"
        + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in method["legend"])
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        path(2, "/methodology/0/record"),
        methodology_id="source-page-2",
        methodology_text=text,
        methodology_url=URL,
        disclosure_status="explicit: missed votes penalized, tenure and Speaker limitations; source grid X is absent from printed legend",
    )
    for chamber, page in (("House", 7), ("Senate", 27)):
        bundle.add(
            "scorecard_metrics",
            source,
            path(page, "/score-heading"),
            metric_id=key(chamber, "2023"),
            name="Total",
            chamber_text=chamber,
            period_text="2023",
            value_unit_text="percent",
            is_primary="true",
        )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        roll = item["publisher_item_key_text"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        position_loc = path(7 if chamber == "House" else 27, f"/items/{i}/record/publisher_position_text")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=key(chamber, roll),
            publisher_item_id=roll,
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=chamber,
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=position_loc,
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "2023"),
            item_id=key(chamber, roll),
            participation_id="annual-2023",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-2",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc + "/methodology_text",
            methodology_id=key(chamber, "roll", roll),
            methodology_text=item["methodology_text"],
            methodology_url=URL,
            disclosure_status="explicit: literal publisher vote explanation",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "House" if page < 23 else "Senate"
        identity = key(
            chamber, record["state_text"], record["member_name_text"], record["district_text"] or "no-district"
        )
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            party=record["party_text"],
            district=record["district_text"],
            chamber_text=chamber,
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            loc + "/score_text",
            metric_id=key(chamber, "2023"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, value in record["results"].items():
            roll = ITEM_KEYS[chamber][int(ordinal) - 1]
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, roll),
                metric_id=key(chamber, "2023"),
                participation_id="annual-2023",
                publisher_member_key=identity,
                result_id="published-chart",
                result_text=value,
            )
    return bundle.finish(
        "Complete source-defined 2023 report: every House/Senate member page, published percent score, twenty action columns per chamber, dated vote narrative and explicit preferred position reconciles to original native source and retained semantic row observations. Empty/zero-score/missing-district records and X/parenthesized symbols stay literal. No inferred Congress/session or invented score/identity repair."
    )
