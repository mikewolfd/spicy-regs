"""CPAC's public Wix CMS congressional ratings and scoring-item catalogs.

Only the edition explicitly selected by the publisher's Congress page is a full
current edition. Older years on former members' profiles are not full historical
scorecards. Source API decimal spelling and absent values remain unchanged.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from decimal import Decimal, InvalidOperation
from typing import Any

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    soup,
)

parser_version = "cpac-current-federal-wix/1"
INDEX = "https://www.cpac.org/foundation/ratings/us"
BOOTSTRAP = "https://www.cpac.org/_api/v1/access-tokens"
API = "https://www.cpac.org/_api/cloud-data/v2/items/query"
HOSTS = ("www.cpac.org",)
APP_ID = "e593b0bd-b783-45b8-97c2-873d42aacaf4"
PAGE_SIZE = 1000
MAX_ROWS = 40_000


def edition_for_year(year: int) -> ScorecardEdition:
    if isinstance(year, bool) or not isinstance(year, int) or not 1900 <= year <= 2100:
        raise ScorecardSourceError("CPAC current edition year is invalid")
    return ScorecardEdition(
        "cpac", str(year), INDEX, f"CPAC Congressional Ratings — {year}", year=str(year), chamber="both"
    )


def _literal(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ScorecardSourceError("CPAC CMS literal scalar changed type")
    return str(value)


def _year(value: Any) -> int:
    try:
        number = Decimal(_literal(value) or "")
    except InvalidOperation as error:
        raise ScorecardSourceError("CPAC CMS edition year is malformed") from error
    if not number.is_finite() or number != number.to_integral_value() or not 1900 <= number <= 2100:
        raise ScorecardSourceError("CPAC CMS edition year is malformed")
    return int(number)


def _index(context: ScorecardContext, suffix: str = ""):
    document = context.read(INDEX, stage="scorecards:cpac-current:index" + suffix, hosts=HOSTS)
    node = soup(document).select_one("script#wix-warmup-data")
    try:
        warmup = json.loads(node.string) if node is not None else {}
        records = warmup["appsWarmupData"]["dataBinding"]["dataStore"]["recordsByCollectionId"]["StateDatabase"]
        selected = [row for row in records.values() if row.get("stateId") == "us"]
    except (TypeError, ValueError, KeyError, AttributeError) as error:
        raise ScorecardSourceError("CPAC Congress page no longer exposes its source edition") from error
    if len(selected) != 1 or selected[0].get("stateName") != "Congress":
        raise ScorecardSourceError("CPAC Congress page has an ambiguous source edition")
    return document, edition_for_year(_year(selected[0].get("currentRatingYear")))


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    return (_index(context)[1],)


def _json(context: ScorecardContext, url: str, stage: str, *, content=None, headers=None):
    document = context.read_request(
        url,
        method="POST" if content is not None else "GET",
        content=content,
        stage="scorecards:cpac-current:" + stage,
        hosts=HOSTS,
        request_headers=headers,
    )
    if (document.response.content_type or "").split(";", 1)[0].strip() != "application/json":
        raise ScorecardSourceError("CPAC CMS response is not JSON")
    data = json_data(document)
    if not isinstance(data, dict) or any(key in data for key in ("errors", "error", "message")):
        raise ScorecardSourceError("CPAC CMS read did not return a complete data object")
    return document, data


def _headers(context: ScorecardContext):
    document, data = _json(context, BOOTSTRAP, "public-visitor-bootstrap")
    try:
        token = data["apps"][APP_ID]["accessToken"]
    except (KeyError, TypeError) as error:
        raise ScorecardSourceError("CPAC public visitor data token is unavailable") from error
    if not isinstance(token, str) or not token or "\r" in token or "\n" in token:
        raise ScorecardSourceError("CPAC public visitor data token is malformed")
    return document, {"Authorization": token, "Content-Type": "application/json"}


def _catalog(context: ScorecardContext, collection: str, scope_field: str, headers, suffix=""):
    records, documents, total = [], [], None
    while True:
        query = {
            "dataCollectionId": collection,
            "query": {
                "filter": {scope_field: {"$eq": "Congress"}},
                "sort": [{"fieldName": "_id", "order": "ASC"}],
                "paging": {"offset": len(records), "limit": PAGE_SIZE},
            },
            "returnTotalCount": True,
        }
        document, data = _json(
            context,
            API,
            f"{collection}:{len(records)}" + suffix,
            content=json.dumps(query, separators=(",", ":")).encode(),
            headers=headers,
        )
        page, metadata = data.get("dataItems"), data.get("pagingMetadata")
        if not isinstance(page, list) or not isinstance(metadata, dict):
            raise ScorecardSourceError("CPAC CMS catalog layout changed")
        count, declared, has_next = metadata.get("count"), metadata.get("total"), metadata.get("hasNext")
        if (
            isinstance(declared, bool)
            or not isinstance(declared, int)
            or not 0 < declared <= MAX_ROWS
            or isinstance(count, bool)
            or not isinstance(count, int)
            or count != len(page)
            or count > PAGE_SIZE
            or not isinstance(has_next, bool)
            or metadata.get("tooManyToCount") is not False
            or metadata.get("offset", len(records)) != len(records)
            or (total is not None and declared != total)
        ):
            raise ScorecardSourceError("CPAC CMS source count or pagination does not reconcile")
        total = declared
        for position, item in enumerate(page):
            if (
                not isinstance(item, dict)
                or item.get("dataCollectionId") != collection
                or not isinstance(item.get("id"), str)
                or not item["id"]
                or not isinstance(item.get("data"), dict)
                or item["data"].get("_id") != item["id"]
                or item["data"].get(scope_field) != "Congress"
            ):
                raise ScorecardSourceError("CPAC CMS catalog identity or federal scope changed")
            records.append((document, f"$.dataItems[{position}].data", item["data"]))
        documents.append(document)
        if len({row[2]["_id"] for row in records}) != len(records):
            raise ScorecardSourceError("CPAC CMS catalog repeats an identity")
        if len(records) > total or has_next != (len(records) < total) or (has_next and not page):
            raise ScorecardSourceError("CPAC CMS source count or pagination does not reconcile")
        if not has_next:
            return records, documents


def _member_context(title):
    if not isinstance(title, str):
        raise ScorecardSourceError("CPAC CMS member title changed type")
    match = re.fullmatch(r"US (Representative|Senator|Delegate|Resident Commissioner) (?:from|for) (.+)", title)
    if not match:
        raise ScorecardSourceError("CPAC CMS member chamber and state context is unsupported")
    return ("Senate" if match[1] == "Senator" else "House"), match[2]


def _item_context(item):
    year = _year(item.get("billYear"))
    title = item.get("billSubTitle", item.get("billSubtitile"))
    match = re.fullmatch(r"(\d{4}) - US (Senate|House(?: of Representatives)?)", title or "")
    if not match or int(match[1]) != year:
        raise ScorecardSourceError("CPAC CMS item year or chamber context changed")
    citation = item.get("billNumber")
    if not isinstance(citation, str) or not citation:
        raise ScorecardSourceError("CPAC CMS item citation is missing")
    roll_match = re.search(r"(?:^|;\s*)Roll Call ([0-9]+)$", citation)
    roll = roll_match[1] if roll_match else None
    bill = citation[: roll_match.start()].strip().rstrip(";").strip() if roll_match else citation
    return year, "Senate" if match[2] == "Senate" else "House", citation, bill or None, roll


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if context.evidence_policy == "full":
        raise ScorecardSourceError("CPAC public visitor bootstrap requires hash_only or metadata_only evidence")
    primary, selected = _index(context)
    if edition != selected:
        raise ScorecardSourceError("CPAC CMS reader requires the publisher's current federal edition")
    bootstrap, headers = _headers(context)
    members, member_documents = _catalog(context, "PeopleDatabase", "peopleState", headers)
    items, item_documents = _catalog(context, "BillDatabase", "billState", headers)
    repeated_members, repeated_member_documents = _catalog(context, "PeopleDatabase", "peopleState", headers, ":reread")
    repeated_items, repeated_item_documents = _catalog(context, "BillDatabase", "billState", headers, ":reread")
    final, final_edition = _index(context, ":reread")
    if (
        final_edition != selected
        or [row[2] for row in members] != [row[2] for row in repeated_members]
        or [row[2] for row in items] != [row[2] for row in repeated_items]
    ):
        raise ScorecardSourceError("CPAC federal catalogs or selected edition changed during the complete read")
    year = int(edition.edition_id)
    member_years = Counter(_year(row[2].get("currentRatingYear")) for row in members)
    item_years = Counter(_item_context(row[2])[0] for row in items)
    selected_members = [row for row in members if _year(row[2]["currentRatingYear"]) == year]
    selected_items = [row for row in items if _year(row[2]["billYear"]) == year]
    if not selected_members or not selected_items or any(value > year for value in (*member_years, *item_years)):
        raise ScorecardSourceError("CPAC current edition is empty or disagrees with its catalogs")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="CPAC Foundation",
        parser_version=parser_version,
        rendition_rule="cpac-current-cms-literals/1",
        homepage="https://www.cpac.org/",
    )
    bundle.use(bootstrap, "public-visitor-bootstrap")
    bundle.use(final, "edition", role="corroboration")
    for documents, group, role in (
        (member_documents, "members", "primary"),
        (item_documents, "items", "primary"),
        (repeated_member_documents, "members", "corroboration"),
        (repeated_item_documents, "items", "corroboration"),
    ):
        for position, document in enumerate(documents):
            bundle.use(document, f"{group}:page:{position}", role=role)
    member_doc = selected_members[0][0]
    for field, group in (("currentRating", "annual"), ("lifetimeRating", "lifetime")):
        bundle.metric(
            member_doc,
            group + ":rating",
            field,
            path="$.dataItems[*].data." + field,
            unit="percent",
            primary=group == "annual",
        )
    identities = set()
    for document, path, member in selected_members:
        identifier = member.get("ratingsMyCpacId")
        name, profile_id = member.get("name"), member.get("myCPACId")
        if (
            any(not isinstance(value, str) or not value for value in (identifier, name, profile_id))
            or identifier in identities
        ):
            raise ScorecardSourceError("CPAC CMS member rating identity is empty or repeated")
        identities.add(identifier)
        chamber, state = _member_context(member.get("title1"))
        bundle.add(
            "scorecard_members",
            document,
            path,
            publisher_member_key=identifier,
            publisher_member_id=identifier,
            member_name=name,
            identifiers_json=json_column(
                [
                    {"scheme": "cpac", "value": identifier},
                    {"scheme": "cpac_profile", "value": profile_id},
                    {"scheme": "wix_people", "value": member["_id"]},
                ]
            ),
            chamber_text=chamber,
            state=state,
            period_text=_literal(member["currentRatingYear"]),
            notes_text=json_column({"title1": member["title1"], "myCPACId": profile_id}),
        )
        for field, group in (("currentRating", "annual"), ("lifetimeRating", "lifetime")):
            literal = _literal(member.get(field))
            if literal is not None and decimal_text(literal) is None:
                raise ScorecardSourceError("CPAC CMS reported rating is not an explicit number")
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + "." + field,
                publisher_member_key=identifier,
                metric_id=group + ":rating",
                value_text=literal,
                value_number=decimal_text(literal),
            )
    item_ids = set()
    for document, path, item in selected_items:
        _, chamber, citation, bill, roll = _item_context(item)
        identifier, title, target = item.get("billId"), item.get("billName"), item.get("conservativePosition")
        if (
            any(not isinstance(value, str) or not value for value in (identifier, title, target))
            or identifier in item_ids
        ):
            raise ScorecardSourceError("CPAC CMS scoring item identity or position changed")
        item_ids.add(identifier)
        references = []
        for kind, value in (("bill", bill), ("roll_call", roll)):
            if value:
                references.append(
                    {
                        "occurrence_id": "billNumber:" + kind,
                        "citation_text": citation,
                        "kind": kind,
                        "source_path": path + ".billNumber",
                        "chamber_text": chamber,
                        "bill_citation_text" if kind == "bill" else "roll_number_text": value,
                    }
                )
        bundle.add(
            "scorecard_items",
            document,
            path,
            item_id=identifier,
            publisher_item_id=identifier,
            item_kind_text="roll call" if roll else "bill action",
            title=title,
            chamber_text=chamber,
            bill_citation_text=bill,
            roll_number_text=roll,
            references_json=json_column(references),
            publisher_position_text=target,
            position_basis="explicit",
            position_source_path=path + ".conservativePosition",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            path,
            metric_id="annual:rating",
            item_id=identifier,
            participation_id="annual",
            publisher_position_text=target,
            position_basis="explicit",
        )
    return bundle.finish(
        "Publisher selects current federal year; complete PeopleDatabase and BillDatabase pagination reconciles with "
        "exact source totals; current year partitions preserve absent ratings; full federal catalogs and selected year "
        "are unchanged on reread; CMS does not disclose member-level item results or item weights",
        declared={
            "federal_member_profiles": len(members),
            "federal_items": len(items),
            "member_year_partitions": {str(k): v for k, v in sorted(member_years.items())},
            "item_year_partitions": {str(k): v for k, v in sorted(item_years.items())},
            "selected_members": len(selected_members),
            "selected_items": len(selected_items),
            "annual_values_absent": sum(row[2].get("currentRating") is None for row in selected_members),
            "lifetime_values_absent": sum(row[2].get("lifetimeRating") is None for row in selected_members),
        },
    )
