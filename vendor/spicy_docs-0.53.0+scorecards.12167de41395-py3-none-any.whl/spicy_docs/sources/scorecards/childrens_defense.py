"""CDF Action's explicit 117th-Congress profiles, directory and disclosed bills."""

from __future__ import annotations

import re
from collections import Counter
from hashlib import sha256
from urllib.parse import urljoin, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
    validate_url,
)

parser_version = "cdf-explicit-117-html-directory-profiles/1"
HOSTS = ("cdf-action.org", "live-cdf-action-council.pantheonsite.io")
INDEX = "https://cdf-action.org/legislative-report-card/"
METHOD = "https://cdf-action.org/about-the-report-card/"
BILLS = "https://cdf-action.org/reportcard-bills/"
EDITION = ScorecardEdition(
    "childrens_defense",
    "117",
    INDEX,
    "CDF Action's Legislative Report Card",
    congress="117",
    chamber="both",
    is_current=False,
)
COUNTERS = {
    "Grade": "grade",
    "Votes for Children": "votes",
    "Vote for Children": "votes",
    "Bills Sponsored or Cosponsored": "combined",
    "Bill Sponsored or Cosponsored": "combined",
    "Actions Against the Interests of Children": "against",
    "Action Against the Interests of Children": "against",
}
METRICS = {
    "grade": "Grade",
    "votes": "Votes for Children",
    "sponsored": "bills sponsored for children",
    "cosponsored": "bills cosponsored for children",
    "combined": "Bills Sponsored or Cosponsored",
    "against": "Actions Against the Interests of Children",
}
LIST_LABELS = {
    "votes for children": "votes",
    "vote for children": "votes",
    "bills sponsored for children": "sponsored",
    "bill sponsored for children": "sponsored",
    "bills cosponsored for children": "cosponsored",
    "bill cosponsored for children": "cosponsored",
    "actions against the interests of children": "against",
    "action against the interests of children": "against",
}


def _text(node):
    return node.get_text(" ", strip=True)


def _one(nodes, reason):
    if len(nodes) != 1:
        raise ScorecardSourceError(reason)
    return nodes[0]


def _number(value):
    if not re.fullmatch(r"0|[1-9]\d*", value):
        raise ScorecardSourceError("CDF source count is absent or no longer a literal integer")
    return value


def _facets(html):
    result = {}
    for field in ["grade", "party", "chamber", "state"]:
        container = _one(html.select(".sf-field-taxonomy-" + field), "CDF directory facet is missing or repeated")
        counts = {}
        for node in container.select("li[data-sf-count],option[data-sf-count]"):
            value = (
                node.get("value")
                if node.name == "option"
                else _one(node.select("input"), "CDF facet input is missing or repeated").get("value")
            )
            if value == "":
                continue
            label_node = (
                node if node.name == "option" else _one(node.select("label"), "CDF facet label is missing or repeated")
            )
            label = re.sub(r"\s*\(\d+\)$", "", _text(label_node)).strip()
            count = int(_number(str(node["data-sf-count"])))
            if not label or label in counts:
                raise ScorecardSourceError("CDF directory repeats a facet identity")
            counts[label] = count
        if not counts:
            raise ScorecardSourceError("CDF directory has an empty facet population")
        result[field] = counts
    totals = {sum(v.values()) for v in result.values()}
    if len(totals) != 1 or not next(iter(totals)) or set(result["chamber"]) != {"House", "Senate"}:
        raise ScorecardSourceError("CDF directory populations do not reconcile")
    return result


def _directory(document, number):
    html = soup(document)
    facets = _facets(html)
    current = _one(html.select(".page-numbers.current"), "CDF directory lacks an explicit current page")
    if _text(current) != str(number):
        raise ScorecardSourceError("CDF directory returned a different pagination scope")
    pages = [number]
    for node in html.select("a.page-numbers[href]"):
        text = _text(node)
        if text.isdigit():
            pages.append(int(text))
    last = max(pages)
    following = html.select("a.next.page-numbers[href]")
    if len(following) > 1:
        raise ScorecardSourceError("CDF directory repeats its next-page link")
    next_url = urljoin(document.url, str(following[0]["href"])) if following else None
    if next_url:
        validate_url(next_url, HOSTS)
        if urlsplit(next_url).path != "/legislative-report-card/" or urlsplit(next_url).query != "sf_paged=" + str(
            number + 1
        ):
            raise ScorecardSourceError("CDF directory next-page route changed")
    banners = [_text(p) for p in html.select("main p") if _text(p).startswith("Updated through ")]
    banner = _one(banners, "CDF source index period banner is missing or repeated")
    cards = html.select(".cl-layout__item")
    if not cards:
        raise ScorecardSourceError("CDF directory page contains no published members")
    rows = []
    for card in cards:
        identifiers = [re.fullmatch(r"cl-layout__item--id-(\d+)", str(c)) for c in card.get("class", [])]
        identifiers = [m[1] for m in identifiers if m]
        post = _one(identifiers, "CDF member has no unique publisher post identity")
        anchor = _one(card.select(".cl-element-title__anchor[href]"), "CDF member link is missing or repeated")
        source_href = urljoin(document.url, str(anchor["href"]))
        url = source_href.rstrip("/") + "/"
        validate_url(url, HOSTS)
        if not re.fullmatch(r"/member_profile/[^/]+-117/", urlsplit(url).path) or urlsplit(url).query:
            raise ScorecardSourceError("CDF directory contains a member outside the reviewed 117th edition")
        label = _text(anchor)
        name = re.fullmatch(r"(Rep\.|Sen\.) (.+)", label)
        if name is None:
            raise ScorecardSourceError("CDF published federal member label changed")
        grade = _text(_one(card.select(".scorecardGrade .cl-element-taxonomy__term"), "CDF member grade is missing"))
        if grade not in {"A", "B", "C", "D", "F", "L"}:
            raise ScorecardSourceError("CDF member grade has an unreviewed shape")
        context = {}
        for a in card.select(".cl-element-taxonomy__term[href]"):
            parts = urlsplit(str(a["href"])).path.strip("/").split("/")
            if len(parts) == 2 and parts[0] in {"state", "party", "chamber", "district"}:
                if parts[0] in context:
                    raise ScorecardSourceError("CDF repeats a member context field")
                context[parts[0]] = _text(a)
        if (
            not {"state", "party", "chamber"} <= context.keys()
            or context["chamber"] != ("House" if name[1] == "Rep." else "Senate")
            or (context["chamber"] == "House" and "district" not in context)
            or (context["chamber"] == "Senate" and "district" in context)
        ):
            raise ScorecardSourceError("CDF directory member context is incomplete or conflicts")
        measurements = {}
        for li in card.select("li.counteritem"):
            value = _one(li.select(":scope > .counternum"), "CDF listing count is missing")
            # The publisher nests malformed <li> elements; only direct strings belong to this count.
            counter_label = " ".join(str(s).strip() for s in li.find_all(string=True, recursive=False)).strip()
            metric = LIST_LABELS.get(counter_label)
            if metric is None or metric in measurements:
                raise ScorecardSourceError("CDF listing measurement labels changed")
            measurements[metric] = {"value": _number(_text(value)), "label": counter_label}
        if set(measurements) != {"votes", "sponsored", "cosponsored", "against"}:
            raise ScorecardSourceError("CDF listing measurements are incomplete")
        rows.append(
            {
                "post": post,
                "url": url,
                "source_href": source_href,
                "label": label,
                "name": name[2],
                "grade": grade,
                **context,
                "measurements": measurements,
                "path": ".cl-layout__item--id-" + post,
            }
        )
    return {"rows": rows, "facets": facets, "last": last, "next_url": next_url, "banner": banner}


def _roster(context, *, stage):
    documents, rows, url, number, expected, size, last = [], [], INDEX, 1, {}, 0, 0
    while url is not None:
        document = context.read(url, stage=f"cdf:{stage}:page:{number}", hosts=HOSTS)
        facts = _directory(document, number)
        if not expected:
            expected, size, last = facts["facets"], len(facts["rows"]), facts["last"]
            if last != (sum(expected["grade"].values()) + size - 1) // size:
                raise ScorecardSourceError("CDF directory page count does not reconcile")
        total = sum(expected["grade"].values())
        if facts["facets"] != expected or facts["last"] != last or len(facts["rows"]) != min(size, total - len(rows)):
            raise ScorecardSourceError("CDF directory changed or returned an incomplete page")
        if (number < last) != (facts["next_url"] is not None):
            raise ScorecardSourceError("CDF directory pagination did not complete")
        documents.append((document, facts))
        rows.extend(facts["rows"])
        url, number = facts["next_url"], number + 1
    if len(rows) != sum(expected["grade"].values()) or len({r["post"] for r in rows}) != len(rows):
        raise ScorecardSourceError("CDF directory repeats or omits members")
    for facet in expected:
        if dict(Counter(r[facet] for r in rows)) != expected[facet]:
            raise ScorecardSourceError("CDF parsed members do not reconcile to source facet counts")
    return documents


def _official_reference(url, citation, path):
    parts = urlsplit(url)
    if (
        parts.scheme != "https"
        or parts.hostname != "www.congress.gov"
        or not re.fullmatch(
            r"/bill/117th-congress/(?:house|senate)-(?:bill|resolution|joint-resolution|concurrent-resolution)/\d+",
            parts.path,
        )
        or parts.query
        or parts.fragment
    ):
        raise ScorecardSourceError("CDF legislative reference has an unreviewed identity or Congress")
    return {
        "occurrence_id": "bill:0",
        "kind": "url",
        "citation_text": url,
        "bill_citation_text": citation,
        "congress_text": "117",
        "source_path": path,
    }


def _profile(document, member):
    html = soup(document)
    article = _one(html.select("article.member_profile"), "CDF profile article is absent or repeated")
    if article.get("id") != "post-" + member["post"]:
        raise ScorecardSourceError("CDF profile post identity differs from its directory")
    heading = _text(_one(article.select("#mptitlesection h1"), "CDF profile member heading is missing"))
    if heading != member["label"]:
        raise ScorecardSourceError("CDF profile member name differs from its directory")
    ribbon = _text(_one(article.select(".bioribbon"), "CDF profile context is missing"))
    if not ribbon.startswith(member["party"] + ", " + member["state"]):
        raise ScorecardSourceError("CDF profile party/state differs from its directory")
    if member["chamber"] == "House":
        district = re.search(r", (\d+)(?:st|nd|rd|th) District$|, (At-Large)(?: District)?$", ribbon)
        if district is None or next(v for v in district.groups() if v is not None) != member["district"]:
            raise ScorecardSourceError("CDF profile district differs from its directory")
    measurements = {}
    for box in article.select(".counterbox"):
        value = _text(_one(box.select(".counterdigit"), "CDF profile counter value is missing"))
        label = _text(_one(box.select(".countertext"), "CDF profile counter label is missing"))
        metric = COUNTERS.get(label)
        if metric is None or metric in measurements:
            raise ScorecardSourceError("CDF profile measurement labels changed")
        measurements[metric] = {
            "value": value if metric == "grade" else _number(value),
            "label": label,
            "path": "article#post-" + member["post"] + "/.counterbox#" + str(box.get("id")),
        }
    if (
        set(measurements) != {"grade", "votes", "combined", "against"}
        or measurements["grade"]["value"] != member["grade"]
    ):
        raise ScorecardSourceError("CDF profile grade or measurement population differs")
    bio = _text(_one(article.select(".biobody"), "CDF profile Congress and summary are absent"))
    if not bio.startswith("During the 117th Congress,"):
        raise ScorecardSourceError("CDF detail page is outside the explicit 117th Congress edition")
    numbers = re.findall(r"\b(?:taken|introduced|cosponsored) (\d+) (?:votes?|bills?|actions?)", bio)
    if len(numbers) != 4 or any(
        numbers[index] != member["measurements"][metric]["value"]
        for index, metric in [(0, "votes"), (1, "sponsored"), (2, "cosponsored"), (3, "against")]
    ):
        raise ScorecardSourceError("CDF profile narrative and listing counts disagree")
    if any(
        measurements[k]["value"] != member["measurements"][k]["value"] for k in ["votes", "against"]
    ) or measurements["combined"]["value"] != str(int(numbers[1]) + int(numbers[2])):
        raise ScorecardSourceError("CDF profile summary and native component counts disagree")
    container = _one(article.select(".cdfendorse"), "CDF published action container is absent or repeated")
    endorsement_note = _text(_one(container.select(".endorsementnote"), "CDF profile action scope is missing"))
    actions = []
    for ordinal, li in enumerate(container.select("li.bill")):
        anchor = _one(li.select("a[href*='congress.gov/bill/']"), "CDF action has no unique legislative reference")
        spans = li.select("span.action")
        reason_node = _one(li.select("span#positive,span#negative"), "CDF action's source classification is missing")
        native_id = str(li.get("id", ""))
        labels = list(li.get("class", []))
        if (
            not spans
            or not native_id
            or labels
            not in [
                ["bill", "co-sponsored"],
                ["bill", "sponsored"],
                ["bill", "voted-for"],
                ["bill", "voted-against"],
                ["bill", "did-not-vote"],
            ]
        ):
            raise ScorecardSourceError("CDF action presentation has an unreviewed shape")
        action_text = " ".join(_text(span) for span in spans)
        full_text = _text(li)
        if not full_text.startswith(action_text + " "):
            raise ScorecardSourceError("CDF source action text is not the prefix of its published entry")
        citation, url = _text(anchor), str(anchor["href"])
        path = "article#post-" + member["post"] + f"/.cdfendorse/li.bill[{ordinal + 1}]"
        _official_reference(url, citation, path + "/a")
        actions.append(
            {
                "native_id": native_id,
                "ordinal": ordinal,
                "classes": labels,
                "action_text": action_text,
                "full_text": full_text,
                "item_title": full_text[len(action_text) + 1 :],
                "citation": citation,
                "url": url,
                "reason": str(reason_node["id"]),
                "path": path,
            }
        )
    return {
        "measurements": measurements,
        "bio": bio,
        "ribbon": ribbon,
        "actions": actions,
        "endorsement_note": endorsement_note,
    }


def _methodology(document):
    html = soup(document)
    node = _one(html.select("main .post-content"), "CDF methodology content is absent or repeated")
    text = _text(node)
    if not all(phrase in text for phrase in ["117th", "extra credit", "leadership", "sponsoring", "cosponsoring"]):
        raise ScorecardSourceError("CDF methodology no longer describes the reviewed scoring model")
    return text


def _bill_catalog(document):
    html = soup(document)
    content = _one(html.select("main .post-content"), "CDF bill catalog content is absent or repeated")
    note = _text(
        _one(
            [p for p in content.select("p") if "publicly endorsed by CDF" in _text(p)],
            "CDF endorsement legend is missing",
        )
    )
    records = []
    for ordinal, a in enumerate(content.select("a[href*='congress.gov/bill/']")):
        prefix = str(a.previous_sibling).strip()
        match = re.fullmatch(r"((?:H\.R\.|S\.|H\.J\.Res\.|S\.J\.Res\.|H\.Res\.|S\.Res\.)\s*\d+)\s*[–—-]", prefix)
        title = _text(a)
        if match is None or not title:
            raise ScorecardSourceError("CDF catalog citation/title shape changed")
        path = f"main/.post-content/a.bill[{ordinal + 1}]"
        citation, url = match[1], str(a["href"])
        _official_reference(url, citation, path)
        records.append(
            {
                "citation": citation,
                "url": url,
                "title": title,
                "endorsed": a.find_parent(["strong", "b"]) is not None,
                "path": path,
            }
        )
    if not records or len({(r["citation"], r["url"]) for r in records}) != len(records):
        raise ScorecardSourceError("CDF disclosed bill list is empty or repeats a source identity")
    return {"note": note, "records": records}


def list_scorecards(context):
    facts = _directory(context.read(INDEX, stage="cdf:listing", hosts=HOSTS), 1)
    if not facts["rows"]:
        raise ScorecardSourceError("CDF has no complete reviewed edition")
    return (EDITION,)


def acquire_scorecard(edition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("CDF requires its explicit reviewed 117th-Congress detail edition")
    directory = _roster(context, stage="directory")
    source, first = directory[0]
    methodology_document = context.read(METHOD, stage="cdf:methodology", hosts=HOSTS)
    methodology = _methodology(methodology_document)
    catalog_document = context.read(BILLS, stage="cdf:bills", hosts=HOSTS)
    catalog = _bill_catalog(catalog_document)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Children's Defense Fund Action",
        parser_version=parser_version,
        rendition_rule="complete source-counted 117th-Congress member directory, every explicit detail profile and disclosed action occurrence; conflicting index banner preserved; full source semantic reread",
        homepage="https://cdf-action.org/",
    )
    for number, (document, _) in enumerate(directory, 1):
        bundle.use(document, "directory-page:" + str(number))
    bundle.use(methodology_document, "report-methodology")
    bundle.use(catalog_document, "published-bill-list")
    bundle.tables["scorecards"][0].update(
        edition_label_text="117th Congress",
        timespan_text="During the 117th Congress",
        methodology_url=METHOD,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "index-banner",
                    "period_text": first["banner"],
                    "kind": "explicit",
                    "congress_text": "118" if "118th" in first["banner"] else None,
                    "source_path": "main/p[index-banner]",
                },
                {
                    "occurrence_id": "detail-edition",
                    "period_text": "During the 117th Congress",
                    "kind": "explicit",
                    "congress_text": "117",
                    "source_path": "article.member_profile/.biobody",
                },
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        methodology_document,
        "main/.post-content",
        methodology_id="report-model",
        methodology_url=METHOD,
        chamber_text="both",
        disclosure_status="partial",
        methodology_text=methodology,
    )
    bundle.add(
        "scorecard_methodologies",
        catalog_document,
        "main/.post-content/p[endorsement-legend]",
        methodology_id="bill-endorsements",
        disclosure_status="partial",
        methodology_text=catalog["note"],
    )
    for identifier, label in METRICS.items():
        bundle.add(
            "scorecard_metrics",
            source,
            first["rows"][0]["path"],
            metric_id=identifier,
            name=label,
            value_unit_text="grade" if identifier == "grade" else "count",
            chamber_text="both",
            period_text="During the 117th Congress",
            methodology_id="report-model",
            is_primary="true" if identifier == "grade" else "false",
        )
    for ordinal, item in enumerate(catalog["records"]):
        identifier = key("catalog", item["citation"])
        bundle.add(
            "scorecard_items",
            catalog_document,
            item["path"],
            item_id=identifier,
            publisher_item_id=item["citation"],
            item_kind_text="bill",
            title=item["title"],
            congress_text="117",
            bill_citation_text=item["citation"],
            references_json=json_column([_official_reference(item["url"], item["citation"], item["path"])]),
            publisher_position_text="publicly endorsed by CDF" if item["endorsed"] else None,
            position_basis="explicit" if item["endorsed"] else None,
            position_source_path=item["path"] + "/strong" if item["endorsed"] else None,
        )
        bundle.add(
            "scorecard_metric_items",
            catalog_document,
            item["path"],
            metric_id="grade",
            item_id=identifier,
            participation_id="published-bill-list",
            methodology_id="bill-endorsements" if item["endorsed"] else "report-model",
            publisher_position_text="publicly endorsed by CDF" if item["endorsed"] else None,
            position_basis="explicit" if item["endorsed"] else None,
        )
    profiles, source_items, item_keys = [], {}, {}
    for document, facts in directory:
        for member in facts["rows"]:
            profile_document = context.read(member["url"], stage="cdf:profile:" + member["post"], hosts=HOSTS)
            profile = _profile(profile_document, member)
            profiles.append((profile_document, member, profile))
            bundle.use(profile_document, "member-profile:" + member["post"])
            native_key = member["post"]
            bundle.add(
                "scorecard_members",
                document,
                member["path"],
                publisher_member_key=native_key,
                publisher_member_id=native_key,
                member_name=member["name"],
                chamber_text=member["chamber"],
                state=member["state"],
                district=member.get("district"),
                party=member["party"],
                period_text="During the 117th Congress",
                identifiers_json=json_column([{"scheme": "cdf_wp_post_id", "value": native_key}]),
                notes_text=json_column(
                    {
                        "publisher_label_text": member["label"],
                        "publisher_profile_href": member["source_href"],
                        "detail_context_text": profile["ribbon"],
                        "detail_summary_text": profile["bio"],
                        "detail_action_scope_text": profile["endorsement_note"],
                    }
                ),
            )
            for metric in METRICS:
                detail = metric in profile["measurements"]
                value = profile["measurements"][metric] if detail else member["measurements"][metric]
                location = value["path"] if detail else member["path"] + "/li.counteritem[" + metric + "]"
                bundle.add(
                    "scorecard_member_ratings",
                    profile_document if detail else document,
                    location,
                    publisher_member_key=native_key,
                    metric_id=metric,
                    value_text=value["value"],
                    value_number=None if metric == "grade" else decimal_text(value["value"]),
                    notes_text=json_column({"source_label_text": value["label"]}),
                )
            for action in profile["actions"]:
                fingerprint = (action["native_id"], action["citation"], action["url"], action["item_title"])
                identifier = key(
                    "profile-item",
                    action["native_id"],
                    sha256(json_column(list(fingerprint)).encode()).hexdigest()[:24],
                )
                if identifier in item_keys and item_keys[identifier] != fingerprint:
                    raise ScorecardSourceError("CDF source item identifier hash collision")
                if fingerprint not in source_items:
                    source_items[fingerprint] = identifier
                    item_keys[identifier] = fingerprint
                    bundle.add(
                        "scorecard_items",
                        profile_document,
                        action["path"],
                        item_id=identifier,
                        publisher_item_id=action["native_id"],
                        item_kind_text="bill",
                        title=action["item_title"],
                        congress_text="117",
                        bill_citation_text=action["citation"],
                        references_json=json_column(
                            [_official_reference(action["url"], action["citation"], action["path"] + "/a")]
                        ),
                    )
                    bundle.add(
                        "scorecard_metric_items",
                        profile_document,
                        action["path"],
                        metric_id="grade",
                        item_id=identifier,
                        participation_id="published-profile-actions",
                        methodology_id="report-model",
                    )
                bundle.add(
                    "scorecard_member_item_results",
                    profile_document,
                    action["path"],
                    result_id=key(native_key, action["native_id"], str(action["ordinal"])),
                    publisher_member_key=native_key,
                    metric_id="grade",
                    item_id=identifier,
                    participation_id="published-profile-actions",
                    action_text=action["action_text"],
                    result_text=action["full_text"],
                    reason_text=action["reason"],
                )
    repeated_directory = _roster(context, stage="directory:reread")
    if [facts for _, facts in directory] != [facts for _, facts in repeated_directory]:
        raise ScorecardSourceError("CDF complete directory changed during the source read")
    for number, (document, _) in enumerate(repeated_directory, 1):
        bundle.use(document, "directory-page:" + str(number), role="corroboration")
    for _, member, profile in profiles:
        repeated = context.read(member["url"], stage="cdf:profile:reread:" + member["post"], hosts=HOSTS)
        if _profile(repeated, member) != profile:
            raise ScorecardSourceError("CDF original member profile changed during the source read")
        bundle.use(repeated, "member-profile:" + member["post"], role="corroboration")
    repeated_method = context.read(METHOD, stage="cdf:methodology:reread", hosts=HOSTS)
    repeated_bills = context.read(BILLS, stage="cdf:bills:reread", hosts=HOSTS)
    if _methodology(repeated_method) != methodology or _bill_catalog(repeated_bills) != catalog:
        raise ScorecardSourceError("CDF methodology or complete disclosed bill list changed during the source read")
    bundle.use(repeated_method, "report-methodology", role="corroboration")
    bundle.use(repeated_bills, "published-bill-list", role="corroboration")
    return bundle.finish(
        "All directory pages complete and reconcile source grade/party/chamber/state populations; every original profile explicitly states 117th Congress, native summary fields agree, every repeated action occurrence survives, and complete directory/profiles/methodology/bills reread unchanged",
        declared={
            "directory_facets": first["facets"],
            "directory_pages": first["last"],
            "index_period_banner": first["banner"],
            "detail_congress": "117",
            "bill_catalog_scope": "every disclosed original bill-list entry; narrative bill totals do not establish full underlying scored corpus",
            "published_bill_list_entries": len(catalog["records"]),
            "profile_action_occurrences": sum(len(p["actions"]) for _, _, p in profiles),
            "item_identity_rule": "catalog citations and profile native IDs with exact literal citation/link/title fingerprint remain distinct; misleading HTML IDs are never official bill numbers",
            "grade_values": "A, B, C, D, F, L; L is the publisher leadership designation",
            "source_counts_basis": "source-declared directory facet counts and complete original published list/profile populations",
        },
    )
