"""Publisher-native Parks API periods, current directory context and exact action occurrences."""

from __future__ import annotations

import json
import re
from hashlib import sha256

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)

parser_version = "national-parks-action-native-api/1"
HOSTS = ("nationalparksaction.org",)
BASE = "https://nationalparksaction.org/wp-json/rds-bt50-scorecard/v1/"
INDEX = "https://nationalparksaction.org/scorecard/"
METRICS = ("score", "possible_score", "vote_index", "presence_score")
VOTE_FIELDS = {
    "billID",
    "stateBillID",
    "billName",
    "motion",
    "voteDate",
    "voteRating",
    "vote",
    "comment",
    "referenceUrl",
    "referenceUrlText",
}


def _json(source):
    """Preserve source numeric token spellings instead of round-tripping through floats."""
    try:
        return json.loads(
            source.body,
            parse_int=str,
            parse_float=str,
            parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
        )
    except (ValueError, UnicodeError):
        raise ScorecardSourceError("National Parks API did not supply complete finite JSON") from None


def _catalog(source):
    data = _json(source)
    try:
        entries = data["scorecards"]
        ids = set()
        if not isinstance(entries, list) or not entries:
            raise ValueError
        for entry in entries:
            card, bills = entry["scorecard"], entry["bills"]
            identity = card["scorecardID"]
            if (
                not re.fullmatch(r"\d+", identity)
                or identity in ids
                or card["stateCode"] != "US"
                or not card["scorecardName"].startswith("National Parks Action Fund ")
                or not isinstance(bills, list)
                or int(card["ratedBills"]) != len(bills)
                or len({b["billID"] for b in bills}) != len(bills)
            ):
                raise ValueError
            ids.add(identity)
            for bill in bills:
                if not bill["stateBillID"] or not bill["billName"] or bill["stateCode"] != "US":
                    raise ValueError
        return entries
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "National Parks API catalog lacks a complete unique federal bill/period enumeration"
        ) from None


def _edition(card, *, include_details=True):
    congress = re.search(r"\b(\d+)th Congress\b", card["scorecardName"])
    if congress is None:
        raise ScorecardSourceError("National Parks API edition has no explicit congressional period")
    return ScorecardEdition(
        "national_parks_action",
        ("api:" if include_details else "api-catalogue:") + card["scorecardID"],
        BASE + "bills/",
        card["scorecardName"],
        congress=congress[1],
        chamber="both",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext, *, include_details=True):
    source = context.read(BASE + "bills/", stage="scorecards:national_parks_action_api:listing", hosts=HOSTS)
    return tuple(_edition(entry["scorecard"], include_details=include_details) for entry in _catalog(source))


def _directory(source, catalog):
    data = _json(source)
    try:
        if not isinstance(data, list) or not data:
            raise ValueError
        ids, periods = set(), {entry["scorecard"]["scorecardID"] for entry in catalog}
        for member in data:
            if (
                not re.fullmatch(r"\d+", member["id"])
                or member["id"] in ids
                or not member["first_name"]
                or not member["last_name"]
                or not member["state"]
                or member["chamber"] not in {"House", "Senate"}
                or not isinstance(member["score_sets"], list)
            ):
                raise ValueError
            ids.add(member["id"])
            score_ids = set()
            for score in member["score_sets"]:
                if set(score) != {
                    "id",
                    "sessionid",
                    "niceTitle",
                    "score",
                    "possible_score",
                    "vote_index",
                    "presence_score",
                    "adjustment",
                }:
                    raise ValueError
                if (
                    score["id"] not in periods
                    or score["id"] in score_ids
                    or not score["niceTitle"]
                    or not re.fullmatch(r"\d+", score["sessionid"])
                    or not isinstance(score["adjustment"], (dict, list))
                ):
                    raise ValueError
                score_ids.add(score["id"])
                for metric in METRICS:
                    if (
                        not isinstance(score[metric], str)
                        or re.fullmatch(r"-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?", score[metric]) is None
                    ):
                        raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "National Parks API directory has incomplete identities or source-native score fields"
        ) from None


def _detail(source, bills):
    data = _json(source)
    try:
        if (
            data["statusCode"] != "200"
            or data["message"] != "Success"
            or not isinstance(data["billVotes"], list)
            or not isinstance(data["sponsoredBills"], list)
        ):
            raise ValueError
        ids = {b["billID"] for b in bills}
        for vote in data["billVotes"]:
            if (
                set(vote) != VOTE_FIELDS
                or vote["billID"] not in ids
                or not all(isinstance(v, str) for v in vote.values())
                or not vote["stateBillID"]
                or not vote["motion"]
                or not vote["vote"]
                or re.fullmatch(r"-?\d+(?:\.\d+)?", vote["voteRating"]) is None
            ):
                raise ValueError
        # Sponsorship requires its own reviewed source shape; do not silently drop a new result form.
        if data["sponsoredBills"]:
            raise ValueError
        return data["billVotes"]
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError(
            "National Parks API detail is incomplete, inconsistent with catalog, or has an unqualified sponsorship shape"
        ) from None


def _literal_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _reference(citation, path):
    kind = "nomination" if citation.startswith("PN") else "bill"
    ref = {"occurrence_id": "0", "citation_text": citation, "kind": kind, "source_path": path}
    if kind == "bill":
        ref["bill_citation_text"] = citation
    return _literal_json([ref])


def _catalog_item(bundle, source, bill, ordinal, bill_index, congress):
    path = f"/scorecards/{ordinal}/bills/{bill_index}"
    item_id = key("catalog-bill", bill["billID"])
    nomination = bill["stateBillID"].startswith("PN")
    bundle.add(
        "scorecard_items",
        source,
        path,
        item_id=item_id,
        publisher_item_id=bill["billID"],
        item_kind_text="nomination" if nomination else "publisher_bill_catalog",
        title=bill["billName"],
        congress_text=congress,
        bill_citation_text=None if nomination else bill["stateBillID"],
        references_json=_reference(bill["stateBillID"], path + "/stateBillID"),
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        path,
        methodology_id=item_id,
        methodology_text=_literal_json(bill),
        methodology_url=source.url,
        disclosure_status="literal API bill catalog metadata; catalog entry is not an invented roll call or proof of metric participation",
    )


def acquire_scorecard(edition, context: ScorecardContext, *, include_details=True):
    directory_source = context.read(
        BASE + "legislators/", stage="scorecards:national_parks_action_api:directory-start", hosts=HOSTS
    )
    catalog_source = context.read(
        BASE + "bills/", stage="scorecards:national_parks_action_api:catalog-start", hosts=HOSTS
    )
    styles_source = context.read(
        BASE + "styles/", stage="scorecards:national_parks_action_api:styles-start", hosts=HOSTS
    )
    catalog = _catalog(catalog_source)
    matches = [
        (i, entry)
        for i, entry in enumerate(catalog)
        if _edition(entry["scorecard"], include_details=include_details) == edition
    ]
    if len(matches) != 1:
        raise ScorecardSourceError("Selected National Parks API edition is no longer present exactly once")
    ordinal, selected = matches[0]
    card, bills = selected["scorecard"], selected["bills"]
    directory = _directory(directory_source, catalog)
    styles = _json(styles_source)
    if (
        not isinstance(styles, dict)
        or styles.get("score_type_to_display") != "voteindex"
        or not styles.get("header_subtxt")
        or not styles.get("info")
    ):
        raise ScorecardSourceError("National Parks API methodology/display settings changed")
    bundle = Bundle(
        edition,
        context,
        catalog_source,
        publisher_name="National Parks Action Fund",
        parser_version=parser_version,
        rendition_rule="parks-api-current-native-directory-historical-score-sets-complete-details/1"
        if include_details
        else "parks-api-native-directory-score-fields-and-bill-catalogue-no-member-actions/1",
        homepage="https://nationalparksaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        published_at_text=card["createDate"], updated_at_text=card["updateDate"], methodology_url=styles_source.url
    )
    bundle.use(directory_source, "native_directory_and_score_fields")
    bundle.use(catalog_source, "bill_catalog")
    bundle.use(styles_source, "methodology")
    bundle.add(
        "scorecard_methodologies",
        styles_source,
        "/",
        methodology_id="publisher-api-settings",
        methodology_text=_literal_json(styles),
        methodology_url=styles_source.url,
        disclosure_status="explicit native API configuration; UI grade, lifetime, rounding and attendance transformations are not published scores in this rendition",
    )
    for metric in METRICS:
        bundle.metric(directory_source, metric, metric, path="/score_sets/" + metric, primary=metric == "vote_index")
    for bill_index, bill in enumerate(bills):
        _catalog_item(bundle, catalog_source, bill, ordinal, bill_index, edition.congress)
    expected = 0
    action_ids = set()
    for index, member in enumerate(directory):
        member_key = key("native-directory", member["id"])
        source_path = f"/{index}"
        bundle.add(
            "scorecard_members",
            directory_source,
            source_path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            member_name=member["first_name"] + " " + member["last_name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["sub_district"],
            party=member["party"],
            notes_text=_literal_json({k: member[k] for k in ("legislatorKey", "legislatorKeySimple", "districtCode")}),
        )
        sets = [(i, score) for i, score in enumerate(member["score_sets"]) if score["id"] == card["scorecardID"]]
        if not sets:
            continue
        expected += 1
        score_index, score = sets[0]
        if score["niceTitle"] != edition.congress + "th":
            raise ScorecardSourceError("National Parks API score-set period contradicts its catalog")
        for metric in METRICS:
            bundle.add(
                "scorecard_member_ratings",
                directory_source,
                source_path + f"/score_sets/{score_index}/{metric}",
                metric_id=metric,
                publisher_member_key=member_key,
                value_text=score[metric],
                value_number=decimal_text(score[metric]),
                notes_text=_literal_json({k: score[k] for k in ("id", "sessionid", "niceTitle", "adjustment")}),
            )
        if not include_details:
            continue
        detail_url = BASE + f"legislators/detail/?legislatorId={member['id']}&scorecardId={card['scorecardID']}"
        detail = context.read(
            detail_url, stage="scorecards:national_parks_action_api:detail-" + member["id"], hosts=HOSTS
        )
        votes = _detail(detail, bills)
        bundle.use(detail, "member_detail:" + member["id"])
        for position, vote in enumerate(votes):
            path = f"/billVotes/{position}"
            facts = {k: v for k, v in vote.items() if k != "vote"}
            # No publisher action ID/chamber exists. Share only exactly identical native facts.
            item_id = "native-vote:" + sha256(_literal_json(facts).encode()).hexdigest()
            if item_id not in action_ids:
                action_ids.add(item_id)
                nomination = vote["stateBillID"].startswith("PN")
                roll = re.search(r"\bRC#\s*(\d+)\b", vote["motion"])
                bundle.add(
                    "scorecard_items",
                    detail,
                    path,
                    item_id=item_id,
                    item_kind_text="publisher_vote",
                    title=vote["billName"] + " — " + vote["motion"],
                    congress_text=edition.congress,
                    item_date_text=vote["voteDate"],
                    roll_number_text=roll[1] if roll else None,
                    bill_citation_text=None if nomination else vote["stateBillID"],
                    references_json=_reference(vote["stateBillID"], path + "/stateBillID"),
                    publisher_position_text=vote["comment"] or None,
                    position_basis="explicit" if vote["comment"] else None,
                    position_source_path=path + "/comment" if vote["comment"] else None,
                )
                bundle.add(
                    "scorecard_methodologies",
                    detail,
                    path,
                    methodology_id=item_id,
                    methodology_text=_literal_json(facts),
                    methodology_url=detail.url,
                    disclosure_status="literal native action metadata including voteRating; missing action chamber and session stay unknown",
                )
                bundle.add(
                    "scorecard_metric_items",
                    detail,
                    path,
                    metric_id="vote_index",
                    item_id=item_id,
                    participation_id="native-api-vote",
                    methodology_id=item_id,
                    publisher_position_text=vote["comment"] or None,
                    position_basis="explicit" if vote["comment"] else None,
                )
            bundle.add(
                "scorecard_member_item_results",
                detail,
                path + "/vote",
                item_id=item_id,
                metric_id="vote_index",
                participation_id="native-api-vote",
                publisher_member_key=member_key,
                result_id=str(position),
                result_text=vote["vote"],
                action_text=vote["vote"],
            )
    if expected == 0:
        raise ScorecardSourceError("National Parks API period unexpectedly has no native score-set records")
    for label, before, route in (
        ("directory", directory_source, "legislators/"),
        ("catalog", catalog_source, "bills/"),
        ("styles", styles_source, "styles/"),
    ):
        after = context.read(BASE + route, stage="scorecards:national_parks_action_api:" + label + "-end", hosts=HOSTS)
        if after.body != before.body:
            raise ScorecardSourceError(
                "National Parks API source changed during complete enumeration; preserve prior scope"
            )
        bundle.use(
            after,
            {"directory": "native_directory_and_score_fields", "catalog": "bill_catalog", "styles": "methodology"}[
                label
            ],
            role="corroboration",
        )
    rule = (
        "Complete named API catalogue ratings/items rendition: finite current directory and catalog arrays, declared bill counts, every native score-set field for the selected period and byte-identical directory/catalog/styles rereads. Member action details are outside this rendition and remain pending; failed detail reads are never treated as absent actions. Current directory identities stay beside historical scores; no historical roster, UI grades or lifetime calculations are invented."
        if not include_details
        else "Complete native API rendition for one catalog period: finite directory and catalog arrays, declared bill count, every available member-period detail response, and byte-identical directory/catalog/styles rereads. Current directory identities remain beside historical scores; absent historical roster members and UI-computed grades/lifetime values are not invented. Raw negative/decimal scores, internal session IDs, action metadata and missing legislative chamber/session remain literal."
    )
    return bundle.finish(
        rule,
        declared={
            "catalog_bills": len(bills),
            "native_directory_members": len(directory),
            "available_period_score_sets": expected,
        },
    )


class NationalParksActionAPICatalogueReader:
    """Named complete catalogue rendition; member action qualification remains independent."""

    parser_version = parser_version

    def list_scorecards(self, context):
        return list_scorecards(context, include_details=False)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(edition, context, include_details=False)
