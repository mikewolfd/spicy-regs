"""LCV's 2025 CSV exports, corroborated against complete HTML tables and every vote detail.

CSV score strings are authoritative: ``0`` remains ``0`` while the alternate HTML
shows ``0%``. Item CSVs' incidental current ratings never override edition ratings.
"""

from __future__ import annotations

import csv
import io
from urllib.parse import urlencode, urlsplit

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    soup,
)

parser_version = "lcv-2025-csv-html/2"
HOSTS = ("www.lcv.org",)
BASE = "https://www.lcv.org"
MEMBERS = BASE + "/congressional-scorecard/members-of-congress/"
VOTES = BASE + "/congressional-scorecard/congressional-votes/"
METHODOLOGY = BASE + "/congressional-scorecard/about-the-scorecard/"
EDITION = ScorecardEdition("lcv", "2025", MEMBERS, "2025 National Environmental Scorecard", year="2025", chamber="both")
MEMBER_QUERY = {
    "export": "true",
    "sort": "state-a-z",
    "active_tab": "",
    "chamber": "senate",
    "street_address": "",
    "zip": "",
    "session_year": "2025",
    "state": "",
    "party": "All",
    "last_name": "",
    "include_former": "1",
    "export-type": "moc-listing",
}
VOTE_QUERY = {
    "export": "true",
    "chamber": "senate",
    "show": "scorecard",
    "session_year": "2025",
    "issue_filter": "all",
    "export-type": "votes",
}
MEMBER_HEADER = ["First Name", "Last Name", "Party", "District", "Year Score", "Lifetime Score", "URL"]
ITEM_HEADER = ["Vote Title", "Year", "Roll Call Vote Number", "Vote Link"]
RESULT_HEADER = [
    "State",
    "First Name",
    "Last Name",
    "Party",
    "District",
    "Year Score",
    "Lifetime Score",
    "Vote Type",
    "URL",
]


def _csv(document):
    try:
        return list(csv.reader(io.StringIO(document.body.decode("utf-8-sig")), strict=True))
    except (UnicodeError, csv.Error) as error:
        raise ScorecardSourceError("LCV CSV is malformed") from error


def parse_members(document):
    chamber = state = None
    headers = set()
    members = []
    for position, row in enumerate(_csv(document), 1):
        if not row:
            continue
        if len(row) == 1:
            if row[0] in {"House", "Senate"}:
                chamber, state = row[0], None
            else:
                state = row[0]
        elif row == MEMBER_HEADER and chamber:
            if chamber in headers:
                raise ScorecardSourceError("LCV member export repeats a chamber header")
            headers.add(chamber)
        elif len(row) == 7 and chamber in headers and state:
            members.append((position, chamber, state, row))
        else:
            raise ScorecardSourceError("LCV member export structure changed")
    if headers != {"House", "Senate"} or not members or len({r[-1][-1] for r in members}) != len(members):
        raise ScorecardSourceError("LCV member export is incomplete or repeats member URLs")
    return members


def parse_items(document):
    chamber = None
    headers = set()
    items = []
    for position, row in enumerate(_csv(document), 1):
        if not row:
            continue
        if len(row) == 1 and row[0] in {"Senate Votes", "House Votes"}:
            chamber = row[0].removesuffix(" Votes")
        elif row == ITEM_HEADER and chamber:
            headers.add(chamber)
        elif len(row) == 4 and chamber in headers and row[1] == "2025":
            items.append((position, chamber, row))
        else:
            raise ScorecardSourceError("LCV vote export identity or structure changed")
    if headers != {"House", "Senate"} or not items or len({r[-1][-1] for r in items}) != len(items):
        raise ScorecardSourceError("LCV vote export is incomplete or repeats item URLs")
    return items


def _cards(document):
    html = soup(document)
    cards = html.select(".congress-item")
    result = {}
    for card in cards:
        anchor = card.select_one("a.card-link[href]")
        if anchor is None or anchor["href"] in result:
            raise ScorecardSourceError("LCV member HTML repeats or omits a member URL")
        result[anchor["href"]] = card
    if not result or html.select(".pagination .next, a.next.page-numbers"):
        raise ScorecardSourceError("LCV member HTML is empty or paginated")
    return html, result


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    source = context.read(MEMBERS + "?session_year=2025", stage="scorecards:lcv:listing", hosts=HOSTS)
    _, cards = _cards(source)
    years = {
        node.get_text(strip=True) for card in cards.values() if (node := card.select_one(".congress-year-score .year"))
    }
    if years != {"2025"}:
        raise ScorecardSourceError("LCV requested edition is not displayed")
    return (EDITION,)


def _member_key(url):
    parts = urlsplit(url)
    if parts.hostname != HOSTS[0] or not parts.path.startswith("/moc/") or parts.query:
        raise ScorecardSourceError("LCV member URL changed identity shape")
    return parts.path.removeprefix("/moc/").rstrip("/")


def parse_results(document):
    metadata = {}
    rows = []
    saw_header = False
    for position, row in enumerate(_csv(document), 1):
        if not row:
            continue
        if not saw_header:
            if row == RESULT_HEADER:
                saw_header = True
            elif len(row) == 2 and row[0] not in metadata:
                metadata[row[0]] = row[1]
            elif row != ["Votes"]:
                raise ScorecardSourceError("LCV item export preamble changed")
        elif len(row) == 1:
            continue  # Publisher state group, repeated independently in every data row.
        elif len(row) == 9:
            rows.append((position, row))
        else:
            raise ScorecardSourceError("LCV member-item export row changed")
    if not rows or not saw_header or len({row[-1] for _, row in rows}) != len(rows):
        raise ScorecardSourceError("LCV item export is empty or repeats a member")
    return metadata, rows


def _methodology(bundle, context):
    document = context.read(METHODOLOGY, stage="scorecards:lcv:methodology", hosts=HOSTS)
    html = soup(document)
    anchors = html.select("a#score-calculation")
    item = anchors[0].find_parent("li") if len(anchors) == 1 else None
    heading = item.select_one(".uk-accordion-title") if item else None
    content = item.select_one(".uk-accordion-content") if item else None
    if heading is None or heading.get_text(" ", strip=True) != "How does LCV calculate scores?" or content is None:
        raise ScorecardSourceError("LCV calculation-methodology section changed")
    paragraphs = content.find_all("p", recursive=False)
    texts = [p.get_text(" ", strip=True) for p in paragraphs[:2]]
    if (
        len(texts) != 2
        or any(not text or len(text) > 1000 for text in texts)
        or "annual scores" not in texts[0]
        or "Lifetime scores" not in texts[1]
    ):
        raise ScorecardSourceError("LCV annual/lifetime methodology paragraphs changed")
    bundle.use(document, "calculation_methodology")
    bundle.tables["scorecards"][0]["methodology_url"] = METHODOLOGY
    for position, (metric, text) in enumerate(zip(("annual", "lifetime"), texts, strict=True), 1):
        identifier = metric + "-calculation"
        bundle.add(
            "scorecard_methodologies",
            document,
            f"li:has(a#score-calculation) .uk-accordion-content > p:nth-of-type({position})",
            methodology_id=identifier,
            methodology_text=text,
            methodology_url=METHODOLOGY,
            disclosure_status="partial",
        )
        next(row for row in bundle.tables["scorecard_metrics"] if row["metric_id"] == metric)["methodology_id"] = (
            identifier
        )


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("LCV reader supports only the qualified 2025 edition")
    member_csv = context.read(MEMBERS + "?" + urlencode(MEMBER_QUERY), stage="scorecards:lcv:members-csv", hosts=HOSTS)
    members = parse_members(member_csv)
    member_html = context.read(MEMBERS + "?session_year=2025", stage="scorecards:lcv:members-html", hosts=HOSTS)
    _, cards = _cards(member_html)
    if set(cards) != {row[-1] for _, _, _, row in members}:
        raise ScorecardSourceError("LCV complete HTML and CSV member sets disagree")
    bundle = Bundle(
        edition,
        context,
        member_csv,
        publisher_name="League of Conservation Voters",
        parser_version=parser_version,
        rendition_rule="lcv-edition-csv-values-item-csv-results-html-corroboration/1",
        homepage=BASE,
    )
    bundle.use(member_csv, "members_and_ratings")
    bundle.use(member_html, "members_and_ratings", role="corroboration")
    for metric in ("annual", "lifetime"):
        bundle.metric(
            member_csv,
            metric,
            "Year Score" if metric == "annual" else "Lifetime Score",
            path="CSV/chamber headers",
            primary=metric == "annual",
        )
    _methodology(bundle, context)
    member_ids = set()
    for position, chamber, state, row in members:
        url = row[-1]
        member_id = _member_key(url)
        member_ids.add(member_id)
        card = cards[url]
        for selector, expected in (("year", row[4]), ("lifetime", row[5])):
            node = card.select_one(f".congress-{selector}-score .data-score")
            literal = node.get_text(strip=True) if node else ""
            compared = "na" if literal == "N/A" else literal.removesuffix("%")
            if compared != expected:
                raise ScorecardSourceError(
                    "LCV alternate rating renditions disagree beyond their declared display rule"
                )
        year = card.select_one(".congress-year-score .year")
        if year and year.get_text(strip=True) != "2025":
            raise ScorecardSourceError("LCV member annual score is a different year")
        path = f"CSV/row[{position}]"
        bundle.add(
            "scorecard_members",
            member_csv,
            path,
            publisher_member_key=member_id,
            publisher_member_id=url,
            member_name=row[0] + " " + row[1],
            state=state,
            district=row[3],
            party=row[2],
            chamber_text=chamber,
        )
        for metric, value in zip(("annual", "lifetime"), row[4:6], strict=True):
            bundle.add(
                "scorecard_member_ratings",
                member_csv,
                path + "/" + metric,
                metric_id=metric,
                publisher_member_key=member_id,
                value_text=value,
                value_number=decimal_text(value),
            )
    item_csv = context.read(VOTES + "?" + urlencode(VOTE_QUERY), stage="scorecards:lcv:items-csv", hosts=HOSTS)
    items = parse_items(item_csv)
    item_html = context.read(VOTES + "?session_year=2025", stage="scorecards:lcv:items-html", hosts=HOSTS)
    html = soup(item_html)
    html_urls = {a["href"] for a in html.select("a[href]") if "/roll-call-vote/" in a["href"]}
    if html_urls != {row[-1] for _, _, row in items}:
        raise ScorecardSourceError("LCV complete HTML and CSV item sets disagree")
    bundle.use(item_csv, "item_catalog")
    bundle.use(item_html, "item_catalog", role="corroboration")
    for _, chamber, item in items:
        url = item[-1]
        detail = context.read(url, stage="scorecards:lcv:item-html", hosts=HOSTS)
        html, item_cards = _cards(detail)
        form = html.select_one("form.ajax-form")
        fields = (
            {node.get("name"): node.get("value", "") for node in form.select('input[type="hidden"]')} if form else {}
        )
        if fields.get("export-type") != "rcv" or not fields.get("export-post-id"):
            raise ScorecardSourceError("LCV item export form changed")
        params = {
            "export": "true",
            "sort": fields.get("sort", "state-a-z"),
            "voteOption": "",
            "export-post-id": fields["export-post-id"],
            "export-type": "rcv",
        }
        result_csv = context.read(url + "?" + urlencode(params), stage="scorecards:lcv:item-csv", hosts=HOSTS)
        metadata, results = parse_results(result_csv)
        if (
            metadata.get("Year") != "2025"
            or metadata.get("Congress") != chamber
            or metadata.get("Vote Title") != item[0]
            or metadata.get("Roll Call Vote Number") != item[2]
        ):
            raise ScorecardSourceError("LCV item export and catalog identities disagree")
        if set(item_cards) != {row[-1] for _, row in results}:
            raise ScorecardSourceError("LCV complete item HTML and CSV member sets disagree")
        item_id = fields["export-post-id"]
        bundle.use(result_csv, "item:" + item_id)
        bundle.use(detail, "item:" + item_id, role="corroboration")
        bundle.add(
            "scorecard_items",
            result_csv,
            "CSV/preamble",
            item_id=item_id,
            publisher_item_id=item_id,
            item_kind_text=metadata.get("Vote Type"),
            title=metadata["Vote Title"],
            item_date_text=metadata["Year"],
            chamber_text=chamber,
            roll_number_text=metadata["Roll Call Vote Number"],
            publisher_position_text=metadata.get("Pro-Environment Vote"),
            position_basis="explicit",
            position_source_path="CSV/preamble/Pro-Environment Vote",
        )
        bundle.add(
            "scorecard_metric_items",
            result_csv,
            "CSV/preamble",
            metric_id="annual",
            item_id=item_id,
            participation_id="scorecard",
            publisher_position_text=metadata.get("Pro-Environment Vote"),
            position_basis="explicit",
        )
        for position, row in results:
            member_id = _member_key(row[-1])
            if member_id not in member_ids or item_cards[row[-1]].get("data-vote-type") != row[-2]:
                raise ScorecardSourceError("LCV item member or literal result does not reconcile")
            bundle.add(
                "scorecard_member_item_results",
                result_csv,
                f"CSV/row[{position}]/Vote Type",
                metric_id="annual",
                item_id=item_id,
                participation_id="scorecard",
                publisher_member_key=member_id,
                result_id="reported",
                result_text=row[-2],
            )
    return bundle.finish(
        "Both chamber member and item catalogs reconcile between complete HTML and CSV; every "
        "listed item export is acquired, its identity checked, and all reported member results "
        "reconcile by source member URL and literal data-vote-type to its complete HTML table. "
        "Edition CSV ratings are selected; incidental item-export current ratings are corroborating "
        "context and never replace edition ratings. Item dates retain each item export Year literally. "
        "The current publisher annual/lifetime calculation paragraphs are captured as partial "
        "methodology disclosure; no historical effective date or score reproduction is asserted."
    )
