"""IJM current federal scorecard API reader with source-stated grade configuration."""

from .rds_bt50 import Publisher, acquire_current, list_current

parser_version = "ijm-rds-bt50-current-api/3"
PUBLISHER = Publisher(
    "ijm",
    "International Justice Mission",
    "https://www.ijm.org/",
    "https://scorecard.ijm.org/",
    3995,
    "119th Congress",
    parser_version,
    range_grade_configuration=True,
    rendered_api_json=True,
)
EDITION = PUBLISHER.edition


def list_scorecards(context):
    return list_current(context, PUBLISHER)


def acquire_scorecard(edition, context):
    return acquire_current(edition, context, PUBLISHER)
