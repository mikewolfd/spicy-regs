"""NFIB's original publisher-linked live federal Quorum JSON and CSV scorecards."""

from __future__ import annotations

import re
from urllib.parse import urljoin, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import quorum_public
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "nfib-119-live-public-quorum/1"
INDEX = "https://www.nfib.com/how-congress-voted/"
SCORECARD = "https://www.nfib.com/candidate-scorecard/"
HOSTS = ("www.nfib.com",)
EDITION = ScorecardEdition("nfib", "119-current-quorum", INDEX, "How Congress Voted", congress="119", chamber="both")
NUMERIC_TYPES = {"percentage_of_columns", "votes_with_organization", "votes_against_organization", "sum_of_columns"}
RESULT_LABELS = {1: "Support", 2: "Oppose", 5: "Present", 8: "Delegate", None: ""}


def _index(document):
    html = soup(document)
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("NFIB index does not reach HTML end")
    links = {urljoin(INDEX, str(a["href"])) for a in html.select("a[href]")}
    paragraphs = [p.get_text(" ", strip=True) for p in html.select("p")]
    current = [p for p in paragraphs if "current 119th Congress scorecard" in p]
    rules = [p for p in paragraphs if "70 percent or more" in p and "Guardian of Small Business Award" in p]
    if SCORECARD not in links or len(current) != 1 or len(rules) != 1:
        raise ScorecardSourceError("NFIB original index no longer declares the reviewed federal period and award rule")
    return current[0], rules[0]


def _wrapper(document):
    html = soup(document)
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("NFIB scorecard wrapper does not reach HTML end")
    selected = {}
    for chamber in ("Senate", "House"):
        containers = html.select("#" + chamber.lower() + "-list")
        frames = containers[0].select("iframe[src]") if len(containers) == 1 else []
        if len(frames) != 1:
            raise ScorecardSourceError("NFIB must identify one original sheet for each federal chamber")
        url = urlsplit(str(frames[0]["src"]))
        match = re.fullmatch(r"/spreadsheet/external/([A-Za-z]{10,80})/", url.path)
        if url.scheme != "https" or url.netloc != "www.quorum.us" or url.query or url.fragment or match is None:
            raise ScorecardSourceError("NFIB source sheet is outside the reviewed public route")
        selected[chamber] = match[1]
    if len(set(selected.values())) != 2:
        raise ScorecardSourceError("NFIB repeats one chamber sheet")
    return selected


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="nfib:index", hosts=HOSTS))
    _wrapper(context.read(SCORECARD, stage="nfib:wrapper", hosts=HOSTS))
    return (EDITION,)


def _review(sheet, chamber):
    if sheet.data["name"] != f"How Congress Voted ({chamber})":
        raise ScorecardSourceError("NFIB public sheet does not identify its selected chamber")
    if any(c["column_type"] not in NUMERIC_TYPES | {"field", "stance_record"} for c in sheet.columns):
        raise ScorecardSourceError("NFIB sheet introduced an unreviewed scoring column")
    primary = [c for c in sheet.columns if c["column_type"] == "percentage_of_columns"]
    if len(primary) != 1 or primary[0]["name"] != "Score" or primary[0]["should_hide_column_on_public"]:
        raise ScorecardSourceError("NFIB published primary score is missing or ambiguous")
    fields = [c for c in sheet.columns if c["column_type"] == "field"]
    if len(fields) != 1 or fields[0]["field"] != "title" or not fields[0]["should_hide_column_on_public"]:
        raise ScorecardSourceError("NFIB source context column changed")
    items = [c for c in sheet.columns if c["column_type"] == "stance_record"]
    votes = set()
    for c in items:
        if (
            c["should_hide_column_on_public"]
            or type(c["vote_id"]) is not int
            or c["vote_id"] < 1
            or c["vote_id"] in votes
        ):
            raise ScorecardSourceError("NFIB source actions lack unique visible publisher vote identities")
        votes.add(c["vote_id"])
    if not items:
        raise ScorecardSourceError("NFIB has no complete visible scoring-action catalog")
    return primary[0], items


def _member(member, chamber):
    match = re.search(r"\(([A-Za-z]+)-([A-Z]{2})(?:-([^()]+))?\)$", member["name"])
    if match is None or (chamber == "Senate") != (match[3] is None):
        raise ScorecardSourceError("NFIB literal member display context changed")
    return member["firstname"] + " " + member["lastname"], match[1], match[2], match[3]


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
    if edition != EDITION:
        raise ScorecardSourceError("NFIB reader supports only its reviewed 119th live public sheets")
    index = context.read(INDEX, stage="nfib:index", hosts=HOSTS)
    period, award = _index(index)
    wrapper = context.read(SCORECARD, stage="nfib:wrapper", hosts=HOSTS)
    slugs = _wrapper(wrapper)
    sheets = {c: quorum_public.acquire(context, slug, "nfib:" + c.lower()) for c, slug in slugs.items()}
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="National Federation of Independent Business",
        parser_version=parser_version,
        rendition_rule="publisher-selected live chamber sheets; complete public JSON cache and CSV EOF reconcile; every selected source field stable reread; PDF reports are separate editions",
        homepage="https://www.nfib.com/",
    )
    bundle.use(index, "period", "award-methodology")
    bundle.use(wrapper, "chamber-sheet-links")
    bundle.tables["scorecards"][0].update(
        periods_json=json_column(
            [
                {
                    "occurrence_id": "current",
                    "period_text": period,
                    "kind": "explicit",
                    "source_path": "p:current-congress",
                    "congress_text": "119",
                }
            ]
        )
    )
    bundle.add(
        "scorecard_methodologies",
        index,
        "p:guardian-threshold",
        methodology_id="guardian-award",
        methodology_text=award,
        disclosure_status="explicit",
    )
    counts = {}
    for chamber, sheet in sheets.items():
        primary, items = _review(sheet, chamber)
        document = sheet.json_document
        bundle.use(document, chamber + ":members", chamber + ":metric-configuration", chamber + ":actions")
        bundle.use(sheet.csv_document, chamber + ":published-values")
        units = {
            c["id"]: "%" if c["column_type"] == "percentage_of_columns" else "votes"
            for c in sheet.columns
            if c["column_type"] in NUMERIC_TYPES
        }
        metrics = quorum_public.append_measurements(bundle, sheet, chamber, NUMERIC_TYPES, {primary["id"]}, units)
        primary_id = metrics[primary["id"]]
        visible = {
            c["id"]: position
            for position, c in enumerate((c for c in sheet.columns if not c["should_hide_column_on_public"]), 1)
        }
        positions = {c["id"]: i for i, c in enumerate(sheet.data["columns"])}
        roster_ids = {str(m["id"]) for m in sheet.data["row_data"]}
        for c in items:
            location = f"$.columns[{positions[c['id']]}]"
            identifier = key(chamber, str(c["id"]))
            methodology = key(chamber, "column", str(c["id"]))
            bundle.add(
                "scorecard_methodologies",
                document,
                location,
                methodology_id=methodology,
                chamber_text=chamber,
                methodology_text=json_column(quorum_public.column_metadata(c, roster_ids)),
                disclosure_status="partial",
            )
            bill = re.search(r"(?:H\.Con\.Res\.|H\.J\.Res\.|H\.R\.|H R)\s*\d+", c["name"])
            references = [
                {
                    "occurrence_id": "publisher-vote",
                    "citation_text": str(c["vote_id"]),
                    "kind": "quorum_vote",
                    "source_path": location + ".vote_id",
                    "congress_text": "119",
                    "chamber_text": chamber,
                }
            ]
            if bill:
                references.append(
                    {
                        "occurrence_id": "bill",
                        "citation_text": bill[0],
                        "kind": "bill",
                        "source_path": location + ".name",
                        "congress_text": "119",
                        "chamber_text": chamber,
                        "bill_citation_text": bill[0],
                    }
                )
            bundle.add(
                "scorecard_items",
                document,
                location,
                item_id=identifier,
                publisher_item_id=str(c["vote_id"]),
                item_kind_text=c["column_type"],
                title=c["name"],
                congress_text="119",
                chamber_text=chamber,
                bill_citation_text=bill[0] if bill else None,
                references_json=json_column(references),
            )
            bundle.add(
                "scorecard_metric_items",
                document,
                location,
                metric_id=primary_id,
                item_id=identifier,
                participation_id="visible-sheet",
                methodology_id=methodology,
            )
        blank_scores = 0
        for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True), 2):
            identity = str(member["id"])
            member_key = key(chamber, identity)
            name, party, state, district = _member(member, chamber)
            location = f"$.row_data[{ordinal - 2}]"
            bundle.add(
                "scorecard_members",
                document,
                location,
                publisher_member_key=member_key,
                publisher_member_id=identity,
                identifiers_json=json_column([{"scheme": "quorum", "value": identity}]),
                member_name=name,
                chamber_text=chamber,
                party=party,
                state=state,
                district=district,
                notes_text=json_column(
                    {
                        "display_name": member["name"],
                        "title": next(c["data"].get(identity) for c in sheet.columns if c["column_type"] == "field"),
                    }
                ),
            )
            if row[visible[primary["id"]]] == "":
                blank_scores += 1
                bundle.add(
                    "scorecard_member_ratings",
                    sheet.csv_document,
                    f"CSV/row={ordinal}/column={visible[primary['id']] + 1}",
                    publisher_member_key=member_key,
                    metric_id=primary_id,
                )
            for c in items:
                value, native = row[visible[c["id"]]], c["data"].get(identity)
                if (
                    type(native) not in {int, type(None)}
                    or native not in RESULT_LABELS
                    or RESULT_LABELS[native] != value
                ):
                    raise ScorecardSourceError(
                        "NFIB published action labels differ from their reviewed source enum cache"
                    )
                bundle.add(
                    "scorecard_member_item_results",
                    sheet.csv_document,
                    f"CSV/row={ordinal}/column={visible[c['id']] + 1}",
                    result_id="published-cell",
                    item_id=key(chamber, str(c["id"])),
                    publisher_member_key=member_key,
                    metric_id=primary_id,
                    participation_id="visible-sheet",
                    result_text=value or None,
                    reason_text=json_column({"quorum_code": native}),
                )
        counts[chamber] = {
            "source_row_count": sheet.data["row_count"],
            "source_columns": len(sheet.columns),
            "visible_actions": len(items),
            "blank_primary_score_cells": blank_scores,
            "visible_result_cells": sheet.data["row_count"] * len(items),
            "sheet_name": sheet.data["name"],
        }
    repeated_index = context.read(INDEX, stage="nfib:index:reread", hosts=HOSTS)
    repeated_wrapper = context.read(SCORECARD, stage="nfib:wrapper:reread", hosts=HOSTS)
    if _index(repeated_index) != (period, award) or _wrapper(repeated_wrapper) != slugs:
        raise ScorecardSourceError("NFIB original period, award rule or chamber selection changed during acquisition")
    bundle.use(repeated_index, role="corroboration")
    bundle.use(repeated_wrapper, role="corroboration")
    for chamber, sheet in sheets.items():
        repeated = quorum_public.acquire(context, slugs[chamber], "nfib:" + chamber.lower() + ":reread")
        if quorum_public.semantic_facts(repeated) != quorum_public.semantic_facts(sheet):
            raise ScorecardSourceError("NFIB complete public sheet facts changed during acquisition")
        bundle.use(repeated.json_document, role="corroboration")
        bundle.use(repeated.csv_document, role="corroboration")
    return bundle.finish(
        "Both publisher-selected chambers; complete public JSON row_count reconciles CSV EOF, visible columns, member order and every action cache label; all source facts stable reread",
        declared=counts,
    )
