"""The New American's original Freedom Index report pages and embedded native vote JSON."""

from __future__ import annotations

import json
import re

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "new-american-native-report/2"
INDEX = "https://freedomindex.us/us/reports/"
ABOUT = "https://freedomindex.us/about/"
HOSTS = ("freedomindex.us",)
REPORT_URL = re.compile(r"https://freedomindex\.us/us/report/(\d+)/")
REPORT_TITLE = re.compile(r"(Freedom Index|Scorecard) (\d{3})-(\d+)")
VOTE_FIELDS = {
    "id",
    "title",
    "impact_summary",
    "text_more",
    "bill_number",
    "rollcall_number",
    "votes_for",
    "votes_against",
    "date_formatted",
    "bill_url",
    "url_vote",
    "citation_html",
    "citation_keys",
}
GLYPHS = {"fa-check", "fa-xmark", "fa-minus"}


def _literal(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def _html(source):
    if b"</html>" not in source.body.lower() or "html" not in (source.response.content_type or "").lower():
        raise ScorecardSourceError("Freedom Index source is not a complete HTML response")
    return soup(source)


def _catalog(source):
    document = _html(source)
    entries, identities = [], set()
    for link in document.select("h2 a[href]"):
        url = REPORT_URL.fullmatch(link["href"])
        if not url:
            continue
        title = link.get_text(" ", strip=True)
        match = REPORT_TITLE.fullmatch(title)
        if not match or url[1] in identities:
            raise ScorecardSourceError("Freedom Index catalogue has duplicate or unreviewed report identities")
        identities.add(url[1])
        entries.append((url[1], title, match[1], match[2], match[3]))
    if not entries or document.select("a[rel=next], .pagination a, button[data-load-more]"):
        raise ScorecardSourceError("Freedom Index report catalogue is empty or requires unreviewed pagination")
    current = {
        series: max((int(c), int(period)) for _, _, s, c, period in entries if s == series)
        for series in {entry[2] for entry in entries}
    }
    return tuple(
        ScorecardEdition(
            "new_american",
            "report:" + identifier,
            f"https://freedomindex.us/us/report/{identifier}/",
            title,
            congress=congress,
            chamber="both",
            is_current=(int(congress), int(period)) == current[series],
        )
        for identifier, title, series, congress, period in entries
    )


def list_scorecards(context):
    return _catalog(context.read(INDEX, stage="scorecards:new-american:listing", hosts=HOSTS))


def _methodology(source):
    document = _html(source)
    headings = [h for h in document.select("h3") if h.get_text(" ", strip=True) == "The Scoring"]
    if len(headings) != 1:
        raise ScorecardSourceError("Freedom Index source scoring methodology is missing")
    text = headings[0].parent.get_text(" ", strip=True)
    if not all(value in text for value in ["constitutional", "five votes", "lifetime", "did not vote"]):
        raise ScorecardSourceError("Freedom Index scoring methodology changed; review required")
    sections = {"The Scoring": text}
    for heading in document.select("h2,h3"):
        name = heading.get_text(" ", strip=True)
        if name in {
            "Constitutional Methodology",
            "Three powerful and effective tools to hold your lawmakers accountable:",
        }:
            sections[name] = heading.parent.get_text(" ", strip=True)
    for accordion in document.select(".accordion-item"):
        heading = accordion.select_one("h2")
        if heading is None:
            raise ScorecardSourceError("Freedom Index methodology question has no heading")
        name = heading.get_text(" ", strip=True)
        if name in sections:
            raise ScorecardSourceError("Freedom Index methodology heading repeats")
        sections[name] = accordion.get_text(" ", strip=True)
    return sections


def _unique_fields(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("Duplicate embedded JSON field")
        result[name] = value
    return result


def _votes(document, edition, chamber):
    scripts = [
        script.get_text() for script in document.find_all("script") if "window.fiVoteData =" in script.get_text()
    ]
    try:
        if len(scripts) != 1:
            raise ValueError
        data = json.JSONDecoder(object_pairs_hook=_unique_fields).raw_decode(
            scripts[0].split("window.fiVoteData =", 1)[1].lstrip()
        )[0]
        cards = document.select(".fi-vote-card[data-vote-id]")
        expected = 10 if edition.title.startswith("Freedom Index ") else 6
        if not isinstance(data, dict) or len(data) != expected or len(cards) != expected:
            raise ValueError
        result, seen = [], set()
        for card in cards:
            identifier = card["data-vote-id"]
            vote = data[identifier]
            heading = card.select_one("h3")
            positions = [
                span
                for span in card.select("span.text-nowrap")
                if span.get_text(" ", strip=True).startswith("Constitutional Vote:")
            ]
            if (
                identifier in seen
                or set(vote) != VOTE_FIELDS
                or type(vote["id"]) is not int
                or str(vote["id"]) != identifier
                or heading is None
                or heading.get_text(" ", strip=True) != vote["title"]
                or not all(isinstance(vote[k], str) for k in VOTE_FIELDS - {"id", "citation_keys"})
                or not isinstance(vote["citation_keys"], list)
                or any(not isinstance(c, str) for c in vote["citation_keys"])
                or not vote["title"]
                or not vote["text_more"]
                or len(positions) != 1
            ):
                raise ValueError
            position = positions[0].get_text(" ", strip=True).removeprefix("Constitutional Vote:").strip()
            if position not in {"Yes", "No"} or (vote["rollcall_number"] and not vote["rollcall_number"].isdigit()):
                raise ValueError
            if vote["url_vote"] != f"https://freedomindex.us/us/vote/{identifier}/":
                raise ValueError
            seen.add(identifier)
            result.append(
                {
                    "id": identifier,
                    "native": vote,
                    "position": position,
                    "ordinal": heading.get_text(" ", strip=True).split(".", 1)[0],
                    "chamber": chamber,
                    "visible_text": card.get_text(" ", strip=True),
                }
            )
        if seen != set(data):
            raise ValueError
        return result
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ScorecardSourceError("Freedom Index vote cards and embedded JSON do not reconcile") from None


def _glyph(cell):
    icons = cell.select("i")
    if len(icons) != 1 or cell.get_text(" ", strip=True):
        raise ScorecardSourceError("Freedom Index result cell has an unreviewed glyph")
    glyph = set(icons[0].get("class", [])) & GLYPHS
    if len(glyph) != 1 or set(icons[0].get("class", [])) != {"fas", next(iter(glyph))}:
        raise ScorecardSourceError("Freedom Index result icon changed")
    return next(iter(glyph))


def _identity(element):
    link = element.select_one("a[href]")
    match = re.fullmatch(r"https://freedomindex\.us/legislator/(\d+)/", link["href"] if link else "")
    if not match or not link.get_text(" ", strip=True):
        raise ScorecardSourceError("Freedom Index member is missing its native identity")
    return match[1], link.get_text(" ", strip=True)


def _report(source, edition, chamber, *, grid=False):
    document = _html(source)
    title, header = document.select_one("#fi-report h1"), document.select_one("#fi-report h2")
    if title is None or title.get_text(" ", strip=True) != edition.title or header is None:
        raise ScorecardSourceError("Freedom Index response belongs to a different report")
    if header.get_text(" ", strip=True) != chamber + " Votes":
        raise ScorecardSourceError("Freedom Index response belongs to a different chamber")
    votes = _votes(document, edition, chamber)
    rows = (
        document.select("#fi-report-grid > .fi-legislator-card-vote")
        if grid
        else document.select("#fi-report-table-body > tr.scorecard-row")
    )
    if not rows or document.select("#fi-report .pagination a, #fi-report a[rel=next]"):
        raise ScorecardSourceError("Freedom Index member snapshot is empty or paginated")
    if "$('.fi-legislator-card-vote, .scorecard-row').each" not in source.body.decode("utf-8"):
        raise ScorecardSourceError("Freedom Index client-side complete-member filtering changed")
    if not grid:
        headings = [
            h.get_text(" ", strip=True) for h in document.select("#fi-report-table-body")[0].parent.select("thead th")
        ]
        if headings != ["Name", "Party", "State", "Score", *[v["ordinal"] for v in votes]]:
            raise ScorecardSourceError("Freedom Index table headers do not match the complete vote sequence")
    members, seen = [], set()
    for row in rows:
        identifier, name = _identity(row)
        if identifier in seen or (grid and row.get("data-leg-id") != identifier):
            raise ScorecardSourceError("Freedom Index member appears twice or changes native identity")
        seen.add(identifier)
        if grid:
            titles = [c.get_text(" ", strip=True) for c in row.select(".card-body > div > .flex-grow-1")]
            if titles != [v["native"]["title"] for v in votes]:
                raise ScorecardSourceError("Freedom Index member card has an incomplete item grid")
            cells = row.select(".card-body > div > .flex-shrink-0")
            score = row.select_one(".card-header .fs-7.fw-bold")
            party = None
        else:
            children = row.find_all(["td", "th"], recursive=False)
            if len(children) != 4 + len(votes):
                raise ScorecardSourceError("Freedom Index member row is incomplete")
            cells, score, party = children[4:], children[3], children[1].get_text(" ", strip=True)
            if children[2].get_text(" ", strip=True) != row.get("data-state"):
                raise ScorecardSourceError("Freedom Index visible member state conflicts with its native attribute")
        score = score.get_text(" ", strip=True) if score else ""
        if (re.fullmatch(r"\d{1,3}%", score) is None and score != "N/A") or not row.get("data-state"):
            raise ScorecardSourceError("Freedom Index native member rating or state changed")
        if score != "N/A" and int(score[:-1]) > 100:
            raise ScorecardSourceError("Freedom Index rating exceeds its explicit source scale")
        members.append(
            {
                "id": identifier,
                "name": name,
                "state": row["data-state"],
                "district": row.get("data-district") or None,
                "party": party,
                "party_attribute": row.get("data-party"),
                "score_attribute": row.get("data-score"),
                "score": score,
                "glyphs": [_glyph(cell) for cell in cells],
            }
        )
    intro = document.select_one("#fi-report > .container-xl > .row > .col-12 > .card > .card-body")
    paragraphs = [p.get_text(" ", strip=True) for p in intro.select("p")] if intro else []
    if not paragraphs:
        raise ScorecardSourceError("Freedom Index report introduction is missing")
    return {"votes": votes, "members": members, "intro": paragraphs}


def _grid_reconciles(table, grid):
    def comparable(member):
        return {k: v for k, v in member.items() if k != "party"}

    return (
        table["votes"] == grid["votes"]
        and table["intro"] == grid["intro"]
        and {m["id"]: comparable(m) for m in table["members"]} == {m["id"]: comparable(m) for m in grid["members"]}
    )


def acquire_scorecard(edition, context):
    catalog = context.read(INDEX, stage="scorecards:new-american:catalogue-start", hosts=HOSTS)
    editions = _catalog(catalog)
    if edition not in editions:
        raise ScorecardSourceError("Selected Freedom Index edition is absent or changed")
    methodology = context.read(ABOUT, stage="scorecards:new-american:methodology-start", hosts=HOSTS)
    scoring = _methodology(methodology)
    selected, documents, grids = {}, {}, {}
    for code, chamber in [("H", "House"), ("S", "Senate")]:
        url = edition.source_url + "chamber/" + code + "/"
        grid = context.read(url, stage="scorecards:new-american:" + code + "-grid", hosts=HOSTS)
        table = context.read(url + "?view=table", stage="scorecards:new-american:" + code + "-table-start", hosts=HOSTS)
        selected[chamber], rendered = _report(table, edition, chamber), _report(grid, edition, chamber, grid=True)
        if not _grid_reconciles(selected[chamber], rendered):
            raise ScorecardSourceError("Freedom Index complete native table and card views differ")
        documents[chamber], grids[chamber] = table, grid
    rereads = []
    for code, chamber in [("H", "House"), ("S", "Senate")]:
        end = context.read(
            edition.source_url + "chamber/" + code + "/?view=table",
            stage="scorecards:new-american:" + code + "-table-end",
            hosts=HOSTS,
        )
        if _report(end, edition, chamber) != selected[chamber]:
            raise ScorecardSourceError("Freedom Index complete report changed during acquisition")
        rereads.append((end, chamber + "_native_table"))
    end = context.read(INDEX, stage="scorecards:new-american:catalogue-end", hosts=HOSTS)
    if _catalog(end) != editions:
        raise ScorecardSourceError("Freedom Index report catalogue changed during acquisition")
    rereads.append((end, "source_catalogue"))
    end = context.read(ABOUT, stage="scorecards:new-american:methodology-end", hosts=HOSTS)
    if _methodology(end) != scoring:
        raise ScorecardSourceError("Freedom Index methodology changed during acquisition")
    rereads.append((end, "methodology"))
    bundle = Bundle(
        edition,
        context,
        catalog,
        publisher_name="The New American",
        parser_version=parser_version,
        homepage="https://thenewamerican.com/",
        rendition_rule="freedom-index-complete-native-report-card-and-table-views/1",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        methodology_url=ABOUT, series_id=key("new_american", edition.title.rsplit(" ", 1)[0])
    )
    bundle.use(catalog, "source_catalogue")
    bundle.use(methodology, "methodology")
    for name, text in scoring.items():
        bundle.add(
            "scorecard_methodologies",
            methodology,
            "heading=" + name,
            methodology_id="publisher-scoring" if name == "The Scoring" else key("publisher-methodology", name),
            methodology_text=text,
            methodology_url=ABOUT,
            disclosure_status="explicit source selection, scoring, fiscal cost and nonvoting/eligibility rules; published scores retained without reproduction",
        )
    for source, group in rereads:
        bundle.use(source, group, role="corroboration")
    for chamber, facts in selected.items():
        source = documents[chamber]
        bundle.use(source, chamber + "_native_table")
        bundle.use(grids[chamber], chamber + "_native_table", role="corroboration")
        metric_id = key(chamber, "report-score")
        bundle.metric(source, metric_id, "Report Score", path="#fi-report-table-body", chamber=chamber, unit="percent")
        for ordinal, paragraph in enumerate(facts["intro"]):
            bundle.add(
                "scorecard_methodologies",
                source,
                f"#fi-report/intro/p/{ordinal}",
                methodology_id=key(chamber, "intro", str(ordinal)),
                chamber_text=chamber,
                methodology_text=paragraph,
                methodology_url=source.url,
                disclosure_status="literal original report introduction; source inconsistencies retained",
            )
        for vote in facts["votes"]:
            native, item_id = vote["native"], key("vote", vote["id"])
            path = "script:window.fiVoteData/" + vote["id"]
            bundle.add(
                "scorecard_items",
                source,
                path,
                item_id=item_id,
                publisher_item_id=vote["id"],
                item_kind_text="roll_call" if native["rollcall_number"] else "publisher_action",
                title=native["title"],
                congress_text=edition.congress,
                chamber_text=chamber,
                item_date_text=native["date_formatted"] or None,
                roll_number_text=native["rollcall_number"] or None,
                bill_citation_text=native["bill_number"] or None,
                references_json=_literal(
                    [
                        {
                            "occurrence_id": "native-bill-url",
                            "kind": "url",
                            "citation_text": native["bill_url"],
                            "source_path": path + "/bill_url",
                        }
                    ]
                    if native["bill_url"]
                    else []
                ),
                publisher_position_text=vote["position"],
                position_basis="explicit",
                position_source_path="#vcard-" + vote["id"] + "/Constitutional Vote",
            )
            bundle.add(
                "scorecard_methodologies",
                source,
                path,
                methodology_id=item_id,
                chamber_text=chamber,
                methodology_text=_literal({"native_vote_json": native, "native_vote_card_text": vote["visible_text"]}),
                methodology_url=native["url_vote"],
                disclosure_status="literal embedded native vote JSON; narrative, source citations, fiscal cost and source count conflicts remain unchanged",
            )
            bundle.add(
                "scorecard_metric_items",
                source,
                "#vcard-" + vote["id"],
                metric_id=metric_id,
                item_id=item_id,
                participation_id="report-grid",
                publisher_position_text=vote["position"],
                position_basis="explicit",
                methodology_id="publisher-scoring",
                counts_toward_metric="true",
            )
        for ordinal, member in enumerate(facts["members"]):
            path, member_key = f"#fi-report-table-body/tr/{ordinal}", key("legislator", chamber, member["id"])
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=member_key,
                publisher_member_id=member["id"],
                member_name=member["name"],
                chamber_text=chamber,
                state=member["state"],
                district=member["district"],
                party=member["party"],
                identifiers_json=_literal([{"scheme": "freedomindex.us:legislator", "value": member["id"]}]),
                notes_text=_literal({"native_party_attribute": member["party_attribute"]}),
            )
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/Score",
                metric_id=metric_id,
                publisher_member_key=member_key,
                value_text=member["score"],
                value_number=decimal_text(member["score"]),
                notes_text=_literal({"native_data_score": member["score_attribute"]}),
            )
            for vote, glyph in zip(facts["votes"], member["glyphs"], strict=True):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + "/vote/" + vote["ordinal"],
                    publisher_member_key=member_key,
                    item_id=key("vote", vote["id"]),
                    result_id="native-icon",
                    metric_id=metric_id,
                    participation_id="report-grid",
                    result_text=glyph,
                    reason_text="Literal native Font Awesome icon class; no official Yea/Nay action inferred.",
                )
    return bundle.finish(
        "Complete original report rendition: every chamber's finite member table, embedded native vote map, "
        "full card grid and explicit item headers reconcile; final table, catalogue and methodology rereads "
        "remain unchanged. Report products stay separate; native icons and reported scores remain literal."
    )
