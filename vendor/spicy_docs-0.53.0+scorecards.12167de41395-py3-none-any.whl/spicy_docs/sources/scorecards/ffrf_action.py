"""FFRF Action Fund's native public Quorum scores, item cells and chamber methods."""

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import quorum_public
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "ffrf-action-public-quorum/1"
HOSTS = ("ffrfaction.org",)
INDEX = "https://ffrfaction.org/scorecard/"
PERIOD_NOTICE = (
    "https://ffrfaction.org/ffrf-action-fund-launches-2025-2026-dynamic-house-scorecard-on-state-church-issues/"
)
EDITION = ScorecardEdition("ffrf_action", "119", INDEX, "Dynamic House Scorecard", congress="119", chamber="both")
ROUTES = {"House": INDEX, "Senate": "https://ffrfaction.org/senate-scorecard/"}
METHODS = {
    "House": "https://ffrfaction.org/scorecard-calculations/",
    "Senate": "https://ffrfaction.org/senate-scorecard-calculations/",
}
PRIMARY = {"House": 2127545, "Senate": 2109456}
NUMERIC_TYPES = {
    "sum_of_columns",
    "custom_number",
    "custom_tag",
    "nay_votes",
    "number_of_times_sponsored_and_cosponsored",
    "multiplication_of_columns",
}
ITEM_TYPES = {"caucus_membership", "sponsorship_record", "voting_record"}
# Exact publisher column IDs and literal method descriptions; aliases are source
# specific, never inferred from fuzzy title similarity or a bill-only join.
ITEMS = {
    "House": {
        2109465: (
            "Congressional Freethought Caucus",
            "Congressional Freethought Membership",
            "Congressional Freethought Membership",
        ),
        2109587: (
            "Keep Public Funds in Public Schools Act",
            "Keep Public Funds in Public Schools Act",
            "Co-Sponsoring:",
        ),
        2109466: ("Do No Harm Act", "Do No Harm Act", "Co-Sponsoring:"),
        2109467: ("Stop Comstock Act", "Stop Comstock Act", "Co-Sponsoring:"),
        2109468: (
            "Supreme Court Tenure Establishment and Retirement Modernization Act",
            "Supreme Court Tenure Establishment and Retirement Modernization Act of 2025 (SCERT)",
            "Co-Sponsoring:",
        ),
        2109469: (
            "GOP Reconciliation Bill",
            "Voting ‘Nay’ on GOP Reconciliation Bill",
            "Voting ‘Nay’ on GOP Reconciliation Bill",
        ),
    },
    "Senate": {
        2109398: (
            "Keep Public Funds in Public Schools Act",
            "Keep Public Funds in Public Schools Act",
            "Co-sponsoring:",
        ),
        2109387: ("Do No Harm Act", "Do No Harm Act", "Co-sponsoring:"),
        2109388: ("Stop Comstock Act", "Stop Comstock Act", "Co-sponsoring:"),
        2109389: (
            "GOP Reconciliation Bill",
            "Voting ‘Nay’ on GOP Reconciliation Bill",
            "Voting ‘Nay’ on GOP Reconciliation Bill",
        ),
        2109390: (
            "On the Nomination of Emil Bove",
            "Emil Bove for circuit judge of the U.S. Court of Appeals for the Third Circuit",
            "Voting ‘Nay’ on Trump Nominees:",
        ),
        2109391: (
            "On the Nomination of Russell Vought",
            "Russell Vought for director of the Office of Management and Budget (OMB)",
            "Voting ‘Nay’ on Trump Nominees:",
        ),
    },
}


def _wrapper(document, chamber):
    slug = quorum_public.external_slug(document)
    titles = soup(document).select("h2")
    if len(titles) != 1 or titles[0].get_text(" ", strip=True) != "Dynamic " + chamber + " Scorecard":
        raise ScorecardSourceError("FFRF original wrapper title or chamber changed")
    return slug


def _period_notice(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("FFRF edition-period notice does not reach HTML document end")
    html = soup(document)
    titles = html.select("h1")
    published = html.select('meta[property="article:published_time"]')
    content = html.select(".elementor-widget-theme-post-content")
    expected = "FFRF Action Fund launches 2025-2026 Dynamic House Scorecard on state-church issues"
    if len(titles) != 1 or titles[0].get_text(" ", strip=True) != expected or len(published) != 1 or len(content) != 1:
        raise ScorecardSourceError("FFRF current House edition-period notice changed")
    paragraphs = [node.get_text(" ", strip=True) for node in content[0].select("p")]
    periods = [
        text
        for text in paragraphs
        if text.startswith("The FFRF Action Fund is pleased to announce its 2025-2026 Dynamic House Scorecard.")
    ]
    congresses = [text for text in paragraphs if "a comprehensive evaluation of the 119th Congress." in text]
    if len(periods) != 1 or len(congresses) != 1 or not published[0].get("content"):
        raise ScorecardSourceError("FFRF source period cannot be tied to its stated Congress")
    return {
        "title": expected,
        "published_at": published[0]["content"],
        "period_statement": periods[0],
        "congress_statement": congresses[0],
    }


def _method(document, chamber):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("FFRF methodology does not reach HTML document end")
    nodes = [
        node
        for node in soup(document).select(".elementor-widget-text-editor")
        if node.get_text(" ", strip=True).startswith("All " + chamber + " members are awarded points")
    ]
    if len(nodes) != 1:
        raise ScorecardSourceError("FFRF chamber scoring method is missing or ambiguous")
    node = nodes[0]
    text = node.get_text(" ", strip=True)
    effective = re.findall(r"As of (.*?), the scoring criteria are:", text)
    if len(effective) != 1:
        raise ScorecardSourceError("FFRF methodology version statement changed")
    leaves = [li for li in node.select("li") if li.find("li") is None]
    weighted = {}
    for ordinal, leaf in enumerate(leaves, 1):
        literal = leaf.get_text(" ", strip=True)
        weight = re.search(r" \((\d+%[^()]*)\)$", literal)
        if weight is None:
            continue
        label = literal[: weight.start()]
        if label in weighted:
            raise ScorecardSourceError("FFRF repeats a scoring-method item")
        parent = leaf.find_parent("li")
        parent_text = None
        if parent:
            parent_text = " ".join(
                part.get_text(" ", strip=True) if hasattr(part, "get_text") else str(part).strip()
                for part in parent.contents
                if getattr(part, "name", None) != "ul"
            ).strip()
        weighted[label] = {
            "text": literal,
            "weight_text": weight[1],
            "weight_number": weight[1].split("%")[0],
            "links": [{"text": a.get_text(" ", strip=True), "url": a["href"]} for a in leaf.select("a[href]")],
            "parent_text": parent_text,
            "ordinal": ordinal,
        }
    if set(weighted) != {item[1] for item in ITEMS[chamber].values()}:
        raise ScorecardSourceError("FFRF scoring items differ from the exact reviewed chamber method")
    for _title, label, target in ITEMS[chamber].values():
        if target != label and weighted[label]["parent_text"] != target:
            raise ScorecardSourceError("FFRF source preferred action grouping changed")
    return text, effective[0], weighted


def _references(item):
    references = []
    for ordinal, link in enumerate(item["links"], 1):
        url = link["url"]
        bill = re.fullmatch(r"https://www\.congress\.gov/bill/(\d+)th-congress/(house|senate)-bill/(\d+)", url)
        senate = re.fullmatch(
            r"https://www\.senate\.gov/legislative/LIS/roll_call_votes/vote(\d+)(\d)/vote_\1_\2_0*(\d+)\.htm", url
        )
        house = re.fullmatch(r"https://clerk\.house\.gov/Votes/\d{4}0*(\d+)", url)
        if not (bill or senate or house):
            raise ScorecardSourceError("FFRF method acquired an unreviewed legislative citation route")
        reference = {
            "occurrence_id": str(ordinal),
            "citation_text": url,
            "kind": "bill" if bill else "roll_call",
            "source_path": f"method/leaf-li={item['ordinal']}/a={ordinal}/@href",
        }
        if bill:
            reference.update(congress_text=bill[1], chamber_text=bill[2].title(), bill_citation_text=url)
        elif senate:
            reference.update(
                congress_text=senate[1], chamber_text="Senate", session_text=senate[2], roll_number_text=senate[3]
            )
        elif house:
            reference.update(chamber_text="House", roll_number_text=house[1])
        references.append(reference)
    return references


def list_scorecards(context: ScorecardContext):
    # Older launch articles reuse this URL; they do not themselves supply a
    # separate historical score snapshot.
    for chamber, url in ROUTES.items():
        wrapper = context.read(url, stage="ffrf-action:" + chamber + ":discovery", hosts=HOSTS)
        _wrapper(wrapper, chamber)
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("FFRF requested edition is outside the observed publisher current-Congress source")
    notice = context.read(PERIOD_NOTICE, stage="ffrf-action:period-notice", hosts=HOSTS)
    notice_shape = _period_notice(notice)
    selected = {}
    for chamber, url in ROUTES.items():
        wrapper = context.read(url, stage="ffrf-action:" + chamber + ":wrapper", hosts=HOSTS)
        slug = _wrapper(wrapper, chamber)
        method = context.read(METHODS[chamber], stage="ffrf-action:" + chamber + ":method", hosts=HOSTS)
        shape = _method(method, chamber)
        sheet = quorum_public.acquire(context, slug, "ffrf-action:" + chamber)
        if sheet.data["name"] != chamber + " Scorecard for 119th Congress":
            raise ScorecardSourceError("FFRF public sheet states another Congress or chamber")
        selected[chamber] = wrapper, method, shape, sheet
    bundle = Bundle(
        edition,
        context,
        selected["House"][0],
        publisher_name="FFRF Action Fund",
        parser_version=parser_version,
        rendition_rule="ffrf-action-csv-reported-values-json-identities-method-html-weights/1",
        homepage="https://ffrfaction.org/",
    )
    periods = []
    declared = {}
    bundle.use(notice, "House:period-notice")
    bundle.add(
        "scorecard_methodologies",
        notice,
        ".elementor-widget-theme-post-content",
        methodology_id="House:edition-period-notice",
        chamber_text="House",
        methodology_text=json_column(notice_shape),
        disclosure_status="explicit",
    )
    periods.append(
        {
            "occurrence_id": "House:published-edition-period",
            "period_text": notice_shape["title"],
            "kind": "explicit",
            "source_path": notice.url + "#h1",
            "congress_text": "119",
            "chamber_text": "House",
        }
    )
    for chamber, (wrapper, method, shape, sheet) in selected.items():
        text, effective, weighted = shape
        jsondoc, csvdoc = sheet.json_document, sheet.csv_document
        bundle.use(wrapper, chamber + ":wrapper")
        bundle.use(method, chamber + ":method")
        bundle.use(jsondoc, chamber + ":members", chamber + ":items", chamber + ":configuration")
        bundle.use(csvdoc, chamber + ":ratings", chamber + ":results")
        bundle.add(
            "scorecard_methodologies",
            jsondoc,
            "$",
            methodology_id=key(chamber, "publisher-sheet-scope"),
            chamber_text=chamber,
            methodology_text=json_column(
                {field: value for field, value in sheet.data.items() if field not in {"columns", "row_data"}}
            ),
            disclosure_status="explicit",
        )
        periods.append(
            {
                "occurrence_id": chamber + ":sheet",
                "period_text": sheet.data["name"],
                "kind": "explicit",
                "source_path": jsondoc.url + "#$.name",
                "congress_text": "119",
                "chamber_text": chamber,
            }
        )
        method_id = key(chamber, "publisher-method")
        bundle.add(
            "scorecard_methodologies",
            method,
            ".elementor-widget-text-editor",
            methodology_id=method_id,
            chamber_text=chamber,
            effective_at_text=effective,
            methodology_text=text,
            methodology_url=method.url,
            disclosure_status="explicit",
        )
        for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True)):
            identity = quorum_public.member_context(member, sheet, row)
            bundle.add(
                "scorecard_members",
                jsondoc,
                f"$.row_data[{ordinal}]",
                publisher_member_key=key(chamber, str(member["id"])),
                publisher_member_id=str(member["id"]),
                identifiers_json=json_column([{"scheme": "quorum", "value": str(member["id"])}]),
                member_name=identity["name"],
                chamber_text=chamber,
                state=identity["state"],
                district=identity["district"],
                party=identity["party"],
                period_text=sheet.data["name"],
                notes_text=json_column(
                    {"display_name": identity["display_name"], "csv_fields": identity["csv_values"]}
                ),
            )
        if any(column["column_type"] not in NUMERIC_TYPES | ITEM_TYPES | {"field"} for column in sheet.columns):
            raise ScorecardSourceError("FFRF public sheet contains an unreviewed column kind")
        metrics = quorum_public.append_measurements(
            bundle, sheet, chamber, NUMERIC_TYPES, {PRIMARY[chamber]}, {PRIMARY[chamber]: "points"}
        )
        visible = {
            column["id"]: position
            for position, column in enumerate((c for c in sheet.columns if not c["should_hide_column_on_public"]), 1)
        }
        items = [
            column
            for column in sheet.columns
            if column["column_type"] in ITEM_TYPES and not column["should_hide_column_on_public"]
        ]
        if {column["id"] for column in items} != set(ITEMS[chamber]):
            raise ScorecardSourceError("FFRF visible item IDs differ from the reviewed source method map")
        positions = {column["id"]: index for index, column in enumerate(sheet.data["columns"])}
        for column in sheet.columns:
            if column["column_type"] not in ITEM_TYPES:
                continue
            path = f"$.columns[{positions[column['id']]}]"
            bundle.add(
                "scorecard_methodologies",
                jsondoc,
                path,
                methodology_id=key(chamber, "item-column", str(column["id"])),
                chamber_text=chamber,
                methodology_text=json_column(
                    quorum_public.column_metadata(column, {str(m["id"]) for m in sheet.data["row_data"]})
                ),
                disclosure_status="explicit",
            )
            if column["should_hide_column_on_public"]:
                continue
            expected_title, label, target = ITEMS[chamber][column["id"]]
            if column["name"] != expected_title:
                raise ScorecardSourceError("FFRF source item title changed from its reviewed exact method mapping")
            item = weighted[label]
            refs = _references(item)
            refs = [{**reference, "source_path": method.url + "#" + reference["source_path"]} for reference in refs]
            item_id = key(chamber, str(column["id"]))
            locator = method.url + "#method/leaf-li=" + str(item["ordinal"])
            bundle.add(
                "scorecard_items",
                jsondoc,
                path,
                item_id=item_id,
                publisher_item_id=str(column["id"]),
                item_kind_text=column["column_type"],
                title=column["name"],
                chamber_text=chamber,
                congress_text=refs[0].get("congress_text") if len(refs) == 1 else None,
                session_text=refs[0].get("session_text") if len(refs) == 1 else None,
                roll_number_text=refs[0].get("roll_number_text") if len(refs) == 1 else None,
                bill_citation_text=refs[0].get("bill_citation_text") if len(refs) == 1 else None,
                references_json=json_column(refs),
                publisher_position_text=target,
                position_basis="explicit",
                position_source_path=locator,
            )
            participation_id = "publisher-chamber-method"
            bundle.add(
                "scorecard_metric_items",
                method,
                "method/leaf-li=" + str(item["ordinal"]),
                metric_id=metrics[PRIMARY[chamber]],
                item_id=item_id,
                participation_id=participation_id,
                methodology_id=method_id,
                publisher_position_text=target,
                position_basis="explicit",
                weight_text=item["weight_text"],
                weight_number=item["weight_number"],
                contribution_rule_text=item["text"],
                counts_toward_metric="true",
            )
            for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True), 2):
                value = row[visible[column["id"]]]
                bundle.add(
                    "scorecard_member_item_results",
                    csvdoc,
                    f"CSV/row={ordinal}/column={visible[column['id']] + 1}",
                    result_id=participation_id,
                    metric_id=metrics[PRIMARY[chamber]],
                    item_id=item_id,
                    participation_id=participation_id,
                    publisher_member_key=key(chamber, str(member["id"])),
                    result_text=value,
                    action_text=value or None,
                )
        reread_wrapper = context.read(ROUTES[chamber], stage="ffrf-action:" + chamber + ":wrapper:reread", hosts=HOSTS)
        reread_method = context.read(METHODS[chamber], stage="ffrf-action:" + chamber + ":method:reread", hosts=HOSTS)
        reread = quorum_public.acquire(context, sheet.data["public_slug"], "ffrf-action:" + chamber + ":reread")
        if (
            _wrapper(reread_wrapper, chamber) != sheet.data["public_slug"]
            or _method(reread_method, chamber) != shape
            or quorum_public.semantic_facts(reread) != quorum_public.semantic_facts(sheet)
        ):
            raise ScorecardSourceError("FFRF complete member, item, score or method facts changed during acquisition")
        bundle.use(reread_wrapper, chamber + ":wrapper", role="corroboration")
        bundle.use(reread_method, chamber + ":method", role="corroboration")
        bundle.use(
            reread.json_document,
            chamber + ":members",
            chamber + ":items",
            chamber + ":configuration",
            role="corroboration",
        )
        bundle.use(reread.csv_document, chamber + ":ratings", chamber + ":results", role="corroboration")
        declared[chamber] = {
            "json_row_count": sheet.data["row_count"],
            "json_column_count": len(sheet.columns),
            "visible_scoring_column_count": len(items),
        }
    reread_notice = context.read(PERIOD_NOTICE, stage="ffrf-action:period-notice:reread", hosts=HOSTS)
    if _period_notice(reread_notice) != notice_shape:
        raise ScorecardSourceError("FFRF source edition-period notice changed during acquisition")
    bundle.use(reread_notice, "House:period-notice", role="corroboration")
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text="119th Congress",
        methodology_url=METHODS["House"],
        periods_json=json_column(periods),
        timespan_text="2025-2026",
    )
    return bundle.finish(
        "Each public JSON row_count reconciles unique source members and exact complete CSV EOF/member/visible-column order; all reported final scores and visible item cells copied literally. Exact source column IDs and literal method titles reconcile every visible item/weight; raw hidden adjustments, parameters, cached measurements and formula relationships remain separate. Current source facts agree on second complete JSON/CSV/method/wrapper read; no formula evaluated or historical snapshot inferred.",
        declared=declared,
    )
