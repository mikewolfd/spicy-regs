"""NumbersUSA's original JSON gradecards, with nested category and action observations.

The edition covers the publisher's selected-Congress grade-search population. Historical
scores embedded in a current member chart are retained in the capture; they do
not establish a complete historical roster. Grades never become calculated scores.
"""

from __future__ import annotations

import hashlib
import json
import re
from html.parser import HTMLParser

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "numbersusa-congress-json/1"
BASE = "https://grades.numbersusa.org/v1/"
INDEX = "https://www.numbersusa.org/grades/"
HOSTS = ("grades.numbersusa.org", "www.numbersusa.org")


def _text(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ScorecardSourceError("NumbersUSA scalar changed representation")
    return str(value)


def _id(value):
    value = _text(value)
    if value is None or not re.fullmatch(r"[1-9][0-9]*", value):
        raise ScorecardSourceError("NumbersUSA native identifier is absent or malformed")
    return value


def _read(context, route, stage):
    document = context.read(BASE + route, stage="scorecards:numbersusa:" + stage, hosts=HOSTS)
    if "json" not in (document.response.content_type or "").lower():
        raise ScorecardSourceError("NumbersUSA API response is not JSON")
    return document, json_data(document)


def _options(data):
    fields = {"states", "subjects", "congress_terms", "chambers", "current_congress_id"}
    if not isinstance(data, dict) or not fields <= data.keys():
        raise ScorecardSourceError("NumbersUSA filter catalog shape changed")
    congress = _id(data["current_congress_id"])
    for field in fields - {"current_congress_id"}:
        rows = data[field]
        if not isinstance(rows, list) or not rows or any(not isinstance(row, dict) or "id" not in row for row in rows):
            raise ScorecardSourceError("NumbersUSA filter population is empty or malformed")
        if len({_text(row["id"]) for row in rows}) != len(rows):
            raise ScorecardSourceError("NumbersUSA filter repeats an identity")
    if {row.get("name") for row in data["chambers"]} != {"House", "Senate"}:
        raise ScorecardSourceError("NumbersUSA federal chamber scope changed")
    if congress not in {_id(row["id"]) for row in data["congress_terms"]}:
        raise ScorecardSourceError("NumbersUSA current Congress is outside its edition catalog")
    if {"", "-1"} - {_text(row["id"]) for row in data["subjects"]}:
        raise ScorecardSourceError("NumbersUSA overall or career metric is absent")
    return congress


def _edition(congress, *, is_current=True):
    return ScorecardEdition(
        "numbersusa",
        congress,
        INDEX,
        "NumbersUSA Immigration-Reduction Grade Cards",
        congress=congress,
        chamber="both",
        is_current=is_current,
    )


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _, options = _read(context, "grades/filter-options/", "listing")
    congress = _options(options)
    _, catalog = _read(context, "congress/all/", "edition-catalog")
    if not isinstance(catalog, dict) or catalog.get("congress_ids") != [row["id"] for row in options["congress_terms"]]:
        raise ScorecardSourceError("NumbersUSA edition catalogs disagree")
    return tuple(_edition(_id(row["id"]), is_current=_id(row["id"]) == congress) for row in options["congress_terms"])


def _roster(data, congress):
    if not isinstance(data, dict) or set(data) != {"brackets"} or not isinstance(data["brackets"], dict):
        raise ScorecardSourceError("NumbersUSA grade-search shape or pagination changed")
    result = {}
    for bracket, rows in data["brackets"].items():
        if not isinstance(bracket, str) or not isinstance(rows, list):
            raise ScorecardSourceError("NumbersUSA grade-search bracket is malformed")
        for member in rows:
            fields = {
                "id",
                "name",
                "state",
                "current_score",
                "congress_id",
                "current_score_letter_grade",
                "title",
                "party",
                "bioguide_id",
            }
            if not isinstance(member, dict) or not fields <= member.keys():
                raise ScorecardSourceError("NumbersUSA member listing fields changed")
            member_id = _id(member["id"])
            if member_id in result or _id(member["congress_id"]) != congress:
                raise ScorecardSourceError("NumbersUSA roster repeats an identity or mixes editions")
            for field in fields - {"id", "congress_id"}:
                _text(member[field])
            if any(not isinstance(member[field], str) for field in ("name", "state", "title", "party")):
                raise ScorecardSourceError("NumbersUSA member context is no longer literal text")
            if not re.fullmatch(r"[A-Z]{2}(?:[0-9]{2})?", member["state"]):
                raise ScorecardSourceError("NumbersUSA listing state/district code changed")
            if member["current_score_letter_grade"] is not None and member["current_score_letter_grade"] != bracket:
                raise ScorecardSourceError("NumbersUSA grade bracket disagrees with member grade")
            if member["title"] not in {"Rep", "Sen"} or not member["name"] or not member["state"]:
                raise ScorecardSourceError("NumbersUSA federal member context is absent")
            result[member_id] = member
    return result


def _category_nodes(data, path="$.categories"):
    if not isinstance(data, list):
        raise ScorecardSourceError("NumbersUSA category children are not an array")
    for position, category in enumerate(data):
        locator = f"{path}[{position}]"
        required = {
            "title",
            "description",
            "score",
            "weight",
            "literals",
            "actions",
            "ratios",
            "totals",
            "nonaction_description",
            "nonaction_is_action",
        }
        if not isinstance(category, dict) or not required <= category.keys():
            raise ScorecardSourceError("NumbersUSA category fields changed")
        if not isinstance(category["title"], str) or not category["title"]:
            raise ScorecardSourceError("NumbersUSA category title is absent or malformed")
        score = category["score"]
        if (
            not isinstance(score, dict)
            or not {"category_id", "congress_id", "legislator", "display_score", "display_grade", "total_actions"}
            <= score.keys()
        ):
            raise ScorecardSourceError("NumbersUSA category score is malformed")
        if not isinstance(category["actions"], list) or not isinstance(category["ratios"], list):
            raise ScorecardSourceError("NumbersUSA category actions are malformed")
        # The captured current edition has no ratio-based scoring. A future
        # ratio object needs an explicit parser rather than silently disappearing.
        if category["ratios"]:
            raise ScorecardSourceError("NumbersUSA ratio-based category needs a reviewed mapping")
        yield category, locator
        yield from _category_nodes(category["literals"], locator + ".literals")


def _grade(score):
    grade = score["display_grade"]
    if grade is None:
        return None
    if not isinstance(grade, dict) or "display_grade" not in grade:
        raise ScorecardSourceError("NumbersUSA category grade shape changed")
    return _text(grade["display_grade"])


def _references(action, path):
    """Preserve each official link occurrence; downstream resolves the literal URL."""

    class Links(HTMLParser):
        def __init__(self):
            super().__init__()
            self.urls = []

        def handle_starttag(self, tag, attrs):
            if tag == "a":
                href = dict(attrs).get("href")
                if href and re.match(r"https?://(?:www\.)?(?:congress\.gov|senate\.gov|clerk\.house\.gov)/", href):
                    self.urls.append(href)

    references = []
    for field in ("correct_header", "correct_text", "incorrect_header", "incorrect_text"):
        text = action[field]
        if text is None:
            continue
        if not isinstance(text, str):
            raise ScorecardSourceError("NumbersUSA action description is not source text")
        links = Links()
        links.feed(text)
        for index, url in enumerate(links.urls):
            references.append(
                {
                    "occurrence_id": key(field, str(index)),
                    "citation_text": url,
                    "kind": "url",
                    "source_path": f"{path}.{field}/a[{index}]/@href",
                }
            )
    return json_column(references)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    primary = context.read(INDEX, stage="scorecards:numbersusa:publisher", hosts=HOSTS)
    html = soup(primary)
    settings = next((node.get_text() for node in html.find_all("script") if "window.NUSA_URLS=" in node.get_text()), "")
    match = re.search(r"window\.NUSA_URLS\s*=\s*(\{[^;]+\})\s*;", settings)
    try:
        configured = json.loads(match.group(1)) if match else {}
    except ValueError as error:
        raise ScorecardSourceError("NumbersUSA publisher API configuration is malformed") from error
    if configured.get("django_api_url", "").rstrip("/") != BASE.rstrip("/"):
        raise ScorecardSourceError("NumbersUSA original publisher no longer configures the selected API")
    options_document, options = _read(context, "grades/filter-options/", "filters")
    current_congress = _options(options)
    congress = edition.congress
    if congress not in {_id(row["id"]) for row in options["congress_terms"]} or edition != _edition(
        congress, is_current=congress == current_congress
    ):
        raise ScorecardSourceError("NumbersUSA selected edition is outside the publisher edition catalog")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="NumbersUSA Action",
        parser_version=parser_version,
        rendition_rule="numbersusa-original-json-grade-search-and-member-categories/1",
        homepage="https://www.numbersusa.org/",
    )
    bundle.use(primary, "publisher_api_authority")
    bundle.use(options_document, "filter_catalog")
    document, catalog = _read(context, "congress/all/", "edition-catalog")
    if not isinstance(catalog, dict) or catalog.get("congress_ids") != [row["id"] for row in options["congress_terms"]]:
        raise ScorecardSourceError("NumbersUSA edition catalogs disagree")
    bundle.use(document, "edition_catalog")
    query = f"grades/search/?congress={congress}"
    roster_document, data = _read(context, query, "members")
    members = _roster(data, congress)
    if not members:
        raise ScorecardSourceError("NumbersUSA grade-search roster is empty")
    bundle.use(roster_document, "member_catalog_and_overall_ratings")
    # These are publisher-defined partitions, not an assumed congressional size.
    for field, parameter in (("states", "state"), ("chambers", "chamber")):
        observed = {}
        partitions = options[field]
        if field == "states":
            # The source roster includes DC even though the filter dropdown
            # lists states only. Request every additional observed state code.
            extra = {member["state"][:2] for member in members.values()} - {row["abbreviation"] for row in partitions}
            partitions = [*partitions, *[{"abbreviation": code} for code in sorted(extra)]]
        for partition in partitions:
            value = partition["abbreviation"] if field == "states" else _id(partition["id"])
            if field == "states" and (not isinstance(value, str) or not re.fullmatch(r"[A-Z]{2}", value)):
                raise ScorecardSourceError("NumbersUSA state filter abbreviation changed")
            part_document, part_data = _read(context, query + f"&{parameter}={value}", "partition")
            part = _roster(part_data, congress)
            for member_id, member in part.items():
                if member_id in observed or member != members.get(member_id):
                    raise ScorecardSourceError("NumbersUSA member partitions overlap or disagree with the full roster")
                if field == "states" and not member["state"].startswith(partition["abbreviation"]):
                    raise ScorecardSourceError("NumbersUSA state filter returned another state")
                if field == "chambers" and member["title"] != {"House": "Rep", "Senate": "Sen"}[partition["name"]]:
                    raise ScorecardSourceError("NumbersUSA chamber filter returned another chamber")
                observed[member_id] = member
            bundle.use(part_document, "member_catalog_and_overall_ratings", role="corroboration")
        if observed != members:
            raise ScorecardSourceError("NumbersUSA grade-search population differs from its complete partitions")
    ranges_document, ranges = _read(context, f"grades/{congress}/ranges/", "grade-ranges")
    if not isinstance(ranges, dict) or not isinstance(ranges.get("grade_ranges"), list) or not ranges["grade_ranges"]:
        raise ScorecardSourceError("NumbersUSA grade ranges are absent")
    bundle.use(ranges_document, "grade_ranges")
    bundle.add(
        "scorecard_methodologies",
        ranges_document,
        "$.grade_ranges",
        methodology_id="grade-ranges",
        methodology_text=json_column(ranges["grade_ranges"]),
    )
    metrics = set()
    categories = {}
    components = set()
    items = {}
    participations = set()
    details = []
    subject_rosters = {}
    for subject in options["subjects"]:
        subject_id = _text(subject["id"])
        if subject_id == "":
            continue
        subject_document, subject_data = _read(context, query + f"&subject={subject_id}", "subject-ratings")
        subject_members = _roster(subject_data, congress)
        if set(subject_members) != set(members):
            raise ScorecardSourceError("NumbersUSA metric population differs from its member catalog")
        for member_id, member in subject_members.items():
            for field in ("name", "state", "title", "party", "bioguide_id"):
                if member[field] != members[member_id][field]:
                    raise ScorecardSourceError("NumbersUSA metric member identities disagree")
        subject_rosters[subject_id] = (subject_document, subject_members, subject["name"])
        bundle.use(subject_document, "subject_ratings:" + subject_id)

    def rating(document, path, member_id, metric_id, name, value, chamber, primary=False, notes=None):
        if metric_id not in metrics:
            bundle.metric(document, metric_id, name, path=path, chamber=chamber, primary=primary)
            metrics.add(metric_id)
        bundle.add(
            "scorecard_member_ratings",
            document,
            path,
            metric_id=metric_id,
            publisher_member_key=member_id,
            value_text=value,
            value_number=decimal_text(value),
            notes_text=notes,
        )

    def component(document, path, parent, child, weight):
        identity = (parent, child)
        if identity not in components:
            bundle.add(
                "scorecard_metric_components",
                document,
                path,
                parent_metric_id=parent,
                component_metric_id=child,
                weight_text=_text(weight),
                weight_number=decimal_text(_text(weight)),
            )
            components.add(identity)

    for member_id, listed in sorted(members.items()):
        route = f"legislator/{member_id}/gradecard/{congress}/"
        document, detail = _read(context, route, "member:" + member_id)
        if (
            not isinstance(detail, dict)
            or _text(detail.get("selected_congress_id")) != congress
            or not isinstance(detail.get("legislator"), dict)
            or _id(detail["legislator"].get("id")) != member_id
        ):
            raise ScorecardSourceError("NumbersUSA gradecard identity disagrees with its selected member or edition")
        chamber = detail.get("legislative_body", {}).get("name")
        if (
            chamber != {"Rep": "House", "Sen": "Senate"}[listed["title"]]
            or detail["legislator"].get("bioguide_id") != listed["bioguide_id"]
        ):
            raise ScorecardSourceError("NumbersUSA gradecard and roster member identifiers disagree")
        bundle.use(document, "member_detail:" + member_id)
        details.append((route, detail))
        identifiers = [{"scheme": "numbersusa", "value": member_id}]
        if listed["bioguide_id"]:
            identifiers.append({"scheme": "bioguide", "value": _text(listed["bioguide_id"])})
        state = listed["state"]
        if not re.fullmatch(r"[A-Z]{2}(?:[0-9]{2})?", state):
            raise ScorecardSourceError("NumbersUSA listing state/district code changed")
        bundle.add(
            "scorecard_members",
            roster_document,
            "$.brackets.*[id=" + member_id + "]",
            publisher_member_key=member_id,
            publisher_member_id=member_id,
            identifiers_json=json_column(identifiers),
            member_name=listed["name"],
            chamber_text=chamber,
            state=state[:2],
            district=state[2:] or None,
            party=listed["party"],
            notes_text=json_column({"listing_state": state}),
        )
        overall = detail.get("overall_scores")
        if not isinstance(overall, list):
            raise ScorecardSourceError("NumbersUSA overall scores are malformed")
        selected = [
            (position, value) for position, value in enumerate(overall) if _text(value.get("congress_id")) == congress
        ]
        if len(selected) != 1:
            raise ScorecardSourceError("NumbersUSA member has no unique selected-Congress score")
        index, score = selected[0]
        if (
            score.get("score") != listed["current_score"]
            or score.get("letter_grade") != listed["current_score_letter_grade"]
        ):
            raise ScorecardSourceError("NumbersUSA overall listing and member gradecard disagree")
        prefix = key(chamber, "overall")
        rating(
            document,
            f"$.overall_scores[{index}].score",
            member_id,
            prefix + ":score",
            "Overall score",
            _text(score["score"]),
            chamber,
        )
        rating(
            document,
            f"$.overall_scores[{index}].letter_grade",
            member_id,
            prefix + ":grade",
            "Overall Grade",
            _text(score["letter_grade"]),
            chamber,
            primary=True,
        )
        career_document, career, career_name = subject_rosters["-1"]
        career_score = career[member_id]
        rating(
            career_document,
            "$.brackets.*[id=" + member_id + "].current_score",
            member_id,
            key(chamber, "career", "score"),
            career_name + " score",
            _text(career_score["current_score"]),
            chamber,
        )
        rating(
            career_document,
            "$.brackets.*[id=" + member_id + "].current_score_letter_grade",
            member_id,
            key(chamber, "career", "grade"),
            career_name,
            _text(career_score["current_score_letter_grade"]),
            chamber,
        )
        nodes = list(_category_nodes(detail.get("categories")))
        member_categories = set()
        for category, path in nodes:
            category_score = category["score"]
            category_id = _id(category_score["category_id"])
            if (
                category_id in member_categories
                or _id(category_score["legislator"]) != member_id
                or _id(category_score["congress_id"]) != congress
            ):
                raise ScorecardSourceError("NumbersUSA member category is repeated or has a different identity")
            member_categories.add(category_id)
            category_metric = key(chamber, "category", category_id)
            definition = {field: category[field] for field in ("title", "description", "weight")}
            if category_metric in categories and categories[category_metric] != definition:
                raise ScorecardSourceError("NumbersUSA shared category definition changed between members")
            categories[category_metric] = definition
            notes = json_column(
                {
                    "score": category_score,
                    "totals": category["totals"],
                    "nonaction_description": category["nonaction_description"],
                    "nonaction_is_action": category["nonaction_is_action"],
                    "description": category["description"],
                }
            )
            rating(
                document,
                path + ".score.display_score",
                member_id,
                category_metric + ":score",
                category["title"] + " score",
                _text(category_score["display_score"]),
                chamber,
                notes=notes,
            )
            rating(
                document,
                path + ".score.display_grade",
                member_id,
                category_metric + ":grade",
                category["title"],
                _grade(category_score),
                chamber,
                notes=notes,
            )
            if category_id in subject_rosters:
                _, subject_members, _ = subject_rosters[category_id]
                source_value = subject_members[member_id]
                grade_matches = source_value["current_score_letter_grade"] == _grade(category_score) or (
                    source_value["current_score_letter_grade"] == "no_grade" and _grade(category_score) is None
                )
                if _text(source_value["current_score"]) != _text(category_score["display_score"]) or not grade_matches:
                    raise ScorecardSourceError("NumbersUSA category listing and member gradecard disagree")
            if ".literals[" not in path:
                component(document, path + ".weight", prefix + ":score", category_metric + ":score", category["weight"])
            for child in category["literals"]:
                child_metric = key(chamber, "category", _id(child["score"]["category_id"])) + ":score"
                # Child metrics appear later in the depth-first walk. Their
                # references are checked after every member has been parsed.
                component(document, path + ".literals", category_metric + ":score", child_metric, child["weight"])
            seen = {}
            for position, action in enumerate(category["actions"]):
                action_path = f"{path}.actions[{position}]"
                required = {
                    "id",
                    "action_id",
                    "category_id",
                    "date",
                    "action_header",
                    "action_text",
                    "correct_header",
                    "correct_text",
                    "correct_points",
                    "incorrect_header",
                    "incorrect_text",
                    "incorrect_points",
                    "is_right_answer",
                    "order",
                }
                if (
                    not isinstance(action, dict)
                    or not required <= action.keys()
                    or not isinstance(action["is_right_answer"], bool)
                ):
                    raise ScorecardSourceError("NumbersUSA action fields changed")
                item_id = key("action", _id(action["action_id"]), "impact", _id(action["id"]))
                if _id(action["category_id"]) != category_id:
                    raise ScorecardSourceError("NumbersUSA action is attached to another category")
                # One source action/impact can have multiple member-specific
                # dated observations. Keep each occurrence without manufacturing
                # separate scoring definitions or dropping apparent duplicates.
                digest = hashlib.sha256(json_column(action).encode()).hexdigest()
                seen[digest] = seen.get(digest, 0) + 1
                result_id = key(category_metric, digest, str(seen[digest]))
                definition = {
                    field: value
                    for field, value in action.items()
                    if field not in {"date", "action_header", "action_text", "is_right_answer"}
                }
                if item_id in items and items[item_id] != definition:
                    raise ScorecardSourceError("NumbersUSA shared scoring action changed between members")
                if item_id not in items:
                    items[item_id] = definition
                    target = action["correct_header"] or action["correct_text"]
                    bundle.add(
                        "scorecard_items",
                        document,
                        action_path,
                        item_id=item_id,
                        publisher_item_id=_text(action["action_id"]),
                        item_kind_text="publisher action",
                        title=action["correct_header"]
                        or action["incorrect_header"]
                        or action["correct_text"]
                        or action["incorrect_text"],
                        congress_text=congress,
                        # The action object supplies no chamber. A shared
                        # definition can appear in both chamber gradecards;
                        # member context must not become item scope.
                        chamber_text=None,
                        references_json=_references(action, action_path),
                        publisher_position_text=target,
                        position_basis="explicit" if target else "absent",
                        position_source_path=action_path
                        + (".correct_header" if action["correct_header"] else ".correct_text")
                        if target
                        else None,
                    )
                participation = (category_metric + ":score", item_id)
                if participation not in participations:
                    bundle.add(
                        "scorecard_metric_items",
                        document,
                        action_path,
                        metric_id=participation[0],
                        item_id=item_id,
                        participation_id="impact",
                        contribution_rule_text=json_column(
                            {
                                field: action[field]
                                for field in (
                                    "correct_points",
                                    "incorrect_points",
                                    "correct_header",
                                    "correct_text",
                                    "incorrect_header",
                                    "incorrect_text",
                                )
                            }
                        ),
                    )
                    participations.add(participation)
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    action_path,
                    item_id=item_id,
                    publisher_member_key=member_id,
                    result_id=result_id,
                    metric_id=category_metric + ":score",
                    participation_id="impact",
                    action_text=json_column(
                        {field: action[field] for field in ("action_header", "action_text", "date")}
                    ),
                    result_text="true" if action["is_right_answer"] else "false",
                    contribution_text=json_column(
                        {"correct_points": action["correct_points"], "incorrect_points": action["incorrect_points"]}
                    ),
                )
        top_ids = {_id(category["score"]["category_id"]) for category in detail["categories"]}
        if top_ids != set(subject_rosters) - {"-1"}:
            raise ScorecardSourceError("NumbersUSA gradecard categories differ from its filter subjects")
    # Reread each member, including item definitions/results, rather than only
    # proving that an unchanged directory happened to list the same names.
    for route, previous in details:
        document, repeated = _read(context, route, "member-recheck")
        if repeated != previous:
            raise ScorecardSourceError("NumbersUSA member gradecard changed during acquisition")
        bundle.use(document, "member_detail:" + _id(previous["legislator"]["id"]), role="corroboration")
    for route, previous, group in [
        (query, members, "member_catalog_and_overall_ratings"),
        *[
            (query + f"&subject={subject}", values, "subject_ratings:" + subject)
            for subject, (_, values, _) in subject_rosters.items()
        ],
    ]:
        document, repeated = _read(context, route, "rating-recheck")
        if _roster(repeated, congress) != previous:
            raise ScorecardSourceError("NumbersUSA complete rating catalog changed during acquisition")
        bundle.use(document, group, role="corroboration")
    document, repeated = _read(context, "grades/filter-options/", "filter-recheck")
    if repeated != options:
        raise ScorecardSourceError("NumbersUSA edition filters changed during acquisition")
    bundle.use(document, "filter_catalog", role="corroboration")
    for route, previous, group in (
        (f"grades/{congress}/ranges/", ranges, "grade_ranges"),
        ("congress/all/", catalog, "edition_catalog"),
    ):
        document, repeated = _read(context, route, "methodology-recheck")
        if repeated != previous:
            raise ScorecardSourceError("NumbersUSA edition or grade methodology changed during acquisition")
        bundle.use(document, group, role="corroboration")
    return bundle.finish(
        "Complete unpaginated grade-search JSON at EOF; identical state/chamber partition membership and values; every source-listed member detail captured twice unchanged; overall/category listings reconcile with gradecards; career and all rating catalogs reread unchanged; edition filters reread unchanged.",
        declared={
            "pagination": "unpaginated brackets object; no publisher total field",
            "population": "publisher selected-Congress federal grade-search population",
            "categories": len(options["subjects"]) - 2,
        },
    )
