"""Native Freedom Index congressional roster, cumulative and session scores, and issue JSON."""

from __future__ import annotations

import json
import re
from dataclasses import replace

from spicy_docs.sources.scorecards import new_american as reports
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key

parser_version = "new-american-native-roster/1"
INDEX = "https://freedomindex.us/us/legislators/"


def _catalog(source):
    document = reports._html(source)
    options = document.select('select[name="session"] option')
    defaults = re.findall(r"var defaultSessionId\s*=\s*'(\d+)';", source.body.decode("utf-8"))
    if not options or len({o.get("value") for o in options}) != len(options):
        raise ScorecardSourceError("Freedom Index native Congress filters are missing or duplicated")
    if len(defaults) != 1 or defaults[0] not in {o.get("value") for o in options}:
        raise ScorecardSourceError("Freedom Index current native roster filter is missing")
    editions = []
    for option in options:
        identifier, label = option.get("value", ""), option.get_text(" ", strip=True)
        match = re.fullmatch(r"(\d{3})(?:th|rd|nd|st) Congress", label)
        if not identifier.isdigit() or option.get("data-session-id") != identifier or not match:
            raise ScorecardSourceError("Freedom Index native roster filter identity changed")
        editions.append(
            ScorecardEdition(
                "new_american",
                "roster:session:" + identifier,
                INDEX + "session/" + identifier + "/",
                "Congressional Legislators — " + label,
                congress=match[1],
                chamber="both",
                is_current=identifier == defaults[0],
            )
        )
    return tuple(editions)


def list_scorecards(context):
    return _catalog(context.read(INDEX, stage="scorecards:new-american-roster:listing", hosts=reports.HOSTS))


def _json(document, identifier):
    selected = document.select('script[type="application/json"]#' + identifier)
    try:
        if len(selected) != 1:
            raise ValueError
        return json.loads(selected[0].get_text(), object_pairs_hook=reports._unique_fields)
    except (ValueError, TypeError):
        raise ScorecardSourceError("Freedom Index native roster JSON is missing or malformed") from None


def _score(number, grade):
    if (number != "" and (re.fullmatch(r"\d{1,3}", number) is None or int(number) > 100)) or grade not in {
        "A",
        "B",
        "C",
        "D",
        "F",
        "NA",
    }:
        raise ScorecardSourceError("Freedom Index native roster score/grade shape changed")
    if (number == "") != (grade == "NA"):
        raise ScorecardSourceError("Freedom Index missing score and native grade do not reconcile")


def _facts(source, edition):
    document = reports._html(source)
    grid = document.select_one("#fi-legislators-grid")
    selected = document.select('select[name="session"] option[selected]')
    native_id = edition.edition_id.rsplit(":", 1)[1]
    if (
        grid is None
        or len(selected) != 1
        or selected[0].get("value") != native_id
        or grid.get("data-session-name") != selected[0].get_text(" ", strip=True)
        or edition not in tuple(replace(value, is_current=edition.is_current) for value in _catalog(source))
    ):
        # HTTP 200 query-string responses silently retain the default Congress.
        raise ScorecardSourceError("Freedom Index roster does not belong to the requested native Congress filter")
    tags, issues = _json(document, "fi-list-tag-names"), _json(document, "fi-legislators-score-issues")
    if (
        not isinstance(tags, dict)
        or not isinstance(issues, dict)
        or any(not identifier.isdigit() or not isinstance(name, str) or not name for identifier, name in tags.items())
    ):
        raise ScorecardSourceError("Freedom Index native issue label map changed")
    states = [o.get_text(" ", strip=True) for o in document.select('select[name="state"] option') if o.get("value")]
    wrappers = grid.select(":scope > .fi-legislator-card-wrapper")
    if not wrappers or grid.get("data-total") != str(len(wrappers)):
        raise ScorecardSourceError("Freedom Index declared roster count does not match the complete grid")
    members, identities = [], set()
    for ordinal, wrapper in enumerate(wrappers):
        cards = wrapper.select(":scope > .lc")
        if len(cards) != 1 or wrapper.get("data-index") != str(ordinal):
            raise ScorecardSourceError("Freedom Index roster card indexes are incomplete")
        card = cards[0]
        identifier = card.get("data-lid", "")
        name, office = card.select_one(".lc-name"), card.select_one(".lc-office")
        details = card.select(".lc-district")
        if (
            not identifier.isdigit()
            or identifier in identities
            or card.get("href") != f"https://freedomindex.us/legislator/{identifier}/"
            or name is None
            or not name.get_text(" ", strip=True)
            or office is None
            or office.get_text(" ", strip=True) not in {"House", "Senate"}
            or not 1 <= len(details) <= 2
        ):
            raise ScorecardSourceError("Freedom Index roster native identity or source member context changed")
        identities.add(identifier)
        place = details[0].get_text(" ", strip=True)
        matches = [state for state in states if place == state or place.startswith(state + " ")]
        if len(matches) != 1:
            raise ScorecardSourceError("Freedom Index source state/district does not match its native state filter")
        state = matches[0]
        scores = {field: card.get("data-" + field) for field in ["fs", "fg", "ss", "sg"]}
        if any(value is None for value in scores.values()):
            raise ScorecardSourceError("Freedom Index source score attributes are missing")
        _score(scores["fs"], scores["fg"])
        _score(scores["ss"], scores["sg"])
        members.append(
            {
                "id": identifier,
                "name": name.get_text(" ", strip=True),
                "chamber": office.get_text(" ", strip=True),
                "state": state,
                "district": place.removeprefix(state).strip() or None,
                "party": details[1].get_text(" ", strip=True) if len(details) == 2 else None,
                "scores": scores,
            }
        )
    if set(issues) != identities:
        raise ScorecardSourceError("Freedom Index native issue map does not cover exactly the declared roster")
    for values in issues.values():
        if not isinstance(values, dict):
            raise ScorecardSourceError("Freedom Index issue map has an unreviewed member shape")
        for identifier, value in values.items():
            if (
                not identifier.isdigit()
                or not isinstance(value, dict)
                or set(value) != {"s", "g"}
                or type(value["s"]) is not int
                or not isinstance(value["g"], str)
            ):
                raise ScorecardSourceError("Freedom Index native issue value changed")
            _score(str(value["s"]), value["g"])
    return {"members": members, "tags": tags, "issues": issues, "label": grid["data-session-name"]}


def acquire_scorecard(edition, context):
    catalog = context.read(INDEX, stage="scorecards:new-american-roster:catalogue-start", hosts=reports.HOSTS)
    editions = _catalog(catalog)
    if edition not in editions:
        raise ScorecardSourceError("Selected Freedom Index native roster filter is absent or changed")
    methodology = context.read(
        reports.ABOUT, stage="scorecards:new-american-roster:methodology-start", hosts=reports.HOSTS
    )
    scoring = reports._methodology(methodology)
    source = context.read(edition.source_url, stage="scorecards:new-american-roster:roster-start", hosts=reports.HOSTS)
    facts = _facts(source, edition)
    end = context.read(edition.source_url, stage="scorecards:new-american-roster:roster-end", hosts=reports.HOSTS)
    if _facts(end, edition) != facts:
        raise ScorecardSourceError("Freedom Index native roster or scores changed during acquisition")
    catalog_end = context.read(INDEX, stage="scorecards:new-american-roster:catalogue-end", hosts=reports.HOSTS)
    methodology_end = context.read(
        reports.ABOUT, stage="scorecards:new-american-roster:methodology-end", hosts=reports.HOSTS
    )
    if _catalog(catalog_end) != editions or reports._methodology(methodology_end) != scoring:
        raise ScorecardSourceError("Freedom Index roster catalogue or methodology changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="The New American",
        parser_version=parser_version,
        homepage="https://thenewamerican.com/",
        rendition_rule="freedom-index-complete-native-filtered-roster-score-attributes-and-issue-json/1",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        methodology_url=reports.ABOUT, series_id=key("new_american", "Congressional Legislators")
    )
    bundle.use(source, "native_roster")
    bundle.use(catalog, "native_roster_filters")
    bundle.use(methodology, "methodology")
    bundle.use(end, "native_roster", role="corroboration")
    bundle.use(catalog_end, "native_roster_filters", role="corroboration")
    bundle.use(methodology_end, "methodology", role="corroboration")
    for name, text in scoring.items():
        bundle.add(
            "scorecard_methodologies",
            methodology,
            "heading=" + name,
            methodology_id=key("methodology", name),
            methodology_text=text,
            methodology_url=reports.ABOUT,
            disclosure_status="literal source methodology; no grade conversion or score reproduction",
        )
    bundle.add(
        "scorecard_methodologies",
        source,
        "script#fi-list-tag-names",
        methodology_id="native-issue-labels",
        methodology_text=reports._literal(facts["tags"]),
        methodology_url=source.url,
        disclosure_status="native issue IDs and labels; JSON includes unlabeled IDs that remain separate unnamed metrics",
    )
    for identifier, name, unit in [
        ("fs", "Freedom Score", "percent"),
        ("fg", "Freedom Score", "grade"),
        ("ss", "Session Score", "percent"),
        ("sg", "Session Score", "grade"),
    ]:
        bundle.metric(source, identifier, name, path=".lc/@data-" + identifier, unit=unit, primary=identifier == "fs")
        bundle.tables["scorecard_metrics"][-1].update(
            cohort_text=facts["label"],
            period_text="lifetime" if identifier.startswith("f") else facts["label"],
        )
    issue_ids = set(facts["tags"]) | {identifier for values in facts["issues"].values() for identifier in values}
    for identifier in sorted(issue_ids, key=int):
        for field, unit in [("s", "percent"), ("g", "grade")]:
            bundle.metric(
                source,
                key("issue", identifier, field),
                facts["tags"].get(identifier),
                path=(
                    "script#fi-list-tag-names/" + identifier
                    if identifier in facts["tags"]
                    else "script#fi-legislators-score-issues/*/" + identifier + "/" + field
                ),
                unit=unit,
                primary=False,
            )
            bundle.tables["scorecard_metrics"][-1]["cohort_text"] = facts["label"]
    for ordinal, member in enumerate(facts["members"]):
        path, member_key = f"#fi-legislators-grid/wrapper/{ordinal}/a.lc", key("legislator", member["id"])
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            member_name=member["name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["district"],
            party=member["party"],
            period_text=facts["label"],
            identifiers_json=reports._literal([{"scheme": "freedomindex.us:legislator", "value": member["id"]}]),
            notes_text="Source roster filter context; cumulative scores are observed now and do not assert a historical cutoff.",
        )
        for identifier, value in member["scores"].items():
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/@data-" + identifier,
                metric_id=identifier,
                publisher_member_key=member_key,
                value_text=("N/A" if value == "NA" else value or None),
                value_number=decimal_text(value) if identifier.endswith("s") else None,
                notes_text=reports._literal({"native_attribute_value": value}),
            )
        for identifier, values in facts["issues"][member["id"]].items():
            for field, value in values.items():
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    "script#fi-legislators-score-issues/" + member["id"] + "/" + identifier + "/" + field,
                    metric_id=key("issue", identifier, field),
                    publisher_member_key=member_key,
                    value_text=str(value),
                    value_number=str(value) if field == "s" else None,
                )
    return bundle.finish(
        "Complete native roster for one explicit source Congress filter: declared member count, "
        "contiguous card indexes and exact issue-map membership reconcile. All native score attributes, "
        "grades and labeled or unlabeled issue JSON values are retained; stable roster, filter and "
        "methodology rereads complete. Cumulative/issue values do not assert an undisclosed historical cutoff.",
        declared={"members": len(facts["members"])},
    )
