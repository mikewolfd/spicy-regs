"""Original Parks 2020 historical PDF, including distinct eligibility colors and doubled votes."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from spicy_docs.sources.scorecards.national_parks_action import _references
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "national-parks-action-2020-qualified-semantic/1"
INDEX = "https://nationalparksaction.org/scorecard/"
DRIVE_ID = "1jog5c3nxMmIAYqvWbpoH0gcWH5zEK_vs"
URL = "https://drive.usercontent.google.com/download?id=" + DRIVE_ID + "&export=download"
SOURCE_SHA256 = "e364b3df1eb31379c8acd591a80d40c09acf0eaeec5a9c73c7a2b20e64a1b113"
QUALIFIED_SHA256 = "ae82ff2054d1a577443bf809166b52cd6a3d42b6aeda4a101a9c52c95373c615"
EDITION = ScorecardEdition(
    "national_parks_action",
    "2020-pdf",
    URL,
    "2020 Congressional Scorecard",
    year="2020",
    congress="116",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    **dict(enumerate((21, 20, 20, 20, 20), 6)),
    **dict(enumerate((22, 32, 29, 26, 25, 29, 22, 28, 25, 24, 30, 27, 27, 23, 32, 23, 21), 16)),
}
TOKENS = {
    "Pro-Parks Vote",
    "Anti-Parks Vote",
    "Member Absent or Did Not Vote",
    "Not Applicable: N/A",
    "Ineligible to Vote",
}
ITEM_IDENTITIES = {
    "Senate": (
        ("22", "S. 47", None, "February 12, 2019", 4),
        ("33", None, None, "February 28, 2019", 4),
        ("77", None, None, "April 11, 2019", 4),
        ("335", "H.R. 3055", "Amendment #1019", "October 28, 2019", 5),
        ("339", "H.R. 3055", "Amendment #1209", "October 31, 2019", 5),
        ("121", "H.R. 1957", None, "June 17, 2020", 5),
    ),
    "House": (
        ("95", "S. 47", None, "February 26, 2019", 11),
        ("363", "H.R. 2740", "Amendment #90", "June 19, 2019", 11),
        ("381", "H.R. 3055", "Amendment #135", "June 20, 2019", 11),
        ("389", "H.R. 3055", "Amendment #163", "June 20, 2019", 12),
        ("391", "H.R. 3055", "Amendment #167", "June 20, 2019", 12),
        ("521", "H.R. 205", None, "September 11, 2019", 12),
        ("525", "H.R. 1941", None, "September 11, 2019", 13),
        ("597", "H.R. 2181", None, "October 30, 2019", 13),
        ("602", "H.R. 1373", None, "October 30, 2019", 14),
        ("36", "H.R. 4031", None, "February 5, 2020", 14),
        ("69", "H.R. 2546", None, "February 12, 2020", 14),
        ("155", "H.R. 1957", None, "July 22, 2020", 15),
    ),
}


@dataclass(frozen=True, slots=True)
class NationalParksAction2020Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context):
    source = context.read(INDEX, stage="scorecards:parks-2020:listing", hosts=("nationalparksaction.org",))
    if "drive.google.com/file/d/" + DRIVE_ID not in source.body.decode("utf-8"):
        raise ScorecardSourceError("Parks publisher no longer links the qualified 2020 PDF; requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if data["format_version"] != "national_parks_action-2020-qualified-source-facts/1" or data["sources"] != {
            "pdf-2020-content": {"sha256": SOURCE_SHA256, "page_count": 34}
        }:
            raise ValueError
        counts, identities = dict.fromkeys(PAGE_MEMBERS, 0), set()
        for entry in data["members"]:
            record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            page, ordinal = evidence["physical_page"], evidence["source_ordinal"]
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            size = 6 if chamber == "Senate" else 12
            if (
                page not in counts
                or ordinal != counts[page]
                or identity in identities
                or chamber != ("Senate" if page < 11 else "House")
                or evidence["source_label"] != "pdf-2020-content"
                or not record["member_name_text"]
                or not record["state_text"]
                or (chamber == "Senate" and record["district_text"] is not None)
                or (chamber == "House" and re.fullmatch(r"All|\d+", record["district_text"] or "") is None)
                or record["party_text"] not in {"Republican", "Democrat", "Independent"}
                or set(record["results"]) != {str(i) for i in range(1, size + 1)}
                or any(v not in TOKENS for v in record["results"].values())
                or record["grade_text"] not in {"A", "B", "C", "D", "F", "N/A"}
                or (
                    record["score_text"] != "N/A"
                    and (
                        re.fullmatch(r"\d{1,3}%", record["score_text"]) is None or int(record["score_text"][:-1]) > 100
                    )
                )
                or (record["score_text"] == "N/A") != (record["grade_text"] == "N/A")
            ):
                raise ValueError
            counts[page] += 1
            identities.add(identity)
        if counts != PAGE_MEMBERS or len(data["items"]) != 18 or len(data["methodology"]) != 20:
            raise ValueError
        for chamber, expected in ITEM_IDENTITIES.items():
            selected = [e for e in data["items"] if e["chamber"] == chamber]
            if len(selected) != len(expected):
                raise ValueError
            for i, (entry, required) in enumerate(zip(selected, expected, strict=True)):
                record, evidence = entry["record"], entry["evidence"]
                values = (
                    record["roll_number_text"],
                    record["bill_citation_text"],
                    record["amendment_citation_text"],
                    record["item_date_text"],
                    evidence["physical_page"],
                )
                weighted = i in {0, len(expected) - 1}
                if (
                    values != required
                    or record["publisher_item_key_text"] != str(i + 1)
                    or evidence["chart_ordinal"] != i + 1
                    or evidence["source_label"] != "pdf-2020-content"
                    or record["source_pages"] != [required[-1]]
                    or record["item_kind_text"] != "roll_call"
                    or not record["title_text"]
                    or not record["methodology_text"]
                    or not record["publisher_position_text"]
                    or record["position_basis"] != "explicit"
                    or record["weight_text"] != ("This vote was double weighted." if weighted else None)
                ):
                    raise ValueError
        if any(not e["record"]["methodology_text"] for e in data["methodology"]):
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("Parks semantic facts fail the complete qualified 2020 PDF shape") from None


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Parks 2020 PDF requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:parks-2020:report", hosts=("drive.usercontent.google.com",))
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="national_parks_action:qualified-2020-pdf",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="National Parks Action Fund",
        parser_version=parser_version,
        rendition_rule="national-parks-action-complete-2020-downloadable-pdf-historical-roster/1",
        homepage="https://nationalparksaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0]["methodology_url"] = URL
    bundle.use(source, "members_and_scores", "member_results", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}/record"),
            methodology_id=f"source-{i}",
            methodology_text=entry["record"]["methodology_text"],
            methodology_url=URL,
            disclosure_status="explicit original methodology, doubled votes, chamber-specific attendance/eligibility, published grades, exclusions and distinct color legends",
        )
    for chamber in ("Senate", "House"):
        first_page = 6 if chamber == "Senate" else 16
        for metric, name, unit, primary in (("percent", "%", "percent", True), ("grade", "Rating", "grade", False)):
            bundle.metric(
                source,
                key(chamber, metric),
                name,
                path=path(first_page, "/score-heading/" + metric),
                chamber=chamber,
                unit=unit,
                primary=primary,
            )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], entry["chamber"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        item_id = key(chamber, item["publisher_item_key_text"])
        method = key("item", chamber, item["publisher_item_key_text"])
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=item["publisher_item_key_text"],
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            congress_text="116",
            chamber_text=chamber,
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc + "/methodology_text",
            methodology_id=method,
            methodology_text=item["methodology_text"],
            methodology_url=URL,
            disclosure_status="literal original item narrative; explicit doubled weighting remains source text, without invented weights on other items",
        )
        for metric in ("percent", "grade"):
            bundle.add(
                "scorecard_metric_items",
                source,
                loc,
                metric_id=key(chamber, metric),
                item_id=item_id,
                participation_id="source-116-period",
                methodology_id=method,
                publisher_position_text=item["publisher_position_text"],
                position_basis="explicit",
                weight_text=item["weight_text"],
            )
    for i, entry in enumerate(data["members"]):
        record, chamber, page = entry["record"], entry["chamber"], entry["evidence"]["physical_page"]
        district_part = [record["district_text"]] if record["district_text"] is not None else []
        identity = key(chamber, record["state_text"], *district_part, record["member_name_text"])
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=record["notes_text"] or None,
        )
        for metric, field_name in (("percent", "score_text"), ("grade", "grade_text")):
            value = record[field_name]
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + "/" + field_name,
                metric_id=key(chamber, metric),
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value) if metric == "percent" else None,
            )
        for ordinal, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key(chamber, ordinal),
                metric_id=key(chamber, "percent"),
                participation_id="source-116-period",
                publisher_member_key=identity,
                result_id="publisher-color-legend",
                result_text=value,
            )
    return bundle.finish(
        "Complete publisher-linked 2020 PDF: every historical member row, independently reported percent/grade, original Senate and House item narratives, chamber-specific eligibility/exclusions and every native vector-color cell reconcile to the source text and printed legends. Doubled weighting, source dates/citations, N/A ratings and distinct not-applicable/ineligible categories remain literal. No inferred session, official action, grade conversion or score reproduction."
    )
