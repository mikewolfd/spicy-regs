"""Page streaming and composition, independent of recognition providers."""

from __future__ import annotations

import hashlib
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, replace

from spicy_docs.transport.credentials import CredentialRefusedError

from .model import (
    Box,
    DocumentReader,
    ExtractionError,
    ImageBackend,
    Observation,
    Page,
    PageContent,
    PageResult,
    PageStrategy,
    ProcessingIssue,
    Raster,
    Recognition,
    TextBlock,
)


def _observation(id: str, recognition: Recognition, image: Raster | None = None) -> Observation:
    # Provider block coordinates are relative to the supplied image, not the PDF.
    blocks = recognition.blocks or ((TextBlock(recognition.text),) if recognition.text else ())
    blocks = tuple(
        replace(
            b,
            box=image.box.place(b.box) if image and b.box else b.box,
            inspected_region=image.box.place(b.inspected_region)
            if image and b.inspected_region
            else b.inspected_region,
            observation=id,
        )
        for b in blocks
    )
    return Observation(
        id,
        recognition.text,
        recognition.configuration,
        recognition.raw,
        blocks,
        recognition.images or ((image,) if image else ()),
        recognition.text_format,
        recognition.issues,
        image.box if image else recognition.inspected_region,
        tuple(
            replace(
                table,
                bbox=image.box.place(table.bbox) if image and table.bbox else table.bbox,
                cell_boxes=tuple(
                    tuple(image.box.place(box) if image and box else box for box in row) for row in table.cell_boxes
                ),
                cell_details=tuple(
                    replace(cell, box=image.box.place(cell.box) if image and cell.box else cell.box)
                    for cell in table.cell_details
                ),
            )
            for table in recognition.tables
        ),
    )


@dataclass(frozen=True)
class NativeText:
    """The PDF's own text layer as one observation; an image page is refused."""

    def extract(self, page: Page) -> PageContent:
        if not page.has_native_layer:
            raise ExtractionError("native extraction requires a PDF text layer; choose an image backend")
        observation = _observation("native", page.native())
        return PageContent(observation.blocks, (observation,))


@dataclass(frozen=True)
class FullPage:
    """Render the whole page once and recognize it with the backend."""

    backend: ImageBackend

    def extract(self, page: Page) -> PageContent:
        image = page.render()
        observation = _observation("full", self.backend.recognize(image), image)
        return PageContent(observation.blocks, (observation,))


@dataclass(frozen=True)
class NativeWithRegions:
    """Native text plus one recognized observation per selected crop region.

    Selects at most 64 non-overlapping regions per page, checks pixel-rounded crop
    bounds before any paid model call, and requires native block coordinates; a
    region that clips a native text line is refused. A refusal during recognition
    carries the observations made so far, the failed raster and the failure.
    """

    backend: ImageBackend
    regions: Mapping[int, Sequence[Box]]

    def extract(self, page: Page) -> PageContent:
        from .pages import crop

        native = NativeText().extract(page).observations[0]
        selected = tuple(self.regions.get(page.number, ()))
        if not selected:
            return PageContent(native.blocks, (native,))
        if len(selected) > 64:
            raise ValueError("select at most 64 regions per page")
        if any(a.intersects(b) for i, a in enumerate(selected) for b in selected[i + 1 :]):
            raise ValueError("selected regions overlap")
        image = page.render()
        crops = tuple(crop(image, box) for box in selected)
        # Check actual pixel-rounded crop bounds before any paid/model operation.
        actual = tuple(c.box for c in crops)
        if any(a.intersects(b) for i, a in enumerate(actual) for b in actual[i + 1 :]):
            raise ValueError("pixel-rounded regions overlap")
        kept = []
        for block in native.blocks:
            if block.box is None:
                if block.text:
                    raise ExtractionError("regional composition requires native block coordinates")
                continue
            intersects = [box for box in actual if box.intersects(block.box)]
            if intersects and not any(box.contains(block.box) for box in intersects):
                if block.text.strip():
                    raise ValueError("selected region clips a native text line")
                # PDF producers often emit whitespace lines across otherwise empty gaps.
                kept.append(block)
            elif not intersects:
                kept.append(block)
        observations = [native]
        for i, raster in enumerate(crops, 1):
            try:
                observation = _observation(f"region-{i}", self.backend.recognize(raster), raster)
            except (ExtractionError, CredentialRefusedError) as exc:
                exc.details = {"observations": tuple(observations), "failed_image": raster, "failure": exc.details}
                raise
            observations.append(observation)
            kept.extend(observation.blocks)
        # Insert each region at the first replaced native line, preserving the
        # provider's order within columns. Regions without a native anchor follow
        # native content in caller-selected order; geometry is not reading order.
        ordered = []
        pending = list(observations[1:])
        for block in native.blocks:
            for observation in tuple(pending):
                region = observation.inspected_region
                if region and block.box and region.contains(block.box):
                    ordered.extend(observation.blocks)
                    pending.remove(observation)
            if block in kept:
                ordered.append(block)
        for observation in pending:
            ordered.extend(observation.blocks)
            index = observations.index(observation)
            observations[index] = replace(
                observation,
                issues=(
                    *observation.issues,
                    ProcessingIssue(
                        "unanchored-region-order",
                        "Region has no replaced native line; appended in selected region order.",
                    ),
                ),
            )
        kept = ordered
        return PageContent(tuple(kept), tuple(observations))


class DocumentExtractor:
    """One API for PDFs and images; caller owns acquisition and result retention.

    Without a strategy, use Docling with Apple Vision, Egret Large and accurate
    TableFormer V1, rendering PDFs at 300 DPI. Explicit strategies remain injectable.
    Iterate to exhaustion or close the returned generator to release the document.
    A failure after earlier yielded pages does not make the whole document complete.
    ``tables=True`` runs PyMuPDF's ``find_tables()`` on each retained PDF page
    and attaches the result to ``PageResult.tables``, independent of ``strategy``
    and never merged into ``PageResult.text``; native detection adds nothing for
    image input, while provider-stated tables remain. It defaults to ``False`` so no existing
    caller's output changes, and adds roughly six times the whole-document wall
    time of ``tables=False`` for a recovery rate that depends entirely on whether
    the source PDF's tables are ruled.
    """

    def __init__(
        self,
        strategy: PageStrategy | None = None,
        *,
        reader: DocumentReader | None = None,
        max_input_bytes: int = 64 * 1024**2,
        tables: bool = False,
    ):
        if max_input_bytes < 1:
            raise ValueError("max_input_bytes must be positive")
        use_default = strategy is None
        if strategy is None:
            from .docling import Docling

            strategy = FullPage(Docling())
        if reader is None:
            from .pages import DefaultReader

            reader = DefaultReader(dpi=300 if use_default else 200)
        self.strategy, self.reader, self.max_input_bytes, self.tables = strategy, reader, max_input_bytes, tables

    def extract(
        self,
        source: bytes,
        *,
        media_type: str,
        pages: Sequence[int] | None = None,
        overrides: Mapping[int, PageStrategy] | None = None,
    ) -> Iterator[PageResult]:
        """Yield one result per selected page, in order; ``pages`` and ``overrides`` must name distinct in-range pages.

        ``media_type`` must be ``application/pdf`` or an image type, ``overrides``
        must be a subset of the selection, and each result's metadata carries the
        source digest, page geometry and the strategy used.
        """
        if not isinstance(source, bytes) or not source or len(source) > self.max_input_bytes:
            raise ValueError("source must be nonempty bytes within max_input_bytes")
        media_type = media_type.partition(";")[0].strip().lower()
        if media_type != "application/pdf" and not media_type.startswith("image/"):
            raise ValueError("expected application/pdf or an image media type")
        digest = hashlib.sha256(source).hexdigest()
        with self.reader.open(source, media_type) as document:
            selected = range(1, document.page_count + 1) if pages is None else tuple(pages)
            selected_members = selected if pages is None else set(selected)
            if not selected or len(selected_members) != len(selected):
                raise ValueError("select at least one distinct page")
            if pages is not None and any(type(n) is not int or not 1 <= n <= document.page_count for n in selected):
                raise ValueError("page selection is outside the document")
            if overrides and any(type(n) is not int or n not in selected_members for n in overrides):
                raise ValueError("page override is outside the selected pages")
            for number in selected:
                page = document.page(number)
                strategy = (overrides or {}).get(number, self.strategy)
                content = strategy.extract(page)
                yield PageResult(
                    {
                        "source_sha256": digest,
                        "source_size_bytes": len(source),
                        "media_type": media_type,
                        "page": number,
                        "page_count": document.page_count,
                        "geometry": page.geometry,
                        "strategy": type(strategy).__name__,
                        "coordinates": "normalized displayed page; top-left origin",
                    },
                    content,
                    tuple(
                        replace(table, page=number)
                        for observation in content.observations
                        for table in observation.tables
                    )
                    + (page.find_tables() if self.tables else ()),
                )
