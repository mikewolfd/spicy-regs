"""Prepare pinned MLX snapshots without modifying the Hugging Face cache."""

from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path

ADDITIONAL_VLM_MODELS = {
    "ovisocr2": (
        "mlx-community/OvisOCR2-8bit",
        "703d23a97d7e6474c7b53e991d6606362d10773f",
        '\nExtract all readable content from the image in natural human reading order and output the result as a single Markdown document. For charts or images, represent them using an HTML image tag: <img src="images/bbox_{left}_{top}_{right}_{bottom}.jpg" />, where left, top, right, bottom are bounding box coordinates scaled to [0, 1000). Format formulas as LaTeX. Format tables as HTML: <table>...</table>. Transcribe all other text as standard Markdown. Preserve the original text without translation or paraphrasing.',
    ),
    "nuextract3": (
        "numind/NuExtract3-mlx-4bits",
        "29c38269f94054282bf9ea97a20dfc6bb8bbefea",
        "",
    ),
}

_FILES = ("*.safetensors", "*.json", "*.jinja", "*.txt", "*.model", "*.tiktoken")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _selected(snapshot: Path) -> dict[str, Path]:
    files = {
        path.name: path
        for path in snapshot.iterdir()
        if path.is_file() and any(fnmatch.fnmatch(path.name, pattern) for pattern in _FILES)
    }
    if "config.json" not in files or not any(name.endswith(".safetensors") for name in files):
        raise ValueError("pinned Docling VLM snapshot lacks config.json or safetensors weights")
    return files


def _prepared_bytes(source: Path, *, processor_compatibility: bool) -> bytes:
    data = source.read_bytes()
    if source.name != "processor_config.json" or not processor_compatibility:
        return data
    config = json.loads(data)
    image_processor = config.get("image_processor")
    if not isinstance(image_processor, dict) or image_processor.get("image_processor_type") != "Qwen3VLImageProcessor":
        raise ValueError("expected nested Qwen3VLImageProcessor in pinned processor_config.json")
    image_processor["image_processor_type"] = "Qwen2VLImageProcessor"
    return (json.dumps(config, indent=2, ensure_ascii=False) + "\n").encode()


def prepare_vlm_artifacts(
    *,
    artifacts_path: str,
    repo_id: str,
    revision: str,
    processor_compatibility: bool,
    local_files_only: bool,
) -> dict:
    """Copy model configuration, link weights, and verify every prepared byte."""
    from huggingface_hub import snapshot_download

    snapshot = Path(
        snapshot_download(
            repo_id=repo_id,
            revision=revision,
            allow_patterns=list(_FILES),
            local_files_only=local_files_only,
        )
    )
    sources = _selected(snapshot)
    if processor_compatibility and "processor_config.json" not in sources:
        raise ValueError("pinned Docling VLM snapshot lacks processor_config.json")
    parent = Path(artifacts_path).expanduser().resolve()
    parent.mkdir(parents=True, exist_ok=True)
    target = parent / repo_id.replace("/", "--")
    expected = {
        name: (
            _sha256(source)
            if name.endswith(".safetensors")
            else hashlib.sha256(_prepared_bytes(source, processor_compatibility=processor_compatibility)).hexdigest()
        )
        for name, source in sources.items()
    }

    def verify_existing() -> None:
        if not target.is_dir():
            raise ValueError(f"Docling VLM artifact target is not a prepared directory: {target}")
        actual_names = {entry.name for entry in target.iterdir()}
        if actual_names != set(expected):
            raise ValueError(f"Docling VLM artifact target has different files: {target}")
        for name, digest in expected.items():
            path = target / name
            if not path.is_file() or _sha256(path) != digest:
                raise ValueError(f"Docling VLM artifact target differs from pinned snapshot: {path}")

    if target.exists() or target.is_symlink():
        verify_existing()
    else:
        stage = Path(tempfile.mkdtemp(prefix=".docling-vlm-", dir=parent))
        try:
            for name, source in sources.items():
                dest = stage / name
                if name.endswith(".safetensors"):
                    os.symlink(source.resolve(strict=True), dest)
                else:
                    dest.write_bytes(_prepared_bytes(source, processor_compatibility=processor_compatibility))
            try:
                stage.rename(target)
            except OSError:
                if not target.exists():
                    raise
                verify_existing()
        finally:
            if stage.exists():
                shutil.rmtree(stage)
        verify_existing()
    return {
        "repo_id": repo_id,
        "revision": revision,
        "snapshot": str(snapshot),
        "artifacts_path": str(parent),
        "prepared_path": str(target),
        "processor_compatibility": "nested Qwen3VLImageProcessor -> Qwen2VLImageProcessor"
        if processor_compatibility
        else None,
        "files_sha256": expected,
    }
