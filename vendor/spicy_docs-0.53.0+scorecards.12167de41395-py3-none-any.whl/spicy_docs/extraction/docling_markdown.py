"""Convert generated Markdown through GFM and Docling HTML without inferring table structure."""

from __future__ import annotations

import hashlib
import io
import re

from .model import ExtractionError

CONVERSION = "marko-gfm+docling-html-v1"


def _table_issues(soup):
    """Check stated spans before HTML recovery can silently shift the header/data grid."""
    issues, warnings = [], []
    for index, table in enumerate(soup.find_all("table")):
        rows = [row for row in table.find_all("tr") if row.find_parent("table") is table]
        groups = [row.find_parent(["thead", "tbody", "tfoot"]) or table for row in rows]
        widths, active = [], []
        for row_index, row in enumerate(rows):
            group_end = row_index + 1
            while group_end < len(rows) and groups[group_end] is groups[row_index]:
                group_end += 1
            width = sum(span for end, span in active if end > row_index)
            for cell in row.find_all(["th", "td"], recursive=False):
                try:
                    column_span = int(cell.get("colspan", 1))
                    row_span = int(cell.get("rowspan", 1))
                    if row_span == 0:  # HTML's explicit "through the end of this row group".
                        row_span = group_end - row_index
                    if column_span < 1 or row_span < 1:
                        raise ValueError
                except (TypeError, ValueError):
                    issues.append({"table": index, "row": row_index, "reason": "invalid_span"})
                    continue
                if row_index + row_span > group_end:
                    issues.append({"table": index, "row": row_index, "reason": "rowspan_crosses_row_group"})
                width += column_span
                if row_span > 1:
                    active.append((row_index + row_span, column_span))
            widths.append(width)
        if len(set(widths)) > 1:
            # Forms can legitimately use a ragged grid. Retain stated cells and warn;
            # a missing slot is unknown, not an observed empty cell or guessed header.
            warnings.append({"table": index, "reason": "ragged_table_rows", "row_widths": widths})
    return issues, warnings


def _markdown_table_issues(node, source):
    """Refuse GFM's lossy padding/truncation of uneven pipe rows before rendering."""
    from marko.ext.gfm.elements import Table, TableRow

    issues = []
    if isinstance(node, Table):
        for row in node.children:
            start, end = row.source_span
            cells = TableRow.splitter.split(source[start:end].strip())
            if cells and not cells[0]:
                cells.pop(0)
            if cells and not cells[-1]:
                cells.pop()
            if len(cells) != node.num_of_cols:
                issues.append({"reason": "ragged_markdown_row", "source_span": [start, end]})
    children = getattr(node, "children", None)
    if isinstance(children, list):
        for child in children:
            issues.extend(_markdown_table_issues(child, source))
    return issues


def convert_markdown(source: str):
    """Return a Docling document plus conversion evidence; perform no OCR or resource fetches."""
    import marko
    from bs4 import BeautifulSoup
    from docling.backend.html_backend import HTMLDocumentBackend
    from docling.datamodel.backend_options import HTMLBackendOptions
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.document import InputDocument

    receipt = {"backend": CONVERSION, "source_sha256": hashlib.sha256(source.encode()).hexdigest()}
    # Full-response fences are transport formatting; preserve the original bytes in the caller's raw response.
    fenced = re.fullmatch(r"\s*```(?:markdown|md|html)?\s*\n(.*?)\n```\s*", source, flags=re.DOTALL)
    body = fenced.group(1) if fenced else source
    renderer = marko.Markdown(extensions=["gfm"])
    tree = renderer.parse(body)
    issues = _markdown_table_issues(tree, body)
    if issues:
        raise ExtractionError(
            "Generated Markdown table would lose or invent cells", details={**receipt, "issues": issues}
        )
    html = renderer.render(tree)
    receipt["html_sha256"] = hashlib.sha256(html.encode()).hexdigest()
    soup = BeautifulSoup(html, "html.parser")
    issues, table_warnings = _table_issues(soup)
    if issues:
        raise ExtractionError("Generated table structure is ambiguous", details={**receipt, "issues": issues})
    # Malformed pipe tables remain ordinary text, including every row. They are not recovered table records.
    receipt["warnings"] = (
        ["unstructured_pipe_rows"]
        if any(
            sum(line.count("|") >= 2 for line in paragraph.get_text().splitlines()) >= 2
            for paragraph in soup.find_all("p")
        )
        else []
    )
    receipt["table_warnings"] = table_warnings
    stream = io.BytesIO(html.encode())
    options = HTMLBackendOptions(infer_furniture=False, add_title=False, fetch_images=False)
    input_document = InputDocument(
        path_or_stream=stream,
        filename="response.html",
        format=InputFormat.HTML,
        backend=HTMLDocumentBackend,
        backend_options=options,
    )
    backend = HTMLDocumentBackend(in_doc=input_document, path_or_stream=stream, options=options)
    try:
        document = backend.convert()
    finally:
        backend.unload()
    # Text generation provides no measured word or cell geometry. Do not attach synthetic boxes.
    return document, receipt
