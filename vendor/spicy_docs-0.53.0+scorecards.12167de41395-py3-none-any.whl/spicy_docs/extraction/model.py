"""Small data types and injectable interfaces for page extraction."""

from __future__ import annotations

import math
from collections.abc import Iterator, Mapping, Sequence
from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from typing import Any, Protocol


class ExtractionError(RuntimeError):
    """A failed extraction, optionally carrying retained provider diagnostics."""

    def __init__(self, message: str, *, details: Any = None):
        super().__init__(message)
        self.details = details


@dataclass(frozen=True, slots=True)
class Box:
    """Normalized displayed-page coordinates, top-left origin."""

    x0: float = 0
    y0: float = 0
    x1: float = 1
    y1: float = 1

    def __post_init__(self):
        if not all(math.isfinite(v) for v in (self.x0, self.y0, self.x1, self.y1)):
            raise ValueError("box coordinates must be finite")
        if not (0 <= self.x0 < self.x1 <= 1 and 0 <= self.y0 < self.y1 <= 1):
            raise ValueError("box must have positive area within [0, 1]")

    def contains(self, other: Box) -> bool:
        return self.x0 <= other.x0 and self.y0 <= other.y0 and self.x1 >= other.x1 and self.y1 >= other.y1

    def intersects(self, other: Box) -> bool:
        return self.x0 < other.x1 and self.x1 > other.x0 and self.y0 < other.y1 and self.y1 > other.y0

    def union(self, other: Box) -> Box:
        """The smallest displayed-page box containing both boxes."""
        return Box(min(self.x0, other.x0), min(self.y0, other.y0), max(self.x1, other.x1), max(self.y1, other.y1))

    def place(self, child: Box) -> Box:
        """Map crop-relative coordinates into this page region."""
        w, h = self.x1 - self.x0, self.y1 - self.y0
        return Box(self.x0 + child.x0 * w, self.y0 + child.y0 * h, self.x0 + child.x1 * w, self.y0 + child.y1 * h)


@dataclass(frozen=True, slots=True)
class Raster:
    """Encoded image bytes plus their pixel size and normalized page region."""

    data: bytes
    width: int
    height: int
    box: Box = field(default_factory=Box)
    media_type: str = "image/png"


@dataclass(frozen=True, slots=True)
class TextBlock:
    """One text run, optionally placed and scored, tagged with its observation id."""

    text: str
    box: Box | None = None
    confidence: float | None = None
    observation: str = ""
    inspected_region: Box | None = None


@dataclass(frozen=True, slots=True)
class ProcessingIssue:
    """A provider or composition limitation retained separately from raw output."""

    code: str
    message: str


@dataclass(frozen=True, slots=True)
class TableCell:
    """One provider-stated cell; indexes are zero-based and spans preserve merged cells."""

    row: int
    column: int
    text: str | None
    box: Box | None = None
    row_span: int = 1
    column_span: int = 1
    column_header: bool = False
    row_header: bool = False
    row_section: bool = False

    def __post_init__(self):
        if self.row < 0 or self.column < 0 or self.row_span < 1 or self.column_span < 1:
            raise ValueError("cell indexes must be nonnegative and spans positive")


@dataclass(frozen=True, slots=True)
class Recognition:
    """One model reading: its text, configuration and raw output, with optional blocks and images.

    ``blocks``, when given, must join to exactly ``text`` in order or construction is refused.
    """

    text: str
    configuration: dict[str, Any]
    raw: Any
    blocks: tuple[TextBlock, ...] = ()
    images: tuple[Raster, ...] = ()
    text_format: str = "plain"
    issues: tuple[ProcessingIssue, ...] = ()
    inspected_region: Box | None = None
    tables: tuple[TableObservation, ...] = ()

    def __post_init__(self):
        if self.text_format not in ("plain", "markdown", "html"):
            raise ValueError("text_format must be plain, markdown or html")
        if self.blocks and "\n".join(block.text for block in self.blocks) != self.text:
            raise ValueError("recognition blocks must preserve the complete recognition text")


@dataclass(frozen=True, slots=True)
class Observation:
    id: str
    text: str
    configuration: dict[str, Any]
    raw: Any
    blocks: tuple[TextBlock, ...]
    images: tuple[Raster, ...] = ()
    text_format: str = "plain"
    issues: tuple[ProcessingIssue, ...] = ()
    inspected_region: Box | None = None
    tables: tuple[TableObservation, ...] = ()


@dataclass(frozen=True, slots=True)
class PageContent:
    blocks: tuple[TextBlock, ...]
    observations: tuple[Observation, ...]

    @property
    def text(self) -> str:
        return "\n".join(block.text for block in self.blocks if block.text)


@dataclass(frozen=True, slots=True)
class TableObservation:
    """Provider-stated table cells and geometry, kept beside page text.

    ``None`` cell text means unknown or missing; ``""`` means observed empty.
    Geometry can be absent even when text is known. ``cell_details`` preserves
    provider-stated headers and merged spans; ``raw`` retains its original table.
    """

    page: int
    bbox: Box | None
    row_count: int
    column_count: int
    #: Row-major values preserve unknown versus observed empty.
    cells: tuple[tuple[str | None, ...], ...]
    #: Measured boxes only; unavailable geometry is None.
    cell_boxes: tuple[tuple[Box | None, ...], ...]
    #: The extractor's own confidence, when it states one. PyMuPDF's table
    #: finder does not, so this is ``None`` for every observation it produces.
    confidence: float | None = None
    raw: Any = None
    cell_details: tuple[TableCell, ...] = ()

    def __post_init__(self):
        if self.page < 1:
            raise ValueError("table page must be 1 or greater")
        if self.row_count < 1 or self.column_count < 1:
            raise ValueError("table must have at least one row and one column")
        shape = (self.row_count, self.column_count)
        for name, rows in (("cells", self.cells), ("cell_boxes", self.cell_boxes)):
            if len(rows) != shape[0] or any(len(row) != shape[1] for row in rows):
                raise ValueError(f"{name} must be shaped row_count x column_count")
        if self.confidence is not None and not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")


@dataclass(frozen=True, slots=True)
class PageResult:
    """One page's metadata, content and provider-stated tables."""

    metadata: dict[str, Any]
    content: PageContent
    #: Provider tables, plus native table detection when opted in, kept beside
    #: content without folding cell relationships into page text.
    tables: tuple[TableObservation, ...] = ()

    @property
    def text(self) -> str:
        return self.content.text


class ImageBackend(Protocol):
    """A recognition model over one raster."""

    def recognize(self, image: Raster) -> Recognition: ...


class Page(Protocol):
    """One page of an opened document: native text, rendering and table detection."""

    number: int
    geometry: dict[str, Any]
    has_native_layer: bool

    def native(self) -> Recognition: ...
    def render(self) -> Raster: ...
    def find_tables(self) -> tuple[TableObservation, ...]: ...


class Document(Protocol):
    """An opened document's page count and one-based page access."""

    page_count: int

    def page(self, number: int) -> Page: ...


class DocumentReader(Protocol):
    """Open source bytes of one media type, yielding a :class:`Document` until context exit."""

    def open(self, source: bytes, media_type: str) -> AbstractContextManager[Document]: ...


class PageStrategy(Protocol):
    """How one page becomes observations and ordered blocks."""

    def extract(self, page: Page) -> PageContent: ...


class Extractor(Protocol):
    """The streaming extraction entry point over exact source bytes."""

    def extract(
        self,
        source: bytes,
        *,
        media_type: str,
        pages: Sequence[int] | None = None,
        overrides: Mapping[int, PageStrategy] | None = None,
    ) -> Iterator[PageResult]: ...
