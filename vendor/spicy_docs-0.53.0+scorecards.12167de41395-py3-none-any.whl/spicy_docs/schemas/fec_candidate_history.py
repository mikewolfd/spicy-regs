"""The FEC candidate master as a table: one row per candidate per two-year cycle, and its row projection."""

from __future__ import annotations

from collections.abc import Mapping

from spicy_docs.schemas.tables import AT_JOINED_KEY, table_contract

#: Each published column after ``candidate_id`` and ``cycle``, and the header field it copies. Together with
#: ``CAND_ID`` these are every ``sources.fec.candidate_master.CANDIDATE_MASTER_FIELDS`` entry once; a test holds the
#: two lists to that, because this stdlib-only leaf does not import ``sources``.
_FROM_FIELD: dict[str, str] = {
    "name": "CAND_NAME",
    "party": "CAND_PTY_AFFILIATION",
    "election_year": "CAND_ELECTION_YR",
    "office_state": "CAND_OFFICE_ST",
    "office": "CAND_OFFICE",
    "office_district": "CAND_OFFICE_DISTRICT",
    "incumbent_challenger_status": "CAND_ICI",
    "status": "CAND_STATUS",
    "principal_committee_id": "CAND_PCC",
    "street_1": "CAND_ST1",
    "street_2": "CAND_ST2",
    "city": "CAND_CITY",
    "state": "CAND_ST",
    "zip": "CAND_ZIP",
}


def project_candidate_master_row(row: Mapping) -> dict[str, str | None]:
    """Project one :func:`iter_candidate_master_rows` row onto the published columns; a blank field is NULL.

    A blank ``CAND_ID`` refuses: it would publish an empty identity.
    """
    fields = row["fields"]
    if not fields["CAND_ID"].strip():
        raise ValueError("FEC candidate master row has a blank CAND_ID")
    projected: dict[str, str | None] = {"candidate_id": fields["CAND_ID"], "cycle": str(row["cycle"])}
    projected.update({column: fields[field] or None for column, field in _FROM_FIELD.items()})
    FEC_CANDIDATE_HISTORY.spelled_key(projected)
    return projected


FEC_CANDIDATE_HISTORY = table_contract(
    "fec_candidate_history",
    grain="One row per FEC candidate per two-year cycle, as that cycle's bulk candidate master states it.",
    identity=("candidate_id", "cycle"),
    # The shared key spelling refuses empty components and the reserved "@" separator.
    key_spelling=AT_JOINED_KEY,
    version_column=None,
    columns={
        "candidate_id": "The FEC candidate id (`CAND_ID`).",
        "cycle": "The two-year cycle the file covers, as its closing even year.",
        "name": "The candidate's name as that cycle's file states it (`CAND_NAME`); NULL when blank.",
        "party": "The party affiliation code (`CAND_PTY_AFFILIATION`), literal; NULL when blank.",
        "election_year": "The candidate's election year as filed (`CAND_ELECTION_YR`); NULL when blank.",
        "office_state": "The office's state code (`CAND_OFFICE_ST`); NULL when blank.",
        "office": "The office sought code (`CAND_OFFICE`), literal; NULL when blank.",
        "office_district": "The office's district (`CAND_OFFICE_DISTRICT`); NULL when blank.",
        "incumbent_challenger_status": "The incumbent/challenger/open code (`CAND_ICI`), literal; NULL when blank.",
        "status": "The candidate status code (`CAND_STATUS`), literal; NULL when blank.",
        "principal_committee_id": "The candidate's principal campaign committee (`CAND_PCC`); NULL when none.",
        "street_1": "The first street line of the candidate's address (`CAND_ST1`); NULL when blank.",
        "street_2": "The second street line (`CAND_ST2`); NULL when blank.",
        "city": "The address city (`CAND_CITY`); NULL when blank.",
        "state": "The address state (`CAND_ST`); NULL when blank.",
        "zip": "The address ZIP code as filed (`CAND_ZIP`); NULL when blank.",
    },
)

__all__ = ["FEC_CANDIDATE_HISTORY", "project_candidate_master_row"]
