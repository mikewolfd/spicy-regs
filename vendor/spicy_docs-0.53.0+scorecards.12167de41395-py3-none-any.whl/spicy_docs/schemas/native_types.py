"""Stdlib-only native table type grammar and exact value validation."""

from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta
from decimal import Decimal
from functools import lru_cache

_SCALARS = frozenset({"VARCHAR", "BOOLEAN", "INTEGER", "BIGINT", "DOUBLE", "DATE", "TIMESTAMP", "TIMESTAMPTZ"})
_TOKEN = re.compile(r'\s*("(?:[^"]|"")*"|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[(),\[\]])')


@lru_cache(maxsize=256)
def parse_type(text: str):
    """Return a type tree; refuse unknown tokens, duplicate fields and trailing SQL."""
    tokens, position = [], 0
    while position < len(text):
        match = _TOKEN.match(text, position)
        if match is None:
            raise ValueError(f"Invalid native type: {text!r}")
        tokens.append(match[1])
        position = match.end()
    cursor = 0

    def take(expected=None):
        nonlocal cursor
        if cursor >= len(tokens) or expected is not None and tokens[cursor] != expected:
            raise ValueError(f"Invalid native type: {text!r}")
        value = tokens[cursor]
        cursor += 1
        return value

    def parse():
        name = take()
        if name in _SCALARS:
            tree = (name,)
        elif name == "DECIMAL":
            take("(")
            precision = int(take())
            take(",")
            scale = int(take())
            take(")")
            if not 1 <= precision <= 38 or not 0 <= scale <= precision:
                raise ValueError("Decimal precision/scale is outside Decimal128")
            tree = (name, precision, scale)
        elif name == "STRUCT":
            take("(")
            fields = []
            while True:
                field_name = take()
                if field_name.startswith('"'):
                    field_name = field_name[1:-1].replace('""', '"')
                elif not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", field_name):
                    raise ValueError("Invalid struct field")
                if field_name in {key for key, _ in fields}:
                    raise ValueError("Duplicate struct field")
                fields.append((field_name, parse()))
                if tokens[cursor : cursor + 1] != [","]:
                    break
                take(",")
            take(")")
            tree = (name, tuple(fields))
        else:
            raise ValueError(f"Unsupported native type: {name}")
        while tokens[cursor : cursor + 1] == ["["]:
            take("[")
            take("]")
            tree = ("LIST", tree)
        return tree

    result = parse()
    if cursor != len(tokens):
        raise ValueError(f"Trailing native type tokens: {text!r}")
    return result


def is_value_of(column_type: str, value: object) -> bool:
    """Validate native values recursively without coercion or loss of precision."""

    def check(tree, item):
        if item is None:
            return True
        name = tree[0]
        if name == "VARCHAR":
            return isinstance(item, str)
        if name == "BOOLEAN":
            return type(item) is bool
        if name in {"INTEGER", "BIGINT"}:
            bound = 1 << ({"INTEGER": 31, "BIGINT": 63}[name])
            return type(item) is int and -bound <= item < bound
        if name == "DOUBLE":
            return type(item) is float and math.isfinite(item)
        if name == "DATE":
            return type(item) is date
        if name == "TIMESTAMP":
            return isinstance(item, datetime) and item.tzinfo is None
        if name == "TIMESTAMPTZ":
            return isinstance(item, datetime) and item.utcoffset() == timedelta(0)
        if name == "DECIMAL":
            if not isinstance(item, Decimal) or not item.is_finite():
                return False
            _, digits, exponent = item.as_tuple()
            # Coefficient at declared scale must fit without rounding.
            extra = exponent + tree[2]
            if extra < 0 and any(digits[len(digits) + extra :]):
                return False
            return max(len(digits) + extra, 1) <= tree[1]
        if name == "LIST":
            return isinstance(item, list) and all(check(tree[1], child) for child in item)
        if name == "STRUCT":
            return (
                isinstance(item, dict)
                and set(item) == {key for key, _ in tree[1]}
                and all(check(dtype, item[key]) for key, dtype in tree[1])
            )
        return False

    return check(parse_type(column_type), value)
