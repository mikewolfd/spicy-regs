"""The ``gao_decisions`` table: every legal decision page GAO's own Month in Review and Annual Index list.

Shaped from ``sources.gao.month_in_review``'s listed decisions and numbered others (a Contract Appeals Board docket,
a ``P`` number); a page GAO lists with no number is left out. The outcome is read by
``interpretation.gao_decisions`` and, where the decision's page was read, its caption by
``sources.gao.decision_pages``; both are passed in, as a bill's stage is, so this module stays a leaf. Until round 5 the
host shaped these rows itself and called the release date ``decision_date``; it is ``released_date`` here because it
is when GAO released the decision, not when GAO decided it (B-424477: decided 2026-08-07, released 2026-08-28).
"""

from __future__ import annotations

import json

from spicy_docs.schemas.tables import Row, table_contract, text

#: GAO's site, which a listing's links are relative to.
GAO_SITE = "https://www.gao.gov"
#: The route that supplies every row: GAO's own Month in Review and Annual Index.
SOURCE = "gao_listing"

GAO_DECISIONS = table_contract(
    "gao_decisions",
    grain=(
        "One row per legal decision page GAO's own Month in Review or Annual Index lists with a number: every "
        "B-numbered decision and every docket- or P-numbered other. Federal Agency Major Rule Reports, B-numbered "
        "from April 2017, are products, not rows here."
    ),
    identity=("decision_number", "url"),
    version_column=None,
    columns={
        "decision_number": (
            "The decision's number as GAO's listing spells it, suffixes and all (`B-424129.2`, "
            "`B-423916.2,B-423916.3`, `B-235577.2-O.M.`, a docket `2020-02`). With `url`, the key."
        ),
        "b_numbers_json": (
            "JSON array of the decision's B-numbers: the ones its page's File line states where the page was read, "
            "else the ones in `decision_number`, split on commas and semicolons. GAO's listing cuts a few long "
            "lists, ending them `et al` or where its number field is full, and a fragment it cut mid-number is left "
            "out; b_numbers_truncated says where the list here is still the cut one. `[]` for a docket- or "
            "P-numbered decision."
        ),
        "decision_type": (
            "GAO's label for the page as its listing states it: `Bid Protest Decision`, `Appropriations Decision`, "
            "`Legal Other Decision` and the like. A label, not a check: GAO also labels a few reports and letters "
            "`Bid Protest Decision` (B-423717, B-401197)."
        ),
        "title": (
            "The decision's heading as GAO's listing states it: the protester or the question decided. GAO "
            "double-escapes some headings, so a few keep `&mdash;`, `&#151;` or `&amp;` literally."
        ),
        "released_date": (
            "The listing's Publicly Released date (its Published date where it states no release), as an ISO date: "
            "when GAO released the decision, not when it decided it (B-424477: decided 2026-08-07, released "
            "2026-08-28). A count by fiscal year counts releases."
        ),
        "topics_json": "JSON array of GAO's headings the decision was listed under, in listed order.",
        "url": (
            "The decision's gao.gov page, as the listing links it (percent-encoded where GAO encodes it). With "
            "`decision_number`, the key."
        ),
        "listing_page": "The first Month in Review or Annual Index page that listed the decision, as requested.",
        "source": "The route that supplied the row: `gao_listing` (GAO's own Month in Review and Annual Index).",
        "decision_status": (
            "GAO's outcome sentence for the decision as its listing states it, word for word with HTML whitespace "
            "collapsed (`We deny the protest.`); NULL where the listing states none."
        ),
        # Before the two readings, which a host re-reads on every held row and appends last.
        "b_numbers_truncated": (
            "`true` where GAO's listing cut the decision's numbers -- the list ends `et al` or in a separator, or "
            "fills the listing's number field (64 characters for decisions released 2009-2011, 252 from 2012) -- and "
            "no decision page has completed it, so b_numbers_json holds only what the listing names; `false` "
            "otherwise."
        ),
        "decided_date": (
            "The day GAO decided the decision, from the Date line of its page's caption, as an ISO date; NULL where no "
            "page was read or the page prints no caption (a letter, a report, a decision GAO posts only as a PDF). "
            "GAO releases a decision after deciding it, often days later (B-424477: decided 2026-08-07, released "
            "2026-08-28), so a count by decided_date and one by released_date differ."
        ),
        "outcome": (
            "The outcome decision_status states, read by a closed table of GAO's exact sentences: `sustained`, "
            "`sustained_in_part`, `denied`, `dismissed`, `denied_in_part_dismissed_in_part`, or `request` where the "
            "sentence decides only a request (reconsideration, costs, reimbursement, dismissal); a sentence deciding "
            "the protest and a request reads the protest's outcome. "
            "NULL where no sentence is stated or the table does not read it (an advisory opinion, an appropriations "
            "opinion, a wording GAO wrote after the table was made): never a guess."
        ),
        "outcome_rule": (
            "The table that read outcome, `gao-decision-outcome/002`; NULL where outcome is NULL. A row read under an "
            "earlier table names that table."
        ),
    },
)


def shape_gao_decision(decision: object, *, outcome: object, caption: object = None) -> Row:
    """One ``gao_decisions`` row for a listed decision or numbered other, its outcome finding and its page's caption.

    ``decision`` is a ``GaoListedDecision`` or ``GaoListedOther`` (an other states no B-numbers), ``outcome`` the
    ``DecisionOutcome`` ``interpretation.gao_decisions.decision_outcome`` read from its status, and ``caption`` the
    ``GaoDecisionCaption`` ``sources.gao.decision_pages.read_decision_caption`` read from its page, or None where no
    page was read or it prints no caption; all by attribute. A caption's File list replaces the listing's numbers,
    complete where the listing cut them.
    """
    numbers = caption.numbers if caption is not None else getattr(decision, "decision_numbers", ())
    truncated = caption is None and getattr(decision, "decision_numbers_cut", False)
    return {
        "decision_number": text(decision.product_number),
        "b_numbers_json": json.dumps(list(numbers), ensure_ascii=False),
        "decision_type": text(decision.label),
        "title": text(decision.heading),
        "released_date": text(decision.released or decision.published),
        "topics_json": json.dumps(list(decision.topics), ensure_ascii=False),
        "url": GAO_SITE + decision.link,
        "listing_page": text(decision.listing_page),
        "source": SOURCE,
        "decision_status": text(decision.status),
        "b_numbers_truncated": "true" if truncated else "false",
        "decided_date": None if caption is None else caption.decided_date,
        "outcome": text(outcome.outcome),
        "outcome_rule": text(outcome.rule),
    }


__all__ = ["GAO_DECISIONS", "GAO_SITE", "SOURCE", "shape_gao_decision"]
