"""CBO PDF card observations using maintained text/structured extraction backends.

Qualification remains incomplete: see docs/research/cbo-pdf-qualification-2026-11-13.md.
The bounded retained-pair comparison does not select a production PDF backend or
replace the owner's complete native, rendered and model parity requirements.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlsplit

from spicy_docs.schemas.cbo_estimate_cards import CBO_ESTIMATE_CARD_SCHEMA
from spicy_docs.sources.cbo import CboEstimateCard, CboSourceError, card_row, validate_card


@dataclass(frozen=True)
class PdfIdentity:
    publication_id: str
    pdf_url: str
    page_source_sha256: str
    page_source_locator: str
    rule: str = "verified-publication-page-pdf-link/1"


def identity_from_page(card, *, pdf_url, source_sha256, source_locator):
    """A validated publication page's explicit PDF link is authoritative; bill/month is not."""
    parts = urlsplit(pdf_url)
    if (
        parts.scheme != "https"
        or parts.hostname != "www.cbo.gov"
        or parts.query
        or parts.fragment
        or parts.path not in card.documents
        or not re.fullmatch(r"sha256:[0-9a-f]{64}", source_sha256)
        or not source_locator
    ):
        raise CboSourceError("PDF identity requires the verified publication page's explicit PDF link and original pin")
    return PdfIdentity(card.publication_id, pdf_url, source_sha256, source_locator)


_MEASURES = {
    "direct_spending_outlays": r"Direct Spending \(Outlays\)",
    "revenues": r"Revenues",
    "increase_or_decrease_in_the_deficit": r"Increase or Decrease \(-\) in the Deficit",
    "spending_subject_to_appropriation_outlays": r"Spending Subject to Appropriation \(Outlays\)",
}
_QUESTIONS = {
    "increase_net_spending": r"Increases net direct spending in any of the four consecutive 10-year periods beginning in [0-9]{4}\?",
    "pay_go": r"Statutory pay-as-you-go procedures apply\?",
    "increase_budget_deficits": r"Increases on-budget deficits in any of the four consecutive 10-year periods beginning in [0-9]{4}\?",
    "mandate_effect_intergovernmental": r"Contains intergovernmental mandate\?",
    "mandate_effect_private_sector": r"Contains private-sector mandate\?",
}
_CELL = r"(?:-?(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)|\*|not estimated)"


def parse_pdf_card_text(text, *, identity: PdfIdentity):
    """Strictly read the observed first-page layout; unknown cells refuse.

    Input is a maintained backend's observation, not publisher bytes. Caller
    retains that observation, its method and the original page separately.
    """
    if not isinstance(identity, PdfIdentity) or identity.rule != "verified-publication-page-pdf-link/1":
        raise CboSourceError("PDF-only bill/month candidates have unresolved publication identity")
    flat = " ".join(text.split())
    unit = re.search(r"By Fiscal Year, Millions of Dollars\s+", flat)
    if unit is None or "Congressional Budget Office" not in flat or "Cost Estimate" not in flat:
        raise CboSourceError("PDF page does not state the expected CBO card and millions unit")
    body = flat[unit.end() :]
    periods = re.match(r"([0-9]{4}(?:-[0-9]{4})?)\s+([0-9]{4}(?:-[0-9]{4})?)\s+([0-9]{4}(?:-[0-9]{4})?)\s+", body)
    if periods is None:
        raise CboSourceError("PDF card does not state three positional fiscal window headings")
    matches = sorted(
        (match.start(), match.end(), name, kind)
        for kind, labels in (("measure", _MEASURES), ("question", _QUESTIONS))
        for name, label in labels.items()
        for match in re.finditer(label, body)
    )
    measures, answers = {}, {}
    for position, (start, end, name, kind) in enumerate(matches):
        if name in measures or name in answers:
            raise CboSourceError("PDF first page repeats a card label")
        stop = matches[position + 1][0] if position + 1 < len(matches) else len(body)
        value = body[end:stop].strip()
        if kind == "measure":
            cells = re.fullmatch(rf"({_CELL})\s+({_CELL})\s+({_CELL})", value)
            if cells is None:
                raise CboSourceError(f"PDF card has unread or extra cells for {name}")
            measures[name] = cells.groups()
        else:
            # The last answer is followed by footnotes and explanatory prose.
            answer = re.match(
                r"(No|Yes(?:,\s*(?:Over Threshold|Under Threshold|Cannot Determine Costs))?|Excluded from UMRA|< \$[0-9.]+ billion)(?=\s|$)",
                value,
            )
            if answer is None:
                raise CboSourceError(f"PDF card has an unread answer for {name}")
            answers[name] = answer[1]
    if not measures or set(answers) != set(_QUESTIONS):
        raise CboSourceError("PDF card labels are incomplete")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    heading_index = next(
        (
            index
            for index, line in enumerate(lines)
            if re.match(r"(?:H\.R\.|S\.|H\. Con\.|S\. Con\.|Legislation)", line)
        ),
        None,
    )
    if heading_index is None:
        raise CboSourceError("PDF estimate heading is unread")
    unit_index = next(index for index, line in enumerate(lines) if "By Fiscal Year, Millions of Dollars" in line)
    header = lines[heading_index:unit_index]
    context_index = next((index for index, line in enumerate(header) if line.startswith("As ")), len(header))
    heading = " ".join(header[:context_index])
    subtitle = " ".join(header[context_index:]) or None
    notes = tuple(line for line in lines if line.startswith("* =") or "table applies to each bill" in line.lower())
    card = CboEstimateCard(
        identity.publication_id,
        heading,
        subtitle,
        periods.groups(),
        measures,
        answers,
        notes,
        (urlsplit(identity.pdf_url).path,),
        markup="pdf-first-page",
    )
    card_row(card, card_source="pdf-native")
    return card


def read_native_pdf_card(payload, *, identity, reader=None):
    """Read one original page through the existing PyMuPDF backend; retain the returned observation."""
    from spicy_docs.extraction.pages import DefaultReader

    with (reader or DefaultReader()).open(payload, "application/pdf") as document:
        observation = document.page(1).native()
    card = parse_pdf_card_text(observation.text, identity=identity)
    return card, observation


def structured_pdf_reader(client, *, model, identity):
    """Configure the existing injectable structured interface with the same card schema."""
    from spicy_docs.extraction.gemini import Gemini
    from spicy_docs.extraction.prompts import CBO_ESTIMATE_CARD

    return Gemini(
        client,
        model=model,
        mode="structured",
        prompt=CBO_ESTIMATE_CARD + "\nVerified publication_id: " + identity.publication_id,
        outcome_schema=CBO_ESTIMATE_CARD_SCHEMA,
    )


def structured_card_observation(recognizer, image, *, identity, page_number=1, **provenance):
    """Return the retained conversation and validated observation; never claim model accuracy."""
    import hashlib
    import json

    if type(page_number) is not int or page_number < 1:
        raise ValueError("PDF page_number must be one-based")
    observation = recognizer.recognize(image)
    row = dict(observation.raw["outcome"])
    if row["publication_id"] != identity.publication_id:
        raise CboSourceError("Model card publication identity differs from the pinned page/PDF association")
    request = observation.raw["calls"][0]["request"]
    request_id = (
        provenance.pop("request_id", None)
        or "sha256:" + hashlib.sha256(json.dumps(request, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    )
    row.update(
        provenance,
        card_source="pdf-llm",
        page_number=page_number,
        identity_rule=identity.rule,
        extraction_method="structured",
        model_id=recognizer.model,
        request_id=request_id,
        pdf_urls=[identity.pdf_url],
    )
    validate_card(row)
    return row, observation
