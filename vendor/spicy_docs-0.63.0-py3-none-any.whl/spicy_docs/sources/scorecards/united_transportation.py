"""One named UTU retrospective assessment; no annual roster or source-time Senate term."""

import re
from hashlib import sha256

from spicy_docs.schemas.tables import json_column

from .capwiz_html import native, text
from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key, soup
from .qualified_observations import require_reviewed_pdf

parser_version = "utu-2012-named-retrospective-html/1"
SOURCE_URL = "https://www.smart-union.org/why-obama-biden-deserve-your-vote-nov-6/"
PDF_URL = "https://www.smart-union.org/wp-content/uploads/2022/02/October-2012-SMART-Transportation-Newsletter.pdf"
HTML_SHA256 = "fc134e9a91f1f9a8c8869a8eb4411574686eec69ca190b93bb5391d4919c0ebd"
PDF_SHA256 = "6ebb47439bb6030b2d3d65b659d57988f6a2134cf3aea67043cb5ea864260ef2"
TITLE = "Why Obama-Biden deserve your vote Nov. 6"
DATE = "October 26, 2012"
PUBLISHED = "2012-10-26T16:33:29+00:00"
BYLINE = "By James Stem – UTU National Legislative Director –"
STATEMENT = (
    "* Vice President Biden, who as a U.S. senator for 30 years, rode Amtrak more than any other fare-paying person "
    "in America, commuting daily between Washington, D.C., and his Delaware home. "
    "He has a lifetime UTU Senate voting record of 97 percent on issues vital to UTU members."
)
HOSTS = ("www.smart-union.org",)
ARTICLE_PATH = "css:article#post-18264"
ASSESSMENT_PATH = "(//article[@id='post-18264']//div[@class='entry-content']//p)[9]"
EDITION = ScorecardEdition(
    "united_transportation",
    "2012-10-26-post-18264-retrospective-assessment",
    SOURCE_URL,
    TITLE,
    # The article's date is publication context, not a 2012 evaluation period.
    chamber="UTU Senate",
    is_current=False,
)


def list_scorecards(context):
    """Select only the reviewed article; newsletter/archive populations are unknown."""
    return (EDITION,)


def _one(nodes, label):
    if len(nodes) != 1:
        raise ScorecardSourceError("UTU named article has missing or repeated " + label)
    return nodes[0]


def _facts(document):
    if document.url != SOURCE_URL or sha256(document.body).hexdigest() != HTML_SHA256:
        raise ScorecardSourceError("UTU named original article bytes or custody changed")
    if document.response.content_type.split(";", 1)[0].strip().lower() != "text/html":
        raise ScorecardSourceError("UTU named article is not original HTML")
    try:
        raw = document.body.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ScorecardSourceError("UTU named original article is not UTF-8") from error
    if (
        not re.search(r"</body>\s*</html>(?:\s*<!--.*?-->)*\s*$", raw, re.DOTALL | re.IGNORECASE)
        or len(re.findall(r"<article\b", raw, re.IGNORECASE)) != 1
        or len(re.findall(r"</article\s*>", raw, re.IGNORECASE)) != 1
    ):
        raise ScorecardSourceError("UTU named article does not reach complete original HTML boundaries")
    root = soup(document)
    # The retained source uses non-self-closing metadata tags. html.parser
    # nests the document title beneath them; SVG icon titles are outside head.
    title = _one(root.select("head title"), "document title")
    canonical = _one(root.select('link[rel="canonical"]'), "canonical locator")
    published = _one(root.select('meta[property="article:published_time"]'), "publication metadata")
    if text(title) != TITLE + " - SMART Union" or canonical.get("href") != SOURCE_URL:
        raise ScorecardSourceError("UTU named article title or canonical source changed")
    if published.get("content") != PUBLISHED:
        raise ScorecardSourceError("UTU named article publication metadata changed")
    article = _one(root.select("article#post-18264"), "post-18264")
    heading = _one(article.select("h1.entry-title"), "article heading")
    date = _one(article.select(":scope > p.font-light"), "visible publication date")
    content = _one(article.select(".entry-content"), "complete article content")
    paragraphs = content.find_all("p")
    # This is the reviewed article's paragraph inventory, not a publisher count
    # of rated members. The complete original stays in private capture storage;
    # unrelated endorsement paragraphs are not republished as methodology.
    if len(paragraphs) != 16 or text(heading) != TITLE or text(date) != DATE:
        raise ScorecardSourceError("UTU complete named article inventory, heading or date changed")
    if text(paragraphs[0]) != BYLINE or text(paragraphs[8]) != STATEMENT:
        raise ScorecardSourceError("UTU attribution or retrospective Biden assessment changed")
    if text(content).count("97 percent") != 1 or sum("voting record of" in text(p) for p in paragraphs) != 1:
        raise ScorecardSourceError("UTU named article assessment occurrence is missing or repeated")
    return {
        "article_attributes": dict(article.attrs),
        "heading": native(heading, ARTICLE_PATH + " h1.entry-title"),
        "byline": native(paragraphs[0], "(//article[@id='post-18264']//div[@class='entry-content']//p)[1]"),
        "assessment": native(paragraphs[8], ASSESSMENT_PATH),
        "publication_date": native(date, ARTICLE_PATH + " > p.font-light"),
        "title": native(title, "//head//title"),
        # Non-self-closing preload links in this original cause html.parser to
        # attach unrelated head content to the canonical void element. Only
        # each void element's own attributes and locator are source context.
        "canonical": {"source_path": '//link[@rel="canonical"]', "attributes": dict(canonical.attrs)},
        "publication_metadata": {
            "source_path": '//meta[@property="article:published_time"]',
            "attributes": dict(published.attrs),
        },
        "date": text(date),
        "subject": text(paragraphs[8]).split(", who as a U.S. senator", 1)[0].removeprefix("* "),
        "period": "lifetime",
        "chamber": "UTU Senate",
        "metric": "lifetime UTU Senate voting record",
        "value": "97 percent",
    }


def _corroboration(document):
    # These exact newsletter bytes already received page-1/page-4 visual and
    # Defaults/Docling/OvisOCR2/Gemini review. This HTML reader does not extract
    # PDF-derived fields or substitute model output for the article's statement.
    message = "UTU named newsletter corroboration bytes, format or custody changed"
    require_reviewed_pdf(document, source_url=PDF_URL, source_sha256=PDF_SHA256, message=message)
    if document.response.content_type.split(";", 1)[
        0
    ].strip().lower() != "application/pdf" or not document.body.rstrip().endswith(b"%%EOF"):
        raise ScorecardSourceError(message)


def acquire_scorecard(edition, context):
    if edition != EDITION:
        raise ScorecardSourceError("UTU reader supports only its named retrospective article assessment")
    source = context.read(SOURCE_URL, stage="utu:named-article", hosts=HOSTS)
    facts = _facts(source)
    newsletter = context.read(PDF_URL, stage="utu:newsletter-corroboration", hosts=HOSTS)
    _corroboration(newsletter)
    repeated = context.read(SOURCE_URL, stage="utu:named-article-reread", hosts=HOSTS)
    if _facts(repeated) != facts or repeated.body != source.body:
        raise ScorecardSourceError("UTU complete named article changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="United Transportation Union",
        parser_version=parser_version,
        rendition_rule="one complete named UTU original article supplies one retrospective assessment; exact newsletter is corroboration/1",
        homepage=None,
    )
    groups = ("publisher", "article-context", "member", "assessment")
    bundle.use(source, *groups)
    bundle.use(newsletter, "publisher", "assessment", role="corroboration")
    bundle.use(repeated, "edition", *groups, role="corroboration")
    bundle.tables["scorecard_publishers"][0].update(
        abbreviation="UTU", scorecard_index_url=None, source_path=ARTICLE_PATH + " .entry-content p:first-of-type"
    )
    periods = [
        {
            "occurrence_id": "native-lifetime",
            "kind": "explicit",
            "period_text": facts["period"],
            "source_path": ASSESSMENT_PATH,
        }
    ]
    bundle.tables["scorecards"][0].update(
        series_id="united_transportation:named-retrospective-assessments",
        publisher_edition_key="18264",
        edition_label_text=TITLE,
        timespan_text=facts["period"],
        periods_json=json_column(periods),
        published_at_text=facts["date"],
        source_path=ARTICLE_PATH,
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        ARTICLE_PATH,
        methodology_id="original-article-context",
        methodology_text=json_column(
            {
                k: facts[k]
                for k in (
                    "article_attributes",
                    "heading",
                    "byline",
                    "assessment",
                    "publication_date",
                    "title",
                    "canonical",
                    "publication_metadata",
                )
            }
        ),
        disclosure_status="literal assessment and attribution/publication context; retrospective rating formula, denominator and exact lifetime bounds unknown",
    )
    metric_id = "lifetime-senate-assessment"
    bundle.add(
        "scorecard_metrics",
        source,
        ASSESSMENT_PATH,
        metric_id=metric_id,
        name=facts["metric"],
        value_unit_text="percent",
        chamber_text=facts["chamber"],
        period_text=facts["period"],
        periods_json=json_column(periods),
    )
    member_key = key("article", "18264", "subject", facts["subject"])
    bundle.add(
        "scorecard_members",
        source,
        ASSESSMENT_PATH,
        publisher_member_key=member_key,
        member_name=facts["subject"],
        identifiers_json="[]",
        # No source-time Senate membership, official identity or term is inferred.
    )
    bundle.add(
        "scorecard_member_ratings",
        source,
        ASSESSMENT_PATH,
        metric_id=metric_id,
        publisher_member_key=member_key,
        value_text=facts["value"],
        value_number=decimal_text(facts["value"].removesuffix(" percent")),
    )
    return bundle.finish(
        "Complete only for the exact named UTU post-18264 article and its one explicit retrospective assessment. "
        "Original HTML EOF, full article/paragraph inventory, title, date, UTU byline and unique literal assessment "
        "are checked and reread unchanged. The exact October 2012 newsletter is separately captured as reviewed "
        "page-1/page-4 corroboration; no PDF-derived field or second rating is emitted. "
        "No annual roster, serving-2012 Senate term, lifetime dates, denominator, scoring items or formula established.",
    )
