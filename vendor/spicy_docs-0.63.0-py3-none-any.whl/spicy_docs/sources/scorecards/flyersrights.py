"""FlyersRights' recovered 2016 retrospective, with each original rendition separate.

The published component points are measurements, not identified roll-call votes.
Literal totals and grades survive source inconsistencies and are never calculated.
The linked PDF's complete privately reviewed text uses the existing retention seam.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)
from spicy_docs.sources.scorecards.workbooks import column, literal_sheets

parser_version = "flyersrights-2016-literal-renditions/1"
HTML = "https://web.archive.org/web/20160820125445id_/http://www.flyersrights.org:80/dbmanager/reportcard/index.php"
HTML_REPEAT = (
    "https://web.archive.org/web/20170101201606id_/http://www.flyersrights.org:80/dbmanager/reportcard/index.php"
)
HOUSE = (
    "https://web.archive.org/web/20161230102124id_/http://flyersrights.org/dbmanager/reportcard/"
    "House%20Report%20Card%202016.xlsx"
)
SENATE = (
    "https://web.archive.org/web/20161230082303id_/http://flyersrights.org/dbmanager/reportcard/"
    "Senate%20Report%20Card%20%202016.xlsx"
)
METHOD = (
    "https://web.archive.org/web/20160823221233id_/http://www.flyersrights.org:80/dbmanager/reportcard/"
    "ReportCardMethology.pdf"
)
ANNOUNCEMENT = "https://strandedpassengers.blogspot.com/2016/08/website-news-legislation-help-im_19.html"
PINS = {
    HTML: "3a4b508a791a31b91d2015d9a2533c4ae2b2360030baa2ab8fd36143190e94f7",
    HTML_REPEAT: "3a4b508a791a31b91d2015d9a2533c4ae2b2360030baa2ab8fd36143190e94f7",
    HOUSE: "99a12bf4882aac6b2c34b18ffa9392f536fef2ca63623b500938c84289ea9a41",
    SENATE: "044c70a58cc0536fd40f837bba9b147ce64cbd53d274c1723f6c95b0c83ab11e",
    METHOD: "d882e896dc3fbcffbbf4c25ef85ff517198884a21232bfbfa2ca71605448accd",
    ANNOUNCEMENT: "5d7c8681f97cb6ace373c4fda9f979c0c8e1317f29b11d1a8225a2c6ba54c029",
}
QUALIFIED_SHA256 = "c496e95aceddc7efb1efc8b806dbbf7fb7defd16afd2d778b97e945dd092c4b5"
HTML_EDITION = ScorecardEdition(
    "flyersrights", "2016-original-archived-html", HTML, "Congressional Report Card", year="2016", is_current=False
)
HOUSE_EDITION = ScorecardEdition(
    "flyersrights",
    "2016-house-original-archived-xlsx",
    HOUSE,
    "FlyersRights.org 2016 House Report Card",
    year="2016",
    chamber="House",
    is_current=False,
)
SENATE_EDITION = ScorecardEdition(
    "flyersrights",
    "2016-senate-original-archived-xlsx",
    SENATE,
    "FlyersRights.org 2016 Senate Report Card",
    year="2016",
    chamber="Senate",
    is_current=False,
)
EDITIONS = (HTML_EDITION, HOUSE_EDITION, SENATE_EDITION)
HTML_COUNTS = {"H": 435, "S": 100}
WORKBOOK_END = {HOUSE: 438, SENATE: 103}
GRADES = {"A+", "A", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"}
PERIOD = "over the past eight years"


def _read(context, url, stage):
    document = context.read(
        url, stage="flyersrights:" + stage, hosts=("web.archive.org", "strandedpassengers.blogspot.com")
    )
    if document.url != url or sha256(document.body).hexdigest() != PINS[url]:
        raise ScorecardSourceError("FlyersRights named original changed at " + stage)
    return document


def _facts(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("FlyersRights requires its exact privately reviewed complete methodology")
    try:
        data = json.loads(body)
        if (
            set(data) != {"format_version", "source_sha256", "page_count", "pages"}
            or data["format_version"] != "flyersrights-reviewed-methodology/1"
            or data["source_sha256"] != PINS[METHOD]
            or data["page_count"] != 4
            or len(data["pages"]) != 4
        ):
            raise ValueError
        for n, page in enumerate(data["pages"], 1):
            if (
                set(page) != {"physical_page", "source_path", "text"}
                or type(page["physical_page"]) is not int
                or page["physical_page"] != n
                or page["source_path"] != f"PDF/page[{n}]/native-text"
                or not isinstance(page["text"], str)
                or not page["text"].strip()
            ):
                raise ValueError
        return data
    except (ValueError, KeyError, TypeError):
        raise ScorecardSourceError("FlyersRights methodology lacks complete ordered reviewed pages") from None


def _announcement(document):
    nodes = soup(document).select(".post-body")
    if len(nodes) != 1:
        raise ScorecardSourceError("FlyersRights original release announcement is missing")
    text = nodes[0].get_text(" ", strip=True)
    if (
        "August, 17, 2016" not in text
        or "all 535 members of Congress" not in text
        or "FlyersRights.org measured Congressional performance" not in text
        or PERIOD not in text
        or not any(
            a.get("href") == "http://flyersrights.org/dbmanager/reportcard/index.php" for a in nodes[0].find_all("a")
        )
    ):
        raise ScorecardSourceError(
            "FlyersRights announcement cannot establish attribution, edition and retrospective scope"
        )
    return text


def _html(document):
    if b'content="text/html;charset=iso-8859-1"' not in document.body:
        raise ScorecardSourceError("FlyersRights HTML no longer declares its original charset")
    root = soup(document)
    tables = root.find_all("table")
    if len(tables) != 3 or "Congressional Report Card" not in root.get_text(" ", strip=True):
        raise ScorecardSourceError("FlyersRights original report-card table is missing")
    expected_links = {
        "ReportCardMethology.pdf",
        "House%20Report%20Card%202016.xlsx",
        "Senate%20Report%20Card%20%202016.xlsx",
    }
    if {a.get("href") for a in tables[1].find_all("a")} != expected_links:
        raise ScorecardSourceError("FlyersRights original rendition links are incomplete")
    rows = tables[2].find_all("tr")
    cells = []
    for row in rows:
        nodes = row.find_all(["td", "th"], recursive=False)
        if len(nodes) != 18 or any(n.has_attr("rowspan") or n.has_attr("colspan") for n in nodes):
            raise ScorecardSourceError("FlyersRights HTML member table is not rectangular")
        cells.append([n.get_text(" ", strip=True) for n in nodes])
    if not cells or cells[0][:5] != ["Committee", "Name", "Party", "State", "Chamber"] or not all(cells[0][5:]):
        raise ScorecardSourceError("FlyersRights HTML header is incomplete")
    counts = {"H": 0, "S": 0}
    identities = set()
    for row in cells[1:]:
        if row[4] not in counts or not row[1] or not row[2] or not row[3] or row[1] in identities:
            raise ScorecardSourceError("FlyersRights HTML member identities are missing or repeated")
        counts[row[4]] += 1
        identities.add(row[1])
        if (
            any(decimal_text(v) is None for v in row[5:15])
            or (row[15] != "n/a" if row[4] == "S" else decimal_text(row[15]) is None)
            or decimal_text(row[16]) is None
            or row[17] not in GRADES
        ):
            raise ScorecardSourceError("FlyersRights HTML lacks a literal component, total or grade")
    if counts != HTML_COUNTS:
        raise ScorecardSourceError("FlyersRights HTML does not contain the complete published roster")
    return cells[0], cells[1:]


def _workbook(document, edition):
    sheets = literal_sheets(document.body)
    if set(sheets) != {"Sheet1"}:
        raise ScorecardSourceError("FlyersRights workbook worksheet scope changed")
    cells = sheets["Sheet1"]
    end, width = WORKBOOK_END[document.url], 17 if edition == HOUSE_EDITION else 16
    if cells.get("A2") is None or cells["A2"].value != edition.title:
        raise ScorecardSourceError("FlyersRights workbook title does not establish its selected edition")
    headers = []
    for n in range(1, width + 1):
        cell = cells.get(column(n) + "3")
        if cell is None or not cell.value:
            raise ScorecardSourceError("FlyersRights workbook headers are incomplete")
        headers.append(cell.value)
    if headers[:4] != [
        "Committee",
        "Name",
        "State",
        "D/R",
    ]:
        raise ScorecardSourceError("FlyersRights workbook headers are incomplete")
    total = column(width - 1)
    summary = cells.get(total + str(end + 1))
    if summary is None or summary.formula != f"AVERAGE({total}4:{total}{end})":
        raise ScorecardSourceError("FlyersRights workbook no longer declares its complete member range")
    rows, names = [], set()
    for n in range(4, end + 1):
        values = [cells.get(column(i) + str(n)) for i in range(1, width + 1)]
        raw = [c.value if c is not None else None for c in values]
        if (
            any(not isinstance(v, str) or not v for v in raw[1:4])
            or raw[1] in names
            or any(decimal_text(v) is None for v in raw[4:-1])
            or raw[-1] not in GRADES
        ):
            raise ScorecardSourceError("FlyersRights workbook roster or scored cells are incomplete")
        names.add(raw[1])
        rows.append(raw)
    return headers, rows, cells


def list_scorecards(context: ScorecardContext):
    """List only the separately qualified named recovered renditions."""
    return EDITIONS


@dataclass(frozen=True, slots=True)
class FlyersRightsReader:
    parser_version: ClassVar[str] = parser_version
    qualified_methodology: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        _facts(self.qualified_methodology)
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_methodology=self.qualified_methodology,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_methodology=None, retain_observations=None):
    if edition not in EDITIONS or qualified_methodology is None or retain_observations is None:
        raise ScorecardSourceError("FlyersRights requires a named 2016 rendition and its private reviewed methodology")
    facts = _facts(qualified_methodology)
    source = _read(context, edition.source_url, "selected-rendition")
    announcement = _read(context, ANNOUNCEMENT, "announcement")
    announcement_text = _announcement(announcement)
    method = _read(context, METHOD, "methodology")
    require_reviewed_pdf(
        method,
        source_url=METHOD,
        source_sha256=PINS[METHOD],
        message="FlyersRights methodology differs from the reviewed complete original",
        trailer_window=1024,
    )
    observation = retain_qualified(
        method,
        qualified_methodology,
        retain_observations,
        source_sha256=PINS[METHOD],
        observations_sha256=QUALIFIED_SHA256,
        stage="flyersrights:2016:reviewed-methodology",
    )
    landing = source if edition == HTML_EDITION else _read(context, HTML, "publisher-rendition-links")
    html_headers, html_rows = _html(landing)
    if edition == HTML_EDITION:
        headers, rows, cells = html_headers, html_rows, None
        first_metric = 5
    else:
        headers, rows, cells = _workbook(source, edition)
        first_metric = 4
    reread = _read(context, edition.source_url, "selected-rendition-reread")
    if reread.body != source.body:
        raise ScorecardSourceError("FlyersRights selected rendition changed on reread")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="FlyersRights.org",
        parser_version=parser_version,
        rendition_rule="one exact original rendition supplies its own complete roster and values; other renditions never replace cells/1",
        homepage="https://flyersrights.org/",
    )
    bundle.use(source, "members", "values", "headers", "rendition-syntax")
    bundle.use(reread, "members", "values", "headers", "rendition-syntax", role="corroboration")
    bundle.use(announcement, "release-announcement", "period")
    bundle.use(method, "methodology")
    if landing is not source:
        bundle.use(landing, "publisher-rendition-links")
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text="2016",
        methodology_url=METHOD,
        timespan_text=PERIOD,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "announcement-retrospective",
                    "period_text": PERIOD,
                    "kind": "relative",
                    "source_path": ANNOUNCEMENT + "#.post-body",
                }
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        announcement,
        ".post-body",
        methodology_id="release-announcement",
        methodology_text=announcement_text,
        disclosure_status="literal original release announcement",
    )
    for page in facts["pages"]:
        bundle.add(
            "scorecard_methodologies",
            method,
            f"pdf:page={page['physical_page']};observation={observation};{page['source_path']}",
            methodology_id=key("methodology-page", str(page["physical_page"])),
            methodology_text=page["text"],
            methodology_url=METHOD,
            disclosure_status="complete privately reviewed original native page text",
        )
    mapped_cells = (
        set()
        if cells is None
        else {
            "A2",
            *(column(i) + "3" for i in range(1, len(headers) + 1)),
            *(column(i) + str(n) for i in range(1, len(headers) + 1) for n in range(4, WORKBOOK_END[source.url] + 1)),
        }
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "HTML/table[3]/tr[1]" if cells is None else "XLSX/Sheet1",
        methodology_id="rendition-syntax",
        methodology_text=json_column(
            {"header_cells": headers}
            if cells is None
            else {
                "title_text": cells["A2"].value,
                "header_cells": headers,
                "auxiliary_cells": {
                    coordinate: asdict(cell) for coordinate, cell in cells.items() if coordinate not in mapped_cells
                },
            }
        ),
        disclosure_status="literal title, headers and unmapped auxiliary cells; cached formulas never evaluated",
    )
    for i in range(first_metric, len(headers)):
        locator = f"HTML/table[3]/tr[1]/td[{i + 1}]" if cells is None else f"XLSX/Sheet1/{column(i + 1)}3"
        bundle.add(
            "scorecard_metrics",
            source,
            locator,
            metric_id=key("column", str(i + 1)),
            name=headers[i],
            chamber_text=edition.chamber,
            is_primary=None,
            periods_json="[]",
        )
    for n, row in enumerate(rows, 2 if cells is None else 4):
        committee, name = row[:2]
        party, state, chamber = (row[2], row[3], row[4]) if cells is None else (row[3], row[2], edition.chamber)
        match = re.fullmatch(r"([A-Z]{2})(?:\s*-\s*(\d+))?", state)
        if not match:
            raise ScorecardSourceError("FlyersRights literal state/district field changed shape")
        identity = key("literal-roster", chamber, state, name)
        locator = f"HTML/table[3]/tr[{n}]" if cells is None else f"XLSX/Sheet1/A{n}:{column(len(headers))}{n}"
        bundle.add(
            "scorecard_members",
            source,
            locator,
            publisher_member_key=identity,
            member_name=name,
            chamber_text=chamber,
            state=match[1],
            district=match[2],
            party=party,
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "committee_text": committee,
                    "state_district_text": state,
                    **({"committee_cell_present": "A" + str(n) in cells} if cells is not None else {}),
                }
            ),
        )
        for i in range(first_metric, len(headers)):
            coordinate = column(i + 1) + str(n)
            path = locator + f"/td[{i + 1}]" if cells is None else "XLSX/Sheet1/" + coordinate
            bundle.add(
                "scorecard_member_ratings",
                source,
                path,
                metric_id=key("column", str(i + 1)),
                publisher_member_key=identity,
                value_text="N/A" if row[i] == "n/a" else row[i],
                value_number=decimal_text(row[i]),
                value_status_text="N/A" if row[i] == "n/a" else None,
                notes_text=(json_column({"native_value_text": row[i]}) if row[i] == "n/a" else None)
                if cells is None
                else json_column(
                    {
                        "formula": cells[coordinate].formula,
                        "formula_attributes": cells[coordinate].formula_attributes,
                    }
                ),
            )
    return bundle.finish(
        "Exact publisher-linked 2016 retrospective rendition, full rectangular source roster and all literal component, "
        "total and grade cells; complete reviewed four-page methodology and original announcement retained; "
        "selected bytes agree on reread. Workbook member ranges follow their original summary formula; auxiliary "
        "cells and formula attributes remain separate. No official roster, roll calls, score calculation or exact start year inferred.",
        declared={"announcement_members": 535},
    )
