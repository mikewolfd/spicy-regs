"""The regional council's complete 2024 Congressional Scorecard issue grid."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key
from spicy_docs.sources.scorecards.qualified_observations import (
    RetainObservations,
    require_reviewed_pdf,
    retain_qualified,
)

parser_version = "carpenters-ncsrcc-qualified-grid/1"
PUBLISHER = "North Central States Regional Council of Carpenters"
URL = (
    "https://web.archive.org/web/20251121232831id_/https://northcountrycarpenter.org/sites/default/files/"
    "documents/2024%20Carpenter%20Economics%20_0.pdf"
)
SOURCE_SHA256 = "306d2222ac22bed1d6923097f84a60fbaaa607215721bfcea5f1b52cff100eb7"
QUALIFIED_SHA256 = "1ac728f2610b080f7e1a593187252cdd695f1bc3f1a563e36d1a22290496045d"
EDITION = ScorecardEdition(
    "carpenters_ncsrcc",
    "carpenter-economics-2024-regional",
    URL,
    "Congressional Scorecard",
    year="2024",
    is_current=False,
)
ITEMS = (
    ("Davis-Bacon", "red", 4),
    ("Inflation Reduction Act", "blue", 5),
    ("Infrastructure", "cyan", 6),
    ("CHIPS and Science ACT", "brown", 7),
    ("ACCESS Act (H.R. 7887)", "black", 9),
)
GROUP_ROWS = (7, 7, 10, 12)
MARKS = {"green_check", "red_cross", "blank"}
COMPLETENESS = (
    "The exact complete 13-page regional 2024 magazine contains the full Congressional Scorecard on physical "
    "page 12, printed pages 22–23, followed by the next article. All 36 source member occurrences, five issue "
    "descriptions and 168 printed cells, including 15 literal blanks, are retained. The last group prints four "
    "columns; no fifth-column cells are invented. Exact original bytes agree on reread. No aggregate score, "
    "blank meaning, congressional period or official action is inferred."
)


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=URL,
        source_sha256=SOURCE_SHA256,
        message="Regional Carpenters PDF differs from the reviewed complete original",
        trailer_window=1024,
    )


def _facts(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("Regional Carpenters requires the exact privately reviewed facts")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "reviewed-grids-private-pdf/1"
            or data["source_sha256"] != SOURCE_SHA256
            # This field records the old census assignment, not the emitted publisher identity.
            or data["assigned_publisher_id"] != "carpenters"
            or data["source_publisher_text"] != PUBLISHER
            or data["shape"] != "regional_issue_marks"
            or data["page_count"] != 13
            or [p["physical_page"] for p in data["native_pages"]] != list(range(1, 14))
            or any(type(p["physical_page"]) is not int for p in data["native_pages"])
            or set(data["native_blocks"]) != {"1", "2", "12", "13"}
            or data["title_text"] != EDITION.title
            or data["edition_label_text"] != "2024"
            or any(data[k] is not None for k in ("aggregate_score", "blank_meaning", "congress_text"))
            or data["source_declared_counts"] != {}
            or data["publisher_imprint"]["physical_page"] != 2
            or data["publisher_imprint"]["source_path"] != "PDF/page[2]/imprint"
            or PUBLISHER not in data["publisher_imprint"]["text"].replace("\n", " ")
        ):
            raise ValueError
        blocks = {}
        for page, entries in data["native_blocks"].items():
            if len({b["ordinal"] for b in entries}) != len(entries):
                raise ValueError
            for block in entries:
                if (
                    type(block["ordinal"]) is not int
                    or block["ordinal"] <= 0
                    or not isinstance(block["text"], str)
                    or not block["text"].strip()
                    or block["source_path"] != f"PDF/page[{page}]/native-block[{block['ordinal']}]"
                ):
                    raise ValueError
                blocks[(int(page), block["ordinal"])] = block
        if len(data["items"]) != len(ITEMS) or len(data["group_headers"]) != len(GROUP_ROWS):
            raise ValueError
        for ordinal, (item, (title, color, block)) in enumerate(zip(data["items"], ITEMS, strict=True), 1):
            if (
                type(item["column_ordinal"]) is not int
                or item["column_ordinal"] != ordinal
                or item["title_text"] != title
                or item["color"] != color
                or item["source_path"] != blocks[(12, block)]["source_path"]
                or not blocks[(12, block)]["text"].startswith(title + "\n")
            ):
                raise ValueError
        for group, header in enumerate(data["group_headers"], 1):
            if (
                type(header["group_ordinal"]) is not int
                or header["group_ordinal"] != group
                or header["colors"] != [i[1] for i in ITEMS[: 4 if group == 4 else 5]]
                or header["chamber_header_text"] is not None
            ):
                raise ValueError
        expected = {(g, r) for g, count in enumerate(GROUP_ROWS, 1) for r in range(1, count + 1)}
        members, identities = {}, set()
        for member in data["members"]:
            coordinate = member["group_ordinal"], member["row_ordinal"]
            identity = member["state_text"], member["label_text"]
            if (
                any(type(v) is not int for v in coordinate)
                or coordinate not in expected
                or coordinate in members
                or identity in identities
                or any(not isinstance(v, str) or not v.strip() for v in identity)
                or member["chamber_header_text"] is not None
                or member["chamber_context"] != ("Senate" if coordinate[0] == 4 else "House")
                or member["chamber_context_basis"] != "reviewed grid grouping, not a printed chamber heading"
                or member["source_path"] != f"PDF/page[12]/grid[{coordinate[0]}]/row[{coordinate[1]}]"
                or blocks[(12, member["label_native_block"])]["text"].strip() != member["label_text"]
            ):
                raise ValueError
            members[coordinate] = member
            identities.add(identity)
        if set(members) != expected:
            raise ValueError
        cells = set()
        for cell in data["cells"]:
            g, r, c = cell["group_ordinal"], cell["row_ordinal"], cell["column_ordinal"]
            coordinate = g, r, c
            if (
                any(type(v) is not int for v in coordinate)
                or (g, r) not in expected
                or c not in range(1, 5 if g == 4 else 6)
                or coordinate in cells
                or cell["mark"] not in MARKS
                or cell["value_text"] != ("" if cell["mark"] == "blank" else None)
                or cell["source_path"] != f"PDF/page[12]/grid[{g}]/row[{r}]/cell[{c}]"
            ):
                raise ValueError
            cells.add(coordinate)
        if len(cells) != 168 or sum(c["mark"] == "blank" for c in data["cells"]) != 15:
            raise ValueError
        if not blocks[(12, 3)]["text"].strip():
            raise ValueError
        return data, members, blocks
    except (KeyError, TypeError, ValueError, IndexError):
        raise ScorecardSourceError("Regional Carpenters facts do not establish the complete reviewed grid") from None


@dataclass(frozen=True, slots=True)
class CarpentersNcsrccReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        _facts(self.qualified_observations)
        _source(context.read(URL, stage="carpenters-ncsrcc:2024:list", hosts=("web.archive.org",)))
        return (EDITION,)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Regional Carpenters requires its named 2024 edition and private reviewed facts")
    data, members, blocks = _facts(qualified_observations)
    source = context.read(URL, stage="carpenters-ncsrcc:2024:original", hosts=("web.archive.org",))
    _source(source)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="carpenters-ncsrcc:2024:qualified-facts",
    )
    reread = context.read(URL, stage="carpenters-ncsrcc:2024:reread", hosts=("web.archive.org",))
    _source(reread)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=PUBLISHER,
        parser_version=parser_version,
        rendition_rule="regional publisher's complete named 2024 magazine grid; metric-free literal graphical observations/1",
        homepage="https://northcountrycarpenter.org/",
    )
    bundle.tables["scorecard_publishers"][0]["source_path"] = "PDF/page[2]/imprint"
    bundle.tables["scorecards"][0].update(edition_label_text="2024", publisher_edition_key=None, methodology_url=URL)
    bundle.use(source, "member_results", "members", "scored_items", "methodology")
    bundle.use(reread, "member_results", "members", "scored_items", "methodology", role="corroboration")

    def path(original):
        return f"pdf:page={original.split('[')[1].split(']')[0]};observation={observation};{original}"

    contexts = [("imprint", data["publisher_imprint"]["source_path"], json_column(data["publisher_imprint"]))]
    contexts += [
        (
            "grid-scope",
            blocks[(12, 3)]["source_path"],
            json_column(
                {
                    "source_text": blocks[(12, 3)]["text"],
                    "source_group_headers": data["group_headers"],
                    "aggregate_score": data["aggregate_score"],
                    "blank_meaning": data["blank_meaning"],
                }
            ),
        )
    ]
    contexts += [
        (
            key("issue", str(n)),
            blocks[(12, item[2])]["source_path"],
            json_column(
                {
                    "source_text": blocks[(12, item[2])]["text"],
                    "source_header": data["items"][n - 1],
                }
            ),
        )
        for n, item in enumerate(ITEMS, 1)
    ]
    for identity, locator, text in contexts:
        bundle.add(
            "scorecard_methodologies",
            source,
            path(locator),
            methodology_id=identity,
            methodology_text=text,
            methodology_url=URL,
            disclosure_status="literal selected original imprint or issue prose; no disclosed grid formula or blank meaning",
        )
    for ordinal, item in enumerate(data["items"], 1):
        references = []
        if ordinal == 5:
            references.append(
                {
                    "occurrence_id": "heading-bill",
                    "citation_text": "H.R. 7887",
                    "kind": "bill",
                    "bill_citation_text": "H.R. 7887",
                    "source_path": path(item["source_path"]),
                }
            )
            references.append(
                {
                    "occurrence_id": "paragraph-bill",
                    "citation_text": "H.R.7887",
                    "kind": "bill",
                    "bill_citation_text": "H.R.7887",
                    "source_path": path(item["source_path"]),
                }
            )
        bundle.add(
            "scorecard_items",
            source,
            path(item["source_path"]),
            item_id=key("issue", str(ordinal)),
            title=item["title_text"],
            bill_citation_text="H.R. 7887" if ordinal == 5 else None,
            references_json=json_column(references),
        )
    for member in data["members"]:
        identity = key("native-name-state", member["state_text"], member["label_text"])
        bundle.add(
            "scorecard_members",
            source,
            path(member["source_path"]),
            publisher_member_key=identity,
            member_name=member["label_text"],
            state=member["state_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "literal_label": member["label_text"],
                    "label_native_block": member["label_native_block"],
                    "reviewed_chamber_context": member["chamber_context"],
                    "reviewed_chamber_context_basis": member["chamber_context_basis"],
                }
            ),
        )
    for cell in data["cells"]:
        member = members[(cell["group_ordinal"], cell["row_ordinal"])]
        bundle.add(
            "scorecard_member_item_results",
            source,
            path(cell["source_path"]),
            item_id=key("issue", str(cell["column_ordinal"])),
            result_id="native-graphic-cell",
            publisher_member_key=key("native-name-state", member["state_text"], member["label_text"]),
            result_text="" if cell["mark"] == "blank" else cell["mark"],
        )
    return bundle.finish(COMPLETENESS, declared=data["source_declared_counts"])
