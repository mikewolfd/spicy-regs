"""ASCF's separately selected original chamber grids and privately reviewed facts.

Only the two named captures are supported. The dated actions establish the
selection's human label, not a published edition year or an inferred Congress.
Historical ASC succession and other editions remain outside this reader.
"""

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar, TypedDict

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from .qualified_observations import RetainObservations, require_reviewed_pdf, retain_qualified

parser_version = "ascf-named-2010-qualified-originals/1"
PUBLISHER = "American Security Council Foundation"
PUBLISHER_ID = "american_security_council_foundation"
HOSTS = ("web.archive.org",)


class _Source(TypedDict):
    url: str
    source_sha256: str
    facts_sha256: str
    members: int
    title: str
    asset_chamber: str
    chamber: str
    metrics: list[str]
    positions: list[str]


SOURCES: dict[str, _Source] = {
    "house": {
        "url": "https://web.archive.org/web/20120125114210id_/http://www.ascfusa.org/files/fckfiles/House_Votes_ASCF.pdf",
        "source_sha256": "700b016dccc35695044b9d0a639d799146c6fb3709b1ba7996741374a4560b72",
        "facts_sha256": "c6249ae42d81768fb76d824751a5ea2e210178576dce0fefaedd6e7cda071619",
        "members": 437,
        "title": "HOUSE VOTES",
        "asset_chamber": "HOUSE OF REPRESENTATIVES",
        "chamber": "HOUSE OF REPRESENTATIVES",
        "metrics": ["+", "Score"],
        "positions": ["+", "-", "-", "-", "+", "-", "-", "-", "-", "-"],
    },
    "senate": {
        "url": "https://web.archive.org/web/20120125110853id_/http://www.ascfusa.org/files/fckfiles/Senate_Votes_ASCF.pdf",
        "source_sha256": "53f85a3838e06d5a1fe2d1d46da53d9eb3db63070b4bdb5eb6cee5b273228eba",
        "facts_sha256": "0801bff0d5ff53af60039a323dbee6c546d3e7f0f42df67b4024d8e74e0027a1",
        "members": 103,
        "title": "SENATE VOTES",
        "asset_chamber": "SENATE",
        "chamber": "U.S. SENATE",
        "metrics": ["+", "-", "Score"],
        "positions": ["-", "-", "-", "+", "+", "-", "+", "+", "+", "-"],
    },
}
EDITIONS = tuple(
    ScorecardEdition(
        PUBLISHER_ID,
        "named-2010-" + tag + "-original",
        source["url"],
        source["title"],
        chamber=source["chamber"],
        is_current=False,
    )
    for tag, source in SOURCES.items()
)
KEYS = list(map(str, range(1, 11)))
CAPTION = re.compile(r"(?P<name>.+)\(\s*(?P<party>[RDI])-(?P<state>[A-Z]{2})(?P<district>[^)]*)\)")
LOCATOR = re.compile(r"PDF/page\[[12]\]/native/block\[[1-9][0-9]*\](?:/pixel/[^\s]+)?")


def list_scorecards(context):
    """Return only the separately selected archived originals; no live discovery."""
    return EDITIONS


def _source(document, selected):
    require_reviewed_pdf(
        document,
        source_url=selected["url"],
        source_sha256=selected["source_sha256"],
        message="ASCF original PDF differs from the complete reviewed capture",
    )
    if document.response.content_type != "application/pdf":
        raise ScorecardSourceError("ASCF original PDF content type changed")


def _string(value, *, empty=False):
    if not isinstance(value, str) or (not empty and not value):
        raise ValueError


def _locator(value):
    _string(value)
    if not LOCATOR.fullmatch(value):
        raise ValueError


def _facts(body, selected):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != selected["facts_sha256"]:
        raise ScorecardSourceError("ASCF requires the exact privately reviewed semantic asset")
    try:
        data = json.loads(body)
        if (
            data["source_sha256"] != selected["source_sha256"]
            or data["publisher_text"] != PUBLISHER
            or data["title_text"] != selected["title"]
            or data["chamber_text"] != selected["asset_chamber"]
            or data["year_text"] != "2010"
            or any(data[name] is not None for name in ("congress_text", "session_text", "published_at_text"))
            or len(data["members"]) != selected["members"]
            or [a["publisher_item_key_text"] for a in data["actions"]] != KEYS
            or [p["publisher_item_key_text"] for p in data["publisher_positions"]] != KEYS
            or [p["value_text"] for p in data["publisher_positions"]] != selected["positions"]
            or [m["metric_label_text"] for m in data["metrics"]] != selected["metrics"]
        ):
            raise ValueError
        for action in data["actions"]:
            description = action["description_text"]
            _string(description)
            _locator(action["source_locator"])
            date = re.search(r"\((\d\d/\d\d/2010)", description)
            roll = re.search(r"Roll Call No\. (\d+)", description)
            position = re.search(r"ASCF position correct vote was ([^.]+)", description)
            if date is None or roll is None or position is None:
                raise ValueError
            if (
                action["source_action_key_text"] != action["publisher_item_key_text"] + "."
                or action["item_date_text"] != date[1]
                or action["roll_number_text"] != roll[1]
                or action["publisher_position_text"] != position[1]
                or any(action[name] is not None for name in ("congress_text", "session_text"))
                or not action["description_source_paths"]
            ):
                raise ValueError
            for locator in action["description_source_paths"]:
                _locator(locator)
            for reference in action["references"]:
                _string(reference["citation_text"])
                if reference["citation_text"] not in description or reference["kind_text"] is not None:
                    raise ValueError
        for record in [*data["metrics"], *data["publisher_positions"]]:
            _locator(record["source_path"])
        positions = set()
        wraps = 0
        for member in data["members"]:
            _string(member["member_label_text"])
            _string(member["state_heading_text"])
            _locator(member["source_locator"])
            _locator(member["state_heading_source_path"])
            if (
                not CAPTION.fullmatch(member["member_label_text"])
                or member["source_locator"] in positions
                or list(member["results"]) != KEYS
                or list(member["result_source_paths"]) != KEYS
                or [r["metric_label_text"] for r in member["published_ratings"]] != selected["metrics"]
                or set(member["printed_metric_source_paths"]) != set(selected["metrics"])
            ):
                raise ValueError
            positions.add(member["source_locator"])
            for mark, locator in zip(member["results"].values(), member["result_source_paths"].values(), strict=True):
                if mark not in {"+", "-", "NA", "NV", "P", ""}:
                    raise ValueError
                _locator(locator)
            for rating in member["published_ratings"]:
                value, label = rating["value_text"], rating["metric_label_text"]
                _string(value, empty=True)
                _locator(member["printed_metric_source_paths"][label])
                if (
                    (label == "Score" and not re.fullmatch(r"\d+%", value))
                    or (label == "+" and value and not value.isdecimal())
                    or (label == "-" and value != "")
                ):
                    raise ValueError
            if member.get("raw_wrap_text") is not None:
                if member["raw_wrap_text"] != "NANA" or [member["results"][k] for k in ("1", "2")] != ["", ""]:
                    raise ValueError
                _locator(member["raw_wrap_source_path"])
                _string(member["interpretation_notes"])
                wraps += 1
            elif "" in member["results"].values():
                raise ValueError
        if wraps != (3 if selected["asset_chamber"] == "SENATE" else 0):
            raise ValueError
        contexts = data["source_contexts"]
        for context in contexts:
            _string(context["kind_text"])
            _string(context["text"])
            _locator(context["source_path"])
        if (
            sum(c["kind_text"] == "source legend" for c in contexts) != 2
            or not any("110th Congress" in c["text"] for c in contexts)
            or not any(PUBLISHER in c["text"] for c in contexts)
            or not any(
                c["kind_text"] == "source page1 heading" and c["text"].strip() == selected["chamber"] for c in contexts
            )
        ):
            raise ValueError
        for note in data["interpretation_notes"]:
            _string(note)
        return data
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        raise ScorecardSourceError("ASCF semantic facts do not establish the complete reviewed original") from None


@dataclass(frozen=True, slots=True)
class ASCFReader:
    """Bind one pinned chamber asset and the existing private retention callback."""

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        for edition, selected in zip(EDITIONS, SOURCES.values(), strict=True):
            if sha256(self.qualified_observations).hexdigest() == selected["facts_sha256"]:
                _facts(self.qualified_observations, selected)
                return (edition,)
        raise ScorecardSourceError("ASCF requires one named reviewed chamber asset")

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition not in EDITIONS or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("ASCF requires a named chamber original and private reviewed facts")
    selected = SOURCES["house" if edition.edition_id == EDITIONS[0].edition_id else "senate"]
    data = _facts(qualified_observations, selected)
    source = context.read(edition.source_url, stage="ascf:original", hosts=HOSTS)
    _source(source, selected)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=selected["source_sha256"],
        observations_sha256=selected["facts_sha256"],
        stage="ascf:reviewed-facts",
    )
    reread = context.read(edition.source_url, stage="ascf:original-reread", hosts=HOSTS)
    _source(reread, selected)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=PUBLISHER,
        parser_version=parser_version,
        rendition_rule="one exact separately selected archived chamber PDF and pinned reviewed literal facts/1",
        homepage="http://www.ascfusa.org/",
    )
    bundle.use(source, "members", "results", "items", "metrics", "context")
    bundle.use(reread, "members", "results", "items", "metrics", "context", role="corroboration")

    def path(original):
        return f"pdf:page={original.split('[')[1].split(']')[0]};observation={observation};{original}"

    legend = next(c for c in data["source_contexts"] if c["kind_text"] == "source legend")
    bundle.tables["scorecard_publishers"][0].update(
        abbreviation="ASCF",
        aliases_json=json_column(["ASCF"]),
        source_path=path(legend["source_path"]),
    )
    heading = next(c for c in data["source_contexts"] if c["kind_text"] == "source heading" and "Votes" in c["text"])
    bundle.tables["scorecards"][0].update(
        series_id=PUBLISHER_ID + ":voter_index",
        publisher_edition_key=None,
        edition_label_text=None,
        methodology_url=edition.source_url,
        source_path=path(heading["source_path"]),
    )
    for n, record in enumerate(data["source_contexts"], 1):
        if record["kind_text"] == "printed metric header":
            continue  # This literal header is already retained by its metric row.
        text = record["text"]
        if record["kind_text"] == "publisher position header":
            text = json_column({"header_text": text, "positions": data["publisher_positions"]})
        bundle.add(
            "scorecard_methodologies",
            source,
            path(record["source_path"]),
            methodology_id=key("source-context", str(n)),
            methodology_text=text,
            methodology_url=edition.source_url,
            disclosure_status="literal original "
            + record["kind_text"]
            + "; no scoring formula or historical ASC continuity inferred",
        )
    for metric in data["metrics"]:
        bundle.add(
            "scorecard_metrics",
            source,
            path(metric["source_path"]),
            metric_id=key("printed-column", metric["metric_label_text"]),
            name=metric["metric_label_text"],
            chamber_text=edition.chamber,
        )
    for action in data["actions"]:
        identity = key("action", action["publisher_item_key_text"])
        bundle.add(
            "scorecard_items",
            source,
            path(action["source_locator"]),
            item_id=identity,
            publisher_item_id=action["source_action_key_text"],
            title=action["description_text"],
            item_date_text=action["item_date_text"],
            roll_number_text=action["roll_number_text"],
            chamber_text=edition.chamber,
            publisher_position_text=action["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path(action["source_locator"]),
            references_json=json_column(
                [
                    {
                        "occurrence_id": str(n),
                        "kind": "source-reference",
                        "citation_text": r["citation_text"],
                        "source_path": path(action["source_locator"]),
                    }
                    for n, r in enumerate(action["references"], 1)
                ]
            ),
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path(action["source_locator"]),
            methodology_id=key("action-syntax", identity),
            methodology_text=json_column(
                {
                    "source_action_key_text": action["source_action_key_text"],
                    "description_source_paths": action["description_source_paths"],
                }
            ),
            disclosure_status="literal original paragraph key and native continuation locators; prose is retained in the item",
        )
    for member in data["members"]:
        identity = key("native-occurrence", member["source_locator"])
        caption = CAPTION.fullmatch(member["member_label_text"])
        if caption is None:
            raise ScorecardSourceError("ASCF semantic facts do not establish the complete reviewed original")
        notes = {
            "raw_label_text": member["member_label_text"],
            "state_heading_source_path": member["state_heading_source_path"],
        }
        for name in ("raw_wrap_text", "raw_wrap_source_path", "interpretation_notes"):
            if name in member:
                notes[name] = member[name]
        bundle.add(
            "scorecard_members",
            source,
            path(member["source_locator"]),
            publisher_member_key=identity,
            member_name=caption["name"],
            party=caption["party"],
            state=caption["state"],
            district=caption["district"] or None,
            chamber_text=edition.chamber,
            identifiers_json="[]",
            notes_text=json_column(notes),
        )
        for rating in member["published_ratings"]:
            bundle.add(
                "scorecard_member_ratings",
                source,
                path(member["printed_metric_source_paths"][rating["metric_label_text"]]),
                publisher_member_key=identity,
                metric_id=key("printed-column", rating["metric_label_text"]),
                value_text=rating["value_text"],
                value_number=decimal_text(rating["value_text"]),
            )
        for item_key, mark in member["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                path(member["result_source_paths"][item_key]),
                publisher_member_key=identity,
                item_id=key("action", item_key),
                result_id="literal-keyed-cell",
                result_text=mark,
            )
    return bundle.finish(
        "Complete only for the named archived chamber original and its exact reviewed asset. All "
        + str(selected["members"])
        + " source member occurrences, ten actions, ten keyed cells per occurrence, "
        "printed metric columns, target marks, full legends and paragraph context pass pinned shape checks. "
        "Exact original PDF bytes and URL agree on full reread. NANA remains unresolved name-area context "
        "with keyed columns1/2 empty; P and empty totals/minus cells stay literal. No score, formula, "
        "Congress, session, edition year or official member/action identity is inferred.",
    )
