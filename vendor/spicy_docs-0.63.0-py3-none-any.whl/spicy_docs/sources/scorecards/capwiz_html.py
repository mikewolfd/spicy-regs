"""Observed Capwiz DOM and item syntax, with explicit publisher-owned scopes.

Publisher readers supply the selected original, period, population, action legend
and grid rules. These helpers neither discover publishers nor choose editions.
"""

import re
from collections import Counter
from copy import deepcopy
from urllib.parse import parse_qs, urlsplit

from bs4 import Comment, NavigableString

from .common import ScorecardSourceError

ITEM = re.compile(r"(.+) \((\d{2}/\d{2}/\d{4}), Roll Call No\. (\d+)\)")


CITATIONS = {
    "bill": re.compile(r"H\.R\. \d+|S\. \d+"),
    "amendment": re.compile(r"(?:Amdt\.?|Amendment) (?:No\. )?\d+"),
}


def text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def authored_children(node, allowed, *, publisher):
    for child in node.children:
        if isinstance(child, Comment):
            continue
        if isinstance(child, NavigableString):
            if str(child).strip():
                raise ScorecardSourceError(publisher + " structural container has unreviewed authored text")
        elif child.name not in allowed:
            raise ScorecardSourceError(publisher + " structural container has unreviewed child content")
    return node.find_all(recursive=False)


def native(node, path):
    retained = deepcopy(node)
    for comment in retained.find_all(string=lambda value: isinstance(value, Comment)):
        comment.extract()
    # No output encoding is selected for retained source markup. BeautifulSoup's
    # default serialization otherwise rewrites source charset metadata to UTF-8.
    return {
        "source_path": path,
        "text": text(node),
        "attributes": dict(node.attrs),
        "html": retained.decode(eventual_encoding=None),
    }


def header(row, path, cells):
    ordinals = Counter()
    retained = []
    for cell in cells:
        ordinals[cell.name] += 1
        retained.append(native(cell, path + "/" + cell.name + "[" + str(ordinals[cell.name]) + "]"))
    return {**native(row, path), "cells": retained}


def _relative_path(node, container):
    parts = []
    while node is not container:
        siblings = node.parent.find_all(node.name, recursive=False)
        index = next(n for n, sibling in enumerate(siblings, 1) if sibling is node)
        parts.append(node.name + "[" + str(index) + "]")
        node = node.parent
    return "/" + "/".join(reversed(parts))


def items(
    dl,
    chamber,
    congress,
    ordinal,
    expected,
    *,
    publisher,
    detail_in_span=False,
    sessions=("2",),
    leading_description_anchor=False,
    detail_in_paragraph=False,
    contextual_links=False,
    route_prefix="",
):
    """Read observed item syntax; each departure from the legacy shape is caller-selected.

    NOW uses combined sessions, a leading description anchor, paragraph-wrapped
    2006 descriptions and contextual links. Defaults retain DAV/Teamsters rules.
    A literal route prefix is checked and removed only for query validation; the
    original href is retained unchanged.
    """
    children = authored_children(
        dl, {"dt", "dd", "a"} if leading_description_anchor else {"dt", "dd"}, publisher=publisher
    )
    if leading_description_anchor:
        if (
            not children
            or children[0].name != "a"
            or children[0].attrs != {"name": "descriptions"}
            or text(children[0])
            or children[0].find()
        ):
            raise ScorecardSourceError(publisher + " leading description anchor changed")
        children = children[1:]
    if [c.name for c in children] != ["dt", "dd"] * expected:
        raise ScorecardSourceError(publisher + " complete key-vote explanation inventory changed")
    items = []
    for n in range(expected):
        dt, dd = children[n * 2 : n * 2 + 2]
        path = "(//dl[@id='keyvotes'])[" + str(ordinal) + "]"
        title_text = text(dt)
        number = str(n + 1)
        match = ITEM.fullmatch(title_text.removeprefix(number + ". "))
        links = dd.select("a[href]")
        details = [link for link in links if text(link) == "More"]
        if (
            not title_text.startswith(number + ". ")
            or not match
            or len(details) != 1
            or (not contextual_links and len(links) != 1)
        ):
            raise ScorecardSourceError(publisher + " item title, literal date, roll or detail link changed")
        title, date, roll = match.groups()
        link = details[0]
        if detail_in_span:
            parent = link.parent
            if (
                parent.name != "span"
                or parent.parent is not dd
                or authored_children(parent, {"a"}, publisher=publisher) != [link]
            ):
                raise ScorecardSourceError(publisher + " detail link left the observed direct span")
            span_ordinal = dd.find_all("span", recursive=False).index(parent) + 1
            link_path = "/span[" + str(span_ordinal) + "]/a/@href"
        elif detail_in_paragraph:
            if link.parent.name != "p" or link.parent.parent is not dd:
                raise ScorecardSourceError(publisher + " detail link left the observed direct paragraph")
            link_path = _relative_path(link, dd) + "/@href"
        else:
            if link.parent is not dd:
                raise ScorecardSourceError(publisher + " detail link left the observed direct description")
            link_path = "/a/@href"
        href = link["href"]
        if not href.startswith(route_prefix):
            raise ScorecardSourceError(publisher + " native item route left the observed literal prefix")
        route = urlsplit(href[len(route_prefix) :])
        query = parse_qs(route.query, keep_blank_values=True)
        if (
            route.scheme
            or route.netloc
            or route.path != "vote.xc"
            or set(query) != {"votenum", "chamber", "congress", "voteid", "state"}
            or any(len(v) != 1 for v in query.values())
            or query["votenum"] != [roll]
            or query["congress"][0] not in {congress + session for session in sessions}
            or query["chamber"] != ["H" if chamber == "house" else "S"]
            or query["state"] != ["US"]
            or not re.fullmatch(r"\d+", query["voteid"][0])
        ):
            raise ScorecardSourceError(publisher + " native item route conflicts with the named period or title")
        refs = [
            {
                "occurrence_id": "native-detail-link",
                "kind": "publisher_item",
                "citation_text": href,
                "source_path": path + "/dd[" + number + "]" + link_path,
            },
            {
                "occurrence_id": "title-roll",
                "kind": "roll_call",
                "citation_text": "Roll Call No. " + roll,
                "roll_number_text": roll,
                "congress_text": congress,
                "session_text": query["congress"][0][len(congress) :],
                "chamber_text": chamber,
                "source_path": path + "/dt[" + number + "]",
            },
        ]
        retained_links = []
        if contextual_links:
            for occurrence, anchor in enumerate(links, 1):
                anchor_path = path + "/dd[" + number + "]" + _relative_path(anchor, dd)
                role = "scored-item-detail" if anchor is link else "contextual-reference"
                retained_links.append({**native(anchor, anchor_path), "role": role})
                if anchor is not link:
                    refs.append(
                        {
                            "occurrence_id": "contextual-link-" + str(occurrence),
                            "kind": "publisher_context",
                            "citation_text": anchor["href"],
                            "source_path": anchor_path + "/@href",
                        }
                    )
        for field, node in (("title", dt), ("description", dd)):
            for kind, pattern in CITATIONS.items():
                for occurrence, citation in enumerate(pattern.finditer(text(node)), 1):
                    refs.append(
                        {
                            "occurrence_id": field + "-" + kind + "-" + str(occurrence),
                            "kind": kind,
                            "citation_text": citation.group(),
                            "source_path": path + ("/dt[" if field == "title" else "/dd[") + number + "]",
                        }
                    )
        item = {
            "title": title,
            "title_text": title_text,
            "date": date,
            "roll": roll,
            "publisher_id": query["voteid"][0],
            "href": href,
            "references": refs,
            "path": path + "/dt[" + number + "]",
            "description_path": path + "/dd[" + number + "]",
            "description": text(dd),
            "title_html": str(dt),
            "description_html": str(dd),
        }
        if sessions != ("2",) or contextual_links:
            item["session"] = query["congress"][0][len(congress) :]
        if contextual_links:
            item["links"] = retained_links
        items.append(item)
    return items
