"""NAIFA's named Frontline selected Senate action; historical Voting Report stays unrecovered."""

import re
from copy import deepcopy

from spicy_docs.schemas.tables import json_column

from .capwiz_html import authored_children, native, text
from .common import Bundle, ScorecardContext, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "life-underwriters-naifa-frontline-selected-html/2"
PUBLISHER = "National Association of Insurance and Financial Advisors"
EDITION_ID = "naifa-frontline-2005-02-15-s5-selected-senate-action"
PUBLICATION_DATE = "February 15, 2005"
ISSUE_LABEL = "Volume 3, No. 4"
ARTICLE_TITLE = "Mission Accomplished: Class Action Reform Passes Senate"
ITEM_TITLE = "Class Action Fairness Act (S.5)"
POSITION = "NAIFA has long supported this effort"
HOSTS = ("web.archive.org",)
ARCHIVE = "https://web.archive.org/web/"
ORIGIN = "http://www.naifa.org/frontline/"
SOURCES = {
    "issue": (
        ARCHIVE + "20050429042242id_/" + ORIGIN + "20050215_nfl.html",
        ARCHIVE + "20050429065821id_/" + ORIGIN + "20050215_nfl.html",
        "NAIFA Frontline February 15, 2005",
        2,
    ),
    "article": (
        ARCHIVE + "20050429042242id_/" + ORIGIN + "20050215_nfl_1.html",
        ARCHIVE + "20050429065739id_/" + ORIGIN + "20050215_nfl_1.html",
        "NAIFA Frontline: February 15, 2005",
        1,
    ),
    "votes": (
        ARCHIVE + "20050429042242id_/http://www.naifa.org:80/frontline/classactionvote.html",
        ARCHIVE + "20050429042242id_/http://www.naifa.org:80/frontline/classactionvote.html",
        "NAIFA Frontline: February 15, 2005",
        1,
    ),
}
# The named original explicitly declares these selected-action subtotals. They
# establish its published scope, not an independently reconstructed Senate roll.
GROUP_COUNTS = {"YEAs": 72, "NAYs": 26, "Not Voting": 2}
MEMBER = re.compile(r"(.+) \(([RDI])-([A-Z]{2})\)")


def edition(edition_id):
    if edition_id != EDITION_ID:
        raise ScorecardSourceError(
            "NAIFA edition is outside the named Frontline selected action; historical Voting Report remains unsupported"
        )
    return ScorecardEdition(
        "life_underwriters",
        EDITION_ID,
        SOURCES["issue"][0],
        "NAIFA Frontline: " + PUBLICATION_DATE + ", " + ISSUE_LABEL + " — selected S.5 Senate action",
        year="2005",
        chamber="senate",
        is_current=False,
    )


def list_scorecards(context: ScorecardContext):
    return (edition(EDITION_ID),)


def _path(node):
    parts = []
    while node.name != "[document]":
        siblings = node.parent.find_all(node.name, recursive=False)
        ordinal = next(n for n, sibling in enumerate(siblings, 1) if sibling is node)
        parts.append(node.name + "[" + str(ordinal) + "]")
        node = node.parent
    return "/" + "/".join(reversed(parts))


def _children(node, allowed):
    return authored_children(node, allowed, publisher="NAIFA Frontline")


def _one(nodes, message):
    if len(nodes) != 1:
        raise ScorecardSourceError("NAIFA " + message + " is missing or repeated")
    return nodes[0]


def _html(document, role):
    requested, resolved, title, body_count = SOURCES[role]
    if document.response.requested_url != requested or document.url != resolved:
        raise ScorecardSourceError("NAIFA archive custody escaped the selected original request/response")
    if (
        not document.body.rstrip().lower().endswith(b"</html>")
        or "html" not in (document.response.content_type or "").lower()
    ):
        raise ScorecardSourceError("NAIFA original HTML is incomplete or the format changed")
    html = soup(document)
    if (
        len(html.select("html")) != 1
        or len(html.select("body")) != body_count
        or text(_one(html.select("title"), "document title")) != title
    ):
        raise ScorecardSourceError("NAIFA Frontline original document identity changed")
    _one(html.select('img[alt="NAIFA Frontline"]'), "Frontline masthead")
    _one(html.select('img[alt="NAIFA"]'), "source publisher masthead")
    if PUBLISHER + ", 2901 Telestar Court, Falls Church, VA 22042" not in text(html.body):
        raise ScorecardSourceError("NAIFA source-time publisher attribution changed")
    dates = html.body.find_all(string=lambda value: value and " ".join(value.split()) == PUBLICATION_DATE)
    issues = html.body.find_all(string=lambda value: value and " ".join(value.split()) == ISSUE_LABEL)
    _one(dates, "publication date")
    _one(issues, "issue label")
    return html, _path(dates[0].parent), _path(issues[0].parent)


def _context(html, document, role):
    body = deepcopy(html.body)
    separate_paths = []
    if role == "votes":
        separate_paths.append(_path(_one(html.select('table[width="471"]'), "selected-action table")))
        _one(body.select('table[width="471"]'), "selected-action table").decompose()
    elif role == "article":
        heading = _one(html.select("h3"), "article heading")
        nodes = [heading, *heading.parent.find_all("p", recursive=False)]
        separate_paths = [_path(node) for node in nodes]
        retained_heading = _one(body.select("h3"), "article heading")
        for node in [retained_heading, *retained_heading.parent.find_all("p", recursive=False)]:
            node.decompose()
    return {
        "head": native(html.head, _path(html.head)),
        "body": native(body, _path(html.body)),
        "separately_retained_source_paths": separate_paths,
        "source_custody": {
            "requested_archive_url": document.response.requested_url,
            "resolved_archive_url": document.url,
            "source_role": role,
        },
    }


def _facts(document, role):
    html, date_path, issue_path = _html(document, role)
    facts = {"date_path": date_path, "issue_path": issue_path}
    if role == "issue":
        link = _one(html.select('a[href="20050215_nfl_1.html"]'), "selected article link")
        if text(link) != "click here to read more" or ARTICLE_TITLE not in text(html.body):
            raise ScorecardSourceError("NAIFA issue no longer identifies the selected article")
        facts["article_link"] = native(link, _path(link))
    elif role == "article":
        heading = _one(html.select("h3"), "article heading")
        if text(heading) != ARTICLE_TITLE:
            raise ScorecardSourceError("NAIFA selected article heading changed")
        paragraphs = heading.parent.find_all("p", recursive=False)
        if len(paragraphs) != 7:
            raise ScorecardSourceError("NAIFA complete original article paragraph inventory changed")
        first = text(paragraphs[0])
        witness = (
            ITEM_TITLE
            + " passed the Senate on February 10 by a vote of "
            + str(GROUP_COUNTS["YEAs"])
            + " to "
            + str(GROUP_COUNTS["NAYs"])
            + "."
        )
        if witness not in first or first.count(POSITION) != 1:
            raise ScorecardSourceError(
                "NAIFA article date, selected-action counts or explicit preferred action changed"
            )
        link = _one(
            paragraphs[0].select('a[href="http://www.naifa.org/frontline/classactionvote.html"]'),
            "selected vote-list link",
        )
        if text(link) != "www.naifa.org/frontline/classactionvote.html":
            raise ScorecardSourceError("NAIFA article's selected vote-list label changed")
        facts.update(
            heading=native(heading, _path(heading)),
            paragraphs=[native(node, _path(node)) for node in paragraphs],
            position_path=_path(paragraphs[0]),
            vote_link=native(link, _path(link)),
        )
    else:
        heading = _one(html.select("h3"), "selected vote heading")
        if text(heading) != ARTICLE_TITLE:
            raise ScorecardSourceError("NAIFA selected vote publication heading changed")
        table = _one(html.select('table[width="471"]'), "complete selected-action table")
        rows = _children(table, {"tr"})
        if len(rows) != 2:
            raise ScorecardSourceError("NAIFA selected-action table row inventory changed")
        title_cells = _children(rows[0], {"td"})
        cells = _children(rows[1], {"td"})
        if len(title_cells) != 1 or text(title_cells[0]) != ITEM_TITLE or len(cells) != 2:
            raise ScorecardSourceError("NAIFA selected item title or group columns changed")
        if [node.name for node in _children(cells[0], {"p", "ul"})] != ["p", "ul"] or [
            node.name for node in _children(cells[1], {"p", "ul"})
        ] != ["p", "ul", "p", "ul"]:
            raise ScorecardSourceError("NAIFA authored vote-group structure changed")
        groups, members = [], []
        for group, cell, slot in [("YEAs", cells[0], 0), ("NAYs", cells[1], 0), ("Not Voting", cells[1], 1)]:
            heading = cell.find_all("p", recursive=False)[slot]
            listing = cell.find_all("ul", recursive=False)[slot]
            group_heading = group + (" - " if group == "Not Voting" else " — ") + str(GROUP_COUNTS[group])
            if text(heading) != group_heading:
                raise ScorecardSourceError("NAIFA native selected-action group/count statement changed")
            nodes = _children(listing, {"li"})
            if len(nodes) != GROUP_COUNTS[group]:
                raise ScorecardSourceError("NAIFA source-declared group count does not match every member occurrence")
            groups.append(
                {
                    "name": group,
                    "heading": native(heading, _path(heading)),
                    "list_attributes": dict(listing.attrs),
                    "list_path": _path(listing),
                    "cell_attributes": dict(cell.attrs),
                    "cell_path": _path(cell),
                }
            )
            for ordinal, node in enumerate(nodes, 1):
                fonts = _children(node, {"font"})
                if len(fonts) != 1 or fonts[0].find():
                    raise ScorecardSourceError("NAIFA member label has unreviewed nested content")
                label = text(node)
                match = MEMBER.fullmatch(label)
                if not match:
                    raise ScorecardSourceError("NAIFA member's literal surname/party/state syntax changed")
                members.append(
                    {
                        "name": match[1],
                        "party": match[2],
                        "state": match[3],
                        "label": label,
                        "group": group,
                        "group_heading": group_heading,
                        "group_ordinal": str(ordinal),
                        "occurrence": str(len(members) + 1),
                        "native": native(node, _path(node)),
                    }
                )
        if len(html.select("li")) != len(members):
            raise ScorecardSourceError("NAIFA selected member inventory escaped the complete source groups")
        pdf = _one(html.select('a[href="../pdf/classactionvote.pdf"]'), "advertised vote PDF")
        facts.update(
            members=members,
            groups=groups,
            table_attributes=dict(table.attrs),
            table_path=_path(table),
            rows_attributes=[dict(row.attrs) for row in rows],
            item_title=native(title_cells[0], _path(title_cells[0])),
            pdf_link=native(pdf, _path(pdf)),
        )
    facts["context"] = _context(html, document, role)
    return facts


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition(selected.edition_id):
        raise ScorecardSourceError("NAIFA selected edition metadata conflicts with the named Frontline action")
    documents, facts, repeats = {}, {}, {}
    for role in SOURCES:
        documents[role] = context.read(SOURCES[role][0], stage="naifa-frontline:" + role + "-original", hosts=HOSTS)
        facts[role] = _facts(documents[role], role)
    for role in SOURCES:
        repeats[role] = context.read(SOURCES[role][0], stage="naifa-frontline:" + role + "-reread", hosts=HOSTS)
        if _facts(repeats[role], role) != facts[role]:
            raise ScorecardSourceError("NAIFA complete original source facts changed on reread")
    issue, article, votes = (documents[role] for role in SOURCES)
    bundle = Bundle(
        selected,
        context,
        issue,
        publisher_name=PUBLISHER,
        parser_version=parser_version,
        rendition_rule="named-naifa-frontline-selected-action-original-html",
        homepage="http://www.naifa.org/",
    )
    bundle.tables["scorecards"][0].update(
        series_id=key("life_underwriters", "naifa-frontline-selected-actions"),
        edition_label_text=PUBLICATION_DATE + " " + ISSUE_LABEL,
        publisher_name_text=PUBLISHER,
        source_path=facts["issue"]["date_path"],
        published_at_text=PUBLICATION_DATE,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "issue-publication-date",
                    "kind": "explicit",
                    "period_text": PUBLICATION_DATE,
                    "year_text": "2005",
                    "source_path": facts["issue"]["date_path"],
                }
            ]
        ),
    )
    for role in SOURCES:
        groups = {
            "issue": ("edition", "issue-context"),
            "article": ("item", "preferred-action", "article-context"),
            "votes": ("members", "results", "vote-list-context"),
        }[role]
        bundle.use(documents[role], *groups)
        bundle.use(repeats[role], *groups, role="corroboration")
        bundle.add(
            "scorecard_methodologies",
            documents[role],
            facts[role]["context"]["body"]["source_path"],
            methodology_id=role + "-native-context",
            methodology_text=json_column(facts[role]["context"]),
            disclosure_status="explicit",
        )
    bundle.add(
        "scorecard_methodologies",
        article,
        facts["article"]["heading"]["source_path"],
        methodology_id="selected-action-article",
        methodology_text=json_column({name: value for name, value in facts["article"].items() if name != "context"}),
        disclosure_status="explicit",
    )
    bundle.add(
        "scorecard_methodologies",
        votes,
        facts["votes"]["table_path"],
        methodology_id="selected-action-groups",
        methodology_text=json_column(
            {name: value for name, value in facts["votes"].items() if name not in {"members", "context"}}
        ),
        disclosure_status="explicit",
    )
    item_id = "selected-s5-senate-action"
    bundle.add(
        "scorecard_items",
        article,
        facts["article"]["position_path"],
        item_id=item_id,
        item_kind_text="publisher-selected Senate vote",
        title=ITEM_TITLE,
        item_date_text="February 10",
        chamber_text="senate",
        bill_citation_text="S.5",
        publisher_position_text=POSITION,
        position_basis="explicit",
        position_source_path=facts["article"]["position_path"],
        references_json=json_column(
            [
                {
                    "occurrence_id": "article-bill-label",
                    "kind": "bill",
                    "citation_text": "S.5",
                    "bill_citation_text": "S.5",
                    "source_path": facts["article"]["position_path"],
                },
                {
                    "occurrence_id": "article-selected-vote-link",
                    "kind": "publisher_item",
                    "citation_text": facts["article"]["vote_link"]["attributes"]["href"],
                    "source_path": facts["article"]["vote_link"]["source_path"] + "/@href",
                },
            ]
        ),
    )
    for member in facts["votes"]["members"]:
        member_key = key("selected-action-occurrence", member["group"], member["group_ordinal"], member["label"])
        path = member["native"]["source_path"]
        bundle.add(
            "scorecard_members",
            votes,
            path,
            publisher_member_key=member_key,
            member_name=member["name"],
            party=member["party"],
            state=member["state"],
            chamber_text="senate",
            identifiers_json="[]",
            notes_text=json_column(
                {name: member[name] for name in ("label", "group", "group_ordinal", "occurrence", "native")}
            ),
        )
        bundle.add(
            "scorecard_member_item_results",
            votes,
            path,
            item_id=item_id,
            publisher_member_key=member_key,
            result_id="source-vote-group",
            result_text=member["group"],
            reason_text=member["group_heading"],
        )
    return bundle.finish(
        "Complete named NAIFA Frontline issue, linked explanation and selected S.5 Senate list reached closing HTML; source mastheads, publication/issue labels, article preferred action and literal February 10 date, all source-declared group subtotals and every located member occurrence reconciled and reread unchanged. Scope is one publisher-selected action, without an aggregate rating or historical Voting Report continuity.",
        declared={"selected_action_groups": GROUP_COUNTS},
    )
