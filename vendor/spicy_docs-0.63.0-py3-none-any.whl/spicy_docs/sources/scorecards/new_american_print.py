"""The New American's separately selected 2008 printed Freedom Index.

The modern application's six-vote retrospective Scorecard is a different
product. This reader uses the existing publisher identity and exact privately
reviewed native observations, without running a model or calculating scores.
"""

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from .qualified_observations import RetainObservations, require_reviewed_pdf, retain_qualified

parser_version = "new-american-named-printed-freedom-index/2"
HOSTS = ("thenewamerican.com",)
SOURCE_URL = "https://thenewamerican.com/assets/sites/2/pdf/Freedom_Index_110-4.pdf"
SOURCE_SHA256 = "4d0d982181ed842ab94c4fa2958204036ac99374d05fb908291044fa59a05f26"
IMPRINT_URL = "https://thenewamerican.com/assets/sites/10/TNA-Oct-27-2008-Vol.-24-No.-22.pdf"
IMPRINT_SHA256 = "c04f5a0a15d2d8a9523f71702c9e3d5c0bf66a802a8871768a6a910c193583e0"
FACTS_SHA256 = "549c86c8aa6860e01a1889c361d68b982e6573b90399ea2a80cb4973c3bf883b"
EDITION = ScorecardEdition(
    "new_american", "freedom-index-110-4-print", SOURCE_URL, "The Freedom Index", "2008", "110", "both", False
)
ITEMS = list(map(str, range(31, 41)))
COUNTS = {"House": 434, "Senate": 100}
PAGE_COUNTS = {2: 105, 4: 110, 6: 109, 7: 110, 9: 72, 10: 28}
HEADER_PATHS = {"House": "PDF/page[2]/block[5]", "Senate": "PDF/page[9]/block[36]"}
PATH = re.compile(r"PDF/page\[(?:[1-9]|10)\]/block\[\d+\](?:/line\[\d+\]|/prefix)?")
CAPTION = re.compile(r"(?:(\d+)\s+)?(.+) \(([RDI])\)(: Speaker)?")


def list_scorecards(context):
    """Only the named reviewed print edition; no historical catalogue claim."""
    return (EDITION,)


def _facts(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != FACTS_SHA256:
        raise ScorecardSourceError("Printed Freedom Index requires its exact private reviewed native facts")
    try:
        data = json.loads(body)
        if (
            data["source_sha256"] != SOURCE_SHA256
            or data["corroboration_sha256"] != IMPRINT_SHA256
            or data["title"] != EDITION.title
            or data["publication_date_text"] != "October 27, 2008"
            or data["congress_text"] != "110"
            or data["session_text"] is not None
            or data["standalone_legal_imprint"] is not None
            or set(data["chambers"]) != set(COUNTS)
        ):
            raise ValueError
        locations, pages = set(), {}
        for chamber, count in COUNTS.items():
            facts = data["chambers"][chamber]
            if len(facts["members"]) != count or [i["ordinal"] for i in facts["items"]] != ITEMS:
                raise ValueError
            states = set()
            for member in facts["members"]:
                caption = CAPTION.fullmatch(member["member_label"])
                path = member["source_path"]
                if (
                    caption is None
                    or (caption[1], caption[2], caption[3], caption[4])
                    != (member["district"], member["member_name"], member["party"], member["role"])
                    or path in locations
                    or not PATH.fullmatch(path)
                    or not PATH.fullmatch(member["state_source_path"])
                    or not isinstance(member["state"], str)
                    or not member["state"]
                    or len(member["results"]) != 10
                    or any(v not in {"+", "-", "?", "P"} for v in member["results"])
                    or len(member["ratings"]) != 2
                    or any(not re.fullmatch(r"\d+%?|", v) for v in member["ratings"])
                    or (chamber == "Senate" and member["district"] is not None)
                ):
                    raise ValueError
                locations.add(path)
                states.add(member["state"])
                page = int(path.split("[")[1].split("]")[0])
                pages[page] = pages.get(page, 0) + 1
            if len(states) != 50:
                raise ValueError
            for item in facts["items"]:
                description = item["description"]
                if (
                    not isinstance(description, str)
                    or not description
                    or not item["title"]
                    or not description.startswith(item["title"])
                    or not item["source_paths"]
                    or any(not PATH.fullmatch(p) for p in item["source_paths"])
                    or item["rolls"] != re.findall(r"Roll\s+Call\s+(\d+)", description)
                    or len(item["rolls"]) != 1
                    or item["dates"] != re.findall(r"(?:June|July|September|October)\s+\d{1,2},\s*2008", description)
                    or len(item["dates"]) != 1
                    or item["position"] != "nays"
                    or not re.search(r"pluses\s+to\s+the\s+“nays”", description)
                    or any(b not in description for b in item["bills"])
                    or len(item["bill_paths"]) != len(item["bills"])
                    or any(p not in item["source_paths"] for p in item["bill_paths"])
                    or any(
                        item[k] not in item["source_paths"]
                        for k in ("date_source_path", "roll_source_path", "position_source_path")
                    )
                    or any(
                        r["citation_text"] not in description or r["source_path"] not in item["source_paths"]
                        for r in item["item_references"]
                    )
                ):
                    raise ValueError
                parts = item["description_parts"]
                if (
                    not parts
                    or any(not isinstance(p["text"], str) or not p["text"] for p in parts)
                    or "".join(p["text"] for p in parts) != description
                    or [p["source_path"] for p in parts] != item["source_paths"]
                ):
                    raise ValueError
                match = re.search(r"Roll\s+Call\s+(\d+)", description)
                if match is None:
                    raise ValueError
                offset = 0
                for part in parts:
                    if offset <= match.start(1) < offset + len(part["text"]):
                        if item["roll_source_path"] != part["source_path"] or match[1] not in part["text"]:
                            raise ValueError
                        break
                    offset += len(part["text"])
                else:
                    raise ValueError
        if pages != PAGE_COUNTS:
            raise ValueError
        for context in data["contexts"]:
            if (
                context["source"] not in {"index", "imprint"}
                or not context["text"]
                or not (PATH.fullmatch(context["source_path"]) or context["source_path"] == "PDF/metadata")
            ):
                raise ValueError
        if not any(c["source"] == "imprint" and "wholly owned subsidiary" in c["text"] for c in data["contexts"]):
            raise ValueError
        vacancies = [c for c in data["contexts"] if c["kind"] == "explicit vacant House district row"]
        if len(vacancies) != 1 or vacancies[0]["source_path"] != "PDF/page[6]/block[14]/line[143]":
            raise ValueError
        vacancy = json.loads(vacancies[0]["text"])
        if (
            vacancy["native_row_label"] != "\t11\t Vacant\t"
            or vacancy["chamber_text"] != "House"
            or vacancy["state_heading_text"] != "Ohio"
            or vacancy["rating_slots"] != ["", ""]
            or vacancy["result_slots"] != [""] * 10
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, AttributeError, IndexError):
        raise ScorecardSourceError(
            "Printed Freedom Index facts do not establish the complete reviewed edition"
        ) from None


def _source(document, url, digest):
    require_reviewed_pdf(
        document,
        source_url=url,
        source_sha256=digest,
        message="Printed Freedom Index original or source-time magazine differs from its reviewed PDF",
    )
    if document.response.content_type != "application/pdf":
        raise ScorecardSourceError("Printed Freedom Index PDF content type changed")


@dataclass(frozen=True, slots=True)
class PrintedFreedomIndexReader:
    """Existing acquisition seam with a private pinned native-observation asset."""

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        _facts(self.qualified_observations)
        return (EDITION,)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Printed Freedom Index requires the named edition and privately retained reviewed facts"
        )
    data = _facts(qualified_observations)
    source = context.read(SOURCE_URL, stage="new-american-print:original", hosts=HOSTS)
    _source(source, SOURCE_URL, SOURCE_SHA256)
    imprint = context.read(IMPRINT_URL, stage="new-american-print:source-time-imprint", hosts=HOSTS)
    _source(imprint, IMPRINT_URL, IMPRINT_SHA256)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=FACTS_SHA256,
        stage="new-american-print:reviewed-native-facts",
    )
    reread = context.read(SOURCE_URL, stage="new-american-print:original-reread", hosts=HOSTS)
    _source(reread, SOURCE_URL, SOURCE_SHA256)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="The New American",
        parser_version=parser_version,
        homepage="https://thenewamerican.com/",
        rendition_rule="named printed 110-4 index and source-time magazine/1",
    )
    bundle.use(source, "members", "ratings", "items", "results", "context")
    bundle.use(imprint, "source-time publisher imprint")
    bundle.use(reread, "members", "ratings", "items", "results", "context", role="corroboration")

    def path(original):
        if original == "PDF/metadata":
            return f"pdf:document;observation={observation};{original}"
        page = original.split("[")[1].split("]")[0]
        return f"pdf:page={page};observation={observation};{original}"

    bundle.tables["scorecards"][0].update(
        series_id="new_american:printed-freedom-index",
        edition_label_text="The Freedom Index",
        publisher_edition_key=None,
        published_at_text=data["publication_date_text"],
        methodology_url=SOURCE_URL,
    )
    for n, record in enumerate(data["contexts"]):
        bundle.add(
            "scorecard_methodologies",
            source if record["source"] == "index" else imprint,
            path(record["source_path"]),
            methodology_id=key("print-context", str(n)),
            methodology_text=record["text"],
            methodology_url=SOURCE_URL if record["source"] == "index" else IMPRINT_URL,
            disclosure_status=record["kind"],
        )
    for chamber, facts in data["chambers"].items():
        metric_ids = [key(chamber, "printed-score", p) for p in ("31-40", "1-40")]
        for period, metric_id in zip(("31-40", "1-40"), metric_ids, strict=True):
            bundle.metric(
                source,
                metric_id,
                period,
                path=path(HEADER_PATHS[chamber]) + "/header/" + period,
                chamber=chamber,
                unit="percent",
            )
            bundle.tables["scorecard_metrics"][-1]["period_text"] = period
        for item in facts["items"]:
            item_id = key("print", chamber, item["ordinal"])
            item_path = path(item["source_paths"][0]) + "/item/" + item["ordinal"]
            bundle.add(
                "scorecard_items",
                source,
                item_path,
                item_id=item_id,
                publisher_item_id=item["ordinal"],
                item_kind_text="roll_call",
                title=item["title"],
                congress_text="110",
                chamber_text=chamber,
                item_date_text=item["dates"][0],
                roll_number_text=item["rolls"][0],
                publisher_position_text=item["position"],
                position_basis="explicit",
                position_source_path=path(item["position_source_path"]),
                references_json=json_column(
                    [
                        {
                            "occurrence_id": str(i),
                            "kind": "bill_citation",
                            "citation_text": text,
                            "source_path": path(item["bill_paths"][i]) + "/bill/" + str(i),
                        }
                        for i, text in enumerate(item["bills"])
                    ]
                    + [
                        {
                            "occurrence_id": "context-item-" + str(i),
                            "kind": "publisher_item_citation",
                            "citation_text": reference["citation_text"],
                            "source_path": path(reference["source_path"]) + "/item-reference/" + str(i),
                        }
                        for i, reference in enumerate(item["item_references"])
                    ]
                ),
            )
            bundle.add(
                "scorecard_methodologies",
                source,
                item_path,
                methodology_id=item_id,
                chamber_text=chamber,
                methodology_text=item["description"],
                methodology_url=SOURCE_URL,
                disclosure_status=json_column(
                    {
                        "literal_native_description_paths": item["source_paths"],
                        "literal_date_source_path": item["date_source_path"],
                        "literal_roll_source_path": item["roll_source_path"],
                        "literal_position_source_path": item["position_source_path"],
                    }
                ),
            )
            bundle.add(
                "scorecard_metric_items",
                source,
                item_path,
                metric_id=metric_ids[0],
                item_id=item_id,
                participation_id="printed-votes-31-40",
                publisher_position_text=item["position"],
                position_basis="explicit",
                counts_toward_metric="true",
            )
        for member in facts["members"]:
            original = member["source_path"]
            member_key = key("print-occurrence", chamber, original)
            member_path = path(original)
            bundle.add(
                "scorecard_members",
                source,
                member_path,
                publisher_member_key=member_key,
                member_name=member["member_name"],
                chamber_text=chamber,
                state=member["state"],
                district=member["district"],
                party=member["party"],
                notes_text=json_column(
                    {
                        "original_combined_label": member["member_label"],
                        "state_heading_source_path": member["state_source_path"],
                        "printed_role": member["role"],
                    }
                ),
            )
            for i, (metric_id, value) in enumerate(zip(metric_ids, member["ratings"], strict=True)):
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    member_path + "/score/" + str(i),
                    metric_id=metric_id,
                    publisher_member_key=member_key,
                    value_text=value,
                    value_number=decimal_text(value),
                )
            for ordinal, mark in zip(ITEMS, member["results"], strict=True):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    member_path + "/vote/" + ordinal,
                    publisher_member_key=member_key,
                    item_id=key("print", chamber, ordinal),
                    result_id="printed-mark",
                    metric_id=metric_ids[0],
                    participation_id="printed-votes-31-40",
                    result_text=mark,
                    reason_text="Literal publisher mark; no official member vote or identity inferred.",
                )
    return bundle.finish(
        "Complete named print scope: all native state/member rows, both score columns and ten results per row; every action narrative and source context retained. Matching magazine corroborates all ten index pages and source-time imprint; original reread remains byte-identical. Cumulative scores remain published values; votes 1-30 are outside this grid."
    )
