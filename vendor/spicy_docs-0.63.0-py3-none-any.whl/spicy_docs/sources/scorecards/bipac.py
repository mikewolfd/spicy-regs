"""BIPAC 2012 observations in separately selected original cop tenant profiles.

Each scope is one complete original profile and its literal BIPAC occurrence.
Adjacent organizations and COP voting records remain separately labeled context;
they never supply BIPAC metrics, items, methodology or annual-roster completeness.
"""

import re
from hashlib import sha256
from typing import TypedDict

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.capwiz_html import authored_children, native, text
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key, soup

parser_version = "bipac-2012-single-original-tenant-profile/1"
HOSTS = ("web.archive.org",)
TABLE = "(//div[@class='left-col']//table)"
OTHER = "//div[@class='left-col']//span[normalize-space(.)='Other Ratings:']"
LABEL = "BIPAC, 2012:"
OTHER_LABELS = (
    "Associated General Contractors, 2012:",
    LABEL,
    "National Association of Manufacturers, 2012:",
    "National Federation of Independent Business, 2012:",
    "National Retail Federation, 2011:",
    "National Small Business Association, 2012:",
    "U.S. Chamber of Commerce, 2012:",
)


class _Profile(TypedDict):
    timestamp: str
    heading: str
    name: str
    party: str
    cop_congresses: tuple[str, ...]
    cop_rows: tuple[int, ...]
    sha256: str


PROFILES: dict[str, _Profile] = {
    "11600": {
        "timestamp": "20141024095356",
        "heading": "Senator Lisa  Murkowski  (R)",
        "name": "Lisa  Murkowski",
        "party": "R",
        "cop_congresses": ("113", "112", "111", "110", "109", "108"),
        "cop_rows": (5, 6, 7, 14, 6, 8),
        "sha256": "52137e8c7f9b8a2a422478abd01d579da98f27fd8350d8c920e23578322ba3c7",
    },
    "20043": {
        "timestamp": "20141024095414",
        "heading": "Senator Mark  Begich  (D)",
        "name": "Mark  Begich",
        "party": "D",
        "cop_congresses": ("113", "112", "111"),
        "cop_rows": (5, 6, 7),
        "sha256": "f7cf686fbc9c53519ae16e78e2e23abae37f29bce32d1a87f3121adc3c622a10",
    },
}


def _url(identifier):
    return (
        "https://web.archive.org/web/"
        + PROFILES[identifier]["timestamp"]
        + "id_/http://www.bipac.net:80/incumbent_detail.asp?g=cop&leg_id_num="
        + identifier
    )


EDITIONS = tuple(
    ScorecardEdition(
        "bipac",
        "2012-cop-single-profile-" + identifier,
        _url(identifier),
        "BIPAC 2012 observation in one original cop tenant profile leg_id_num=" + identifier,
        year="2012",
        chamber="Senate",
        is_current=False,
    )
    for identifier in PROFILES
)


def list_scorecards(context):
    """List separately selected original profiles, never an annual edition."""
    return EDITIONS


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("BIPAC single profile field is missing or repeated: " + selector)
    return nodes[0]


def _rows(table, expected):
    rows = authored_children(table, {"tr"}, publisher="BIPAC profile")
    if len(rows) != expected:
        raise ScorecardSourceError("BIPAC complete original profile table inventory changed")
    for row in rows:
        if not authored_children(row, {"td"}, publisher="BIPAC profile"):
            raise ScorecardSourceError("BIPAC original profile contains an empty row")
    return rows


def _profile(document, identifier):
    expected = PROFILES[identifier]
    if (
        document.url != _url(identifier)
        or sha256(document.body).hexdigest() != expected["sha256"]
        or not document.body.rstrip().lower().endswith(b"</html>")
    ):
        raise ScorecardSourceError("BIPAC named original profile bytes or archive custody changed")
    root = soup(document)
    container = _one(root, "div.left-col")
    if [text(t) for t in root.find_all("title")] != [
        "Incumbent Information",
        "Conoco Phillips - Voter Information Center",
    ]:
        raise ScorecardSourceError("BIPAC original tenant publication labels changed")
    footer = _one(root, "#footer")
    if text(footer) != "Copyright © Conoco Phillips, 2013":
        raise ScorecardSourceError("BIPAC original tenant attribution changed")
    tables = container.find_all("table")
    if len(tables) != len(expected["cop_congresses"]) + 3:
        raise ScorecardSourceError("BIPAC single profile context table scope changed")
    identity, *contexts, ratings = tables
    _rows(identity, 3)
    state = _one(identity, ".p2_head")
    heading = _one(identity, ".p2_normal > strong")
    if text(state) != "Alaska U.S. Senate" or heading.get_text().strip() != expected["heading"]:
        raise ScorecardSourceError("BIPAC native source-time member heading changed")
    links = identity.select("a[href]")
    committee = "/incumbent_detail.asp?g=cop&leg_id_num=" + identifier + "&cmte=y"
    write = "/write_step_one.asp?g=cop&leg_id_num=" + identifier + "&type=0&state=AK"
    if sum(a.get("href") == committee for a in links) != 1 or sum(a.get("href") == write for a in links) != 1:
        raise ScorecardSourceError("BIPAC original tenant/member links disagree with the selected profile")
    for table, congress, count in zip(contexts[:-1], expected["cop_congresses"], expected["cop_rows"], strict=True):
        rows = _rows(table, count)
        title = text(rows[0]).removeprefix("U.S. Senate:  ").removeprefix("U.S. Senate: ")
        if title != "Key COP Senate Votes - " + congress + "th Congress":
            raise ScorecardSourceError("BIPAC adjacent COP authorship or period label changed")
    symbol_rows = _rows(contexts[-1], 6)
    if text(symbol_rows[0]) != "Symbol Key:":
        raise ScorecardSourceError("BIPAC adjacent COP symbol context changed")
    other = [n for n in container.select(".p2_subhead") if text(n) == "Other Ratings:"]
    if len(other) != 1 or ratings.parent is not other[0].parent:
        raise ScorecardSourceError("BIPAC rating table left its original Other Ratings occurrence")
    section = other[0].parent
    history = "/incumbent_detail.asp?g=cop&leg_id_num=" + identifier + "&show=history"
    explanation = "/page.asp?content=ratings_organizations&g=cop&parent=BIPAC"
    if [a.get("href") for a in section.select("a[href]")] != [history, explanation]:
        raise ScorecardSourceError("BIPAC native rating history/explanation selection changed")
    rows = _rows(ratings, 16)
    if any(len(row.find_all("td", recursive=False)) != 1 for row in rows):
        raise ScorecardSourceError("BIPAC original rating label/value pairs are malformed")
    for index, label in enumerate(OTHER_LABELS):
        label_row, value_row = rows[index * 2 + 1 : index * 2 + 3]
        if text(label_row) != label or not re.fullmatch(r"\(\d+%\)", text(value_row)):
            raise ScorecardSourceError("BIPAC complete literal Other Ratings inventory changed")
    if [i.get("src") for i in rows[0].select("img")] != ["/images/scale.gif"] or [
        i.get("src") for i in rows[-1].select("img")
    ] != ["/images/scale_bottom.gif"]:
        raise ScorecardSourceError("BIPAC original rating table boundaries changed")
    path = TABLE + "[" + str(len(tables)) + "]"
    return {
        "root": root,
        "identity": identity,
        "footer": footer,
        "contexts": contexts,
        "other": other[0],
        "section": section,
        "ratings": ratings,
        "label_path": path + "/tr[4]/td[1]",
        "value_path": path + "/tr[5]/td[1]",
        "label": rows[3].find("td", recursive=False),
        "value": rows[4].find("td", recursive=False),
    }


def acquire_scorecard(edition, context):
    if edition not in EDITIONS:
        raise ScorecardSourceError("BIPAC requires one separately named original tenant profile")
    identifier = edition.edition_id.removeprefix("2012-cop-single-profile-")
    source = context.read(edition.source_url, stage="bipac:single-profile", hosts=HOSTS)
    parsed = _profile(source, identifier)
    reread = context.read(edition.source_url, stage="bipac:single-profile-reread", hosts=HOSTS)
    _profile(reread, identifier)
    if reread.body != source.body:
        raise ScorecardSourceError("BIPAC single profile changed on reread")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="BIPAC",
        parser_version=parser_version,
        rendition_rule="one exact original cop tenant profile supplies one literal BIPAC 2012 observation/1",
        homepage="https://bipac.org/",
    )
    bundle.use(source, "single-profile", "source-time-member", "BIPAC-rating", "adjacent-context")
    bundle.use(reread, "single-profile", "BIPAC-rating", role="corroboration")
    period = [
        {
            "occurrence_id": "native-bipac-label",
            "kind": "explicit",
            "period_text": LABEL,
            "year_text": "2012",
            "source_path": parsed["label_path"],
        }
    ]
    bundle.tables["scorecards"][0].update(
        series_id="bipac:single-original-cop-tenant-profile",
        publisher_edition_key=None,
        edition_label_text=LABEL,
        source_path=parsed["label_path"],
        periods_json=json_column(period),
    )
    # Native adjacent syntax is retained once, with its own labels. Its contents
    # never become BIPAC measurements, actions, positions or scoring methodology.
    contextual = {
        "tenant": "cop",
        "leg_id_num": identifier,
        "archived_profile_timestamp_text": PROFILES[identifier]["timestamp"],
        "original_profile_url": edition.source_url.split("id_/", 1)[1],
        "publication_titles": [
            native(t, "/html/head/title[" + str(n) + "]") for n, t in enumerate(parsed["root"].find_all("title"), 1)
        ],
        "tenant_footer": native(parsed["footer"], "#footer"),
        "source_time_member": native(parsed["identity"], TABLE + "[1]"),
        "adjacent_COP_context": [native(t, TABLE + "[" + str(n) + "]") for n, t in enumerate(parsed["contexts"], 2)],
        "other_ratings_heading": native(parsed["other"], OTHER),
        "other_ratings_links": [
            native(a, "(" + OTHER + "/..//a)[" + str(n) + "]")
            for n, a in enumerate(parsed["section"].select("a[href]"), 1)
        ],
        "other_ratings": native(parsed["ratings"], TABLE + "[" + str(len(parsed["contexts"]) + 2) + "]"),
    }
    bundle.add(
        "scorecard_methodologies",
        source,
        "//div[@class='left-col']",
        methodology_id="original-profile-context",
        methodology_text=json_column(contextual),
        disclosure_status="literal tenant/member and adjoining separately labeled context; BIPAC scoring methodology unknown",
    )
    bundle.add(
        "scorecard_metrics",
        source,
        parsed["label_path"],
        metric_id="bipac-2012",
        name=LABEL,
        value_unit_text="percent",
        period_text=LABEL,
        periods_json=json_column(period),
        is_primary=None,
    )
    member_key = key("tenant", "cop", "leg_id_num", identifier)
    bundle.add(
        "scorecard_members",
        source,
        TABLE + "[1]",
        publisher_member_key=member_key,
        publisher_member_id=identifier,
        member_name=PROFILES[identifier]["name"],
        chamber_text="U.S. Senate",
        state="Alaska",
        party=PROFILES[identifier]["party"],
        identifiers_json=json_column(
            [{"scheme": "bipac.net:tenant", "value": "cop"}, {"scheme": "bipac.net:leg_id_num", "value": identifier}]
        ),
    )
    bundle.add(
        "scorecard_member_ratings",
        source,
        parsed["value_path"],
        metric_id="bipac-2012",
        publisher_member_key=member_key,
        value_text=text(parsed["value"]),
        value_number=decimal_text(text(parsed["value"])[1:-2]),
    )
    return bundle.finish(
        "Complete only for one exact original cop tenant profile leg_id_num="
        + identifier
        + " and its one literal BIPAC, 2012: observation. Original rating-table boundaries, all seven literal rating "
        "labels, native tenant/member identity, separately labeled COP context and exact reread are checked. "
        "No annual roster, additional history, BIPAC actions, scale bounds or exact scoring period established.",
    )
