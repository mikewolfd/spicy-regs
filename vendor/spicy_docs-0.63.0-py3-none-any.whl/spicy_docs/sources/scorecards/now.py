"""Named NOW archived congressional action grids, without aggregate ratings."""

import re
from collections import Counter
from copy import deepcopy

from bs4 import Comment, NavigableString

from spicy_docs.schemas.tables import json_column

from . import capwiz_html
from .common import Bundle, ScorecardContext, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "now-named-capwiz-html/2"
HOSTS = ("web.archive.org",)
EDITION_2008 = "110-combined-2008-archived-native"
EDITION_2006_SENATE = "109-combined-2006-senate-archived-native"
SUMMARY_TITLE = "110th Scorecard Shows Party Line Voting; Senate Bills Faced Filibusters"
DIRECTORY_2008 = "http://now.org:80/issues/election/elections2008/"
DIRECTORY_2006 = "http://www.now.org/issues/election/elections2006/"
SUMMARY_URL = "https://web.archive.org/web/20081023155712id_/" + DIRECTORY_2008 + "scorecard.html"
CHAMBER_SOURCES = {
    ("110", "house"): (
        "20081106053122",
        DIRECTORY_2008 + "house_votes.html",
        "NOW Congressional Scorecard 2008: U.S. House of Representatives Votes",
        16,
    ),
    ("110", "senate"): (
        "20081106053131",
        DIRECTORY_2008 + "senate_votes.html",
        "NOW Congressional Scorecard 2008: U.S. Senate Key Votes",
        16,
    ),
    ("109", "senate"): ("20061120215523", DIRECTORY_2006 + "senate_votes.html", "U.S. Senate Key Votes", 23),
}
LEGEND = {
    "Y": "Voted Yes (No position by organization)",
    "N": "Voted No (No position by organization)",
    "+": "Voted With Us",
    "-": "Voted Against Us",
    "P": "Voted Present",
    "NV": "Did Not Vote",
    "I": "Not in Office",
    "S": "Speaker (Typically the speaker does not participate in roll call votes.)",
}
# Measured all-state source occurrences, including replacements. These pins are
# checked against the retained named originals, not an official member roster.
HOUSE_110 = dict(
    zip(
        [
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY",
        ],
        (
            7,
            1,
            8,
            4,
            55,
            7,
            5,
            1,
            25,
            14,
            2,
            2,
            20,
            10,
            5,
            4,
            6,
            9,
            2,
            9,
            11,
            15,
            8,
            5,
            9,
            1,
            3,
            3,
            2,
            13,
            3,
            29,
            13,
            1,
            19,
            5,
            5,
            19,
            2,
            6,
            1,
            9,
            32,
            3,
            1,
            12,
            9,
            3,
            8,
            1,
        ),
        strict=True,
    )
)
REVIEWED_ROWS = {
    ("110", "house"): HOUSE_110,
    ("110", "senate"): {**dict.fromkeys(HOUSE_110, 2), "MS": 3, "WY": 3},
    ("109", "senate"): {**dict.fromkeys(HOUSE_110, 2), "NJ": 3},
}
MEMBER = re.compile(r"(.+) \(([A-Z])-([A-Z]{2})(?:-(AL|\d+))?\)")
POSITION = re.compile(r"(?:A vote|Vote) ((?:AGAINST|FOR|against|in support)\b.*?) (?:was|is) correct\.")
# Unescaped quotation marks in the original Senate header split the title into
# HTML attributes. Keep this exact source defect, never reconstruct a new title.
MALFORMED_HEADER = {
    "title": "Promoting Fetal ",
    'rights"': "",
    "(08": "",
    "02": "",
    "2007,": "",
    "roll": "",
    "call": "",
    "no.": "",
    '302)"': "",
}


def _url(congress, chamber):
    timestamp, original, _, _ = CHAMBER_SOURCES[congress, chamber]
    return "https://web.archive.org/web/" + timestamp + "id_/" + original


def edition(edition_id):
    if edition_id == EDITION_2008:
        return ScorecardEdition(
            "now",
            edition_id,
            SUMMARY_URL,
            "NOW Congressional Scorecard 2008",
            year="2008",
            congress="110",
            chamber="both",
            is_current=False,
        )
    if edition_id == EDITION_2006_SENATE:
        return ScorecardEdition(
            "now",
            edition_id,
            _url("109", "senate"),
            "U.S. Senate Key Votes",
            year="2006",
            congress="109",
            chamber="senate",
            is_current=False,
        )
    raise ScorecardSourceError(
        "NOW edition is outside the named complete originals; the 2006 House grid lacks item narratives 20–22"
    )


def list_scorecards(context: ScorecardContext):
    return (edition(EDITION_2008), edition(EDITION_2006_SENATE))


def _children(node, allowed):
    return capwiz_html.authored_children(node, allowed, publisher="NOW")


def _html(document, expected_url, title, date):
    if document.url != expected_url or document.response.requested_url != expected_url:
        raise ScorecardSourceError("NOW archive custody escaped the named original")
    if (
        not document.body.rstrip().lower().endswith(b"</html>")
        or "html" not in (document.response.content_type or "").lower()
    ):
        raise ScorecardSourceError("NOW original HTML is incomplete or the format changed")
    html = soup(document)
    if (
        len(html.select("html")) != 1
        or len(html.select("body")) != 1
        or not html.select("title")
        or capwiz_html.text(html.select("title")[0]) != title
    ):
        raise ScorecardSourceError("NOW original document identity changed")
    for name in ("create_date", "update_date"):
        nodes = html.select('meta[name="' + name + '"]')
        if len(nodes) != 1 or nodes[0].get("content") != date:
            raise ScorecardSourceError("NOW native publication date changed")
    return html


def _context(html, url, original, timestamp):
    body, head = deepcopy(html.body), deepcopy(html.head)
    # Remove only the item list itself: the malformed 2006 outer dl is context.
    for node in list(body.select("table#votes")) + [
        n for n in body.select("dl#keyvotes") if not n.select("dl#keyvotes")
    ]:
        node.decompose()
    for root in (body, head):
        for node in root.select("script, style"):
            node.decompose()
        for node in root.find_all(string=lambda value: isinstance(value, Comment)):
            node.extract()
    return {
        "body": capwiz_html.native(body, "//body"),
        "head": capwiz_html.native(head, "//head"),
        "source_custody": {"original_publisher_url": original, "archive_url": url, "archive_timestamp": timestamp},
    }


def _grid(table, chamber, items, populations, congress):
    path = "//table[@id='votes']"
    label = "House of Representatives" if chamber == "house" else "Senate"
    if table.get("summary") != "This table contains U.S. " + label + " Key Votes by state.":
        raise ScorecardSourceError("NOW table chamber statement changed")
    members, headers, states, spacers, counts = [], [], [], [], Counter()
    for ordinal, row in enumerate(_children(table, {"tr"}), 1):
        row_path = path + "/tr[" + str(ordinal) + "]"
        cells, rid = _children(row, {"th", "td"}), row.get("id", "")
        if re.fullmatch(r"STATE_[A-Z]{2}_spacer_2", rid):
            state = rid.split("_")[1]
            if (
                len(cells) != 1
                or cells[0].name != "td"
                or cells[0].find()
                or capwiz_html.text(row)
                or not states
                or state != states[-1]
                or state in spacers
            ):
                raise ScorecardSourceError("NOW native spacer/state boundary changed")
            spacers.append(state)
        elif re.fullmatch(r"STATE_[A-Z]{2}_0", rid):
            state = rid.split("_")[1]
            if (
                len(cells) != len(items) + 1
                or state not in populations
                or state in states
                or cells[0].name != "th"
                or any(c.name != "td" for c in cells[1:])
            ):
                raise ScorecardSourceError("NOW complete state header inventory changed")
            states.append(state)
            for number, (cell, item) in enumerate(zip(cells[1:], items, strict=True), 1):
                anchors = _children(cell, {"a"})
                if (
                    len(anchors) != 1
                    or capwiz_html.text(cell) != str(number)
                    or anchors[0].get("href") != item["href"]
                    or anchors[0].find()
                ):
                    raise ScorecardSourceError("NOW state item links conflict with the complete explanations")
                attributes = {name: value for name, value in anchors[0].attrs.items() if name != "href"}
                expected = (
                    MALFORMED_HEADER
                    if (congress, chamber, number) == ("110", "senate", 3)
                    else {"title": anchors[0].get("title")}
                )
                if (congress, chamber, number) == ("110", "senate", 3) and item[
                    "title_text"
                ] != '3. Promoting Fetal "Rights" (08/02/2007, Roll Call No. 302)':
                    raise ScorecardSourceError("NOW malformed header no longer belongs to its observed literal item")
                if attributes != expected or (
                    (congress, chamber, number) != ("110", "senate", 3)
                    and " ".join((anchors[0].get("title") or "").split())
                    != item["title_text"].removeprefix(str(number) + ". ")
                ):
                    raise ScorecardSourceError("NOW repeated item title/observed malformed attributes changed")
        elif re.fullmatch(r"STATE_[A-Z]{2}_[1-9]\d*", rid):
            state, publisher_id = rid.split("_")[1:]
            if (
                len(cells) != len(items) + 1
                or any(c.name != "td" for c in cells)
                or not states
                or state != states[-1]
                or state in spacers
                or any(c.find() for c in cells[1:])
            ):
                raise ScorecardSourceError("NOW member cells or state placement changed")
            anchors = cells[0].find_all(recursive=False)
            prefix_parts = []
            for child in cells[0].children:
                if isinstance(child, Comment):
                    continue
                if isinstance(child, NavigableString):
                    prefix_parts.append(str(child))
                elif len(anchors) != 1 or child is not anchors[0]:
                    raise ScorecardSourceError("NOW native member identity contains unreviewed content")
            prefix = " ".join(" ".join(prefix_parts).split())
            bio_prefix = "" if congress == "110" else "http://www.now.org/congress/"
            if (
                len(anchors) != 1
                or anchors[0].name != "a"
                or anchors[0].find()
                or anchors[0].get("href") != bio_prefix + "bio/?id=" + publisher_id
            ):
                raise ScorecardSourceError("NOW biography link conflicts with its literal native member ID")
            match = MEMBER.fullmatch(capwiz_html.text(anchors[0]))
            if (
                not match
                or match[3] != state
                or (prefix and not re.fullmatch(r"\d+\.", prefix))
                or (chamber == "senate" and (prefix or match[4]))
                or (prefix and match[4] and prefix != match[4] + ".")
            ):
                raise ScorecardSourceError("NOW literal name/state/district fields disagree")
            actions = [capwiz_html.text(cell) or None for cell in cells[1:]]
            if any(action not in LEGEND for action in actions) or any(
                member["publisher_id"] == publisher_id for member in members
            ):
                raise ScorecardSourceError("NOW action vocabulary or unique native member IDs changed")
            members.append(
                {
                    "publisher_id": publisher_id,
                    "row_id": rid,
                    "path": row_path,
                    "name": match[1],
                    "party": match[2],
                    "state": state,
                    "district": match[4] or (prefix.removesuffix(".") if prefix else None),
                    "district_prefix": prefix,
                    "district_suffix": match[4],
                    "identity": capwiz_html.text(cells[0]),
                    "member_href": anchors[0]["href"],
                    "row_attributes": dict(row.attrs),
                    "actions": actions,
                    "cells": [
                        capwiz_html.native(cell, row_path + "/td[" + str(n) + "]") for n, cell in enumerate(cells, 1)
                    ],
                }
            )
            counts[state] += 1
            continue
        else:
            raise ScorecardSourceError("NOW row is outside the native state/member structure")
        headers.append(capwiz_html.header(row, row_path, cells))
    if dict(counts) != populations or set(states) != set(populations) or spacers != states:
        raise ScorecardSourceError("NOW complete named native population/state boundaries are missing")
    return {"path": path, "attributes": dict(table.attrs), "headers": headers, "members": members}


def _facts(document, congress, chamber):
    timestamp, original, title, count = CHAMBER_SOURCES[congress, chamber]
    date = "2008-10-17" if congress == "110" else "2006-11-03"
    html = _html(document, _url(congress, chamber), title, date)
    label = "House of Representatives" if chamber == "house" else "Senate"
    headings = html.select(".cwh2 h2")
    if [capwiz_html.text(heading) for heading in headings] != [
        "Key Votes: U.S. " + label + " " + congress + "th Congress",
        "U.S. " + label + " " + congress + "th Congress, Combined Sessions",
    ]:
        raise ScorecardSourceError("NOW native chamber/combined-session period changed")
    if [capwiz_html.text(node) for node in html.select("script") if "CAgateway(" in capwiz_html.text(node)] != [
        "CAgateway('now');"
    ]:
        raise ScorecardSourceError("NOW native Capwiz publisher gateway changed")
    tables = html.select("table#votes")
    explanations = [node for node in html.select("dl#keyvotes") if not node.select("dl#keyvotes")]
    if len(tables) != 1 or len(explanations) != 1 or len(html.select("dl#keyvotes")) != (1 if congress == "110" else 2):
        raise ScorecardSourceError("NOW complete table/explanation inventory changed")
    dl = explanations[0]
    ordinal = 1 if congress == "110" else 2
    items = capwiz_html.items(
        dl,
        chamber,
        congress,
        ordinal,
        count,
        publisher="NOW",
        sessions=("1", "2"),
        leading_description_anchor=congress == "110",
        detail_in_span=congress == "110",
        detail_in_paragraph=congress == "109",
        contextual_links=True,
        route_prefix="" if congress == "110" else "http://www.now.org/congress/",
    )
    ids = set()
    for number, item in enumerate(items, 1):
        dt, dd = dl.find_all("dt", recursive=False)[number - 1], dl.find_all("dd", recursive=False)[number - 1]
        if (
            dd.get("id") != "sc" + str(number)
            or dt.get("onclick") != "expandcontent(this, 'sc" + str(number) + "')"
            or item["publisher_id"] in ids
            or item["date"][-4:]
            != {"110": {"1": "2007", "2": "2008"}, "109": {"1": "2005", "2": "2006"}}[congress][item["session"]]
        ):
            raise ScorecardSourceError("NOW native item occurrence/session/date fields changed")
        ids.add(item["publisher_id"])
        positions = POSITION.findall(item["description"])
        if len(positions) != 1:
            raise ScorecardSourceError("NOW explicit item position sentence changed")
        item.update(
            position=positions[0],
            title_native=capwiz_html.native(dt, item["path"]),
            description_native=capwiz_html.native(dd, item["description_path"]),
        )
    legends = html.find_all("h3", string=lambda value: value and value.strip() == "Legend")
    if len(legends) != 1:
        raise ScorecardSourceError("NOW native action legend missing or repeated")
    if congress == "110":
        nodes = _children(legends[0].parent, {"h3", "li"})
        if len(nodes) != len(LEGEND) + 1:
            raise ScorecardSourceError("NOW complete action legend inventory changed")
        meanings = {}
        for node in nodes[1:]:
            strong = node.find_all("strong", recursive=False)
            if len(strong) != 1 or node.name != "li":
                raise ScorecardSourceError("NOW action legend syntax changed")
            meanings[capwiz_html.text(strong[0])] = capwiz_html.text(node).split(":", 1)[1].strip()
    else:
        legend_tables = legends[0].parent.select("table")
        if len(legend_tables) != 1:
            raise ScorecardSourceError("NOW 2006 table legend changed")
        meanings = {}
        rows = _children(legend_tables[0], {"tr"})
        if len(rows) != len(LEGEND):
            raise ScorecardSourceError("NOW 2006 complete action legend inventory changed")
        for row in rows:
            cells = _children(row, {"td"})
            if len(cells) != 2:
                raise ScorecardSourceError("NOW 2006 action legend width changed")
            meanings[capwiz_html.text(cells[0])] = capwiz_html.text(cells[1])
    if meanings != LEGEND:
        raise ScorecardSourceError("NOW native action meanings changed")
    filters = html.select("select[name=state]")
    populations = REVIEWED_ROWS[congress, chamber]
    if len(filters) != 1:
        raise ScorecardSourceError("NOW all-state selector inventory changed")
    options = _children(filters[0], {"option"})
    if (
        filters[0].get("onchange") != "showOnlyRowsMatching('STATE_', this.value, true);"
        or len(options) != len(populations) + 1
        or options[0].get("value") != ""
        or capwiz_html.text(options[0]) != "All States"
        or {node.get("value") for node in options[1:]} != set(populations)
    ):
        raise ScorecardSourceError("NOW selector no longer establishes the complete all-state rendition")
    return {
        "items": items,
        **_grid(tables[0], chamber, items, populations, congress),
        "item_list_attributes": dict(dl.attrs),
        "item_list_prefix": [
            capwiz_html.native(anchor, "(//dl[@id='keyvotes'])[1]/a[1]") for anchor in dl.find_all("a", recursive=False)
        ],
        "context": _context(html, document.url, original, timestamp),
        "published_at": date,
        "updated_at": date,
    }


def _summary(document):
    html = _html(document, SUMMARY_URL, SUMMARY_TITLE, "2008-10-17")
    links = [
        a
        for a in html.select("a[href]")
        if a.get("href")
        in {
            "http://now.org/issues/election/elections2008/house_votes.html",
            "http://now.org/issues/election/elections2008/senate_votes.html",
        }
    ]
    if [(capwiz_html.text(a), a["href"].rsplit("/", 1)[1]) for a in links] != [
        ("House", "house_votes.html"),
        ("Senate", "senate_votes.html"),
        ("House of Representatives scorecard", "house_votes.html"),
        ("Senate scorecard", "senate_votes.html"),
    ]:
        raise ScorecardSourceError("NOW summary complete chamber links changed")
    statement = capwiz_html.text(html.body)
    if (
        "overall Sen. McCain was not present for nine of our scored votes, voted incorrectly on five and correct on two."
        not in statement
        or "Sen. Obama was recorded as not voting on five of the scored measures and had eleven correct votes."
        not in statement
    ):
        raise ScorecardSourceError("NOW summary candidate action witnesses changed")
    return _context(html, document.url, DIRECTORY_2008 + "scorecard.html", "20081023155712")


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition(selected.edition_id):
        raise ScorecardSourceError("NOW selected edition metadata conflicts with its named originals")
    congress = selected.congress
    if congress is None:
        raise ScorecardSourceError("NOW selected edition requires its source Congress")
    chambers = ("house", "senate") if selected.edition_id == EDITION_2008 else ("senate",)
    summary = context.read(SUMMARY_URL, stage="now:summary-original", hosts=HOSTS) if congress == "110" else None
    summary_facts = _summary(summary) if summary else None
    documents, facts, repeats = {}, {}, {}
    for chamber in chambers:
        documents[chamber] = context.read(_url(congress, chamber), stage="now:" + chamber + "-original", hosts=HOSTS)
        facts[chamber] = _facts(documents[chamber], congress, chamber)
    summary_repeat = context.read(SUMMARY_URL, stage="now:summary-reread", hosts=HOSTS) if summary else None
    if summary_repeat and _summary(summary_repeat) != summary_facts:
        raise ScorecardSourceError("NOW summary source facts changed on reread")
    for chamber in chambers:
        repeats[chamber] = context.read(_url(congress, chamber), stage="now:" + chamber + "-reread", hosts=HOSTS)
        if _facts(repeats[chamber], congress, chamber) != facts[chamber]:
            raise ScorecardSourceError("NOW complete chamber source facts changed on reread")
    if summary:
        senate = facts["senate"]["members"]
        for name, state, expected in (("McCain", "AZ", {"NV": 9, "-": 5, "+": 2}), ("Obama", "IL", {"NV": 5, "+": 11})):
            candidates = [member for member in senate if member["name"] == name and member["state"] == state]
            if len(candidates) != 1 or dict(Counter(candidates[0]["actions"])) != expected:
                raise ScorecardSourceError("NOW Senate rows conflict with the summary's literal candidate witnesses")
    primary = documents[chambers[0]]
    bundle = Bundle(
        selected,
        context,
        primary,
        publisher_name="National Organization for Women",
        parser_version=parser_version,
        rendition_rule="named-archive-complete-all-state-native-action-grids",
        homepage="https://now.org/",
    )
    period = congress + "th Congress, Combined Sessions"
    date = "2008-10-17" if congress == "110" else "2006-11-03"
    bundle.tables["scorecards"][0].update(
        edition_label_text=selected.title,
        source_path="(//h2)[2]",
        timespan_text=period,
        published_at_text=date,
        updated_at_text=date,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "native-combined-session-heading",
                    "kind": "explicit",
                    "period_text": period,
                    "congress_text": congress,
                    "source_path": "(//h2)[2]",
                }
            ]
        ),
    )
    if summary:
        if summary_repeat is None:
            raise ScorecardSourceError("NOW complete summary reread is missing")
        bundle.use(summary, "summary")
        bundle.use(summary_repeat, "summary", role="corroboration")
        bundle.add(
            "scorecard_methodologies",
            summary,
            "//body",
            methodology_id="summary-native-context",
            methodology_text=json_column(summary_facts),
            disclosure_status="explicit",
        )
    for chamber in chambers:
        document, grid = documents[chamber], facts[chamber]
        groups = (chamber + ":members", chamber + ":items", chamber + ":actions", chamber + ":context")
        bundle.use(document, *groups)
        bundle.use(repeats[chamber], *groups, *(("edition",) if chamber == chambers[0] else ()), role="corroboration")
        bundle.add(
            "scorecard_methodologies",
            document,
            "//body",
            methodology_id=key(chamber, "native-context"),
            chamber_text=chamber,
            methodology_text=json_column(grid["context"]),
            disclosure_status="explicit",
        )
        bundle.add(
            "scorecard_methodologies",
            document,
            grid["path"],
            methodology_id=key(chamber, "native-grid-context"),
            chamber_text=chamber,
            methodology_text=json_column(
                {
                    "table_attributes": grid["attributes"],
                    "headers_and_spacers": grid["headers"],
                    "item_list_attributes": grid["item_list_attributes"],
                    "item_list_prefix": grid["item_list_prefix"],
                }
            ),
            disclosure_status="explicit",
        )
        for item in grid["items"]:
            item_id = key(chamber, item["publisher_id"])
            bundle.add(
                "scorecard_items",
                document,
                item["path"],
                item_id=item_id,
                publisher_item_id=item["publisher_id"],
                item_kind_text="roll_call",
                title=item["title"],
                item_date_text=item["date"],
                congress_text=congress,
                chamber_text=chamber,
                session_text=item["session"],
                roll_number_text=item["roll"],
                references_json=json_column(item["references"]),
                publisher_position_text=item["position"],
                position_basis="explicit",
                position_source_path=item["description_path"],
            )
            bundle.add(
                "scorecard_methodologies",
                document,
                item["description_path"],
                methodology_id=key(chamber, "item", item["publisher_id"]),
                chamber_text=chamber,
                methodology_text=json_column(item),
                disclosure_status="explicit",
            )
        for member in grid["members"]:
            member_key = key(chamber, member["publisher_id"])
            bundle.add(
                "scorecard_members",
                document,
                member["path"],
                publisher_member_key=member_key,
                publisher_member_id=member["publisher_id"],
                identifiers_json="[]",
                member_name=member["name"],
                chamber_text=chamber,
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text=period,
                notes_text=json_column({field: value for field, value in member.items() if field != "actions"}),
            )
            for item, cell, action in zip(grid["items"], member["cells"][1:], member["actions"], strict=True):
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    cell["source_path"],
                    item_id=key(chamber, item["publisher_id"]),
                    publisher_member_key=member_key,
                    result_id="native-cell",
                    result_text=action,
                    reason_text=LEGEND[action],
                )
    rule = "Named archived originals reached closing HTML; complete all-state selectors, measured state populations, replacement occurrences, ordered repeated item links and literal malformed header attributes, every dated combined-session action and description, biography IDs, native action legends and authored context reconciled and reread unchanged."
    if summary:
        rule += " The 2008 summary candidate witnesses agree."
    return bundle.finish(rule + " No aggregate rating is reported.")
