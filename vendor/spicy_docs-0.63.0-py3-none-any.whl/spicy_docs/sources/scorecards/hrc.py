"""HRC's qualified final 118th Congress PDF, replayed from reviewed source facts.

This reader never runs a model or treats arbitrary model output as a source.
The caller supplies the exact privately retained qualification asset and retains
it again with this acquisition. A different PDF or observation asset refuses.
"""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.hrc_outcomes import HOUSE_ITEMS, RATING_PERIODS, SENATE_ITEMS, validate_outcome
from spicy_docs.sources.scorecards.qualified_observations import retain_qualified

parser_version = "hrc-118-qualified-gemini/2"
INDEX = "https://www.hrc.org/resources/congressional-scorecard"
PDF = "https://hrc-prod-requests.s3-us-west-2.amazonaws.com/files/documents/118th-Congressional-Scorecard-HRC-2024-Final.pdf"
HOSTS = ("www.hrc.org", "hrc-prod-requests.s3-us-west-2.amazonaws.com")
SOURCE_SHA256 = "804c1157e71da53a00821fdcaf15a1790448c682eb49d44613a577cfce9cb855"
QUALIFIED_SHA256 = "d8ac93e130bfb17bbb8657b6d25b6419bd79ca964fe03608a889b21c9385bebb"
EDITION = ScorecardEdition(
    "hrc", "118-final", INDEX, "CONGRESSIONAL SCORECARD", congress="118", chamber="both", is_current=False
)
RetainObservations = Callable[..., Mapping[str, object]]


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    """List the supported closed edition only, corroborated by the original index."""
    document = context.read(INDEX, stage="hrc:index", hosts=HOSTS)
    if PDF not in {a.get("href") for a in soup(document).select("a[href]")}:
        raise ScorecardSourceError("HRC index no longer states the qualified final 118th PDF")
    return (EDITION,)


@dataclass(frozen=True, slots=True)
class HRCReader:
    """An explicit host injection; raw structured observations require private retention.

    ``retain_observations(document, exact_bytes, stage=...)`` must retain the
    complete asset privately and return a fresh canonical UUID4 ``observation_id``.
    Never pass the public HTTP capture writer as this callback. The asset contains
    full source narratives, vacancy facts and locators to retained model evidence.
    """

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        return list_scorecards(context)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _qualified(body: bytes) -> dict:
    from jsonschema import ValidationError

    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("HRC structured observations do not match the reviewed qualification pin")
    # The exact bytes are pinned before parsing; arbitrary JSON is never admitted.
    try:
        data = json.loads(body)
        if data["format_version"] != "hrc-qualified-118/1" or data["source_sha256"] != SOURCE_SHA256:
            raise ValueError
        groups = ("members", "items", "notes", "result_definitions", "scoring_notes", "vacant_seats")
        if tuple(len(data[name]) for name in groups) != (540, 56, 31, 9, 1, 1):
            raise ValueError
        for name in groups:
            for entry in data[name]:
                evidence = entry["evidence"]
                if entry["chamber"] not in {"Senate", "House"}:
                    raise ValueError
                if not 1 <= evidence["physical_page"] <= 27 or not evidence["json_pointer"].startswith("/"):
                    raise ValueError
                if evidence["schema_version"] not in {"hrc-118-source-facts/2", "hrc-118-source-facts/3"}:
                    raise ValueError
                for field_name in ("outcome_sha256", "observation_sha256"):
                    if len(evidence[field_name]) != 64 or any(
                        c not in "0123456789abcdef" for c in evidence[field_name]
                    ):
                        raise ValueError
        for number in (4, 5, 6, *range(10, 27)):
            members = [e["record"] for e in data["members"] if e["evidence"]["physical_page"] == number]
            vacancies = [e["record"] for e in data["vacant_seats"] if e["evidence"]["physical_page"] == number]
            validate_outcome(
                number,
                {
                    "members": members,
                    "vacant_seats": vacancies,
                    "notes": [],
                    "scoring_notes": [],
                    "result_definitions": [],
                    "uncertainties": [],
                },
                member_grid_only=True,
            )
        identities = set()
        for entry in data["members"]:
            row, chamber = entry["record"], entry["chamber"]
            if not row["state_text"] or chamber != ("Senate" if entry["evidence"]["physical_page"] <= 6 else "House"):
                raise ValueError
            if chamber == "House" and not row["district_text"]:
                raise ValueError
            identity = (chamber, row["state_text"], row["district_text"], row["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
        for chamber, item_keys, note_count in (("Senate", SENATE_ITEMS, 7), ("House", HOUSE_ITEMS, 24)):
            if Counter(e["record"]["item_key"] for e in data["items"] if e["chamber"] == chamber) != Counter(item_keys):
                raise ValueError
            if Counter(e["record"]["marker_text"] for e in data["notes"] if e["chamber"] == chamber) != Counter(
                str(n) for n in range(1, note_count + 1)
            ):
                raise ValueError
            expected_glyphs = ("●", "○", "⊗", "P", "^") if chamber == "Senate" else ("●", "○", "⊗", "P")
            if Counter(
                e["record"]["result_text"] for e in data["result_definitions"] if e["chamber"] == chamber
            ) != Counter(expected_glyphs):
                raise ValueError
        notes = {(e["chamber"], e["record"]["marker_text"]) for e in data["notes"]}
        if any(
            (e["chamber"], marker) not in notes for e in data["members"] for marker in e["record"]["footnote_markers"]
        ):
            raise ValueError
    except (ValueError, TypeError, KeyError, IndexError, ValidationError):
        raise ScorecardSourceError("HRC qualified source scope is incomplete or inconsistent") from None
    return data


def _retain(document: SourceDocument, body: bytes, callback: RetainObservations) -> str:
    try:
        return retain_qualified(
            document,
            body,
            callback,
            source_sha256=SOURCE_SHA256,
            observations_sha256=QUALIFIED_SHA256,
            stage="hrc:qualified-observations",
        )
    except ScorecardSourceError:
        raise ScorecardSourceError("HRC qualified observations were not retained privately") from None


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
) -> ScorecardAcquisition:
    """Refuse changed/unqualified inputs; map only reviewed final-118 source facts."""
    if edition != EDITION:
        raise ScorecardSourceError("HRC reader supports only the qualified final 118th Congress edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("HRC requires pinned observations and an explicit private retention callback")
    data = _qualified(qualified_observations)
    document = context.read(PDF, stage="hrc:118-final-pdf", hosts=HOSTS)
    if document.url != PDF or sha256(document.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("HRC PDF differs from the independently qualified original")
    observation_id = _retain(document, qualified_observations, retain_observations)
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="Human Rights Campaign",
        parser_version=parser_version,
        rendition_rule="final-118 PDF; individually source-checked immutable semantic records; no model calls",
        homepage="https://www.hrc.org",
    )
    bundle.use(document, "members", "ratings", "items", "member-results", "source-notes")
    bundle.tables["scorecards"][0]["source_path"] = "pdf:page=1"
    bundle.tables["scorecards"][0]["edition_label_text"] = "118th Congress"

    def path(group: str, index: int, suffix: str = "") -> str:
        page = data[group][index]["evidence"]["physical_page"]
        return f"pdf:page={page};observation={observation_id};/{group}/{index}/record{suffix}"

    note_map = {(e["chamber"], e["record"]["marker_text"]): e["record"]["text"] for e in data["notes"]}
    legends = {
        (e["chamber"], e["record"]["result_text"]): e["record"]["meaning_text"] for e in data["result_definitions"]
    }
    for index, entry in enumerate(data["result_definitions"]):
        row = entry["record"]
        bundle.add(
            "scorecard_methodologies",
            document,
            path("result_definitions", index),
            methodology_id=key(entry["chamber"], "legend", row["result_text"]),
            chamber_text=entry["chamber"],
            cohort_text=row["result_text"],
            methodology_text=row["meaning_text"],
        )
    for index, entry in enumerate(data["scoring_notes"]):
        bundle.add(
            "scorecard_methodologies",
            document,
            path("scoring_notes", index),
            methodology_id=key(entry["chamber"], "scoring-note", str(index)),
            chamber_text=entry["chamber"],
            methodology_text=entry["record"],
        )
    for chamber in ("Senate", "House"):
        first = next(i for i, e in enumerate(data["members"]) if e["chamber"] == chamber)
        for period in RATING_PERIODS:
            rating_index = next(
                i for i, r in enumerate(data["members"][first]["record"]["ratings"]) if r["period_text"] == period
            )
            bundle.add(
                "scorecard_metrics",
                document,
                path("members", first, f"/ratings/{rating_index}/period_text"),
                metric_id=key(chamber, period),
                name=period,
                period_text=period,
                chamber_text=chamber,
            )
    for index, entry in enumerate(data["items"]):
        row, chamber = entry["record"], entry["chamber"]
        location = path("items", index)
        references = []
        for collection, kind in (("bill_citations", "bill"), ("amendment_citations", "amendment")):
            for number, citation in enumerate(row[collection]):
                references.append(
                    {
                        "occurrence_id": key(collection, str(number)),
                        "citation_text": citation,
                        "kind": kind,
                        "source_path": location + f"/{collection}/{number}",
                        "congress_text": row["congress_text"],
                        "chamber_text": chamber,
                    }
                )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=key(chamber, row["item_key"]),
            publisher_item_id=row["item_key"],
            title=row["title_text"],
            item_date_text=row["date_text"],
            congress_text=row["congress_text"],
            chamber_text=chamber,
            session_text=row["session_text"],
            roll_number_text=row["roll_number_text"],
            bill_citation_text=row["bill_citations"][0] if len(row["bill_citations"]) == 1 else None,
            amendment_citation_text=row["amendment_citations"][0] if len(row["amendment_citations"]) == 1 else None,
            references_json=json_column(references),
            publisher_position_text=row["publisher_target_text"],
            position_basis="explicit" if row["publisher_target_text"] else None,
            position_source_path=location + "/publisher_target_text" if row["publisher_target_text"] else None,
        )
    for index, entry in enumerate(data["members"]):
        row, chamber = entry["record"], entry["chamber"]
        member_key = key(chamber, row["state_text"], row["district_text"] or "no-district", row["member_name_text"])
        notes = "\n\n".join(note_map[(chamber, marker)] for marker in row["footnote_markers"]) or None
        bundle.add(
            "scorecard_members",
            document,
            path("members", index),
            publisher_member_key=member_key,
            identifiers_json="[]",
            member_name=row["member_name_text"],
            chamber_text=chamber,
            state=row["state_text"],
            district=row["district_text"],
            party=row["party_text"],
            notes_text=notes,
        )
        for number, rating in enumerate(row["ratings"]):
            value = rating["value_text"]
            historical_house = value.endswith("^")
            bundle.add(
                "scorecard_member_ratings",
                document,
                path("members", index, f"/ratings/{number}"),
                publisher_member_key=member_key,
                metric_id=key("House" if historical_house else chamber, rating["period_text"]),
                # Normalize the publisher's missing-value spelling in native
                # columns; the pinned observation retains the original NA.
                value_text="N/A" if value == "NA" else value,
                value_number=decimal_text(value),
                notes_text=legends[("Senate", "^")] if historical_house else None,
            )
        for number, result in enumerate(row["item_results"]):
            bundle.add(
                "scorecard_member_item_results",
                document,
                path("members", index, f"/item_results/{number}"),
                publisher_member_key=member_key,
                item_id=key(chamber, result["item_key"]),
                result_id="published",
                result_text=result["result_text"],
            )
    # Counts below are independently inspected source rows, never publisher-declared totals.
    return bundle.finish(
        "Exact qualified final-118 PDF and reviewed observation pins; complete physical-page scopes 3–26; "
        "100 Senate and 440 House named members, three period scores each, 15 Senate and 41 House "
        "item results per member; all 56 items, 31 endnotes and chamber legends retained. One NJ9 vacancy "
        "with three N/A ratings, 41 blank cells and note11 retained privately as a non-member disposition; "
        "excluded from member tables. Full item narratives and source-only notes remain in pinned observations. "
        "Standalone NA ratings normalize to N/A in native columns; original spelling remains in pinned observations. "
        "Cover/introduction/back-cover narrative outside typed scorecard scope remains in original PDF."
    )
