"""TCU/RCPL's recovered first-session 107th Congress Senate HTML record.

``railway_clerks`` retains the catalog identity; the edition names TCU and its
Responsible Citizens Political League (RCPL). IAM hosts the migrated original.
The reviewed TCU history dates the TCU name to 1987. Attribution and the gaps in
other recovered scopes are retained in the railway-clerks-reader-2001-v1 receipt.
"""

from __future__ import annotations

import re
from collections import Counter

from spicy_docs.schemas.tables import json_column

from .capwiz_html import authored_children, native, text
from .common import Bundle, ScorecardContext, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "tcu-rcpl-senate-107-1-native-html/2"
HOSTS = ("www.goiam.org", "www.tcunion.org")
GRID_URL = "https://www.goiam.org/news/us-senate-votes-1st-session/"
CAPTIONS_URL = "https://www.goiam.org/news/us-senate-captions/"
IDENTITY_URL = "https://www.goiam.org/news/what-is-rcpl/"
DEPARTMENT_URL = "https://www.tcunion.org/legislative-outlook/about-the-legislative-department/"
HOME = "https://www.tcunion.org/"
TITLE = "Votes During The 107th Congress, 1st Session"
CUMULATIVE = "Cumulative score is from the 90th Congress, 1st Session through the 107th Congress, 1st Session"
EDITION = ScorecardEdition(
    "railway_clerks", "107-1-senate", GRID_URL, TITLE, year="2001", congress="107", chamber="Senate", is_current=False
)

# Reviewed source sequence in C041, table[2]; this is a source-scope admission
# bound, not a reconstructed official roster or a publisher-declared count.
STATES = (
    "Alabama",
    "Alaska",
    "Arizona",
    "Arkansas",
    "California",
    "Colorado",
    "Connecticut",
    "Delaware",
    "Florida",
    "Georgia",
    "Hawaii",
    "Idaho",
    "Illinois",
    "Indiana",
    "Iowa",
    "Kansas",
    "Kentucky",
    "Louisiana",
    "Maine",
    "Maryland",
    "Massachusetts",
    "Michigan",
    "Minnesota",
    "Mississippi",
    "Missouri",
    "Montana",
    "Nebraska",
    "Nevada",
    "New Hampshire",
    "New Jersey",
    "New Mexico",
    "New York",
    "North Carolina",
    "North Dakota",
    "Ohio",
    "Oklahoma",
    "Oregon",
    "Pennsylvania",
    "Rhode Island",
    "South Carolina",
    "South Dakota",
    "Tennessee",
    "Texas",
    "Utah",
    "Vermont",
    "Virginia",
    "Washington",
    "West Virginia",
    "Wisconsin",
    "Wyoming",
)
LEGEND = (
    "Vote to support the RCPL position = R",
    "Vote to oppose the RCPL position = W",
    "Speaker exercised discretion not to vote = S",
    "Did not vote = ?",
    "Announced for = +",
    "Announced against = –",
    "Not eligible to vote at time = I",
    "Voted Present = P",
    "At-Large = AL",
)
MARKS = frozenset({"R", "W", "S", "?", "+", "–", "I", "P"})
MARK_MEANINGS = {line.rsplit(" = ", 1)[1]: line for line in LEGEND}
HEADERS = [""] + ["Vote #" + str(n) for n in range(1, 12)] + ["Right", "Wrong", "Right", "Wrong"]
CITATION = re.compile(r"(?<!\w)(?:S\.?\s*(?:J\.?\s*Res\.?\s*)?|H\.?\s*R\.?)\s*\d+\b")
DATE = re.compile(r"\bOn\s+([A-Z][a-z]+ \d{1,2}, 2001)\b")
POSITION = re.compile(r"\bA vote\b.+? is a right \(R\) vote\.")
CONTENT_PATH = "//div[@class='text wysiwyg']"


def _one(node, selector):
    selected = node.select(selector)
    if len(selected) != 1:
        raise ScorecardSourceError("TCU/RCPL required source structure is missing or repeated: " + selector)
    return selected[0]


def _page(document, url, heading, *, department=False):
    if document.url != url or b"</html>" not in document.body.lower():
        raise ScorecardSourceError("TCU/RCPL complete original HTML route is missing")
    parsed = soup(document)
    if _one(parsed, "link[rel='canonical']").get("href") != url:
        raise ScorecardSourceError("TCU/RCPL canonical source route changed")
    if text(_one(parsed, "h1")) != heading:
        raise ScorecardSourceError("TCU/RCPL selected source heading changed")
    content = _one(parsed, ".entry-content" if department else "div.text.wysiwyg")
    date = _one(parsed, "time" if department else ".entry-date")
    return content, {"page_heading_text": heading, "displayed_cms_date_text": text(date)}


def _authored(content):
    # The observed WordPress sharing plugin is outside the migrated article.
    # Every other direct authored child remains in the source inventory.
    return [
        child
        for child in authored_children(content, {"p", "table", "div"}, publisher="TCU/RCPL")
        if child.name != "div" or child.get("class") != ["sfsiaftrpstwpr"]
    ]


def _cell(node, path):
    return {**native(node, path), "literal_text": node.get_text("", strip=False)}


def _row(row, path):
    cells = authored_children(row, {"td", "th"}, publisher="TCU/RCPL")
    return {
        "source_path": path,
        "attributes": dict(row.attrs),
        "cells": [_cell(cell, path + "/" + cell.name + "[" + str(n) + "]") for n, cell in enumerate(cells, 1)],
    }, cells


def _grid(document):
    content, context = _page(document, GRID_URL, "US Senate Votes 1st Session")
    children = _authored(content)
    if [child.name for child in children] != ["p", "p", "p", "p", "table", "table"]:
        raise ScorecardSourceError("TCU/RCPL Senate authored context or tables changed")
    paragraphs = children[:4]
    if (
        text(paragraphs[0])
        or [image.get("src") for image in paragraphs[0].select("img")] != ["images/tcu/senatevotes_head.gif"]
        or text(paragraphs[1]) != TITLE
        or text(paragraphs[2]) != CUMULATIVE
        or text(paragraphs[3]) != "Key to Votes:"
    ):
        raise ScorecardSourceError("TCU/RCPL Senate period, cumulative bound or legend heading changed")
    context["paragraphs"] = [_cell(p, CONTENT_PATH + "/p[" + str(n) + "]") for n, p in enumerate(paragraphs, 1)]
    legend_rows = authored_children(children[4], {"tr"}, publisher="TCU/RCPL")
    legend = [_row(row, CONTENT_PATH + "/table[1]/tr[" + str(n) + "]") for n, row in enumerate(legend_rows, 1)]
    if (
        len(legend) != len(LEGEND)
        or any(len(cells) != 2 or text(cells[0]) != "·" for _, cells in legend)
        or tuple(text(cells[1]) for _, cells in legend) != LEGEND
    ):
        raise ScorecardSourceError("TCU/RCPL Senate original mark legend changed")
    context["legend_rows"] = [row for row, _ in legend]
    rows = authored_children(children[5], {"tr"}, publisher="TCU/RCPL")
    if len(rows) != 3 + len(STATES) * 3:
        raise ScorecardSourceError("TCU/RCPL complete Senate source row inventory changed")
    retained = [_row(row, CONTENT_PATH + "/table[2]/tr[" + str(n) + "]") for n, row in enumerate(rows, 1)]
    display = [[text(cell) for cell in cells] for _, cells in retained]
    if display[:3] != [["", "1st Session", "Cumulative"], [""], HEADERS]:
        raise ScorecardSourceError("TCU/RCPL Senate action or total headers changed")
    context["grid_headers"] = [row for row, _ in retained[:3]]
    members, states = [], []
    for state_index, expected_state in enumerate(STATES):
        start = 3 + state_index * 3
        state_row, _state_cells = retained[start]
        if display[start] != [expected_state] + [""] * 15:
            raise ScorecardSourceError("TCU/RCPL Senate source state headings or order changed")
        states.append(state_row)
        for offset in (1, 2):
            row, cells = retained[start + offset]
            values = display[start + offset]
            match = re.fullmatch(r"(.+) \(([DRI])\)", values[0]) if values else None
            if (
                len(cells) != 16
                or match is None
                or any(value not in MARKS for value in values[1:12])
                or any(re.fullmatch(r"\d+", value) is None for value in values[12:])
            ):
                raise ScorecardSourceError("TCU/RCPL Senate member name, literal marks or row width changed")
            # This is a source consistency check. Special marks have no numerical
            # contribution, and neither percentages nor cumulative totals are derived.
            counts = Counter(values[1:12])
            if values[12:14] != [str(counts["R"]), str(counts["W"])]:
                raise ScorecardSourceError("TCU/RCPL Senate source session totals conflict with literal R/W cells")
            members.append(
                {
                    **row,
                    "state": expected_state,
                    "state_source_path": state_row["source_path"],
                    "member_name": match[1],
                    "party": match[2],
                    "display": values[0],
                    "values": values[1:],
                    "occurrence": str(start + offset + 1),
                }
            )
    context["state_headers"] = states
    return {"context": context, "members": members}


def _captions(document):
    content, context = _page(document, CAPTIONS_URL, "US Senate Captions")
    children = _authored(content)
    if [child.name for child in children] != ["p", "p", "p", "table"]:
        raise ScorecardSourceError("TCU/RCPL complete Senate caption context changed")
    if (
        [image.get("src") for image in children[0].select("img")] != ["images/tcu/poitical_heading.gif"]
        or [image.get("src") for image in children[1].select("img")] != ["images/tcu/senatecaption_head.gif"]
        or text(children[0])
        or text(children[1])
        or text(children[2]) != "THE FIRST SESSION OF THE 107 TH CONGRESS"
    ):
        raise ScorecardSourceError("TCU/RCPL captions do not identify the selected Senate session")
    context["paragraphs"] = [_cell(p, CONTENT_PATH + "/p[" + str(n) + "]") for n, p in enumerate(children[:3], 1)]
    rows = authored_children(children[3], {"tr"}, publisher="TCU/RCPL")
    if len(rows) != 11:
        raise ScorecardSourceError("TCU/RCPL complete numbered Senate caption inventory changed")
    items = []
    for ordinal, row in enumerate(rows, 1):
        path = CONTENT_PATH + "/table[1]/tr[" + str(ordinal) + "]"
        retained, cells = _row(row, path)
        if len(cells) != 2 or text(cells[0]) != str(ordinal) + ".":
            raise ScorecardSourceError("TCU/RCPL Senate caption ordinals or cells changed")
        paragraphs = authored_children(cells[1], {"p"}, publisher="TCU/RCPL")
        if len(paragraphs) != 1:
            raise ScorecardSourceError("TCU/RCPL complete Senate caption paragraph changed")
        paragraph = paragraphs[0]
        # Concatenate authored inline runs before collapsing HTML whitespace.
        # WordPress splits individual words and punctuation across b/u elements.
        description = " ".join(paragraph.get_text("", strip=False).split())
        divider = re.search(r"\s*[–-]\s*(?=Using\b|Motion\b|An amendment\b|The Senate\b|Senator\b)", description)
        positions, dates = POSITION.findall(description), DATE.findall(description)
        if divider is None or len(positions) != 1 or len(dates) != 1:
            raise ScorecardSourceError("TCU/RCPL Senate caption title, explicit right-vote statement or date changed")
        refs = []
        for occurrence, match in enumerate(CITATION.finditer(description), 1):
            refs.append(
                {
                    "occurrence_id": "caption-bill-" + str(occurrence),
                    "kind": "bill",
                    "citation_text": match.group(),
                    "bill_citation_text": match.group(),
                    "source_path": path + "/td[2]/p",
                }
            )
        links = []
        for occurrence, link in enumerate(paragraph.select("a[href]"), 1):
            link_path = path + "/td[2]/p//a[" + str(occurrence) + "]"
            links.append({**_cell(link, link_path), "href": link["href"]})
            refs.append(
                {
                    "occurrence_id": "caption-link-" + str(occurrence),
                    "kind": "publisher_link",
                    "citation_text": link["href"],
                    "source_path": link_path + "/@href",
                }
            )
        items.append(
            {
                **retained,
                "ordinal": str(ordinal),
                "title": description[: divider.start()].strip(),
                "description": description,
                "date": dates[0],
                "position": positions[0],
                "references": refs,
                "links": links,
            }
        )
    return {"context": context, "items": items}


def _identity(document):
    content, context = _page(document, IDENTITY_URL, "What is RCPL")
    paragraphs = [node for node in _authored(content) if node.name == "p"]
    matches = [
        (n, p)
        for n, p in enumerate(paragraphs, 1)
        if "the Responsible Citizens Political League (RCPL)" in text(p)
        and "TCU International President" in text(p)
        and "represents the interests of TCU members" in text(p)
    ]
    if len(matches) != 1:
        raise ScorecardSourceError("TCU/RCPL publisher identity witness changed")
    n, paragraph = matches[0]
    return {**context, "source_witness": _cell(paragraph, CONTENT_PATH + "/p[" + str(n) + "]")}


def _department(document):
    content, context = _page(document, DEPARTMENT_URL, "About the Legislative Department", department=True)
    paragraphs = content.find_all("p", recursive=False)
    matches = [
        (n, p)
        for n, p in enumerate(paragraphs, 1)
        if "Voting Records and Candidate Endorsements" in text(p)
        and "during each session of Congress" in text(p)
        and "RCPL voting records" in text(p)
        and "TCU members" in text(p)
    ]
    if len(matches) != 1:
        raise ScorecardSourceError("TCU/RCPL publisher preparation witness changed")
    n, paragraph = matches[0]
    return {**context, "source_witness": _cell(paragraph, "//div[@class='entry-content']/p[" + str(n) + "]")}


def _read(context, *, repeat=False):
    selected = (
        ("grid", GRID_URL, _grid),
        ("captions", CAPTIONS_URL, _captions),
        ("identity", IDENTITY_URL, _identity),
        ("department", DEPARTMENT_URL, _department),
    )
    documents, facts = {}, {}
    for role, url, parser in selected:
        document = context.read(url, stage="tcu-rcpl:" + role + (":reread" if repeat else ""), hosts=HOSTS)
        documents[role], facts[role] = document, parser(document)
    return documents, facts


def list_scorecards(context: ScorecardContext):
    _read(context)
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("TCU/RCPL supports only the qualified first-session 107th Congress Senate scope")
    documents, facts = _read(context)
    repeats, repeated = _read(context, repeat=True)
    if facts != repeated:
        raise ScorecardSourceError("TCU/RCPL source facts changed during acquisition")
    grid, captions = documents["grid"], documents["captions"]
    bundle = Bundle(
        edition,
        context,
        grid,
        publisher_name="TCU",
        parser_version=parser_version,
        rendition_rule="Migrated TCU/RCPL original Senate grid and same-session captions; source-time publisher witnesses, literal cells and stable authored rereads.",
        homepage=HOME,
    )
    groups = {
        "grid": "senate-grid",
        "captions": "senate-captions",
        "identity": "publisher-identity",
        "department": "publisher-preparation",
    }
    for role, group in groups.items():
        bundle.use(documents[role], group)
        bundle.use(repeats[role], group, role="corroboration")
    bundle.use(repeats["grid"], "edition", role="corroboration")
    publisher = bundle.tables["scorecard_publishers"][0]
    publisher.update(
        abbreviation="TCU",
        aliases_json=json_column(["Responsible Citizens Political League", "RCPL"]),
        capture_id=documents["identity"].capture_id,
        source_url=IDENTITY_URL,
        source_path=facts["identity"]["source_witness"]["source_path"],
    )
    bundle.tables["scorecards"][0].update(
        series_id="rcpl",
        publisher_edition_key=None,
        session_text="1",
        edition_label_text=TITLE,
        timespan_text=TITLE,
        methodology_url=GRID_URL,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "publisher-session",
                    "period_text": TITLE,
                    "kind": "explicit",
                    "congress_text": "107",
                    "session_text": "1",
                    "chamber_text": "Senate",
                    "source_path": CONTENT_PATH + "/p[2]",
                }
            ]
        ),
    )
    for role in ("identity", "department"):
        source = documents[role]
        bundle.add(
            "scorecard_methodologies",
            source,
            facts[role]["source_witness"]["source_path"],
            methodology_id="publisher-" + role,
            disclosure_status="Source-time TCU/RCPL attribution",
            methodology_text=json_column(
                {**facts[role], "catalog_publisher_id": "railway_clerks", "current_migration_host": "IAM Union"}
            ),
            methodology_url=source.url,
        )
    bundle.add(
        "scorecard_methodologies",
        grid,
        CONTENT_PATH,
        methodology_id="grid-context",
        chamber_text="Senate",
        disclosure_status="Literal mark legend, session and cumulative counts; no disclosed percentage formula",
        methodology_text=json_column(
            {
                **facts["grid"]["context"],
                "period_basis": "Explicit Congress/session heading; calendar year 2001 is also stated in the paired caption dates. The displayed CMS date does not establish first publication.",
                "cumulative_period_text": CUMULATIVE,
                "consistency_check": "Only literal R and W occurrence counts are compared with stated session Right and Wrong totals. No special-mark, percentage or cumulative calculation is made.",
            }
        ),
        methodology_url=GRID_URL,
    )
    bundle.add(
        "scorecard_methodologies",
        captions,
        CONTENT_PATH,
        methodology_id="captions-context",
        chamber_text="Senate",
        disclosure_status="Same-session Senate caption heading; migrated CMS date retained separately",
        methodology_text=json_column(facts["captions"]["context"]),
        methodology_url=CAPTIONS_URL,
    )
    metrics = ("session-right", "session-wrong", "cumulative-right", "cumulative-wrong")
    for offset, metric in enumerate(metrics, 13):
        label = "Right" if metric.endswith("right") else "Wrong"
        period = TITLE if metric.startswith("session") else CUMULATIVE
        bundle.add(
            "scorecard_metrics",
            grid,
            CONTENT_PATH + "/table[2]/tr[3]/td[" + str(offset) + "]",
            metric_id=metric,
            methodology_id="grid-context",
            name=label,
            chamber_text="Senate",
            period_text=period,
            periods_json="[]",
            is_primary=None,
        )
    for item in facts["captions"]["items"]:
        ordinal, path = item["ordinal"], item["source_path"]
        bills = [ref["citation_text"] for ref in item["references"] if ref["kind"] == "bill"]
        bundle.add(
            "scorecard_items",
            captions,
            path + "/td[2]/p",
            item_id=ordinal,
            publisher_item_id=ordinal,
            title=item["title"],
            item_date_text=item["date"],
            congress_text="107",
            session_text="1",
            chamber_text="Senate",
            bill_citation_text=bills[0] if len(bills) == 1 else None,
            references_json=json_column(item["references"]),
            publisher_position_text=item["position"],
            position_basis="explicit",
            position_source_path=path + "/td[2]/p",
        )
        bundle.add(
            "scorecard_methodologies",
            captions,
            path,
            methodology_id=key("caption", ordinal),
            chamber_text="Senate",
            disclosure_status="Complete literal numbered action caption and explicit right-vote statement",
            methodology_text=json_column(item),
            methodology_url=CAPTIONS_URL,
        )
    for member in facts["grid"]["members"]:
        path = member["source_path"]
        identity = key("Senate", member["state"], member["display"], "row-" + member["occurrence"])
        bundle.add(
            "scorecard_members",
            grid,
            path + "/td[1]",
            publisher_member_key=identity,
            identifiers_json="[]",
            member_name=member["member_name"],
            state=member["state"],
            party=member["party"],
            chamber_text="Senate",
            period_text=TITLE,
            # Keep the original cell syntax once; mapped identity, marks and
            # printed totals already have their own source-backed columns.
            notes_text=json_column(
                {
                    field: member[field]
                    for field in ("source_path", "attributes", "cells", "state_source_path", "occurrence")
                }
            ),
        )
        for ordinal, mark in enumerate(member["values"][:11], 1):
            bundle.add(
                "scorecard_member_item_results",
                grid,
                path + "/td[" + str(ordinal + 1) + "]",
                item_id=str(ordinal),
                publisher_member_key=identity,
                result_id="source-cell",
                result_text=mark,
                reason_text=MARK_MEANINGS[mark],
            )
        for offset, (metric, value) in enumerate(zip(metrics, member["values"][11:], strict=True), 13):
            bundle.add(
                "scorecard_member_ratings",
                grid,
                path + "/td[" + str(offset) + "]",
                metric_id=metric,
                publisher_member_key=identity,
                value_text=value,
                value_number=value,
            )
    return bundle.finish(
        "Qualified first-session 107th Congress Senate source scope: exact reviewed state-heading order, two full-width member occurrences per state, ordinal action columns matched to same-session captions, original legend and all four printed totals retained. Authored source facts and attribution witnesses agree on reread. Counts are observed publisher occurrences; official roster completeness and other editions are not asserted.",
        declared={"publisher_declared_member_count": None, "publisher_declared_item_count": None},
    )
