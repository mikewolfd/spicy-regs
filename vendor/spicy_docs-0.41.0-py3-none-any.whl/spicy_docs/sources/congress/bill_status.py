"""Read source fields and offered text versions from one GovInfo BILLSTATUS XML.

The caller retains the original XML for fields outside this small typed subset.
Publisher strings, ordering, duplicate actions, and summary HTML remain intact.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from xml.etree.ElementTree import Element

from rulespec_artifacts import canonical_json_bytes

from spicy_docs.reading.xml import parse_xml

BILL_TYPES = frozenset({"hr", "s", "hjres", "sjres", "hconres", "sconres", "hres", "sres"})
BILLSTATUS_BULKDATA = "https://www.govinfo.gov/bulkdata/BILLSTATUS"
_PACKAGE = re.compile(r"BILLS-([1-9][0-9]*)(hconres|sconres|hjres|sjres|hres|sres|hr|s)([1-9][0-9]*)([a-z][a-z0-9]*)")
_PACKAGE_URL = re.compile(
    r"https://www\.govinfo\.gov/content/pkg/(?P<package>BILLS-[A-Za-z0-9]+)/"
    r"(?P<format>xml|pdf|html|text)/(?P=package)\.(?P<extension>xml|pdf|htm|txt)"
)
DEFAULT_MAX_BYTES = 16 * 1024 * 1024


class BillSourceError(ValueError):
    """A response cannot establish the requested bill or text version."""


@dataclass(frozen=True, slots=True)
class BillIdentity:
    """A requested measure; construction refuses a non-positive Congress or number and an unsupported type."""

    congress: int
    bill_type: str
    number: int

    def __post_init__(self) -> None:
        if type(self.congress) is not int or self.congress <= 0:
            raise BillSourceError("congress must be a positive integer")
        if type(self.number) is not int or self.number <= 0:
            raise BillSourceError("bill number must be a positive integer")
        if not isinstance(self.bill_type, str) or self.bill_type not in BILL_TYPES:
            raise BillSourceError("bill_type must be a supported lowercase bill or resolution type")


@dataclass(frozen=True, slots=True)
class RecordedVote:
    """One ``<recordedVote>`` on an action: the publisher's reference to a roll call.

    Every field is optional (the guide lists seven children and names none
    required). ``full_action_name`` was absent from all 58 measured JSON
    entries but is carried anyway: the guide documents it, and a field the
    publisher may resume sending is not ours to drop.
    """

    chamber: str | None
    congress: str | None
    date: str | None
    full_action_name: str | None
    roll_number: str | None
    session_number: str | None
    url: str | None


@dataclass(frozen=True, slots=True)
class BillLaw:
    """One ``<laws>`` entry. ``type`` is "Public Law" or "Private Law" per the guide.

    The guide notes the element is empty until a measure is enacted and its
    law number assigned, so an absent ``laws`` is the ordinary case, not a
    gap.
    """

    number: str | None
    type: str | None


@dataclass(frozen=True, slots=True)
class BillTitle:
    """One ``<titles>`` entry: an official, short or display title, versioned by chamber and text version.

    Every field is optional because the guide names none required (a display
    title carries only ``titleType`` and ``title``). ``title`` reads
    ``<title>`` first and falls back to the guide's ``<latestTitle>``
    spelling, which no measured record uses.
    """

    title: str | None
    title_type: str | None
    chamber_code: str | None
    chamber_name: str | None
    bill_text_version_code: str | None
    bill_text_version_name: str | None
    update_date: str | None


@dataclass(frozen=True, slots=True)
class RelatedBill:
    """One ``<relatedBills>`` entry: another same-Congress measure and how CRS or a chamber linked it.

    The guide names this item's title child ``latestTitle``, but live
    BILLSTATUS states ``<title>``, so ``title`` reads ``<title>`` first and
    falls back to ``<latestTitle>``. ``relationship_details_json`` keeps every
    ``relationshipDetails`` item's ``identifiedBy``/``type`` verbatim as
    canonical JSON, because a related bill can carry more than one and
    flattening would drop the others.
    """

    congress: str | None
    bill_type: str | None
    number: str | None
    title: str | None
    latest_action_date: str | None
    latest_action_text: str | None
    relationship_details_json: str


@dataclass(frozen=True, slots=True)
class CboCostEstimate:
    """One ``<cboCostEstimates>`` item: CBO's own row about one scored printing.

    The guide is stale here and the live files govern: both its spellings
    (``rptPubDate``/``rptTitle``/``rptUrl``) and the live ones
    (``pubDate``/``title``/``url``/``description``) are read, live first, the
    same way :func:`_title_text` handles the guide's ``latestTitle``; a field
    the publisher may resume sending is not ours to drop. ``description`` is
    the only field that distinguishes two estimates of one bill. The element
    is never emitted empty, so a bill without it is either never scored or not
    yet linked: a caller records requested-empty, never absence.
    """

    pub_date: str | None
    title: str | None
    url: str | None
    description: str | None


@dataclass(frozen=True, slots=True)
class BillCommittee:
    """One committee or subcommittee the measure reached.

    ``system_code`` is the publisher's own identifier (``hsap00``) and what a
    referral rule keys on; a committee's ``name`` is prose and is not.
    ``chamber`` and ``type`` are absent on a subcommittee, and activities are
    not read here; the caller retains the XML for fields outside this subset.
    """

    system_code: str | None
    name: str | None
    chamber: str | None
    type: str | None
    subcommittees: tuple[BillCommittee, ...] = ()


@dataclass(frozen=True, slots=True)
class BillAction:
    """``text`` is ``None`` when the publisher states the action without one.

    An absent ``<text>`` and one present but blank both read as ``None`` --
    two states, not three, because a blank element states no action text any
    more than a missing one does. Text that is there is kept exactly as
    written, interior and surrounding whitespace included. Refusing a
    document over an absent optional field would lose the bill entirely.
    """

    text: str | None
    action_date: str | None
    action_time: str | None
    action_code: str | None
    action_type: str | None
    source_system_code: str | None
    source_system_name: str | None
    recorded_votes: tuple[RecordedVote, ...] = ()


@dataclass(frozen=True, slots=True)
class BillSponsor:
    bioguide_id: str | None
    full_name: str | None


@dataclass(frozen=True, slots=True)
class BillSummary:
    """``text`` is the summary as the publisher escaped it, from either placement.

    Most summaries carry ``<text>`` directly; some carry it inside a
    ``<cdata>`` wrapper, and both placements are current and escape
    differently. The XML reader resolves both forms and this module decodes
    nothing itself, so the value is the same HTML either way.
    """

    text: str
    version_code: str | None
    action_date: str | None
    action_desc: str | None
    update_date: str | None


@dataclass(frozen=True, slots=True)
class BillTextFormat:
    url: str
    type: str | None
    package_id: str | None


@dataclass(frozen=True, slots=True)
class BillTextVersion:
    type: str | None
    date: str | None
    formats: tuple[BillTextFormat, ...]
    package_id: str | None


@dataclass(frozen=True, slots=True)
class BillStatus:
    """The parsed document; fields are literal publisher strings in publisher order.

    ``cbo_cost_estimates_outcome`` and ``cosponsors`` use ``None`` for "not
    read", never for an observed empty.
    """

    identity: BillIdentity
    schema_version: str
    title: str
    origin_chamber: str | None
    introduced_date: str | None
    update_date: str | None
    update_date_including_text: str | None
    legislation_url: str | None
    latest_action: BillAction | None
    policy_area: str | None
    subjects: tuple[str, ...]
    summaries: tuple[BillSummary, ...]
    actions: tuple[BillAction, ...]
    sponsors: tuple[BillSponsor, ...]
    text_versions: tuple[BillTextVersion, ...]
    laws: tuple[BillLaw, ...] = ()
    committees: tuple[BillCommittee, ...] = ()
    titles: tuple[BillTitle, ...] = ()
    related_bills: tuple[RelatedBill, ...] = ()
    cbo_cost_estimates: tuple[CboCostEstimate, ...] = ()
    #: Every ``<committeeReports>`` citation, in publisher order, exactly as
    #: written ("H. Rept. 118-53", "H. Rept. 118-4, Part 1"). Every one of the
    #: 1,153 items in the two measured zips states exactly one ``<citation>``
    #: and nothing else, so this is a tuple of strings rather than a record.
    #: It is what says whether a bill's CBO estimate is reachable as *text*:
    #: the letter is reprinted in the committee report or nowhere.
    report_citations: tuple[str, ...] = ()
    #: NULL means this block was not read. Empty observations name the XML
    #: shape, never whether CBO produced an estimate. Published per bill.
    cbo_cost_estimates_outcome: str | None = None
    #: The publisher lists cosponsors separately from sponsors. None means a
    #: caller-created status has not examined this list; parsed XML always
    #: supplies a tuple, including an empty tuple when no items are listed.
    cosponsors: tuple[BillSponsor, ...] | None = None


def _validated_identity(identity: BillIdentity) -> BillIdentity:
    if not isinstance(identity, BillIdentity):
        raise BillSourceError("identity must be a BillIdentity")
    return identity


def bill_status_locator(identity: BillIdentity) -> str:
    """Return a locator, without asserting that the publisher serves it."""
    _validated_identity(identity)
    return (
        f"{BILLSTATUS_BULKDATA}/{identity.congress}/{identity.bill_type}/"
        f"BILLSTATUS-{identity.congress}{identity.bill_type}{identity.number}.xml"
    )


def _package_version(identity: BillIdentity, package_id: str) -> str:
    _validated_identity(identity)
    match = _PACKAGE.fullmatch(package_id) if isinstance(package_id, str) else None
    if match is None:
        raise BillSourceError("bill text package ID is malformed")
    congress, bill_type, number, version = match.groups()
    if (congress, bill_type, number) != (str(identity.congress), identity.bill_type, str(identity.number)):
        raise BillSourceError("bill text package identity differs from the requested bill")
    return version


def bill_xml_locator(identity: BillIdentity, package_id: str) -> str:
    """Return a version's XML locator; selection still requires an offered link."""
    _package_version(identity, package_id)
    return f"https://www.govinfo.gov/content/pkg/{package_id}/xml/{package_id}.xml"


def bill_package_id_from_url(identity: BillIdentity, url: str) -> str | None:
    """Return the package id a canonical GovInfo format URL names, or None for any other link."""
    _validated_identity(identity)
    match = _PACKAGE_URL.fullmatch(url)
    if match is None:
        return None
    if {"xml": "xml", "pdf": "pdf", "html": "htm", "text": "txt"}[match["format"]] != match["extension"]:
        return None
    _package_version(identity, match["package"])
    return match["package"]


def select_bill_xml(status: BillStatus, package_id: str) -> tuple[BillTextVersion, BillTextFormat]:
    """Select exactly one XML link explicitly offered for the requested package."""
    locator = bill_xml_locator(status.identity, package_id)
    matches = [
        (version, format_) for version in status.text_versions for format_ in version.formats if format_.url == locator
    ]
    if len(matches) != 1:
        raise BillSourceError("requested bill text XML must be offered exactly once in BILLSTATUS")
    return matches[0]


def _xml_root(body: bytes, max_bytes: int, *, allow_external_doctype: bool = False) -> Element:
    return parse_xml(
        body,
        max_bytes=max_bytes,
        error_type=BillSourceError,
        label="bill XML",
        allow_external_doctype=allow_external_doctype,
    )


def _one(parent: Element | None, name: str, *, required: bool = False) -> Element | None:
    elements = [] if parent is None else parent.findall(name)
    if len(elements) > 1 or (required and not elements):
        raise BillSourceError(f"bill XML requires one {name} element")
    return elements[0] if elements else None


def _text(parent: Element | None, name: str, *, required: bool = False) -> str | None:
    element = _one(parent, name, required=required)
    if element is None:
        return None
    if len(element):
        raise BillSourceError(f"bill XML {name} must be a text leaf")
    value = element.text or ""
    if required and not value.strip():
        raise BillSourceError(f"bill XML {name} must contain text")
    return value


def _required_text(parent: Element | None, name: str) -> str:
    value = _text(parent, name, required=True)
    assert value is not None
    return value


def _items(parent: Element | None, name: str, item_tag: str = "item") -> tuple[Element, ...]:
    container = _one(parent, name)
    if container is None:
        return ()
    if (container.text or "").strip() or any(child.tag != item_tag for child in container):
        raise BillSourceError(f"bill XML {name} has an unsupported list shape")
    return tuple(container)


def _summary(element: Element) -> BillSummary:
    """Read the summary's text where the publisher put it, directly or in ``<cdata>``.

    A summary that states text in both places is refused: nothing in the
    publisher's guide says which would win, and none of the 40,260 files
    measured across the 108th, 113th and 119th Congresses does it.
    """
    wrapper = _one(element, "cdata")
    in_cdata = wrapper is not None and bool(wrapper.findall("text"))
    if in_cdata and element.findall("text"):
        raise BillSourceError("bill XML summary states its text twice")
    return BillSummary(
        text=_required_text(wrapper if in_cdata else element, "text"),
        version_code=_text(element, "versionCode"),
        action_date=_text(element, "actionDate"),
        action_desc=_text(element, "actionDesc"),
        update_date=_text(element, "updateDate"),
    )


def _recorded_vote(element: Element) -> RecordedVote:
    return RecordedVote(
        chamber=_text(element, "chamber"),
        congress=_text(element, "congress"),
        date=_text(element, "date"),
        full_action_name=_text(element, "fullActionName"),
        roll_number=_text(element, "rollNumber"),
        session_number=_text(element, "sessionNumber"),
        url=_text(element, "url"),
    )


def _measured_or_documented(element: Element, measured: str, documented: str) -> str | None:
    """Read the spelling the live files use, falling back to the guide's own.

    The user guide is stale in more than one place and the corpus is the
    authority, so every such field reads the measured name first and the
    documented name only when the measured one is absent. The fallback is
    never a guess: it is the name the publisher's own guide prints, so a
    record that ever does use it yields the value instead of ``None``.
    """
    value = _text(element, measured)
    return value if value is not None else _text(element, documented)


def _title_text(element: Element) -> str | None:
    """Read ``<title>``, falling back to ``<latestTitle>``, the guide's own spelling for it.

    Every live BILLSTATUS measured (108th, 113th and 119th Congresses) states
    ``<title>`` and never ``<latestTitle>``, inside ``<titles>`` and
    ``<relatedBills>`` alike.
    """
    return _measured_or_documented(element, "title", "latestTitle")


def _cbo_cost_estimate(element: Element) -> CboCostEstimate:
    """One ``<cboCostEstimates>`` item under either spelling; see :class:`CboCostEstimate`."""
    return CboCostEstimate(
        pub_date=_measured_or_documented(element, "pubDate", "rptPubDate"),
        title=_measured_or_documented(element, "title", "rptTitle"),
        url=_measured_or_documented(element, "url", "rptUrl"),
        description=_text(element, "description"),
    )


def _cbo_cost_estimates(bill: Element) -> tuple[tuple[CboCostEstimate, ...], str]:
    """Keep the observed list shape even when it cannot supply estimate rows.

    Shape labels contain no source text, attribute values or locators. The
    retained XML supplies those observations; a published marker must never
    copy a credential from an unexpected answer.
    """
    containers = bill.findall("cboCostEstimates")
    if not containers:
        return (), "requested-empty:absent"
    if len(containers) != 1:
        return (), "requested-empty:unexpected-shape:multiple-containers"
    container = containers[0]
    problem = None
    if container.attrib:
        problem = "container-attributes"
    elif (container.text or "").strip():
        problem = "container-text"
    elif any(item.tag != "item" for item in container):
        problem = "non-item-child"
    elif any((item.tail or "").strip() for item in container):
        problem = "container-mixed-text"
    if problem:
        return (), f"requested-empty:unexpected-shape:{problem}"
    if not len(container):
        return (), "requested-empty:present-and-empty"
    fields = {"pubDate", "title", "url", "description", "rptPubDate", "rptTitle", "rptUrl"}
    for item in container:
        if item.attrib:
            problem = "item-attributes"
        elif (item.text or "").strip():
            problem = "item-text"
        elif any(field.tag not in fields for field in item):
            problem = "unknown-item-field"
        elif len({field.tag for field in item}) != len(item):
            problem = "duplicate-item-field"
        elif any(len(field) or field.attrib for field in item):
            problem = "non-scalar-item-field"
        elif any((field.tail or "").strip() for field in item):
            problem = "item-mixed-text"
        elif not any((field.text or "").strip() for field in item):
            problem = "empty-item"
        if problem:
            return (), f"requested-empty:unexpected-shape:{problem}"
    return tuple(_cbo_cost_estimate(item) for item in container), "populated"


def _title(element: Element) -> BillTitle:
    return BillTitle(
        title=_title_text(element),
        title_type=_text(element, "titleType"),
        chamber_code=_text(element, "chamberCode"),
        chamber_name=_text(element, "chamberName"),
        bill_text_version_code=_text(element, "billTextVersionCode"),
        bill_text_version_name=_text(element, "billTextVersionName"),
        update_date=_text(element, "updateDate"),
    )


def _relationship_details(element: Element | None) -> str:
    details = [
        {"identifiedBy": _text(item, "identifiedBy"), "type": _text(item, "type")}
        for item in _items(element, "relationshipDetails")
    ]
    return canonical_json_bytes(details).decode("utf-8")


def _related_bill(element: Element) -> RelatedBill:
    latest_action = _one(element, "latestAction")
    return RelatedBill(
        congress=_text(element, "congress"),
        bill_type=_text(element, "type"),
        number=_text(element, "number"),
        title=_title_text(element),
        latest_action_date=_text(latest_action, "actionDate"),
        latest_action_text=_text(latest_action, "text"),
        relationship_details_json=_relationship_details(element),
    )


def _committee(element: Element) -> BillCommittee:
    return BillCommittee(
        system_code=_text(element, "systemCode"),
        name=_text(element, "name"),
        chamber=_text(element, "chamber"),
        type=_text(element, "type"),
        subcommittees=tuple(_committee(item) for item in _items(element, "subcommittees")),
    )


def _action(element: Element) -> BillAction:
    system = _one(element, "sourceSystem")
    text = _text(element, "text")
    return BillAction(
        text=text if text and text.strip() else None,
        action_date=_text(element, "actionDate"),
        action_time=_text(element, "actionTime"),
        action_code=_text(element, "actionCode"),
        action_type=_text(element, "type"),
        source_system_code=_text(system, "code"),
        source_system_name=_text(system, "name"),
        recorded_votes=tuple(_recorded_vote(item) for item in _items(element, "recordedVotes", "recordedVote")),
    )


def _text_version(element: Element, identity: BillIdentity) -> BillTextVersion:
    formats = tuple(
        BillTextFormat(url=url, type=_text(item, "type"), package_id=bill_package_id_from_url(identity, url))
        for item in _items(element, "formats")
        for url in [_required_text(item, "url")]
    )
    packages = {format_.package_id for format_ in formats if format_.package_id is not None}
    if len(packages) > 1:
        raise BillSourceError("bill text version links disagree on package identity")
    return BillTextVersion(_text(element, "type"), _text(element, "date"), formats, next(iter(packages), None))


#: The counts a 1.0.0 ``<actions>`` states beside its items. They are tallies
#: the publisher derives from the items, not actions, and 3.0.0 dropped them.
_LEGACY_ACTION_TALLIES = frozenset({"actionTypeCounts", "actionByCounts"})


def _wrapped(parent: Element | None, name: str, wrapper: str) -> Element | None:
    """The one ``<wrapper>`` a 1.0.0 container holds (``<subjects><billSubjects>``), or ``None``."""
    container = _one(parent, name)
    if container is None:
        return None
    if (container.text or "").strip() or any(child.tag != wrapper for child in container):
        raise BillSourceError(f"bill XML {name} has an unsupported 1.0.0 shape")
    return _one(container, wrapper)


def _wrapped_items(parent: Element | None, name: str, wrapper: str) -> tuple[Element, ...]:
    """The items of a 1.0.0 list under its wrapper (``<committees><billCommittees><item>``)."""
    return _items(_one(parent, name), wrapper) if _wrapped(parent, name, wrapper) is not None else ()


def _action_items(bill: Element, *, legacy: bool) -> tuple[Element, ...]:
    """The action items, less the tallies a 1.0.0 ``<actions>`` states beside them."""
    if not legacy:
        return _items(bill, "actions")
    container = _one(bill, "actions")
    if container is None:
        return ()
    if (container.text or "").strip() or any(child.tag not in {"item", *_LEGACY_ACTION_TALLIES} for child in container):
        raise BillSourceError("bill XML actions has an unsupported 1.0.0 shape")
    return tuple(child for child in container if child.tag == "item")


def parse_bill_status(body: bytes, *, identity: BillIdentity, max_bytes: int = DEFAULT_MAX_BYTES) -> BillStatus:
    """Validate one BILLSTATUS identity and retain literal fields in publisher order.

    Both schemas the publisher serves are read. 3.0.0 is the current one; 1.0.0
    is the one its user guide still documents, and the bulk zips still carry it
    for 13 bills of the 108th-119th Congresses. 1.0.0 states the same fields
    under the guide's names: ``<billType>``/``<billNumber>`` for the identity,
    ``<version>`` inside ``<bill>``, and ``<billCommittees>``,
    ``<billSubjects>`` and ``<billSummaries>`` wrapping committees, subjects
    and summaries. One field has no faithful 1.0.0 counterpart: 1.0.0 lists
    recorded votes once for the bill rather than on the action that took them,
    so its actions carry none, and ``updateDateIncludingText`` and
    ``legislationUrl`` are absent there, so they read ``None``.

    An identity mismatch, a summary stating its text twice, disagreeing
    policy-area fields, and a 1.0.0 name under any other version all refuse.
    """
    _validated_identity(identity)
    root = _xml_root(body, max_bytes)
    if root.tag != "billStatus":
        raise BillSourceError("BILLSTATUS XML root is unsupported")
    bill = _one(root, "bill", required=True)
    legacy = _one(bill, "billType") is not None or _one(bill, "billNumber") is not None
    schema_version = _required_text(bill if legacy else root, "version")
    if legacy and schema_version != "1.0.0":
        raise BillSourceError("BILLSTATUS XML uses 1.0.0 element names under another version")
    if (
        _required_text(bill, "congress") != str(identity.congress)
        or _required_text(bill, "billType" if legacy else "type") != identity.bill_type.upper()
        or _required_text(bill, "billNumber" if legacy else "number") != str(identity.number)
    ):
        raise BillSourceError("BILLSTATUS XML identity differs from the requested bill")
    latest = _one(bill, "latestAction")
    subjects = _wrapped(bill, "subjects", "billSubjects") if legacy else _one(bill, "subjects")
    committees = _wrapped_items(bill, "committees", "billCommittees") if legacy else _items(bill, "committees")
    summaries = _wrapped_items(bill, "summaries", "billSummaries") if legacy else _items(bill, "summaries", "summary")
    policy_area = _text(_one(bill, "policyArea"), "name")
    subject_policy_area = _text(_one(subjects, "policyArea"), "name")
    # Current BILLSTATUS repeats this source term in both documented locations.
    if policy_area is not None and subject_policy_area is not None and policy_area != subject_policy_area:
        raise BillSourceError("BILLSTATUS policy area fields disagree")
    estimates, estimates_outcome = _cbo_cost_estimates(bill)
    return BillStatus(
        identity=identity,
        schema_version=schema_version,
        title=_required_text(bill, "title"),
        origin_chamber=_text(bill, "originChamber"),
        introduced_date=_text(bill, "introducedDate"),
        update_date=_text(bill, "updateDate"),
        update_date_including_text=_text(bill, "updateDateIncludingText"),
        legislation_url=_text(bill, "legislationUrl"),
        latest_action=None if latest is None else _action(latest),
        policy_area=policy_area if policy_area is not None else subject_policy_area,
        subjects=tuple(_required_text(item, "name") for item in _items(subjects, "legislativeSubjects")),
        summaries=tuple(_summary(item) for item in summaries),
        actions=tuple(_action(item) for item in _action_items(bill, legacy=legacy)),
        sponsors=tuple(
            BillSponsor(_text(item, "bioguideId"), _text(item, "fullName")) for item in _items(bill, "sponsors")
        ),
        cosponsors=tuple(
            BillSponsor(_text(item, "bioguideId"), _text(item, "fullName")) for item in _items(bill, "cosponsors")
        ),
        text_versions=tuple(_text_version(item, identity) for item in _items(bill, "textVersions")),
        laws=tuple(BillLaw(_text(item, "number"), _text(item, "type")) for item in _items(bill, "laws")),
        committees=tuple(_committee(item) for item in committees),
        titles=tuple(_title(item) for item in _items(bill, "titles")),
        related_bills=tuple(_related_bill(item) for item in _items(bill, "relatedBills")),
        cbo_cost_estimates=estimates,
        report_citations=tuple(
            _required_text(item, "citation") for item in _items(bill, "committeeReports", "committeeReport")
        ),
        cbo_cost_estimates_outcome=estimates_outcome,
    )


__all__ = [
    "BILLSTATUS_BULKDATA",
    "BillAction",
    "BillCommittee",
    "BillIdentity",
    "BillLaw",
    "BillSourceError",
    "BillSponsor",
    "BillStatus",
    "BillSummary",
    "BillTextFormat",
    "BillTextVersion",
    "BillTitle",
    "CboCostEstimate",
    "RecordedVote",
    "RelatedBill",
    "bill_package_id_from_url",
    "bill_status_locator",
    "bill_xml_locator",
    "parse_bill_status",
    "select_bill_xml",
]
