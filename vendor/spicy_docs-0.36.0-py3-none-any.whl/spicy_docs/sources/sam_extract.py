"""SAM.gov bulk entity extracts: trigger, poll, defensive parse.

The Entity Management API's asynchronous extract (``format=json``) answers the
trigger with a plain-text sentence naming a download URL whose ``api_key`` is
the literal ``REPLACE_WITH_API_KEY`` placeholder; the download answers HTTP
400 with ``errorCode`` ``FSP`` while the file generates and serves the file
only as ``application/x-gzip`` (all measured 2026-09-23). The trigger states
no count, so the downloaded file's own
``totalRecords`` is the selection's count, and a floor: the file is written while
registrations change, so it may hold more (never fewer) registrations, each keyed
by UEI and EFT indicator (:func:`registrations`). SAM also keeps a renewed
registration's prior record Active until its expiry is processed and counts both, so a
superseded version the source held before the trigger's day counts toward that floor
(:attr:`SamBulkExtract.superseded`). The key travels merged into each
URL's own query: httpx's ``params`` replaces a query rather than extending it,
which once dropped every selection filter. This module owns that loop and the
defensive file parse, so callers receive validated entity records or a
refusal, never a partial, unchecked population.

The synchronous paged walk lives in :mod:`spicy_docs.sources.sam` and refuses a
too-deep query after one page; this extract path is the full-coverage
mechanism (up to the publisher's per-file bound, one file per
``registrationDate`` year window).
"""

from __future__ import annotations

import gzip
import io
import json
import re
import time
import zipfile
from collections.abc import Callable, Iterator, Mapping, Sequence
from datetime import UTC, date, datetime, timedelta
from typing import Any, cast
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx
from loguru import logger

from spicy_docs.transport.credentials import scrub_credential
from spicy_docs.transport.retry import retry_http

API = "https://api.sam.gov/entity-information/v4"
API_KEY_PLACEHOLDER = "REPLACE_WITH_API_KEY"

# Each request states what it accepts. The download serves only application/x-gzip and answers
# 406 "Invalid Accept Header" to Accept: application/json, so a client-wide JSON Accept failed
# every scheduled spicy-regs run on its first poll (run 35907412992); */* gets the in-progress 400
# JSON and then the file. Receipts, 2026-09-23, in corpora/fork-execution-2026-09-21/: the 406 for
# a ready file in sam-406-2026-09-23/, the */* answers in sam-initial-load-2026-09-23/.
_TRIGGER_ACCEPT = {"Accept": "application/json"}
_DOWNLOAD_ACCEPT = {"Accept": "*/*"}

# The download answers "still generating" until the file is written. The 2026 registration-year
# extract (147,256 rows, 71.5 MB gzip) was still generating 21 minutes after its trigger and ready
# at the next poll, 46 minutes after it; when in between it finished is unmeasured (receipts in
# sam-initial-load-2026-09-23/). The default wait is 25 minutes of wall clock from the trigger,
# because the spicy-regs sam_entities job has 30 minutes in all (_rollup.yml's timeout_minutes
# default) and the reader must refuse before the job is cancelled.
EXTRACT_MAX_WAIT = 25 * 60.0
EXTRACT_POLL_INTERVAL = 30.0
# Polls answered within seconds (the whole ready 71.5 MB file in 5.3 s); httpx's read timeout
# bounds each socket read, not the transfer, so 30 s ends a stalled poll without cutting the file.
_POLL_TIMEOUT = httpx.Timeout(30.0)
MAX_RETRIES = 5
DEFAULT_TIMEOUT = httpx.Timeout(120.0, connect=30.0)


_SENTENCE_URL = re.compile(r"https://api\.sam\.gov/\S+")


class SamExtractError(RuntimeError):
    """A selected SAM extract could not be acquired and validated."""


def year_window_literal(year: int) -> str:
    """SAM ``registrationDate`` range literal spanning a whole calendar year."""
    if isinstance(year, bool) or not isinstance(year, int) or not 1 <= year <= 9999:
        raise SamExtractError("year must be a valid calendar year")
    return f"[01/01/{year},12/31/{year}]"


def extract_entities_url(*, registration_status: str = "A", year: int | None = None) -> str:
    """Name one extract trigger: ``format=json``, optionally scoped to one registration year."""
    if registration_status not in ("A", "E"):
        raise SamExtractError("registration_status must be 'A' or 'E'")
    query = [("registrationStatus", registration_status), ("format", "json")]
    if year is not None:
        query.append(("registrationDate", year_window_literal(year)))
    return f"{API}/entities?{urlencode(query, safe='[],/')}"


def registration_key(record: Mapping[str, Any]) -> tuple[str, str | None]:
    """A SAM registration's identity: its UEI and its EFT indicator.

    One entity registers once per EFT indicator (measured 2026-09-23: 187 of the 147,038 UEIs in the
    2026 registration-year extract carry more than one), so the UEI alone is not a key.
    """
    registration = record["entityRegistration"]
    return validate_entity(record), registration.get("entityEFTIndicator")


def registrations(records: Sequence[dict]) -> list[dict]:
    """One record per registration: a repeated key keeps its newest ``lastUpdateDate``.

    The extract is generated over minutes while registrations change, so a file can carry two
    versions of one registration (two in the 2026 extract, 2026-09-23) and registrations newer
    than its own ``totalRecords``. Identical repeats collapse; differing ones at one date refuse.
    """
    return [held[-1] for held in _versions(records).values()]


def _versions(records: Sequence[dict]) -> dict[tuple[str, str | None], list[dict]]:
    """Each registration's distinct versions, oldest ``lastUpdateDate`` first."""
    grouped: dict[tuple[str, str | None], list[dict]] = {}
    for record in records:
        held = grouped.setdefault(registration_key(record), [])
        if record not in held:
            held.append(record)
    for key, held in grouped.items():
        if len({_updated(record) for record in held}) != len(held):
            raise SamExtractError(f"SAM extract holds two differing versions of {key} at one lastUpdateDate")
        held.sort(key=_updated)
    return grouped


def _concurrent_superseded(versions: Mapping[tuple[str, str | None], list[dict]], trigger_day: date) -> list[dict]:
    """The superseded versions the source held concurrently, each credited toward ``totalRecords``.

    SAM keeps a renewed registration's prior record Active until its expiry is processed and
    counts both: the 2007 and 2008 registration-year extracts each declared exactly their rows
    and held one UEI twice, a fresh trigger reproduced the 2007 file, and the entity API answered
    two Active records for each UEI (2026-09-26; receipts in
    corpora/fork-execution-2026-09-21/sam-superseded-2026-09-26/). A superseded version earns
    credit only when its successor was updated before the day preceding ``trigger_day`` (SAM
    dates are Eastern time): a version written while the file generated earns nothing, so a file
    that skipped one registration while repeating another still refuses.
    """
    cutoff = (trigger_day - timedelta(days=1)).isoformat()
    credited = []
    for (uei, eft), held in versions.items():
        kept = held[-1]["entityRegistration"]
        if len(held) < 2 or not _updated(held[-1]) or _updated(held[-1]) >= cutoff:
            continue
        for older in held[:-1]:
            prior = older["entityRegistration"]
            credited.append(
                {
                    "uei": uei,
                    "eft_indicator": eft,
                    "superseded_last_update": prior.get("lastUpdateDate"),
                    "superseded_expiration": prior.get("registrationExpirationDate"),
                    "kept_last_update": kept.get("lastUpdateDate"),
                    "kept_expiration": kept.get("registrationExpirationDate"),
                    "trigger_day": trigger_day.isoformat(),
                }
            )
    return credited


def _updated(record: Mapping[str, Any]) -> str:
    return str(record["entityRegistration"].get("lastUpdateDate") or "")


def validate_entity(record: object) -> str:
    """Return the record's nonempty ``entityRegistration.ueiSAM`` or refuse the record."""
    registration = cast(dict[str, object], record).get("entityRegistration") if isinstance(record, dict) else None
    uei = cast(dict[str, object], registration).get("ueiSAM") if isinstance(registration, dict) else None
    if not isinstance(uei, str) or not uei.strip():
        raise SamExtractError("SAM entity requires a nonempty entityRegistration.ueiSAM")
    return uei


def _total_records(payload: object) -> int:
    """The payload's nonnegative integer ``totalRecords``; a reported source error refuses."""
    _refuse_source_error(payload)
    total = cast(dict[str, object], payload).get("totalRecords") if isinstance(payload, dict) else None
    if type(total) is not int or total < 0:
        raise SamExtractError("SAM response requires a nonnegative integer totalRecords")
    return total


def _entity_data(payload: object) -> list[dict]:
    """The payload's validated ``entityData`` array; a missing array refuses."""
    _refuse_source_error(payload)
    records = cast(dict[str, object], payload).get("entityData") if isinstance(payload, dict) else None
    if not isinstance(records, list):
        raise SamExtractError("SAM response requires an entityData array")
    for record in records:
        validate_entity(record)
    return cast(list[dict], records)


def _refuse_source_error(payload: object) -> None:
    if isinstance(payload, dict) and any(
        cast(dict[str, object], payload).get(key) for key in ("error", "errors", "errorCode", "errorMessage")
    ):
        raise SamExtractError("SAM response reports a source error")


def find_extract_download_url(payload: object) -> str | None:
    """Locate an extract download URL in a trigger response.

    SAM embeds the download link carrying the literal ``REPLACE_WITH_API_KEY``
    placeholder, and the exact key path has varied across API versions, so the
    structure is walked and the first string that looks like that URL is
    returned (placeholder preferred; otherwise any http(s) URL whose path
    mentions download/extract).
    """
    if isinstance(payload, str):
        # The trigger answers a sentence: "Extract File will be available for download with
        # url: https://api.sam.gov/.../download-entities?api_key=REPLACE_WITH_API_KEY&token=...
        # in some time." (measured 2026-09-23).
        match = _SENTENCE_URL.search(payload)
        return match.group(0).rstrip(".,;") if match else None
    fallback: str | None = None

    def walk(node: object) -> str | None:
        nonlocal fallback
        if isinstance(node, str):
            if API_KEY_PLACEHOLDER in node and node.startswith("http"):
                return node
            if (
                fallback is None
                and node.startswith("http")
                and ("download" in node.lower() or "extract" in node.lower())
            ):
                fallback = node
            return None
        if isinstance(node, dict):
            for key, value in node.items():
                if key in {"selfLink", "nextLink", "prevLink", "previousLink"}:
                    continue
                hit = walk(value)
                if hit:
                    return hit
        elif isinstance(node, list):
            for value in node:
                hit = walk(value)
                if hit:
                    return hit
        return None

    return walk(payload) or fallback


def _in_progress(response: httpx.Response) -> dict | None:
    """SAM's in-progress answer, an HTTP 400 JSON body carrying ``errorCode`` ``FSP``; otherwise None."""
    if response.status_code != 400:
        return None
    try:
        body = response.json()
    except ValueError:
        return None
    return body if isinstance(body, dict) and body.get("errorCode") == "FSP" else None


def reinject_extract_key(link: str, api_key: str) -> str:
    """Return ``link`` with the real api_key re-injected on the SAM host.

    SAM returns links with the key masked — as a query-param placeholder or the
    literal ``REPLACE_WITH_API_KEY`` token. Both are swapped for ``api_key``;
    anything outside the authorized API host refuses.
    """
    parts = urlparse(link)
    if parts.scheme != "https" or parts.hostname != "api.sam.gov" or parts.username or parts.password:
        raise SamExtractError("SAM response link is outside the authorized API host")
    link = link.replace(API_KEY_PLACEHOLDER, api_key)
    parts = urlparse(link)
    query = parse_qs(parts.query, keep_blank_values=True)
    query["api_key"] = [api_key]
    return urlunparse(parts._replace(query=urlencode(query, doseq=True)))


def _body(response: httpx.Response) -> object:
    """A JSON body when the response is one, otherwise its text (the trigger answers a sentence)."""
    try:
        return response.json()
    except ValueError:
        return response.text


def extract_population(raw: bytes) -> tuple[int, list[dict]]:
    """A downloaded extract's own ``totalRecords`` and its validated records.

    The trigger states no count (it answers a sentence), so the file's envelope is the only
    publisher count for the selection; an extract without one refuses. Measured 2026-09-23: the
    download is a gzip JSON envelope, ``{"totalRecords": 508, "entityData": [508 entities]}`` for
    one registration day, equal to the paged route's count for the same selection.
    """
    try:
        doc = json.loads(_decompress_extract(raw))
    except ValueError:
        raise SamExtractError("SAM extract is not one JSON envelope") from None
    if not isinstance(doc, dict) or "totalRecords" not in doc:
        raise SamExtractError("SAM extract states no totalRecords")
    return _total_records(doc), _entity_data(doc)


def parse_extract_records(raw: bytes) -> list[dict]:
    """Return the validated entity records of one downloaded extract.

    Handles gzip- and zip-compressed payloads, then parses the inner text as
    either a JSON envelope (``{"entityData": [...]}``), a bare JSON array, a
    single entity object, or newline-delimited JSON. Malformed or unrecognized
    input refuses the selection rather than yielding a partial population.
    """
    return list(_iter_extract_records(raw))


def _iter_extract_records(raw: bytes) -> Iterator[dict]:
    text = _decompress_extract(raw)
    if not text.strip():
        raise SamExtractError("SAM extract is empty without an explicit source population")
    stripped = text.lstrip()
    if stripped[:1] in ("{", "["):
        try:
            doc = json.loads(stripped)
        except ValueError:
            yield from _iter_ndjson(text)
            return
        if isinstance(doc, dict):
            if "entityData" in doc:
                records = _entity_data(doc)
                if "totalRecords" in doc and len(records) != _total_records(doc):
                    raise SamExtractError("SAM extract entityData differs from totalRecords")
                yield from records
            elif "entityRegistration" in doc or "ueiSAM" in doc:
                validate_entity(doc)
                yield doc
            else:
                raise SamExtractError("SAM extract has no recognized entity population")
            return
        if isinstance(doc, list):
            for record in doc:
                validate_entity(record)
                yield record
            return
    yield from _iter_ndjson(text)


def _decompress_extract(raw: bytes) -> str:
    """The extract's inner text, transparently decompressing gzip/zip."""
    if raw[:2] == b"\x1f\x8b":  # gzip magic
        try:
            return gzip.decompress(raw).decode("utf-8")
        except (OSError, EOFError, UnicodeError):
            raise SamExtractError("SAM gzip extract is malformed") from None
    if raw[:2] == b"PK":  # zip magic
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                members = [member for member in archive.infolist() if not member.is_dir()]
                if len(members) != 1:
                    raise SamExtractError("SAM ZIP extract requires exactly one data member")
                return archive.read(members[0]).decode("utf-8")
        except (zipfile.BadZipFile, UnicodeError):
            raise SamExtractError("SAM ZIP extract is malformed") from None
    try:
        return raw.decode("utf-8")
    except UnicodeError:
        raise SamExtractError("SAM extract is not valid UTF-8") from None


def _iter_ndjson(text: str) -> Iterator[dict]:
    """Each non-blank line as a validated entity; malformed JSON refuses the extract."""
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except ValueError:
            raise SamExtractError("SAM extract contains malformed JSON records") from None
        validate_entity(record)
        yield record


class SamBulkExtract:
    """One extract selection: trigger it, poll its download, and yield validated entities.

    ``api_key`` is sent as a query parameter (the publisher's contract for the
    extract route); links returned by the publisher have it masked and are
    re-injected with the real key on the SAM host only. ``max_records`` bounds
    emitted records, not downloaded bytes. Records yielded before a refusal are
    partial — callers must exhaust the iterator before writing output.

    ``superseded`` lists, once :meth:`records` has yielded, each concurrent superseded
    version credited toward the file's ``totalRecords`` (UEI, EFT indicator, both versions'
    ``lastUpdateDate`` and expiration, and the trigger's day) for the caller's evidence.

    ``max_wait`` seconds of ``clock`` from the trigger bound the wait for the file
    (:data:`EXTRACT_MAX_WAIT`): no poll starts after it, polls run ``poll_interval``
    seconds apart under 30 s timeouts, and the trigger's own retries count against
    it. spicy-regs' ``build_sam_entities._iter_sam_entities`` passes no ``max_wait``
    today, so waiting out the measured 46 minutes there means raising
    ``timeout_minutes`` in its ``rollup-sam-entities.yml`` and passing ``max_wait``
    through.
    """

    def __init__(
        self,
        *,
        api_key: str,
        registration_status: str = "A",
        year: int | None = None,
        max_records: int | None = None,
        transport: httpx.BaseTransport | None = None,
        max_wait: float = EXTRACT_MAX_WAIT,
        poll_interval: float = EXTRACT_POLL_INTERVAL,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
        today: Callable[[], date] = lambda: datetime.now(UTC).date(),
    ) -> None:
        if not api_key or not api_key.strip():
            raise SamExtractError("SAM extracts require a SAM-authorized API key")
        if max_records is not None and (type(max_records) is not int or max_records <= 0):
            raise SamExtractError("max_records must be a positive integer or None")
        if any(type(value) not in (int, float) or value <= 0 for value in (max_wait, poll_interval)):
            raise SamExtractError("extract max_wait and poll_interval must be positive seconds")
        self.api_key = api_key
        self.registration_status = registration_status
        self.year = year
        self.max_records = max_records
        self.transport = transport
        self.max_wait = max_wait
        self.poll_interval = poll_interval
        self.sleep = sleep
        self.clock = clock
        self.today = today
        self.superseded: list[dict] = []
        self._seen = 0

    def records(self) -> Iterator[dict]:
        """Trigger the extract, download it, and yield validated entities."""
        self._seen = 0
        # Extract download URLs commonly 302 to a signed blob URL.
        with httpx.Client(timeout=DEFAULT_TIMEOUT, follow_redirects=True, transport=self.transport) as client:
            url = extract_entities_url(registration_status=self.registration_status, year=self.year)
            deadline, trigger_day = self.clock() + self.max_wait, self.today()
            trigger = _body(self._get(client, url))
            if isinstance(trigger, dict) and "entityData" in trigger:
                total, records = _total_records(trigger), _entity_data(trigger)
            else:
                download_url = find_extract_download_url(trigger)
                if download_url is None:
                    raise SamExtractError("SAM extract trigger named no download URL")
                total, records = self._download_records(client, download_url, deadline)
            versions = _versions(records)
            records = [held[-1] for held in versions.values()]
            self.superseded = _concurrent_superseded(versions, trigger_day)
            held = len(records) + len(self.superseded)
            if held < total:
                raise SamExtractError(
                    f"SAM extract holds {len(records):,} registrations and {len(self.superseded):,} concurrent "
                    f"superseded records, fewer than its totalRecords {total:,}"
                )
            if self.superseded:
                logger.info(
                    "SAM extract: {:,} concurrent superseded records credited toward its totalRecords",
                    len(self.superseded),
                )
            if held > total:
                logger.info("SAM extract: {:,} registrations beyond its totalRecords {:,}", held - total, total)
            for record in records:
                if not self._budget_left():
                    return
                self._seen += 1
                yield record

    def _budget_left(self) -> bool:
        return self.max_records is None or self._seen < self.max_records

    def _get(self, client: httpx.Client, url: str) -> httpx.Response:
        """GET the trigger ``url`` for JSON with the key merged into its own query, under bounded retries.

        Passing ``params`` to httpx replaces a URL's query rather than extending it, which
        silently dropped every selection filter (measured 2026-09-23: the trigger answered
        the unfiltered 1,845,420-entity default page), so the key is merged here instead.
        """
        keyed = httpx.URL(url).copy_merge_params({"api_key": self.api_key})

        def attempt() -> httpx.Response:
            response = client.get(keyed, headers=_TRIGGER_ACCEPT)
            if response.status_code == 429 or response.status_code >= 500:
                raise httpx.HTTPStatusError("retryable", request=response.request, response=response)
            if response.status_code != 200:
                raise SamExtractError(
                    f"SAM request refused with HTTP {response.status_code}; verify SAM-specific access"
                )
            return response

        return retry_http(attempt, retryable=(httpx.HTTPError,), max_attempts=MAX_RETRIES, api_key=self.api_key)

    def _download_records(self, client: httpx.Client, download_url: str, deadline: float) -> tuple[int, list[dict]]:
        """Poll the extract download until ready, starting no poll after ``deadline``; parse its bytes."""
        url = reinject_extract_key(download_url, self.api_key)
        details: set[str] = set()
        last = "none"
        while self.clock() < deadline:
            try:
                response = client.get(url, headers=_DOWNLOAD_ACCEPT, timeout=_POLL_TIMEOUT)
            except httpx.HTTPError as error:
                last = type(error).__name__
            else:
                # The file may still be generating: SAM answers 400 with errorCode FSP ("Extract
                # File Generation is Still in Progress", measured 2026-09-23), and 202/404/429/5xx.
                progress = _in_progress(response)
                status = response.status_code
                if progress is None and status not in (202, 404, 429) and status < 500:
                    if status != 200:
                        raise SamExtractError(f"SAM extract refused with HTTP {status}")
                    return extract_population(response.content)
                last = f"HTTP {status}"
                if progress is not None:
                    detail = scrub_credential(str(progress.get("detail", "")), self.api_key).strip()[:200]
                    if detail not in details:
                        details.add(detail)
                        logger.debug("SAM extract still generating: {}", detail)
            self.sleep(min(self.poll_interval, max(0.0, deadline - self.clock())))
        raise SamExtractError(f"SAM extract did not finish within its {self.max_wait:g} s wait; last poll: {last}")


__all__ = [
    "API",
    "API_KEY_PLACEHOLDER",
    "EXTRACT_MAX_WAIT",
    "EXTRACT_POLL_INTERVAL",
    "SamBulkExtract",
    "SamExtractError",
    "extract_entities_url",
    "extract_population",
    "find_extract_download_url",
    "parse_extract_records",
    "registration_key",
    "registrations",
    "reinject_extract_key",
    "validate_entity",
    "year_window_literal",
]
