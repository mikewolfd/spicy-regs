"""One pinned OFAC enhanced export through the maintained source-release stream."""

import hashlib
import re
from contextlib import closing
from dataclasses import dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.ofac import MAX_ZIP_BYTES, OfacError, ofac_scope, snapshot_records, validate_scope

SCOPE_ID = "ofac-enhanced-snapshot-v1"
SCHEMA_NAME = "ofac-enhanced-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
MAX_PAGE_BYTES = 4 * 1024**2
MAX_PAGE_RECORDS = 100
_PAIR = {
    "type": "array",
    "minItems": 2,
    "maxItems": 2,
    "items": {"type": "string"},
}
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["id", "selected_list", "kind", "ordinal", "entity_id", "identity_id", "element", "source_locator"],
    "properties": {
        "id": {"type": "string"},
        "selected_list": {"enum": ["sdn", "consolidated"]},
        "kind": {"enum": ["root", "container", "metadata", "entity", "extension"]},
        "ordinal": {"type": "integer", "minimum": 0},
        "entity_id": {"type": ["string", "null"]},
        "identity_id": {"type": ["string", "null"]},
        "element": {"$ref": "#/$defs/element"},
        "source_locator": {"type": "object"},
    },
    "$defs": {
        "element": {
            "type": "object",
            "additionalProperties": False,
            "required": ["name", "attributes", "namespace_declarations", "path", "content"],
            "properties": {
                "name": {"type": "string"},
                "attributes": {"type": "array", "items": _PAIR},
                "namespace_declarations": {"type": "array", "items": _PAIR},
                "path": {"type": "array", "minItems": 1, "items": {"type": "integer", "minimum": 1}},
                "content": {"type": "array", "items": {"anyOf": [{"type": "string"}, {"$ref": "#/$defs/element"}]}},
            },
        }
    },
    "x-spicy-record-order": [
        {"fieldPath": "/id", "nullOrder": "forbidden", "tupleComparison": "utf16-code-unit", "valueType": "string"}
    ],
}


def _key(index):
    return f"ofac://snapshot/page/{index}"


def iter_retained_pages(scope, *, blob_source):
    """Supply the exact original ZIP once, without an expanded XML file."""
    capture = validate_scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, _key(0), capture["response_sha256"], capture["byte_size"], blob_source, "application/zip"
    )


def _page(index, rows, terminal):
    return {"requestKey": _key(index), "page": index, "results": rows, "terminal": terminal}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = validate_scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["response_sha256"],
        capture["byte_size"],
        "application/zip",
    ):
        raise OfacError("OFAC original differs from the selected capture")
    page, rows, size = 0, [], 0
    overhead = len(canonical_json_bytes(_page(page, [], False)))
    with closing(snapshot_records(stream, scope=scope)) as records:
        for record in records:
            record_size = len(canonical_json_bytes(record))
            if rows and (len(rows) == MAX_PAGE_RECORDS or overhead + size + record_size + len(rows) > MAX_PAGE_BYTES):
                yield _page(page, rows, False)
                page, rows, size = page + 1, [], 0
                overhead = len(canonical_json_bytes(_page(page, [], False)))
            if overhead + record_size > MAX_PAGE_BYTES:
                raise OfacError("OFAC observation exceeds the source page bound")
            rows.append(record)
            size += record_size
    yield _page(page, rows, True)


@dataclass
class _Traversal:
    pages: int = 0
    records: int = 0
    terminal: bool = False

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise OfacError("OFAC pages are not contiguous")
        for row in response["results"]:
            if row["ordinal"] != self.records:
                raise OfacError("OFAC observation ordering differs")
            self.records += 1
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if not self.pages or not self.terminal:
            raise OfacError("OFAC export did not finish")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise OfacError("OFAC requires one selected original")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise OfacError("OFAC selected original is missing")


def _window(key):
    if not isinstance(key, str) or re.fullmatch(r"ofac://snapshot/page/(0|[1-9][0-9]*)", key) is None:
        raise OfacError("OFAC page key differs")
    return 0


def _record_scope(record, *, query_scope, page_window):
    capture, locator = query_scope["capture"], record["source_locator"]
    if (
        record["selected_list"] != query_scope["selected_list"]
        or record["id"] != f"ofac:{query_scope['selected_list']}:{capture['response_sha256']}:{record['ordinal']:020d}"
        or any(locator.get(key) != capture[key] for key in ("request_url", "response_sha256", "observed_at"))
        or locator.get("member_name") != query_scope["member_name"]
        or locator.get("source_xpath") != "".join(f"/*[{n}]" for n in record["element"]["path"])
    ):
        raise OfacError("OFAC observation coordinates differ from its selected source")


def _byte_parser(_raw):
    raise OfacError("OFAC requires its captured original stream")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


OFAC_PROFILE = SourceNativeProfile(
    name="Retained OFAC enhanced sanctions export",
    source_system_id="https://sanctionslist.ofac.treas.gov/",
    source_system_version="ENHANCED_XML",
    acquisition_policy_id="urn:spicy-docs:acquisition:ofac-enhanced-export",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="ofac",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "One selected SDN or Consolidated enhanced XML member, not all history or a synchronized pair of lists.",
            "Publisher dataAsOf remains literal and separate from acquisition time, including absent timezone.",
            "Entity ID and identity ID are distinct source facts. Names are not cross-list or real-world identities.",
            "Ordered subtrees retain unknown fields, repeated values and dictionary IDs; no legal inference.",
            "Root and entities container observations are shallow; their children are separate positional observations.",
            "Container whitespace, lexical markup, comments and processing instructions remain in the exact ZIP.",
            "Complete member parsing establishes selected-file coverage; absence does not establish delisting.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_ZIP_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": row["id"],
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=lambda response, **kwargs: True,
    acquisition_check=_Acquisition,
    page_window=_window,
)

__all__ = ["OFAC_PROFILE", "iter_retained_pages", "ofac_scope"]
