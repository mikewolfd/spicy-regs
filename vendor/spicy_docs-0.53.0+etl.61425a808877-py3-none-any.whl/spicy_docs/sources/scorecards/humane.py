"""Humane World Action Fund's complete final 2025 PDF, both chamber charts.

The injected Docling pipeline reads displayed symbols. Raw font extraction tokens
are refused; they cannot be silently converted into publisher results. Complete
chamber charts are checked against retained, visually qualified page boundaries.
"""

from __future__ import annotations

import re

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    pdf,
)

parser_version = "humane-final-2025-docling-displayed-glyphs/2"
HOSTS = ("humaneaction.org",)
URL = "https://humaneaction.org/sites/default/files/2026-02/FINAL%20humane-scorecard-2025.pdf"
EDITION = ScorecardEdition(
    "humane_world_action", "2025-final", URL, "2025 Humane Scorecard", year="2025", chamber="both"
)
HEADERS = {
    "Senate": ("AWA enforcement co-sponsor", "Leader", "Score"),
    "House": (
        "AWA enforcement co-sponsor",
        "Puppy mills co-sponsor",
        "Horse slaughter co-sponsor",
        "Endangered species vote",
        "Wolves vote",
        "USDA/FDA animal welfare letter",
        "Horse slaughter defund letter",
        "Animal Protection Caucus",
        "Leader",
        "Score",
    ),
}
KINDS = {
    "co-sponsor": "cosponsorship",
    "vote": "roll call",
    "letter": "letter",
    "Caucus": "caucus membership",
    "Leader": "leadership",
}
RAW_FONT_TOKENS = frozenset({"ü", "ê", "\x02", "\uf0fc", "\uf0ab"})
TOKENS = {"", "✓", "★", "SP", "X", "NV", "NV*", "•", "••", "•••", "#", "##", "###"}
REASONS = {
    "NV": "Did not vote due to absence or abstention",
    "NV*": "Put statement in Congressional Record (and notified us) indicating missed vote but would have voted pro-animal",
    "#": "Filled seat during term",
    "##": "Resigned during term",
    "###": "Passed away during term",
    "••": "The top leaders of each party typically don't co-sponsor bills and the Speaker of the House doesn't vote, so they have no numerical scores",
    "•": "Delegates from U.S. territories and the District of Columbia cannot vote on bills or amendments on the House floor unless they are taken in the Committee of the Whole",
}
# Reviewed final-2025 report chart boundaries; private qualification receipt 2026-10-03.
PAGE_MEMBERS = {6: 34, 7: 32, 8: 34, 12: 62, 13: 61, 14: 58, 15: 56, 16: 60, 17: 54, 18: 63, 19: 30}
MEMBER = re.compile(r"^(.+) \(([RDI])(?:-(.+))?\)$")


def _identity(document):
    if (
        document.page_count != 20
        or "The 119th Congress, First Session" not in document[0].text
        or "Humane" not in document[0].text
    ):
        raise ScorecardSourceError("Humane PDF is not the qualified final 2025 edition")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    source = context.read(URL, stage="scorecards:humane:listing", hosts=HOSTS)
    with pdf(source, context, expected_pages=20) as document:
        _identity(document)
    return (EDITION,)


def decode_result(raw: str) -> str:
    """Only displayed symbols are accepted from OCR; font-code guessing is refused."""
    if any(code in raw for code in RAW_FONT_TOKENS):
        raise ScorecardSourceError("Humane extraction contains undecoded font tokens")
    return raw


def parse_chart(document, chamber):
    pages = range(5, 8) if chamber == "Senate" else range(11, 19)
    rows = []
    state = None
    for page_index in pages:
        page = document[page_index]
        source_text = " ".join(page.text.split())
        if (
            any(header not in source_text for header in HEADERS[chamber])
            or f"Key to {chamber} Chart" not in source_text
        ):
            raise ScorecardSourceError("Humane chart headers or legend changed")
        selected = [
            (i, table)
            for i, table in enumerate(page.tables, 1)
            if any(row and row[0] and MEMBER.fullmatch(row[0]) for row in table.cells)
        ]
        if len(selected) != 1:
            raise ScorecardSourceError("Humane chart is no longer one complete recognized table")
        table_index, table = selected[0]
        page_members = []
        for index, cells in enumerate(table.cells, 1):
            if len(cells) != len(HEADERS[chamber]) + 1 or not cells[0]:
                raise ScorecardSourceError("Humane chart cell geometry changed")
            # A model-stated column header is not a member or state; exact source
            # headings keep the parser from treating an arbitrary row as a header.
            if tuple(" ".join((cell or "").split()) for cell in cells[1:]) == HEADERS[chamber]:
                continue
            match = MEMBER.fullmatch(cells[0])
            if match is None:
                if any(cells[1:]) or "\n" in cells[0] or "(" in cells[0]:
                    raise ScorecardSourceError("Humane chart has an unrecognized member/state row")
                state = cells[0]
                continue
            if state is None or any(cell is None for cell in cells):
                raise ScorecardSourceError("Humane member lacks source state or a chart cell")
            page_members.append(cells[0])
            decoded = [decode_result(value) for value in cells[1:-1]]
            if set(decoded) - TOKENS or not re.fullmatch(r"(?:\d+\+?|••|#{1,3})", cells[-1]):
                raise ScorecardSourceError("Humane chart introduced an unknown result or score marker")
            rows.append((page.path(table=table_index, row=index), state, match.groups(), decoded, cells[-1]))
        if len(page_members) != PAGE_MEMBERS[page.number]:
            raise ScorecardSourceError("Humane recognized chart is truncated or repeats source members")
    identities = [(state, name[0], name[2]) for _, state, name, _, _ in rows]
    if len(set(identities)) != len(rows) or not rows:
        raise ScorecardSourceError("Humane chart repeats source member identities")
    return rows


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("Humane reader supports only the final 2025 PDF layout")
    source = context.read(URL, stage="scorecards:humane:final-pdf", hosts=HOSTS)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Humane World Action Fund",
        parser_version=parser_version,
        rendition_rule="humane-final-pdf-displayed-glyphs/1",
        homepage="https://humaneaction.org",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    with pdf(source, context, expected_pages=20) as document:
        _identity(document)
        for chamber in ("Senate", "House"):
            chart = parse_chart(document, chamber)
            metric_id = chamber.lower() + ":score"
            pages = [4] if chamber == "Senate" else [8, 9, 10]
            method = "\n".join(document[i].text for i in pages)
            method_id = chamber.lower() + ":method"
            bundle.add(
                "scorecard_methodologies",
                source,
                ";".join(document[i].path() for i in pages),
                methodology_id=method_id,
                chamber_text=chamber,
                methodology_text=method,
                methodology_url=URL,
                disclosure_status="partial",
            )
            header_path = document[5 if chamber == "Senate" else 11].path()
            bundle.metric(source, metric_id, "Score", path=header_path + "/heading[Score]", chamber=chamber)
            for column, header in enumerate(HEADERS[chamber][:-1], 1):
                item_id = key(chamber, header)
                kind = next((value for suffix, value in KINDS.items() if header.endswith(suffix)), "other")
                path = header_path + f"/chart/column[{column + 1}]/heading"
                bundle.add(
                    "scorecard_items",
                    source,
                    path,
                    item_id=item_id,
                    item_kind_text=kind,
                    title=header,
                    chamber_text=chamber,
                )
                bundle.add(
                    "scorecard_metric_items",
                    source,
                    path,
                    metric_id=metric_id,
                    item_id=item_id,
                    participation_id="chart",
                    methodology_id=method_id,
                )
            for path, state, member, results, score in chart:
                name, party, district = member
                member_id = key(chamber, state, name, district) if district else key(chamber, state, name)
                bundle.add(
                    "scorecard_members",
                    source,
                    path,
                    publisher_member_key=member_id,
                    member_name=name,
                    state=state,
                    party=party,
                    district=district,
                    chamber_text=chamber,
                    eligibility_text=REASONS.get(score),
                )
                bundle.add(
                    "scorecard_member_ratings",
                    source,
                    path + "/Score",
                    metric_id=metric_id,
                    publisher_member_key=member_id,
                    value_text=score,
                    value_number=decimal_text(score),
                    notes_text=REASONS.get(score),
                )
                for column, (header, result) in enumerate(zip(HEADERS[chamber][:-1], results, strict=True), 1):
                    bundle.add(
                        "scorecard_member_item_results",
                        source,
                        path + f"/column[{column + 1}]",
                        item_id=key(chamber, header),
                        metric_id=metric_id,
                        participation_id="chart",
                        publisher_member_key=member_id,
                        result_id="chart",
                        result_text=result,
                        reason_text=REASONS.get(result),
                    )
    return bundle.finish(
        "Final PDF has all expected pages, chamber methods, chart headers and legends; every "
        "qualified page boundary on all Senate and House charts reconciles to its member rows. Every "
        "published chart cell, including blank and excluded results, is retained as displayed. "
        "Docling observations and processing identity are retained privately; undecoded font tokens refuse."
    )
