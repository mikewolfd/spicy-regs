"""C4IP's complete first-edition official report PDF and its disclosed grades/methods.

The publisher expressly names a separate member-action annex in page 20 footnote 17.
The accepted scope is the publisher-defined standalone report, not that missing ledger.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    pdf,
    soup,
)

parser_version = "c4ip-first-edition-published-report-docling/2"
HOSTS = ("c4ip.org",)
INDEX = "https://c4ip.org/resources/congressional-innovation-scorecard/"
URL = "https://c4ip.org/wp-content/uploads/2024/03/2024-Congressional-Innovation-Scorecard.pdf"
EDITION = ScorecardEdition(
    "c4ip",
    "2024-first-edition",
    URL,
    "The Congressional Innovation Scorecard: First Edition",
    year="2024",
    chamber="both",
    is_current=False,
)
# Measured historical table boundaries; retained-corpus qualification 2026-10-03.
# A changed report requires requalification instead of silently admitting a cut table.
TABLE_ROWS = {
    28: 28,
    29: 39,
    30: 32,
    32: 19,
    33: 39,
    34: 39,
    35: 39,
    36: 39,
    37: 39,
    38: 39,
    39: 39,
    40: 39,
    41: 39,
    42: 39,
    43: 22,
}


@dataclass(frozen=True, slots=True)
class PublishedReport:
    """Complete report observations; no companion member-action ledger is implied."""

    grades: tuple[dict[str, str | None], ...]
    component_definitions: tuple[tuple[str, str], ...]
    methodology_path: str
    grade_header_path: str
    methodology_text: str
    missing_source_text: str


def parse_published_report(source, context: ScorecardContext) -> PublishedReport:
    rows = []
    with pdf(source, context, expected_pages=46) as document:
        if document.page_count != 46 or "First Edition" not in document[0].text or "March 2024" not in document[0].text:
            raise ScorecardSourceError("C4IP first-edition PDF identity or page boundary changed")
        method = "\n".join(document[i].text for i in range(17, 22))
        if "Data Annex" not in method or "116" not in method or "118" not in method:
            raise ScorecardSourceError("C4IP first-edition method or annex declaration changed")
        for chamber, pages, columns in (("Senate", range(27, 30), 5), ("House", range(31, 43), 6)):
            for index in pages:
                tables = document[index].tables
                if len(tables) != 1:
                    raise ScorecardSourceError("C4IP rating page table geometry changed")
                data = tables[0].cells
                if len(data) - 1 != TABLE_ROWS[index + 1]:
                    raise ScorecardSourceError("C4IP first-edition rating table boundary changed or was truncated")
                if len(data) < 2 or len(data[0]) != columns or not any("Grade" in (cell or "") for cell in data[0]):
                    raise ScorecardSourceError("C4IP rating table header changed")
                for row_index, row in enumerate(data[1:], 2):
                    if (
                        len(row) != columns
                        or any(cell is None or not cell for cell in row)
                        or re.fullmatch(r"[ABCDF][+−-]?", row[-1]) is None
                    ):
                        raise ScorecardSourceError("C4IP rating row changed")
                    rows.append(
                        {
                            "chamber": chamber,
                            "first_name": row[0],
                            "last_name": row[1],
                            "state": row[2],
                            "district": row[3] if chamber == "House" else None,
                            "party": row[-2],
                            "grade": row[-1],
                            "source_path": document[index].path(table=1, row=row_index),
                        }
                    )
        identity = [
            (row["chamber"], row["state"], row["district"], row["first_name"], row["last_name"]) for row in rows
        ]
        if not rows or len(set(identity)) != len(identity):
            raise ScorecardSourceError("C4IP published grades contain duplicate or empty source members")
        dimension_tables = document[18].tables
        if len(dimension_tables) != 1 or len(dimension_tables[0].cells) != 3:
            raise ScorecardSourceError("C4IP source dimension definitions changed")
        components = tuple(row[0] for row in dimension_tables[0].cells)
        if any(not value.startswith(f"Dimension {i}:") for i, value in enumerate(components, 1)):
            raise ScorecardSourceError("C4IP source dimension identities changed")
        return PublishedReport(
            tuple(rows),
            tuple((name, document[18].path(table=1, row=i, column=1)) for i, name in enumerate(components, 1)),
            document[19].path() + "/footnote[17]",
            document[27].path(table=1, row=1, column=5),
            method,
            "Separate stand-alone Data Annex named on PDF page 20 footnote 17 is not acquired; "
            "its item/member action ledger and score reproduction are unsupported.",
        )


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    source = context.read(INDEX, stage="scorecards:c4ip:listing", hosts=HOSTS)
    if URL not in {link.get("href") for link in soup(source).select("a[href]")}:
        raise ScorecardSourceError("C4IP no longer lists the qualified first-edition report")
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("C4IP reader only parses the qualified first-edition PDF layout")
    source = context.read(URL, stage="scorecards:c4ip:report", hosts=HOSTS)
    report = parse_published_report(source, context)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Council for Innovation Promotion",
        parser_version=parser_version,
        rendition_rule="c4ip-official-first-edition-report-only/1",
        homepage="https://c4ip.org",
    )
    bundle.use(source, "report_grades", "report_component_definitions", "report_methodology")
    bundle.add(
        "scorecard_methodologies",
        source,
        report.methodology_path,
        methodology_id="report-scope",
        methodology_text="separate stand-alone “Data Annex” accompanying this report",
        methodology_url=URL,
        disclosure_status="partial: report only; " + report.missing_source_text,
    )
    bundle.metric(source, "overall", "Alphabetical Grade", path=report.grade_header_path, unit="grade")
    for position, (name, path) in enumerate(report.component_definitions, 1):
        metric_id = f"dimension-{position}"
        bundle.metric(source, metric_id, name, path=path, primary=False)
        bundle.add(
            "scorecard_metric_components", source, path, parent_metric_id="overall", component_metric_id=metric_id
        )
    for row in report.grades:
        parts = (row["chamber"], row["state"], row["first_name"], row["last_name"])
        member_id = key(*parts, row["district"]) if row["district"] else key(*parts)
        bundle.add(
            "scorecard_members",
            source,
            row["source_path"],
            publisher_member_key=member_id,
            member_name=row["first_name"] + " " + row["last_name"],
            chamber_text=row["chamber"],
            state=row["state"],
            district=row["district"],
            party=row["party"],
        )
        bundle.add(
            "scorecard_member_ratings",
            source,
            row["source_path"] + "/Grade",
            metric_id="overall",
            publisher_member_key=member_id,
            value_text=row["grade"],
        )
    return bundle.finish(
        "Complete publisher-defined First Edition report PDF: all pages, published House and "
        "Senate grade tables, and disclosed component definitions acquired. The qualified fixed "
        "report table boundaries reconcile. Companion standalone Data Annex unavailable; its "
        "item/member action ledger and reproduction remain unsupported. Empty item/result tables "
        "describe this supported report scope and do not assert an empty underlying ledger."
    )
