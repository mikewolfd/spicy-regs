"""Readable publisher XML with exact character-offset source maps across USLM, eCFR, and bill DTD profiles.

This module promotes the RefSpec ``xml_text`` mapping contract into SpicyDocs and extends it to
GPO USLM enactments (``pLaw``, ``statutesAtLarge``, ``statuteCompilation``, USLM bills) and
Congressional Bill DTD documents (``bill``, ``resolution``, ``amendment-doc``).

Offset contract
---------------
- **Offset unit** (:data:`TEXT_OFFSET_UNIT`): ``unicode_code_points`` — 0-based, half-open
  ``[start, end)`` indices into the Python ``str`` rendition returned as ``text`` (Unicode scalar
  values after XML decoding, never UTF-8 bytes and never UTF-16 code units).
- **Rendition identifiers**:
  - ``uslm-block-boundaries/1``: OLRC USLM 1.0 (``uscDoc``) and GPO USLM 2.x (``pLaw``,
    ``statutesAtLarge``, ``statuteCompilation``, USLM ``bill`` / ``resolution`` / ``amendment``).
  - ``ecfr-block-boundaries/1``: eCFR ``ECFR`` and typed ``DIV1``–``DIV9`` documents.
  - ``bill-dtd-block-boundaries/1``: Congressional Bill DTD documents (``bill``, ``resolution``,
    ``amendment-doc``).
- **Traceability**: Every node retains its namespace-independent positional XPath (``/*[1]/*[2]``),
  its exact decoded ``source_text`` bounds (``source_start``, ``source_end``), and—whenever the node
  carries at least one character of text—its exact ``[start, end)`` slice in ``text`` beside
  ``text_sha256`` (``sha256:`` over UTF-8 bytes of ``text``). Empty/self-closing elements omit
  ``start``/``end`` (represented as ``None`` on :class:`XmlTextSpan`).
"""

from __future__ import annotations

import hashlib
from bisect import bisect_left, bisect_right
from collections.abc import Mapping, Sequence
from typing import Any
from xml.etree.ElementTree import Element

from spicy_docs.reading.xml import parse_xml
from spicy_docs.schemas.text_spans import (
    BILL_DTD_RENDITION,
    ECFR_RENDITION,
    TEXT_OFFSET_UNIT,
    USLM_RENDITION,
    XmlTextSpan,
)


def _text_sha256(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


MAX_XML_BYTES = 256 * 1024 * 1024
MAX_XML_DEPTH = 256

_OLRC_USLM_NAMESPACE = "http://xml.house.gov/schemas/uslm/1.0"
_GPO_USLM_NAMESPACE = "http://schemas.gpo.gov/xml/uslm"

_USLM_ROOTS = frozenset(
    {
        f"{{{_OLRC_USLM_NAMESPACE}}}uscDoc",
        f"{{{_GPO_USLM_NAMESPACE}}}pLaw",
        f"{{{_GPO_USLM_NAMESPACE}}}statutesAtLarge",
        f"{{{_GPO_USLM_NAMESPACE}}}statuteCompilation",
        f"{{{_GPO_USLM_NAMESPACE}}}bill",
        f"{{{_GPO_USLM_NAMESPACE}}}resolution",
        f"{{{_GPO_USLM_NAMESPACE}}}amendment",
    }
)
_BILL_DTD_ROOTS = frozenset({"bill", "resolution", "amendment-doc"})

_TEXT_BLOCKS = frozenset(
    [
        "main",
        "appendix",
        "title",
        "subtitle",
        "chapter",
        "subchapter",
        "part",
        "subpart",
        "division",
        "subdivision",
        "level",
        "compiledAct",
        "courtRules",
        "courtRule",
        "reorganizationPlans",
        "reorganizationPlan",
        "section",
        "subsection",
        "paragraph",
        "subparagraph",
        "clause",
        "subclause",
        "item",
        "subitem",
        "subsubitem",
        "continuation",
        "notes",
        "sourceCredit",
        "note",
        "p",
        "ul",
        "ol",
        "li",
        "longTitle",
        "enactingFormula",
        "table",
        "thead",
        "tbody",
        "tfoot",
        "tr",
    ]
)
_TEXT_CELLS = frozenset({"td", "th"})
_ECFR_DIVS = frozenset("DIV" + str(n) for n in range(1, 10))
_ECFR_TYPES = frozenset(
    ["TITLE", "SUBTITLE", "CHAPTER", "SUBCHAP", "SUBCHAPTER", "PART", "SUBPART", "SECTION", "APPENDIX"]
)
_ECFR_BLOCKS = (
    frozenset(
        [
            "P",
            "PSPACE",
            "HEAD",
            "HED",
            "HD",
            "EDNOTE",
            "EFFDNOT",
            "CITA",
            "NOTE",
            "NOTES",
            "TABLE",
            "THEAD",
            "TBODY",
            "TFOOT",
            "TR",
            "CAPTION",
            "DIV",
            "LI",
            "UL",
            "OL",
        ]
    )
    | _ECFR_DIVS
)
_BILL_DTD_BLOCKS = frozenset(
    [
        "metadata",
        "dublinCore",
        "form",
        "legis-body",
        "resolution-body",
        "preamble",
        "whereas",
        "division",
        "title",
        "subtitle",
        "chapter",
        "subchapter",
        "part",
        "subpart",
        "section",
        "subsection",
        "paragraph",
        "subparagraph",
        "clause",
        "subclause",
        "item",
        "subitem",
        "text",
        "header",
        "official-title",
        "action",
        "action-desc",
        "committee-name",
        "quoted-block",
        "after-quoted-block",
        "toc",
        "toc-entry",
        "list",
        "list-item",
        "amendment-block",
        "engrossment-data",
        "attestation",
        "endorsement",
        "table",
        "tgroup",
        "thead",
        "tbody",
        "row",
    ]
)
_BILL_DTD_CELLS = frozenset({"entry"})
_SEPARATOR_RANK = {"": 0, " ": 1, "\t": 2, "\n\n": 3}

_RENDITIONS = {
    "uslm": USLM_RENDITION,
    "ecfr": ECFR_RENDITION,
    "bill-dtd": BILL_DTD_RENDITION,
}


def _resolve_profile(root: Element, profile: str | None, *, allow_fragments: bool) -> str:
    if profile is None:
        if root.tag in _USLM_ROOTS:
            profile = "uslm"
        elif root.tag in _BILL_DTD_ROOTS:
            profile = "bill-dtd"
        else:
            profile = "ecfr"
    if profile not in _RENDITIONS:
        raise ValueError("Unknown publisher XML text profile")
    if allow_fragments:
        return profile
    if profile == "uslm":
        if root.tag not in _USLM_ROOTS:
            raise ValueError("Expected a captured USLM document")
    elif profile == "ecfr":
        if root.tag != "ECFR" and not (root.tag in _ECFR_DIVS and root.get("TYPE") in _ECFR_TYPES):
            raise ValueError("Expected captured eCFR ECFR or typed DIV XML")
    elif profile == "bill-dtd" and root.tag not in _BILL_DTD_ROOTS:
        raise ValueError("Expected captured Congressional Bill DTD XML")
    return profile


def _read_text_from_root(root: Element, profile: str) -> dict[str, Any]:
    ecfr = profile == "ecfr"
    bill_dtd = profile == "bill-dtd"
    raw_parts: list[str] = []
    output: list[str] = []
    parts: list[dict[str, Any]] = []
    nodes: dict[str, dict[str, Any]] = {}
    raw_cursor = cursor = 0
    pending = ""
    trailing_newlines, trailing_tab = 0, False

    def append(value: str | None) -> None:
        nonlocal raw_cursor, cursor, pending, trailing_newlines, trailing_tab
        if not value:
            return
        if pending and value.strip():
            # Existing source whitespace remains source text. Supply only the
            # missing separator before the next visible source character.
            leading = value[: len(value) - len(value.lstrip())]
            if pending == "\n\n":
                needed = max(0, 2 - trailing_newlines - leading.count("\n"))
            elif pending == "\t":
                needed = 0 if trailing_tab or "\t" in leading else 1
            else:
                whitespace_before = output and output[-1][-1:].isspace()
                needed = 0 if whitespace_before or leading else 1
            separator = ("\n" if pending == "\n\n" else pending) * needed
            if cursor and separator:
                output.append(separator)
                parts.append({"kind": "inserted", "start": cursor, "end": cursor + len(separator), "text": separator})
                cursor += len(separator)
            pending = ""
        output.append(value)
        part = {
            "kind": "source",
            "start": cursor,
            "end": cursor + len(value),
            "source_start": raw_cursor,
            "source_end": raw_cursor + len(value),
        }
        if parts and parts[-1]["kind"] == "source":
            parts[-1].update(end=part["end"], source_end=part["source_end"])
        else:
            parts.append(part)
        cursor += len(value)
        raw_cursor += len(value)
        raw_parts.append(value)
        if not value.isspace():
            trailing_newlines, trailing_tab = 0, False
        trailing = value[len(value.rstrip()) :]
        trailing_newlines += trailing.count("\n")
        trailing_tab |= "\t" in trailing

    def boundary(separator: str) -> None:
        nonlocal pending
        if _SEPARATOR_RANK[separator] > _SEPARATOR_RANK[pending]:
            pending = separator

    def cell_separator() -> None:
        # eCFR preserves empty columns as explicit tabs, including first/last
        # empty cells. Unlike deferred whitespace, an empty cell earns its slot.
        nonlocal cursor, pending, trailing_newlines, trailing_tab
        separator = ("\n" * max(0, 2 - trailing_newlines)) if pending == "\n\n" and cursor else ""
        if separator:
            output.append(separator)
            parts.append({"kind": "inserted", "start": cursor, "end": cursor + len(separator), "text": separator})
            cursor += len(separator)
            trailing_newlines += len(separator)
        pending = ""

    def visit(
        node: Element,
        path: str,
        parent: str = "",
        inside_cell: bool = False,
        previous_cell: bool = False,
    ) -> None:
        nonlocal pending, cursor, trailing_newlines, trailing_tab
        tag = node.tag.rsplit("}", 1)[-1]
        kind = tag.upper() if ecfr else tag
        if ecfr:
            cell = kind in {"TD", "TH"}
            block = kind in _ECFR_BLOCKS and not (inside_cell and kind == "P")
        elif bill_dtd:
            cell = tag in _BILL_DTD_CELLS
            block = tag in _BILL_DTD_BLOCKS and not (inside_cell and tag == "text")
        else:
            cell = tag in _TEXT_CELLS
            block = tag in _TEXT_BLOCKS and not (inside_cell and tag == "p")
            block |= tag == "content" and parent in {"section", "reorganizationPlan"}
            block |= tag == "heading" and parent in {"note", "appendix"}
            block |= tag == "chapeau" and any(c.startswith("blockIndent") for c in node.get("class", "").split())
        if block or (ecfr and kind == "BR") or (not ecfr and tag == "br"):
            boundary("\n\n")
        if cell and ecfr:
            cell_separator()
            if previous_cell and not trailing_tab:
                output.append("\t")
                parts.append({"kind": "inserted", "start": cursor, "end": cursor + 1, "text": "\t"})
                cursor += 1
                trailing_tab = True
        elif cell:
            boundary("\t")
        start = raw_cursor
        append(node.text)
        seen_cell = False
        for index, child in enumerate(node, 1):
            visit(child, path + f"/*[{index}]", tag, inside_cell or cell, seen_cell)
            seen_cell |= child.tag.rsplit("}", 1)[-1].upper() in {"TD", "TH"}
            append(child.tail)
        nodes[path] = {
            "source_start": start,
            "source_end": raw_cursor,
            "tag": tag,
            **(
                {"attributes": dict(node.attrib)}
                if ecfr
                else {"identifier": node.get("identifier")}
                if node.get("identifier")
                else {}
            ),
        }
        if (
            block
            or (not ecfr and not bill_dtd and tag == "heading" and parent == "section")
            or (inside_cell and ((ecfr and kind == "P") or (not ecfr and not bill_dtd and tag == "p")))
        ):
            boundary("\n\n")
        if (not ecfr and not bill_dtd and tag == "heading") or (bill_dtd and tag in {"enum", "header"}):
            boundary(" ")
        if cell:
            pending = "" if ecfr else "\t"
            if ecfr:
                trailing_tab = False  # Only a following source gap can separate the next cell.

    visit(root, "/*[1]")
    source_text, text = "".join(raw_parts), "".join(output)
    sources = [part for part in parts if part["kind"] == "source"]
    starts = [part["source_start"] for part in sources]
    ends = [part["source_end"] for part in sources]
    for node in nodes.values():
        lo, hi = node["source_start"], node["source_end"]
        if lo < hi:
            first = sources[bisect_right(ends, lo)]
            last = sources[bisect_left(starts, hi) - 1]
            node.update(
                start=first["start"] + lo - first["source_start"],
                end=last["start"] + hi - last["source_start"],
            )
    return {
        "text": text,
        "source_text": source_text,
        "source_map": parts,
        "nodes": nodes,
        "method": _RENDITIONS[profile],
        "offset_unit": TEXT_OFFSET_UNIT,
        "text_sha256": _text_sha256(text),
    }


def read_text(
    xml: bytes,
    *,
    profile: str | None = None,
    allow_fragments: bool = False,
    max_bytes: int = MAX_XML_BYTES,
    max_depth: int = MAX_XML_DEPTH,
) -> dict[str, Any]:
    """Map decoded code points after the shared parser checks source size and depth.

    Returns ``text``, raw ``source_text``, ``source_map`` of source and inserted spans, ``nodes``
    keyed by positional XPath, ``method`` (rendition identifier), ``offset_unit``
    (``unicode_code_points``), and ``text_sha256``. Inert external DOCTYPE declarations are
    accepted without loading them; internal subsets and entities are refused.
    """
    root = parse_xml(
        xml,
        max_bytes=max_bytes,
        max_depth=max_depth,
        error_type=ValueError,
        label="Publisher text XML",
        allow_external_doctype=True,
    )
    resolved = _resolve_profile(root, profile, allow_fragments=allow_fragments)
    return _read_text_from_root(root, resolved)


def map_source_span(
    source_map: Sequence[Mapping[str, Any]],
    source_start: int,
    source_end: int,
) -> tuple[int, int] | None:
    """Project a half-open ``[source_start, source_end)`` span in ``source_text`` into ``text`` offsets.

    Returns ``None`` when ``source_start == source_end`` (an empty span). Raises ``ValueError``
    when the requested range is inverted or lies outside the mapped source text.
    """
    if type(source_start) is not int or type(source_end) is not int or source_start < 0 or source_end < source_start:
        raise ValueError("source span bounds must satisfy 0 <= source_start <= source_end")
    sources = [part for part in source_map if part["kind"] == "source"]
    max_end = sources[-1]["source_end"] if sources else 0
    if source_end > max_end:
        raise ValueError("source span exceeds mapped source_text length")
    if source_start == source_end:
        return None
    starts = [part["source_start"] for part in sources]
    ends = [part["source_end"] for part in sources]
    first = sources[bisect_right(ends, source_start)]
    last = sources[bisect_left(starts, source_end) - 1]
    return (
        first["start"] + source_start - first["source_start"],
        last["start"] + source_end - last["source_start"],
    )


class XmlTextIndex:
    """Indexed readable-text rendition for O(log N) XPath and sub-element character-offset lookups."""

    __slots__ = (
        "_ends",
        "_sources",
        "_starts",
        "nodes",
        "offset_unit",
        "rendition",
        "rendition_sha256",
        "source_map",
        "source_text",
        "text",
    )

    def __init__(self, rendered: Mapping[str, Any]) -> None:
        self.rendition: str = rendered["method"]
        self.offset_unit: str = rendered["offset_unit"]
        self.rendition_sha256: str = rendered["text_sha256"]
        self.text: str = rendered["text"]
        self.source_text: str = rendered["source_text"]
        self.source_map: list[dict[str, Any]] = rendered["source_map"]
        self.nodes: dict[str, dict[str, Any]] = rendered["nodes"]
        self._sources = [part for part in self.source_map if part["kind"] == "source"]
        self._starts = [part["source_start"] for part in self._sources]
        self._ends = [part["source_end"] for part in self._sources]

    def map_source_span(self, source_start: int, source_end: int) -> tuple[int, int] | None:
        """Project ``[source_start, source_end)`` in ``source_text`` to ``text`` code-point offsets."""
        if (
            type(source_start) is not int
            or type(source_end) is not int
            or source_start < 0
            or source_end < source_start
        ):
            raise ValueError("source span bounds must satisfy 0 <= source_start <= source_end")
        max_end = self._ends[-1] if self._ends else 0
        if source_end > max_end:
            raise ValueError("source span exceeds mapped source_text length")
        if source_start == source_end:
            return None
        first = self._sources[bisect_right(self._ends, source_start)]
        last = self._sources[bisect_left(self._starts, source_end) - 1]
        return (
            first["start"] + source_start - first["source_start"],
            last["start"] + source_end - last["source_start"],
        )

    def span_for_xpath(self, source_xpath: str) -> XmlTextSpan:
        """Return the exact :class:`XmlTextSpan` for positional XPath ``source_xpath``."""
        node = self.nodes[source_xpath]
        start = node.get("start")
        end = node.get("end")
        return XmlTextSpan(
            rendition=self.rendition,
            offset_unit=self.offset_unit,
            rendition_sha256=self.rendition_sha256,
            start=start,
            end=end,
            text=None if start is None or end is None else self.text[start:end],
            source_start=node["source_start"],
            source_end=node["source_end"],
        )

    def map_element_subspan(self, source_xpath: str, local_start: int, local_end: int) -> tuple[int, int] | None:
        """Map a ``[local_start, local_end)`` span inside an element's decoded XML text into ``text``."""
        node = self.nodes[source_xpath]
        lo, hi = node["source_start"], node["source_end"]
        length = hi - lo
        if type(local_start) is not int or type(local_end) is not int or not (0 <= local_start <= local_end <= length):
            raise ValueError("local span exceeds element decoded text bounds")
        return self.map_source_span(lo + local_start, lo + local_end)


def read_xml_text_index(
    xml: bytes,
    *,
    source_family: str | None = None,
    profile: str | None = None,
    allow_fragments: bool = False,
    max_bytes: int = MAX_XML_BYTES,
    max_depth: int = MAX_XML_DEPTH,
) -> XmlTextIndex:
    """Parse ``xml`` once and return an :class:`XmlTextIndex` for the requested family or profile.

    When ``profile`` is omitted and ``source_family`` is supplied:
    - ``ecfr`` selects ``ecfr`` (``ecfr-block-boundaries/1``);
    - ``uscode``, ``law``, and ``statute`` select ``uslm`` (``uslm-block-boundaries/1``);
    - ``bill`` inspects the parsed root namespace, selecting ``uslm`` for USLM bills and
      ``bill-dtd`` (``bill-dtd-block-boundaries/1``) for Congressional Bill DTD documents.
    """
    root = parse_xml(
        xml,
        max_bytes=max_bytes,
        max_depth=max_depth,
        error_type=ValueError,
        label="Publisher text XML",
        allow_external_doctype=True,
    )
    selected = profile
    if selected is None and source_family is not None:
        if source_family == "ecfr":
            selected = "ecfr"
        elif source_family in {"uscode", "law", "statute"}:
            selected = "uslm"
        elif source_family == "bill":
            selected = (
                "uslm"
                if root.tag.startswith((f"{{{_GPO_USLM_NAMESPACE}}}", f"{{{_OLRC_USLM_NAMESPACE}}}"))
                else "bill-dtd"
            )
        else:
            raise ValueError(f"Unknown native reference source family: {source_family!r}")
    resolved = _resolve_profile(root, selected, allow_fragments=allow_fragments)
    return XmlTextIndex(_read_text_from_root(root, resolved))


__all__ = [
    "BILL_DTD_RENDITION",
    "ECFR_RENDITION",
    "MAX_XML_BYTES",
    "MAX_XML_DEPTH",
    "TEXT_OFFSET_UNIT",
    "USLM_RENDITION",
    "XmlTextIndex",
    "XmlTextSpan",
    "map_source_span",
    "read_text",
    "read_xml_text_index",
]
