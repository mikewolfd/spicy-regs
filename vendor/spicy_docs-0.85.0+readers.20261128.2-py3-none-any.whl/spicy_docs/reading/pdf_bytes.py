"""The PDF facts document routes check: the magic header, the trailer, the linearization length and the final xref.

Publishers state ``application/pdf`` or ``application/octet-stream`` for the
same file, so the media type proves nothing; the bytes do. ``%PDF-x.y`` at the
start identifies the stated format, and ``%%EOF`` inside the last kilobyte
is a completion witness. An earlier trailer can survive a truncated update,
so it cannot establish completeness alone. :func:`linearized_length` and
:func:`terminal_xref_offset` read further witnesses; whether a route requires
them stays with the route. :func:`assess_pdf_bytes` reports these observations
without making a reader or source-fidelity decision.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

PDF_MAGIC = b"%PDF-"
_PDF_HEADER = re.compile(rb"%PDF-([0-9]\.[0-9])")
TRAILER_WINDOW = 1024
#: A linearization dictionary sits in the first object, so its ``/L`` is read from the first 2 KiB only.
_LINEARIZED_LENGTH = re.compile(rb"/Linearized[^>]{0,64}?/L\s+([0-9]+)")
_LINEARIZATION_WINDOW = 2048
_FINAL_XREF = re.compile(rb"startxref\s+([0-9]+)\s+%%EOF\s*\Z")
_XREF_OBJECT = re.compile(rb"[0-9]+\s+[0-9]+\s+obj\s*<<")
_XREF_HEADER_WINDOW = 2048
_ZERO_TAIL_WINDOW = 64 << 10


@dataclass(frozen=True)
class PdfByteFacts:
    """Bounded byte observations, not a PDF-parser or source-fidelity verdict."""

    byte_size: int
    pdf_version: str | None
    declared_linearized_bytes: int | None
    trailer_window: int
    eof_in_tail: bool
    terminal_xref_offset: int | None
    trailing_zero_bytes: int
    zero_tail_scan_complete: bool
    issues: tuple[str, ...]


def assess_pdf_bytes(body: bytes, *, trailer_window: int = TRAILER_WINDOW) -> PdfByteFacts:
    """Read existing PDF witnesses and a bounded zero-filled-tail observation.

    A declared linearized length can predate an appended revision, so only a
    capture shorter than that length is flagged. A missing nearby trailer or
    unverified xref nominates structural review; trailing padding and repairable
    files require a real reader. No result certifies complete or meaningful text.
    A zero suffix is counted up to 64 KiB without copying the document; the
    completion flag distinguishes an exact count from a lower bound.
    """
    if not isinstance(body, (bytes, bytearray)):
        raise TypeError("PDF byte assessment requires bytes")
    if type(trailer_window) is not int or trailer_window <= 0:
        raise ValueError("trailer_window must be a positive integer")
    header = _PDF_HEADER.match(body)
    version = header[1].decode("ascii") if header else None
    length = linearized_length(body) if header else None
    eof = b"%%EOF" in body[-trailer_window:]
    xref = terminal_xref_offset(body) if header else None
    position = len(body)
    lower = max(0, position - _ZERO_TAIL_WINDOW)
    while position > lower and body[position - 1] == 0:
        position -= 1
    zero_count = len(body) - position
    zero_complete = position == 0 or position > lower
    issues = []
    if not body:
        issues.append("empty_pdf_response")
    elif not header:
        issues.append("missing_pdf_header")
    else:
        if length is not None and len(body) < length:
            issues.append("shorter_than_linearized_length")
        if not eof:
            issues.append("missing_pdf_trailer")
        if xref is None:
            issues.append("terminal_xref_not_verified")
        # A compressed stream can end in a single zero. Require enough zeros
        # to fill the standard trailer window before naming a zero-filled tail.
        if zero_count >= TRAILER_WINDOW and not eof:
            issues.append("zero_filled_tail")
    return PdfByteFacts(len(body), version, length, trailer_window, eof, xref, zero_count, zero_complete, tuple(issues))


def check_pdf_bytes(
    body: bytes, *, error_type: type[ValueError], label: str, trailer_window: int = TRAILER_WINDOW
) -> str:
    """Refuse empty bytes, a non-``%PDF-`` start, or a missing trailer; return the stated version.

    The default ``%%EOF`` check covers the last 1024 bytes, which a
    publisher-omitted Content-Length cannot prove. A caller can preserve an
    explicitly reviewed route's different trailer window.
    """
    if type(trailer_window) is not int or trailer_window <= 0:
        raise ValueError("trailer_window must be a positive integer")
    if not isinstance(body, (bytes, bytearray)) or not body:
        raise error_type(f"{label} response is empty; a nonempty PDF was requested")
    header = _PDF_HEADER.match(body)
    if header is None:
        raise error_type(f"{label} does not begin with the %PDF- magic")
    if b"%%EOF" not in bytes(body[-trailer_window:]):
        raise error_type(f"{label} does not end with a PDF trailer; the capture is incomplete")
    return header[1].decode("ascii")


def linearized_length(body: bytes) -> int | None:
    """The file length a linearization dictionary states (``/L``), or None for a PDF that is not linearized."""
    stated = _LINEARIZED_LENGTH.search(body, 0, _LINEARIZATION_WINDOW)
    return int(stated[1]) if stated else None


def terminal_xref_offset(body: bytes) -> int | None:
    """The final ``startxref`` offset when it names a cross-reference table or stream inside ``body``, else None.

    The file must end ``startxref N %%EOF``, and ``N`` must point inside the
    capture at an ``xref`` table or an object whose dictionary states
    ``/Type/XRef`` before its stream, which rejects the ``startxref 0`` a
    linearized file's first-page section carries. This is a bounded
    completeness check, not a PDF parser or a semantic-validity claim.
    """
    trailer = _FINAL_XREF.search(body, max(0, len(body) - TRAILER_WINDOW))
    if trailer is None:
        return None
    offset = int(trailer[1])
    if not 0 < offset < trailer.start():
        return None
    header = body[offset : min(offset + _XREF_HEADER_WINDOW, trailer.start())]
    if re.match(rb"xref\s", header):
        return offset
    if _XREF_OBJECT.match(header) is None or (stream := re.search(rb"\bstream(?:\r\n|\r|\n)", header)) is None:
        return None
    dictionary = header[: stream.start()]
    if (
        dictionary.rstrip().endswith(b">>")
        and re.search(rb"\bendobj\b", dictionary) is None
        and re.search(rb"/Type\s*/XRef(?=[\x00\t\n\f\r ()<>\[\]{}/%])", dictionary) is not None
    ):
        return offset
    return None
