"""Bounded TAR (`.tar` and `.tar.gz`/`.tgz`) inspection and selective member reads."""

from __future__ import annotations

import gzip
import hashlib
import io
import os
import tarfile
import zlib
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Literal

from spicy_docs.sources.contracts import canonical_sha256

_CHUNK_BYTES = 64 * 1024
_GZIP_MAGIC = b"\x1f\x8b"


class TarArchiveError(ValueError):
    """Raised when a TAR archive violates safety, type, size, or entry bounds."""


class TarTruncatedError(TarArchiveError):
    """Raised when a TAR or gzip-compressed TAR stream ends prematurely."""


@dataclass(frozen=True, slots=True)
class TarArchiveMember:
    """Verified metadata and digest for one member of a TAR drop."""

    name: str
    byte_size: int
    member_type: Literal["file", "directory"]
    sha256: str | None
    mode: int
    mtime: int
    kept: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "byte_size": self.byte_size,
            "member_type": self.member_type,
            "sha256": self.sha256,
            "mode": self.mode,
            "mtime": self.mtime,
            "kept": self.kept,
        }


def _check_positive_int(value: object, name: str, error_type: type[ValueError]) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise error_type(f"{name} must be a positive integer")
    return value


def _safe_member_name(raw_name: str, *, error_type: type[ValueError], label: str) -> str:
    if not isinstance(raw_name, str) or not raw_name or "\x00" in raw_name:
        raise error_type(f"{label} contains an empty or NUL member name")
    if "\\" in raw_name:
        raise error_type(f"{label} contains a backslash in member name {raw_name!r}")
    normalized = raw_name.rstrip("/")
    if not normalized:
        normalized = "."
    if raw_name.startswith("/"):
        raise error_type(f"{label} contains an absolute path {raw_name!r}")
    if len(normalized) >= 2 and normalized[1] == ":" and normalized[0].isalpha():
        raise error_type(f"{label} contains a drive-qualified path {raw_name!r}")
    parts = PurePosixPath(normalized).parts
    if any(part == ".." for part in parts):
        raise error_type(f"{label} contains a parent-traversal path {raw_name!r}")
    clean = "/".join(part for part in parts if part != ".")
    if not clean:
        raise error_type(f"{label} resolves to an empty relative member path {raw_name!r}")
    return clean


def _decompress_bounded_gzip(
    data: bytes,
    *,
    max_decompressed_bytes: int,
    error_type: type[ValueError],
    label: str,
) -> bytes:
    """Decompress a bounded gzip TAR stream, distinguishing truncation vs size overflow."""
    stream = io.BytesIO(data)
    out = bytearray()
    try:
        with gzip.GzipFile(fileobj=stream, mode="rb") as gz:
            while True:
                chunk = gz.read(_CHUNK_BYTES)
                if not chunk:
                    break
                if len(out) + len(chunk) > max_decompressed_bytes:
                    raise error_type(f"{label} decompressed stream exceeds {max_decompressed_bytes} bytes")
                out.extend(chunk)
    except error_type:
        raise
    except (EOFError, zlib.error, OSError) as exc:
        if error_type in (ValueError, TarArchiveError, TarTruncatedError):
            raise TarTruncatedError(f"{label} gzip stream is truncated or corrupt: {exc}") from exc
        raise error_type(f"{label} gzip stream is truncated or corrupt: {exc}") from exc
    return bytes(out)


def _tar_raw_bytes(
    data: bytes,
    *,
    max_bytes: int,
    max_entries: int,
    max_total_bytes: int,
    compression: Literal["auto", "none", "gzip"],
    error_type: type[ValueError],
    label: str,
) -> tuple[bytes, str]:
    _check_positive_int(max_bytes, "max_bytes", error_type)
    _check_positive_int(max_entries, "max_entries", error_type)
    _check_positive_int(max_total_bytes, "max_total_bytes", error_type)
    if not isinstance(data, bytes) or not data:
        raise error_type(f"{label} must be nonempty bytes")
    if len(data) > max_bytes:
        raise error_type(f"{label} exceeds max_bytes={max_bytes}")
    use_gzip = compression == "gzip" or (compression == "auto" and data.startswith(_GZIP_MAGIC))
    if use_gzip:
        # Allow 512-byte ustar header + padding per entry plus trailer blocks on top of payload budget.
        header_overhead = (max_entries * 1024) + 8192
        raw = _decompress_bounded_gzip(
            data,
            max_decompressed_bytes=max_total_bytes + header_overhead,
            error_type=error_type,
            label=label,
        )
        return raw, "gzip"
    return data, "none"


def inspect_tar_archive(
    data: bytes,
    *,
    max_bytes: int,
    max_entries: int = 4096,
    max_entry_bytes: int = 64 * 1024**2,
    max_total_bytes: int = 256 * 1024**2,
    compression: Literal["auto", "none", "gzip"] = "auto",
    keep: Callable[[str], bool] | None = None,
    collect_payloads: bool = False,
    allow_directories: bool = True,
    error_type: type[ValueError] = TarArchiveError,
    label: str = "tar archive",
) -> dict[str, object]:
    """Validate and inspect a TAR or gzipped TAR archive with strict bounds and truncation detection."""
    _check_positive_int(max_entry_bytes, "max_entry_bytes", error_type)
    raw, actual_compression = _tar_raw_bytes(
        data,
        max_bytes=max_bytes,
        max_entries=max_entries,
        max_total_bytes=max_total_bytes,
        compression=compression,
        error_type=error_type,
        label=label,
    )
    if len(raw) < 1024 or len(raw) % 512 != 0:
        if error_type in (ValueError, TarArchiveError, TarTruncatedError):
            raise TarTruncatedError(f"{label} tar stream is truncated (length={len(raw)})")
        raise error_type(f"{label} tar stream is truncated (length={len(raw)})")

    members: list[TarArchiveMember] = []
    payloads: dict[str, bytes] = {}
    seen_names: set[str] = set()
    total_decoded_bytes = 0
    skipped_count = 0

    try:
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as archive:
            tar_members = archive.getmembers()
            if len(tar_members) > max_entries:
                raise error_type(f"{label} entry count {len(tar_members)} exceeds max_entries={max_entries}")
            for info in tar_members:
                if info.issym() or info.islnk() or info.isdev() or info.ischr() or info.isblk() or info.isfifo():
                    raise error_type(f"{label} contains unsupported non-file entry {info.name!r}")
                if info.isdir():
                    if not allow_directories:
                        raise error_type(f"{label} does not allow directory entry {info.name!r}")
                    clean_name = _safe_member_name(info.name, error_type=error_type, label=label)
                    if clean_name in seen_names:
                        raise error_type(f"{label} repeats member {clean_name!r}")
                    seen_names.add(clean_name)
                    members.append(
                        TarArchiveMember(
                            name=clean_name,
                            byte_size=0,
                            member_type="directory",
                            sha256=None,
                            mode=info.mode,
                            mtime=int(info.mtime),
                            kept=False,
                        )
                    )
                    continue
                if not info.isreg():
                    raise error_type(f"{label} contains unsupported member type for {info.name!r}")
                clean_name = _safe_member_name(info.name, error_type=error_type, label=label)
                if clean_name in seen_names:
                    raise error_type(f"{label} repeats member {clean_name!r}")
                seen_names.add(clean_name)
                if info.size < 0 or info.size > max_entry_bytes:
                    raise error_type(
                        f"{label} member {clean_name!r} size {info.size} exceeds max_entry_bytes={max_entry_bytes}"
                    )
                total_decoded_bytes += info.size
                if total_decoded_bytes > max_total_bytes:
                    raise error_type(f"{label} total decoded size exceeds max_total_bytes={max_total_bytes}")
                should_keep = True if keep is None else bool(keep(clean_name))
                if not should_keep:
                    skipped_count += 1
                    members.append(
                        TarArchiveMember(
                            name=clean_name,
                            byte_size=info.size,
                            member_type="file",
                            sha256=None,
                            mode=info.mode,
                            mtime=int(info.mtime),
                            kept=False,
                        )
                    )
                    continue
                extracted = archive.extractfile(info)
                if extracted is None:
                    raise error_type(f"{label} cannot read file member {clean_name!r}")
                digest = hashlib.sha256()
                observed = 0
                buf = bytearray() if collect_payloads else None
                while True:
                    chunk = extracted.read(_CHUNK_BYTES)
                    if not chunk:
                        break
                    observed += len(chunk)
                    if observed > info.size:
                        raise error_type(f"{label} member {clean_name!r} exceeded declared size")
                    digest.update(chunk)
                    if buf is not None:
                        buf.extend(chunk)
                if observed != info.size:
                    if error_type in (ValueError, TarArchiveError, TarTruncatedError):
                        raise TarTruncatedError(
                            f"{label} member {clean_name!r} is truncated ({observed} != {info.size})"
                        )
                    raise error_type(f"{label} member {clean_name!r} is truncated")
                members.append(
                    TarArchiveMember(
                        name=clean_name,
                        byte_size=info.size,
                        member_type="file",
                        sha256="sha256:" + digest.hexdigest(),
                        mode=info.mode,
                        mtime=int(info.mtime),
                        kept=True,
                    )
                )
                if buf is not None:
                    payloads[clean_name] = bytes(buf)
    except error_type:
        raise
    except (EOFError, tarfile.ReadError, OSError) as exc:
        if error_type in (ValueError, TarArchiveError, TarTruncatedError):
            raise TarTruncatedError(f"{label} tar archive is truncated or corrupt: {exc}") from exc
        raise error_type(f"{label} tar archive is truncated or corrupt: {exc}") from exc

    # Verify proper TAR end-of-archive marker (two 512-byte zero blocks) when raw data wasn't cut off immediately after last header.
    if not raw.endswith(b"\x00" * 1024):
        if error_type in (ValueError, TarArchiveError, TarTruncatedError):
            raise TarTruncatedError(f"{label} lacks two 512-byte end-of-archive blocks")
        raise error_type(f"{label} lacks two 512-byte end-of-archive blocks")

    return {
        "compression": actual_compression,
        "archive_sha256": canonical_sha256(data),
        "archive_bytes": len(data),
        "decoded_bytes": total_decoded_bytes,
        "skipped_count": skipped_count,
        "members": members,
        "payloads": payloads,
    }


def read_tar_member(
    data: bytes,
    member_name: str,
    *,
    max_bytes: int,
    max_entry_bytes: int = 64 * 1024**2,
    max_entries: int = 4096,
    max_total_bytes: int = 256 * 1024**2,
    error_type: type[ValueError] = TarArchiveError,
    label: str = "tar archive",
) -> bytes:
    """Read exact bytes of one named regular member from a bounded TAR archive."""
    clean_target = _safe_member_name(member_name, error_type=error_type, label=label)
    inspected = inspect_tar_archive(
        data,
        max_bytes=max_bytes,
        max_entries=max_entries,
        max_entry_bytes=max_entry_bytes,
        max_total_bytes=max_total_bytes,
        keep=lambda name: os.path.normpath(name) == clean_target,
        collect_payloads=True,
        error_type=error_type,
        label=label,
    )
    payloads: dict[str, bytes] = inspected["payloads"]  # type: ignore[assignment]
    if clean_target not in payloads:
        raise error_type(f"{label} does not contain regular member {clean_target!r}")
    return payloads[clean_target]


__all__ = [
    "TarArchiveError",
    "TarArchiveMember",
    "TarTruncatedError",
    "inspect_tar_archive",
    "read_tar_member",
]
