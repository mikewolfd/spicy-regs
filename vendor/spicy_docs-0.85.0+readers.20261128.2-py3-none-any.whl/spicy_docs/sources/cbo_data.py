"""Read commit-pinned US-CBO/cbo-data catalog, schemas, and tidy CSV vintages.

The Congressional Budget Office publishes 13 machine-readable budget, economic,
and demographic baseline datasets at ``github.com/US-CBO/cbo-data`` with a DCAT
``catalog.json``, per-dataset ``schema.json`` files, and multi-vintage CSVs.
Every request pins a 40-character Git commit SHA rather than a moving branch,
retains exact wire bytes and SHA-256 digests, and validates every CSV row
against its dataset schema before returning records.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import re
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_payload,
    check_request_count,
    check_timing,
    named_challenge,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

REPO = "US-CBO/cbo-data"
RAW_BASE_URL = f"https://raw.githubusercontent.com/{REPO}"
# Verified 2026-11-27 against US-CBO/cbo-data main (2026-06-12T19:14:18Z):
# catalog.json 36,934 B; largest schema.json 75,840 B (ten_year_budget);
# largest CSV 3,853,825 B (demographic/migration_2025-09.csv); 94 files total.
PINNED_COMMIT = "284a95665f9f2f74ed1f482feb629b43fce323da"

BUDGET_DATASETS: tuple[str, ...] = (
    "historical_budget",
    "ten_year_budget",
    "long_term_budget",
    "trust_fund",
    "spending_detail",
    "revenue_detail",
    "tax_parameters",
    "automatic_stabilizers",
)
ECONOMIC_DATASETS: tuple[str, ...] = (
    "historical_economic",
    "economic_projections",
    "long_term_economic",
    "potential_gdp",
    "demographic",
)
DATASETS: tuple[str, ...] = (*BUDGET_DATASETS, *ECONOMIC_DATASETS)

MAX_CATALOG_BYTES = 2 * 1024 * 1024
MAX_SCHEMA_BYTES = 2 * 1024 * 1024
MAX_CSV_BYTES = 32 * 1024 * 1024
DEFAULT_MAX_REQUESTS = 256
DEFAULT_USER_AGENT = "spicy-docs-cbo-data/1.0 (+https://github.com/civictechdc/spicy-regs)"

_COMMIT_RE = re.compile(r"[0-9a-f]{40}")
_REL_PATH_RE = re.compile(r"[A-Za-z0-9._/-]+")
_PUB_ID_RE = re.compile(r"[1-9][0-9]{0,8}")
_VINTAGE_RE = re.compile(r"\d{4}-\d{2}")
_DATE_RE = re.compile(r"(?:\d{4}(?:q[1-4])?|(?:FY|CY)\d{4})")
_YEAR_RE = re.compile(r"\d{4}")

_JSON_MEDIA_TYPES = ("application/json", "text/plain", "application/octet-stream")
_CSV_MEDIA_TYPES = ("text/csv", "text/plain", "application/csv", "application/octet-stream")

_LONG_3_HEADER = ("date", "variable", "value")
_LONG_EST_HEADER = ("date", "variable", "value", "estimate_type")
_REVENUE_IIT_HEADER = ("date", "variable", "value", "section", "estimate_type")
_LFP_RATES_HEADER = ("year", "sex", "age_group", "lfp_rate")
_SPENDING_DETAIL_HEADER = (
    "date",
    "tin",
    "title",
    "disc_or_mand",
    "category",
    "agency",
    "bureau",
    "function_code",
    "subfunction_code",
    "off_budget",
    "budget_authority",
    "outlays",
)

_DEMOGRAPHIC_HEADERS: dict[str, tuple[tuple[str, ...], ...]] = {
    "fertility": (("year", "age", "place_of_birth", "births_per_1000_females"),),
    "migration": (
        ("year", "age", "sex", "immigration_status", "migration_flow", "number_of_people"),
        ("year", "age", "sex", "immigration_status", "migration_flow", "people"),
    ),
    "mortality": (("year", "age", "sex", "deaths_per_1000_people"),),
    "population_bls": (("year", "age", "sex", "number_of_people"),),
    "population_census": (("year", "age", "sex", "number_of_people"),),
    "ss_area_population": (
        ("year", "age", "marital_status", "sex", "number_of_people"),
        ("year", "age", "marital", "sex", "number_of_people"),
    ),
}
_DEMOGRAPHIC_MEASURE = {
    "fertility": "births_per_1000_females",
    "migration": "number_of_people",
    "mortality": "deaths_per_1000_people",
    "population_bls": "number_of_people",
    "population_census": "number_of_people",
    "ss_area_population": "number_of_people",
}


class CboDataError(ValueError):
    """The cbo-data catalog, schema, or CSV payload violated its source contract."""


class CboDataUnavailable(CboDataError):
    """The pinned repository object returned HTTP 404 or 410; capture evidence is retained."""

    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"cbo-data object answered HTTP {capture.status_code}")
        self.capture = capture


class CboDataRefused(CboDataError):
    """The public GitHub endpoint refused access (401/403); refusal evidence is retained."""

    def __init__(self, url: str) -> None:
        super().__init__(f"cbo-data refused access to {url}")
        self.url = url


def validate_commit(commit: str) -> str:
    """Require a full 40-character lowercase Git commit SHA, never a moving branch."""
    if not isinstance(commit, str) or not _COMMIT_RE.fullmatch(commit):
        raise CboDataError("cbo-data commit must be a full 40-character lowercase Git commit SHA")
    return commit


def _safe_rel_path(rel_path: str) -> str:
    if not isinstance(rel_path, str) or not rel_path or rel_path.startswith("/") or rel_path.endswith("/"):
        raise CboDataError(f"cbo-data relative path is invalid: {rel_path!r}")
    if not _REL_PATH_RE.fullmatch(rel_path):
        raise CboDataError(f"cbo-data relative path contains unsupported characters: {rel_path!r}")
    parts = rel_path.split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise CboDataError(f"cbo-data relative path contains traversal segments: {rel_path!r}")
    return rel_path


def raw_url(commit: str, rel_path: str) -> str:
    """Construct an exact commit-pinned raw.githubusercontent.com URL."""
    return f"{RAW_BASE_URL}/{validate_commit(commit)}/{_safe_rel_path(rel_path)}"


def catalog_url(commit: str = PINNED_COMMIT) -> str:
    return raw_url(commit, "catalog.json")


def schema_url(commit: str, schema_path: str) -> str:
    rel = _safe_rel_path(schema_path)
    if not rel.endswith(".json"):
        raise CboDataError(f"cbo-data schema_path must be a JSON file: {schema_path!r}")
    return raw_url(commit, rel)


def distribution_url(commit: str, download_path: str) -> str:
    rel = _safe_rel_path(download_path)
    if not rel.endswith(".csv"):
        raise CboDataError(f"cbo-data distribution downloadURL must be a CSV file: {download_path!r}")
    return raw_url(commit, rel)


@dataclass(frozen=True, slots=True)
class CboDataDistribution:
    title: str
    download_url: str
    vintage: str
    file_type: str
    media_type: str
    format: str


@dataclass(frozen=True, slots=True)
class CboDataCatalogEntry:
    identifier: str
    title: str
    description: str
    publication_id: str
    landing_page: str
    frequency: str
    field_count: int | None
    schema_path: str
    vintages: tuple[str, ...]
    distributions: tuple[CboDataDistribution, ...]


@dataclass(frozen=True, slots=True)
class CboDataCatalog:
    commit: str
    title: str
    description: str
    generated: str
    input_sha256: str
    datasets: tuple[CboDataCatalogEntry, ...]

    def by_identifier(self) -> dict[str, CboDataCatalogEntry]:
        return {entry.identifier: entry for entry in self.datasets}


@dataclass(frozen=True, slots=True)
class CboVariableMetadata:
    name: str
    description: str
    unit: str | None
    category: str | None
    aggregation: str | None
    source_frequency: str | None
    variable_note: str | None
    extra_json: str


@dataclass(frozen=True, slots=True)
class CboDatasetSchema:
    commit: str
    dataset: str
    publication_id: str
    title: str
    source_url: str
    description: str
    frequency: str
    date_format: str
    canonical_columns: tuple[str, ...] | None
    input_sha256: str
    variables: Mapping[str, CboVariableMetadata]
    domain_units: Mapping[str, str]
    domain_descriptions: Mapping[str, str]
    raw_json: str


@dataclass(frozen=True, slots=True)
class CboCsvRow:
    dataset: str
    publication_id: str
    vintage: str
    file_type: str
    source_file: str
    source_row_index: int
    source_sha256: str
    cells: Mapping[str, Any]
    raw_json: str


@dataclass(frozen=True, slots=True)
class CboDataSnapshot:
    commit: str
    catalog: CboDataCatalog
    catalog_capture: CapturedBodyResponse
    schemas: Mapping[str, CboDatasetSchema]
    schema_captures: Mapping[str, CapturedBodyResponse]
    distributions: Mapping[str, tuple[CboCsvRow, ...]]
    distribution_captures: Mapping[str, CapturedBodyResponse]

    def receipts(self) -> dict[str, Any]:
        """Return a JSON-serializable SHA-256 provenance manifest for every captured file."""
        return {
            "repo": REPO,
            "commit": self.commit,
            "catalog": {
                "url": self.catalog_capture.requested_url,
                "sha256": self.catalog_capture.sha256,
                "byte_size": self.catalog_capture.byte_size,
                "observed_at": self.catalog_capture.observed_at,
            },
            "schemas": {
                dataset: {
                    "url": cap.requested_url,
                    "sha256": cap.sha256,
                    "byte_size": cap.byte_size,
                    "observed_at": cap.observed_at,
                }
                for dataset, cap in sorted(self.schema_captures.items())
            },
            "distributions": {
                path: {
                    "url": cap.requested_url,
                    "sha256": cap.sha256,
                    "byte_size": cap.byte_size,
                    "observed_at": cap.observed_at,
                    "rows": len(self.distributions[path]),
                }
                for path, cap in sorted(self.distribution_captures.items())
            },
        }


def _nonempty_str(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CboDataError(f"cbo-data {label} must be a nonempty string")
    return value


def parse_catalog(
    body: bytes,
    *,
    commit: str = PINNED_COMMIT,
    max_bytes: int = MAX_CATALOG_BYTES,
) -> CboDataCatalog:
    """Decode and validate ``catalog.json`` for one pinned commit."""
    pinned = validate_commit(commit)
    data = load_bounded_json(
        body,
        source="cbo-data catalog",
        error_type=CboDataError,
        number_policy="finite-float",
        max_bytes=max_bytes,
    )
    if not isinstance(data, dict):
        raise CboDataError("cbo-data catalog root must be an object")
    raw_datasets = data.get("datasets")
    if not isinstance(raw_datasets, list) or not raw_datasets:
        raise CboDataError("cbo-data catalog datasets must be a nonempty array")
    entries: list[CboDataCatalogEntry] = []
    seen_ids: set[str] = set()
    for index, item in enumerate(raw_datasets):
        if not isinstance(item, dict):
            raise CboDataError(f"cbo-data catalog entry {index} must be an object")
        identifier = _nonempty_str(item.get("identifier"), f"datasets[{index}].identifier")
        if identifier in seen_ids:
            raise CboDataError(f"cbo-data catalog repeats dataset identifier {identifier!r}")
        seen_ids.add(identifier)
        pub_id = _nonempty_str(item.get("publication_id"), f"{identifier}.publication_id")
        if not _PUB_ID_RE.fullmatch(pub_id):
            raise CboDataError(f"cbo-data {identifier} publication_id is invalid: {pub_id!r}")
        schema_path = _nonempty_str(item.get("schema_path"), f"{identifier}.schema_path")
        schema_url(pinned, schema_path)
        raw_vintages = item.get("vintages")
        if not isinstance(raw_vintages, list) or not raw_vintages:
            raise CboDataError(f"cbo-data {identifier} vintages must be nonempty")
        vintages = tuple(_nonempty_str(v, f"{identifier}.vintage") for v in raw_vintages)
        for v in vintages:
            if not _VINTAGE_RE.fullmatch(v):
                raise CboDataError(f"cbo-data {identifier} vintage is invalid: {v!r}")
        raw_dists = item.get("distribution")
        if not isinstance(raw_dists, list) or not raw_dists:
            raise CboDataError(f"cbo-data {identifier} distribution must be nonempty")
        distributions: list[CboDataDistribution] = []
        seen_paths: set[str] = set()
        for dist_idx, dist in enumerate(raw_dists):
            if not isinstance(dist, dict):
                raise CboDataError(f"cbo-data {identifier} distribution[{dist_idx}] must be an object")
            dl = _nonempty_str(dist.get("downloadURL"), f"{identifier}.distribution[{dist_idx}].downloadURL")
            distribution_url(pinned, dl)
            if dl in seen_paths:
                raise CboDataError(f"cbo-data {identifier} repeats distribution downloadURL {dl!r}")
            seen_paths.add(dl)
            vintage = _nonempty_str(dist.get("vintage"), f"{identifier}.distribution[{dist_idx}].vintage")
            if vintage not in vintages:
                raise CboDataError(f"cbo-data {identifier} distribution {dl} vintage {vintage!r} not in vintages")
            file_type = _nonempty_str(dist.get("file_type"), f"{identifier}.distribution[{dist_idx}].file_type")
            media_type = _nonempty_str(dist.get("mediaType"), f"{identifier}.distribution[{dist_idx}].mediaType")
            fmt = _nonempty_str(dist.get("format"), f"{identifier}.distribution[{dist_idx}].format")
            if media_type != "text/csv" or fmt.upper() != "CSV":
                raise CboDataError(f"cbo-data {identifier} distribution {dl} must be CSV, got {media_type}/{fmt}")
            distributions.append(
                CboDataDistribution(
                    title=_nonempty_str(dist.get("title"), f"{identifier}.distribution[{dist_idx}].title"),
                    download_url=dl,
                    vintage=vintage,
                    file_type=file_type,
                    media_type=media_type,
                    format=fmt,
                )
            )
        field_count = item.get("field_count")
        if field_count is not None and (
            isinstance(field_count, bool) or not isinstance(field_count, int) or field_count < 0
        ):
            raise CboDataError(f"cbo-data {identifier} field_count must be a nonnegative integer")
        entries.append(
            CboDataCatalogEntry(
                identifier=identifier,
                title=_nonempty_str(item.get("title"), f"{identifier}.title"),
                description=_nonempty_str(item.get("description"), f"{identifier}.description"),
                publication_id=pub_id,
                landing_page=_nonempty_str(item.get("landingPage"), f"{identifier}.landingPage"),
                frequency=_nonempty_str(item.get("frequency"), f"{identifier}.frequency"),
                field_count=field_count,
                schema_path=schema_path,
                vintages=vintages,
                distributions=tuple(distributions),
            )
        )
    return CboDataCatalog(
        commit=pinned,
        title=_nonempty_str(data.get("title"), "catalog.title"),
        description=_nonempty_str(data.get("description"), "catalog.description"),
        generated=_nonempty_str(data.get("generated"), "catalog.generated"),
        input_sha256="sha256:" + hashlib.sha256(body).hexdigest(),
        datasets=tuple(entries),
    )


def _extract_variable_metadata(name: str, spec: Mapping[str, Any]) -> CboVariableMetadata:
    known = {"description", "unit", "category", "aggregation", "source_frequency", "variable_note"}
    extra = {k: v for k, v in spec.items() if k not in known}
    return CboVariableMetadata(
        name=name,
        description=_nonempty_str(spec.get("description"), f"variable {name} description"),
        unit=str(spec["unit"]) if spec.get("unit") is not None else None,
        category=str(spec["category"]) if spec.get("category") is not None else None,
        aggregation=str(spec["aggregation"]) if spec.get("aggregation") is not None else None,
        source_frequency=str(spec["source_frequency"]) if spec.get("source_frequency") is not None else None,
        variable_note=str(spec["variable_note"]) if spec.get("variable_note") is not None else None,
        extra_json=json.dumps(extra, sort_keys=True, separators=(",", ":"), ensure_ascii=False),
    )


def parse_dataset_schema(
    body: bytes,
    *,
    commit: str = PINNED_COMMIT,
    dataset: str,
    max_bytes: int = MAX_SCHEMA_BYTES,
) -> CboDatasetSchema:
    """Parse one dataset's ``schema.json`` and normalize its variable/domain metadata."""
    pinned = validate_commit(commit)
    data = load_bounded_json(
        body,
        source=f"cbo-data {dataset} schema",
        error_type=CboDataError,
        number_policy="finite-float",
        max_bytes=max_bytes,
    )
    if not isinstance(data, dict):
        raise CboDataError(f"cbo-data {dataset} schema root must be an object")
    if data.get("dataset") != dataset:
        raise CboDataError(f"cbo-data schema dataset {data.get('dataset')!r} differs from expected {dataset!r}")
    pub_id = _nonempty_str(data.get("publication_id"), f"{dataset}.schema.publication_id")
    if not _PUB_ID_RE.fullmatch(pub_id):
        raise CboDataError(f"cbo-data {dataset} schema publication_id is invalid: {pub_id!r}")
    canonical = data.get("canonical_columns")
    if canonical is not None:
        if not isinstance(canonical, list) or not all(isinstance(col, str) and col for col in canonical):
            raise CboDataError(f"cbo-data {dataset} schema canonical_columns must be strings")
        canonical_cols: tuple[str, ...] | None = tuple(canonical)
    else:
        canonical_cols = None

    variables: dict[str, CboVariableMetadata] = {}
    for field_group in ("fields", "rates_fields", "levels_fields", "annual_fields", "quarterly_fields"):
        mapping = data.get(field_group)
        if mapping is None:
            continue
        if not isinstance(mapping, dict):
            raise CboDataError(f"cbo-data {dataset} schema {field_group} must be an object")
        for var_name, spec in mapping.items():
            if not isinstance(var_name, str) or not var_name or not isinstance(spec, dict):
                raise CboDataError(f"cbo-data {dataset} schema {field_group} has invalid entry {var_name!r}")
            variables[var_name] = _extract_variable_metadata(var_name, spec)

    lfp_fmt = data.get("lfp_rates_format")
    if isinstance(lfp_fmt, dict):
        variables["lfp_rate"] = CboVariableMetadata(
            name="lfp_rate",
            description=_nonempty_str(lfp_fmt.get("description"), f"{dataset}.lfp_rates_format.description"),
            unit="Percent",
            category="labor_force_participation",
            aggregation=None,
            source_frequency="annual",
            variable_note=None,
            extra_json=json.dumps(
                {k: v for k, v in lfp_fmt.items() if k != "description"},
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ),
        )

    columns_meta = data.get("columns")
    if columns_meta is not None:
        if not isinstance(columns_meta, dict):
            raise CboDataError(f"cbo-data {dataset} schema columns must be an object")
        for col_name, spec in columns_meta.items():
            if not isinstance(col_name, str) or not isinstance(spec, dict):
                raise CboDataError(f"cbo-data {dataset} schema columns has invalid entry {col_name!r}")
            variables[col_name] = CboVariableMetadata(
                name=col_name,
                description=_nonempty_str(spec.get("description"), f"{dataset}.columns.{col_name}"),
                unit="Millions of dollars" if spec.get("type") == "number" else None,
                category=str(spec.get("type")) if spec.get("type") is not None else None,
                aggregation=None,
                source_frequency=None,
                variable_note=None,
                extra_json=json.dumps(spec, sort_keys=True, separators=(",", ":"), ensure_ascii=False),
            )

    domain_units: dict[str, str] = {}
    domain_descriptions: dict[str, str] = {}
    domains_meta = data.get("domains")
    if domains_meta is not None:
        if not isinstance(domains_meta, dict) or not domains_meta:
            raise CboDataError(f"cbo-data {dataset} schema domains must be a nonempty object")
        for dom_name, spec in domains_meta.items():
            if not isinstance(dom_name, str) or not isinstance(spec, dict):
                raise CboDataError(f"cbo-data {dataset} schema domains has invalid entry {dom_name!r}")
            domain_descriptions[dom_name] = _nonempty_str(spec.get("description"), f"{dataset}.domains.{dom_name}")
            units_map = spec.get("units")
            if not isinstance(units_map, dict) or not units_map:
                raise CboDataError(f"cbo-data {dataset} schema domain {dom_name} missing units")
            for measure, unit in units_map.items():
                domain_units[dom_name] = _nonempty_str(unit, f"{dataset}.domains.{dom_name}.units.{measure}")

    if not variables and not domain_units:
        raise CboDataError(f"cbo-data {dataset} schema declares neither variables nor domains")

    return CboDatasetSchema(
        commit=pinned,
        dataset=dataset,
        publication_id=pub_id,
        title=_nonempty_str(data.get("title"), f"{dataset}.schema.title"),
        source_url=_nonempty_str(data.get("source_url"), f"{dataset}.schema.source_url"),
        description=_nonempty_str(data.get("description"), f"{dataset}.schema.description"),
        frequency=_nonempty_str(data.get("frequency"), f"{dataset}.schema.frequency"),
        date_format=str(data.get("date_format") or ""),
        canonical_columns=canonical_cols,
        input_sha256="sha256:" + hashlib.sha256(body).hexdigest(),
        variables=variables,
        domain_units=domain_units,
        domain_descriptions=domain_descriptions,
        raw_json=json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False),
    )


def _allowed_csv_headers(dataset: str, file_type: str) -> tuple[tuple[str, ...], ...]:
    if dataset == "spending_detail":
        return (_SPENDING_DETAIL_HEADER,)
    if dataset == "demographic":
        if file_type not in _DEMOGRAPHIC_HEADERS:
            raise CboDataError(f"cbo-data demographic has unsupported file_type {file_type!r}")
        return _DEMOGRAPHIC_HEADERS[file_type]
    if dataset == "long_term_economic" and file_type == "lfp_rates":
        return (_LFP_RATES_HEADER,)
    if dataset == "economic_projections":
        return (_LONG_EST_HEADER,)
    if dataset == "revenue_detail":
        return (_LONG_EST_HEADER, _REVENUE_IIT_HEADER)
    return (_LONG_3_HEADER,)


def _parse_finite_number(raw: str, *, field: str, source_file: str, row_index: int) -> float | None:
    if raw == "":
        return None
    try:
        value = float(raw)
    except ValueError as error:
        raise CboDataError(f"cbo-data {source_file} row {row_index} field {field!r} is not numeric: {raw!r}") from error
    if not math.isfinite(value):
        raise CboDataError(f"cbo-data {source_file} row {row_index} field {field!r} is non-finite: {raw!r}")
    return value


def parse_distribution_csv(
    body: bytes,
    *,
    commit: str = PINNED_COMMIT,
    dataset: str,
    publication_id: str,
    vintage: str,
    file_type: str,
    source_file: str,
    schema: CboDatasetSchema,
    max_bytes: int = MAX_CSV_BYTES,
) -> tuple[CboCsvRow, ...]:
    """Validate and parse one pinned CSV distribution against its dataset schema."""
    validate_commit(commit)
    if schema.dataset != dataset or schema.publication_id != publication_id:
        raise CboDataError(f"cbo-data schema does not match {dataset} publication {publication_id}")
    payload = check_payload(
        body, max_bytes, label=f"cbo-data CSV {source_file}", error_type=CboDataError, allow_empty=False
    )
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise CboDataError(f"cbo-data {source_file} is not valid UTF-8: {error}") from error

    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        header = tuple(next(reader))
    except StopIteration as error:
        raise CboDataError(f"cbo-data {source_file} is missing a CSV header") from error
    if len(set(header)) != len(header):
        raise CboDataError(f"cbo-data {source_file} header has duplicate columns: {header}")
    allowed = _allowed_csv_headers(dataset, file_type)
    if header not in allowed:
        raise CboDataError(f"cbo-data {source_file} header {header} differs from allowed {allowed}")

    rows: list[CboCsvRow] = []
    width = len(header)
    for row_index, values in enumerate(reader):
        if len(values) != width:
            raise CboDataError(f"cbo-data {source_file} row {row_index} has {len(values)} columns, expected {width}")
        literal = dict(zip(header, values, strict=True))
        raw_json = json.dumps(literal, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        cells: dict[str, Any] = dict(literal)

        if dataset == "spending_detail":
            if not _DATE_RE.fullmatch(literal["date"]):
                raise CboDataError(f"cbo-data {source_file} row {row_index} invalid date {literal['date']!r}")
            for req in ("tin", "title", "disc_or_mand"):
                if not literal[req].strip():
                    raise CboDataError(f"cbo-data {source_file} row {row_index} missing {req}")
            cells["budget_authority_num"] = _parse_finite_number(
                literal["budget_authority"], field="budget_authority", source_file=source_file, row_index=row_index
            )
            cells["outlays_num"] = _parse_finite_number(
                literal["outlays"], field="outlays", source_file=source_file, row_index=row_index
            )
        elif dataset == "demographic":
            if file_type not in schema.domain_units:
                raise CboDataError(f"cbo-data demographic schema missing domain {file_type!r}")
            if not _YEAR_RE.fullmatch(literal["year"]):
                raise CboDataError(f"cbo-data {source_file} row {row_index} invalid year {literal['year']!r}")
            if not literal["age"].strip():
                raise CboDataError(f"cbo-data {source_file} row {row_index} empty age")
            # Normalize known 2026-01 column renames without altering literal raw_json.
            if "people" in literal and "number_of_people" not in literal:
                cells["number_of_people"] = literal["people"]
            if "marital" in literal and "marital_status" not in literal:
                cells["marital_status"] = literal["marital"]
            measure = _DEMOGRAPHIC_MEASURE[file_type]
            cells["measure"] = measure
            cells["value_raw"] = str(cells[measure])
            cells["value_num"] = _parse_finite_number(
                str(cells[measure]), field=measure, source_file=source_file, row_index=row_index
            )
            cells["unit"] = schema.domain_units[file_type]
            cells["domain_description"] = schema.domain_descriptions[file_type]
        elif dataset == "long_term_economic" and file_type == "lfp_rates":
            if not _YEAR_RE.fullmatch(literal["year"]):
                raise CboDataError(f"cbo-data {source_file} row {row_index} invalid year {literal['year']!r}")
            if not literal["sex"].strip() or not literal["age_group"].strip():
                raise CboDataError(f"cbo-data {source_file} row {row_index} missing sex or age_group")
            if "lfp_rate" not in schema.variables:
                raise CboDataError(f"cbo-data {source_file} schema missing lfp_rate metadata")
            cells["date"] = literal["year"]
            cells["variable"] = "lfp_rate"
            cells["value"] = literal["lfp_rate"]
            cells["value_num"] = _parse_finite_number(
                literal["lfp_rate"], field="lfp_rate", source_file=source_file, row_index=row_index
            )
        else:
            if not _DATE_RE.fullmatch(literal["date"]):
                raise CboDataError(f"cbo-data {source_file} row {row_index} invalid date {literal['date']!r}")
            var_name = literal["variable"]
            if var_name not in schema.variables:
                raise CboDataError(
                    f"cbo-data {source_file} row {row_index} variable {var_name!r} absent from schema.json"
                )
            cells["value_num"] = _parse_finite_number(
                literal["value"], field="value", source_file=source_file, row_index=row_index
            )

        rows.append(
            CboCsvRow(
                dataset=dataset,
                publication_id=publication_id,
                vintage=vintage,
                file_type=file_type,
                source_file=source_file,
                source_row_index=row_index,
                source_sha256=digest,
                cells=cells,
                raw_json=raw_json,
            )
        )
    if not rows:
        raise CboDataError(f"cbo-data {source_file} contains zero data rows")
    return tuple(rows)


@dataclass(frozen=True, slots=True)
class CboDataBudget:
    max_requests: int = DEFAULT_MAX_REQUESTS
    max_catalog_bytes: int = MAX_CATALOG_BYTES
    max_schema_bytes: int = MAX_SCHEMA_BYTES
    max_csv_bytes: int = MAX_CSV_BYTES
    timeout_seconds: float = 30.0
    min_request_interval_seconds: float = 0.05

    def __post_init__(self) -> None:
        check_request_count(self.max_requests)
        check_byte_bound(self.max_catalog_bytes, "max_catalog_bytes", MAX_CATALOG_BYTES)
        check_byte_bound(self.max_schema_bytes, "max_schema_bytes", MAX_SCHEMA_BYTES)
        check_byte_bound(self.max_csv_bytes, "max_csv_bytes", MAX_CSV_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


class CboDataAcquirer(SourceAcquirer):
    """Acquire commit-pinned US-CBO/cbo-data catalog, schemas, and CSV distributions."""

    def __init__(
        self,
        *,
        budget: CboDataBudget | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
        user_agent: str = DEFAULT_USER_AGENT,
    ) -> None:
        budget = budget or CboDataBudget()
        self.budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent=user_agent,
            label="cbo-data",
            error_type=CboDataError,
            context_key="cbo_data_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def acquire_catalog(
        self, commit: str = PINNED_COMMIT, *, reset_budget: bool = True
    ) -> tuple[CboDataCatalog, CapturedBodyResponse]:
        url = catalog_url(commit)

        def parse(capture: CapturedBodyResponse, limit: int) -> CboDataCatalog:
            check_final_url(
                capture.resolved_url,
                url,
                error_type=CboDataError,
                message="cbo-data response left the pinned catalog URL",
            )
            return parse_catalog(capture.body, commit=commit, max_bytes=limit)

        with named_challenge(url, error_type=CboDataRefused, context_key=self.context_key):
            return self.capture_validated(
                url,
                media_types=_JSON_MEDIA_TYPES,
                parse=parse,
                max_bytes=self.budget.max_catalog_bytes,
                unavailable=CboDataUnavailable,
                context={"operation": "catalog", "commit": commit},
                reset_budget=reset_budget,
            )

    def acquire_schema(
        self,
        commit: str,
        entry: CboDataCatalogEntry,
        *,
        reset_budget: bool = True,
    ) -> tuple[CboDatasetSchema, CapturedBodyResponse]:
        url = schema_url(commit, entry.schema_path)

        def parse(capture: CapturedBodyResponse, limit: int) -> CboDatasetSchema:
            check_final_url(
                capture.resolved_url,
                url,
                error_type=CboDataError,
                message=f"cbo-data response left the pinned schema URL for {entry.identifier}",
            )
            return parse_dataset_schema(capture.body, commit=commit, dataset=entry.identifier, max_bytes=limit)

        with named_challenge(url, error_type=CboDataRefused, context_key=self.context_key):
            return self.capture_validated(
                url,
                media_types=_JSON_MEDIA_TYPES,
                parse=parse,
                max_bytes=self.budget.max_schema_bytes,
                unavailable=CboDataUnavailable,
                context={"operation": "schema", "commit": commit, "dataset": entry.identifier},
                reset_budget=reset_budget,
            )

    def acquire_csv(
        self,
        commit: str,
        entry: CboDataCatalogEntry,
        distribution: CboDataDistribution,
        schema: CboDatasetSchema,
        *,
        reset_budget: bool = True,
    ) -> tuple[tuple[CboCsvRow, ...], CapturedBodyResponse]:
        url = distribution_url(commit, distribution.download_url)

        def parse(capture: CapturedBodyResponse, limit: int) -> tuple[CboCsvRow, ...]:
            check_final_url(
                capture.resolved_url,
                url,
                error_type=CboDataError,
                message=f"cbo-data response left the pinned CSV URL for {distribution.download_url}",
            )
            return parse_distribution_csv(
                capture.body,
                commit=commit,
                dataset=entry.identifier,
                publication_id=entry.publication_id,
                vintage=distribution.vintage,
                file_type=distribution.file_type,
                source_file=distribution.download_url,
                schema=schema,
                max_bytes=limit,
            )

        with named_challenge(url, error_type=CboDataRefused, context_key=self.context_key):
            return self.capture_validated(
                url,
                media_types=_CSV_MEDIA_TYPES,
                parse=parse,
                max_bytes=self.budget.max_csv_bytes,
                unavailable=CboDataUnavailable,
                context={
                    "operation": "csv",
                    "commit": commit,
                    "dataset": entry.identifier,
                    "vintage": distribution.vintage,
                    "source_file": distribution.download_url,
                },
                reset_budget=reset_budget,
            )

    def acquire_all(
        self,
        commit: str = PINNED_COMMIT,
        *,
        datasets: Iterable[str] | None = None,
    ) -> CboDataSnapshot:
        """Acquire ``catalog.json``, selected dataset schemas, and all their CSV distributions."""
        pinned = validate_commit(commit)
        selected = tuple(DATASETS if datasets is None else datasets)
        if not selected or len(set(selected)) != len(selected):
            raise CboDataError("cbo-data datasets selection must be nonempty and unique")
        unknown = [name for name in selected if name not in DATASETS]
        if unknown:
            raise CboDataError(f"cbo-data unsupported dataset(s): {', '.join(unknown)}")

        catalog, catalog_capture = self.acquire_catalog(pinned, reset_budget=True)
        by_id = catalog.by_identifier()
        missing = [name for name in selected if name not in by_id]
        if missing:
            raise CboDataError(f"cbo-data catalog is missing selected dataset(s): {', '.join(missing)}")

        schemas: dict[str, CboDatasetSchema] = {}
        schema_captures: dict[str, CapturedBodyResponse] = {}
        distributions: dict[str, tuple[CboCsvRow, ...]] = {}
        distribution_captures: dict[str, CapturedBodyResponse] = {}

        for name in selected:
            entry = by_id[name]
            schema, schema_capture = self.acquire_schema(pinned, entry, reset_budget=False)
            schemas[name] = schema
            schema_captures[name] = schema_capture
            for dist in entry.distributions:
                rows, csv_capture = self.acquire_csv(pinned, entry, dist, schema, reset_budget=False)
                distributions[dist.download_url] = rows
                distribution_captures[dist.download_url] = csv_capture

        return CboDataSnapshot(
            commit=pinned,
            catalog=catalog,
            catalog_capture=catalog_capture,
            schemas=schemas,
            schema_captures=schema_captures,
            distributions=distributions,
            distribution_captures=distribution_captures,
        )
