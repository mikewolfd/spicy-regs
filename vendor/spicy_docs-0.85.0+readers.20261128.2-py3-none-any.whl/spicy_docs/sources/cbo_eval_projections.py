"""Read commit-pinned CBO projection accuracy history from US-CBO/eval-projections.

CBO publishes historical baseline projections, legislative/economic/technical
baseline changes, actuals, GDP, projection errors, and horizon summary
statistics under U.S. public domain terms (``LICENSE.md``). This module pins a
full Git commit SHA, retains exact wire bytes and SHA-256 receipts with an
explicit ``User-Agent``, and validates literal CSV shapes without interpreting
error math or budget policy. See ``docs/sources/cbo-eval-projections.md``.
"""

from __future__ import annotations

import csv
import hashlib
import io
import math
import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from typing import TYPE_CHECKING

from spicy_docs.reading.media_types import bare_media_type
from spicy_docs.reading.refusals import RefusedResponse
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_payload,
    check_request_count,
    check_timing,
    named_challenge,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

REPOSITORY = "US-CBO/eval-projections"
PINNED_COMMIT = "682559ca5800ee7be57a398085fd023a050c7cb9"
RAW_BASE = f"https://raw.githubusercontent.com/{REPOSITORY}"
USER_AGENT = "spicy-docs-cbo-eval-projections/1.0 (+https://github.com/civictechdc/spicy-docs)"
# Largest observed file at PINNED_COMMIT is input_data/baseline_changes.csv (2,451,820 B);
# 16 MiB leaves headroom for future annual releases without accepting unbounded responses.
MAX_FILE_BYTES = 16 * 1024 * 1024
COMPONENTS: tuple[str, ...] = ("outlay", "revenue", "deficit", "debt")
CHANGE_CATEGORIES: frozenset[str] = frozenset({"Legislative", "Economic", "Technical"})
DOC_FILES: tuple[str, ...] = ("README.md", "LICENSE.md", "CHANGE_LOG.md")
INPUT_FILES: tuple[str, ...] = (
    "input_data/actual_GDP.csv",
    "input_data/actuals.csv",
    "input_data/baselines.csv",
    "input_data/baseline_changes.csv",
)
OUTPUT_FILES: tuple[str, ...] = tuple(
    f"output_data/{component}_{suffix}.csv"
    for component in COMPONENTS
    for suffix in ("actuals_pct_GDP", "projection_errors", "projection_errors_summary_stats")
)
ALL_FILES: tuple[str, ...] = (*DOC_FILES, *INPUT_FILES, *OUTPUT_FILES)
_ALLOWED_FILES: frozenset[str] = frozenset(ALL_FILES)
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SHA256 = re.compile(r"sha256:[0-9a-f]{64}")
_YEAR_RANGE = re.compile(r"[0-9]{4}-[0-9]{4}")


class CboEvalProjectionsError(ValueError):
    """The selected US-CBO/eval-projections input could not be read cleanly."""


class CboEvalProjectionsUnavailable(CboEvalProjectionsError):
    """The repository answered 404/410 for the pinned locator; the capture is retained."""

    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"eval-projections answered HTTP {capture.status_code}")
        self.capture = capture


class CboEvalProjectionsRefused(CboEvalProjectionsError):
    """The keyless GitHub raw endpoint refused access; its evidence is retained."""

    refused_response: RefusedResponse

    def __init__(self, url: str) -> None:
        super().__init__(f"eval-projections refused access to {url}")


def check_commit(commit: str) -> str:
    """Require a full lowercase 40-character Git commit SHA, never a moving branch."""
    if not isinstance(commit, str) or not _COMMIT.fullmatch(commit):
        raise CboEvalProjectionsError("commit must be a full lowercase 40-character Git commit SHA")
    return commit


def raw_url(commit: str, rel_path: str) -> str:
    """Build the immutable GitHub raw URL for an allowlisted file at a pinned commit."""
    check_commit(commit)
    if not isinstance(rel_path, str) or rel_path not in _ALLOWED_FILES:
        raise CboEvalProjectionsError(f"unsupported eval-projections file path: {rel_path!r}")
    return f"{RAW_BASE}/{commit}/{rel_path}"


def _sha256_prefixed(body: bytes) -> str:
    return "sha256:" + hashlib.sha256(body).hexdigest()


def _check_sha256_token(value: str, *, label: str) -> str:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        raise CboEvalProjectionsError(f"{label} must be formatted as sha256:<64 lowercase hex chars>")
    return value


def _check_observed_at(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CboEvalProjectionsError("observed_at must be a non-empty ISO-8601 timestamp with timezone")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as error:
        raise CboEvalProjectionsError("observed_at must be a valid ISO-8601 timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise CboEvalProjectionsError("observed_at must state a timezone")
    return value


def _check_component(component: str) -> str:
    if component not in COMPONENTS:
        raise CboEvalProjectionsError(f"unsupported budget component: {component!r}")
    return component


def _decode_csv_rows(
    body: bytes, *, expected_columns: Sequence[str], label: str, max_bytes: int
) -> list[dict[str, str]]:
    check_byte_bound(max_bytes, "max_bytes", MAX_FILE_BYTES)
    payload = check_payload(body, max_bytes, label=label, error_type=CboEvalProjectionsError, allow_empty=False)
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as error:
        raise CboEvalProjectionsError(f"{label} is not valid UTF-8") from error
    if text.startswith("\ufeff"):
        raise CboEvalProjectionsError(f"{label} carries an unexpected UTF-8 BOM")
    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        header = next(reader)
    except StopIteration as error:
        raise CboEvalProjectionsError(f"{label} has no CSV header") from error
    expected = list(expected_columns)
    if header != expected:
        raise CboEvalProjectionsError(f"{label} header differs from expected columns: {header!r} != {expected!r}")
    rows: list[dict[str, str]] = []
    width = len(expected)
    for line_no, fields in enumerate(reader, start=2):
        if len(fields) != width:
            raise CboEvalProjectionsError(f"{label} row {line_no} has {len(fields)} fields, expected {width}")
        rows.append(dict(zip(expected, fields, strict=True)))
    if not rows:
        raise CboEvalProjectionsError(f"{label} contains zero data rows")
    return rows


def _req_str(row: Mapping[str, str], field: str, *, label: str, row_num: int) -> str:
    value = row[field]
    if not value or not value.strip():
        raise CboEvalProjectionsError(f"{label} row {row_num} has blank {field}")
    return value


def _req_int(row: Mapping[str, str], field: str, *, label: str, row_num: int) -> int:
    raw = row[field].strip()
    if not re.fullmatch(r"-?[0-9]+", raw):
        raise CboEvalProjectionsError(f"{label} row {row_num} {field} is not an integer: {row[field]!r}")
    return int(raw)


def _req_bool(row: Mapping[str, str], field: str, *, label: str, row_num: int) -> bool:
    raw = row[field].strip()
    if raw == "True":
        return True
    if raw == "False":
        return False
    raise CboEvalProjectionsError(f"{label} row {row_num} {field} must be 'True' or 'False': {row[field]!r}")


def _req_iso_date(row: Mapping[str, str], field: str, *, label: str, row_num: int) -> str:
    raw = row[field].strip()
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", raw):
        raise CboEvalProjectionsError(f"{label} row {row_num} {field} is not YYYY-MM-DD: {row[field]!r}")
    try:
        date.fromisoformat(raw)
    except ValueError as error:
        raise CboEvalProjectionsError(
            f"{label} row {row_num} {field} is not a calendar date: {row[field]!r}"
        ) from error
    return raw


def _parse_float(raw: str, *, field: str, label: str, row_num: int, allow_blank: bool = False) -> float | None:
    stripped = raw.strip()
    if stripped == "":
        if allow_blank:
            return None
        raise CboEvalProjectionsError(f"{label} row {row_num} has blank {field}")
    try:
        value = float(stripped)
    except ValueError as error:
        raise CboEvalProjectionsError(f"{label} row {row_num} {field} is not numeric: {raw!r}") from error
    if not math.isfinite(value):
        raise CboEvalProjectionsError(f"{label} row {row_num} {field} is not finite: {raw!r}")
    return value


def _req_float(row: Mapping[str, str], field: str, *, label: str, row_num: int) -> float:
    value = _parse_float(row[field], field=field, label=label, row_num=row_num, allow_blank=False)
    assert value is not None
    return value


@dataclass(frozen=True, slots=True)
class ActualGdpRow:
    fiscal_year: int
    gdp: float


@dataclass(frozen=True, slots=True)
class ActualRow:
    component: str
    category: str
    subcategory: str
    fiscal_year: int
    actual_value: float


@dataclass(frozen=True, slots=True)
class BaselineRow:
    component: str
    category: str
    subcategory: str
    baseline_date: str
    spring_flag: bool
    winter_flag: bool
    projected_fiscal_year: int
    projected_year_number: int
    value: float


@dataclass(frozen=True, slots=True)
class BaselineChangeRow:
    component: str
    category: str
    subcategory: str
    changes_baseline_date: str
    change_category: str
    projected_fiscal_year: int
    value: float | None


@dataclass(frozen=True, slots=True)
class ProjectionErrorRow:
    component: str
    category: str
    subcategory: str
    baseline_date: str
    spring_flag: bool
    winter_flag: bool
    projected_fiscal_year: int
    projected_year_number: int
    value: float
    actual_value: float
    gdp: float
    legislative_change: float
    legislative_deficit_change: float | None
    adjusted_projection: float
    projection_error: float
    projection_error_pct_actual: float | None
    leg_change_pct_gdp: float
    projection_error_pct_gdp: float


@dataclass(frozen=True, slots=True)
class SummaryStatRow:
    component: str
    category: str
    subcategory: str
    projected_year_number: int
    projection_year_range: str
    number_of_projections: int
    average_error: float
    average_absolute_error: float
    rmse: float
    two_thirds_spread: float


@dataclass(frozen=True, slots=True)
class ActualPctGdpRow:
    component: str
    category: str
    subcategory: str
    fiscal_year: int
    actual_value: float
    gdp: float
    actuals_pct_gdp: float


@dataclass(frozen=True, slots=True)
class FileReceipt:
    rel_path: str
    commit: str
    url: str
    sha256: str
    byte_size: int
    observed_at: str
    media_type: str


@dataclass(frozen=True, slots=True)
class FileAcquisition:
    receipt: FileReceipt
    body: bytes


@dataclass(frozen=True, slots=True)
class DatasetAcquisition:
    commit: str
    files: Mapping[str, bytes]
    receipts: Mapping[str, FileReceipt]


@dataclass(frozen=True, slots=True)
class EvalProjectionsBundle:
    commit: str
    observed_at: str
    file_sha256: Mapping[str, str]
    actual_gdp: tuple[ActualGdpRow, ...]
    actuals: tuple[ActualRow, ...]
    baselines: tuple[BaselineRow, ...]
    baseline_changes: tuple[BaselineChangeRow, ...]
    projection_errors: tuple[ProjectionErrorRow, ...]
    summary_stats: tuple[SummaryStatRow, ...]
    actuals_pct_gdp: tuple[ActualPctGdpRow, ...]


def parse_actual_gdp(body: bytes, *, max_bytes: int = MAX_FILE_BYTES) -> tuple[ActualGdpRow, ...]:
    label = "input_data/actual_GDP.csv"
    rows = _decode_csv_rows(body, expected_columns=("fiscal_year", "GDP"), label=label, max_bytes=max_bytes)
    parsed: list[ActualGdpRow] = []
    for idx, row in enumerate(rows, start=2):
        fy = _req_int(row, "fiscal_year", label=label, row_num=idx)
        gdp = _req_float(row, "GDP", label=label, row_num=idx)
        parsed.append(ActualGdpRow(fiscal_year=fy, gdp=gdp))
    return tuple(parsed)


def parse_actuals(body: bytes, *, max_bytes: int = MAX_FILE_BYTES) -> tuple[ActualRow, ...]:
    label = "input_data/actuals.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=("component", "category", "subcategory", "fiscal_year", "actual_value"),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[ActualRow] = []
    for idx, row in enumerate(rows, start=2):
        component = _check_component(_req_str(row, "component", label=label, row_num=idx))
        parsed.append(
            ActualRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                fiscal_year=_req_int(row, "fiscal_year", label=label, row_num=idx),
                actual_value=_req_float(row, "actual_value", label=label, row_num=idx),
            )
        )
    return tuple(parsed)


def parse_baselines(body: bytes, *, max_bytes: int = MAX_FILE_BYTES) -> tuple[BaselineRow, ...]:
    label = "input_data/baselines.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=(
            "component",
            "category",
            "subcategory",
            "baseline_date",
            "Spring_flag",
            "Winter_flag",
            "projected_fiscal_year",
            "projected_year_number",
            "value",
        ),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[BaselineRow] = []
    for idx, row in enumerate(rows, start=2):
        component = _check_component(_req_str(row, "component", label=label, row_num=idx))
        parsed.append(
            BaselineRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                baseline_date=_req_iso_date(row, "baseline_date", label=label, row_num=idx),
                spring_flag=_req_bool(row, "Spring_flag", label=label, row_num=idx),
                winter_flag=_req_bool(row, "Winter_flag", label=label, row_num=idx),
                projected_fiscal_year=_req_int(row, "projected_fiscal_year", label=label, row_num=idx),
                projected_year_number=_req_int(row, "projected_year_number", label=label, row_num=idx),
                value=_req_float(row, "value", label=label, row_num=idx),
            )
        )
    return tuple(parsed)


def parse_baseline_changes(body: bytes, *, max_bytes: int = MAX_FILE_BYTES) -> tuple[BaselineChangeRow, ...]:
    label = "input_data/baseline_changes.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=(
            "component",
            "category",
            "subcategory",
            "changes_baseline_date",
            "change_category",
            "projected_fiscal_year",
            "value",
        ),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[BaselineChangeRow] = []
    for idx, row in enumerate(rows, start=2):
        component = _check_component(_req_str(row, "component", label=label, row_num=idx))
        change_category = _req_str(row, "change_category", label=label, row_num=idx)
        if change_category not in CHANGE_CATEGORIES:
            raise CboEvalProjectionsError(f"{label} row {idx} unsupported change_category: {change_category!r}")
        parsed.append(
            BaselineChangeRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                changes_baseline_date=_req_iso_date(row, "changes_baseline_date", label=label, row_num=idx),
                change_category=change_category,
                projected_fiscal_year=_req_int(row, "projected_fiscal_year", label=label, row_num=idx),
                value=_parse_float(row["value"], field="value", label=label, row_num=idx, allow_blank=True),
            )
        )
    return tuple(parsed)


def _projection_error_columns(component: str) -> tuple[str, ...]:
    base = (
        "component",
        "category",
        "subcategory",
        "baseline_date",
        "Spring_flag",
        "Winter_flag",
        "projected_fiscal_year",
        "projected_year_number",
        "value",
        "actual_value",
        "GDP",
    )
    if component in ("outlay", "revenue"):
        return (
            *base,
            f"legislative_{component}_change",
            "adjusted_projection",
            "projection_error",
            "projection_error_pct_actual",
            "leg_change_pct_GDP",
            "projection_error_pct_GDP",
        )
    if component == "deficit":
        return (
            *base,
            "legislative_deficit_change",
            "adjusted_projection",
            "projection_error",
            "leg_change_pct_GDP",
            "projection_error_pct_GDP",
        )
    return (
        *base,
        "legislative_deficit_change",
        "legislative_debt_change",
        "adjusted_projection",
        "projection_error",
        "leg_change_pct_GDP",
        "projection_error_pct_GDP",
    )


def parse_projection_errors(
    body: bytes, *, component: str, max_bytes: int = MAX_FILE_BYTES
) -> tuple[ProjectionErrorRow, ...]:
    _check_component(component)
    label = f"output_data/{component}_projection_errors.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=_projection_error_columns(component),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[ProjectionErrorRow] = []
    for idx, row in enumerate(rows, start=2):
        row_comp = _req_str(row, "component", label=label, row_num=idx)
        if row_comp != component:
            raise CboEvalProjectionsError(f"{label} row {idx} component {row_comp!r} != {component!r}")
        year_num = _req_int(row, "projected_year_number", label=label, row_num=idx)
        if not 1 <= year_num <= 11:
            raise CboEvalProjectionsError(f"{label} row {idx} projected_year_number out of 1..11: {year_num}")
        if component in ("outlay", "revenue"):
            leg_change = _req_float(row, f"legislative_{component}_change", label=label, row_num=idx)
            leg_deficit_change: float | None = None
            pct_actual: float | None = _req_float(row, "projection_error_pct_actual", label=label, row_num=idx)
        elif component == "deficit":
            leg_change = _req_float(row, "legislative_deficit_change", label=label, row_num=idx)
            leg_deficit_change = leg_change
            pct_actual = None
        else:
            leg_deficit_change = _req_float(row, "legislative_deficit_change", label=label, row_num=idx)
            leg_change = _req_float(row, "legislative_debt_change", label=label, row_num=idx)
            pct_actual = None
        parsed.append(
            ProjectionErrorRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                baseline_date=_req_iso_date(row, "baseline_date", label=label, row_num=idx),
                spring_flag=_req_bool(row, "Spring_flag", label=label, row_num=idx),
                winter_flag=_req_bool(row, "Winter_flag", label=label, row_num=idx),
                projected_fiscal_year=_req_int(row, "projected_fiscal_year", label=label, row_num=idx),
                projected_year_number=year_num,
                value=_req_float(row, "value", label=label, row_num=idx),
                actual_value=_req_float(row, "actual_value", label=label, row_num=idx),
                gdp=_req_float(row, "GDP", label=label, row_num=idx),
                legislative_change=leg_change,
                legislative_deficit_change=leg_deficit_change,
                adjusted_projection=_req_float(row, "adjusted_projection", label=label, row_num=idx),
                projection_error=_req_float(row, "projection_error", label=label, row_num=idx),
                projection_error_pct_actual=pct_actual,
                leg_change_pct_gdp=_req_float(row, "leg_change_pct_GDP", label=label, row_num=idx),
                projection_error_pct_gdp=_req_float(row, "projection_error_pct_GDP", label=label, row_num=idx),
            )
        )
    return tuple(parsed)


def parse_summary_stats(body: bytes, *, component: str, max_bytes: int = MAX_FILE_BYTES) -> tuple[SummaryStatRow, ...]:
    _check_component(component)
    label = f"output_data/{component}_projection_errors_summary_stats.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=(
            "component",
            "category",
            "subcategory",
            "projected_year_number",
            "projection_year_range",
            "number_of_projections",
            "average_error",
            "average_absolute_error",
            "RMSE",
            "two_thirds_spread",
        ),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[SummaryStatRow] = []
    for idx, row in enumerate(rows, start=2):
        row_comp = _req_str(row, "component", label=label, row_num=idx)
        if row_comp != component:
            raise CboEvalProjectionsError(f"{label} row {idx} component {row_comp!r} != {component!r}")
        year_num = _req_int(row, "projected_year_number", label=label, row_num=idx)
        if not 1 <= year_num <= 11:
            raise CboEvalProjectionsError(f"{label} row {idx} projected_year_number out of 1..11: {year_num}")
        year_range = _req_str(row, "projection_year_range", label=label, row_num=idx)
        if not _YEAR_RANGE.fullmatch(year_range):
            raise CboEvalProjectionsError(f"{label} row {idx} invalid projection_year_range: {year_range!r}")
        n_proj = _req_int(row, "number_of_projections", label=label, row_num=idx)
        if n_proj <= 0:
            raise CboEvalProjectionsError(f"{label} row {idx} number_of_projections must be positive: {n_proj}")
        parsed.append(
            SummaryStatRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                projected_year_number=year_num,
                projection_year_range=year_range,
                number_of_projections=n_proj,
                average_error=_req_float(row, "average_error", label=label, row_num=idx),
                average_absolute_error=_req_float(row, "average_absolute_error", label=label, row_num=idx),
                rmse=_req_float(row, "RMSE", label=label, row_num=idx),
                two_thirds_spread=_req_float(row, "two_thirds_spread", label=label, row_num=idx),
            )
        )
    return tuple(parsed)


def parse_actuals_pct_gdp(
    body: bytes, *, component: str, max_bytes: int = MAX_FILE_BYTES
) -> tuple[ActualPctGdpRow, ...]:
    _check_component(component)
    label = f"output_data/{component}_actuals_pct_GDP.csv"
    rows = _decode_csv_rows(
        body,
        expected_columns=(
            "component",
            "category",
            "subcategory",
            "fiscal_year",
            "actual_value",
            "GDP",
            "actuals_pct_GDP",
        ),
        label=label,
        max_bytes=max_bytes,
    )
    parsed: list[ActualPctGdpRow] = []
    for idx, row in enumerate(rows, start=2):
        row_comp = _req_str(row, "component", label=label, row_num=idx)
        if row_comp != component:
            raise CboEvalProjectionsError(f"{label} row {idx} component {row_comp!r} != {component!r}")
        parsed.append(
            ActualPctGdpRow(
                component=component,
                category=_req_str(row, "category", label=label, row_num=idx),
                subcategory=_req_str(row, "subcategory", label=label, row_num=idx),
                fiscal_year=_req_int(row, "fiscal_year", label=label, row_num=idx),
                actual_value=_req_float(row, "actual_value", label=label, row_num=idx),
                gdp=_req_float(row, "GDP", label=label, row_num=idx),
                actuals_pct_gdp=_req_float(row, "actuals_pct_GDP", label=label, row_num=idx),
            )
        )
    return tuple(parsed)


def parse_eval_bundle(
    files: Mapping[str, bytes],
    *,
    commit: str,
    observed_at: str,
    expected_sha256: Mapping[str, str] | None = None,
    max_bytes: int = MAX_FILE_BYTES,
) -> EvalProjectionsBundle:
    """Parse all 16 input and output CSVs from one commit-pinned capture."""
    check_commit(commit)
    _check_observed_at(observed_at)
    required = (*INPUT_FILES, *OUTPUT_FILES)
    missing = [path for path in required if path not in files]
    if missing:
        raise CboEvalProjectionsError(f"missing required eval-projections CSVs: {missing}")
    digests: dict[str, str] = {}
    for rel_path, body in files.items():
        if rel_path not in _ALLOWED_FILES:
            raise CboEvalProjectionsError(f"unexpected file in eval-projections bundle: {rel_path!r}")
        check_payload(body, max_bytes, label=rel_path, error_type=CboEvalProjectionsError, allow_empty=False)
        digest = _sha256_prefixed(body)
        if expected_sha256 is not None and rel_path in expected_sha256:
            want = _check_sha256_token(expected_sha256[rel_path], label=f"expected_sha256[{rel_path}]")
            if digest != want:
                raise CboEvalProjectionsError(f"{rel_path} SHA-256 {digest} differs from expected {want}")
        digests[rel_path] = digest
    errors: list[ProjectionErrorRow] = []
    stats: list[SummaryStatRow] = []
    pct_gdp: list[ActualPctGdpRow] = []
    for component in COMPONENTS:
        errors.extend(
            parse_projection_errors(
                files[f"output_data/{component}_projection_errors.csv"], component=component, max_bytes=max_bytes
            )
        )
        stats.extend(
            parse_summary_stats(
                files[f"output_data/{component}_projection_errors_summary_stats.csv"],
                component=component,
                max_bytes=max_bytes,
            )
        )
        pct_gdp.extend(
            parse_actuals_pct_gdp(
                files[f"output_data/{component}_actuals_pct_GDP.csv"], component=component, max_bytes=max_bytes
            )
        )
    return EvalProjectionsBundle(
        commit=commit,
        observed_at=observed_at,
        file_sha256=digests,
        actual_gdp=parse_actual_gdp(files["input_data/actual_GDP.csv"], max_bytes=max_bytes),
        actuals=parse_actuals(files["input_data/actuals.csv"], max_bytes=max_bytes),
        baselines=parse_baselines(files["input_data/baselines.csv"], max_bytes=max_bytes),
        baseline_changes=parse_baseline_changes(files["input_data/baseline_changes.csv"], max_bytes=max_bytes),
        projection_errors=tuple(errors),
        summary_stats=tuple(stats),
        actuals_pct_gdp=tuple(pct_gdp),
    )


@dataclass(frozen=True, slots=True)
class EvalProjectionsBudget:
    max_requests: int = 20
    max_file_bytes: int = MAX_FILE_BYTES
    timeout_seconds: float = 30.0
    min_request_interval_seconds: float = 0.05

    def __post_init__(self) -> None:
        check_request_count(self.max_requests)
        check_byte_bound(self.max_file_bytes, "max_file_bytes", MAX_FILE_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


class CboEvalProjectionsAcquirer(SourceAcquirer):
    """Capture commit-pinned files from US-CBO/eval-projections with explicit User-Agent."""

    def __init__(
        self,
        *,
        budget: EvalProjectionsBudget | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        budget = budget or EvalProjectionsBudget()
        self.budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent=USER_AGENT,
            label="CBO eval-projections repository",
            error_type=CboEvalProjectionsError,
            context_key="cbo_eval_projections_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def acquire_file(
        self,
        commit: str,
        rel_path: str,
        *,
        expected_sha256: str | None = None,
    ) -> FileAcquisition:
        url = raw_url(commit, rel_path)
        want = _check_sha256_token(expected_sha256, label="expected_sha256") if expected_sha256 is not None else None

        def parse(capture: CapturedBodyResponse, limit: int) -> FileReceipt:
            check_final_url(
                capture.resolved_url,
                url,
                error_type=CboEvalProjectionsError,
                message="eval-projections response left the pinned raw URL",
            )
            body = check_payload(
                capture.body, limit, label=rel_path, error_type=CboEvalProjectionsError, allow_empty=False
            )
            digest = _sha256_prefixed(body)
            if want is not None and digest != want:
                raise CboEvalProjectionsError(f"{rel_path} SHA-256 {digest} differs from expected {want}")
            return FileReceipt(
                rel_path=rel_path,
                commit=commit,
                url=url,
                sha256=digest,
                byte_size=len(body),
                observed_at=capture.observed_at,
                media_type=bare_media_type(capture.content_type) or "",
            )

        with named_challenge(url, error_type=CboEvalProjectionsRefused, context_key=self.context_key):
            receipt, capture = self.capture_validated(
                url,
                media_types=("text/plain", "text/csv", "text/markdown", "application/octet-stream"),
                parse=parse,
                max_bytes=self.budget.max_file_bytes,
                unavailable=CboEvalProjectionsUnavailable,
                context={"operation": "acquire_file", "commit": commit, "rel_path": rel_path},
            )
        return FileAcquisition(receipt=receipt, body=capture.body)

    def acquire_dataset(
        self,
        commit: str = PINNED_COMMIT,
        *,
        files: Sequence[str] = ALL_FILES,
        expected_sha256: Mapping[str, str] | None = None,
    ) -> DatasetAcquisition:
        check_commit(commit)
        selected = tuple(files)
        if not selected or len(set(selected)) != len(selected):
            raise CboEvalProjectionsError("files must be a non-empty list without duplicates")
        captured_files: dict[str, bytes] = {}
        receipts: dict[str, FileReceipt] = {}
        for rel_path in selected:
            expected = expected_sha256.get(rel_path) if expected_sha256 is not None else None
            acquired = self.acquire_file(commit, rel_path, expected_sha256=expected)
            captured_files[rel_path] = acquired.body
            receipts[rel_path] = acquired.receipt
        return DatasetAcquisition(commit=commit, files=captured_files, receipts=receipts)


__all__ = [
    "ALL_FILES",
    "CHANGE_CATEGORIES",
    "COMPONENTS",
    "DOC_FILES",
    "INPUT_FILES",
    "MAX_FILE_BYTES",
    "OUTPUT_FILES",
    "PINNED_COMMIT",
    "RAW_BASE",
    "REPOSITORY",
    "USER_AGENT",
    "ActualGdpRow",
    "ActualPctGdpRow",
    "ActualRow",
    "BaselineChangeRow",
    "BaselineRow",
    "CboEvalProjectionsAcquirer",
    "CboEvalProjectionsError",
    "CboEvalProjectionsRefused",
    "CboEvalProjectionsUnavailable",
    "DatasetAcquisition",
    "EvalProjectionsBudget",
    "EvalProjectionsBundle",
    "FileAcquisition",
    "FileReceipt",
    "ProjectionErrorRow",
    "SummaryStatRow",
    "check_commit",
    "parse_actual_gdp",
    "parse_actuals",
    "parse_actuals_pct_gdp",
    "parse_baseline_changes",
    "parse_baselines",
    "parse_eval_bundle",
    "parse_projection_errors",
    "parse_summary_stats",
    "raw_url",
]
