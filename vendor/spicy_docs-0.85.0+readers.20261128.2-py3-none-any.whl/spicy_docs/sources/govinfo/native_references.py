"""Literal law and Statutes at Large USLM references through the maintained bounded XML scanner."""

from collections.abc import Callable

from spicy_docs.sources.govinfo.uslm import DEFAULT_MAX_BYTES
from spicy_docs.sources.uscode.references import UsCodeReference, UsCodeReferenceScan, scan_uscode_references


def scan_law_references(
    xml: bytes,
    *,
    on_reference: Callable[[UsCodeReference], object] | None = None,
    max_bytes: int = 16 * 1024 * 1024,
    max_observations: int = 10_000,
    max_depth: int = 256,
) -> UsCodeReferenceScan:
    """Keep law href/ref elements and ancestry without claiming Code identity.

    Reuses the literal USLM reader. Source credits are counted by that reader but
    not emitted here; law source identity requires the separate law validator.
    Callbacks remain provisional until a successful return.
    """
    return scan_uscode_references(
        xml,
        on_reference=on_reference,
        max_bytes=max_bytes,
        max_observations=max_observations,
        max_depth=max_depth,
    )


def scan_statute_references(
    xml: bytes,
    *,
    on_reference: Callable[[UsCodeReference], object] | None = None,
    max_bytes: int = DEFAULT_MAX_BYTES,
    max_observations: int = 50_000,
    max_depth: int = 256,
) -> UsCodeReferenceScan:
    """Keep Statutes at Large (``STATUTE-*.xml``) href/ref elements and ancestry literally.

    Reuses the literal bounded USLM reader: every ``href`` attribute and ``ref`` element
    (including sidenote citations and early-volume ``footnoteRef`` elements without ``href``)
    survives with its expanded namespace and positional XPath ancestry. Source credits are
    counted by that reader but not emitted here; volume identity requires
    :func:`spicy_docs.sources.govinfo.uslm.validate_statutes_at_large_xml`.
    Callbacks remain provisional until a successful return.
    """
    return scan_uscode_references(
        xml,
        on_reference=on_reference,
        max_bytes=max_bytes,
        max_observations=max_observations,
        max_depth=max_depth,
    )


__all__ = ["scan_law_references", "scan_statute_references"]
