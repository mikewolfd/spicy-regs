"""Reader for RegInfo.gov OIRA Executive Order 12866 bulk XML reviews and meetings.

Under Executive Order 12866, significant regulatory actions go to OMB's Office
of Information and Regulatory Affairs (OIRA) for review before publication.
RegInfo.gov publishes bulk XML exports through ``XMLReportList`` and
``XMLViewFileAction`` with no API key required:

- ``AGY_AGENCY_LIST.xml``: numeric agency code to acronym and name.
- ``EO_RULE_COMPLETED_{YYYY}.xml``: reviews concluded in calendar year ``YYYY``.
- ``EO_RULE_COMPLETED_YTD.xml``: reviews concluded in the current year.
- ``EO_RULES_UNDER_REVIEW.xml``: reviews still pending at OIRA.
- ``EO_12866_Meeting_Data_*.xml``: EO 12866 meeting logs (``Cp1252`` encoded).

``EO_RULE_COMPLETED_30_DAYS.xml`` is explicitly skipped because it is a rolling
subset of ``EO_RULE_COMPLETED_YTD.xml``. Source facts such as historical
``DECISION`` wording and defunct agency codes are preserved verbatim, and every
yielded record carries ``source_file`` and ``source_sha256`` pinning the exact
XML bytes that produced it.
"""

from __future__ import annotations

import hashlib
import html
import logging
import math
import re
import time
import xml.etree.ElementTree as ET
from collections.abc import Callable, Collection, Iterator, Sequence
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from typing import TYPE_CHECKING, Any
from urllib.parse import urljoin, urlsplit

from spicy_docs.reading.error_pages import SNIFF_BYTES, detect_error_page, sniff
from spicy_docs.reading.xml import parse_xml
from spicy_docs.sources.base import Reader
from spicy_docs.transport.captured import observed_instant
from spicy_docs.transport.credentials import (
    ACCESS_REFUSED_STATUSES,
    CredentialRefusedError,
    refusal_message,
    scrub_credential,
)
from spicy_docs.transport.retry import retry_after_seconds

if TYPE_CHECKING:
    import httpx

logger = logging.getLogger(__name__)

REPORT_LIST_URL = "https://www.reginfo.gov/public/do/XMLReportList"
XML_FILE_URL = "https://www.reginfo.gov/public/do/XMLViewFileAction?f={file_name}"
UNDER_REVIEW = "under_review"
CONCLUDED = "concluded"
DEFAULT_USER_AGENT = "spicy-docs-oira/1.0 (+https://github.com/mikewolfd/spicy-regs)"
MAX_FILE_BYTES = 32 * 1024 * 1024

ALLOWED_HOST = "www.reginfo.gov"
AGENCY_LIST_FILE = "AGY_AGENCY_LIST.xml"
REVIEWS_YTD_FILE = "EO_RULE_COMPLETED_YTD.xml"
REVIEWS_PENDING_FILE = "EO_RULES_UNDER_REVIEW.xml"
REVIEWS_30_DAYS_FILE = "EO_RULE_COMPLETED_30_DAYS.xml"

DEFAULT_PAUSE_SECONDS = 0.5
DEFAULT_TIMEOUT_SECONDS = 120.0
DEFAULT_CONNECT_TIMEOUT_SECONDS = 30.0
MAX_RETRIES = 4
MAX_REDIRECTS = 5
_BACKOFF_CAP_SECONDS = 30.0

_REVIEW_ROOT_TAG = "OIRA_DATA"
_MEETING_ROOT_TAG = "RESULTS"
_REVIEW_TAG = "REGACT"
_MEETING_TAG = "ROW"

# Known Yes/No and operational flags seen on <REGACT> records. All non-core
# child elements are captured dynamically into ``flags`` so newly added flags
# (such as ``EXPEDITED_REVIEW``) are never silently dropped.
REVIEW_FLAG_TAGS: tuple[str, ...] = (
    "PANDEMIC_RESPONSE",
    "HEALTH_CARE_ACT",
    "DODD_FRANK_ACT",
    "INTERNATIONAL_IMPACTS",
    "UNFUNDED_MANDATES",
    "HOMELAND_SECURITY",
    "REGULATORY_FLEXIBILITY_ANALYSIS",
    "SMALL_ENTITIES_AFFECTED",
    "FEDERALISM_IMPLICATIONS",
    "TCJA",
    "EXPEDITED_REVIEW",
    "REVIEW_EXTENDED",
)

_CORE_REVIEW_TAGS = frozenset(
    {
        "AGENCY_CODE",
        "RIN",
        "TITLE",
        "STAGE",
        "ECONOMICALLY_SIGNIFICANT",
        "MAJOR",
        "LEGAL_DEADLINE",
        "DATE_RECEIVED",
        "DATE_COMPLETED",
        "DECISION",
        "DATE_PUBLISHED",
    }
)

_SAFE_FILE_NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+\.xml$")
_FILE_LINK_RE = re.compile(r"XMLViewFileAction\?(?:[^\"'>\s]*&(?:amp;)?)?f=([A-Za-z0-9_.-]+\.xml)")
_REVIEWS_YEAR_RE = re.compile(r"^EO_RULE_COMPLETED_(\d{4})\.xml$")
_MEETINGS_RE = re.compile(r"^EO_12866_Meeting_Data_[A-Za-z0-9_-]+\.xml$")
_YEAR_IN_NAME_RE = re.compile(r"(\d{4})")
_WS_RE = re.compile(r"\s+")

_XML_DECL_RE = re.compile(rb"\A(\xef\xbb\xbf)?(<\?xml\b[^?]*\?>)", re.IGNORECASE)
_XML_ENCODING_RE = re.compile(rb"""(\bencoding\s*=\s*)(["'])([^"']+)\2""", re.IGNORECASE)
_TRANSCODE_ENCODINGS: dict[str, str] = {
    "cp1252": "cp1252",
    "windows-1252": "cp1252",
    "win-1252": "cp1252",
    "iso-8859-1": "iso-8859-1",
    "latin-1": "iso-8859-1",
    "latin1": "iso-8859-1",
}

_MONTHS: dict[str, int] = {
    "JAN": 1,
    "FEB": 2,
    "MAR": 3,
    "APR": 4,
    "MAY": 5,
    "JUN": 6,
    "JUL": 7,
    "AUG": 8,
    "SEP": 9,
    "OCT": 10,
    "NOV": 11,
    "DEC": 12,
}
_ISO_DATE_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[T\s].*)?$")
_ORACLE_DATE_RE = re.compile(r"^(\d{1,2})-([A-Za-z]{3})-(\d{2}|\d{4})(?:\s.*)?$")
_REDIRECT_STATUSES = frozenset({301, 302, 303, 307, 308})


class OiraSourceError(RuntimeError):
    """Raised when RegInfo.gov OIRA source inputs or XML payloads are invalid."""


class OiraUnavailableError(OiraSourceError):
    """Raised when RegInfo.gov is unreachable, refuses access, or omits expected XML exports."""


class OiraAccessRefusedError(CredentialRefusedError, OiraUnavailableError):
    """HTTP 401/403 refusal from RegInfo.gov; aborts immediately without retry or fallback."""


@dataclass(frozen=True, slots=True)
class OiraCapturedFile:
    """Exact bytes and integrity metadata captured for one RegInfo.gov XML export."""

    file_name: str
    url: str
    sha256: str
    byte_size: int
    raw_bytes: bytes = field(repr=False)
    fetched_at: str


@dataclass(frozen=True, slots=True)
class AgencyEntry:
    """One numeric agency-code mapping row from ``AGY_AGENCY_LIST.xml``."""

    code: str
    acronym: str | None
    name: str | None

    def as_tuple(self) -> tuple[str | None, str | None]:
        """Return ``(acronym, name)`` for tuple-oriented callers."""
        return (self.acronym, self.name)


AgencyMap = dict[str, AgencyEntry]


@dataclass(frozen=True, slots=True)
class OiraReportIndex:
    """Discovered RegInfo.gov OIRA EO 12866 XML export inventory."""

    agency_list: str
    completed_years: tuple[tuple[int, str], ...]
    completed_ytd: str | None
    under_review: str | None
    meeting_files: tuple[str, ...]

    def review_files(self) -> tuple[str, ...]:
        """Return concluded annual files (oldest-first), then YTD, then under-review.

        Raises :class:`OiraUnavailableError` if per-year, YTD, or under-review
        exports are missing from the report list.
        """
        missing: list[str] = []
        if not self.completed_years:
            missing.append("per-year review files")
        if self.completed_ytd is None:
            missing.append(REVIEWS_YTD_FILE)
        if self.under_review is None:
            missing.append(REVIEWS_PENDING_FILE)
        if missing:
            raise OiraUnavailableError(
                f"report list at {REPORT_LIST_URL} is missing {', '.join(missing)}; has the page changed?"
            )
        assert self.completed_ytd is not None and self.under_review is not None
        return (*(name for _, name in self.completed_years), self.completed_ytd, self.under_review)

    def years_with_files(self) -> frozenset[int]:
        """Calendar years covered by dedicated annual completed-review exports."""
        return frozenset(year for year, _ in self.completed_years)


# --------------------------------------------------------------------------- #
# Pure helpers & validation
# --------------------------------------------------------------------------- #


def sha256_digest(raw_bytes: bytes) -> str:
    """Return the canonical ``sha256:<hex>`` digest of ``raw_bytes``."""
    return "sha256:" + hashlib.sha256(raw_bytes).hexdigest()


def _validate_file_name(file_name: str) -> str:
    if not isinstance(file_name, str) or ".." in file_name or _SAFE_FILE_NAME_RE.fullmatch(file_name) is None:
        raise OiraSourceError(f"invalid RegInfo.gov XML file name: {file_name!r}")
    return file_name


def xml_file_url(file_name: str) -> str:
    """Build the ``XMLViewFileAction`` URL for one validated XML file name."""
    return XML_FILE_URL.format(file_name=_validate_file_name(file_name))


def _validate_user_agent(user_agent: str) -> str:
    if not isinstance(user_agent, str) or not user_agent.strip() or "\r" in user_agent or "\n" in user_agent:
        raise OiraSourceError("user_agent must be a single non-empty header value")
    return user_agent.strip()


def _validate_positive_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise OiraSourceError(f"{name} must be a positive integer")
    return value


def _validate_nonnegative_seconds(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise OiraSourceError(f"{name} must be a finite non-negative number")
    return float(value)


def _validate_positive_seconds(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise OiraSourceError(f"{name} must be a finite positive number")
    return float(value)


def _check_allowed_url(url: str, *, what: str) -> None:
    parsed = urlsplit(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or host != ALLOWED_HOST:
        safe = scrub_credential(f"{parsed.scheme}://{parsed.netloc}")
        raise OiraUnavailableError(f"{what}: response URL left {ALLOWED_HOST} ({safe})")


def _meeting_sort_key(file_name: str) -> tuple[int, int, str]:
    match = _YEAR_IN_NAME_RE.search(file_name)
    year = int(match.group(1)) if match else 9999
    lower = file_name.lower()
    if "first_half" in lower:
        period = 1
    elif "second_half" in lower:
        period = 2
    else:
        period = 99
    return (year, period, file_name)


def parse_report_list(html_text: str) -> OiraReportIndex:
    """Parse RegInfo.gov's ``XMLReportList`` HTML into an :class:`OiraReportIndex`.

    Explicitly skips ``EO_RULE_COMPLETED_30_DAYS.xml`` (a rolling subset of
    ``EO_RULE_COMPLETED_YTD.xml``). Raises :class:`OiraUnavailableError` if no
    OIRA EO 12866 export links are found.
    """
    if not isinstance(html_text, str):
        raise OiraSourceError("report list HTML must be a string")
    raw_names = sorted({name for name in _FILE_LINK_RE.findall(html_text) if ".." not in name})

    agency_list = AGENCY_LIST_FILE
    years_by_num: dict[int, str] = {}
    completed_ytd: str | None = None
    under_review: str | None = None
    meetings: list[str] = []

    for name in raw_names:
        if name == REVIEWS_30_DAYS_FILE:
            continue
        if name == AGENCY_LIST_FILE:
            agency_list = name
        elif name == REVIEWS_YTD_FILE:
            completed_ytd = name
        elif name == REVIEWS_PENDING_FILE:
            under_review = name
        elif (year_match := _REVIEWS_YEAR_RE.match(name)) is not None:
            years_by_num[int(year_match.group(1))] = name
        elif _MEETINGS_RE.match(name) is not None:
            meetings.append(name)

    if not years_by_num and completed_ytd is None and under_review is None and not meetings:
        raise OiraUnavailableError(f"no OIRA EO 12866 export links found on {REPORT_LIST_URL}; has the page changed?")

    return OiraReportIndex(
        agency_list=agency_list,
        completed_years=tuple(sorted(years_by_num.items())),
        completed_ytd=completed_ytd,
        under_review=under_review,
        meeting_files=tuple(sorted(meetings, key=_meeting_sort_key)),
    )


def _clean_text(value: str | None) -> str | None:
    """Unescape double-escaped HTML entities, collapse whitespace, and turn blanks into ``None``."""
    if value is None:
        return None
    cleaned = _WS_RE.sub(" ", html.unescape(value)).strip()
    return cleaned or None


def _local_tag(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[-1]
    return tag


def _text(elem: ET.Element, tag: str) -> str | None:
    return _clean_text(elem.findtext(tag))


def parse_oira_date(value: str | None) -> str | None:
    """Normalize a RegInfo.gov date to ISO ``YYYY-MM-DD``.

    Supports ISO ``YYYY-MM-DD`` (review exports) and Oracle ``DD-MON-YY`` /
    ``DD-MON-YYYY`` (meeting exports). Two-digit years pivot at 80:
    ``yy >= 80`` maps to ``1900 + yy``; otherwise ``2000 + yy``. Unparseable
    values return ``None``.
    """
    if not value:
        return None
    text = value.strip()
    if not text:
        return None
    iso_match = _ISO_DATE_RE.match(text)
    if iso_match is not None:
        try:
            return date(int(iso_match.group(1)), int(iso_match.group(2)), int(iso_match.group(3))).isoformat()
        except ValueError:
            return None
    oracle_match = _ORACLE_DATE_RE.match(text)
    if oracle_match is not None:
        month = _MONTHS.get(oracle_match.group(2).upper())
        if month is None:
            return None
        year_text = oracle_match.group(3)
        if len(year_text) == 2:
            yy = int(year_text)
            year = 1900 + yy if yy >= 80 else 2000 + yy
        else:
            year = int(year_text)
        try:
            return date(year, month, int(oracle_match.group(1))).isoformat()
        except ValueError:
            return None
    return None


def _prepare_xml_bytes(raw_bytes: bytes, *, file_name: str) -> bytes:
    """Transcode Cp1252 / Latin-1 XML declarations to UTF-8 for Expat without altering original bytes."""
    decl_match = _XML_DECL_RE.match(raw_bytes)
    if decl_match is None:
        return raw_bytes
    decl = decl_match.group(2)
    enc_match = _XML_ENCODING_RE.search(decl)
    if enc_match is None:
        return raw_bytes
    declared = enc_match.group(3).decode("ascii", errors="ignore").strip().lower()
    python_codec = _TRANSCODE_ENCODINGS.get(declared)
    if python_codec is None:
        return raw_bytes
    normalized_decl = _XML_ENCODING_RE.sub(rb"\1\2UTF-8\2", decl, count=1)
    body_bytes = raw_bytes[decl_match.end() :]
    try:
        decoded_body = body_bytes.decode(python_codec, errors="strict")
    except UnicodeDecodeError as exc:
        raise OiraSourceError(f"{file_name}: failed to decode declared {declared} XML: {exc}") from exc
    return normalized_decl + decoded_body.encode("utf-8")


def _validate_and_parse_xml(
    raw_bytes: bytes,
    *,
    expected_root: str,
    file_name: str,
    max_bytes: int = MAX_FILE_BYTES,
) -> ET.Element:
    """Refuse HTML/error pages, oversized payloads, DTDs/entities, and unexpected roots."""
    _validate_positive_int(max_bytes, "max_bytes")
    if not isinstance(raw_bytes, bytes):
        raise OiraSourceError(f"{file_name}: XML payload must be bytes")
    if not raw_bytes:
        raise OiraUnavailableError(f"{file_name}: empty response body")
    if len(raw_bytes) > max_bytes:
        raise OiraUnavailableError(f"{file_name}: payload ({len(raw_bytes)} bytes) exceeds max_bytes ({max_bytes})")

    marker = detect_error_page(
        raw_bytes,
        status_code=200,
        url=xml_file_url(file_name),
        media_types=("application/xml", "text/xml"),
    )
    if marker is not None:
        raise OiraUnavailableError(
            f"{file_name}: did not return XML; detected {marker.family} error/HTML page ({marker})"
        )

    kind = sniff(raw_bytes[:SNIFF_BYTES])
    if kind != "xml":
        raise OiraUnavailableError(f"{file_name}: did not return XML (sniffed {kind}, {len(raw_bytes)} bytes)")

    prepared = _prepare_xml_bytes(raw_bytes, file_name=file_name)
    # Transcoding Cp1252 multi-byte characters (such as em-dash) to UTF-8 can
    # slightly expand byte length; raw_bytes has already passed max_bytes above.
    parse_limit = max(max_bytes, len(prepared))
    try:
        root = parse_xml(
            prepared,
            max_bytes=parse_limit,
            error_type=ValueError,
            label=file_name,
            allow_external_doctype=False,
        )
    except ValueError as exc:
        raise OiraSourceError(str(exc)) from exc

    if _local_tag(root.tag) != expected_root:
        raise OiraSourceError(f"{file_name}: expected XML root <{expected_root}>, got <{root.tag}>")
    return root


# --------------------------------------------------------------------------- #
# Record parsers
# --------------------------------------------------------------------------- #


def parse_agency_list(
    data: bytes,
    *,
    file_name: str = AGENCY_LIST_FILE,
    max_bytes: int = MAX_FILE_BYTES,
) -> AgencyMap:
    """Parse ``AGY_AGENCY_LIST.xml`` into a map of numeric agency code to :class:`AgencyEntry`."""
    root = _validate_and_parse_xml(data, expected_root=_REVIEW_ROOT_TAG, file_name=file_name, max_bytes=max_bytes)
    agencies: AgencyMap = {}
    for elem in root.iter("AGENCY"):
        code = _text(elem, "AGENCY_CODE")
        if code:
            agencies[code] = AgencyEntry(
                code=code,
                acronym=_text(elem, "ACRONYM"),
                name=_text(elem, "NAME"),
            )
    return agencies


def normalize_review(
    elem: ET.Element,
    source_file: str,
    *,
    source_sha256: str | None = None,
) -> dict[str, Any]:
    """Map one ``<REGACT>`` element to a source-faithful review dict.

    Preserves literal ``DECISION`` wording and numeric ``AGENCY_CODE``
    unchanged, turns whitespace-only tags into ``None``, and dynamically
    captures all non-core child elements into ``flags``.
    """
    flags: dict[str, str] = {}
    for child in elem:
        local = _local_tag(child.tag)
        if local in _CORE_REVIEW_TAGS:
            continue
        value = _clean_text("".join(child.itertext()))
        if value is not None:
            flags[local.lower()] = value

    is_under_review = source_file == REVIEWS_PENDING_FILE
    return {
        "rin": _text(elem, "RIN"),
        "agency_number": _text(elem, "AGENCY_CODE"),
        "title": _text(elem, "TITLE"),
        "stage": _text(elem, "STAGE"),
        "economically_significant": _text(elem, "ECONOMICALLY_SIGNIFICANT"),
        "major": _text(elem, "MAJOR"),
        "legal_deadline": _text(elem, "LEGAL_DEADLINE"),
        "received_date": parse_oira_date(_text(elem, "DATE_RECEIVED")),
        "concluded_date": parse_oira_date(_text(elem, "DATE_COMPLETED")),
        "decision": _text(elem, "DECISION"),
        "published_date": parse_oira_date(_text(elem, "DATE_PUBLISHED")),
        "review_extended": _text(elem, "REVIEW_EXTENDED"),
        "flags": flags,
        "under_review": is_under_review,
        "review_status": UNDER_REVIEW if is_under_review else CONCLUDED,
        "source_file": source_file,
        "source_sha256": source_sha256,
    }


def normalize_meeting(
    elem: ET.Element,
    source_file: str,
    *,
    source_sha256: str | None = None,
) -> dict[str, Any]:
    """Map one ``<ROW>`` meeting element to a source-faithful meeting-log dict."""
    agency = _text(elem, "AGENCYSUBAGENCYACRONYM") or ""
    if "-" in agency:
        raw_number, _, raw_acronym = agency.partition("-")
        agency_number = raw_number.strip() or None
        agency_acronym = raw_acronym.strip() or None
    elif agency.isdigit():
        agency_number = agency
        agency_acronym = None
    else:
        agency_number = None
        agency_acronym = agency or None

    return {
        "meeting_id": _text(elem, "MEETING_ID"),
        "rin": _text(elem, "RIN"),
        "agency_number": agency_number,
        "agency_acronym": agency_acronym,
        "title": _text(elem, "TITLE"),
        "rule_stage": _text(elem, "RULE_STAGE_DESC"),
        "meeting_date": parse_oira_date(_text(elem, "MEETINGDATETIME")),
        "meeting_status": _text(elem, "MEETING_TYPE"),
        "type_code": _text(elem, "TYPE_CD"),
        "requestor_organization": _text(elem, "REQUESTOR"),
        "requestor_name": _text(elem, "REQUESTOR_NAME"),
        "summary": _text(elem, "SUMMARY"),
        "source_file": source_file,
        "source_sha256": source_sha256,
    }


def parse_reviews_xml(
    data: bytes,
    *,
    source_file: str,
    years_with_files: Collection[int] | None = None,
    max_bytes: int = MAX_FILE_BYTES,
) -> Iterator[dict[str, Any]]:
    """Validate and stream normalized review dicts from raw OIRA review XML bytes.

    When ``source_file`` is ``EO_RULE_COMPLETED_YTD.xml`` and
    ``years_with_files`` contains the year of a row's ``concluded_date``, that
    overlapping YTD row is omitted so each review comes from one file.
    """
    _validate_file_name(source_file)
    root = _validate_and_parse_xml(data, expected_root=_REVIEW_ROOT_TAG, file_name=source_file, max_bytes=max_bytes)
    digest = sha256_digest(data)
    covered_years = frozenset(years_with_files) if years_with_files else frozenset()
    for elem in root.iter(_REVIEW_TAG):
        record = normalize_review(elem, source_file, source_sha256=digest)
        concluded = record["concluded_date"]
        if (
            source_file == REVIEWS_YTD_FILE
            and concluded
            and len(concluded) >= 4
            and concluded[:4].isdigit()
            and int(concluded[:4]) in covered_years
        ):
            continue
        yield record


def parse_meetings_xml(
    data: bytes,
    *,
    source_file: str,
    max_bytes: int = MAX_FILE_BYTES,
) -> Iterator[dict[str, Any]]:
    """Validate and stream normalized meeting-log dicts from raw OIRA meeting XML bytes."""
    _validate_file_name(source_file)
    root = _validate_and_parse_xml(data, expected_root=_MEETING_ROOT_TAG, file_name=source_file, max_bytes=max_bytes)
    digest = sha256_digest(data)
    for elem in root.iter(_MEETING_TAG):
        yield normalize_meeting(elem, source_file, source_sha256=digest)


# --------------------------------------------------------------------------- #
# Live HTTP transport (lazy httpx import)
# --------------------------------------------------------------------------- #


class _RetryableHttpError(Exception):
    def __init__(self, message: str, *, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


def _create_http_client(*, user_agent: str, timeout_seconds: float) -> httpx.Client:
    import httpx

    timeout = httpx.Timeout(timeout_seconds, connect=min(DEFAULT_CONNECT_TIMEOUT_SECONDS, timeout_seconds))
    return httpx.Client(
        timeout=timeout,
        follow_redirects=False,
        headers={"User-Agent": user_agent},
    )


def _stream_once(
    client: httpx.Client,
    url: str,
    *,
    what: str,
    user_agent: str,
    max_bytes: int,
) -> bytes:
    """Issue one bounded streaming GET, enforcing host pinning, 401/403 abort, and byte limit."""
    current_url = url
    _check_allowed_url(current_url, what=what)

    for _hop in range(MAX_REDIRECTS + 1):
        with client.stream("GET", current_url, headers={"User-Agent": user_agent}) as response:
            status = response.status_code
            if status in ACCESS_REFUSED_STATUSES:
                raise OiraAccessRefusedError(refusal_message(ALLOWED_HOST, status, what))

            if status in _REDIRECT_STATUSES:
                location = response.headers.get("location")
                if not location:
                    raise OiraUnavailableError(f"{what}: HTTP {status} redirect without Location header")
                current_url = urljoin(str(response.url), location)
                _check_allowed_url(current_url, what=what)
                continue

            if status == 429 or status >= 500:
                delay_hint = retry_after_seconds(response.headers.get("retry-after"), now=datetime.now(UTC))
                raise _RetryableHttpError(f"{what}: HTTP {status}", retry_after=delay_hint)

            if status != 200:
                raise OiraUnavailableError(f"{what}: HTTP {status}")

            _check_allowed_url(str(response.url), what=what)

            content_length = response.headers.get("content-length")
            if (
                content_length is not None
                and content_length.strip().isdigit()
                and int(content_length.strip()) > max_bytes
            ):
                raise OiraUnavailableError(
                    f"{what}: Content-Length ({content_length.strip()}) exceeds max_bytes ({max_bytes})"
                )

            buf = bytearray()
            for chunk in response.iter_bytes():
                if len(buf) + len(chunk) > max_bytes:
                    raise OiraUnavailableError(f"{what}: response exceeds max_bytes ({max_bytes})")
                buf.extend(chunk)
            return bytes(buf)

    raise OiraUnavailableError(f"{what}: exceeded {MAX_REDIRECTS} redirects")


def _fetch_live_bytes(
    url: str,
    *,
    what: str,
    client: httpx.Client | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
    max_bytes: int = MAX_FILE_BYTES,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    max_retries: int = MAX_RETRIES,
    sleep: Callable[[float], None] | None = None,
) -> bytes:
    """GET ``url`` with lazy ``httpx``, bounded streaming, host pinning, and transient retries."""
    import httpx

    validated_ua = _validate_user_agent(user_agent)
    _validate_positive_int(max_bytes, "max_bytes")
    _validate_positive_seconds(timeout_seconds, "timeout_seconds")
    attempts = _validate_positive_int(max_retries, "max_retries")
    sleep_fn = time.sleep if sleep is None else sleep

    owned_client = client is None
    active_client = (
        _create_http_client(user_agent=validated_ua, timeout_seconds=timeout_seconds) if owned_client else client
    )
    assert active_client is not None
    try:
        for attempt in range(1, attempts + 1):
            try:
                return _stream_once(
                    active_client,
                    url,
                    what=what,
                    user_agent=validated_ua,
                    max_bytes=max_bytes,
                )
            except OiraSourceError:
                raise
            except _RetryableHttpError as exc:
                reason = scrub_credential(str(exc))
                retry_hint = exc.retry_after
            except (httpx.TransportError, httpx.StreamError) as exc:
                reason = scrub_credential(f"{type(exc).__name__}: {exc}")
                retry_hint = None

            if attempt == attempts:
                raise OiraUnavailableError(f"{what}: failed after {attempt} attempt(s): {reason}")

            backoff = min(float(2 ** (attempt - 1)), _BACKOFF_CAP_SECONDS)
            if retry_hint is not None and math.isfinite(retry_hint) and retry_hint > 0:
                backoff = min(max(backoff, retry_hint), _BACKOFF_CAP_SECONDS)
            logger.warning(
                "OIRA: %s failed (%s), attempt %d/%d; retrying in %.1fs", what, reason, attempt, attempts, backoff
            )
            sleep_fn(backoff)
    finally:
        if owned_client:
            active_client.close()

    raise AssertionError("unreachable")  # pragma: no cover


def _check_report_list_bytes(raw_bytes: bytes, *, max_bytes: int) -> str:
    if not raw_bytes:
        raise OiraUnavailableError("report list returned an empty response body")
    if len(raw_bytes) > max_bytes:
        raise OiraUnavailableError(f"report list ({len(raw_bytes)} bytes) exceeds max_bytes ({max_bytes})")
    marker = detect_error_page(
        raw_bytes,
        status_code=200,
        url=REPORT_LIST_URL,
        media_types=("text/html",),
    )
    if marker is not None:
        raise OiraUnavailableError(f"report list returned an error/block page ({marker.family}: {marker})")
    return raw_bytes.decode("utf-8", errors="replace")


def list_report_files(
    html_or_none: str | bytes | None = None,
    *,
    fetch_bytes: Callable[[str], bytes] | None = None,
    client: httpx.Client | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
    max_file_bytes: int = MAX_FILE_BYTES,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    max_retries: int = MAX_RETRIES,
    sleep: Callable[[float], None] | None = None,
) -> OiraReportIndex:
    """Discover OIRA EO 12866 XML exports from ``XMLReportList`` HTML or a live/injected fetch.

    Pass ``html_or_none`` as ``str`` or ``bytes`` for offline parsing with no
    network dependency. When ``None``, fetches :data:`REPORT_LIST_URL` using
    ``fetch_bytes`` (if provided) or the live HTTP client.
    """
    _validate_positive_int(max_file_bytes, "max_file_bytes")
    if isinstance(html_or_none, str):
        html_text = _check_report_list_bytes(html_or_none.encode("utf-8"), max_bytes=max_file_bytes)
        return parse_report_list(html_text)
    if isinstance(html_or_none, bytes):
        html_text = _check_report_list_bytes(html_or_none, max_bytes=max_file_bytes)
        return parse_report_list(html_text)
    if html_or_none is not None:
        raise OiraSourceError("html_or_none must be str, bytes, or None")

    if fetch_bytes is not None:
        raw_bytes = fetch_bytes(REPORT_LIST_URL)
        if not isinstance(raw_bytes, bytes):
            raise OiraSourceError("fetch_bytes must return bytes")
    else:
        raw_bytes = _fetch_live_bytes(
            REPORT_LIST_URL,
            what="report list",
            client=client,
            user_agent=user_agent,
            max_bytes=max_file_bytes,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries,
            sleep=sleep,
        )
    return parse_report_list(_check_report_list_bytes(raw_bytes, max_bytes=max_file_bytes))


# --------------------------------------------------------------------------- #
# Readers
# --------------------------------------------------------------------------- #


class _OiraXmlReader(Reader):
    """Shared RegInfo.gov OIRA XML discovery, capture, integrity, and parsing workflow."""

    source_id = "oira"
    parser_version = "oira-v1"
    expected_root: str

    def __init__(
        self,
        *,
        files: Sequence[str] | None = None,
        index: OiraReportIndex | None = None,
        fetch_bytes: Callable[[str], bytes] | None = None,
        on_capture: Callable[[OiraCapturedFile], None] | None = None,
        client: httpx.Client | None = None,
        user_agent: str = DEFAULT_USER_AGENT,
        pause_seconds: float | None = None,
        max_file_bytes: int = MAX_FILE_BYTES,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = MAX_RETRIES,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
        sleep: Callable[[float], None] | None = None,
    ) -> None:
        super().__init__()
        self.files = tuple(_validate_file_name(name) for name in files) if files is not None else None
        self.report_index = index
        self._fetch_bytes = fetch_bytes
        self._on_capture = on_capture
        self._client = client
        self.user_agent = _validate_user_agent(user_agent)
        if pause_seconds is None:
            self.pause_seconds = 0.0 if fetch_bytes is not None else DEFAULT_PAUSE_SECONDS
        else:
            self.pause_seconds = _validate_nonnegative_seconds(pause_seconds, "pause_seconds")
        self.max_file_bytes = _validate_positive_int(max_file_bytes, "max_file_bytes")
        self.timeout_seconds = _validate_positive_seconds(timeout_seconds, "timeout_seconds")
        self.max_retries = _validate_positive_int(max_retries, "max_retries")
        self._clock = clock
        self._sleep = time.sleep if sleep is None else sleep
        self.file_counts: dict[str, int] = {}
        self.file_sha256: dict[str, str] = {}
        self.agencies: AgencyMap = {}

    def select_files(self, index: OiraReportIndex) -> tuple[str, ...]:
        raise NotImplementedError

    def _parse_file_records(
        self,
        raw_bytes: bytes,
        *,
        source_file: str,
        selected_files: tuple[str, ...],
    ) -> Iterator[dict[str, Any]]:
        raise NotImplementedError

    def iter_records(self) -> Iterator[dict[str, Any]]:
        self.file_counts = {}
        self.file_sha256 = {}
        self.last_keys = []
        self.failed_keys = []
        self.agencies = {}

        if self._fetch_bytes is not None or self._client is not None:
            yield from self._iter_with_client(self._client)
            return

        active_client = _create_http_client(user_agent=self.user_agent, timeout_seconds=self.timeout_seconds)
        try:
            yield from self._iter_with_client(active_client)
        finally:
            active_client.close()

    def _get_url_bytes(self, url: str, *, what: str, client: httpx.Client | None, made_request: bool) -> bytes:
        if made_request and self.pause_seconds > 0:
            self._sleep(self.pause_seconds)
        if self._fetch_bytes is not None:
            data = self._fetch_bytes(url)
            if not isinstance(data, bytes):
                raise OiraSourceError(f"{what}: fetch_bytes must return bytes")
            if len(data) > self.max_file_bytes:
                raise OiraUnavailableError(
                    f"{what}: payload ({len(data)} bytes) exceeds max_bytes ({self.max_file_bytes})"
                )
            return data
        return _fetch_live_bytes(
            url,
            what=what,
            client=client,
            user_agent=self.user_agent,
            max_bytes=self.max_file_bytes,
            timeout_seconds=self.timeout_seconds,
            max_retries=self.max_retries,
            sleep=self._sleep,
        )

    def _make_capture(self, file_name: str, raw_bytes: bytes) -> OiraCapturedFile:
        return OiraCapturedFile(
            file_name=file_name,
            url=xml_file_url(file_name),
            sha256=sha256_digest(raw_bytes),
            byte_size=len(raw_bytes),
            raw_bytes=raw_bytes,
            fetched_at=observed_instant(self._clock),
        )

    def _emit_capture(self, capture: OiraCapturedFile) -> None:
        self.file_sha256[capture.file_name] = capture.sha256
        if self._on_capture is not None:
            self._on_capture(capture)

    def _fetch_agency_map(
        self,
        agency_file: str,
        *,
        client: httpx.Client | None,
        made_request: bool,
    ) -> tuple[AgencyMap, bool]:
        """Fetch ``AGY_AGENCY_LIST.xml`` best-effort; still aborts immediately on 401/403."""
        url = xml_file_url(agency_file)
        try:
            raw_bytes = self._get_url_bytes(url, what=agency_file, client=client, made_request=made_request)
            made_request = True
            agencies = parse_agency_list(raw_bytes, file_name=agency_file, max_bytes=self.max_file_bytes)
        except CredentialRefusedError:
            raise
        except OiraSourceError as exc:
            logger.warning(
                "OIRA: agency list %s unavailable (%s); rows keep numeric agency_number",
                agency_file,
                scrub_credential(str(exc)),
            )
            return {}, made_request
        self._emit_capture(self._make_capture(agency_file, raw_bytes))
        return agencies, made_request

    def _iter_with_client(self, client: httpx.Client | None) -> Iterator[dict[str, Any]]:
        made_request = False
        index = self.report_index
        if self.files is not None:
            selected_files = self.files
            agency_file = index.agency_list if index is not None else AGENCY_LIST_FILE
        else:
            if index is None:
                index = list_report_files(
                    None,
                    fetch_bytes=self._fetch_bytes,
                    client=client,
                    user_agent=self.user_agent,
                    max_file_bytes=self.max_file_bytes,
                    timeout_seconds=self.timeout_seconds,
                    max_retries=self.max_retries,
                    sleep=self._sleep,
                )
                made_request = True
                self.report_index = index
            selected_files = self.select_files(index)
            agency_file = index.agency_list

        self.agencies, made_request = self._fetch_agency_map(agency_file, client=client, made_request=made_request)

        for file_name in selected_files:
            url = xml_file_url(file_name)
            try:
                raw_bytes = self._get_url_bytes(url, what=file_name, client=client, made_request=made_request)
                made_request = True
                records = list(
                    self._parse_file_records(
                        raw_bytes,
                        source_file=file_name,
                        selected_files=selected_files,
                    )
                )
            except Exception:
                self.failed_keys.append(file_name)
                raise

            self._emit_capture(self._make_capture(file_name, raw_bytes))
            self.file_counts[file_name] = len(records)
            self.last_keys.append(file_name)
            yield from records


class OiraReviewsReader(_OiraXmlReader):
    """Yields normalized EO 12866 review dicts across annual, YTD, and under-review exports."""

    source_id = "oira_reviews"
    expected_root = _REVIEW_ROOT_TAG

    def select_files(self, index: OiraReportIndex) -> tuple[str, ...]:
        return index.review_files()

    def _parse_file_records(
        self,
        raw_bytes: bytes,
        *,
        source_file: str,
        selected_files: tuple[str, ...],
    ) -> Iterator[dict[str, Any]]:
        years_with_files = {
            int(match.group(1)) for name in selected_files if (match := _REVIEWS_YEAR_RE.match(name)) is not None
        }
        return parse_reviews_xml(
            raw_bytes,
            source_file=source_file,
            years_with_files=years_with_files,
            max_bytes=self.max_file_bytes,
        )


class OiraMeetingsReader(_OiraXmlReader):
    """Yields normalized EO 12866 meeting-log dicts across listed meeting exports."""

    source_id = "oira_meetings"
    expected_root = _MEETING_ROOT_TAG

    def select_files(self, index: OiraReportIndex) -> tuple[str, ...]:
        if not index.meeting_files:
            raise OiraUnavailableError(
                f"report list at {REPORT_LIST_URL} lists no EO 12866 meeting files; has the page changed?"
            )
        return index.meeting_files

    def _parse_file_records(
        self,
        raw_bytes: bytes,
        *,
        source_file: str,
        selected_files: tuple[str, ...],
    ) -> Iterator[dict[str, Any]]:
        del selected_files
        return parse_meetings_xml(
            raw_bytes,
            source_file=source_file,
            max_bytes=self.max_file_bytes,
        )


__all__ = [
    "AGENCY_LIST_FILE",
    "ALLOWED_HOST",
    "CONCLUDED",
    "DEFAULT_CONNECT_TIMEOUT_SECONDS",
    "DEFAULT_PAUSE_SECONDS",
    "DEFAULT_TIMEOUT_SECONDS",
    "DEFAULT_USER_AGENT",
    "MAX_FILE_BYTES",
    "MAX_REDIRECTS",
    "MAX_RETRIES",
    "REPORT_LIST_URL",
    "REVIEWS_30_DAYS_FILE",
    "REVIEWS_PENDING_FILE",
    "REVIEWS_YTD_FILE",
    "REVIEW_FLAG_TAGS",
    "UNDER_REVIEW",
    "XML_FILE_URL",
    "AgencyEntry",
    "AgencyMap",
    "OiraAccessRefusedError",
    "OiraCapturedFile",
    "OiraMeetingsReader",
    "OiraReportIndex",
    "OiraReviewsReader",
    "OiraSourceError",
    "OiraUnavailableError",
    "list_report_files",
    "normalize_meeting",
    "normalize_review",
    "parse_agency_list",
    "parse_meetings_xml",
    "parse_oira_date",
    "parse_report_list",
    "parse_reviews_xml",
    "sha256_digest",
    "xml_file_url",
]
