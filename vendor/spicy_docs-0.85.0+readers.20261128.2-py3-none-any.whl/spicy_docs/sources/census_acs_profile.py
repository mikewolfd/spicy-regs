"""Publish and independently replay one retained ACS county or congressional district query with exact source bytes."""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from datetime import datetime
from functools import cache
from io import BytesIO
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.reading.evidence_zip import deterministic_zip_entry, has_deterministic_zip_metadata
from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.releases.profile import SourceNativeProfile
from spicy_docs.sources.census_acs import MAX_BYTES, AcsError, AcsSelection, acs_records, descriptor
from spicy_docs.transport.captured import CapturedBodyResponse

SCOPE_ID = "census-acs5-counties"
SCHEMA_NAME = "census-acs5-county-observation"
SCHEMA_VERSION = "1.0"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-{SCHEMA_VERSION}.json"
CD_SCOPE_ID = "census-acs5-congressional-districts"
CD_SCHEMA_NAME = "census-acs5-congressional-district-observation"
CD_SCHEMA_KEY = f"schemas/{CD_SCHEMA_NAME}-{SCHEMA_VERSION}.json"
MAX_BUNDLE_BYTES = 16 * MAX_BYTES


def _observation_schema(
    schema_name: str,
    *,
    geography: str,
    code_field: str,
    code_pattern: str,
    geo_id_pattern: str,
) -> dict:
    fields = (
        "dataset",
        "vintage",
        "geography",
        "state",
        code_field,
        "name",
        "geo_id",
        "values",
        "variables",
        "value_sources",
        "metadata_sources",
    )
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"urn:spicy-docs:schema:{schema_name}:1.0",
        "type": "object",
        "additionalProperties": False,
        "required": list(fields),
        "properties": {
            "dataset": {"const": "acs/acs5"},
            "vintage": {"type": "integer", "minimum": 2009},
            "geography": {"const": geography},
            "state": {"type": "string", "pattern": "^[0-9]{2}$"},
            code_field: {"type": "string", "pattern": code_pattern},
            "name": {"type": "string", "minLength": 1},
            "geo_id": {"type": "string", "pattern": geo_id_pattern},
            "values": {"type": "object", "additionalProperties": {"type": ["string", "null"]}},
            "variables": {"type": "object"},
            "value_sources": {"type": "object"},
            "metadata_sources": {"type": "object"},
        },
        "x-spicy-record-order": [
            {
                "fieldPath": "/geo_id",
                "nullOrder": "forbidden",
                "tupleComparison": "utf16-code-unit",
                "valueType": "string",
            }
        ],
    }


_SCHEMA = _observation_schema(
    SCHEMA_NAME,
    geography="county",
    code_field="county",
    code_pattern="^[0-9]{3}$",
    geo_id_pattern="^0500000US[0-9]{5}$",
)
_CD_SCHEMA = _observation_schema(
    CD_SCHEMA_NAME,
    geography="congressional district",
    code_field="congressional_district",
    code_pattern="^(?:[0-9]{2}|ZZ)$",
    geo_id_pattern="^500[0-9]{2}00US[0-9]{2}(?:[0-9]{2}|ZZ)$",
)


def acs_scope(selection: AcsSelection, captures) -> dict:
    """Bind the exact selected query and every metadata/data capture before publication."""
    acs_records(selection, captures)
    return {
        "selection": asdict(selection) | {"variables": list(selection.variables)},
        "captures": [descriptor(c) for c in captures],
    }


def _selection_from_scope(selected: object, *, expected_geography: str | None = None) -> AcsSelection:
    if (
        not isinstance(selected, dict)
        or set(selected) not in ({"vintage", "state", "variables"}, {"vintage", "state", "variables", "geography"})
        or not isinstance(selected["variables"], list)
    ):
        raise AcsError("ACS release selection fields differ")
    geography = selected.get("geography", "county")
    selection = AcsSelection(selected["vintage"], selected["state"], tuple(selected["variables"]), geography)
    if expected_geography is not None and selection.geography != expected_geography:
        raise AcsError("ACS release geography differs from this profile")
    return selection


def _scope(value, *, expected_geography: str | None = None):
    if not isinstance(value, dict) or set(value) != {"selection", "captures"}:
        raise AcsError("ACS release scope fields differ")
    selection = _selection_from_scope(value["selection"], expected_geography=expected_geography)
    captures = value["captures"]
    if not isinstance(captures, list) or len(captures) != len(selection.urls):
        raise AcsError("ACS release capture inventory differs")

    for capture, url in zip(captures, selection.urls, strict=True):
        if (
            not isinstance(capture, dict)
            or set(capture) != {"request_url", "response_sha256", "observed_at", "byte_size"}
            or capture["request_url"] != url
            or not isinstance(capture["response_sha256"], str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
            or type(capture["byte_size"]) is not int
            or not 0 < capture["byte_size"] <= MAX_BYTES
        ):
            raise AcsError("ACS release capture identity differs")
        try:
            observed = datetime.fromisoformat(capture["observed_at"])
        except (TypeError, ValueError) as error:
            raise AcsError("ACS release capture timestamp is invalid") from error
        if observed.utcoffset() is None:
            raise AcsError("ACS release capture timestamp needs a timezone")
    return value


@dataclass(frozen=True, slots=True)
class AcsRetainedPage:
    request_key: str
    response_bytes: bytes
    page_index: int = 0
    traversal_index: int = 0
    window_index: int = 0
    window_page_index: int = 0
    source_cursor: None = None
    evidence_media_type: str = "application/zip"


def retained_page(selection: AcsSelection, captures) -> AcsRetainedPage:
    """One bounded evidence ZIP follows the existing retained-source publisher pattern."""
    scope = acs_scope(selection, captures)
    output = BytesIO()
    with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr(deterministic_zip_entry("manifest.json"), canonical_json_bytes(scope))
        for index, capture in enumerate(captures):
            archive.writestr(deterministic_zip_entry(f"responses/{index}.json"), capture.body)
    body = output.getvalue()
    if len(body) > MAX_BUNDLE_BYTES:
        raise AcsError("ACS evidence bundle exceeds its byte bound")
    return AcsRetainedPage(selection.data_url(selection.chunks[0]), body)


def _parse_bundle(body, *, expected_geography: str | None = None):
    if not isinstance(body, bytes) or len(body) > MAX_BUNDLE_BYTES:
        raise AcsError("ACS evidence bundle exceeds its byte bound")
    try:
        with ZipFile(BytesIO(body)) as archive:
            infos = archive.infolist()
            if not infos or infos[0].filename != "manifest.json" or infos[0].file_size > MAX_BYTES:
                raise AcsError("ACS evidence manifest missing or oversized")
            scope = _scope(
                load_integer_json(archive.read(infos[0]), source="ACS manifest", error_type=AcsError),
                expected_geography=expected_geography,
            )
            names = ["manifest.json", *(f"responses/{i}.json" for i in range(len(scope["captures"])))]
            if len(infos) != len(names) or any(
                not has_deterministic_zip_metadata(i, name=n) for i, n in zip(infos, names, strict=True)
            ):
                raise AcsError("ACS evidence ZIP membership or metadata differs")
            captures = []
            for info, stated in zip(infos[1:], scope["captures"], strict=True):
                if info.file_size != stated["byte_size"]:
                    raise AcsError("ACS retained response size differs")
                raw = archive.read(info)
                if "sha256:" + hashlib.sha256(raw).hexdigest() != stated["response_sha256"]:
                    raise AcsError("ACS retained response digest differs")
                captures.append(
                    CapturedBodyResponse(
                        stated["request_url"],
                        stated["request_url"],
                        200,
                        "application/json",
                        stated["observed_at"],
                        raw,
                    )
                )
    except BadZipFile as error:
        raise AcsError("ACS evidence ZIP is invalid") from error
    selection = _selection_from_scope(scope["selection"], expected_geography=expected_geography)
    return {"scope": scope, "results": list(acs_records(selection, captures))}


def _included(response, *, query_scope, page_window):
    selection = _selection_from_scope(query_scope["selection"])
    if response["scope"] != query_scope or page_window != selection.data_url(selection.chunks[0]):
        raise AcsError("ACS evidence differs from the captured release scope")
    return True


@dataclass
class _Traversal:
    pages: int = 0

    def add(self, response, *, page_index):
        if page_index != 0 or self.pages:
            raise AcsError("ACS release requires one complete retained query")
        self.pages += 1

    def finish(self):
        if self.pages != 1:
            raise AcsError("ACS release omitted its retained query")


@dataclass
class _Acquisition:
    windows: int = 0

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if not records_included:
            raise AcsError("ACS release omitted query records")
        self.windows += 1

    def finish(self, *, query_scope):
        if self.windows != 1:
            raise AcsError("ACS release requires one retained query window")


def _record_scope(record, *, query_scope, page_window):
    selected = query_scope["selection"]
    if (
        record["vintage"] != selected["vintage"]
        or (selected["state"] != "*" and record["state"] != selected["state"])
        or record["geography"] != selected.get("geography", "county")
        or any(
            set(record[f]) != set(selected["variables"])
            for f in ("values", "variables", "value_sources", "metadata_sources")
        )
    ):
        raise AcsError("ACS record differs from its selected scope")


@cache
def _schema_digest(schema_key: str, geography: str):
    schema = _SCHEMA if geography == "county" else _CD_SCHEMA
    return schema_bundle_digest({schema_key: schema})


def _classify_record(record: object) -> dict:
    if not isinstance(record, dict):
        raise AcsError("ACS release record must be an object")
    return dict(record)


def _acs_profile(
    *,
    name: str,
    scope_id: str,
    schema_name: str,
    schema_key: str,
    schema: dict,
    record_stem: str,
    geography: str,
    code_field: str,
    coverage_limits: list[str],
) -> SourceNativeProfile:
    return SourceNativeProfile(
        name=name,
        source_system_id="https://api.census.gov/data",
        source_system_version="acs/acs5",
        acquisition_policy_id=f"urn:spicy-docs:acquisition:{scope_id}",
        acquisition_policy_version="1.0",
        scope_id=scope_id,
        source_schema_key=schema_key,
        source_schema=schema,
        record_stem=record_stem,
        max_traversals=1,
        source_state_scope="observed-crawl",
        traversal_acceptance="single-observed-traversal",
        acquisition_policy=lambda scope: {
            "initialQueryScope": _scope(scope, expected_geography=geography),
            "strategy": "retained-geography-keyed-query",
            "coverageLimits": coverage_limits,
        },
        validate_query_scope=lambda scope: _scope(scope, expected_geography=geography),
        parse_page_response=lambda body: _parse_bundle(body, expected_geography=geography),
        next_page=lambda response, *, seen_urls: None,
        traversal_check=_Traversal,
        classify_record=_classify_record,
        wrap_record=lambda record, *, schema_digest: {
            "fieldDiagnostics": [],
            "record": dict(record),
            "schemaDigest": schema_digest,
            "schemaName": schema_name,
            "schemaVersion": SCHEMA_VERSION,
            "scopeId": scope_id,
            "sourceRecordId": f"{record['vintage']}:{record['state']}:{record[code_field]}",
        },
        record_digest=lambda record: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(record))).hexdigest(),
        rendition_rows=lambda record: (),
        source_schema_declaration=lambda: {
            "schemaDigest": _schema_digest(schema_key, geography),
            "schemaName": schema_name,
            "schemaVersion": SCHEMA_VERSION,
        },
        source_schema_digest=lambda: _schema_digest(schema_key, geography),
        validate_record_scope=_record_scope,
        records_included=_included,
        acquisition_check=_Acquisition,
        page_window=lambda url: url,
    )


ACS5_COUNTY_PROFILE = _acs_profile(
    name="Retained ACS five-year county observations",
    scope_id=SCOPE_ID,
    schema_name=SCHEMA_NAME,
    schema_key=SCHEMA_KEY,
    schema=_SCHEMA,
    record_stem="census-acs5-county",
    geography="county",
    code_field="county",
    coverage_limits=[
        "Selected ACS5 vintage, variables and single-state or nationwide county query only.",
        "The API states no total count; returned membership is observed, not a frozen publisher snapshot.",
        "No numeric coercion, geocoding, backfill or linked acquisition.",
    ],
)

ACS5_CONGRESSIONAL_DISTRICT_PROFILE = _acs_profile(
    name="Retained ACS five-year congressional district observations",
    scope_id=CD_SCOPE_ID,
    schema_name=CD_SCHEMA_NAME,
    schema_key=CD_SCHEMA_KEY,
    schema=_CD_SCHEMA,
    record_stem="census-acs5-congressional-district",
    geography="congressional district",
    code_field="congressional_district",
    coverage_limits=[
        "Selected ACS5 vintage, variables and single-state or nationwide congressional district query only.",
        "The API states no total count; returned membership is observed, not a frozen publisher snapshot.",
        "No numeric coercion, geocoding, backfill or linked acquisition.",
    ],
)
