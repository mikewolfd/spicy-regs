"""Literal rows of reviewed FEC Federal Elections workbooks, with no contest filters.

Use the existing bounded OOXML reader. State certification, ballot-line fusion,
round selection, electoral-vs-popular separation, and financial candidate
identity remain downstream decisions.
"""

import hashlib
import re
from collections import defaultdict
from dataclasses import asdict, dataclass

from spicy_docs.sources.scorecards.workbooks import literal_sheets

READER_VERSION = "fec-election-workbook/2"
SENATE_2022 = "7. US Senate Results by State"
TITLE_2022 = "FEDERAL ELECTIONS 2022:  ELECTION RESULTS FOR THE U.S. SENATE AND THE U.S. HOUSE OF REPRESENTATIVES"


@dataclass(frozen=True)
class SheetSpec:
    """Reviewed worksheet contract inside one official FEC election workbook."""

    name: str
    office: str
    layout: str
    headers: dict[str, str]


@dataclass(frozen=True)
class EditionSpec:
    """Reviewed official FEC election workbook edition contract."""

    cycle: int
    edition_kind: str
    title_sheet: str
    title_cell: str
    title_text: str
    sheets: tuple[SheetSpec, ...]
    sentinel_cells: tuple[tuple[str, str, str], ...] = ()


_CONGRESS_2022_HEADERS = {
    "B1": "STATE ABBREVIATION",
    "D1": "DISTRICT",
    "E1": "FEC ID",
    "I1": "CANDIDATE NAME",
    "L1": "PRIMARY VOTES",
    "P1": "GENERAL VOTES ",
    "T1": "COMBINED GE PARTY TOTALS (when applicable)",
    "AC1": "3RD ROUND RCV VOTES",
}
_CONGRESS_2020_SENATE_HEADERS = {
    "B1": "STATE ABBREVIATION",
    "D1": "DISTRICT",
    "E1": "FEC ID",
    "I1": "CANDIDATE NAME",
    "L1": "PRIMARY VOTES",
    "P1": "GENERAL VOTES ",
    "R1": "GE RUNOFF ELECTION VOTES (GA, LA)",
    "T1": "COMBINED GE PARTY TOTALS (when applicable)",
}
_CONGRESS_2020_HOUSE_HEADERS = {
    "B1": "STATE ABBREVIATION",
    "D1": "DISTRICT",
    "E1": "FEC ID",
    "I1": "CANDIDATE NAME",
    "L1": "PRIMARY VOTES",
    "P1": "GENERAL VOTES ",
    "R1": "GE RUNOFF ELECTION VOTES (GA, GU, LA)",
    "T1": "COMBINED GE PARTY TOTALS (CT, NY)",
}
_CONGRESS_2018_HEADERS = {
    "B1": "STATE ABBREVIATION",
    "D1": "DISTRICT",
    "E1": "FEC ID#",
    "I1": "CANDIDATE NAME",
    "L1": "PRIMARY VOTES",
    "P1": "GENERAL VOTES ",
    "R1": "GE RUNOFF ELECTION VOTES (MS Senate)",
    "T1": "COMBINED GE PARTY TOTALS (CT, NY)",
}
_CONGRESS_2016_HEADERS = {
    "B1": "STATE ABBREVIATION",
    "D1": "D",
    "E1": "FEC ID#",
    "I1": "CANDIDATE NAME",
    "L1": "PRIMARY VOTES",
    "P1": "GENERAL VOTES ",
    "R1": "GE RUNOFF ELECTION VOTES (LA)",
    "T1": "COMBINED GE PARTY TOTALS (CT, NY, SC)",
}
_PRES_GENERAL_2020_HEADERS = {
    "B1": "FEC ID",
    "D1": "STATE ABBREVIATION",
    "H1": "LAST NAME,  FIRST",
    "I1": "TOTAL VOTES",
    "J1": "PARTY",
    "K1": "GENERAL RESULTS",
    "M1": "TOTAL VOTES #",
    "N1": "COMBINED GE PARTY TOTALS (NY)",
    "Q1": "ELECTORAL VOTES",
}
_PRES_PRIMARY_2020_HEADERS = {
    "B1": "FEC ID",
    "D1": "STATE ABBREVIATION",
    "H1": "LAST NAME,  FIRST",
    "I1": "TOTAL VOTES",
    "J1": "PARTY",
    "K1": "PRIMARY RESULTS",
    "M1": "RANKED CHOICE VOTING (RCV) ROUND 2",
    "S1": "RANKED CHOICE VOTING (RCV) ROUND 8",
}
_PRES_GENERAL_2016_HEADERS = {
    "B1": "FEC ID",
    "D1": "STATE ABBREVIATION",
    "H1": "LAST NAME,  FIRST",
    "I1": "TOTAL VOTES",
    "J1": "PARTY",
    "K1": "GENERAL RESULTS",
    "L1": "TOTAL VOTES #",
    "M1": "GENERAL %",
    "N1": "WINNER INDICATOR",
}
_PRES_ELECTORAL_2016_HEADERS = {
    "A1": "2016 PRESIDENTIAL ELECTORAL AND POPULAR VOTE",
    "A3": "STATE",
    "B3": "ELECTORAL VOTE",
    "C3": "ELECTORAL VOTE",
    "B4": "Trump (R)",
    "C4": "Clinton (D)",
}
_PRES_PRIMARY_2016_HEADERS = {
    "B1": "FEC ID",
    "D1": "STATE ABBREVIATION",
    "H1": "LAST NAME,  FIRST",
    "I1": "TOTAL VOTES",
    "J1": "PARTY",
    "K1": "PRIMARY RESULTS",
    "L1": "PRIMARY %",
}
_PRES_MATRIX_2024_HEADERS = {
    "A1": "STATE",
    "B1": "ELECTORAL VOTES",
    "C1": "ELECTORAL VOTE: TRUMP (R)",
    "D1": "ELECTORAL VOTE: HARRIS (D)",
    "M1": "HARRIS",
    "Y1": "TRUMP",
    "AC1": "NONE OF THESE CANDIDATES",
    "AD1": "WRITE-INS (SCATTERED)",
    "AE1": "TOTAL VOTES",
}

EDITIONS: dict[int, EditionSpec] = {
    2016: EditionSpec(
        cycle=2016,
        edition_kind="federal_elections",
        title_sheet="Publication Information",
        title_cell="A22",
        title_text=(
            "FEDERAL ELECTIONS 2016:  ELECTION RESULTS FOR THE U.S. PRESIDENT, "
            "THE U.S. SENATE AND THE U.S. HOUSE OF REPRESENTATIVES"
        ),
        sheets=(
            SheetSpec(
                name="2016 Pres General Results",
                office="president",
                layout="pres_general_2016",
                headers=_PRES_GENERAL_2016_HEADERS,
            ),
            SheetSpec(
                name="Table 2. Electoral &  Pop Vote",
                office="president",
                layout="pres_electoral_table2_2016",
                headers=_PRES_ELECTORAL_2016_HEADERS,
            ),
            SheetSpec(
                name="2016 Pres Primary Results",
                office="president",
                layout="pres_primary_2016",
                headers=_PRES_PRIMARY_2016_HEADERS,
            ),
            SheetSpec(
                name="2016 US Senate Results by State",
                office="senate",
                layout="congress_2016",
                headers=_CONGRESS_2016_HEADERS,
            ),
            SheetSpec(
                name="2016 US House Results by State",
                office="house",
                layout="congress_2016",
                headers=_CONGRESS_2016_HEADERS,
            ),
        ),
    ),
    2018: EditionSpec(
        cycle=2018,
        edition_kind="federal_elections",
        title_sheet="Publication Information",
        title_cell="A15",
        title_text="FEDERAL ELECTIONS 2018:  ELECTION RESULTS FOR THE U.S. SENATE AND THE U.S. HOUSE OF REPRESENTATIVES",
        sheets=(
            SheetSpec(
                name="2018 US Senate Results by State",
                office="senate",
                layout="congress_2018",
                headers=_CONGRESS_2018_HEADERS,
            ),
            SheetSpec(
                name="2018 US House Results by State",
                office="house",
                layout="congress_2018",
                headers=_CONGRESS_2018_HEADERS,
            ),
        ),
    ),
    2020: EditionSpec(
        cycle=2020,
        edition_kind="federal_elections",
        title_sheet="1. 2020 Publication Information",
        title_cell="A23",
        title_text=(
            "FEDERAL ELECTIONS 2020:  ELECTION RESULTS FOR THE U.S. PRESIDENT, "
            "THE U.S. SENATE AND THE U.S. HOUSE OF REPRESENTATIVES"
        ),
        sheets=(
            SheetSpec(
                name="9. 2020 Pres General Results",
                office="president",
                layout="pres_general_2020",
                headers=_PRES_GENERAL_2020_HEADERS,
            ),
            SheetSpec(
                name="10. 2020 Pres Primary Results",
                office="president",
                layout="pres_primary_2020",
                headers=_PRES_PRIMARY_2020_HEADERS,
            ),
            SheetSpec(
                name="12. US Senate Results by State",
                office="senate",
                layout="congress_2020",
                headers=_CONGRESS_2020_SENATE_HEADERS,
            ),
            SheetSpec(
                name="13. US House Results by State",
                office="house",
                layout="congress_2020",
                headers=_CONGRESS_2020_HOUSE_HEADERS,
            ),
        ),
    ),
    2022: EditionSpec(
        cycle=2022,
        edition_kind="federal_elections",
        title_sheet="1. 2022 Publication Information",
        title_cell="A15",
        title_text=TITLE_2022,
        sheets=(
            SheetSpec(
                name=SENATE_2022,
                office="senate",
                layout="congress_2022",
                headers=_CONGRESS_2022_HEADERS,
            ),
            SheetSpec(
                name="8. US House Results by State",
                office="house",
                layout="congress_2022",
                headers=_CONGRESS_2022_HEADERS,
            ),
        ),
    ),
    2024: EditionSpec(
        cycle=2024,
        edition_kind="presidential_general",
        title_sheet="OFFICIAL 2024 PRES GE RESULTS",
        title_cell="A1",
        title_text="STATE",
        sheets=(
            SheetSpec(
                name="OFFICIAL 2024 PRES GE RESULTS",
                office="president",
                layout="pres_matrix_2024",
                headers=_PRES_MATRIX_2024_HEADERS,
            ),
        ),
        sentinel_cells=(("OFFICIAL 2024 PRES GE RESULTS", "B66", "General Election Date:  11/05/2024"),),
    ),
}


def supported_cycles() -> tuple[int, ...]:
    """Return all reviewed election workbook cycles in ascending order."""
    return tuple(sorted(EDITIONS))


def edition_spec(cycle: int) -> EditionSpec:
    """Return the reviewed workbook specification for ``cycle`` or refuse."""
    spec = EDITIONS.get(cycle)
    if spec is None:
        supported = ", ".join(str(c) for c in supported_cycles())
        raise ValueError(f"Election cycle {cycle} is unreviewed; supported editions are: {supported}")
    return spec


def workbook_rows(body: bytes, *, sha256: str, cycle: int):
    """Yield every physical row and literal cell of one supported result edition.

    The digest identifies the original, not a cached conversion. Null cells,
    formulas, zero votes, totals, notes and appendix observations all survive.
    A ballot roster or changed layout refuses before yielding anything.
    """
    if "sha256:" + hashlib.sha256(body).hexdigest() != sha256:
        raise ValueError("Election workbook differs from its selected original digest")
    spec = edition_spec(cycle)
    sheets = literal_sheets(body)
    title_sheet = sheets.get(spec.title_sheet, {})
    title_cell = title_sheet.get(spec.title_cell)
    if title_cell is None or title_cell.value != spec.title_text:
        raise ValueError(
            f"Expected reviewed Federal Elections {cycle} results, not a ballot roster or unreviewed layout"
        )
    for sheet_name, coordinate, expected_text in spec.sentinel_cells:
        sentinel = sheets.get(sheet_name, {}).get(coordinate)
        if sentinel is None or sentinel.value != expected_text:
            raise ValueError(f"Expected reviewed Federal Elections {cycle} results sentinel {sheet_name}!{coordinate}")
    for sheet_spec in spec.sheets:
        sheet_cells = sheets.get(sheet_spec.name, {})
        if not sheet_cells or any(
            sheet_cells.get(cell) is None or sheet_cells[cell].value != text
            for cell, text in sheet_spec.headers.items()
        ):
            raise ValueError(
                f"Federal Elections {cycle} {sheet_spec.office} result columns changed in {sheet_spec.name}"
            )
    for sheet, cells in sheets.items():
        rows = defaultdict(dict)
        for coordinate, cell in cells.items():
            match = re.fullmatch(r"([A-Z]+)([1-9][0-9]*)", coordinate)
            facts = asdict(cell)
            facts["date_value"] = cell.date_value.isoformat() if cell.date_value is not None else None
            rows[int(match[2])][match[1]] = facts
        for number, row in sorted(rows.items()):
            yield {
                "sheet": sheet,
                "row": number,
                "cells": row,
                "source_sha256": sha256,
                "cycle": cycle,
                "reader_version": READER_VERSION,
            }
