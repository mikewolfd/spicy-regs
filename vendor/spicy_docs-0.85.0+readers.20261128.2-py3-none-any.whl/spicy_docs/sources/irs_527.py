"""Streaming IRS Form 8871/8872 political organization (Section 527) bulk reader and bounded HTTP acquirer.

Official specification: ``PolOrgsFileLayout.doc`` from
``https://forms.irs.gov/app/pod/dataDownload/dataLayout``.
Archive download: ``GET https://forms.irs.gov/app/pod/dataDownload/fullData``
(``PolOrgsFullData.zip``, holding ``var/IRS/data/scripts/pofd/download/FullDataFile.txt``).

All pipe-delimited record types (``H``, ``1``, ``2``, ``A``, ``B``, ``D``,
``E``, ``R``, ``F``) are parsed faithfully with literal date and amount
strings preserved. Truncated or malformed rows are refused explicitly rather
than silently dropping fields.
"""

from __future__ import annotations

import hashlib
import io
import re
import stat
import zlib
from collections.abc import Callable, Iterator
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import IO, TYPE_CHECKING, BinaryIO, Literal
from zipfile import ZIP_DEFLATED, ZIP_STORED, BadZipFile, ZipFile, ZipInfo

from spicy_docs.reading.media_types import bare_media_type
from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response
from spicy_docs.transport.captured import CapturedBodyResponse, attach_capture, observed_instant
from spicy_docs.transport.credentials import CredentialRefusedError, failure_reason
from spicy_docs.transport.http import RetryableHTTPStatusError
from spicy_docs.transport.retry import retry_http
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_request_count,
    check_timing,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

DATA_LAYOUT_URL = "https://forms.irs.gov/app/pod/dataDownload/dataLayout"
FULL_DATA_URL = "https://forms.irs.gov/app/pod/dataDownload/fullData"
FULL_DATA_MEMBER = "var/IRS/data/scripts/pofd/download/FullDataFile.txt"
EXPECTED_ARCHIVE_FILENAME = "PolOrgsFullData.zip"
PARSER_VERSION = "irs-527-v1"
DEFAULT_MAX_ARCHIVE_BYTES = 2 * 1024**3
DEFAULT_MAX_MEMBER_BYTES = 16 * 1024**3
DEFAULT_MAX_LINE_BYTES = 64 * 1024
_REFUSAL_BODY_MAX_BYTES = 1024 * 1024
DEFAULT_USER_AGENT = "spicy-docs-irs-527/1.0"
ARCHIVE_MEDIA_TYPES = ("application/zip", "application/x-zip-compressed", "application/octet-stream")
RECORD_TYPES = ("H", "1", "2", "A", "B", "D", "E", "R", "F")

_ISQL_RETURN_TRAILER = "(return status = 0)"
_VALID_FILE_MODIFIERS = frozenset({"A", "B", "C", "D", "F"})
_DIGITS = re.compile(r"[0-9]+")
_DATE8 = re.compile(r"[0-9]{8}")
_TIME4 = re.compile(r"[0-9]{4}")

# Exact column definitions from PolOrgsFileLayout.doc and observed PolOrgsFullData.zip output.
# Tuple: (field_names, expects_trailing_pipe)
_RECORD_LAYOUTS: dict[str, tuple[tuple[str, ...], bool]] = {
    "H": (
        (
            "record_type",
            "transmission_date",
            "transmission_time",
            "file_id_modifier",
        ),
        True,
    ),
    "1": (
        (
            "record_type",
            "form_type",
            "form_id_number",
            "initial_report_indicator",
            "amended_report_indicator",
            "final_report_indicator",
            "ein",
            "organization_name",
            "mailing_address_1",
            "mailing_address_2",
            "mailing_address_city",
            "mailing_address_state",
            "mailing_address_zip_code",
            "mailing_address_zip_ext",
            "email_address",
            "established_date",
            "custodian_name",
            "custodian_address_1",
            "custodian_address_2",
            "custodian_address_city",
            "custodian_address_state",
            "custodian_address_zip_code",
            "custodian_address_zip_ext",
            "contact_person_name",
            "contact_address_1",
            "contact_address_2",
            "contact_address_city",
            "contact_address_state",
            "contact_address_zip_code",
            "contact_address_zip_ext",
            "business_address_1",
            "business_address_2",
            "business_address_city",
            "business_address_state",
            "business_address_zip_code",
            "business_address_zip_ext",
            "exempt_8872_indicator",
            "exempt_state",
            "exempt_990_indicator",
            "purpose",
            "material_change_date",
            "insert_datetime",
            "related_entity_bypass",
            "eain_bypass",
        ),
        False,
    ),
    "D": (
        (
            "record_type",
            "form_id_number",
            "director_id",
            "org_name",
            "ein",
            "entity_name",
            "entity_title",
            "entity_address_1",
            "entity_address_2",
            "entity_address_city",
            "entity_address_state",
            "entity_address_zip_code",
            "entity_address_zip_code_ext",
        ),
        True,
    ),
    "R": (
        (
            "record_type",
            "form_id_number",
            "entity_id",
            "org_name",
            "ein",
            "entity_name",
            "entity_relationship",
            "entity_address_1",
            "entity_address_2",
            "entity_address_city",
            "entity_address_state",
            "entity_address_zip_code",
            "entity_address_zip_ext",
        ),
        True,
    ),
    "E": (
        (
            "record_type",
            "form_id_number",
            "eain_id",
            "election_authority_id_number",
            "state_issued",
        ),
        True,
    ),
    "2": (
        (
            "record_type",
            "form_type",
            "form_id_number",
            "period_begin_date",
            "period_end_date",
            "initial_report_indicator",
            "amended_report_indicator",
            "final_report_indicator",
            "change_of_address_indicator",
            "organization_name",
            "ein",
            "mailing_address_1",
            "mailing_address_2",
            "mailing_address_city",
            "mailing_address_state",
            "mailing_address_zip_code",
            "mailing_address_zip_ext",
            "email_address",
            "org_formation_date",
            "custodian_name",
            "custodian_address_1",
            "custodian_address_2",
            "custodian_address_city",
            "custodian_address_state",
            "custodian_address_zip_code",
            "custodian_address_zip_ext",
            "contact_person_name",
            "contact_address_1",
            "contact_address_2",
            "contact_address_city",
            "contact_address_state",
            "contact_address_zip_code",
            "contact_address_zip_ext",
            "business_address_1",
            "business_address_2",
            "business_address_city",
            "business_address_state",
            "business_address_zip_code",
            "business_address_zip_ext",
            "qtr_indicator",
            "monthly_rpt_month",
            "pre_elect_type",
            "pre_or_post_elect_date",
            "pre_or_post_elect_state",
            "sched_a_ind",
            "total_sched_a",
            "sched_b_ind",
            "total_sched_b",
            "insert_datetime",
        ),
        True,
    ),
    "A": (
        (
            "record_type",
            "form_id_number",
            "sched_a_id",
            "org_name",
            "ein",
            "contributor_name",
            "contributor_address_1",
            "contributor_address_2",
            "contributor_address_city",
            "contributor_address_state",
            "contributor_address_zip_code",
            "contributor_address_zip_ext",
            "contributor_employer",
            "contribution_amount",
            "contributor_occupation",
            "agg_contribution_ytd",
            "contribution_date",
        ),
        True,
    ),
    "B": (
        (
            "record_type",
            "form_id_number",
            "sched_b_id",
            "org_name",
            "ein",
            "recipient_name",
            "recipient_address_1",
            "recipient_address_2",
            "recipient_address_city",
            "recipient_address_state",
            "recipient_address_zip_code",
            "recipient_address_zip_ext",
            "recipient_employer",
            "expenditure_amount",
            "recipient_occupation",
            "expenditure_date",
            "expenditure_purpose",
        ),
        True,
    ),
    "F": (
        (
            "record_type",
            "transmission_date",
            "transmission_time",
            "record_count",
        ),
        True,
    ),
}


class Irs527Error(ValueError):
    """An unresolved IRS 527 acquisition or malformed/truncated record."""


@dataclass(frozen=True, slots=True)
class Irs527Record:
    """One parsed IRS 527 pipe-delimited record with literal field strings."""

    line_number: int
    record_type: str
    fields: dict[str, str]
    raw_line: str


@dataclass(frozen=True, slots=True)
class Irs527MalformedRow:
    """Explicit refusal entry when ``on_malformed='yield_error'`` is requested."""

    line_number: int
    record_type: str | None
    reason: str
    raw_line: str


@dataclass(frozen=True, slots=True)
class Irs527ArchiveDownload:
    """Streaming download metadata for ``PolOrgsFullData.zip`` saved to disk."""

    requested_url: str
    resolved_url: str
    status_code: int
    content_type: str | None
    observed_at: str
    path: Path
    byte_size: int
    sha256: str


def _check_positive_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise Irs527Error(f"{name} must be a positive integer")
    return value


def _check_digits(value: str, *, field_name: str, line_prefix: str) -> None:
    if _DIGITS.fullmatch(value) is None:
        raise Irs527Error(f"{line_prefix} field {field_name!r} must contain ASCII digits")


def parse_record(line: str, *, line_number: int = 1) -> Irs527Record:
    """Parse one pipe-delimited IRS 527 line strictly, preserving literal date/amount strings."""
    if not isinstance(line, str):
        raise Irs527Error("IRS 527 record must be text")
    _check_positive_int(line_number, "line_number")
    clean = line.rstrip("\r\n")
    if "\n" in clean or "\r" in clean:
        raise Irs527Error(f"IRS 527 line {line_number} contains an embedded newline")
    if not clean:
        raise Irs527Error(f"IRS 527 line {line_number} is empty")
    parts = clean.split("|")
    record_type = parts[0]
    layout = _RECORD_LAYOUTS.get(record_type)
    if layout is None:
        raise Irs527Error(f"IRS 527 line {line_number} has unknown record type {record_type!r}")
    columns, trailing_pipe = layout
    prefix = f"IRS 527 line {line_number} ({record_type})"
    expected_parts = len(columns) + (1 if trailing_pipe else 0)
    if len(parts) != expected_parts:
        raise Irs527Error(
            f"{prefix} is malformed or truncated: expected {expected_parts} pipe segments, got {len(parts)}"
        )
    if trailing_pipe and parts[-1] != "":
        raise Irs527Error(f"{prefix} must end with a pipe delimiter")
    values = parts[:-1] if trailing_pipe else parts
    fields = dict(zip(columns, values, strict=True))
    _validate_record_fields(record_type, fields, prefix)
    return Irs527Record(line_number=line_number, record_type=record_type, fields=fields, raw_line=clean)


def _validate_record_fields(record_type: str, fields: dict[str, str], prefix: str) -> None:
    if record_type == "H":
        if _DATE8.fullmatch(fields["transmission_date"]) is None:
            raise Irs527Error(f"{prefix} transmission_date must be YYYYMMDD")
        if _TIME4.fullmatch(fields["transmission_time"]) is None:
            raise Irs527Error(f"{prefix} transmission_time must be HHMM")
        if fields["file_id_modifier"] not in _VALID_FILE_MODIFIERS:
            raise Irs527Error(f"{prefix} has unexpected file_id_modifier {fields['file_id_modifier']!r}")
        return
    if record_type == "F":
        if _DATE8.fullmatch(fields["transmission_date"]) is None:
            raise Irs527Error(f"{prefix} transmission_date must be YYYYMMDD")
        if _TIME4.fullmatch(fields["transmission_time"]) is None:
            raise Irs527Error(f"{prefix} transmission_time must be HHMM")
        _check_digits(fields["record_count"], field_name="record_count", line_prefix=prefix)
        return
    _check_digits(fields["form_id_number"], field_name="form_id_number", line_prefix=prefix)
    if record_type == "1":
        if fields["form_type"] != "8871":
            raise Irs527Error(f"{prefix} expected form_type '8871', got {fields['form_type']!r}")
    elif record_type == "2":
        if fields["form_type"] != "8872":
            raise Irs527Error(f"{prefix} expected form_type '8872', got {fields['form_type']!r}")
    elif record_type == "D":
        _check_digits(fields["director_id"], field_name="director_id", line_prefix=prefix)
    elif record_type == "R":
        _check_digits(fields["entity_id"], field_name="entity_id", line_prefix=prefix)
    elif record_type == "E":
        _check_digits(fields["eain_id"], field_name="eain_id", line_prefix=prefix)
    elif record_type == "A":
        _check_digits(fields["sched_a_id"], field_name="sched_a_id", line_prefix=prefix)
    elif record_type == "B":
        _check_digits(fields["sched_b_id"], field_name="sched_b_id", line_prefix=prefix)


def iter_records(
    stream: IO[bytes],
    *,
    encoding: str = "latin-1",
    max_line_bytes: int = DEFAULT_MAX_LINE_BYTES,
    on_malformed: Literal["raise", "yield_error"] = "raise",
    verify_footer_count: bool = True,
    allow_return_status_trailer: bool = True,
) -> Iterator[Irs527Record | Irs527MalformedRow]:
    """Stream pipe-delimited IRS 527 records from a binary stream line-by-line.

    Requires an opening ``H`` header record and a closing ``F`` footer record.
    In ``on_malformed='raise'`` (default), any malformed or truncated row raises
    ``Irs527Error``. In ``on_malformed='yield_error'``, malformed data rows yield
    ``Irs527MalformedRow`` instead of silently dropping fields.
    """
    _check_positive_int(max_line_bytes, "max_line_bytes")
    if on_malformed not in ("raise", "yield_error"):
        raise Irs527Error("on_malformed must be 'raise' or 'yield_error'")
    if not hasattr(stream, "readline"):
        raise Irs527Error("IRS 527 stream must support readline()")
    saw_header = False
    saw_footer = False
    saw_trailer = False
    data_count = 0
    line_number = 0
    while True:
        raw = stream.readline(max_line_bytes + 1)
        if not raw:
            break
        line_number += 1
        if len(raw) > max_line_bytes and not raw.endswith((b"\n", b"\r")):
            raise Irs527Error(f"IRS 527 line {line_number} exceeds max_line_bytes={max_line_bytes}")
        try:
            text = raw.decode(encoding, errors="strict")
        except UnicodeDecodeError as error:
            raise Irs527Error(f"IRS 527 line {line_number} could not be decoded as {encoding}") from error
        clean = text.rstrip("\r\n")
        if saw_footer:
            if allow_return_status_trailer and not saw_trailer and clean == _ISQL_RETURN_TRAILER:
                saw_trailer = True
                continue
            if not clean:
                continue
            raise Irs527Error(f"IRS 527 line {line_number} appears after the F footer record")
        if not saw_header:
            record = parse_record(clean, line_number=line_number)
            if record.record_type != "H":
                raise Irs527Error("IRS 527 stream must begin with an H header record")
            saw_header = True
            yield record
            continue
        candidate_type = clean.split("|", 1)[0] if clean else None
        try:
            record = parse_record(clean, line_number=line_number)
        except Irs527Error as error:
            if on_malformed == "raise":
                raise
            data_count += 1
            yield Irs527MalformedRow(
                line_number=line_number,
                record_type=candidate_type if candidate_type in _RECORD_LAYOUTS else None,
                reason=str(error),
                raw_line=clean,
            )
            continue
        if record.record_type == "H":
            raise Irs527Error(f"IRS 527 line {line_number} contains an unexpected second H header record")
        if record.record_type == "F":
            saw_footer = True
            if verify_footer_count and int(record.fields["record_count"]) != data_count:
                raise Irs527Error(
                    f"IRS 527 F footer record count {record.fields['record_count']} "
                    f"differs from observed data record count {data_count}"
                )
            yield record
            continue
        data_count += 1
        yield record
    if not saw_header:
        raise Irs527Error("IRS 527 stream is empty")
    if not saw_footer:
        raise Irs527Error("IRS 527 stream ended without an F footer record")


def _open_zip_source(source: Path | str | BinaryIO | bytes):
    if isinstance(source, (str, Path)):
        return open(source, "rb")
    if isinstance(source, (bytes, bytearray)):
        if not source:
            raise Irs527Error("IRS 527 ZIP payload is empty")
        return nullcontext(io.BytesIO(bytes(source)))
    if not hasattr(source, "read") or not hasattr(source, "seekable") or not source.seekable():
        raise Irs527Error("IRS 527 ZIP source must be a path, bytes, or seekable binary stream")
    return nullcontext(source)


def _select_full_data_member(archive: ZipFile, *, member_name: str, max_member_bytes: int) -> ZipInfo:
    infos = archive.infolist()
    if len(infos) > 64:
        raise Irs527Error("IRS 527 ZIP contains too many entries")
    matches: list[ZipInfo] = []
    for info in infos:
        if info.flag_bits & 1:
            raise Irs527Error("IRS 527 ZIP contains an encrypted entry")
        if info.compress_type not in (ZIP_STORED, ZIP_DEFLATED):
            raise Irs527Error("IRS 527 ZIP uses an unsupported compression method")
        mode = stat.S_IFMT(info.external_attr >> 16)
        if mode not in (0, stat.S_IFREG) and not info.is_dir():
            raise Irs527Error("IRS 527 ZIP contains a non-regular entry")
        if "\\" in info.filename or "\x00" in info.filename or ".." in info.filename.split("/"):
            raise Irs527Error("IRS 527 ZIP contains an unsafe entry path")
        if info.is_dir():
            if info.file_size != 0:
                raise Irs527Error("IRS 527 ZIP directory entry contains data")
            continue
        if info.filename != member_name:
            raise Irs527Error(f"IRS 527 ZIP contains unexpected entry {info.filename!r}")
        if info.file_size > max_member_bytes:
            raise Irs527Error("IRS 527 ZIP member exceeds max_member_bytes")
        matches.append(info)
    if len(matches) != 1:
        raise Irs527Error(f"IRS 527 ZIP must contain exactly one {member_name!r} file entry")
    return matches[0]


def iter_archive_records(
    source: Path | str | BinaryIO | bytes,
    *,
    member_name: str = FULL_DATA_MEMBER,
    max_member_bytes: int = DEFAULT_MAX_MEMBER_BYTES,
    encoding: str = "latin-1",
    max_line_bytes: int = DEFAULT_MAX_LINE_BYTES,
    on_malformed: Literal["raise", "yield_error"] = "raise",
    verify_footer_count: bool = True,
    allow_return_status_trailer: bool = True,
) -> Iterator[Irs527Record | Irs527MalformedRow]:
    """Stream IRS 527 records member-by-line from ``PolOrgsFullData.zip`` without loading the archive in memory."""
    _check_positive_int(max_member_bytes, "max_member_bytes")
    if not isinstance(member_name, str) or not member_name:
        raise Irs527Error("member_name must be a non-empty string")
    try:
        with _open_zip_source(source) as stream, ZipFile(stream, "r") as archive:
            member = _select_full_data_member(archive, member_name=member_name, max_member_bytes=max_member_bytes)
            with archive.open(member, "r") as member_stream:
                yield from iter_records(
                    member_stream,
                    encoding=encoding,
                    max_line_bytes=max_line_bytes,
                    on_malformed=on_malformed,
                    verify_footer_count=verify_footer_count,
                    allow_return_status_trailer=allow_return_status_trailer,
                )
                # Drain any trailing bytes (e.g. if trailer skipped or EOF not yet triggered) so ZipExtFile
                # always completes its CRC32 and length verification.
                trailing = member_stream.read(1)
                if trailing:
                    raise Irs527Error("IRS 527 ZIP member contains unread trailing bytes")
    except Irs527Error:
        raise
    except (BadZipFile, zlib.error, EOFError, RuntimeError, OSError) as error:
        raise Irs527Error(f"IRS 527 ZIP could not be read: {error}") from error


class _RetryableIrs527TransportError(ConnectionError):
    """Retryable transport error during streaming download without raw provider text."""


def _refusal_media_type(response: httpx.Response) -> str:
    if response.headers.get("content-encoding", "identity").strip().lower() != "identity":
        return "application/octet-stream"
    return (response.headers.get("content-type") or "application/octet-stream").split(";", 1)[0].strip() or (
        "application/octet-stream"
    )


def _stated_content_length(response: httpx.Response) -> int | None:
    stated = response.headers.get("content-length")
    return int(stated) if stated is not None and stated.isascii() and stated.isdigit() else None


def _read_bounded_refusal(
    response: httpx.Response,
    *,
    max_bytes: int,
    default_reason: str | None,
) -> tuple[bytes | None, str, str | None, int | None, int | None]:
    """Read at most ``max_bytes`` of a refused/non-200 response without buffering bulk payloads."""
    import httpx

    media_type = _refusal_media_type(response)
    stated = _stated_content_length(response)
    if stated is not None and stated > max_bytes:
        return None, media_type, "response-byte-limit", None, stated
    body = bytearray()
    try:
        for chunk in response.iter_raw(chunk_size=min(max_bytes + 1, 64 * 1024)):
            observed = len(body) + len(chunk)
            if observed > max_bytes:
                return None, media_type, "response-byte-limit", observed, stated
            body.extend(chunk)
    except (httpx.RequestError, CredentialRefusedError):
        return None, media_type, "response-unavailable", len(body), stated
    return bytes(body), media_type, default_reason, len(body), stated


class Irs527Acquirer(SourceAcquirer):
    """Bounded GET-only acquirer for IRS 527 ``PolOrgsFullData.zip``.

    Never sends HTTP ``HEAD`` (which IRS redirects to 404). Always declares an
    explicit ``User-Agent``. Supports both streaming download to disk and bounded
    in-memory capture for tests/small fixtures.
    """

    def __init__(
        self,
        *,
        user_agent: str = DEFAULT_USER_AGENT,
        max_requests: int = 4,
        max_bytes: int = DEFAULT_MAX_ARCHIVE_BYTES,
        timeout_seconds: float = 300,
        min_request_interval_seconds: float = 0.5,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        check_request_count(max_requests)
        check_byte_bound(max_bytes, "max_bytes", DEFAULT_MAX_ARCHIVE_BYTES)
        check_timing(timeout_seconds, min_request_interval_seconds)
        if not isinstance(user_agent, str) or not user_agent.strip() or "\r" in user_agent or "\n" in user_agent:
            raise Irs527Error("IRS 527 user_agent must be a single non-empty header value")
        self.max_bytes = max_bytes
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=timeout_seconds,
            min_request_interval_seconds=min_request_interval_seconds,
            user_agent=user_agent.strip(),
            label="IRS 527",
            error_type=Irs527Error,
            context_key="irs_527_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def acquire_full_data(self, *, max_bytes: int | None = None) -> CapturedBodyResponse:
        """Capture ``PolOrgsFullData.zip`` via bounded GET into memory (for small fixtures or bounded runs)."""
        limit = self.max_bytes if max_bytes is None else max_bytes
        check_byte_bound(limit, "max_bytes", self.max_bytes)

        def parse(capture: CapturedBodyResponse, _limit: int) -> CapturedBodyResponse:
            if capture.status_code != 200:
                raise Irs527Error(f"IRS 527 source answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                FULL_DATA_URL,
                error_type=Irs527Error,
                message="IRS 527 final URL differs from fullData endpoint",
            )
            if capture.body[:4] != b"PK\x03\x04":
                raise Irs527Error("IRS 527 response does not start with a ZIP local file header")
            return capture

        _, capture = self.capture_validated(
            FULL_DATA_URL,
            media_types=ARCHIVE_MEDIA_TYPES,
            parse=parse,
            max_bytes=limit,
            unavailable=lambda resp: Irs527Error(f"IRS 527 unavailable (HTTP {resp.status_code})"),
            context={"url": FULL_DATA_URL, "method": "GET"},
            method="GET",
            max_attempts=1,
        )
        return capture

    def download_full_data(
        self,
        destination: Path,
        *,
        max_bytes: int | None = None,
        max_attempts: int | None = None,
    ) -> Irs527ArchiveDownload:
        """Stream ``PolOrgsFullData.zip`` via GET directly to ``destination`` without buffering in memory."""
        import httpx

        limit = self.max_bytes if max_bytes is None else max_bytes
        check_byte_bound(limit, "max_bytes", self.max_bytes)
        if max_attempts is not None:
            check_request_count(max_attempts, "max_attempts")
        refusal_limit = min(limit, _REFUSAL_BODY_MAX_BYTES)
        target = Path(destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp_path = target.with_name(f".{target.name}.part")
        self._http.reset_budget()
        remaining = self.remaining_requests
        if remaining <= 0:
            budget_error = Irs527Error("Source acquisition exhausted its total request budget")
            attach_refused_response(
                budget_error,
                RefusedResponse(
                    FULL_DATA_URL,
                    "before-request",
                    None,
                    "application/octet-stream",
                    "request-budget-exhausted",
                ),
            )
            budget_error.__dict__[self.context_key] = {
                "url": FULL_DATA_URL,
                "method": "GET",
                "requestCount": self._http.request_count,
            }
            raise budget_error
        attempts = remaining if max_attempts is None else min(remaining, max_attempts)

        def _attach_failure_evidence(
            error: Exception,
            *,
            response: httpx.Response | None,
            status: int,
            resolved_url: str,
            content_type: str | None,
            observed_at: str,
            stage: str,
            default_reason: str | None,
        ) -> None:
            if response is not None:
                body_bytes, media_type, reason, observed_size, stated_size = _read_bounded_refusal(
                    response, max_bytes=refusal_limit, default_reason=default_reason
                )
            else:
                body_bytes = None
                media_type = (content_type or "application/octet-stream").split(";", 1)[0].strip()
                reason = default_reason or "response-unavailable"
                observed_size = None
                stated_size = None
            attach_refused_response(
                error,
                RefusedResponse(
                    FULL_DATA_URL,
                    stage,
                    body_bytes,
                    media_type,
                    reason,
                    observed_size,
                    stated_size,
                ),
            )
            attach_capture(
                error,
                CapturedBodyResponse(
                    requested_url=FULL_DATA_URL,
                    resolved_url=resolved_url,
                    status_code=status,
                    content_type=content_type or media_type,
                    observed_at=observed_at,
                    body=body_bytes if body_bytes is not None else b"",
                ),
            )

        def attempt() -> Irs527ArchiveDownload:
            if temp_path.exists():
                temp_path.unlink()
            digest = hashlib.sha256()
            observed = 0
            status = 0
            resolved_url = FULL_DATA_URL
            content_type: str | None = None
            observed_at = observed_instant(self._clock)
            try:
                with self._http.open_stream("GET", FULL_DATA_URL, headers={"Accept-Encoding": "identity"}) as response:
                    status = response.status_code
                    resolved_url = str(response.url)
                    content_type = response.headers.get("content-type")
                    observed_at = (
                        response.extensions["spicy_docs_retained_observed_at"]
                        if "spicy_docs_retained_observed_at" in response.extensions
                        else observed_instant(self._clock)
                    )
                    if status in (401, 403):
                        body_bytes, media_type, reason, observed_size, stated_size = _read_bounded_refusal(
                            response, max_bytes=refusal_limit, default_reason="access-refused"
                        )
                        error = CredentialRefusedError(f"Body source answered HTTP {status}; stopping acquisition")
                        attach_refused_response(
                            error,
                            RefusedResponse(
                                FULL_DATA_URL,
                                "transport",
                                body_bytes,
                                media_type,
                                reason,
                                observed_size,
                                stated_size,
                            ),
                        )
                        raise error
                    if status == 429 or status >= 500:
                        retry_error = RetryableHTTPStatusError(
                            f"Body source answered retryable HTTP {status}",
                            request=response.request,
                            response=response,
                        )
                        _attach_failure_evidence(
                            retry_error,
                            response=response,
                            status=status,
                            resolved_url=resolved_url,
                            content_type=content_type,
                            observed_at=observed_at,
                            stage="transport",
                            default_reason=f"http-{status}",
                        )
                        raise retry_error
                    validation_failure: str | None = None
                    if status != 200:
                        validation_failure = f"IRS 527 source answered HTTP {status}"
                    elif resolved_url != FULL_DATA_URL:
                        validation_failure = "IRS 527 final URL differs from fullData endpoint"
                    elif response.headers.get("content-encoding", "identity").strip().lower() != "identity":
                        validation_failure = "IRS 527 response uses unsupported content encoding"
                    elif bare_media_type(content_type) not in ARCHIVE_MEDIA_TYPES:
                        validation_failure = "IRS 527 source Content-Type differs from ZIP"
                    if validation_failure is not None:
                        error = Irs527Error(validation_failure)
                        _attach_failure_evidence(
                            error,
                            response=response,
                            status=status,
                            resolved_url=resolved_url,
                            content_type=content_type,
                            observed_at=observed_at,
                            stage="source-validation",
                            default_reason=None,
                        )
                        raise error
                    stated = response.headers.get("content-length")
                    if stated is not None:
                        if not stated.isascii() or not stated.isdigit():
                            raise Irs527Error("IRS 527 response Content-Length is invalid")
                        if int(stated) > limit:
                            oversize_error = Irs527Error("IRS 527 response exceeds its byte bound")
                            attach_refused_response(
                                oversize_error,
                                RefusedResponse(
                                    FULL_DATA_URL,
                                    "transport",
                                    None,
                                    _refusal_media_type(response),
                                    "response-byte-limit",
                                    stated_byte_size=int(stated),
                                ),
                            )
                            raise oversize_error
                    first_prefix = bytearray()
                    with open(temp_path, "wb") as out:
                        for chunk in response.iter_raw(chunk_size=64 * 1024):
                            observed += len(chunk)
                            if observed > limit:
                                oversize_error = Irs527Error("IRS 527 response exceeds its byte bound")
                                attach_refused_response(
                                    oversize_error,
                                    RefusedResponse(
                                        FULL_DATA_URL,
                                        "transport",
                                        None,
                                        _refusal_media_type(response),
                                        "response-byte-limit",
                                        observed,
                                        int(stated) if stated is not None else None,
                                    ),
                                )
                                raise oversize_error
                            if len(first_prefix) < 4:
                                first_prefix.extend(chunk[: 4 - len(first_prefix)])
                                if len(first_prefix) == 4 and bytes(first_prefix) != b"PK\x03\x04":
                                    prefix_error = Irs527Error(
                                        "IRS 527 response does not start with a ZIP local file header"
                                    )
                                    attach_refused_response(
                                        prefix_error,
                                        RefusedResponse(
                                            FULL_DATA_URL,
                                            "source-validation",
                                            bytes(first_prefix),
                                            _refusal_media_type(response),
                                            observed_byte_size=len(first_prefix),
                                        ),
                                    )
                                    raise prefix_error
                            digest.update(chunk)
                            out.write(chunk)
                    if len(first_prefix) < 4 or bytes(first_prefix) != b"PK\x03\x04":
                        prefix_error = Irs527Error("IRS 527 response does not start with a ZIP local file header")
                        attach_refused_response(
                            prefix_error,
                            RefusedResponse(
                                FULL_DATA_URL,
                                "source-validation",
                                bytes(first_prefix),
                                _refusal_media_type(response),
                                observed_byte_size=len(first_prefix),
                            ),
                        )
                        raise prefix_error
                    if stated is not None and int(stated) != observed:
                        raise Irs527Error("IRS 527 response size differs from Content-Length")
                temp_path.replace(target)
            except httpx.RequestError as request_error:
                if temp_path.exists():
                    temp_path.unlink()
                transport_error = _RetryableIrs527TransportError(
                    f"IRS 527 transport failed while downloading archive: {failure_reason(request_error)}"
                )
                attach_refused_response(
                    transport_error,
                    RefusedResponse(
                        FULL_DATA_URL,
                        "transport",
                        None,
                        (content_type or "application/octet-stream").split(";", 1)[0].strip(),
                        "response-unavailable",
                        observed if observed > 0 else None,
                    ),
                )
                raise transport_error from None
            except Exception as error:
                if temp_path.exists():
                    temp_path.unlink()
                if isinstance(error, Irs527Error) and "refused_response" not in error.__dict__:
                    _attach_failure_evidence(
                        error,
                        response=None,
                        status=status,
                        resolved_url=resolved_url,
                        content_type=content_type,
                        observed_at=observed_at,
                        stage="source-validation",
                        default_reason="response-unavailable",
                    )
                elif isinstance(error, Irs527Error) and "capture" not in error.__dict__:
                    refused = error.__dict__.get("refused_response")
                    attach_capture(
                        error,
                        CapturedBodyResponse(
                            requested_url=FULL_DATA_URL,
                            resolved_url=resolved_url,
                            status_code=status,
                            content_type=content_type or "application/octet-stream",
                            observed_at=observed_at,
                            body=refused.response_bytes
                            if isinstance(refused, RefusedResponse) and refused.response_bytes is not None
                            else b"",
                        ),
                    )
                raise
            return Irs527ArchiveDownload(
                requested_url=FULL_DATA_URL,
                resolved_url=resolved_url,
                status_code=status,
                content_type=content_type,
                observed_at=observed_at,
                path=target,
                byte_size=observed,
                sha256="sha256:" + digest.hexdigest(),
            )

        try:
            return retry_http(
                attempt,
                retryable=(_RetryableIrs527TransportError, RetryableHTTPStatusError),
                max_attempts=attempts,
            )
        except RetryableHTTPStatusError as error:
            wrapped = Irs527Error(f"IRS 527 source answered HTTP {error.response.status_code}")
            for key in ("refused_response", "capture"):
                if key in error.__dict__:
                    wrapped.__dict__[key] = error.__dict__[key]
            wrapped.__dict__[self.context_key] = {
                "url": FULL_DATA_URL,
                "method": "GET",
                "requestCount": self._http.request_count,
            }
            raise wrapped from error
        except _RetryableIrs527TransportError as error:
            wrapped = Irs527Error(str(error))
            if "refused_response" in error.__dict__:
                wrapped.__dict__["refused_response"] = error.__dict__["refused_response"]
            wrapped.__dict__[self.context_key] = {
                "url": FULL_DATA_URL,
                "method": "GET",
                "requestCount": self._http.request_count,
            }
            raise wrapped from error
        except Exception as error:
            error.__dict__[self.context_key] = {
                "url": FULL_DATA_URL,
                "method": "GET",
                "requestCount": self._http.request_count,
            }
            raise


__all__ = [
    "ARCHIVE_MEDIA_TYPES",
    "DATA_LAYOUT_URL",
    "DEFAULT_MAX_ARCHIVE_BYTES",
    "DEFAULT_MAX_LINE_BYTES",
    "DEFAULT_MAX_MEMBER_BYTES",
    "DEFAULT_USER_AGENT",
    "EXPECTED_ARCHIVE_FILENAME",
    "FULL_DATA_MEMBER",
    "FULL_DATA_URL",
    "PARSER_VERSION",
    "RECORD_TYPES",
    "Irs527Acquirer",
    "Irs527ArchiveDownload",
    "Irs527Error",
    "Irs527MalformedRow",
    "Irs527Record",
    "iter_archive_records",
    "iter_records",
    "parse_record",
]
