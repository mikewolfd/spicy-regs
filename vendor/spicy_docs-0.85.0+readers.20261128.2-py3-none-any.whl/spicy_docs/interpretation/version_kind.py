"""Classify a bill version's ``version_code`` slug into a document kind.

Ported from BillTrax ``src/lib/version-kind.ts`` and synchronized exhaustively
with ``sources.congress.bill_versions.VERSION_CODES``, the sealed publisher-fact
vocabulary, this states the distinction the vocabulary does not: a slug like
``engrossed-amendment-senate`` (or ``eas`` / ``eas2``) names an edit-instruction
document, not full bill text, and diffing it against full text produces the
"+0 added / -N removed" trap.

Publisher document kind is decoupled from document length: valid short bills
(e.g. a 1-section naming bill) remain ``full_text``. Previously a 20-section /
10 KB ``full_text_slug_thin`` heuristic demoted most real legislative text to
``kind_uncertain``; now ``kind_uncertain`` (``full_text_slug_empty_body``) fires
only when a measured body yielded zero sections or zero bytes, keeping metadata-
only reclassification (``body_bytes=None`` with ``section_count >= 1``)
deterministic.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from spicy_docs.sources.congress.bill_versions import (
    VERSION_CODES,
    VERSION_CODES_BY_SLUG,
    version_slug,
)

VersionKind = Literal["full_text", "procedural_amendments", "procedural_summary", "kind_uncertain", "unknown"]

#: Edit-instruction and sponsorship-amendment documents, not full bill text.
PROCEDURAL_AMENDMENTS_SLUGS: frozenset[str] = frozenset(
    {
        # Sealed long slugs and display-name variants
        "engrossed-amendment-senate",
        "engrossed-amendment-house",
        "amendment-senate",
        "amendment-house",
        "amendment-engrossed-senate",
        "amendment-engrossed-house",
        "amendment-senate-house",
        "amendment-ordered-to-be-printed-senate",
        "additional-sponsors-house",
        "additional-sponsors-senate",
        "re-engrossed-amendment-house",
        "re-engrossed-amendment-senate",
        "failed-amendment-senate",
        "failed-amendment-house",
        # GovInfo short codes and numbered reprints from VERSION_CODES
        "eas",
        "eah",
        "eas2",
        "as",
        "ash",
        "sas",
        "reah",
        "res",
        "fah",
    }
)

#: Brief procedural documents, not full bill text.
PROCEDURAL_SUMMARY_SLUGS: frozenset[str] = frozenset(
    {
        # Sealed long slugs and display-name variants
        "statement-of-substance",
        "held-at-desk-senate",
        "held-at-desk-house",
        "previously-passed-senate",
        "sponsor-change",
        # GovInfo short codes from VERSION_CODES
        "hds",
        "hdh",
        "sc",
    }
)

#: Slugs whose documents carry complete bill text.
FULL_TEXT_SLUGS: frozenset[str] = frozenset(
    {
        # Sealed long slugs (VERSION_CODES) and display-name variants
        "introduced-in-house",
        "introduced-in-senate",
        "engrossed-in-house",
        "engrossed-in-senate",
        "engrossed-in-house-substitute",
        "enrolled-bill",
        "re-enrolled-bill",
        "printed-as-passed",
        "public-law",
        "private-law",
        # Committee referral / receipt / reporting versions (full text accompanies the action)
        "referred-to-senate",
        "referred-to-house",
        "referred-in-house",
        "referred-in-senate",
        "received-in-senate",
        "received-in-house",
        "referred-to-committee",
        "referred-to-committee-house",
        "referred-to-committee-senate",
        "referral-instructions-house",
        "referral-instructions-senate",
        "referred-with-amendments-house",
        "referred-with-amendments-senate",
        "reported-in-house",
        "reported-in-senate",
        "reported-to-senate",
        "reported-by-committee",
        # Calendar placement and printings
        "placed-on-calendar-senate",
        "placed-on-calendar-house",
        "ordered-to-be-printed-house",
        "ordered-to-be-printed-senate",
        "ordered-to-be-printed-with-house-amendment",
        "public-print",
        "previous-action-vitiated",
        # Passage and floor disposition variants
        "passed-as-proposed",
        "passed-as-voted",
        "engrossed-and-deemed-passed-by-house",
        "considered-and-passed-house",
        "considered-and-passed-senate",
        "committee-discharge-house",
        "committee-discharged-house",
        "committee-discharge-senate",
        "committee-discharged-senate",
        "failed-in-house",
        "failed-in-senate",
        "failed-passage-house",
        "failed-passage-senate",
        "indefinitely-postponed-house",
        "indefinitely-postponed-senate",
        "laid-on-table-in-house",
        "laid-on-table-in-senate",
        # Reference / administrative
        "reference-change-senate",
        "reference-change-house",
        "returned-to-the-house-by-unanimous-consent",
        "returned-to-the-senate-by-unanimous-consent",
        # Other known full-text milestones
        "original-in-senate",
        "original-in-house",
        "agreed-to-senate",
        "agreed-to-house",
        # GovInfo short codes and numbered reprints from VERSION_CODES
        "ih",
        "is",
        "eh",
        "es",
        "enr",
        "pcs",
        "pch",
        "rds",
        "rfh",
        "rh",
        "rs",
        "rfs",
        "ats",
        "cps",
        "rcs",
        "rhuc",
        "cdh",
        "eh1s",
        "lth",
        "rfs2",
        "ris",
        "rdh",
        "rch",
        "rth",
        "rts",
        "rih",
        "rah",
        "ras",
        "cds",
        "oph",
        "ops",
        "pp",
        "pav",
        "eph",
        "cph",
        "ath",
        "fph",
        "fps",
        "iph",
        "ips",
        "lts",
        "pwah",
        "renr",
        "pap",
    }
)

if (
    (PROCEDURAL_AMENDMENTS_SLUGS & PROCEDURAL_SUMMARY_SLUGS)
    or (PROCEDURAL_AMENDMENTS_SLUGS & FULL_TEXT_SLUGS)
    or (PROCEDURAL_SUMMARY_SLUGS & FULL_TEXT_SLUGS)
):
    raise AssertionError("version_kind slug sets must be pairwise disjoint")

_CLASSIFIED_SLUGS = PROCEDURAL_AMENDMENTS_SLUGS | PROCEDURAL_SUMMARY_SLUGS | FULL_TEXT_SLUGS
_UNCLASSIFIED_VOCABULARY = {entry.slug for entry in VERSION_CODES} - _CLASSIFIED_SLUGS
if _UNCLASSIFIED_VOCABULARY:
    raise AssertionError(
        f"VERSION_CODES entries missing from version_kind classification: {sorted(_UNCLASSIFIED_VOCABULARY)}"
    )

#: Pattern matching a numbered GovInfo reprint suffix (e.g. ``rh2``, ``eas12``, ``eh2s``)
#: derived from a base short code in ``VERSION_CODES_BY_SLUG``.
_REPRINT_SUFFIX = re.compile(r"^([a-z]+)(?:[2-9]|[1-9][0-9]+|[1-9][0-9]*s)$")

VERSION_KIND_LABELS: dict[VersionKind, str] = {
    "full_text": "Full bill text",
    "procedural_amendments": "Amendment document — not full bill text",
    "procedural_summary": "Procedural summary — not full bill text",
    "kind_uncertain": "Full bill text (empty body — verify)",
    "unknown": "Unknown format",
}

#: Inline hint for a non-full-text kind, shown in a version picker.
VERSION_KIND_WARNINGS: dict[VersionKind, str] = {
    "procedural_amendments": "amendment instructions, not bill text",
    "procedural_summary": "procedural summary, not bill text",
    "kind_uncertain": "empty or unparsed body — may be incomplete",
}

#: Unknown-slug fallback threshold: only applies to slugs absent from the known sets.
_UNKNOWN_SLUG_FULL_TEXT_BYTES = 10_000


@dataclass(frozen=True, slots=True)
class VersionKindFinding:
    """One classification, naming the rule that fired and the size evidence it was given.

    ``rule`` is one of ``procedural_amendments_slug``,
    ``procedural_summary_slug``, ``full_text_slug``,
    ``full_text_slug_empty_body`` (downgraded to ``kind_uncertain`` when a
    measured body yielded zero sections or zero bytes),
    ``amendment_substring`` (an unlisted slug this repo's own heuristic caught),
    ``size_heuristic`` or ``unknown``.
    """

    kind: VersionKind
    rule: str
    section_count: int | None
    body_bytes: int | None


def _resolve_slug(version_code: str | None) -> str:
    """Normalize a stored code or publisher display name into its lookup slug.

    Resolves measured display names through ``version_slug`` (for example
    ``"Received in Senate"`` -> ``"referred-to-senate"``, ``"Reported to Senate"``
    -> ``"reported-in-senate"``), and maps unlisted numbered reprints such as
    ``rh2`` or ``eas12`` back to their base GovInfo short code when that base
    exists in ``VERSION_CODES_BY_SLUG``.
    """
    if not version_code:
        return ""
    slug = version_slug(version_code)
    if slug in _CLASSIFIED_SLUGS:
        return slug
    match = _REPRINT_SUFFIX.fullmatch(slug)
    if match is not None:
        base = match.group(1)
        entry = VERSION_CODES_BY_SLUG.get(base)
        if entry is not None and entry.govinfo_suffix == base:
            return base
    return slug


def version_kind_finding(
    version_code: str | None,
    *,
    section_count: int | None = None,
    body_bytes: int | None = None,
) -> VersionKindFinding:
    """Classify one bill version by its ``version_code`` slug and optional body
    measurements, naming the rule that decided it.

    ``version_code`` is normalized through ``version_slug`` defensively -- a
    caller that passes the display name or a numbered reprint suffix instead of
    a canonical long slug still classifies deterministically.

    For known full-text slugs, valid short bills (even 1 section) stay
    ``full_text``. ``kind_uncertain`` (``full_text_slug_empty_body``) is emitted
    only when an explicit measurement establishes ``section_count == 0`` or
    ``body_bytes == 0``; when ``body_bytes`` is ``None`` (such as held-row
    metadata reclassification with ``section_count >= 1``), the printing
    classifies deterministically as ``full_text``.
    """
    slug = _resolve_slug(version_code)

    def _finding(kind: VersionKind, rule: str) -> VersionKindFinding:
        return VersionKindFinding(kind, rule, section_count, body_bytes)

    if slug in PROCEDURAL_AMENDMENTS_SLUGS:
        return _finding("procedural_amendments", "procedural_amendments_slug")
    if slug in PROCEDURAL_SUMMARY_SLUGS:
        return _finding("procedural_summary", "procedural_summary_slug")

    if slug in FULL_TEXT_SLUGS:
        empty_sections = section_count is not None and section_count <= 0
        empty_body = body_bytes is not None and body_bytes <= 0
        if empty_sections or empty_body:
            return _finding("kind_uncertain", "full_text_slug_empty_body")
        return _finding("full_text", "full_text_slug")

    # An unlisted slug containing "amendment" is almost certainly procedural
    # (catches future variant names the vocabulary has not named yet).
    if "amendment" in slug:
        return _finding("procedural_amendments", "amendment_substring")

    # Unknown slug -- infer from size if available.
    if body_bytes is not None and body_bytes >= _UNKNOWN_SLUG_FULL_TEXT_BYTES:
        return _finding("full_text", "size_heuristic")
    return _finding("unknown", "unknown")


def version_kind(
    version_code: str | None,
    *,
    section_count: int | None = None,
    body_bytes: int | None = None,
) -> VersionKind:
    """The kind alone; see `version_kind_finding` for the rule that produced it."""
    return version_kind_finding(version_code, section_count=section_count, body_bytes=body_bytes).kind


__all__ = [
    "FULL_TEXT_SLUGS",
    "PROCEDURAL_AMENDMENTS_SLUGS",
    "PROCEDURAL_SUMMARY_SLUGS",
    "VERSION_KIND_LABELS",
    "VERSION_KIND_WARNINGS",
    "VersionKind",
    "VersionKindFinding",
    "version_kind",
    "version_kind_finding",
]
