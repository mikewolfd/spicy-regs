"""Stdlib-only character-offset text span shape and rendition vocabulary."""

from __future__ import annotations

from dataclasses import dataclass

#: Character-offset unit for every rendition span: 0-based half-open Unicode code points in ``text``.
TEXT_OFFSET_UNIT = "unicode_code_points"

#: Named readable-text renditions produced by ``spicy_docs.reading.xml_text.read_text``.
USLM_RENDITION = "uslm-block-boundaries/1"
ECFR_RENDITION = "ecfr-block-boundaries/1"
BILL_DTD_RENDITION = "bill-dtd-block-boundaries/1"

#: Valid named readable-text renditions whose code-point offsets a native reference row may carry.
TEXT_RENDITIONS = frozenset({USLM_RENDITION, ECFR_RENDITION, BILL_DTD_RENDITION})


@dataclass(frozen=True, slots=True)
class XmlTextSpan:
    """One XML element's exact span in a named readable-text rendition.

    ``start`` and ``end`` are 0-based half-open ``unicode_code_points`` indices into the rendition
    text whose digest is ``rendition_sha256``, so ``rendition_text[start:end] == text``. Empty
    elements (``source_start == source_end``) carry ``start = end = text = None``.
    """

    rendition: str
    offset_unit: str
    rendition_sha256: str
    start: int | None
    end: int | None
    text: str | None
    source_start: int
    source_end: int


__all__ = [
    "BILL_DTD_RENDITION",
    "ECFR_RENDITION",
    "TEXT_OFFSET_UNIT",
    "TEXT_RENDITIONS",
    "USLM_RENDITION",
    "XmlTextSpan",
]
