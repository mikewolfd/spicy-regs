"""Federal Register source semantics for the source-native release.

This module classifies source fields and derives source-owned records.  It does
not build the common artifact container; :mod:`spicy_docs.source_native`
delegates that work to ``rulespec_artifacts``.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable, Generator, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import date, timedelta
from functools import cache
from types import MappingProxyType
from typing import Any, Final, cast
from urllib.parse import parse_qs, urlencode, urlparse

from rulespec_artifacts import FramedSection, canonical_json_bytes, framed_section_digest, schema_bundle_digest

from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response

SOURCE_SYSTEM_ID: Final = "https://www.federalregister.gov/api/v1"
SOURCE_SYSTEM_VERSION: Final = "v1"
MAX_RESULTS_PER_PAGE: Final = 1_000
MAX_PAGE_BYTES: Final = 24 * 1024 * 1024
MAX_RECONCILIATION_TRAVERSALS: Final = 3
RESULT_CAP: Final = 10_000
MAX_WINDOW_DAYS: Final = 90
MAX_PAGES_PER_TRAVERSAL: Final = 10_000
FEDERAL_REGISTER_DOCUMENTS_URL: Final = f"{SOURCE_SYSTEM_ID}/documents.json"
SCOPE_ID: Final = "federal-register-documents"
SCHEMA_NAME: Final = "federal-register-document"
#: 1.2 (2026-10-03): the request adds ``action``, ``correction_of``, ``corrections``, ``regulations_dot_gov_info`` and
#: ``significant`` (:data:`DOCUMENT_FIELDS`), so the records a release seals carry five fields 1.1 never admitted.
SCHEMA_VERSION: Final = "1.2"
SCHEMA_PATH: Final = "sources/federal-register-document-1.2.schema.json"

API_RESPONSE_FIELDS: Final = frozenset(
    {
        "count",
        "description",
        "next_page_url",
        "previous_page_url",
        "results",
        "total_pages",
    }
)
DOCUMENT_FIELDS: Final = frozenset(
    {
        "abstract",
        "action",
        "agencies",
        "agency_names",
        "body_html_url",
        "cfr_references",
        "comments_close_on",
        "correction_of",
        "corrections",
        "docket_ids",
        "document_number",
        "effective_on",
        "end_page",
        "executive_order_number",
        "full_text_xml_url",
        "html_url",
        "pdf_url",
        "publication_date",
        "regulation_id_numbers",
        "regulations_dot_gov_info",
        "signing_date",
        "significant",
        "start_page",
        "subtype",
        "title",
        "topics",
        "type",
        "volume",
    }
)
#: Every other document field the API documents (``DocumentField`` in ``/api/v1/documentation.json``), and why it is
#: not requested. Requested and excluded together are the documented list, which a test holds them to: a field the
#: publisher adds is a decision here, not a silent drop (round 6, 2026-10-03).
EXCLUDED_DOCUMENT_FIELDS: Final = MappingProxyType(
    {
        "amendatory_instructions": "The document's amendatory instructions, which its body states.",
        "cfr_topics": "`topics` grouped by affected CFR part; `topics` and `cfr_references` are requested.",
        "citation": "`volume` FR `start_page`, built from two requested fields.",
        "comment_url": "A link to regulations.gov's comment form; `regulations_dot_gov_info` names the document.",
        "dates": "The DATES caption as prose, which the body states.",
        "disposition_notes": "A presidential document's disposition prose; not requested yet.",
        "docket_id": "The first of `docket_ids`, which is requested whole.",
        "dockets": (
            "Regulations.gov's own docket and document records as the Register caches them (live counts, "
            "update instants); the Regulations.gov readers read those from regulations.gov."
        ),
        "excerpts": "A search snippet the API builds, not a field of the document.",
        "executive_order_notes": "Prose notes on an executive order's later history; not requested yet.",
        "explanation": "Documented but absent from four documents read with every documented field (2026-10-03).",
        "images": "Images inside the body; the body renditions carry them.",
        "images_metadata": "Metadata of the images inside the body.",
        "json_url": "This record's own API address, built from its number and date.",
        "mods_url": "GovInfo's MODS address; the GovInfo readers resolve MODS themselves.",
        "not_received_for_publication": "A presidential-document flag; not requested yet.",
        "page_length": "The page count, from `start_page` and `end_page`.",
        "page_views": "A live page-view counter, not a fact about the document.",
        "president": "The president in office, which the Register derives from the document's dates.",
        "presidential_document_number": "A presidential document's own number; not requested yet.",
        "proclamation_number": "A proclamation's number; not requested yet.",
        "public_inspection_pdf_url": "The pre-publication Public Inspection copy, not the published document.",
        "raw_text_url": "A plain-text rendition; the HTML and XML bodies are requested.",
        "regulation_id_number_info": "The Unified Agenda's record for each RIN, which the Unified Agenda reader reads.",
        "regulations_dot_gov_url": "NULL on four documents read 2026-10-03; `regulations_dot_gov_info` states the link.",
        "related_documents": "The Register's grouping of documents under one docket label; not requested yet.",
        "toc_doc": "The table-of-contents line; `title` is requested.",
        "toc_subject": "The table-of-contents subject heading.",
    }
)
_RIN: Final = re.compile(r"^[0-9]{4}-[A-Z][A-Z0-9]{3}$")
_ASCII_ID: Final = re.compile(r"^[A-Za-z0-9._-]+$")
_AGENCY_FIELDS: Final = frozenset({"id", "json_url", "name", "parent_id", "raw_name", "slug", "url"})
_CFR_REFERENCE_FIELDS: Final = frozenset({"chapter", "citation_url", "part", "title"})
_TEXT_FIELDS: Final = frozenset(
    {
        "abstract",
        "action",
        "body_html_url",
        "comments_close_on",
        "correction_of",
        "effective_on",
        "executive_order_number",
        "full_text_xml_url",
        "html_url",
        "pdf_url",
        "signing_date",
        "subtype",
        "title",
        "type",
    }
)
_INTEGER_FIELDS: Final = frozenset({"end_page", "start_page", "volume"})
_TEXT_ARRAY_FIELDS: Final = frozenset({"agency_names", "corrections", "docket_ids", "topics"})
#: ``regulations_dot_gov_info``: the Register's own statement of the regulations.gov docket and document it matched
#: the document to, with regulations.gov's comment count as of the Register's last check. A closed object: each key the
#: API was seen to state (all 2026-09 and sampled 1998-2024 windows, round 6 scout C) with its JSON type. It comes in
#: several shapes -- ``{}`` (never checked), the check instant alone (checked, nothing found), a document and count but
#: no docket, a docket but no document, and all of it -- so every key is optional and nullable.
_REGULATIONS_DOT_GOV_TEXT: Final = frozenset(
    {
        "agency_id",
        "checked_regulationsdotgov_at",
        "comments_url",
        "docket_id",
        "document_id",
        "regulation_id_number",
        "title",
    }
)
_REGULATIONS_DOT_GOV_INTEGER: Final = frozenset({"comments_count", "supporting_documents_count"})
_REGULATIONS_DOT_GOV_OBJECTS: Final = MappingProxyType(
    {"regulatory_plan": frozenset({"html_url", "title"}), "supporting_documents": frozenset({"document_id", "title"})}
)
REGULATIONS_DOT_GOV_INFO_FIELDS: Final = (
    _REGULATIONS_DOT_GOV_TEXT | _REGULATIONS_DOT_GOV_INTEGER | frozenset(_REGULATIONS_DOT_GOV_OBJECTS)
)
_RENDITION_FIELDS: Final = (
    ("body-html", "body_html_url", "text/html"),
    ("body-xml", "full_text_xml_url", "application/xml"),
    ("html", "html_url", "text/html"),
    ("pdf", "pdf_url", "application/pdf"),
)


class FederalRegisterSourceError(ValueError):
    """The carried Federal Register evidence is not safely publishable."""


FederalRegisterFetch = Callable[[str], bytes]


@dataclass(frozen=True, slots=True)
class FederalRegisterPage:
    """One exact API response and the source cursor that requested it."""

    traversal_index: int
    page_index: int
    request_key: str
    source_cursor: str | None
    response_bytes: bytes
    window_index: int = 0
    window_page_index: int = 0

    @property
    def evidence_media_type(self) -> str:
        return "application/json"

    def __post_init__(self) -> None:
        if min(self.traversal_index, self.page_index, self.window_index, self.window_page_index) < 0:
            raise FederalRegisterSourceError("traversal, window, and page indexes must be non-negative")
        if (self.window_page_index == 0) != (self.source_cursor is None):
            raise FederalRegisterSourceError("Federal Register window boundary differs from its source cursor")
        if not self.request_key:
            raise FederalRegisterSourceError("request_key must be nonempty")
        if not self.response_bytes:
            raise FederalRegisterSourceError("Federal Register evidence must not be empty")


@dataclass(slots=True)
class FederalRegisterTraversalCheck:
    """Check the source-declared inventory while a traversal streams."""

    declared_count: int | None = None
    declared_page_count: int | None = None
    observed_count: int = 0
    observed_page_count: int = 0

    def add(self, response: Mapping[str, Any], *, page_index: int) -> None:
        count = response.get("count")
        total_pages = response.get("total_pages")
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise FederalRegisterSourceError("Federal Register response count is invalid")
        if isinstance(total_pages, bool) or not isinstance(total_pages, int) or total_pages < 1:
            raise FederalRegisterSourceError("Federal Register response total_pages is invalid")
        if self.declared_count is None:
            self.declared_count = count
            self.declared_page_count = total_pages
        elif count != self.declared_count or total_pages != self.declared_page_count:
            raise FederalRegisterSourceError("Federal Register page inventory declarations changed")
        if page_index != self.observed_page_count:
            raise FederalRegisterSourceError("Federal Register page indexes are not contiguous")
        self.observed_count += len(response["results"])
        self.observed_page_count += 1

    def finish(self) -> None:
        if self.declared_count != self.observed_count:
            raise FederalRegisterSourceError("Federal Register declared and observed record counts differ")
        if self.declared_page_count != self.observed_page_count:
            raise FederalRegisterSourceError("Federal Register declared and observed page counts differ")


def federal_register_query_scope(value: Mapping[str, Any]) -> dict[str, str]:
    """Validate the one closed Federal Register date-window query."""

    if set(value) != {"publishedFrom", "publishedThrough"}:
        raise FederalRegisterSourceError("Federal Register query scope fields differ")
    try:
        published_from = date.fromisoformat(str(value["publishedFrom"]))
        published_through = date.fromisoformat(str(value["publishedThrough"]))
    except ValueError as error:
        raise FederalRegisterSourceError("Federal Register query scope dates are invalid") from error
    if published_through < published_from:
        raise FederalRegisterSourceError("Federal Register query scope is reversed")
    return {
        "publishedFrom": published_from.isoformat(),
        "publishedThrough": published_through.isoformat(),
    }


def federal_register_documents_url(
    query_scope: Mapping[str, Any],
    *,
    per_page: int = MAX_RESULTS_PER_PAGE,
) -> str:
    """Build the current canonical API request for a source date window."""

    scope = federal_register_query_scope(query_scope)
    if isinstance(per_page, bool) or not isinstance(per_page, int) or not 1 <= per_page <= MAX_RESULTS_PER_PAGE:
        raise FederalRegisterSourceError("Federal Register per_page is outside the source bound")
    parameters = [
        ("per_page", str(per_page)),
        ("order", "newest"),
        ("conditions[publication_date][gte]", scope["publishedFrom"]),
        ("conditions[publication_date][lte]", scope["publishedThrough"]),
        *(("fields[]", field) for field in sorted(DOCUMENT_FIELDS)),
    ]
    return f"{FEDERAL_REGISTER_DOCUMENTS_URL}?{urlencode(parameters)}"


def federal_register_request_window(value: str) -> tuple[date, date]:
    """Parse one canonical initial window request and refuse query drift."""

    parsed = urlparse(value)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "www.federalregister.gov"
        or parsed.port is not None
        or parsed.path != "/api/v1/documents.json"
        or parsed.fragment
        or parsed.username is not None
        or parsed.password is not None
    ):
        raise FederalRegisterSourceError("Federal Register window request URL is invalid")
    parameters = parse_qs(parsed.query, keep_blank_values=True)
    expected_fields = {
        "conditions[publication_date][gte]",
        "conditions[publication_date][lte]",
        "fields[]",
        "order",
        "per_page",
    }
    if set(parameters) != expected_fields:
        raise FederalRegisterSourceError("Federal Register window request fields differ")
    per_page_values = parameters["per_page"]
    if len(per_page_values) != 1 or not per_page_values[0].isdigit():
        raise FederalRegisterSourceError("Federal Register window per_page is invalid")
    per_page = int(per_page_values[0])
    scope = federal_register_query_scope(
        {
            "publishedFrom": parameters["conditions[publication_date][gte]"][0]
            if len(parameters["conditions[publication_date][gte]"]) == 1
            else "",
            "publishedThrough": parameters["conditions[publication_date][lte]"][0]
            if len(parameters["conditions[publication_date][lte]"]) == 1
            else "",
        }
    )
    if parameters["order"] != ["newest"]:
        raise FederalRegisterSourceError("Federal Register window request policy differs")
    requested_fields = frozenset(parameters["fields[]"])
    if requested_fields != DOCUMENT_FIELDS:
        raise FederalRegisterSourceError("Federal Register window request field set differs from current fields")
    if federal_register_documents_url(scope, per_page=per_page) != value:
        raise FederalRegisterSourceError("Federal Register window request is not canonical")
    return date.fromisoformat(scope["publishedFrom"]), date.fromisoformat(scope["publishedThrough"])


def validate_federal_register_window_partition(
    windows: list[tuple[tuple[date, date], bool]],
    *,
    query_scope: Mapping[str, Any],
) -> None:
    """Require ordered, nonoverlapping leaf windows that exactly cover the query."""

    scope = federal_register_query_scope(query_scope)
    published_from = date.fromisoformat(scope["publishedFrom"])
    published_through = date.fromisoformat(scope["publishedThrough"])
    if not windows:
        raise FederalRegisterSourceError("Federal Register acquisition has no date windows")
    position = 0

    def consume(expected: tuple[date, date]) -> None:
        nonlocal position
        if position >= len(windows) or windows[position][0] != expected:
            raise FederalRegisterSourceError("Federal Register split windows are missing, overlapping, or unordered")
        _, records_included = windows[position]
        position += 1
        window_start, window_end = expected
        if records_included:
            return
        if window_start == window_end:
            raise FederalRegisterSourceError(f"Federal Register result cap is ambiguous for {window_start.isoformat()}")
        midpoint = window_start + (window_end - window_start) // 2
        consume((window_start, midpoint))
        consume((midpoint + timedelta(days=1), window_end))

    window_start = published_from
    while window_start <= published_through:
        window_end = min(
            window_start + timedelta(days=MAX_WINDOW_DAYS - 1),
            published_through,
        )
        consume((window_start, window_end))
        window_start = window_end + timedelta(days=1)
    if position != len(windows):
        raise FederalRegisterSourceError("Federal Register acquisition has extra date windows")


@dataclass(slots=True)
class FederalRegisterAcquisitionCheck:
    """Replay the exact pre-order split tree, including capped probes."""

    windows: list[tuple[tuple[date, date], bool]] = field(default_factory=list)

    def add_window(
        self,
        response: Mapping[str, Any],
        *,
        page_window: object | None,
        records_included: bool,
        response_bytes: bytes,
    ) -> None:
        del response_bytes
        if (
            not isinstance(page_window, tuple)
            or len(page_window) != 2
            or not all(isinstance(value, date) for value in page_window)
        ):
            raise FederalRegisterSourceError("Federal Register page lacks a validated date window")
        expected = response.get("count", RESULT_CAP) < RESULT_CAP
        if records_included is not expected:
            raise FederalRegisterSourceError("Federal Register split decision differs from its response count")
        self.windows.append((cast(tuple[date, date], page_window), records_included))

    def finish(self, *, query_scope: Mapping[str, Any]) -> None:
        validate_federal_register_window_partition(self.windows, query_scope=query_scope)


def federal_register_records_included(
    response: Mapping[str, Any],
    *,
    query_scope: Mapping[str, Any],
    page_window: object | None,
) -> bool:
    """Profile hook: a window's records are included as-is only when its declared count is below the result cap."""
    del query_scope, page_window
    count = response.get("count")
    return isinstance(count, int) and not isinstance(count, bool) and count < RESULT_CAP


def federal_register_acquisition_policy(
    query_scope: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "coverageLimits": [
            "Two consecutive traversals must agree on observed records within the requested date windows.",
            "Matching crawls do not establish a frozen publisher-wide version or source absence outside those windows.",
        ],
        "documentFields": sorted(DOCUMENT_FIELDS),
        "initialQueryScope": federal_register_query_scope(query_scope),
        "maxTraversals": MAX_RECONCILIATION_TRAVERSALS,
        "maxWindowDays": MAX_WINDOW_DAYS,
        # Reused numbers need composite identity; see federal_register_source_record_id.
        # publication_date belongs to the group key, so no cross-date orderBy applies.
        # Repeats of one pair collapse only when all canonical record digests agree.
        "observationSelection": {
            "groupBy": ["/document_number", "/publication_date"],
            "tieDisposition": "refuse-differing-record-digest-at-normalized-instant",
        },
        "renditionSelection": {
            "fields": [
                {"mediaType": media_type, "renditionId": rendition_id, "sourceField": source_field}
                for rendition_id, source_field, media_type in _RENDITION_FIELDS
            ],
            "missingLocator": "emit-null",
        },
        "resultCap": RESULT_CAP,
        "strategy": "date-window-cap-split-stable-reconciliation",
    }


def _validated_page_url(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise FederalRegisterSourceError("Federal Register next_page_url must be null or nonempty text")
    parsed = urlparse(value)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "www.federalregister.gov"
        or parsed.port is not None
        or parsed.path not in {"/api/v1/documents", "/api/v1/documents.json"}
        or not parsed.query
        or parsed.fragment
        or parsed.username is not None
        or parsed.password is not None
    ):
        raise FederalRegisterSourceError("Federal Register returned an unsafe page cursor")
    return value


def federal_register_next_page_url(
    response: Mapping[str, Any],
    *,
    seen_urls: set[str],
) -> str | None:
    """Return one trusted next cursor and refuse a repeated URL."""

    next_url = _validated_page_url(response.get("next_page_url"))
    if next_url is not None:
        if next_url in seen_urls:
            raise FederalRegisterSourceError("Federal Register returned a cyclic page cursor")
        seen_urls.add(next_url)
    return next_url


def _refused_federal_response(request_key: str, response_bytes: bytes | None) -> RefusedResponse:
    byte_size = len(response_bytes) if isinstance(response_bytes, bytes) else None
    reason = None
    if byte_size is None:
        reason = "unsupported-response"
    elif byte_size > MAX_PAGE_BYTES:
        reason = "response-byte-limit"
    return RefusedResponse(
        request_key=request_key,
        stage="source-validation",
        response_bytes=response_bytes if reason is None else None,
        media_type="application/json" if reason is None else "application/octet-stream",
        unavailable_reason=reason,
        observed_byte_size=byte_size,
    )


def iter_federal_register_pages(
    fetch: FederalRegisterFetch,
    *,
    query_scope: Mapping[str, Any],
    traversals: int = 2,
    per_page: int = MAX_RESULTS_PER_PAGE,
    max_pages_per_traversal: int = MAX_PAGES_PER_TRAVERSAL,
) -> Generator[FederalRegisterPage, None, None]:
    """Fetch bounded exact API pages through cap-safe date-window traversal."""

    if (
        isinstance(traversals, bool)
        or not isinstance(traversals, int)
        or not 1 <= traversals <= MAX_RECONCILIATION_TRAVERSALS
    ):
        raise FederalRegisterSourceError("Federal Register traversal count is outside the source bound")
    if (
        isinstance(max_pages_per_traversal, bool)
        or not isinstance(max_pages_per_traversal, int)
        or max_pages_per_traversal < 1
    ):
        raise FederalRegisterSourceError("Federal Register page bound must be positive")
    scope = federal_register_query_scope(query_scope)
    published_from = date.fromisoformat(scope["publishedFrom"])
    published_through = date.fromisoformat(scope["publishedThrough"])
    for traversal_index in range(traversals):
        emitted_pages = 0
        emitted_windows = 0

        def fetch_bytes(request_url: str) -> bytes:
            try:
                response_bytes = fetch(request_url)
            except Exception as error:
                attach_refused_response(
                    error,
                    RefusedResponse(
                        request_key=request_url,
                        stage="transport",
                        response_bytes=None,
                        media_type="application/octet-stream",
                        unavailable_reason="transport-unavailable",
                    ),
                )
                raise
            try:
                if not isinstance(response_bytes, bytes) or not response_bytes:
                    raise FederalRegisterSourceError("Federal Register fetch returned no response bytes")
                if len(response_bytes) > MAX_PAGE_BYTES:
                    raise FederalRegisterSourceError("Federal Register response exceeds its evidence byte bound")
            except FederalRegisterSourceError as error:
                attach_refused_response(error, _refused_federal_response(request_url, response_bytes))
                raise
            return response_bytes

        def window_pages(window_start: date, window_end: date) -> Iterator[FederalRegisterPage]:
            nonlocal emitted_pages, emitted_windows
            window_scope = {
                "publishedFrom": window_start.isoformat(),
                "publishedThrough": window_end.isoformat(),
            }
            initial_url = federal_register_documents_url(window_scope, per_page=per_page)
            request_url = initial_url
            response_bytes: bytes | None = None
            try:
                response_bytes = fetch_bytes(initial_url)
                first_bytes = response_bytes
                first_response = parse_page_response(first_bytes)
                declared_count = first_response["count"]
                if emitted_pages >= max_pages_per_traversal:
                    raise FederalRegisterSourceError("Federal Register acquisition exceeded its evidence-page bound")
                window_index = emitted_windows
                emitted_windows += 1
                if declared_count >= RESULT_CAP:
                    yield FederalRegisterPage(
                        # window_pages is drained via `yield from` before traversal_index advances
                        traversal_index=traversal_index,  # noqa: B023
                        page_index=emitted_pages,
                        request_key=initial_url,
                        source_cursor=None,
                        response_bytes=first_bytes,
                        window_index=window_index,
                        window_page_index=0,
                    )
                    emitted_pages += 1
                    if window_start == window_end:
                        raise FederalRegisterSourceError(
                            f"Federal Register result cap is ambiguous for {window_start.isoformat()}"
                        )
                    midpoint = window_start + (window_end - window_start) // 2
                    yield from window_pages(window_start, midpoint)
                    yield from window_pages(midpoint + timedelta(days=1), window_end)
                    return

                cursor: str | None = None
                response_bytes = first_bytes
                response = first_response
                seen_urls = {initial_url}
                inventory = FederalRegisterTraversalCheck()
                window_page_index = 0
                while True:
                    if emitted_pages >= max_pages_per_traversal:
                        raise FederalRegisterSourceError(
                            "Federal Register acquisition exceeded its evidence-page bound"
                        )
                    inventory.add(response, page_index=window_page_index)
                    next_url = federal_register_next_page_url(response, seen_urls=seen_urls)
                    yield FederalRegisterPage(
                        # window_pages is drained via `yield from` before traversal_index advances
                        traversal_index=traversal_index,  # noqa: B023
                        page_index=emitted_pages,
                        request_key=request_url,
                        source_cursor=cursor,
                        response_bytes=response_bytes,
                        window_index=window_index,
                        window_page_index=window_page_index,
                    )
                    emitted_pages += 1
                    if next_url is None:
                        inventory.finish()
                        return
                    cursor = next_url
                    request_url = next_url
                    response_bytes = fetch_bytes(request_url)
                    response = parse_page_response(response_bytes)
                    window_page_index += 1
            except Exception as error:
                attach_refused_response(error, _refused_federal_response(request_url, response_bytes))
                raise

        window_start = published_from
        while window_start <= published_through:
            window_end = min(window_start + timedelta(days=MAX_WINDOW_DAYS - 1), published_through)
            yield from window_pages(window_start, window_end)
            window_start = window_end + timedelta(days=1)


def _reject_float(value: str) -> None:
    raise FederalRegisterSourceError(f"Federal Register JSON contains unsupported float {value!r}")


def _reject_constant(value: str) -> None:
    raise FederalRegisterSourceError(f"Federal Register JSON contains non-finite number {value!r}")


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise FederalRegisterSourceError(f"Federal Register JSON repeats field {key!r}")
        result[key] = value
    return result


def parse_page_response(raw: bytes) -> Mapping[str, Any]:
    """Parse one bounded source response without changing its evidence bytes."""

    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
            parse_float=_reject_float,
            parse_constant=_reject_constant,
        )
    except FederalRegisterSourceError:
        raise
    except (UnicodeError, json.JSONDecodeError) as error:
        raise FederalRegisterSourceError(f"invalid Federal Register response JSON: {error}") from error
    if not isinstance(value, Mapping):
        raise FederalRegisterSourceError("Federal Register response must be an object")
    unknown = set(value) - API_RESPONSE_FIELDS
    if unknown:
        raise FederalRegisterSourceError(f"unclassified Federal Register response fields: {sorted(unknown)}")
    count = value.get("count")
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise FederalRegisterSourceError("Federal Register response count is invalid")
    results = value.get("results", [] if count == 0 else None)
    if not isinstance(results, list):
        raise FederalRegisterSourceError("Federal Register response results must be an array")
    if len(results) > MAX_RESULTS_PER_PAGE:
        raise FederalRegisterSourceError("Federal Register response exceeds the page record bound")
    normalized = dict(value)
    normalized["results"] = results
    normalized.setdefault("next_page_url", None)
    normalized.setdefault("total_pages", 1 if count == 0 else None)
    _validated_page_url(normalized.get("next_page_url"))
    return normalized


def _is_text(value: object) -> bool:
    return value is None or isinstance(value, str)


def _is_count(value: object) -> bool:
    return value is None or (isinstance(value, int) and not isinstance(value, bool) and value >= 0)


def _is_text_object(value: object, allowed: frozenset[str]) -> bool:
    return isinstance(value, Mapping) and set(value) <= allowed and all(map(_is_text, value.values()))


def _check_regulations_dot_gov_info(info: object) -> None:
    """Refuse a ``regulations_dot_gov_info`` that is not the closed object the Register states, at any depth."""
    if info is None:
        return
    if not isinstance(info, Mapping) or not set(info) <= REGULATIONS_DOT_GOV_INFO_FIELDS:
        raise FederalRegisterSourceError("unclassified Federal Register regulations_dot_gov_info fields")
    for name, value in info.items():
        if name in _REGULATIONS_DOT_GOV_TEXT:
            valid = _is_text(value)
        elif name in _REGULATIONS_DOT_GOV_INTEGER:
            valid = _is_count(value)
        elif name == "supporting_documents":
            allowed = _REGULATIONS_DOT_GOV_OBJECTS[name]
            valid = value is None or (isinstance(value, list) and all(_is_text_object(item, allowed) for item in value))
        else:
            valid = value is None or _is_text_object(value, _REGULATIONS_DOT_GOV_OBJECTS[name])
        if not valid:
            raise FederalRegisterSourceError(
                f"Federal Register regulations_dot_gov_info.{name} has an unsupported type"
            )


def classify_document(value: object) -> dict[str, Any]:
    """Return one faithful, closed source record and reject schema drift."""

    if not isinstance(value, Mapping):
        raise FederalRegisterSourceError("Federal Register result must be an object")
    source = cast(Mapping[str, Any], value)
    unknown = set(source) - DOCUMENT_FIELDS
    if unknown:
        raise FederalRegisterSourceError(f"unclassified Federal Register document fields: {sorted(unknown)}")
    document_number = source.get("document_number")
    if not isinstance(document_number, str) or _ASCII_ID.fullmatch(document_number) is None:
        raise FederalRegisterSourceError("Federal Register result lacks document_number")
    publication_date = source.get("publication_date")
    if not isinstance(publication_date, str) or not publication_date:
        raise FederalRegisterSourceError("Federal Register result lacks publication_date")
    try:
        parsed_publication_date = date.fromisoformat(publication_date)
    except ValueError as error:
        raise FederalRegisterSourceError("Federal Register publication_date is invalid") from error
    if parsed_publication_date.isoformat() != publication_date:
        raise FederalRegisterSourceError("Federal Register publication_date is not canonical")
    for field_name in _TEXT_FIELDS:
        field_value = source.get(field_name)
        if field_value is not None and not isinstance(field_value, str):
            raise FederalRegisterSourceError(f"Federal Register {field_name} must be text or null")
    if source.get("full_text_xml_url") == "":
        raise FederalRegisterSourceError("Federal Register full_text_xml_url must be null or nonempty text")
    for field_name in _INTEGER_FIELDS:
        field_value = source.get(field_name)
        if field_value is not None and (isinstance(field_value, bool) or not isinstance(field_value, int)):
            raise FederalRegisterSourceError(f"Federal Register {field_name} must be an integer or null")
    for field_name in _TEXT_ARRAY_FIELDS:
        field_value = source.get(field_name)
        if field_value is not None and (
            not isinstance(field_value, list) or any(not isinstance(item, str) for item in field_value)
        ):
            raise FederalRegisterSourceError(f"Federal Register {field_name} must be a text array or null")
    significant = source.get("significant")
    if significant is not None and not isinstance(significant, bool):
        raise FederalRegisterSourceError("Federal Register significant must be true, false or null")
    for field_name, allowed_fields in (
        ("agencies", _AGENCY_FIELDS),
        ("cfr_references", _CFR_REFERENCE_FIELDS),
    ):
        values = source.get(field_name)
        if values is None:
            continue
        if not isinstance(values, list):
            raise FederalRegisterSourceError(f"Federal Register {field_name} must be an array or null")
        for item in values:
            if not isinstance(item, Mapping) or not set(item) <= allowed_fields:
                raise FederalRegisterSourceError(f"unclassified Federal Register {field_name} fields")
            for nested_name, nested_value in item.items():
                valid_type = nested_value is None or (
                    not isinstance(nested_value, bool) and isinstance(nested_value, (int, str))
                )
                if not valid_type:
                    raise FederalRegisterSourceError(
                        f"Federal Register {field_name}.{nested_name} has an unsupported type"
                    )
    _check_regulations_dot_gov_info(source.get("regulations_dot_gov_info"))
    record = dict(source)
    canonical_json_bytes(record)
    return record


def federal_register_observation_version(record: Mapping[str, Any]) -> str | None:
    """Return canonical publication_date for comparing repeated observations.

    classify_document requires this date; the source record remains unchanged.
    The date is also part of the composite identity, so every observation of one
    identity has the same version. Equal canonical digests collapse; differing
    digests refuse the release rather than choosing a correction arbitrarily.
    """

    value = record.get("publication_date")
    if not isinstance(value, str) or not value:
        raise FederalRegisterSourceError("Federal Register publication_date must be nonempty text")
    return date.fromisoformat(value).isoformat()


def field_diagnostics(record: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Describe malformed RIN values without removing their source evidence."""

    values = record.get("regulation_id_numbers")
    if values is None:
        return []
    if not isinstance(values, list):
        return [
            {
                "code": "malformed-rin-container",
                "field": "regulation_id_numbers",
                "value": values,
            }
        ]
    diagnostics = []
    for value in values:
        if not isinstance(value, str) or _RIN.fullmatch(value) is None:
            diagnostics.append(
                {
                    "code": "malformed-rin",
                    "field": "regulation_id_numbers",
                    "value": value,
                }
            )
    return diagnostics


def federal_register_source_record_id(record: Mapping[str, Any]) -> str:
    """Join document_number and publication_date into a reversible source identity.

    Numbers can identify unrelated documents: 00-111 names both a 2000-01-18 notice
    and a 2000-01-14 rule. classify_document requires an _ASCII_ID number and a
    canonical YYYY-MM-DD date. Neither permits @, so splitting the result on @
    recovers both source-issued values exactly.
    """

    from spicy_docs.schemas.tables import federal_register_record_key

    return federal_register_record_key((str(record["document_number"]), str(record["publication_date"])))


def source_record(record: Mapping[str, Any], *, schema_digest: str) -> dict[str, Any]:
    """Wrap classified source fields with their source schema reference."""

    return {
        "fieldDiagnostics": field_diagnostics(record),
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": SCHEMA_VERSION,
        "scopeId": SCOPE_ID,
        "sourceRecordId": federal_register_source_record_id(record),
    }


def rendition_rows(record: Mapping[str, Any]) -> tuple[dict[str, Any], ...]:
    """Preserve every source-stated locator field, including explicit absence."""

    source_record_id = federal_register_source_record_id(record)
    rows: list[dict[str, Any]] = []
    for rendition_id, source_field, media_type in _RENDITION_FIELDS:
        locator = record.get(source_field)
        if locator is not None and (not isinstance(locator, str) or not locator):
            raise FederalRegisterSourceError(f"Federal Register {source_field} must be null or nonempty text")
        rows.append(
            {
                "expectedByteSize": None,
                "expectedSha256": None,
                "locator": locator,
                "mediaType": media_type,
                "renditionId": rendition_id,
                "sourceField": source_field,
                "sourceRecordId": source_record_id,
            }
        )
    return tuple(rows)


_NULLABLE_TEXT_SCHEMA: Final = {"type": ["string", "null"]}
_TEXT_ARRAY_SCHEMA: Final = {
    "items": {"type": "string"},
    "type": ["array", "null"],
}
_COUNT_SCHEMA: Final = {"minimum": 0, "type": ["integer", "null"]}


def _text_object_schema(fields: frozenset[str]) -> dict[str, Any]:
    return {
        "additionalProperties": False,
        "properties": {field: _NULLABLE_TEXT_SCHEMA for field in sorted(fields)},
        "type": "object",
    }


_REGULATIONS_DOT_GOV_INFO_SCHEMA: Final = {
    "additionalProperties": False,
    "properties": {
        **{field: _NULLABLE_TEXT_SCHEMA for field in sorted(_REGULATIONS_DOT_GOV_TEXT)},
        **{field: _COUNT_SCHEMA for field in sorted(_REGULATIONS_DOT_GOV_INTEGER)},
        "regulatory_plan": {
            "anyOf": [{"type": "null"}, _text_object_schema(_REGULATIONS_DOT_GOV_OBJECTS["regulatory_plan"])]
        },
        "supporting_documents": {
            "items": _text_object_schema(_REGULATIONS_DOT_GOV_OBJECTS["supporting_documents"]),
            "type": ["array", "null"],
        },
    },
    "type": ["object", "null"],
}

FEDERAL_REGISTER_DOCUMENT_SCHEMA: Final[dict[str, Any]] = {
    "$id": "urn:spicy-regs:schema:federal-register-document:1.2",
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "additionalProperties": False,
    "properties": {
        "abstract": _NULLABLE_TEXT_SCHEMA,
        "action": _NULLABLE_TEXT_SCHEMA,
        "agencies": {
            "items": {
                "additionalProperties": False,
                "properties": {field: {"type": ["integer", "string", "null"]} for field in sorted(_AGENCY_FIELDS)},
                "type": "object",
            },
            "type": ["array", "null"],
        },
        "agency_names": _TEXT_ARRAY_SCHEMA,
        "body_html_url": _NULLABLE_TEXT_SCHEMA,
        "cfr_references": {
            "items": {
                "additionalProperties": False,
                "properties": {
                    field: {"type": ["integer", "string", "null"]} for field in sorted(_CFR_REFERENCE_FIELDS)
                },
                "type": "object",
            },
            "type": ["array", "null"],
        },
        "comments_close_on": _NULLABLE_TEXT_SCHEMA,
        "correction_of": _NULLABLE_TEXT_SCHEMA,
        "corrections": _TEXT_ARRAY_SCHEMA,
        "docket_ids": _TEXT_ARRAY_SCHEMA,
        "document_number": {"minLength": 1, "type": "string"},
        "effective_on": _NULLABLE_TEXT_SCHEMA,
        "end_page": {"type": ["integer", "null"]},
        "executive_order_number": _NULLABLE_TEXT_SCHEMA,
        "full_text_xml_url": {"minLength": 1, "type": ["string", "null"]},
        "html_url": _NULLABLE_TEXT_SCHEMA,
        "pdf_url": _NULLABLE_TEXT_SCHEMA,
        "publication_date": {"format": "date", "type": "string"},
        # The source has emitted malformed containers and members. Preserve the
        # exact JSON value and attach nonfatal field diagnostics instead of
        # silently dropping source evidence.
        "regulation_id_numbers": {},
        "regulations_dot_gov_info": _REGULATIONS_DOT_GOV_INFO_SCHEMA,
        "signing_date": _NULLABLE_TEXT_SCHEMA,
        "significant": {"type": ["boolean", "null"]},
        "start_page": {"type": ["integer", "null"]},
        "subtype": _NULLABLE_TEXT_SCHEMA,
        "title": _NULLABLE_TEXT_SCHEMA,
        "topics": _TEXT_ARRAY_SCHEMA,
        "type": _NULLABLE_TEXT_SCHEMA,
        "volume": {"type": ["integer", "null"]},
    },
    "required": ["document_number", "publication_date"],
    "type": "object",
    "x-spicy-record-order": [
        {
            "fieldPath": "/document_number",
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
    ],
}


#: The schema is constant; cache its digest once per process across publish/replay.
@cache
def source_schema_digest() -> str:
    """Use the installed Rulespec schema-family identity implementation."""

    return schema_bundle_digest({SCHEMA_PATH: FEDERAL_REGISTER_DOCUMENT_SCHEMA})


def source_schema_declaration() -> dict[str, str]:
    return {
        "schemaDigest": source_schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": SCHEMA_VERSION,
    }


def source_record_digest(record: Mapping[str, Any]) -> str:
    """Digest one source result through Rulespec's sole ordered-record digester."""

    return framed_section_digest(
        "spicyregs-federal-register-record/1",
        (FramedSection("record", 1, (dict(record),)),),
    )


__all__ = [
    "API_RESPONSE_FIELDS",
    "DOCUMENT_FIELDS",
    "EXCLUDED_DOCUMENT_FIELDS",
    "FEDERAL_REGISTER_DOCUMENTS_URL",
    "FEDERAL_REGISTER_DOCUMENT_SCHEMA",
    "MAX_PAGES_PER_TRAVERSAL",
    "MAX_RESULTS_PER_PAGE",
    "MAX_WINDOW_DAYS",
    "REGULATIONS_DOT_GOV_INFO_FIELDS",
    "RESULT_CAP",
    "SCHEMA_NAME",
    "SCHEMA_PATH",
    "SCHEMA_VERSION",
    "SCOPE_ID",
    "SOURCE_SYSTEM_ID",
    "SOURCE_SYSTEM_VERSION",
    "FederalRegisterAcquisitionCheck",
    "FederalRegisterFetch",
    "FederalRegisterPage",
    "FederalRegisterSourceError",
    "FederalRegisterTraversalCheck",
    "classify_document",
    "federal_register_acquisition_policy",
    "federal_register_documents_url",
    "federal_register_next_page_url",
    "federal_register_observation_version",
    "federal_register_query_scope",
    "federal_register_records_included",
    "federal_register_request_window",
    "federal_register_source_record_id",
    "field_diagnostics",
    "iter_federal_register_pages",
    "parse_page_response",
    "rendition_rows",
    "source_record",
    "source_record_digest",
    "source_schema_declaration",
    "source_schema_digest",
    "validate_federal_register_window_partition",
]
