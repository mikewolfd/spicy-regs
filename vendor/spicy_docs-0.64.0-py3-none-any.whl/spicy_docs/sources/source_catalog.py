"""Replay bounded publisher metadata as facts, without selecting data or routes.

The exact capture remains the authority for original JSON spelling and XML.
Normalized records preserve parsed unknown fields and report defective entries.
An observed page never establishes collection-wide enumeration or availability.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from typing import Any
from urllib.parse import urlsplit
from xml.etree.ElementTree import tostring

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.reading.s3_listing import parse_s3_listing
from spicy_docs.reading.xml import parse_xml
from spicy_docs.sources.courtlistener.listing import BulkObject, parse_listing_page
from spicy_docs.transport.credentials import scrub_record

MAX_METADATA_BYTES = 8 * 1024**2
KINDS = ("dcat", "govinfo-bulk", "sitemap", "s3", "courtlistener", "ecfr-titles")


def stable_id(namespace: str, kind: str, native_id: str) -> str:
    """Unambiguous source-scoped identity; capture versions have separate IDs."""
    value = f"{namespace}\0{kind}\0{native_id}".encode()
    return f"{kind}:{hashlib.sha256(value).hexdigest()}"


def parse_metadata(
    payload: bytes,
    *,
    kind: str,
    namespace: str,
    capture_url: str,
    observed_at: str,
    sha256: str | None = None,
    content_type: str | None = None,
    scope: dict[str, Any] | None = None,
    bucket: str | None = None,
    prefix: str | None = None,
    secrets: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Read one caller-selected capture; no requests, implicit traversal or policy.

    ``sha256`` pins decoded payload bytes. A mismatched digest refuses parsing.
    ``scope`` names the caller's query, not the collection's covered period.
    Snapshot, modification and filename dates remain raw metadata, not periods.
    Credential values are removed from normalized records; exact originals must
    be held privately by the caller. Unknown fields otherwise remain intact.
    """
    if kind not in KINDS or not namespace or not observed_at:
        raise ValueError("kind, namespace and observed_at must identify the selected metadata")
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    out: dict[str, Any] = {"format": "spicy-source-discovery", "version": 1}
    out.update({name: [] for name in ("collections", "routes", "observations", "items", "periods", "errors")})
    obs: dict[str, Any] = {
        "id": stable_id(namespace, "observation", f"{capture_url}\0{digest}\0{observed_at}"),
        "capture_url": capture_url,
        "observed_at": observed_at,
        "sha256": digest,
        "bytes": len(payload),
        "content_type": content_type,
        "scope": scope or {"selected_url": capture_url},
        "status": "observed-page",
        "enumeration_complete": False,
        "metadata_kind": kind,
        "collection_ids": [],
    }
    out["observations"].append(obs)

    def error(path: str, message: str, raw: Any = None) -> None:
        out["errors"].append({"observation_id": obs["id"], "path": path, "message": message, "raw": raw})
        obs["status"] = "partial" if out["collections"] else "parse-error"

    def collection(native: str, title: str, raw: Any) -> str:
        cid = stable_id(namespace, "collection", native)
        obs["collection_ids"].append(cid)
        out["collections"].append(
            {
                "id": cid,
                "namespace": namespace,
                "native_id": native,
                "title": title,
                "raw": raw,
                "observation_ids": [obs["id"]],
            }
        )
        temporal = raw.get("temporal") if isinstance(raw, dict) else None
        out["periods"].append(
            {
                "collection_id": cid,
                "kind": "publisher_temporal" if temporal else "unknown",
                "label": temporal if isinstance(temporal, str) else "Unknown",
                "basis": "publisher-metadata" if temporal else "metadata-does-not-state-covered-period",
                "raw": temporal,
            }
        )
        return cid

    def route(cid: str, native: str, url: str, raw: Any, method: str = "unknown") -> str:
        rid = stable_id(namespace, "route", f"{cid}\0{native}")
        out["routes"].append(
            {
                "id": rid,
                "collection_id": cid,
                "label": native,
                "access_url": url,
                "delivery_method": method,
                "lifecycle": "unknown",
                "custodian": "unknown",
                "content_behavior": "unknown",
                "raw": raw,
            }
        )
        return rid

    def item(cid: str, rid: str, native: str, url: str | None, raw: Any) -> None:
        out["items"].append(
            {
                "id": stable_id(namespace, "item", f"{rid}\0{native}"),
                "collection_id": cid,
                "route_id": rid,
                "native_id": native,
                "name": native,
                "access_url": url,
                "status": "advertised",
                "raw": raw,
                "observation_id": obs["id"],
                "version_id": stable_id(namespace, "item-version", f"{rid}\0{native}\0{digest}"),
            }
        )

    try:
        if len(payload) > MAX_METADATA_BYTES:
            raise ValueError("metadata exceeds its byte bound")
        if sha256 and sha256.removeprefix("sha256:") != digest.removeprefix("sha256:"):
            raise ValueError("metadata digest differs from its input pin")
        media = (content_type or "").split(";", 1)[0].lower().strip()
        json_kind = kind in {"dcat", "govinfo-bulk", "ecfr-titles"}
        if media and not (
            media == "application/json" or media.endswith("+json")
            if json_kind
            else media in {"text/xml", "application/xml"} or media.endswith("+xml")
        ):
            raise ValueError("metadata media type differs from the selected parser")
        if json_kind:
            data = load_bounded_json(
                payload,
                source="publisher metadata",
                error_type=ValueError,
                number_policy="finite-float",
                max_bytes=MAX_METADATA_BYTES,
            )
            if not isinstance(data, dict):
                raise ValueError("metadata root must be an object")
            obs["raw"] = data
            key = {"dcat": "dataset", "govinfo-bulk": "files", "ecfr-titles": "titles"}[kind]
            rows = data.get(key)
            if kind == "dcat":
                groups = [data[field] for field in ("dataset", "datasetSeries", "service") if field in data]
                if not groups or any(not isinstance(group, list) for group in groups):
                    raise ValueError("catalog must state dataset, datasetSeries or service arrays")
                rows = [row for group in groups for row in group]
            if not isinstance(rows, list):
                raise ValueError(f"metadata must state a {key} array")
            if kind == "dcat":
                seen: set[str] = set()
                for index, row in enumerate(rows):
                    path = f"dataset[{index}]"
                    if not isinstance(row, dict) or not isinstance(row.get("identifier"), str) or not row["identifier"]:
                        error(path, "dataset must state a nonempty string identifier", row)
                        continue
                    if row["identifier"] in seen:
                        error(path, "dataset repeats native identifier", row)
                        continue
                    seen.add(row["identifier"])
                    cid = collection(row["identifier"], str(row.get("title") or row["identifier"]), row)
                    out["collections"][-1].update(
                        {
                            "publisher": row.get("publisher"),
                            "description": row.get("description"),
                            "native_type": row.get("@type"),
                            "relationships": [
                                {"relation": field, "raw": row[field]}
                                for field in ("inSeries", "seriesMember", "isPartOf", "hasPart", "servesDataset")
                                if field in row
                            ],
                        }
                    )
                    if row.get("endpointURL"):
                        endpoints = row["endpointURL"] if isinstance(row["endpointURL"], list) else [row["endpointURL"]]
                        for endpoint in endpoints:
                            if not isinstance(endpoint, str):
                                error(path + ".endpointURL", "service endpoint URL must be a string", endpoint)
                            else:
                                route(cid, endpoint, endpoint, row, "api")
                    distributions = row.get("distribution", [])
                    if not isinstance(distributions, list):
                        error(path + ".distribution", "distribution must be an array", distributions)
                        continue
                    seen_routes: dict[str, dict[str, Any]] = {}
                    for pos, dist in enumerate(distributions):
                        if not isinstance(dist, dict):
                            error(f"{path}.distribution[{pos}]", "distribution must be an object", dist)
                            continue
                        urls = [(field, dist[field]) for field in ("accessURL", "downloadURL") if dist.get(field)]
                        if not urls:
                            error(f"{path}.distribution[{pos}]", "distribution does not state a URL", dist)
                        for field, url in urls:
                            if not isinstance(url, str):
                                error(f"{path}.distribution[{pos}].{field}", "URL must be a string", url)
                                continue
                            # Only explicit publisher format names classify a route.
                            method = "api" if str(dist.get("format", "")).upper() == "API" else "unknown"
                            distribution_id = dist.get("identifier") or dist.get("@id")
                            if not isinstance(distribution_id, str):
                                distribution_id = hashlib.sha256(
                                    json.dumps(dist, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
                                ).hexdigest()
                            native_route = f"{distribution_id}\0{url}\0{field}"
                            if native_route in seen_routes:
                                seen_routes[native_route]["distribution_positions"].append(pos)
                                continue
                            rid = route(cid, native_route, url, dist, method)
                            seen_routes[native_route] = out["routes"][-1]
                            out["routes"][-1]["distribution_id"] = distribution_id
                            out["routes"][-1]["distribution_positions"] = [pos]
                            out["routes"][-1]["label"] = str(dist.get("title") or field)
                            out["routes"][-1]["url_role"] = field
                            out["routes"][-1]["media_type"] = dist.get("mediaType")
                            out["routes"][-1]["access_service"] = dist.get("accessService")
                            item(cid, rid, row["identifier"], url, dist)
            else:
                cid = collection(capture_url, namespace, {"metadata_kind": kind})
                rid = route(cid, capture_url, capture_url, {}, "bulk" if kind == "govinfo-bulk" else "api")
                if kind == "govinfo-bulk":
                    out["routes"][-1]["required_accept"] = "application/json"
                for index, row in enumerate(rows):
                    native_key = "name" if kind == "govinfo-bulk" else "number"
                    if not isinstance(row, dict) or row.get(native_key) is None:
                        error(f"{key}[{index}]", f"entry must state {native_key}", row)
                        continue
                    item(cid, rid, str(row[native_key]), row.get("link"), row)
        else:
            root = parse_xml(payload, max_bytes=MAX_METADATA_BYTES, error_type=ValueError, label="publisher metadata")
            obs["raw_xml"] = payload.decode("utf-8")
            listing_url = urlsplit(capture_url)._replace(query="", fragment="").geturl()
            native_scope = (
                f"{bucket}\0{prefix}"
                if kind == "s3"
                else (
                    f"com-courtlistener-storage\0{prefix or 'bulk-data/'}" if kind == "courtlistener" else listing_url
                )
            )
            cid = collection(native_scope, namespace, {"metadata_kind": kind})
            rid = route(cid, native_scope, listing_url, {}, "bulk" if kind != "sitemap" else "sitemap")
            if kind in {"courtlistener", "s3"}:
                if kind == "courtlistener":
                    objects, token = parse_listing_page(payload, prefix=prefix or "bulk-data/")
                else:
                    if not bucket or prefix is None:
                        raise ValueError("S3 metadata requires selected bucket and prefix")
                    objects, token = parse_s3_listing(payload, bucket=bucket, prefix=prefix)
                obs["continuation_token"] = token
                obs["page_terminal"] = token is None
                if token:
                    obs["status"] = "partial"
                for obj in objects:
                    url = obj.url if isinstance(obj, BulkObject) else None
                    item(cid, rid, obj.key, url, asdict(obj))
                    if isinstance(obj, BulkObject):
                        out["items"][-1]["snapshot_date"] = obj.dump_date.isoformat() if obj.dump_date else None
            else:
                ns = "{http://www.sitemaps.org/schemas/sitemap/0.9}"
                if root.tag not in {ns + "sitemapindex", ns + "urlset"}:
                    raise ValueError("metadata is not a sitemap index or URL set")
                entry_tag = ns + ("sitemap" if root.tag == ns + "sitemapindex" else "url")
                for index, node in enumerate(root):
                    loc = node.findtext(ns + "loc")
                    raw = tostring(node, encoding="unicode")
                    if node.tag != entry_tag or not loc:
                        error(f"entry[{index}]", "sitemap entry must state loc", raw)
                        continue
                    item(cid, rid, loc, loc, {"xml": raw, "lastmod": node.findtext(ns + "lastmod")})
        obs["item_count"] = len(out["items"])
        if not out["errors"] and not out["collections"] and not out["items"]:
            obs["status"] = "requested-empty"
        if out["errors"]:
            obs["status"] = "partial" if out["items"] or out["collections"] else "parse-error"
    except ValueError as exc:
        error("$", str(exc))
        obs["status"] = "parse-error"
    return scrub_record(out, *secrets)


def refresh_metadata(client: Any, url: str, *, kind: str, namespace: str, **options: Any) -> tuple[Any, dict[str, Any]]:
    """Capture one selected public endpoint through an existing bounded client.

    No crawling or retries beyond the client's own budget; caller retains capture
    before admitting facts. GovInfo's required Accept is always explicit.
    """
    if (
        not urlsplit(url).hostname
        or urlsplit(url).scheme != "https"
        or urlsplit(url).username
        or urlsplit(url).password
    ):
        raise ValueError("metadata refresh requires a public HTTPS URL")
    if scrub_record(url, *options.get("secrets", ())) != url:
        raise ValueError("metadata refresh URL must not carry credentials")
    headers = (
        {"Accept": "application/json"}
        if kind in {"dcat", "govinfo-bulk", "ecfr-titles"}
        else {"Accept": "application/xml"}
    )
    capture = client.capture(url, max_bytes=MAX_METADATA_BYTES, request_headers=headers)
    result = parse_metadata(
        capture.body,
        kind=kind,
        namespace=namespace,
        capture_url=capture.requested_url,
        observed_at=capture.observed_at,
        sha256=capture.sha256,
        content_type=capture.content_type,
        **options,
    )
    return capture, result
