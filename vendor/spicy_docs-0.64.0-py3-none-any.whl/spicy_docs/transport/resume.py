"""Durable caller-owned byte and traversal checkpoints; no source selection.

Requests, retries and source admission remain with existing acquisition clients.
A checkpoint proves custody and continuity, never publisher-wide completeness.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from collections.abc import Callable, Iterable, Iterator
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

from rulespec_artifacts import LocalBlobWriter

from spicy_docs.transport.credentials import CredentialRefusedError, scrub_credential


class ResumeError(ValueError):
    """A retained checkpoint or a response cannot establish safe continuity."""


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _url(value: str) -> str:
    parts = urlsplit(value)
    secrets = {
        "api_key",
        "apikey",
        "api-key",
        "key",
        "token",
        "access_token",
        "x-amz-credential",
        "x-amz-signature",
        "x-amz-security-token",
    }
    if (
        parts.scheme != "https"
        or not parts.hostname
        or parts.username
        or parts.password
        or parts.fragment
        or any(k.lower() in secrets for k, _ in parse_qsl(parts.query))
    ):
        raise ResumeError("checkpoint requires a credential-free HTTPS locator")
    return value


def _write(path: Path, value: dict) -> None:
    descriptor, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    with os.fdopen(descriptor, "w") as output:
        json.dump(value, output, sort_keys=True)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    temporary.replace(path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _load(path: Path) -> dict:
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError) as error:
        raise ResumeError("checkpoint is missing or unreadable") from error
    if not isinstance(value, dict):
        raise ResumeError("checkpoint must be a JSON object")
    return value


def _sha(value: str) -> str:
    if not isinstance(value, str) or re.fullmatch(r"sha256:[0-9a-f]{64}", value) is None:
        raise ResumeError("expected a SHA-256 identity")
    return value


class PartialDownload:
    """One retained entity version, exclusively owned by a caller holding its run lock.

    Responses use the standard HTTPX shape (status_code, url, headers,
    iter_raw). Pass an already-open streaming response; this class makes no
    requests and never follows redirects or forwards credentials.
    """

    def __init__(self, directory: Path, *, selection_sha256: str, max_bytes: int):
        if type(max_bytes) is not int or max_bytes <= 0:
            raise ResumeError("max_bytes must be a positive integer")
        self.directory = directory
        self.selection = _sha(selection_sha256)
        self.max_bytes = max_bytes
        self.partial = directory / "partial.bin"
        self.receipt = directory / "partial.json"
        directory.mkdir(parents=True, exist_ok=True)

    def _state(self) -> dict:
        state = _load(self.receipt)
        if state.get("selection_sha256") != self.selection or state.get("max_bytes") != self.max_bytes:
            raise ResumeError("partial selection or byte budget changed")
        offset = state.get("bytes")
        if type(offset) is not int or not 0 <= offset <= self.max_bytes:
            raise ResumeError("invalid checkpoint byte offset")
        if self.partial.is_symlink() or not self.partial.is_file() or self.partial.stat().st_size < offset:
            raise ResumeError("retained partial is missing or shorter than its checkpoint")
        # A crash may leave an uncommitted suffix. Validate the committed prefix
        # before truncating that suffix; never silently bless changed local bytes.
        digest = hashlib.sha256()
        with self.partial.open("rb") as source:
            remaining = offset
            while remaining:
                chunk = source.read(min(remaining, 1024 * 1024))
                digest.update(chunk)
                remaining -= len(chunk)
        if "sha256:" + digest.hexdigest() != state.get("sha256"):
            raise ResumeError("retained partial prefix hash changed")
        if self.partial.stat().st_size > offset:
            with self.partial.open("r+b") as output:
                output.truncate(offset)
        return state

    def headers(self) -> dict[str, str]:
        """Require a strong version before requesting the exact remaining range."""
        state = self._state()
        if state["complete"]:
            raise ResumeError("download is already complete")
        if not state["etag"]:
            raise ResumeError(
                "safe range resume requires a strong original ETag; retain this attempt and start another"
            )
        return {"Accept-Encoding": "identity", "Range": f"bytes={state['bytes']}-", "If-Match": state["etag"]}

    def consume(self, response, *, requested_url: str, observed_at: str) -> dict:
        """Admit framing before appending; checkpoint a durable prefix on interruption."""
        requested_url = _url(requested_url)
        resolved = _url(str(response.url))
        status = response.status_code
        if status in {401, 403}:
            raise CredentialRefusedError(f"acquisition HTTP {status} access refused")
        if status == 412:
            raise ResumeError("entity version precondition failed")

        def header(name):
            values = response.headers.get_list(name)
            if len(values) > 1:
                raise ResumeError("repeated response framing header")
            return values[0].strip() if values else None

        if (header("Content-Encoding") or "identity").lower() != "identity":
            raise ResumeError("range transfer requires identity encoding")
        etag = header("ETag")
        strong = etag if etag and re.fullmatch(r'"[\x21\x23-\x7e\x80-\xff]*"', etag) else None
        length = header("Content-Length")
        if length is not None and re.fullmatch(r"[0-9]+", length) is None:
            raise ResumeError("invalid Content-Length")
        length = int(length) if length is not None else None
        content_range = header("Content-Range")
        if self.receipt.exists():
            state = self._state()
            if state["complete"]:
                raise ResumeError("download is already complete")
            if requested_url != state["requested_url"] or resolved != state["resolved_url"]:
                raise ResumeError("response locator differs from retained entity")
            if not state["etag"] or strong != state["etag"] or status != 206:
                raise ResumeError("resume requires HTTP 206 and the original strong ETag")
            match = re.fullmatch(r"bytes ([0-9]+)-([0-9]+)/([0-9]+)", content_range or "")
            if match is None:
                raise ResumeError("resume requires numeric Content-Range")
            start, end, total = map(int, match.groups())
            if (
                start != state["bytes"]
                or end != total - 1
                or total <= start
                or (state["total"] is not None and total != state["total"])
                or (length is not None and length != total - start)
            ):
                raise ResumeError("range does not cover the exact retained remainder")
            state["total"] = total
        else:
            if status != 200 or content_range is not None:
                raise ResumeError("initial transfer requires HTTP 200 without Content-Range")
            if self.partial.exists():
                raise ResumeError("unreceipted partial exists; retain it and choose another attempt directory")
            state: dict[str, Any] = {
                "format": "partial-download-v1",
                "selection_sha256": self.selection,
                "requested_url": requested_url,
                "resolved_url": resolved,
                "etag": strong,
                "total": length,
                "bytes": 0,
                "max_bytes": self.max_bytes,
                "sha256": "sha256:" + hashlib.sha256(b"").hexdigest(),
                "complete": False,
                "observations": [],
            }
            self.partial.touch(exist_ok=False)
        if state["total"] is not None and state["total"] > self.max_bytes:
            raise ResumeError("entity exceeds the selected byte budget")
        state["observations"].append({"observed_at": observed_at, "status": status, "offset": state["bytes"]})
        _write(self.receipt, state)
        with self.partial.open("ab") as output:
            try:
                for chunk in response.iter_raw():
                    if state["bytes"] + len(chunk) > self.max_bytes:
                        raise ResumeError("response exceeded the selected byte budget")
                    if state["total"] is not None and state["bytes"] + len(chunk) > state["total"]:
                        raise ResumeError("response exceeded its stated entity length")
                    output.write(chunk)
                    state["bytes"] += len(chunk)
                if state["bytes"] == 0 or (state["total"] is not None and state["bytes"] != state["total"]):
                    raise ResumeError("response ended before its complete entity length")
                state["complete"] = True
            finally:
                output.flush()
                os.fsync(output.fileno())
                state["sha256"] = _digest(self.partial)
                _write(self.receipt, state)
        return state

    def finish(self, *, store: Path, expected_sha256: str, expected_size: int) -> dict:
        """Validate the complete original and reuse the maintained blob writer."""
        state = self._state()
        if not state["complete"] or state["bytes"] != expected_size or state["sha256"] != _sha(expected_sha256):
            raise ResumeError("complete entity differs from selected size or digest")
        with self.partial.open("rb") as source:
            result = LocalBlobWriter(store).put(
                iter(lambda: source.read(1024 * 1024), b""),
                max_bytes=self.max_bytes,
                expected_digest=expected_sha256,
                expected_size=expected_size,
            )
        return {
            "sha256": result.digest,
            "bytes": result.byte_size,
            "blob_path": result.object_key,
            "reused": result.reused,
            "receipt": str(self.receipt),
        }


class TraversalCheckpoint:
    """Retain validated page pins and continuation without claiming a frozen crawl.

    Caller validates pages through the existing source reader before committing.
    Resume must replay retained pages through that reader's count/identity checks;
    a changing publisher requires a new traversal, preserving the old one.
    """

    def __init__(self, path: Path, *, selection_sha256: str, first_url: str):
        self.path = path
        selection = _sha(selection_sha256)
        first_url = _url(first_url)
        if path.exists():
            self.state: dict[str, Any] = _load(path)
            if self.state.get("selection_sha256") != selection or self.state.get("first_url") != first_url:
                raise ResumeError("traversal selection changed")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            self.state = {
                "format": "traversal-checkpoint-v1",
                "selection_sha256": selection,
                "first_url": first_url,
                "next_url": first_url,
                "pages": [],
                "complete": False,
            }
            _write(path, self.state)

    def commit(
        self, *, url: str, next_url: str | None, capture_sha256: str, declared_count: int | None, observed_at: str
    ) -> None:
        """Advance only after the caller retains and validates the exact page bytes."""
        url = _url(url)
        if self.state["complete"] or url != self.state["next_url"]:
            raise ResumeError("page differs from the pending continuation")
        if next_url is not None:
            next_url = _url(next_url)
            if next_url == url or any(p["url"] == next_url for p in self.state["pages"]):
                raise ResumeError("traversal repeats a continuation")
            if urlsplit(next_url).netloc != urlsplit(self.state["first_url"]).netloc:
                raise ResumeError("continuation leaves the selected host")
        pages = self.state["pages"]
        if pages and declared_count != pages[0]["declared_count"]:
            raise ResumeError("declared count changed; retain this traversal and start another")
        page = {
            "url": url,
            "next_url": next_url,
            "sha256": _sha(capture_sha256),
            "declared_count": declared_count,
            "observed_at": observed_at,
        }
        state = {
            **self.state,
            "pages": [*pages, page],
            "next_url": next_url,
            "terminal_observed": next_url is None,
            "complete": False,
        }
        _write(self.path, state)
        self.state = state

    def track(self, pages: Iterable, *, retain_capture: Callable, api_keys: tuple[str, ...] = ()) -> Iterator:
        """Commit page custody, then complete only after the original iterator validates exhaustion.

        ``retain_capture`` durably retains exact source bytes before returning.
        It is not invoked for already-pinned prefix pages. Early consumer exit
        leaves the traversal incomplete, including after a terminal page yield.
        """
        prefix = list(self.state["pages"])
        observed = 0
        try:
            for page in pages:
                if page.page_index != observed:
                    raise ResumeError("reader page order differs from checkpoint")
                if observed < len(prefix):
                    if (
                        page.capture.requested_url != prefix[observed]["url"]
                        or page.sha256 != prefix[observed]["sha256"]
                    ):
                        raise ResumeError("reader prefix differs from retained capture")
                else:
                    retain_capture(page.capture)
                    self.commit(
                        url=page.capture.requested_url,
                        next_url=page.next_url,
                        capture_sha256=page.sha256,
                        declared_count=page.declared_count,
                        observed_at=page.capture.observed_at,
                    )
                observed += 1
                yield page
        except Exception as error:
            state = {
                **self.state,
                "complete": False,
                "failures": [
                    *self.state.get("failures", []),
                    {
                        "pending_url": self.state["next_url"],
                        "reason": scrub_credential(str(error), *api_keys).replace("\n", " ")[:500],
                    },
                ],
            }
            _write(self.path, state)
            self.state = state
            raise
        if observed < len(prefix) or not observed or self.state["next_url"] is not None:
            raise ResumeError("reader ended without validating the selected terminal traversal")
        state = {**self.state, "complete": True}
        _write(self.path, state)
        self.state = state

    def verify_captures(self, captures: Iterable[Path]) -> None:
        """Check ordered local capture bytes before resuming validation or requests."""
        paths = list(captures)
        if len(paths) != len(self.state["pages"]):
            raise ResumeError("retained page selection differs from the checkpoint")
        for path, page in zip(paths, self.state["pages"], strict=True):
            if _digest(path) != page["sha256"]:
                raise ResumeError("retained page bytes changed")

    def replay_transport(self, captures: Iterable[Path], live):
        """Replay a verified GET prefix through the original reader before live HTTP.

        Start the reader at ``first_url`` with its original whole-walk budget
        and native identity checks. POST needs request-body pins and is not
        supported. The caller owns the live transport lifecycle.
        """
        import httpx

        paths = list(captures)
        self.verify_captures(paths)
        pages = self.state["pages"]
        checkpoint = self

        class FileStream(httpx.SyncByteStream):
            def __init__(self, path):
                self.path = path

            def __iter__(self):
                with self.path.open("rb") as source:
                    yield from iter(lambda: source.read(64 * 1024), b"")

        class PrefixTransport(httpx.BaseTransport):
            def __init__(self):
                self.index = 0

            def handle_request(self, request):
                if request.method != "GET":
                    raise ResumeError("retained-prefix replay supports GET only")
                if self.index < len(pages):
                    page = pages[self.index]
                    if str(request.url) != page["url"]:
                        raise ResumeError("reader request differs from retained prefix")
                    path = paths[self.index]
                    if _digest(path) != page["sha256"]:
                        raise ResumeError("retained page bytes changed before replay")
                    self.index += 1
                    return httpx.Response(
                        200, headers={"Content-Type": "application/json"}, stream=FileStream(path), request=request
                    )
                if (
                    self.index == len(pages)
                    and pages
                    and (checkpoint.state["complete"] or str(request.url) != checkpoint.state["next_url"])
                ):
                    raise ResumeError("live request differs from checkpoint continuation")
                self.index += 1
                return live.handle_request(request)

        return PrefixTransport()


class RetainedGetTraversal:
    """Use the original family walker with durable captures and native membership evidence.

    This consumer composes existing family readers, checkpoints and blob storage.
    It qualifies the observed selected traversal, never inventory stability or
    publisher deletion. Hold an exclusive caller run lock for ``directory``.
    """

    def __init__(self, directory: Path, *, selection: dict, first_url: str, max_page_bytes: int):
        if type(max_page_bytes) is not int or max_page_bytes <= 0:
            raise ResumeError("max_page_bytes must be positive")
        from spicy_docs.transport.credentials import scrub_record

        if scrub_record(selection) != selection:
            raise ResumeError("selection must not retain credentials")
        self.directory = directory
        self.max_page_bytes = max_page_bytes
        selection_bytes = json.dumps(selection, sort_keys=True, separators=(",", ":")).encode()
        self.selection_pin = "sha256:" + hashlib.sha256(selection_bytes).hexdigest()
        directory.mkdir(parents=True, exist_ok=True)
        manifest = directory / "selection.json"
        if manifest.exists():
            if _load(manifest) != selection:
                raise ResumeError("retained traversal selection changed")
        else:
            _write(manifest, selection)
        self.selection = selection
        self.progress = TraversalCheckpoint(
            directory / "checkpoint.json", selection_sha256=self.selection_pin, first_url=first_url
        )
        self.store = directory / "captures"
        self.writer = LocalBlobWriter(self.store)

    @staticmethod
    def _immutable_metadata(path: Path, value: dict) -> None:
        encoded = (json.dumps(value, sort_keys=True) + "\n").encode()
        if path.exists():
            if path.is_symlink() or path.read_bytes() != encoded:
                raise ResumeError("retained metadata differs from its content identity")
        else:
            _write(path, value)

    def _verify_metadata(self) -> None:
        for name in ("capture-receipts", "qualifications"):
            folder = self.directory / name
            for path in folder.glob("*.json"):
                value = _load(path)
                name_pin = hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
                if path.stem != name_pin:
                    raise ResumeError("retained metadata content identity changed")
                self._immutable_metadata(path, value)

    def run(
        self,
        *,
        reader_factory: Callable,
        walk: Callable,
        identity: Callable,
        live_transport,
        source_identity: str,
        api_keys: tuple[str, ...] = (),
    ) -> dict:
        """Walk from the first URL, validating retained prefix and all source checks.

        ``reader_factory(transport)`` returns the original context-managed family
        reader. ``walk(reader, first_url)`` returns its native page iterator, with
        the selected whole-walk bounds. ``identity(row)`` states the source's
        native identity, not a downstream table's interpretation.
        """
        if self.selection.get("source_identity") != source_identity:
            raise ResumeError("source identity differs from selected traversal")
        self._verify_metadata()
        paths = [self.store / "sha256" / p["sha256"][7:] for p in self.progress.state["pages"]]
        transport = self.progress.replay_transport(paths, live_transport)
        # Native/count checks may refuse after source page parsing but before
        # yielding to the consumer. Keep one bounded raw attempt for that case.
        from dataclasses import replace

        import httpx

        from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response, retain_refused_response
        from spicy_docs.transport.credentials import scrub_record

        last_attempt: dict[str, Any] = {}
        byte_bound = self.max_page_bytes

        class ObservedTransport(httpx.BaseTransport):
            def handle_request(self, request):
                last_attempt.clear()
                last_attempt.update(url=str(request.url), body=bytearray(), complete=False)
                response = transport.handle_request(request)
                last_attempt["media_type"] = response.headers.get("Content-Type", "application/octet-stream")
                original = response.stream

                class ObservedStream(httpx.SyncByteStream):
                    def __iter__(self):
                        for chunk in original:
                            if len(last_attempt["body"]) + len(chunk) <= byte_bound:
                                last_attempt["body"].extend(chunk)
                            else:
                                last_attempt["over_bound"] = True
                            yield chunk
                        last_attempt["complete"] = True

                    def close(self):
                        original.close()

                response.stream = ObservedStream()
                return response

        native_ids: set[str] = set()

        def retain(capture):
            if capture.method != "GET" or capture.request_body is not None or capture.content_encoding != "identity":
                raise ResumeError("retained consumer supports identity-encoded GET captures only")
            self.writer.put(
                [capture.body],
                max_bytes=self.max_page_bytes,
                expected_digest=capture.sha256,
                expected_size=capture.byte_size,
            )
            receipt = {
                "requested_url": capture.requested_url,
                "resolved_url": capture.resolved_url,
                "status_code": capture.status_code,
                "content_type": capture.content_type,
                "observed_at": capture.observed_at,
                "sha256": capture.sha256,
                "bytes": capture.byte_size,
            }
            receipt_name = hashlib.sha256(json.dumps(receipt, sort_keys=True).encode()).hexdigest() + ".json"
            receipts = self.directory / "capture-receipts"
            receipts.mkdir(exist_ok=True)
            path = receipts / receipt_name
            self._immutable_metadata(path, receipt)

        try:
            with reader_factory(ObservedTransport()) as reader:

                def checked_pages():
                    for page in walk(reader, self.progress.state["first_url"]):
                        for row in page.records:
                            value = identity(row)
                            if not isinstance(value, str) or not value or value != value.strip() or value in native_ids:
                                raise ResumeError("native inventory identity is missing, padded or repeated")
                            native_ids.add(value)
                        yield page

                for _page in self.progress.track(checked_pages(), retain_capture=retain, api_keys=api_keys):
                    pass
        except Exception as error:
            if (
                not isinstance(error, CredentialRefusedError)
                and last_attempt.get("complete")
                and not last_attempt.get("over_bound")
            ):
                attach_refused_response(
                    error,
                    RefusedResponse(
                        last_attempt["url"],
                        "traversal-validation",
                        bytes(last_attempt["body"]),
                        last_attempt["media_type"],
                    ),
                )
            refusal = getattr(error, "refused_response", None)
            if (
                isinstance(refusal, RefusedResponse)
                and refusal.response_bytes is not None
                and any(key and key.encode() in refusal.response_bytes for key in api_keys)
            ):
                error.__dict__["refused_response"] = replace(
                    refusal,
                    response_bytes=None,
                    unavailable_reason="credential echoed in response; bytes not retained",
                )
            receipt = retain_refused_response(
                error,
                store=self.store,
                max_bytes=self.max_page_bytes,
                credential=api_keys[0] if api_keys else "",
            )
            failures = list(self.progress.state.get("failures", []))
            # track normally records the reason. Factory/admission failures can
            # happen before it starts, so retain an actionable failure there too.
            if (
                not failures
                or failures[-1]["reason"] != scrub_credential(str(error), *api_keys).replace("\n", " ")[:500]
            ):
                failures.append(
                    {
                        "pending_url": self.progress.state["next_url"],
                        "reason": scrub_credential(str(error), *api_keys).replace("\n", " ")[:500],
                    }
                )
            failures[-1] = {**failures[-1], "refusal": scrub_record(receipt, *api_keys)}
            state = {**self.progress.state, "complete": False, "failures": failures}
            _write(self.progress.path, state)
            self.progress.state = state
            raise
        report = {
            "format": "retained-get-traversal-qualification-v1",
            "source_identity": source_identity,
            "selection_sha256": self.selection_pin,
            "consumer_code_sha256": _digest(Path(__file__)),
            "selection": self.selection,
            "status": "complete-observed-traversal",
            "inventory_stable": False,
            "native_identity_count": len(native_ids),
            "native_identity_set_sha256": "sha256:"
            + hashlib.sha256(json.dumps(sorted(native_ids)).encode()).hexdigest(),
            "checkpoint_sha256": _digest(self.progress.path),
            "pages": self.progress.state["pages"],
            "failures": self.progress.state.get("failures", []),
            "limits": "Original family reader completed and native identity membership checked. No frozen publisher population, semantic update watermark or deletion is proved.",
        }
        report_name = hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest() + ".json"
        reports = self.directory / "qualifications"
        reports.mkdir(exist_ok=True)
        self._immutable_metadata(reports / report_name, report)
        return report
