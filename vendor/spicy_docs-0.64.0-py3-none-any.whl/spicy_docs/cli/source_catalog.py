"""Explicit metadata replay and refresh; no automatic source crawl."""

from __future__ import annotations

import argparse
import gzip
import json
from datetime import UTC, datetime
from pathlib import Path

from spicy_docs.sources.source_catalog import KINDS, MAX_METADATA_BYTES, parse_metadata, refresh_metadata
from spicy_docs.transport.credentials import failure_reason, scrub_record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("replay", "refresh"))
    parser.add_argument("--kind", required=True, choices=KINDS)
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--capture", required=True, type=Path, help="Retained input or new capture destination")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--observed-at", help="Original capture time (required for replay)")
    parser.add_argument("--sha256", help="Decoded payload pin (required for replay)")
    parser.add_argument("--content-type")
    parser.add_argument("--bucket")
    parser.add_argument("--prefix")
    args = parser.parse_args(argv)
    options = {"bucket": args.bucket, "prefix": args.prefix}
    if args.operation == "replay":
        if not args.observed_at or not args.sha256:
            parser.error("replay requires original --observed-at and --sha256")
        with gzip.open(args.capture, "rb") if args.capture.suffix == ".gz" else args.capture.open("rb") as stream:
            body = stream.read(MAX_METADATA_BYTES + 1)
        result = parse_metadata(
            body,
            kind=args.kind,
            namespace=args.namespace,
            capture_url=args.url,
            observed_at=args.observed_at,
            sha256=args.sha256,
            content_type=args.content_type,
            **options,
        )
    else:
        # A requested refresh is distinct from replay; never replace retained evidence.
        if args.capture.exists() or args.capture.with_suffix(args.capture.suffix + ".json").exists():
            parser.error("refresh capture destination already exists; replay it or select a new destination")
        from httpx import HTTPError

        from spicy_docs.transport.capture import BoundedHttpCapture
        from spicy_docs.transport.credentials import CredentialRefusedError

        client = BoundedHttpCapture(
            max_requests=1,
            timeout_seconds=30,
            min_request_interval_seconds=0,
            user_agent="SpicyDocs metadata discovery",
            error_type=ValueError,
            transport=None,
            clock=lambda: datetime.now(UTC),
            retain_refusal_bodies=True,
        )
        try:
            capture, result = refresh_metadata(client, args.url, kind=args.kind, namespace=args.namespace, **options)
        except (ValueError, ConnectionError, CredentialRefusedError, HTTPError) as error:
            from spicy_docs.reading.refusals import retain_refused_response

            args.output.parent.mkdir(parents=True, exist_ok=True)
            refusal = retain_refused_response(
                error, store=args.capture.parent / "refused-metadata", max_bytes=MAX_METADATA_BYTES
            )
            receipt = scrub_record(
                {
                    "url": args.url,
                    "status": "acquisition-failed",
                    "message": failure_reason(error),
                    "refusal": refusal,
                    "observed_at": datetime.now(UTC).isoformat(),
                }
            )
            args.output.write_text(json.dumps(receipt, indent=2) + "\n")
            return 1
        finally:
            client.close()
        args.capture.parent.mkdir(parents=True, exist_ok=True)
        with args.capture.open("xb") as stream:
            stream.write(capture.body)
        receipt = {
            "url": capture.requested_url,
            "observed_at": capture.observed_at,
            "sha256": capture.sha256,
            "content_type": capture.content_type,
            "status_code": capture.status_code,
            "bytes": capture.byte_size,
        }
        args.capture.with_suffix(args.capture.suffix + ".json").write_text(json.dumps(receipt, indent=2) + "\n")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
