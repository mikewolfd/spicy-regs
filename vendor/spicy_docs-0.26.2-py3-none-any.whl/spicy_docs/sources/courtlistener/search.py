"""CourtListener v4 search: RECAP dockets and opinion clusters, page by page with exact evidence.

The public ``/search/`` endpoint answers ``count``, ``next`` and ``results`` with an opaque cursor,
and cursor pagination requires ``dateFiled`` ordering; ``type=r`` lists RECAP dockets (with a
``document_count`` beside ``count``) and ``type=o`` lists opinion clusters. Keyless requests are
served at a lower rate limit and a token travels as ``Authorization: Token <token>``, while the bulk
exports remain the route for whole-collection work.

Docket counts (``type=r`` and ``type=d``) above 2,000 may be cardinality
estimates; their explicit terminal cursor establishes traversal completion.
Smaller docket counts and opinion counts retain exact-count checks. Publisher explanation: https://wiki.free.law/c/courtlistener/help/api/rest/v4/search#result-counts
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterator, Mapping
from datetime import date as Date
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal
from urllib.parse import urlencode

from spicy_docs.reading.paged_json import (
    DEFAULT_MAX_PAGES,
    JsonPage,
    JsonPageFamily,
    PagedJsonBudget,
    PagedJsonReader,
    PagedJsonSourceError,
    query_value,
)
from spicy_docs.transport.source_acquirer import utc_now

if TYPE_CHECKING:
    import httpx

API = "https://www.courtlistener.com/api/rest/v4"
RESULTS_KEY = "results"
type SearchKind = Literal["r", "o"]
type SearchOrder = Literal["dateFiled asc", "dateFiled desc"]
COURTLISTENER = JsonPageFamily(
    name="courtlistener",
    label="CourtListener",
    host="www.courtlistener.com",
    next_path=("next",),
    count_path=("count",),
    credential_header="Authorization",
    credential_format="Token {key}",
    requires_credential=False,
)
_COURT = re.compile(r"[a-z0-9]{1,32}")


def is_exact_count(kind: str | None, declared_count: int | None) -> bool:
    """Keep small-count checks; the publisher documents docket estimates above 2,000."""
    return kind not in ("r", "d") or declared_count is None or declared_count <= 2_000


def _filed(value: str | None, name: str) -> str | None:
    """The search endpoint takes MM/DD/YYYY; callers pass ISO dates."""
    if value is None:
        return None
    if not isinstance(value, str) or re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value) is None:
        raise PagedJsonSourceError(f"{name} must use YYYY-MM-DD")
    try:
        parsed = Date.fromisoformat(value)
    except ValueError as error:
        raise PagedJsonSourceError(f"{name} must be a valid calendar date") from error
    return parsed.strftime("%m/%d/%Y")


def search_url(
    *,
    kind: SearchKind,
    filed_after: str | None = None,
    filed_before: str | None = None,
    order_by: SearchOrder = "dateFiled asc",
    court: str | None = None,
    nature_of_suit: str | None = None,
    q: str | None = None,
) -> str:
    if kind not in ("r", "o"):
        raise PagedJsonSourceError("kind must be 'r' (RECAP dockets) or 'o' (opinion clusters)")
    if order_by not in ("dateFiled asc", "dateFiled desc"):
        raise PagedJsonSourceError("cursor pagination requires dateFiled ordering")
    if court is not None and (not isinstance(court, str) or _COURT.fullmatch(court) is None):
        raise PagedJsonSourceError("court must be a lowercase CourtListener court identifier")
    query: list[tuple[str, str]] = [("type", kind), ("order_by", order_by)]
    for name, value in (
        ("filed_after", _filed(filed_after, "filed_after")),
        ("filed_before", _filed(filed_before, "filed_before")),
    ):
        if value is not None:
            query.append((name, value))
    for name, value in (("court", court), ("nature_of_suit", nature_of_suit), ("q", q)):
        if value is not None:
            if not isinstance(value, str) or not value.strip() or len(value) > 512:
                raise PagedJsonSourceError(f"{name} must be a nonempty string of at most 512 characters")
            query.append((name, value))
    return f"{API}/search/?{urlencode(query)}"


class CourtListenerSearchReader(PagedJsonReader):
    def __init__(
        self,
        *,
        budget: PagedJsonBudget,
        api_key: str | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        super().__init__(family=COURTLISTENER, budget=budget, api_key=api_key, transport=transport, clock=clock)

    def _count_is_exact(self, url: str, declared_count: int | None) -> bool:
        return is_exact_count(query_value(url, "type"), declared_count)

    def _continuation(
        self, value: Mapping[str, Any], *, url: str, body: Mapping[str, Any] | None, rows: list
    ) -> tuple[str | None, Mapping[str, Any] | None]:
        if "next" not in value:
            raise PagedJsonSourceError("CourtListener search omitted its next cursor")
        return super()._continuation(value, url=url, body=body, rows=rows)

    def search(self, url: str, *, max_pages: int = DEFAULT_MAX_PAGES) -> Iterator[JsonPage]:
        observed = 0
        for page in self.pages(url, records_key=RESULTS_KEY, max_pages=max_pages):
            if page.declared_count is None:
                raise PagedJsonSourceError("CourtListener search omitted its declared count")
            observed += len(page.records)
            if page.next_url is None and not observed and page.declared_count:
                raise PagedJsonSourceError("CourtListener empty search has a positive declared count")
            yield page
