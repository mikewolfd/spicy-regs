"""Carry exact refused response bytes to the caller without changing the error.

Source adapters attach only bounded publisher response bodies and safe request
identifiers. Transport credentials, provider responses, and request headers do
not belong here. ``None`` means unavailable; ``b""`` is an exact empty response.
``stated_byte_size`` is the response's own ``Content-Length``, where it stated
one: a body refused at the byte bound before any of it was read has no observed
size, and the stated one is what a caller can compare the next answer with.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from spicy_docs.storage.blobs import SourceNativeBlobStore


@dataclass(frozen=True)
class RefusedResponse:
    request_key: str
    stage: str
    response_bytes: bytes | None = field(repr=False)
    media_type: str
    unavailable_reason: str | None = None
    observed_byte_size: int | None = None
    stated_byte_size: int | None = None


def attach_refused_response(error: Exception, response: RefusedResponse) -> None:
    """Preserve the error and any more precise context attached by its origin."""
    if not isinstance(getattr(error, "refused_response", None), RefusedResponse):
        error.__dict__["refused_response"] = response


def retain_refused_response(
    error: Exception, *, store: Path | SourceNativeBlobStore, max_bytes: int, credential: str = ""
) -> dict | None:
    """Keep bounded source-validation evidence when parsing fails before storage."""
    import hashlib

    from rulespec_artifacts import BlobLimitError, LocalBlobWriter

    from spicy_docs.storage.blobs import SourceNativeBlobStore
    from spicy_docs.transport.credentials import scrub_credential

    response = getattr(error, "refused_response", None)
    if not isinstance(response, RefusedResponse):
        return None
    result = {
        "request_key": scrub_credential(response.request_key, credential),
        "stage": response.stage,
        "media_type": response.media_type,
        "unavailable_reason": response.unavailable_reason,
        "observed_byte_size": response.observed_byte_size,
    }
    if response.stated_byte_size is not None:
        result["stated_byte_size"] = response.stated_byte_size
    if response.response_bytes is not None:
        if credential and credential.encode() in response.response_bytes:
            result["unavailable_reason"] = "credential echoed in response; bytes not retained"
        else:
            if isinstance(store, SourceNativeBlobStore):
                if type(max_bytes) is not int or max_bytes < 0:
                    raise ValueError("max_bytes must be a non-negative integer")
                size = len(response.response_bytes)
                if size > max_bytes:
                    raise BlobLimitError("refused response exceeds the byte limit")
                digest = "sha256:" + hashlib.sha256(response.response_bytes).hexdigest()
                written = store.put_blob(digest, size, [response.response_bytes])
                result.update(sha256=written.blob_ref, bytes=written.byte_size)
            else:
                written = LocalBlobWriter(store).put([response.response_bytes], max_bytes=max_bytes)
                result.update(sha256=written.digest, bytes=written.byte_size)
    return result
