"""Read the qualified native House PTR grid, retaining cross-page row evidence.

This is a deterministic reader over the maintained PyMuPDF positional helpers.
Image/paper forms, unfamiliar layouts and unplaced rows remain explicit failures.
Native blank ownership is an empty string. A report's new and amended rows stay
distinct; this module does not guess which earlier report an amendment replaces.
"""

from __future__ import annotations

import hashlib
import re
from importlib.metadata import version

from spicy_docs.reading.pdf_grid import display_words, literal, visual_lines
from spicy_docs.sources.house_disclosures import HouseDisclosureError, validate_pdf

PARSER_VERSION = "house-ptr-native-v2"
_STATUS = "Fʋʎʋʐʉ Sʖʃʖʗʕ:"
_HEADERS = ("ID", "Owner", "Asset", "Transaction", "Date", "Notification", "Amount", "Cap.")
_DATE = re.compile(r"[0-9]{2}/[0-9]{2}/[0-9]{4}")
_ACTION = re.compile(r"(?:P|S(?: \((?:partial|full)\))?|E)")
_FILER_LABELS = {"Name:", "Status:", "State/District:"}
_SIGNATURE = re.compile(r"Digitally Signed:[ \t]*(.+?\S)[ \t]*,[ \t]*([0-9]{2}/[0-9]{2}/[0-9]{4})")


def _labeled_value(lines, label):
    """Read one value on its native label's visual row, never the following field.

    The retained native originals put label and value on one visual row even
    though their PDF text stream separates them with a newline. A missing,
    repeated or differently placed field remains unresolved; a signature is
    never substituted for the labeled name.
    """
    matches = [line for line in lines if line and line[0]["text"] == label]
    if len(matches) != 1:
        return None
    value = matches[0][1:]
    if not value or any(word["text"] in _FILER_LABELS for word in value):
        return None
    return literal(value)


def _header(lines):
    for line in lines:
        if tuple(w["text"] for w in line) == _HEADERS:
            return line
    return None


def _fragment(page, words):
    return {
        "page_number": page,
        "bbox": [
            min(w["bbox"][0] for w in words),
            min(w["bbox"][1] for w in words),
            max(w["bbox"][2] for w in words),
            max(w["bbox"][3] for w in words),
        ],
        "words": [{"index": w["index"], "text": w["text"], "bbox": w["bbox"]} for w in words],
    }


def read_ptr_pdf(body: bytes, *, doc_id: str, max_pages: int = 100) -> dict:
    """Read every selected page or return no qualified transactions and a reason.

    This bound covers page visitation only, not decompression or a wall-clock
    budget. Callers own process resource admission. No OCR or model is invoked.
    Checkbox values are retained in original page regions, not inferred from
    missing native text. ``native_layout`` qualifies the declared printed cells,
    not every visual mark or all House report formats.
    """
    import pymupdf

    validate_pdf(body)
    if type(max_pages) is not int or max_pages < 1:
        raise ValueError("max_pages must be a positive integer")
    if not isinstance(doc_id, str) or re.fullmatch(r"[0-9]+", doc_id) is None:
        raise HouseDisclosureError("House DocID must contain only ASCII digits")
    result = {
        "doc_id": doc_id,
        "source_sha256": "sha256:" + hashlib.sha256(body).hexdigest(),
        "parser_version": PARSER_VERSION,
        "backend": "pymupdf",
        "backend_version": version("pymupdf"),
        "model": None,
        "status": "refused",
        "reason": None,
        "pages": [],
        "transactions": [],
    }
    with pymupdf.open(stream=body, filetype="pdf") as document:
        result["page_count"] = len(document)
        if document.is_encrypted:
            result["reason"] = "encrypted_pdf"
            return result
        if len(document) > max_pages:
            result["reason"] = "page_budget_exceeded"
            return result
        pending = []
        previous = None
        refusals = []
        ids = set()
        signatures = []
        for page_number, page in enumerate(document, 1):
            words = display_words(page)
            lines = visual_lines(words)
            text = page.get_text()
            if page_number == 1:
                result["filer_name_raw"] = _labeled_value(lines, "Name:")
                result["state_district_raw"] = _labeled_value(lines, "State/District:")
            for line in lines:
                raw = literal(line)
                if raw.startswith("Digitally Signed:"):
                    signatures.append(_SIGNATURE.fullmatch(raw))
            ids.update(re.findall(r"Filing ID #([0-9]+)", text))
            page_result = {"page_number": page_number, "native_text": text, "status": "native_supplement"}
            result["pages"].append(page_result)
            # A large image can contain transactions missing from a native layer.
            # The small first-page seal is allowed; scanned/mixed pages refuse.
            image_area = sum(pymupdf.Rect(info["bbox"]).get_area() for info in page.get_image_info())
            if not words or image_area > page.rect.get_area() * 0.1:
                page_result["status"] = "unsupported_image_page"
                refusals.append(f"image_page:{page_number}")
                continue
            header = _header(lines)
            if header is None:
                # A qualified native report can finish with vehicle details and
                # the certification. An arbitrary text page is not an empty grid.
                if _STATUS in text or not any(
                    label in text for label in ("Digitally Signed:", "Iʐʘʇʕʖʏʇʐʖ Vʇʊʋʅʎʇ Dʇʖʃʋʎʕ")
                ):
                    page_result["status"] = "unsupported_native_layout"
                    refusals.append(f"unknown_layout:{page_number}")
                continue
            page_result["status"] = "native_grid"
            starts = [w["bbox"][0] - 1 for w in header]
            header_y = header[0]["y"]
            # Header's last line is the dollar threshold. The source footnote
            # terminates the grid; continuation pages need no invented footer.
            top = max(w["bbox"][3] for w in words if header_y - 1 <= w["y"] <= header_y + 25)
            foot = [line[0]["bbox"][1] for line in lines if literal(line).startswith("* For the complete list")]
            bottom = min(foot) if foot else page.rect.height
            grid_lines = [line for line in lines if top < line[0]["y"] < bottom]
            anchors = []
            for pos, line in enumerate(grid_lines):
                action = literal([w for w in line if starts[3] <= w["bbox"][0] < starts[4]])
                date = literal([w for w in line if starts[4] <= w["bbox"][0] < starts[5]])
                if _ACTION.fullmatch(action) and _DATE.fullmatch(date):
                    anchors.append(pos)
            # Keep leading details with the transaction begun on the prior page.
            leading = [w for line in grid_lines[: anchors[0] if anchors else len(grid_lines)] for w in line]
            if leading:
                if previous is None:
                    refusals.append(f"unplaced_content:{page_number}")
                else:
                    previous.append((page_number, starts, leading))
            for i, pos in enumerate(anchors):
                end = anchors[i + 1] if i + 1 < len(anchors) else len(grid_lines)
                previous = [(page_number, starts, [w for line in grid_lines[pos:end] for w in line])]
                pending.append(previous)
        if ids != {doc_id}:
            refusals.append("native_filing_id_mismatch_or_missing")
        if not result.get("filer_name_raw"):
            refusals.append("native_filer_name_missing_or_ambiguous")
        if not result.get("state_district_raw"):
            refusals.append("native_district_missing_or_ambiguous")
        if len(signatures) != 1 or signatures[0] is None:
            refusals.append("native_signature_name_missing_or_ambiguous")
        else:
            result["signature_name_raw"], result["signed_date_raw"] = signatures[0].groups()
            if result.get("filer_name_raw") and (
                " ".join(result["filer_name_raw"].split()) != " ".join(result["signature_name_raw"].split())
            ):
                refusals.append("native_header_signature_name_mismatch")
        if refusals:
            result["reason"] = ";".join(refusals)
            return result
        transactions = []
        for row_number, fragments in enumerate(pending, 1):
            cells = [[] for _ in range(8)]
            statuses = []
            details = []
            in_details = False
            evidence = []
            for number, starts, words in fragments:
                evidence.append(_fragment(number, words))
                for line in visual_lines(words):
                    raw = literal(line)
                    if _STATUS in raw or "Filing Status:" in raw:
                        statuses.append(raw.split(":", 1)[1].strip())
                        in_details = True
                    if in_details:
                        details.append(raw)
                    else:
                        for col in range(8):
                            selected = [
                                w for w in line if starts[col] <= w["bbox"][0] < (starts[col + 1] if col < 7 else 10000)
                            ]
                            if selected:
                                cells[col].append(literal(selected))
            values = ["\n".join(cell) for cell in cells]
            if len(statuses) != 1 or statuses[0] not in {"New", "Amended"} or not values[2]:
                result["reason"] = f"unqualified_row:{row_number}"
                return result
            if (
                not _ACTION.fullmatch(" ".join(values[3].split()))
                or not _DATE.fullmatch(values[4])
                or not _DATE.fullmatch(values[5])
            ):
                result["reason"] = f"unqualified_cells:{row_number}"
                return result
            transactions.append(
                {
                    "row_number": row_number,
                    "page_number": fragments[0][0],
                    "page_end": fragments[-1][0],
                    "native_transaction_id": values[0],
                    "owner_raw": values[1],
                    "asset_raw": values[2],
                    "action_raw": values[3],
                    "transaction_date_raw": values[4],
                    "notification_date_raw": values[5],
                    "amount_raw": values[6],
                    "filing_status_raw": statuses[0],
                    "details_raw": "\n".join(details),
                    "fragments": evidence,
                    "capital_gains_read_status": "checkbox_not_qualified",
                }
            )
        # An unexplained no-row document cannot establish an empty PTR.
        if not transactions:
            result["reason"] = "no_qualified_transaction_rows"
            return result
        result.update(status="native_layout", transactions=transactions)
        return result
