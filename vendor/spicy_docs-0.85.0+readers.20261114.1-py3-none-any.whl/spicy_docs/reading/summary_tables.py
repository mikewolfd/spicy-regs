"""Shared native observations and exact numeric cells for ruled summaries."""

from __future__ import annotations

import re
from dataclasses import asdict
from decimal import Decimal

from spicy_docs.extraction import DocumentExtractor, NativeText


def summary_number(value, scale):
    """Pad a printed number to its column unit, preserving blanks and refusing rounding."""
    if value is None or not value.strip():
        return None
    literal = value.strip()
    negative = literal.startswith("(") and literal.endswith(")")
    if negative:
        literal = literal[1:-1]
        if literal.startswith(("-", "+")):
            raise ValueError("Conflicting signs in a printed numeric cell")
    pattern = r"-?(?:\$\s*)?(?:\d{1,3}(?:,\d{3})+|\d+)" + (rf"(?:\.\d{{1,{scale}}})?" if scale else "")
    if re.fullmatch(pattern, literal) is None:
        raise ValueError("Unrecognized printed numeric cell")
    number = Decimal(literal.replace(",", "").replace("$", "").strip())
    return format(-number if negative else number, f".{scale}f")


def summary_blocks(page, *, above=None):
    """Return observed native lines in displayed order, optionally above a table."""
    return sorted(
        (
            block
            for observation in page.content.observations
            for block in observation.blocks
            if block.box is not None and (above is None or (block.box.y0 + block.box.y1) / 2 < above)
        ),
        key=lambda block: (block.box.y0, block.box.x0),
    )


def native_summary_pages(body, *, rule, pages=None, source_page_numbers=None):
    """Yield maintained extraction observations and their common source identity."""
    mapping = dict(source_page_numbers or {})
    checked_mapping = False
    extractor = DocumentExtractor(NativeText(), tables=True, max_input_bytes=512 * 1024**2)
    for page in extractor.extract(body, media_type="application/pdf", pages=pages):
        if not checked_mapping:
            selected = pages if pages is not None else range(1, page.metadata["page_count"] + 1)
            if mapping and (
                set(mapping) != set(selected)
                or len(set(mapping.values())) != len(mapping)
                or any(type(number) is not int or number < 1 for number in mapping.values())
            ):
                raise ValueError("An excerpt map must uniquely name every selected original page")
            checked_mapping = True
        yield (
            page,
            {
                "rule": rule,
                "source_sha256": "sha256:" + page.metadata["source_sha256"],
                "page": page.metadata["page"],
                "source_page": mapping.get(page.metadata["page"], page.metadata["page"]),
                "physical_pages": page.metadata["page_count"],
                "geometry": page.metadata["geometry"],
                "native_text": page.text,
                "tables": [asdict(table) for table in page.tables],
                "records": [],
                "issues": [],
            },
        )
