"""Bounded Atom feed structure and exact entry spans, without a markup event list.

The existing XML reader owns encoding, entity and depth checks. Source adapters
interpret the returned elements; foreign extensions and repeated entry IDs stay
in the source tree. UTF-8 is required for the original-byte entry locators.
"""

from __future__ import annotations

from dataclasses import dataclass
from xml.etree.ElementTree import Element

from spicy_docs.reading.xml import parse_xml_with_spans

ATOM = "{http://www.w3.org/2005/Atom}"
XML_BASE = "{http://www.w3.org/XML/1998/namespace}base"


@dataclass(frozen=True, slots=True)
class AtomDocument:
    root: Element
    entries: tuple[Element, ...]
    entry_spans: dict[Element, tuple[int, int]]


def read_atom_feed(
    body: bytes,
    *,
    max_bytes: int,
    error_type: type[ValueError],
    label: str,
    max_entries: int = 10_000,
) -> AtomDocument:
    """Read a complete Atom feed, preserving order, extensions and duplicate IDs.

    An empty feed is a valid observation. Malformed or oversized inputs refuse
    as a whole; no partial list is returned as a completed feed.
    """
    if type(max_entries) is not int or max_entries < 0:
        raise error_type("max_entries must be a nonnegative integer")
    root, spans = parse_xml_with_spans(
        body,
        path=(ATOM + "feed", ATOM + "entry"),
        max_bytes=max_bytes,
        error_type=error_type,
        label=label,
    )
    if root.tag != ATOM + "feed":
        raise error_type(f"{label} is not an Atom feed")
    entries = tuple(child for child in root if child.tag == ATOM + "entry")
    if len(entries) > max_entries:
        raise error_type(f"{label} lists more entries than supported")
    return AtomDocument(root, entries, spans)
