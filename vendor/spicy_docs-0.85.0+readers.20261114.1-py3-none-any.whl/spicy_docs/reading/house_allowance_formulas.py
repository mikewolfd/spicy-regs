"""Read stated House allowance formula facts without calculating member allowances."""

from __future__ import annotations

import hashlib
import json
import re
from calendar import month_name
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from importlib.resources import files

from spicy_docs.reading.financial_lines import financial_lines
from spicy_docs.reading.house_allowance_summaries import _TITLE, _section
from spicy_docs.reading.summary_tables import native_summary_pages, summary_blocks, summary_number

RULE = "house-native-allowance-formulas/1"
SOURCE_RESOURCES = ("house_allowance_formulas_corrections.json", "house_allowance_formulas_annotations.json")
_CORRECTIONS = json.loads(files("spicy_docs.reading").joinpath(SOURCE_RESOURCES[0]).read_text())
_ANNOTATIONS = json.loads(files("spicy_docs.reading").joinpath(SOURCE_RESOURCES[1]).read_text())
NUMBER = r"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?"
MONEY = rf"\$\s*{NUMBER}"
PERCENT = rf"(?:{NUMBER}\s*(?:%|percent)|ten percent)"


class _Text:
    """A whitespace-normalized reading view with exact original native fragments."""

    def __init__(self, blocks, indices):
        self.blocks = blocks
        self.tokens = []
        words = []
        offset = 0
        for index in indices:
            for match in re.finditer(r"\S+", blocks[index]["text"]):
                self.tokens.append((offset, offset + len(match[0]), index, match.start()))
                words.append(match[0])
                offset += len(match[0]) + 1
        self.text = " ".join(words)

    def witness(self, start, end):
        fragments = []
        for left, right, block, original in self.tokens:
            begin, finish = max(left, start), min(right, end)
            if begin >= finish:
                continue
            begin, finish = original + begin - left, original + finish - left
            if fragments and fragments[-1]["block"] == block:
                fragments[-1]["end"] = finish
            else:
                fragments.append({"block": block, "start": begin, "end": finish})
        return {"start": start, "end": end, "fragments": fragments}

    def raw(self, origin):
        return "\n".join(self.blocks[f["block"]]["text"][f["start"] : f["end"]] for f in origin["fragments"])


def _number(literal, scale):
    value = " ".join(literal.split())
    value = re.sub(r"\s*(?:%|percent)$", "", value, flags=re.IGNORECASE)
    value = {"one": "1", "two": "2", "three": "3", "ten": "10"}.get(value.casefold(), value)
    if value.startswith("."):
        value = "0" + value
    return summary_number(value, scale)


PARAMETERS = (
    ("main_component_count", "formula", 0, "components", r"(?:based on|following) (?P<value>three) component"),
    ("official_expense_subcomponent_count", "office", 0, "components", r"following (?P<value>two) subcomponents"),
    ("standard_office_component_count", "office", 0, "components", r"Based on (?P<value>one) standard"),
    ("variable_office_component_count", "office", 0, "components", r"standard and (?P<value>two) variable components"),
    (
        "clerk_hire_base",
        "staffing",
        2,
        "USD",
        rf"(?:Standard clerk-hire figure for all Members:\s*|Clerk-hire \(personnel compensation\).*?For \d{{4}} this amount is\s*|Staffing\s*[–—-]\s*Base amount of\s*|A clerk-hire base amount of\s*|Clerk-Hire Component:\s*Standard amount of\s*)(?P<value>{MONEY})",
    ),
    ("office_base", "office", 2, "USD", rf"(?:A base amount of|Office: Standard amount of)\s*(?P<value>{MONEY})"),
    (
        "mileage_multiplier",
        "travel",
        0,
        "factor",
        rf"dollar equivalent of (?P<value>{NUMBER})(?=\s*(?:x|multiplied|\())",
    ),
    ("round_trips", "travel", 0, "round_trips", rf"\((?P<value>{NUMBER}) rounds? trips\)"),
    ("mileage_increase", "travel", 2, "percent", rf"plus (?P<value>{PERCENT})"),
    ("travel_minimum", "travel", 2, "USD", rf"In no case,? shall this amount be less than (?P<value>{MONEY})"),
    ("office_area", "district_office_rent", 0, "square_feet", rf"dollar equivalent of (?P<value>{NUMBER}) square feet"),
    (
        "mail_multiplier",
        "official_mail",
        0,
        "factor",
        rf"(?P<value>{NUMBER}) (?:times|x) (?:the single-piece|the (?:sum|product)|first class)",
    ),
    ("mail_percentage", "official_mail", 2, "percent", rf"set the amount at (?P<value>{PERCENT})"),
    ("travel_base", "travel", 2, "USD", rf"Base amount \((?P<value>{MONEY})\)"),
    ("one_way_trips", "travel", 0, "one_way_trips", rf"assumes (?P<value>{NUMBER}) one-way trips"),
    ("member_one_way_trips", "travel", 0, "one_way_trips", rf"\((?P<value>{NUMBER}) Member/"),
    ("staff_one_way_trips", "travel", 0, "one_way_trips", rf"Member/(?P<value>{NUMBER}) Staff\)"),
    ("lodging_and_meals_days", "travel", 0, "days", rf"(?P<value>{NUMBER}) days of lodging and meals"),
    ("office_expense_lookback", "office", 0, "years", rf"over the last (?P<value>{NUMBER}) years"),
)
PARAMETER_SPECS = {name: (scale, unit) for name, _, scale, unit, _ in PARAMETERS}
ADJUSTMENT_SPECS = {
    "prior_authorization_percentage": (2, "percent"),
    "prior_authorization_reduction": (2, "percent"),
    "percentage_increase": (2, "percent"),
    "amount_increase": (2, "USD"),
    "security_increase": (2, "USD"),
    "sequestration_reduction": (2, "percent"),
}


def _formula_records(view, context):
    records = []

    def add(kind, parameter, component, match, numeric=None, **metadata):
        origin = view.witness(match.start(), match.end())
        values, raw_fields, value_specs, value_origins = {}, {}, {}, {}
        for field, (group, scale, unit) in (numeric or {}).items():
            if match.group(group) is None:
                continue
            witness = view.witness(*match.span(group))
            raw = view.raw(witness)
            values[field] = _number(raw, scale)
            raw_fields[field] = raw
            value_specs[field] = {"scale": scale, "unit": unit}
            value_origins[field] = witness
        records.append(
            {
                "row_kind": kind,
                "table_kind": "allowance_formula",
                "label": parameter.replace("_", " "),
                "parameter": parameter,
                "component": component,
                **context,
                "source_expression": view.text[match.start() : match.end()],
                "origin": origin,
                "values": values,
                "raw_fields": raw_fields,
                "value_specs": value_specs,
                "value_origins": value_origins,
                "context_origins": {
                    key: view.witness(*match.span(key))
                    for key in ("year", "prior", "district_prior", "input_year", "date", "month")
                    if match.groupdict().get(key) is not None
                },
                "issues": [],
                **metadata,
            }
        )
        return records[-1]

    text = view.text
    for name, component, scale, unit, pattern in PARAMETERS:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            row = add("formula_parameter", name, component, match, {"value": ("value", scale, unit)})
            if name == "travel_minimum":
                row.update(bound="lower", inclusive=True, applies_to="travel_amount")
            elif name == "lodging_and_meals_days":
                row["applies_to"] = ["lodging", "meals"]
            elif name == "mileage_increase":
                row["operation_order"] = "not_specified_relative_to_band_selection"

    bands = (
        rf"(?P<label>Under (?P<upper>{NUMBER}) miles?)\s+(?P<rate>\$?(?:\d+)?\.\d+)",
        rf"(?P<label>At least (?P<lower>{NUMBER}) but less than (?P<upper>{NUMBER}) miles)\s+(?P<rate>\$?(?:\d+)?\.\d+)",
        rf"(?P<label>(?P<lower>{NUMBER}) miles or more)\s+(?P<rate>\$?(?:\d+)?\.\d+)",
    )
    for pattern in bands:
        for match in re.finditer(pattern, text):
            numeric = {key: (key, 0, "miles") for key in ("lower", "upper") if key in match.groupdict()}
            numeric["rate"] = ("rate", 2, "USD/mile")
            add(
                "mileage_rate_band",
                "mileage_rate",
                "travel",
                match,
                numeric,
                band_literal=match["label"],
                lower_inclusive=True if "lower" in numeric else None,
                upper_inclusive=False if "upper" in numeric else None,
            )

    pattern = rf"Allowance is (?P<value>{PERCENT}) of the amount authorized in (?P<year>\d{{4}})"
    for match in re.finditer(pattern, text, re.IGNORECASE):
        add(
            "formula_adjustment",
            "prior_authorization_percentage",
            "total_allowance",
            match,
            {"value": ("value", 2, "percent")},
            basis_year=int(match["year"]),
            basis="prior_authorization",
            approximate=False,
        )
    pattern = rf"(?P<value>{PERCENT}) reduction to the (?P<year>\d{{4}}) authorization"
    for match in re.finditer(pattern, text, re.IGNORECASE):
        add(
            "formula_adjustment",
            "prior_authorization_reduction",
            "total_allowance",
            match,
            {"value": ("value", 2, "percent")},
            basis_year=int(match["year"]),
            basis="prior_authorization",
            role="explanation_of_total_percentage",
            approximate=False,
        )
    pattern = rf"Allowance for (?P<year>\d{{4}}) utilizes (?:each Member[’']s (?P<prior>\d{{4}}) amount|the (?P<district_prior>\d{{4}}) amount for each Congressional District)(?: and increases that amount by (?P<approx>approximately )?(?P<increase>{MONEY}|{PERCENT})(?P<average> of the average MRA)?)?"
    for match in re.finditer(pattern, text, re.IGNORECASE):
        previous = int(match["prior"] or match["district_prior"])
        increase = match["increase"]
        parameter = (
            "prior_amount_reused"
            if increase is None
            else "amount_increase"
            if "$" in increase
            else "percentage_increase"
        )
        numeric = None if increase is None else {"value": ("increase", *ADJUSTMENT_SPECS[parameter])}
        add(
            "formula_adjustment",
            parameter,
            "total_allowance",
            match,
            numeric,
            basis_year=previous,
            target_year=int(match["year"]),
            basis="average_MRA"
            if match["average"]
            else "prior_member_amount"
            if match["prior"]
            else "prior_district_amount",
            approximate=bool(match["approx"]),
        )
    pattern = rf"In (?P<month>[A-Za-z]+) (?P<year>\d{{4}}), all MRAs were increased by (?P<value>{MONEY}) in response to heightened security concerns"
    for match in re.finditer(pattern, text):
        month = list(month_name).index(match["month"])
        add(
            "formula_adjustment",
            "security_increase",
            "total_allowance",
            match,
            {"value": ("value", 2, "USD")},
            effective_month=f"{match['year']}-{month:02d}",
            effective_date=None,
            approximate=False,
        )
    pattern = rf"reduced on (?P<date>[A-Za-z]+ \d{{1,2}}, \d{{4}}), by (?P<value>{PERCENT})"
    for match in re.finditer(pattern, text):
        month, day, year = match["date"].replace(",", "").split()
        add(
            "formula_adjustment",
            "sequestration_reduction",
            "total_allowance",
            match,
            {"value": ("value", 2, "percent")},
            effective_date=date(int(year), list(month_name).index(month), int(day)).isoformat(),
            approximate=False,
        )

    for match in re.finditer(
        r"recalculated using the sum of the following components adjusted proportionally to ensure the total is consistent with (?P<year>\d{4}) funding levels",
        text,
    ):
        add(
            "formula_relationship",
            "proportional_recalculation",
            "total_allowance",
            match,
            basis_year=int(match["year"]),
            operation_literal="adjusted proportionally",
            operation=None,
            evaluation_status="not_evaluated_funding_total_and_district_inputs_missing",
        )

    references = (
        (
            "district_distance",
            "travel",
            r"mileage between the District of Columbia and the furthest point in the Member[’']s district, according to the Rand McNally Standard Highway Mileage Guide",
        ),
        (
            "gsa_rental_rate",
            "district_office_rent",
            r"applicable (?:(?P<input_year>\d{4}) )?(?:General Services Administration \(GSA\)|GSA) rental rate",
        ),
        (
            "postal_rate",
            "official_mail",
            r"(?:single-piece rate applicable to first class mail|first class rate for mail \(as determined by the Postmaster General\))",
        ),
        (
            "postal_addresses",
            "official_mail",
            r"number (?:\(as determined (?:by|be) the Postmaster General\) )?of (?:postal )?addresses \(other than business delivery stops\) in the Member[’']s congressional district",
        ),
        ("weighted_air_travel_cost", "travel", r"Weighted travel was calculated.*?(?:airport data\.)"),
        ("gsa_per_diem", "travel", r"GSA (?:[•\uf0b7●]\s+)?Per Diem rate for the district"),
    )
    for name, component, pattern in references:
        for match in re.finditer(pattern, text):
            add(
                "external_input_reference",
                name,
                component,
                match,
                input_value_status="not_supplied",
                input_year=int(match["input_year"]) if match.groupdict().get("input_year") else None,
            )

    for name, component, pattern in (
        ("mileage_calculation", "travel", r"dollar equivalent of 64.*?plus (?:ten percent|10%)"),
        ("rent_calculation", "district_office_rent", r"dollar equivalent of 2,500 square feet.*?rental rate"),
        ("component_sum", "total_allowance", r"is the sum of the following three component amounts"),
    ):
        for match in re.finditer(pattern, text, re.IGNORECASE):
            add(
                "formula_relationship",
                name,
                component,
                match,
                operation_literal=match[0],
                operation="sum" if name == "component_sum" else None,
                evaluation_status="not_evaluated_external_inputs_missing",
            )

    for match in re.finditer(
        r"(?P<cap>Not more than )?(?:the (?P<prefix>product) of )?3 (?:times the (?P<operation>sum|product)|times the single-piece|(?P<symbol>x) first class).*?congressional district\.",
        text,
        re.IGNORECASE,
    ):
        key = next(key for key in ("operation", "prefix", "symbol") if match[key] is not None)
        literal = match[key]
        operation = "product" if literal == "x" else literal.lower()
        row = add(
            "formula_relationship",
            "mail_calculation",
            "official_mail",
            match,
            operation_literal=literal,
            operation_origin=view.witness(*match.span(key)),
            operation=operation,
            limit="not_more_than" if match["cap"] else None,
            evaluation_status="not_evaluated_external_inputs_missing",
        )
        if operation == "sum":
            row["issues"].append("printed_mail_sum_requires_source_review")
    for match in re.finditer(
        r"Base amount \(\$[\d,]+\) \+ \(Weighted Air Travel Cost x Number of One-Way Trips\) \+ Days of Lodging \+ Days of Meals & Incidentals\.",
        text,
    ):
        add(
            "formula_relationship",
            "air_travel_calculation",
            "travel",
            match,
            operation_literal=match[0],
            operation=None,
            evaluation_status="printed_expression_requires_unit_review",
            issues=["printed_travel_expression_uses_days_with_dollar_terms"],
        )

    context_patterns = (
        ("funding_year", r"FY (?P<year>\d{4}) levels"),
        ("appropriation_year", r"Fiscal Year (?P<year>\d{4}) Legislative Branch Appropriations"),
        ("component_basis_year", r"amount of each Member[’']s (?P<year>\d{4}) Representational allowance is the sum"),
        ("staffing_basis_year", r"For (?P<year>\d{4}) this amount is"),
        ("salary_analysis_year", r"analysis of (?P<year>\d{4}) salary levels"),
    )
    for name, pattern in context_patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            add(
                "formula_context",
                name,
                "formula",
                match,
                reference_year=int(match["year"]),
                reference_year_literal=match["year"],
            )
    for match in re.finditer(
        r"House Resolution \d+, agreed to on [A-Za-z]+ \d{1,2}, \d{4}|H\.R\. \d+|P\.L\. \d+-\d+|Budget Control Act of \d{4}|Consolidated Appropriations Act, \d{4}",
        text,
    ):
        add("authority_reference", "printed_authority", "formula", match, authority_literal=match[0])

    records.sort(key=lambda row: (row["origin"]["start"], row["origin"]["end"], row["parameter"]))
    for index, row in enumerate(records):
        row["occurrence"] = index
    return records


def _numeric_dispositions(view, records, heading):
    """Account for numeric occurrences without promoting citation numbers to values."""
    pattern = rf"(?<![\w.])(?:\$\s*)?(?:{NUMBER}|\.\d+)%?|\b(?:one|two|three|ten)\b(?!-?way)"
    year_pattern = r"(?:Allowance for|LEGISLATIVE YEAR|are the|Member[’']s|The) (?P<year>\d{4})(?= (?:Members|Representational|representational|utilizes|was|$))|(?:Allowance for|LEGISLATIVE YEAR) (?P<direct_year>\d{4})"
    years = [
        match.span(key)
        for match in re.finditer(year_pattern, view.text, re.IGNORECASE)
        for key in ("year", "direct_year")
        if match.group(key)
    ]
    enumerators = [match.span(1) for match in re.finditer(r"(?<![\d.])([1-4])\. (?=[A-Z])", view.text)]
    result = []
    for match in re.finditer(pattern, view.text, re.IGNORECASE):
        start, end = match.span()
        item = {"literal": match[0], "origin": view.witness(start, end), "disposition": "unresolved_numeric"}
        values = [
            (row["occurrence"], field)
            for row in records
            for field, origin in row["value_origins"].items()
            if origin["start"] <= start and end <= origin["end"]
        ]
        if len(values) > 1:
            raise ValueError("Formula reader repeats one printed numeric occurrence")
        if values:
            item.update(disposition="typed_value", record=values[0][0], field=values[0][1])
        elif view.text.startswith(heading) and end <= len(heading):
            item["disposition"] = "printed_section_context"
        elif any(left <= start and end <= right for left, right in years):
            item["disposition"] = "printed_formula_year"
        elif any(left <= start and end <= right for left, right in enumerators):
            item["disposition"] = "component_enumerator"
        else:
            references = [
                row["occurrence"]
                for row in records
                if (
                    row["row_kind"] == "authority_reference"
                    and row["origin"]["start"] <= start
                    and end <= row["origin"]["end"]
                )
                or any(origin["start"] <= start and end <= origin["end"] for origin in row["context_origins"].values())
            ]
            if references:
                item.update(disposition="retained_context_or_authority", records=references)
        result.append(item)
    return result


def validate_formula_record(page, row):
    """Validate exact source fragments, numeric values, units and occurrence shape."""
    view = _Text(page["native_blocks"], page["formula_block_indices"])
    origin = row["origin"]
    if (
        not 0 <= origin["start"] < origin["end"] <= len(view.text)
        or origin != view.witness(origin["start"], origin["end"])
        or row["source_expression"] != view.text[origin["start"] : origin["end"]]
    ):
        raise ValueError("Formula record differs from its retained native source span")
    for witness in list(row["context_origins"].values()) + (
        [row["operation_origin"]] if "operation_origin" in row else []
    ):
        if not origin["start"] <= witness["start"] < witness["end"] <= origin["end"] or witness != view.witness(
            witness["start"], witness["end"]
        ):
            raise ValueError("Formula context differs from its source expression")
    if not (set(row["values"]) == set(row["raw_fields"]) == set(row["value_specs"]) == set(row["value_origins"])):
        raise ValueError("Formula record has inconsistent numeric field membership")
    for name, value in row["values"].items():
        witness = row["value_origins"][name]
        spec = row["value_specs"][name]
        if not origin["start"] <= witness["start"] < witness["end"] <= origin["end"]:
            raise ValueError("Formula value lies outside its source expression")
        if witness != view.witness(witness["start"], witness["end"]) or row["raw_fields"][name] != view.raw(witness):
            raise ValueError("Formula value differs from its retained source witness")
        if row["row_kind"] == "mileage_rate_band":
            expected = (2, "USD/mile") if name == "rate" else (0, "miles")
        else:
            expected = (PARAMETER_SPECS | ADJUSTMENT_SPECS)[row["parameter"]]
        if (spec["scale"], spec["unit"]) != expected or value != _number(row["raw_fields"][name], spec["scale"]):
            raise ValueError("Formula value or unit differs from its printed parameter")
    corrections = [
        rule
        for rule in _CORRECTIONS
        if (rule["source_sha256"], rule["source_page"], rule["parameter"], rule["record_origin"])
        == (page["source_sha256"], page["source_page"], row["parameter"], origin)
    ]
    if row.get("repairs", []) != corrections:
        raise ValueError("Formula correction audit differs from its source declaration")
    for rule in corrections:
        if (
            page["source_size_bytes"] != rule["source_size_bytes"]
            or page["page"] != page["source_page"]
            or hashlib.sha256(view.text.encode()).hexdigest() != rule["formula_text_sha256"]
            or row[rule["field"]] != rule["after"]
            or row[rule["literal_field"]] != rule["raw_literal"]
        ):
            raise ValueError("Formula corrected context differs from its reviewed original")
    if "operation_origin" in row:
        if row["operation_literal"] != view.raw(row["operation_origin"]):
            raise ValueError("Formula operation literal differs from its source")
        if not corrections and row["operation"] != (
            "product" if row["operation_literal"] == "x" else row["operation_literal"].lower()
        ):
            raise ValueError("Formula operation differs from its literal without a source correction")
    if "reference_year_literal" in row:
        if row["reference_year_literal"] != view.raw(row["context_origins"]["year"]):
            raise ValueError("Formula reference year literal differs from its source")
        if not corrections and row["reference_year"] != int(row["reference_year_literal"]):
            raise ValueError("Formula reference year differs without a source correction")
    annotations = [
        note
        for note in _ANNOTATIONS
        if (note["source_sha256"], note["source_page"], note["record_origin"])
        == (page["source_sha256"], page["source_page"], row["origin"])
    ]
    if row.get("source_dispositions", []) != annotations:
        raise ValueError("Formula source disposition differs from its reviewed declaration")
    for note in annotations:
        if (
            page["source_size_bytes"] != note["source_size_bytes"]
            or page["page"] != page["source_page"]
            or hashlib.sha256(view.text.encode()).hexdigest() != note["formula_text_sha256"]
            or row["values"].get("rate") != note["value_unchanged"]
            or row["raw_fields"].get("rate") != note["raw_rate"]
            or note["issue"] not in row["issues"]
        ):
            raise ValueError("Formula source disposition changed its value or lost its issue")
    if page.get("target_year_origin"):
        witness = page["target_year_origin"]
        if (
            row.get("target_year_origin") != witness
            or row["target_year"] != witness["target_year"]
            or row.get("target_year_basis") != "adjacent_annual_title_and_dated_adjustment"
        ):
            raise ValueError("Formula target year lost its adjacent source witness")


def _apply_corrections(page, view):
    """Apply reviewed relationships only to the exact complete original and span."""
    for rule in _CORRECTIONS:
        if (page["source_sha256"], page["source_page"]) != (rule["source_sha256"], rule["source_page"]):
            continue
        if (
            page["source_size_bytes"] != rule["source_size_bytes"]
            or page["page"] != page["source_page"]
            or hashlib.sha256(view.text.encode()).hexdigest() != rule["formula_text_sha256"]
        ):
            raise ValueError("House formula correction differs from its reviewed complete original")
        matched = [
            row
            for row in page["records"]
            if row["parameter"] == rule["parameter"] and row["origin"] == rule["record_origin"]
        ]
        if len(matched) != 1:
            raise ValueError("House formula correction target is missing or repeated")
        row = matched[0]
        if row[rule["field"]] != rule["before"] or row[rule["literal_field"]] != rule["raw_literal"]:
            raise ValueError("House formula correction differs from its reviewed literal")
        row[rule["field"]] = rule["after"]
        row["repairs"] = [deepcopy(rule)]
        if rule["field"] == "operation":
            row["issues"].remove("printed_mail_sum_requires_source_review")


def _apply_annotations(page, view):
    for note in _ANNOTATIONS:
        if (page["source_sha256"], page["source_page"]) != (note["source_sha256"], note["source_page"]):
            continue
        if (
            page["source_size_bytes"] != note["source_size_bytes"]
            or page["page"] != page["source_page"]
            or hashlib.sha256(view.text.encode()).hexdigest() != note["formula_text_sha256"]
        ):
            raise ValueError("Formula source disposition differs from its reviewed original")
        matches = [
            row
            for row in page["records"]
            if row["parameter"] == note["parameter"] and row["origin"] == note["record_origin"]
        ]
        if len(matches) != 1:
            raise ValueError("Formula source disposition target is missing or repeated")
        row = matches[0]
        row["source_dispositions"] = [deepcopy(note)]
        row["issues"].append(note["issue"])


def validate_formula_page(page):
    """Check complete native membership and occurrence identity for the shared host."""
    if page["status"] in {"no_recognized_allowance_formula", "allowance_formula_context_read"}:
        if page["records"]:
            raise ValueError("Unrecognized formula page has records")
        if page["status"] == "allowance_formula_context_read":
            _validate_adjacent_title(page["context_title_origin"], page)
        return
    indices = [
        index
        for key in ("formula_block_indices", "formula_ornament_block_indices", "outside_formula_block_indices")
        for index in page[key]
    ]
    if sorted(indices) != list(range(len(page["native_blocks"]))):
        raise ValueError("Formula block partition is incomplete or repeated")
    view = _Text(page["native_blocks"], page["formula_block_indices"])
    if view.text != page["formula_text"]:
        raise ValueError("Formula view differs from retained native blocks")
    if page.get("target_year_origin"):
        witness = page["target_year_origin"]
        _validate_adjacent_title(witness)
        if witness["source_sha256"] != page["source_sha256"] or witness["source_page"] != page["source_page"] + 1:
            raise ValueError("Formula target year witness is not from the adjacent original page")
        dates = [
            row
            for row in page["records"]
            if row["parameter"] == "sequestration_reduction"
            and row["origin"] == witness["formula_adjustment_origin"]
            and row.get("effective_date", "").startswith(str(witness["target_year"]) + "-")
        ]
        if len(dates) != 1:
            raise ValueError("Formula adjacent title lacks its agreeing dated adjustment")
    positions, values = [], []
    for index, row in enumerate(page["records"]):
        if row["occurrence"] != index:
            raise ValueError("Formula occurrence identity is missing or repeated")
        validate_formula_record(page, row)
        positions.append((row["origin"]["start"], row["origin"]["end"], row["parameter"]))
        values.extend((origin["start"], origin["end"]) for origin in row["value_origins"].values())
    if positions != sorted(set(positions)) or len(values) != len(set(values)):
        raise ValueError("Formula source occurrence is repeated or out of order")


def _reading_order(blocks, indices, geometry):
    """Use maintained displayed-line grouping for mixed font sizes in rate rows."""
    x0, y0, x1, y1 = geometry["display_rect"]
    words, ornaments = [], []
    for index in indices:
        block = blocks[index]
        if block["text"].strip() in {"•", "\uf0b7", "●"}:
            ornaments.append(index)
            continue
        box = block["box"]
        bounds = [box["x0"] * (x1 - x0), box["y0"] * (y1 - y0), box["x1"] * (x1 - x0), box["y1"] * (y1 - y0)]
        words.append(
            {"index": index, "bbox": bounds, "x": (bounds[0] + bounds[2]) / 2, "y": (bounds[1] + bounds[3]) / 2}
        )
    return [word["index"] for line in financial_lines(words) for word in line], ornaments


def _iter_formula_pages(body, *, pages=None, source_page_numbers=None):
    """Read selected formula scopes with original observations and explicit input gaps."""
    for observed, result in native_summary_pages(body, rule=RULE, pages=pages, source_page_numbers=source_page_numbers):
        result["source_size_bytes"] = observed.metadata["source_size_bytes"]
        blocks = summary_blocks(observed)
        result["native_blocks"] = [asdict(block) for block in blocks]
        section = _section(result, blocks)
        if section is None:
            result.update(
                status="no_recognized_allowance_formula",
                unread=[{"reason": "formula_heading_not_read", "scope": "complete_native_page"}],
            )
            yield result
            continue
        beginning = next(
            index
            for index, block in enumerate(blocks)
            if asdict(block.box) == section["blocks"][0]["box"] and block.text == section["blocks"][0]["text"]
        )
        stop = next(
            (
                index
                for index, block in enumerate(blocks)
                if index > beginning and _TITLE.fullmatch(" ".join(block.text.split()))
            ),
            len(blocks),
        )
        result["formula_block_indices"], result["formula_ornament_block_indices"] = _reading_order(
            result["native_blocks"], range(beginning, stop), result["geometry"]
        )
        result["outside_formula_block_indices"] = [
            index for index in range(len(blocks)) if not beginning <= index < stop
        ]
        view = _Text(result["native_blocks"], result["formula_block_indices"])
        result["formula_text"] = view.text
        result["section_origin"] = section
        years = re.findall(r"(?:Allowance for|LEGISLATIVE YEAR) (\d{4})", view.text, re.IGNORECASE)
        if not years:
            years = re.findall(
                r"(?:are the|Member[’']s) (\d{4}) (?:Representational|representational) Allowance",
                view.text,
                re.IGNORECASE,
            )[:1]
        context = {
            "target_year": int(years[0]) if years else None,
            "period_start": section["period_start"],
            "period_end": section["period_end"],
            "amended": section["amended"],
        }
        result["records"] = _formula_records(view, context)
        _apply_corrections(result, view)
        _apply_annotations(result, view)
        result["issues"] = list(section["issues"])
        parameters = [row["parameter"] for row in result["records"] if row["row_kind"] == "formula_parameter"]
        for name in ("clerk_hire_base", "office_base", "office_area", "mail_multiplier", "mail_percentage"):
            if parameters.count(name) != 1:
                result["issues"].append("formula_parameter_missing_or_repeated:" + name)
        family = "mileage_bands" if "rates per mile" in view.text else "weighted_air_travel"
        result["formula_family"] = family
        if family == "mileage_bands" and sum(row["row_kind"] == "mileage_rate_band" for row in result["records"]) != 8:
            result["issues"].append("mileage_band_count_not_recognized")
        if context["target_year"] is None:
            result["issues"].append("formula_target_year_not_stated")
        bases = {
            row["reference_year"]
            for row in result["records"]
            if row["parameter"] in {"component_basis_year", "staffing_basis_year"}
        }
        if len(bases) > 1:
            result["issues"].append("printed_component_basis_year_conflict")
        result["numeric_dispositions"] = _numeric_dispositions(view, result["records"], section["heading"])
        unresolved = [item for item in result["numeric_dispositions"] if item["disposition"] == "unresolved_numeric"]
        if unresolved:
            result["issues"].append("formula_numeric_occurrences_unresolved")
        result["status"] = "allowance_formula_facts_partial" if unresolved else "allowance_formula_facts_read"
        result["unread"] = [
            {
                "reason": "replacement_annual_allowance_not_evaluated",
                "scope": "formula_relationships_and_unsupplied_external_inputs",
            }
        ]
        if stop < len(blocks):
            result["unread"].append(
                {
                    "reason": "annual_allowance_rows_belong_to_separate_profile",
                    "scope": "native_text_from_annual_table_heading",
                }
            )
        validate_formula_page(result)
        yield result


def _validate_adjacent_title(witness, page=None):
    match = _TITLE.fullmatch(" ".join(witness["title_literal"].split()))
    if match is None or int(match[1]) != witness["target_year"] or len(witness["blocks"]) != 1:
        raise ValueError("Formula adjacent-title witness has no unique printed year")
    block = witness["blocks"][0]
    if block["text"] != witness["title_literal"]:
        raise ValueError("Formula adjacent-title literal differs from its native block")
    if page is not None and (
        witness["source_sha256"] != page["source_sha256"]
        or witness["source_page"] != page["source_page"]
        or witness["geometry"] != page["geometry"]
        or page["native_blocks"][block["index"]] != block["observation"]
        or block["observation"]["text"] != block["text"]
    ):
        raise ValueError("Formula adjacent title differs from retained native observations")


def _attach_adjacent_context(previous, current):
    if (
        "formula_target_year_not_stated" not in previous["issues"]
        or current["status"] != "no_recognized_allowance_formula"
        or current["source_sha256"] != previous["source_sha256"]
        or current["source_page"] != previous["source_page"] + 1
    ):
        return
    titles = [
        (index, block, _TITLE.fullmatch(" ".join(block["text"].split())))
        for index, block in enumerate(current["native_blocks"])
    ]
    titles = [(index, block, match) for index, block, match in titles if match]
    if len(titles) != 1:
        return
    index, block, match = titles[0]
    year = int(match[1])
    # The selected formula's dated adjustment independently agrees with the
    # following annual title. A containing report year alone is insufficient.
    dated = [
        row
        for row in previous["records"]
        if row["parameter"] == "sequestration_reduction" and row.get("effective_date", "").startswith(str(year) + "-")
    ]
    if len(dated) != 1:
        return
    witness = {
        "source_sha256": current["source_sha256"],
        "source_page": current["source_page"],
        "geometry": current["geometry"],
        "title_literal": block["text"],
        "target_year": year,
        "blocks": [{"index": index, "text": block["text"], "observation": deepcopy(block)}],
        "formula_adjustment_origin": dated[0]["origin"],
    }
    previous["target_year_origin"] = witness
    previous["issues"].remove("formula_target_year_not_stated")
    for row in previous["records"]:
        row.update(
            target_year=year,
            target_year_basis="adjacent_annual_title_and_dated_adjustment",
            target_year_origin=deepcopy(witness),
        )
    current.update(
        status="allowance_formula_context_read",
        context_title_origin=deepcopy(witness),
        provides_formula_context_for_page=previous["source_page"],
        unread=[{"reason": "annual_allowance_rows_belong_to_separate_profile", "scope": "complete_annual_table"}],
    )
    validate_formula_page(previous)
    validate_formula_page(current)


def iter_house_allowance_formula_pages(body, *, pages=None, source_page_numbers=None):
    """Read formula facts and only explicitly selected adjacent native context."""
    pending = None
    for current in _iter_formula_pages(body, pages=pages, source_page_numbers=source_page_numbers):
        if pending is not None:
            _attach_adjacent_context(pending, current)
            yield pending
        pending = current
    if pending is not None:
        yield pending
