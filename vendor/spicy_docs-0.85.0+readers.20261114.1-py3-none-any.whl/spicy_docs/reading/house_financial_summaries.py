"""Read House accountability, appropriation and general-fund receipt summaries.

These unruled financial tables use printed headings and positioned amounts.
Summary values retain their own roles; they are never transaction payments.
"""

from __future__ import annotations

import json
import re
from decimal import Decimal
from importlib.resources import files

from spicy_docs.reading.financial_lines import financial_lines
from spicy_docs.reading.financial_repairs import apply_reviewed_cells
from spicy_docs.reading.house_disbursements_pdf import iter_house_disbursements_pages
from spicy_docs.reading.pdf_grid import literal
from spicy_docs.schemas.senate_expenditure_tables import parse_amount
from spicy_docs.sources.disbursements_index import read_report_period

RULE = "house-native-financial-summaries/1"
# The page host retains declared non-Python inputs beside the reader's code.
SOURCE_RESOURCES = ("house_financial_summaries_corrections.json",)
_AMOUNT_REPAIRS = json.loads(files("spicy_docs.reading").joinpath(SOURCE_RESOURCES[0]).read_text())
_FUNDING = re.compile(r"\d{4}(?:/\d{4})?\Z")
_ACCOUNTABILITY = "STATEMENT OF ACCOUNTABILITY FOR APPROPRIATIONS AND OTHER"
_APPROPRIATIONS = "SUMMARY OF TRANSACTIONS BY APPROPRIATIONS"
_RECEIPTS = "SUMMARY OF GENERAL FUND RECEIPTS AND GIFTS"


def _apply_reviewed_amount_repairs(page, source_byte_size):
    """Change only reviewed normalized cells in their complete original bytes."""
    apply_reviewed_cells(page, source_byte_size, _AMOUNT_REPAIRS, chamber="House", page_fields=("printed_page",))


def _check_appropriation_balance(row):
    """Flag a complete printed equation without filling blanks or forcing totals."""
    if row["table_kind"] != "appropriation_summary":
        return
    values = row["values"]
    if len(values) != 4 or any(value is None for value in values.values()):
        return
    if "transfers_appropriations" in values:
        fields = (
            "opening_unexpended_balance",
            "transfers_appropriations",
            "net_disbursements",
            "closing_unexpended_balance",
        )
        signs = (1, 1, -1, -1)
    elif "opening_unexpended_balance" in values:
        fields = ("opening_unexpended_balance", "net_disbursements", "transfers", "closing_unexpended_balance")
        signs = (1, -1, -1, -1)
    else:
        fields = ("funds_available", "net_disbursements", "transfers", "unexpended_balance")
        signs = (1, -1, -1, -1)
    if sum(Decimal(values[field]) * sign for field, sign in zip(fields, signs, strict=True)):
        row["issues"].append("printed_appropriation_balance_mismatch")


def _printed_page(lines):
    found = [literal(line).strip("()") for line in lines if re.fullmatch(r"\(?[IVXLCDM]+\)?", literal(line))]
    if len(found) != 1:
        return None, None
    values = [{"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}[letter] for letter in found[0]]
    number = sum(
        -value if index + 1 < len(values) and value < values[index + 1] else value for index, value in enumerate(values)
    )
    return found[0], number


def _label(words):
    text = literal([word for word in words if word["text"] != "$"])
    return re.sub(r"[.…]{2,}\s*\Z", "", text).strip() or None


def _money(line):
    amounts = []
    consumed = set()
    for number, word in enumerate(line):
        if word["index"] in consumed:
            continue
        value = parse_amount(word["text"])
        if value is not None:
            amounts.append((word, value))
            continue
        parts = [word]
        method = None
        # Currency and a negative accounting bracket can be separate native
        # words. A bare integer is money only with its observed dollar sign.
        if word["text"] in {"($", "(", "$"} and number + 1 < len(line):
            following = line[number + 1]
            height = max(item["bbox"][3] - item["bbox"][1] for item in (word, following))
            if following["bbox"][0] - word["bbox"][2] > 2 * height:
                continue
            text = word["text"] + following["text"]
            value = parse_amount(text)
            if value is None and word["text"] == "$" and re.fullmatch(r"\d{1,3}(?:,\d{3})+", following["text"]):
                value = Decimal(following["text"].replace(",", ""))
                method = "currency_marked_whole_dollars"
            # Preserve already-supported separate dollar signs verbatim;
            # only combine fragments when the amount otherwise cannot parse.
            if value is not None and parse_amount(following["text"]) is None:
                parts.append(following)
                method = method or "adjacent_accounting_sign_fragments"
        if method is None:
            suffix = re.fullmatch(r"[.…]+(\d[\d,]*\.\d{1,2})", word["text"])
            if suffix and (value := parse_amount(suffix[1])) is not None:
                method = "amount_attached_to_leader_dots"
        if method:
            box = [
                min(item["bbox"][0] for item in parts),
                min(item["bbox"][1] for item in parts),
                max(item["bbox"][2] for item in parts),
                max(item["bbox"][3] for item in parts),
            ]
            observed = {
                **parts[-1],
                "text": literal(parts),
                "bbox": box,
                "x": (box[0] + box[2]) / 2,
                "source_word_indices": [item["index"] for item in parts],
                "reading_method": method,
            }
            amounts.append((observed, value))
            consumed.update(observed["source_word_indices"])
    return amounts


def _amount_source_indices(amounts):
    return {index for word, _ in amounts for index in word.get("source_word_indices", [word["index"]])}


def _amount_readings(amounts):
    return [
        {
            "source_word_indices": word["source_word_indices"],
            "literal": word["text"],
            "value": format(value, ".2f"),
            "method": word["reading_method"],
            "bbox": word["bbox"],
        }
        for word, value in amounts
        if "reading_method" in word
    ]


def _simple_rows(lines, start, end, table_kind):
    pending = []
    roles = []
    rows = []
    gifts = False
    transfer_heading = None
    transfer_kind = None
    for number in range(start + 1, end):
        line = lines[number]
        amounts = _money(line)
        text = literal(line)
        if not amounts:
            if (
                rows
                and table_kind == "accountability"
                and (
                    rows[-1]["row_kind"] == "disbursements"
                    and text.startswith("and ")
                    or rows[-1]["row_kind"] == "lapsed_transfer"
                    and (rows[-1]["label"] or "").endswith(" to")
                )
            ):
                # Some editions align the amount with the first line of a
                # wrapped label instead of its last line. Keep that suffix
                # with its observed row, rather than the next monetary row.
                row = rows[-1]
                row["raw_label"] += " " + text
                row["label"] += " " + text
                row["word_indices"].extend(word["index"] for word in line)
                row.setdefault("label_continuation_lines", []).append(number + 1)
                pending = []
                continue
            if text == "FUNDS" or text.endswith(":"):
                gifts = gifts or text.startswith("Gifts to United States")
                transfer_kind = (
                    "lapsed_transfer"
                    if text.startswith("Lapsed appropriations transferred to")
                    else "transfer"
                    if text == "Transfers:"
                    else None
                )
                transfer_heading = (
                    {"line": number + 1, "literal": text, "word_indices": [word["index"] for word in line]}
                    if transfer_kind
                    else None
                )
                pending = []
            elif not text.startswith("UNITED STATES FOR REDUCTION"):
                pending.extend(line)
            continue
        indices = {word["index"] for word, _ in amounts}
        source_indices = _amount_source_indices(amounts)
        label_words = pending + [word for word in line if word["index"] not in source_indices]
        label = _label(label_words)
        pending = []
        role = "unresolved_component"
        used_transfer_heading = False
        if table_kind == "accountability":
            if label and label.startswith("Unexpended balance"):
                role = "closing_balance" if "opening_balance" in roles else "opening_balance"
            elif label:
                for prefix, candidate in (
                    ("Appropriations", "appropriations"),
                    ("Funds Available under Fiscal Year", "continuing_resolution_funds"),
                    ("Receipts to be deposited", "receipts"),
                    ("Total funds available", "available_total"),
                    ("Disbursements for salaries", "disbursements"),
                    ("Lapsed appropriations", "lapsed_transfer"),
                    ("Deposited in general fund", "deposited_receipts"),
                    ("Total funds disbursed", "disbursed_total"),
                ):
                    if label.startswith(prefix):
                        role = candidate
                        break
                if role == "unresolved_component" and transfer_heading:
                    role = transfer_kind
                    used_transfer_heading = True
            elif roles and roles[-1] == "receipts":
                role = "appropriations_and_receipts_subtotal"
        elif label and label.startswith("Miscellaneous receipts"):
            role = "miscellaneous_receipts"
        elif label and label.startswith("Total general fund receipts"):
            role = "general_fund_receipts_total"
        elif gifts:
            role = "member_salary_gift"
        roles.append(role)
        issues = []
        if len(amounts) != 1:
            issues.append("multiple_amounts_in_summary_component")
        if role == "unresolved_component":
            issues.append("summary_component_role_unresolved")
        rows.append(
            {
                "line": number + 1,
                "table_kind": table_kind,
                "row_kind": role,
                "label": label,
                "raw_label": literal(label_words),
                "values": {"amount": format(amounts[0][1], ".2f") if len(amounts) == 1 else None},
                "raw_fields": {"amount": literal([word for word, _ in amounts])},
                "word_indices": [word["index"] for word in label_words] + sorted(source_indices),
                "money_word_indices": sorted(indices),
                "issues": issues,
                "repairs": [],
            }
        )
        if readings := _amount_readings(amounts):
            rows[-1]["money_readings"] = readings
        if used_transfer_heading:
            rows[-1]["component_heading_origin"] = transfer_heading
    # Both source layouts distinguish indented component amounts from the
    # right-hand totals. Locate those columns from the printed right edges.
    words_by_index = {word["index"]: word for line in lines[start + 1 : end] for word in line}
    money_words = [words_by_index[index] for row in rows for index in row["money_word_indices"]]
    # A subtotal can be indented by one glyph width inside the right-hand
    # column (2011 Q4); the component column remains many glyphs away.
    edge_tolerance = max((word["bbox"][3] - word["bbox"][1] for word in money_words), default=0)
    edges = []
    for row in rows:
        if len(row["money_word_indices"]) == 1:
            edge = words_by_index[row["money_word_indices"][0]]["bbox"][2]
            if not any(abs(edge - previous) <= edge_tolerance for previous in edges):
                edges.append(edge)
    edges.sort()
    for row in rows:
        row["amount_column"] = None
        if len(edges) == 2 and len(row["money_word_indices"]) == 1:
            edge = words_by_index[row["money_word_indices"][0]]["bbox"][2]
            row["amount_column"] = "left" if abs(edge - edges[0]) <= edge_tolerance else "right"
        else:
            row["issues"].append("summary_amount_column_unresolved")
        if row["row_kind"] == "member_salary_gift" and row["label"] is None:
            # An unnamed component can print zero beside a separate zero
            # subtotal. Its observed column, not the missing name, states
            # which occurrence is the subtotal (see the 2026 receipt fixture).
            row["row_kind"] = {
                "left": "member_salary_gift",
                "right": "member_salary_gifts_subtotal",
            }.get(row["amount_column"], "unresolved_component")
            if row["row_kind"] == "unresolved_component":
                row["issues"].append("summary_component_role_unresolved")
    return rows


def _appropriation_header(lines, start):
    first_money = next((number for number in range(start + 1, len(lines)) if _money(lines[number])), len(lines))
    headers = []
    for line in lines[start + 1 : first_money]:
        for index, word in enumerate(line):
            phrase = " ".join(item["text"].casefold() for item in line[index : index + 2])
            if phrase in {"funds available", "net disbursements", "unexpended balance"}:
                selected = line[index : index + 2]
                headers.append(
                    {
                        "label": literal(selected),
                        "x": sum(item["x"] for item in selected) / 2,
                        "word_indices": [item["index"] for item in selected],
                    }
                )
            elif word["text"].casefold() in {"transfers", "transfers/"}:
                headers.append({"label": word["text"], "x": word["x"], "word_indices": [word["index"]]})
            elif word["text"].casefold() == "net" and phrase != "net disbursements":
                # The amended 2010 statement wraps this one header over two
                # lines. Require a unique nearby word in the same column.
                height = word["bbox"][3] - word["bbox"][1]
                following = [
                    item
                    for other in lines[start + 1 : first_money]
                    for item in other
                    if item["text"].casefold() == "disbursements"
                    and abs(item["x"] - word["x"]) <= height
                    and 0 < item["bbox"][1] - word["bbox"][1] <= 2 * height
                ]
                if len(following) == 1:
                    headers.append(
                        {
                            "label": word["text"] + " " + following[0]["text"],
                            "x": (word["x"] + following[0]["x"]) / 2,
                            "word_indices": [word["index"], following[0]["index"]],
                        }
                    )
    headers.sort(key=lambda value: value["x"])
    labels = [item["label"].casefold() for item in headers]
    if labels == ["funds available", "net disbursements", "transfers", "unexpended balance"]:
        roles = ("funds_available", "net_disbursements", "transfers", "unexpended_balance")
    elif labels == ["unexpended balance", "transfers/", "net disbursements", "unexpended balance"]:
        roles = (
            "opening_unexpended_balance",
            "transfers_appropriations",
            "net_disbursements",
            "closing_unexpended_balance",
        )
    elif labels == ["unexpended balance", "net disbursements", "transfers", "unexpended balance"]:
        roles = ("opening_unexpended_balance", "net_disbursements", "transfers", "closing_unexpended_balance")
    else:
        return None
    # Title rows can precede the first financial row; they belong to the body.
    header_indices = {index for item in headers for index in item["word_indices"]}
    last_header = max(
        number for number, line in enumerate(lines) if any(word["index"] in header_indices for word in line)
    )
    while last_header + 1 < first_money and not literal(lines[last_header + 1]).rstrip().endswith(":"):
        last_header += 1
    return {
        "columns": [{**item, "role": role} for item, role in zip(headers, roles, strict=True)],
        "body_start": last_header + 1,
        "header_basis": "printed_on_page",
    }


def _appropriation_rows(lines, header, source_page, carried_title=None):
    columns = header["columns"]
    title = carried_title
    open_title = False
    rows = []
    for number in range(header["body_start"], len(lines)):
        line = lines[number]
        if re.fullmatch(r"\(?[IVXLCDM]+\)?", literal(line)):
            continue
        amounts = _money(line)
        indices = {word["index"] for word, _ in amounts}
        malformed = [word for word in line if re.fullmatch(r"\d{1,3}(?:,\d{3})+,\d{2}", word["text"])]
        indices.update(word["index"] for word in malformed)
        source_indices = _amount_source_indices(amounts) | indices
        label_words = [word for word in line if word["index"] not in source_indices and word["text"] != "$"]
        text = literal(label_words).rstrip(":").strip()
        period = None
        if _FUNDING.fullmatch(text):
            period = text
        elif text:
            no_year = re.search(r"\s*\(no year\)\Z", text, flags=re.IGNORECASE)
            if no_year:
                period = "no year"
                text = text[: no_year.start()].strip()
            if text:
                label_indices = [word["index"] for word in label_words]
                if open_title:
                    title = {
                        **title,
                        "value": title["value"] + " " + text,
                        "source_lines": title.get("source_lines", [title["line"]]) + [number + 1],
                        "word_indices": title["word_indices"] + label_indices,
                    }
                else:
                    title = {
                        "value": text,
                        "source_page": source_page,
                        "line": number + 1,
                        "word_indices": label_indices,
                    }
        # A title can wrap before its colon or no-year/amount row. Once a
        # funding row begins, later headings start a new title rather than
        # inheriting words from the preceding appropriation.
        open_title = bool(text and period is None and not amounts and not literal(label_words).endswith(":"))
        if not amounts and not malformed:
            continue
        values = dict.fromkeys(column["role"] for column in columns)
        raw = dict.fromkeys(values)
        issues = []
        repairs = []
        observations = {}
        for word, value in amounts:
            column = min(columns, key=lambda column: abs(column["x"] - word["x"]))
            role = column["role"]
            if raw[role] is not None:
                issues.append("multiple_amounts_in_" + role)
                values[role] = None
                raw[role] += " " + word["text"]
            else:
                values[role] = format(value, ".2f")
                raw[role] = word["text"]
                observations[role] = word
        for word in malformed:
            column = min(columns, key=lambda column: abs(column["x"] - word["x"]))
            role = column["role"]
            # A malformed comma is not generally a decimal point. The
            # General fund receipts variant repeats this exact amount in
            # the adjacent net column, with zero opening/closing balances.
            # Those independent source cells qualify the punctuation repair.
            whole, cents = word["text"].rsplit(",", 1)
            candidate = format(Decimal(whole.replace(",", "") + "." + cents), ".2f")
            witnesses = ("opening_unexpended_balance", "net_disbursements", "closing_unexpended_balance")
            if (
                role == "transfers_appropriations"
                and raw[role] is None
                and values.get(witnesses[0]) == values.get(witnesses[2]) == "0.00"
                and values.get(witnesses[1]) == candidate
                and all(witness in observations for witness in witnesses)
            ):
                values[role] = candidate
                raw[role] = word["text"]
                repairs.append(
                    {
                        "code": "decimal_separator_from_same_row_repeated_amount",
                        "field": role,
                        "before": word["text"],
                        "after": candidate,
                        "source_word_indices": [word["index"]],
                        "witness_word_indices": [observations[witness]["index"] for witness in witnesses],
                        "reason": "The source repeats the amount in the net column with zero opening and closing balances.",
                    }
                )
            else:
                raw[role] = word["text"] if raw[role] is None else raw[role] + " " + word["text"]
                values[role] = None
                issues.append("unresolved_monetary_punctuation_in_" + role)
        if title is None:
            issues.append("appropriation_title_unresolved")
        total = bool(title and title["value"].casefold().startswith("total"))
        rows.append(
            {
                "line": number + 1,
                "table_kind": "appropriation_summary",
                "row_kind": "report_total" if total else "appropriation_funding_period",
                "appropriation_title": title["value"] if title else None,
                "title_origin": title,
                "funding_period_literal": period,
                "label": None,
                "raw_label": literal(label_words),
                "values": values,
                "raw_fields": raw,
                "word_indices": [word["index"] for word in line],
                "money_word_indices": sorted(indices),
                "issues": issues,
                "repairs": repairs,
            }
        )
        if readings := _amount_readings(amounts):
            rows[-1]["money_readings"] = readings
    return rows, title


def _statement_period(lines, source_page):
    candidates = [(number, line) for number, line in enumerate(lines) if literal(line).upper().startswith("FROM ")]
    if len(candidates) != 1:
        return None
    number, line = candidates[0]
    text = literal(line)
    # Reuse the maintained literal date reader; the native statement also
    # prints the conventional SEPT. abbreviation in one edition.
    expanded = re.sub(r"\bSEPT\.", "September", text, flags=re.IGNORECASE)
    period = read_report_period(expanded, chamber="house")
    amendment = [word for previous in lines[:number] for word in previous if word["text"].upper() == "AMENDED"]
    return {
        "period_start": period.period_start,
        "period_end": period.period_end,
        "amended": bool(amendment),
        "issues": list(period.period_issues),
        "origin": {
            "source_page": source_page,
            "line": number + 1,
            "literal": text,
            "word_indices": [word["index"] for word in line],
            "amendment_word_indices": [word["index"] for word in amendment],
            "basis": "printed_statement_heading",
        },
    }


def iter_house_summary_pages(
    body: bytes, *, report_period_start, report_period_end, pages=None, source_page_numbers=None
):
    """Yield source summaries; unknown money, native text and coordinates remain explicit."""
    previous = None
    statement = None
    preceding_page = None
    for page in iter_house_disbursements_pages(
        body,
        report_period_start=report_period_start,
        report_period_end=report_period_end,
        pages=pages,
        source_page_numbers=source_page_numbers,
    ):
        lines = financial_lines(page["words"])
        printed, ordinal = _printed_page(lines)
        printed_period = _statement_period(lines, page["source_page"])
        contiguous = bool(
            preceding_page
            and ordinal is not None
            and preceding_page["ordinal"] is not None
            and ordinal == preceding_page["ordinal"] + 1
            and page["source_page"] == preceding_page["source_page"] + 1
            and page["page_bbox"] == preceding_page["page_bbox"]
        )
        if printed_period:
            statement = printed_period
        elif not contiguous:
            statement = None
        headings = {
            key: next((number for number, line in enumerate(lines) if literal(line).startswith(prefix)), None)
            for key, prefix in (
                ("accountability", _ACCOUNTABILITY),
                ("appropriations", _APPROPRIATIONS),
                ("receipts", _RECEIPTS),
            )
        }
        result = {
            key: page[key]
            for key in (
                "source_sha256",
                "page",
                "source_page",
                "physical_pages",
                "page_bbox",
                "image_count",
                "words",
                "text",
            )
        }
        result.update(rule=RULE, printed_page=printed, records=[], issues=[], tables=[])
        if not page["image_count"]:
            for kind in ("accountability", "receipts"):
                start = headings[kind]
                if start is not None:
                    end = min(
                        (number for number in headings.values() if number is not None and number > start),
                        default=len(lines),
                    )
                    result["records"].extend(_simple_rows(lines, start, end, kind))
            header = (
                _appropriation_header(lines, headings["appropriations"])
                if headings["appropriations"] is not None
                else None
            )
            carried_title = None
            if (
                header is None
                and previous
                and ordinal is not None
                and previous["ordinal"] is not None
                and ordinal == previous["ordinal"] + 1
                and page["source_page"] == previous["source_page"] + 1
                and page["page_bbox"] == previous["page_bbox"]
            ):
                # Only the immediate next page can omit the printed summary
                # header, and it must begin with its continuing financial body.
                body_lines = [line for line in lines if not re.fullmatch(r"\(?[IVXLCDM]+\)?", literal(line))]
                first_amounts = [_money(line) for line in body_lines if _money(line)][:5]
                if (
                    body_lines
                    and first_amounts
                    and all(len(amounts) >= 2 for amounts in first_amounts)
                    and (_money(body_lines[0]) or literal(body_lines[0]).endswith(":"))
                    and not any(number is not None for number in headings.values())
                ):
                    header = {**previous["header"], "body_start": 0, "header_basis": "previous_contiguous_summary_page"}
                    carried_title = previous["title"]
            if header:
                rows, title = _appropriation_rows(lines, header, page["source_page"], carried_title)
                result["records"].extend(rows)
                result["tables"].append(header)
                previous = (
                    {
                        "source_page": page["source_page"],
                        "ordinal": ordinal,
                        "page_bbox": page["page_bbox"],
                        "header": header,
                        "title": title,
                    }
                    if rows and rows[-1]["row_kind"] != "report_total"
                    else None
                )
            else:
                previous = None
        else:
            previous = None
        result["records"].sort(key=lambda row: row["line"])
        for row in result["records"]:
            row.update(
                period_start=statement["period_start"] if statement else None,
                period_end=statement["period_end"] if statement else None,
                amended=statement["amended"] if statement else None,
                period_origin=(
                    {
                        **statement["origin"],
                        "basis": "printed_statement_heading" if printed_period else "previous_contiguous_statement",
                    }
                    if statement
                    else None
                ),
            )
            row["issues"].extend(statement["issues"] if statement else ["summary_period_unresolved"])
        _apply_reviewed_amount_repairs(result, len(body))
        for row in result["records"]:
            _check_appropriation_balance(row)
        assigned = {index for row in result["records"] for index in row["money_word_indices"]}
        result["unassigned_money_word_indices"] = [
            word["index"]
            for word in page["words"]
            if word["index"] not in assigned
            and (parse_amount(word["text"]) is not None or re.search(r"\d[,.]\d", word["text"]))
        ]
        recognized = {row["line"] for row in result["records"]}
        result["lines"] = [
            {
                "line": number,
                "word_indices": [word["index"] for word in line],
                "role": "summary" if number in recognized else "unassigned_text",
            }
            for number, line in enumerate(lines, 1)
        ]
        result["outside_ledger_word_indices"] = []
        result["status"] = (
            "image_content_pending"
            if page["image_count"]
            else "summary_read"
            if result["records"]
            else "no_recognized_summary"
        )
        preceding_page = {"source_page": page["source_page"], "ordinal": ordinal, "page_bbox": page["page_bbox"]}
        if page["image_count"] or not result["records"]:
            statement = None
        yield result
