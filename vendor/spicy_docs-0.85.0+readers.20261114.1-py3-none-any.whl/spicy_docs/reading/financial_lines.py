"""Group positioned financial text without merging adjacent printed rows."""

from spicy_docs.reading.pdf_grid import visual_lines


def financial_lines(words):
    """Join mixed font sizes only when every word shares a substantial vertical band."""
    lines = []
    for line in visual_lines(words):
        combined = lines[-1] + line if lines else line
        overlap = min(word["bbox"][3] for word in combined) - max(word["bbox"][1] for word in combined)
        height = min(word["bbox"][3] - word["bbox"][1] for word in combined)
        if lines and overlap >= height / 2:
            lines[-1] = sorted(combined, key=lambda word: (word["x"], word["index"]))
        else:
            lines.append(line)
    return lines
