"""Small positional primitives for source-owned PDF grid readers.

Native words and their original indices remain intact. Display coordinates
account for the page rotation, and line clustering never discards a word.
"""

from __future__ import annotations


def display_words(page):
    """Return indexed native words with native and displayed point coordinates."""
    import pymupdf

    result = []
    for index, word in enumerate(page.get_text("words")):
        box = list(pymupdf.Rect(word[:4]) * page.rotation_matrix)
        result.append(
            {
                "index": index,
                "text": word[4],
                "native_bbox": list(word[:4]),
                "bbox": box,
                "x": (box[0] + box[2]) / 2,
                "y": (box[1] + box[3]) / 2,
            }
        )
    return result


def visual_lines(words, *, tolerance=1.0):
    """Group word centers by displayed baseline, retaining top/left order."""
    lines = []
    for word in sorted(words, key=lambda item: (item["y"], item["x"], item["index"])):
        if not lines or word["y"] - lines[-1][0]["y"] > tolerance:
            lines.append([])
        lines[-1].append(word)
    return [sorted(line, key=lambda item: (item["x"], item["index"])) for line in lines]


def vertical_rules(page):
    """Read actual vertical line segments, including rectangle edges, in display space."""
    result = []
    for drawing in page.get_drawings():
        for item in drawing["items"]:
            if item[0] == "l":
                segments = [(item[1], item[2])]
            elif item[0] == "re":
                rect = item[1]
                segments = [(rect.tl, rect.tr), (rect.tr, rect.br), (rect.br, rect.bl), (rect.bl, rect.tl)]
            else:
                continue
            for start, end in segments:
                start, end = start * page.rotation_matrix, end * page.rotation_matrix
                if abs(start.x - end.x) < 0.2 and abs(start.y - end.y) > 4:
                    result.append((start.x, min(start.y, end.y), max(start.y, end.y)))
    # A border can be several touching filled rectangles. Merge their
    # half-point edges and adjacent segments before reading enclosing cells.
    columns = []
    for rule in sorted(result):
        if not columns or rule[0] - columns[-1][0][0] > 0.75:
            columns.append([])
        columns[-1].append(rule)
    merged = []
    for column in columns:
        x = sum(rule[0] for rule in column) / len(column)
        intervals = []
        for _, start, end in sorted(column, key=lambda rule: rule[1]):
            if not intervals or start > intervals[-1][1] + 2:
                intervals.append([start, end])
            else:
                intervals[-1][1] = max(intervals[-1][1], end)
        merged.extend((x, start, end) for start, end in intervals)
    return merged


def literal(words):
    """Join positioned words without changing their spelling or punctuation."""
    return " ".join(word["text"] for word in words)


def label_words(page, original_words):
    """Read labels whose PDF bolding repeats glyphs at identical positions.

    Some publisher headings overprint partial spans: the word extractor returns
    ``DO DOCUM CUMENT NT`` although the page prints ``DOCUMENT``. Reassemble
    positioned characters, removing only identical glyphs at identical bounds.
    This alternate view is for grid labels; original transaction words survive.
    """
    import pymupdf

    characters = {}
    for block in page.get_text("rawdict")["blocks"]:
        for line in block.get("lines", []):
            for span in line["spans"]:
                for char in span["chars"]:
                    box = list(pymupdf.Rect(char["bbox"]) * page.rotation_matrix)
                    key = (char["c"], *(round(value, 3) for value in box))
                    characters[key] = {
                        "index": len(characters),
                        "text": char["c"],
                        "bbox": box,
                        "x": (box[0] + box[2]) / 2,
                        "y": (box[1] + box[3]) / 2,
                    }
    result = []
    for line in visual_lines(characters.values()):
        tokens = []
        separated = True
        for char in line:
            if char["text"].isspace():
                separated = True
                continue
            if tokens:
                previous = tokens[-1][-1]
                height = min(char["bbox"][3] - char["bbox"][1], previous["bbox"][3] - previous["bbox"][1])
                separated |= char["bbox"][0] - previous["bbox"][2] > height * 0.2
            if separated or not tokens:
                tokens.append([])
            tokens[-1].append(char)
            separated = False
        for token in tokens:
            box = [
                min(char["bbox"][0] for char in token),
                min(char["bbox"][1] for char in token),
                max(char["bbox"][2] for char in token),
                max(char["bbox"][3] for char in token),
            ]
            indices = [
                word["index"]
                for word in original_words
                if box[1] <= word["y"] <= box[3] and min(box[2], word["bbox"][2]) - max(box[0], word["bbox"][0]) > 0.1
            ]
            if indices:
                result.append(
                    {
                        "index": indices[0],
                        "word_indices": indices,
                        "text": "".join(char["text"] for char in token),
                        "bbox": box,
                        "x": (box[0] + box[2]) / 2,
                        "y": (box[1] + box[3]) / 2,
                    }
                )
    return result
