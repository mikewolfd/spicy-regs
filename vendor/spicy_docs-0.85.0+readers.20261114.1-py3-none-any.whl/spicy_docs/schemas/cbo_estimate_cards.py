"""Declarative CBO card schema and generated table columns.

The schema is JSON Schema 2020-12, consumable by DocSpec's jsonschema_rs adapter.
Runtime shaping and validation belong to sources.cbo; this module stays a
standard-library-only schema leaf. Literal cells remain authoritative.
"""

from __future__ import annotations

from spicy_docs.schemas.tables import VALUE_KEY, table_contract

SCHEMA_VERSION = "cbo-estimate-card/1"
CARD_MEASURES = (
    "direct_spending_outlays",
    "revenues",
    "increase_or_decrease_in_the_deficit",
    "spending_subject_to_appropriation_outlays",
)
CARD_QUESTIONS = (
    "pay_go",
    "increase_net_spending",
    "increase_budget_deficits",
    "mandate_effect_intergovernmental",
    "mandate_effect_private_sector",
)
CARD_UNIT = "millions-usd"
CARD_WINDOWS = 3


def _text(description, *, nullable=True, **constraints):
    return {"type": ["string", "null"] if nullable else "string", "description": description, **constraints}


def _object(properties):
    return {"type": "object", "properties": properties, "required": list(properties), "additionalProperties": False}


_window = {"period": _text("Literal fiscal window heading, in printed position.", nullable=False, minLength=1)}
for _measure in CARD_MEASURES:
    _window[_measure + "_literal"] = _text("Printed cell; null means this measure is not stated.")
    _window[_measure + "_millions"] = {
        "type": ["integer", "null"],
        "description": "Whole millions derived exactly from the literal and source_unit; null for an unstated or nonnumeric amount.",
    }

_properties = {
    "publication_id": _text(
        "CBO publication identity, independent of any bill link.", nullable=False, pattern=r"^[1-9][0-9]{0,8}$"
    ),
    "congress": {"type": ["integer", "null"], "description": "Congress named by the selected feed."},
    "publication_date": _text("Selected feed Date as a UTC instant; distinct from archive capture time."),
    "publication_title": _text("Selected feed Title, including unresolved bill descriptions."),
    "publication_context": _text("Selected feed Description, retained without inferring bill stage."),
    "title": _text("Literal card heading.", nullable=False),
    "subtitle": _text("Literal card subtitle, where printed."),
    "unit": {
        "const": CARD_UNIT,
        "type": "string",
        "description": "Normalized fiscal-year amounts in millions of dollars; source_unit keeps the printed unit.",
    },
    "source_unit": {
        "type": "string",
        "enum": [CARD_UNIT, "billions-usd"],
        "description": "Unit CBO printed, retained beside normalized millions.",
    },
    "reported_measures": {
        "type": "array",
        "items": _object(
            {
                "source_field": {"type": "string"},
                "label": {"type": "string"},
                "source_unit": {"type": "string", "enum": [CARD_UNIT, "billions-usd"]},
                "literals": {
                    "type": "array",
                    "minItems": CARD_WINDOWS,
                    "maxItems": CARD_WINDOWS,
                    "items": {"type": ["string", "null"]},
                },
                "millions": {
                    "type": "array",
                    "minItems": CARD_WINDOWS,
                    "maxItems": CARD_WINDOWS,
                    "items": {"type": ["integer", "null"]},
                },
            }
        ),
        "description": "Every printed financial row in source order, including named committee components and the publisher-stated total; no total is inferred.",
    },
    "notes": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Literal footer context, limitations and uncertainty, including effects CBO did not review.",
    },
    "windows": {
        "type": "array",
        "minItems": CARD_WINDOWS,
        "maxItems": CARD_WINDOWS,
        "items": _object(_window),
        "description": "Exactly three positional fiscal windows with literal headings and amounts.",
    },
    "answers": {
        **_object({name: _text("Literal CBO answer, including thresholds or uncertainty.") for name in CARD_QUESTIONS}),
        "description": "PAYGO, long-term budget and mandate answers as printed; null means unstated.",
    },
    "flags": {
        **_object({name: {"type": ["boolean", "null"]} for name in CARD_QUESTIONS}),
        "description": "Leading Yes/No answers as booleans; thresholds and other answers stay in answers, with null when no boolean is stated.",
    },
    "footnotes": {
        "type": "array",
        "items": {"type": "string"},
        "description": "Literal notes defining asterisks, per-bill application and qualifications.",
    },
    "pdf_urls": {
        "type": "array",
        "items": {"type": "string"},
        "description": "PDF URLs explicitly linked by the publication; not bill/month guesses.",
    },
    "card_source": {
        "type": "string",
        "enum": ["archive-page", "pdf-native", "pdf-ocr", "pdf-llm"],
        "description": "Source and reading route; PDF routes require separate qualification.",
    },
    "markup": _text("Source layout label, where applicable."),
    "schema_version": {"type": "string", "const": SCHEMA_VERSION, "description": "Shared card schema identity."},
}
for _name, _description in {
    "source_sha256": "Original WARC member SHA-256, not a decoded-copy identity.",
    "source_locator": "WARC record ID plus payload locator; PDF page is separately identified.",
    "receipt_object": "Archive-relative immutable acquisition receipt.",
    "authority": "Archive authority rather than a current publisher answer.",
    "archive_operator": "Public archive operator.",
    "original_publisher_url": "Publisher URL named by the verified WARC record.",
    "archive_timestamp": "Selected archive capture timestamp, YYYYMMDDhhmmss.",
    "earliest_timestamp": "Earliest status-200 capture in the declared index population.",
    "index_sha256": "Retained index answer digest.",
    "index_digest": "Archive index payload digest, independently checked against retained payload.",
    "crawl_id": "Common Crawl collection identity.",
    "warc_filename": "Archive-native WARC path.",
    "extraction_method": "Maintained reader and version used for this observation.",
    "model_id": "Model identity on a structured model observation; otherwise null.",
    "request_id": "Retained model request identity; otherwise null.",
    "identity_rule": "Publication/PDF association rule and retained supporting evidence.",
}.items():
    _properties[_name] = _text(_description)
for _name, _description in {
    "captures": "Distinct status-200 capture coordinates in the declared index population.",
    "warc_offset": "Byte offset of the original WARC member.",
    "warc_length": "Byte length of the original WARC member.",
    "page_number": "One-based original PDF page; null for an HTML card.",
}.items():
    _properties[_name] = {"type": ["integer", "null"], "minimum": 0, "description": _description}

CBO_ESTIMATE_CARD_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "urn:spicy-docs:" + SCHEMA_VERSION,
    **_object(_properties),
}


def _sql_type(schema):
    kind = schema["type"]
    kind = next(t for t in kind if t != "null") if isinstance(kind, list) else kind
    if kind == "object":
        return "STRUCT(" + ", ".join(f"{name} {_sql_type(child)}" for name, child in schema["properties"].items()) + ")"
    if kind == "array":
        return _sql_type(schema["items"]) + "[]"
    return {"string": "VARCHAR", "integer": "BIGINT", "boolean": "BOOLEAN"}[kind]


CBO_ESTIMATE_CARDS = table_contract(
    "cbo_estimate_cards",
    grain="One qualified card per CBO publication, selecting the latest verified archive capture; bill links remain in cbo_cost_estimates.",
    identity=("publication_id",),
    key_spelling=VALUE_KEY,
    version_column="archive_timestamp",
    columns={name: schema["description"] for name, schema in _properties.items()},
    types={name: _sql_type(schema) for name, schema in _properties.items() if _sql_type(schema) != "VARCHAR"},
)
