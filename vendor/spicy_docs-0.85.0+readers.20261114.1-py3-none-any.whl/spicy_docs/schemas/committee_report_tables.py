"""``committee_reports`` (one row per report part), ``committee_report_cbo_letters`` (one row per reprinted CBO letter),
``hearing_transcripts`` and ``report_sections``, keyed on GovInfo packages rather than on a bill, so ``bill_id`` is
nullable and a row exists without a linkage nothing can make yet.

``hearing_transcripts.bill_id`` is always NULL because a legislative hearing is held on a list of bills, which
``hearing_bill_links`` hosts, while a report is filed against one bill and keeps its scalar.  The appended CBO estimate
columns are the report-to-estimate link: the part row states what the cover declared and how many letters were
located, each letter's span sits on its own ``committee_report_cbo_letters`` row (an omnibus report reprints up to 11),
no ``document_citations`` row is written because the print names no estimate key, and the join is on the bill via the
print's own ``recital_bill_id``.
"""

from __future__ import annotations

from spicy_docs.schemas.tables import Reference, Row, flag, json_column, table_contract, text

#: Processing identity for report heading segmentation and table shaping.
#: Hosts include it in their read checkpoint alongside the CBO reader version;
#: publisher last_modified cannot invalidate a corrected reader. Bump this
#: when segmentation or these output semantics change: ``001`` kept the source
#: heading; ``002`` made a report one row per part (``part_id``), so every
#: package is re-read into part rows; ``003`` moved each CBO letter to its own
#: ``committee_report_cbo_letters`` row, so every part is re-read into letters.
REPORT_SECTION_READER_VERSION = "report-headings-003"

#: Which chamber each GovInfo document-type code belongs to.  CRPT's ``erpt``
#: is a Senate executive report, not a House one; naming the six codes as data
#: keeps that from being re-derived from a first letter.
CHAMBER_BY_DOCUMENT_TYPE: dict[str, str] = {
    "hrpt": "house",
    "srpt": "senate",
    "erpt": "senate",
    "hhrg": "house",
    "shrg": "senate",
    "jhrg": "joint",
}


def _package_columns(
    *,
    type_column: str,
    type_description: str,
    number_column: str,
    number_description: str,
) -> dict[str, str]:
    """The columns a captured GovInfo package states, in publish order.

    A committee report and a hearing transcript differ in exactly two column
    names -- what the document-type code and the number are called -- so the
    prose for the other seventeen is written once here, in the same order
    :func:`_package_row` fills them.
    """
    return {
        "package_id": "The GovInfo package id; last_modified identifies its retained package revision.",
        "collection": "The GovInfo collection the package belongs to (CRPT, CHRG).",
        "congress": "The numbered Congress, parsed from the package id's own grammar.",
        type_column: type_description,
        number_column: number_description,
        "chamber": "The chamber, from the package id's document-type code rather than from its first letter.",
        "title": "The package title as the keyed summary states it.",
        "date_issued": "The date the package was issued.",
        "last_modified": "The publisher's package addition/update timestamp, including metadata-only updates. Together with package_id it identifies a retained revision; it is not first publication or a promise that every text change has a unique timestamp.",
        "bill_id": "The bill this package concerns, where a linkage exists; nullable by design (C11).",
        "format": "Which rendition was read (htm, xml, txt, pdf).",
        "media_type": "The response media type, proved against the format before the body was accepted.",
        "requested_url": "The URL the body fetch asked for.",
        "resolved_url": "The URL the body actually came from.",
        "byte_size": "Length in bytes of the captured body.",
        "sha256": "Digest of the captured body bytes.",
        "observed_at": "When the body was captured.",
        "page_count": "How many pages the extraction read, where a page-based extractor ran.",
        "text_sha256": "Digest of the extracted text, so a re-extraction that changed nothing is visible as such.",
    }


#: The two columns both tables append last (docs/tables.md), after their own
#: appendices, so every column before them keeps its position.
_BODY_COMPLETENESS_COLUMNS = {
    "body_completeness": (
        "What the read text states about itself (`sources.govinfo.bodies.publisher_body_status`): "
        "`publisher_placeholder` where it is the publisher's own notice that the text is only in the PDF, so "
        "text_sha256 digests that notice, not the document; `pdf_extracted` for text extracted from a PDF, "
        "including one read in place of a placeholder; `not_flagged` otherwise.  No value asserts the text is "
        "complete.  NULL on a row not re-read since the column was added."
    ),
    "text_derivation": (
        "The derivation that produced the text text_sha256 digests (`markup-reader`, `text-rendition-cleanup` or "
        "`pdf-extraction-gpo-normalized`), from the body sha256 digests; NULL on a row not re-read since the "
        "column was added."
    ),
}


COMMITTEE_REPORTS = table_contract(
    "committee_reports",
    references=(Reference(("bill_id",), "congress_bills", ("bill_id",)),),
    grain=(
        "One row per published part at one dated GovInfo package revision, with the CBO estimate it "
        "reprints or refuses."
    ),
    identity=("package_id", "part_id", "last_modified"),
    version_column="last_modified",
    columns={
        **_package_columns(
            type_column="report_type",
            type_description="The report's document-type code (hrpt, srpt, erpt).",
            number_column="report_number",
            number_description="The report's number within its Congress and type.",
        ),
        # Overridden in place, so the column keeps its position; only the
        # sentence changes, because the identity is now the package and part.
        "package_id": (
            "The GovInfo package id: with part_id and last_modified, this row's identity.  Summary facts (title, date_issued, "
            "last_modified) are the package's and repeat on every part row."
        ),
        # Appended after the nineteen shared columns, the way a hosted table
        # takes new ones (docs/tables.md): every column before this keeps its
        # order and spelling for anyone pinning the prefix.  NULL throughout
        # where no estimate rule was run over this package's text.
        "estimate_rule": (
            "Which rule read this report's cost-estimate statement.  Named even though there is one today, "
            "for the reason document_citations names its own: a second reader over another rendition "
            "would have to say which one produced the span."
        ),
        "estimate_rule_version": (
            "That rule's version, a digest over all patterns, flags, rejects, heading thresholds and rule revision, so a re-read "
            "under a corrected rule is attributable."
        ),
        "report_states_estimate": (
            "Whether the report's own cover carries the statutory recital `Including cost estimate of the "
            "Congressional Budget Office`, printed in brackets.  This is the gate and a heading is never "
            "one: three retained "
            "reports print a CBO heading over a section saying the estimate was not received, and one prints "
            "the estimate under a heading no pattern set had.  `false` is requested-empty with "
            "estimate_absence_reason attached, never absence: 3 of 13 reported bills whose index named an "
            "estimate had none in the report."
        ),
        "recital_bill_id": (
            "The measure the cover states this report accompanies, keyed the way congress_bills.bill_id is, "
            "with the Congress taken from this package's own identity because the cover states none.  The "
            "print's own answer to the report-to-bill join, which is what cbo_cost_estimates.bill_id joins "
            "against; bill_id beside it stays whatever index record the caller read."
        ),
        # Kept in place (ss-uep5): a part-level fact here, a letter-level one on
        # committee_report_cbo_letters, never both for the same heading.
        "estimate_heading": (
            "The part's first cost-estimate section heading, as the committee spelled it, collapsed to one line "
            "where GPO wrapped it across two -- **only where no located CBO letter opens on it**.  Two-sided: a "
            "heading that opens a letter is that letter's fact and sits on its committee_report_cbo_letters row, "
            "so this is NULL there; a heading that opens none (a declared estimate whose letter was not located, "
            "an undeclared report's `Congressional Budget Office Cost Estimate` section saying none was "
            "received, or a committee's own `COMMITTEE COST ESTIMATE` section printed apart from the letter) "
            "is the part's and sits here.  Read whether or not the cover declares an estimate."
        ),
        "estimate_heading_rule": (
            "Which entry of the heading vocabulary matched estimate_heading; NULL exactly where it is.  **That "
            "vocabulary is a floor**: it only ever locates a span the recital already declared."
        ),
        "estimate_absence_reason": (
            "The publisher's own paragraph saying why the estimate is not here, verbatim, where the cover "
            "declares none.  Carried whole rather than as a span, unlike the letter: it is a paragraph, and a "
            "row that holds the words needs no offset to read them."
        ),
        "estimate_absence_rule": (
            "Which reason pattern matched: `not_available` (the estimate had not arrived when the report was "
            "filed) or `not_received` (the committee asked and CBO had not answered).  NULL where the report "
            "gives no reason, which is not the same as having none to give."
        ),
        # Appended last, the way a hosted table takes new columns (docs/tables.md).
        "part_id": (
            "The part of the report this row is: the publisher's own granule id for it, which is also the file "
            "stem its body was read at (`CRPT-119hrpt455-pt2`).  The package id itself where the part's stem is "
            "the package's: a report published in one part, and a Part 1 the publisher left unsuffixed "
            "(`CRPT-119hrpt494`).  Never NULL, because it is half the identity; a package's part rows are "
            "replaced as a set."
        ),
        "part_number": (
            "The part's number as the publisher states it (its `partNumber`, or the `-pt{N}` its id carries, "
            "which must agree).  NULL on a report published in one part at the package id, whose record numbers "
            "none; a report the publisher issued as a lone `-pt1` is (`{package}-pt1`, 1), so a reader counts "
            "rows per package to tell it from Part 1 of several."
        ),
        **_BODY_COMPLETENESS_COLUMNS,
        # Appended last (docs/tables.md).  The five per-letter columns that
        # stood between estimate_heading_rule and estimate_absence_reason moved
        # to committee_report_cbo_letters, one row per letter (ss-uep5, owner Q2).
        "cbo_letter_count": (
            "How many reprinted CBO letters were located in this part, each a committee_report_cbo_letters row "
            "keyed (package_id, part_id, last_modified, letter_seq).  0 where the cover declares an estimate and no letter's "
            "both ends were found, or where it declares none; NULL where no estimate rule was run, which is "
            "not the same as a count of zero."
        ),
    },
)

COMMITTEE_REPORT_CBO_LETTERS = table_contract(
    "committee_report_cbo_letters",
    references=(
        Reference(
            ("package_id", "part_id", "last_modified"), "committee_reports", ("package_id", "part_id", "last_modified")
        ),
    ),
    grain=("One row per CBO letter in a report part at one package revision whose cover declares the estimate."),
    identity=("package_id", "part_id", "last_modified", "letter_seq"),
    version_column="last_modified",
    columns={
        "package_id": "The report package the letter was read from.",
        "part_id": (
            "The report part the letter was read from, spelled as `committee_reports.part_id`, so "
            "(package_id, part_id, last_modified) is the parent row."
        ),
        "letter_seq": "Zero-based position of this letter in its part, in reading order.",
        "estimate_heading": (
            "The section heading the letter opens on, as the committee spelled it, collapsed to one line where "
            "GPO wrapped it across two.  NULL where the letter opens on its CBO letterhead because no vocabulary "
            "heading precedes it (CRPT-111hrpt385-pt1 prints its heading after the letter)."
        ),
        "estimate_heading_rule": (
            "Which entry of the heading vocabulary matched, or `letterhead` where the letter opens on the CBO "
            "letterhead itself rather than a heading.  **That vocabulary is a floor**: it only ever locates a "
            "span the recital already declared."
        ),
        "letter_span_start": (
            "Character offset of the letter in the extracted text the parent row's text_sha256 digests, counted "
            "from zero.  The letter is not carried in the row, so the span is how it is re-read."
        ),
        "letter_span_end": "Offset just past the letter, so text[letter_span_start:letter_span_end] is it.",
        "letter_text_sha256": (
            "Digest of exactly those characters, so a consumer can prove the span it re-read is the span that "
            "was measured.  A re-extraction that moved one character moves every offset after it, which is "
            "why the parent's text_sha256 says which text these offsets index into."
        ),
        "letter_end_rule": (
            "How the letter's end was found: the close CBO printed -- `director_attribution` (118th), "
            "`for_director`, `named_director`, `named_signature` or `for_director_unnamed_title` (1997-2011) "
            "-- or `next_heading_in_series` where the report prints a summary table with no close at all.  A "
            "transmittal followed by `Enclosure.` runs on as `<close>+estimate_approval` through the enclosed "
            "estimate's approval line (`Estimate approved by ... Analysis.`), or `<close>+next_heading_in_series` "
            "where that estimate prints none, so a bare close name marks a span without its estimate.  A letter "
            "whose end could not be found is no row rather than a guessed boundary."
        ),
        "letter_signatory": (
            "The Director as the letter names them; NULL where the attribution states no name, which the one "
            "table-shaped estimate does."
        ),
        "letter_date": (
            "The date the letter's CBO letterhead prints (`Washington, DC, June 16, 1997.`), as YYYY-MM-DD.  "
            "NULL where the letter prints no dateline, which every 118th-Congress letter is: their date is "
            "cbo_cost_estimates' publication date, not repeated here."
        ),
        "last_modified": (
            "The parent report's last_modified, carried so this table versions with the package it came from."
        ),
    },
)

HEARING_TRANSCRIPTS = table_contract(
    "hearing_transcripts",
    references=(
        Reference(("congress", "chamber", "event_id"), "committee_meetings", ("congress", "chamber", "event_id")),
        Reference(("congress", "chamber", "mods_event_id"), "committee_meetings", ("congress", "chamber", "event_id")),
    ),
    grain="One row per dated revision of a captured GovInfo hearing transcript package.",
    identity=("package_id", "last_modified"),
    version_column="last_modified",
    columns={
        **_package_columns(
            type_column="hearing_type",
            type_description="The hearing's document-type code (hhrg, shrg, jhrg).",
            number_column="jacket_number",
            number_description="The hearing's printing jacket number, leading zeros kept because it is opaque.",
        ),
        # Overridden in place, so the column keeps its position for anyone
        # pinning the order; only the sentence changes.
        "date_issued": (
            "The date GovInfo issued the package; for CHRG packages this is the (first) held date: the summary's "
            "dateIssued equals the MODS's first heldDate on 185 of 185 published transcripts (2026-10-03), and the "
            "meeting's date on 117 of 117 matched to committee_meetings.  held_date states it from the MODS itself."
        ),
        "bill_id": (
            "Always NULL here, and NULL for a stated reason: a legislative hearing is held on a *list* of "
            "bills -- twelve of them on CHRG-118hhrg56198 -- so a scalar column would have to pick one of "
            "twelve.  The relationship is one-to-many and `hearing_bill_links` hosts it, one row per "
            "hearing, bill and source, the way `event_id` names `committee_meetings`.  The column stays "
            "because this table shares its shape with `committee_reports`, where a report *is* filed "
            "against one bill."
        ),
        # Appended last, the way a hosted table takes a new column (docs/tables.md):
        # the nineteen columns before it keep their order for anyone pinning it.
        "event_id": (
            "The committee-meeting event id the Congress.gov hearing record names as its associatedMeeting, "
            "which committee_meetings.event_id joins on; NULL where the hearing names none or was not looked up."
        ),
        **_BODY_COMPLETENESS_COLUMNS,
        # Appended after the body-completeness pair, the way a hosted table
        # takes new columns (docs/tables.md), so every column before keeps its
        # position: what the package's own GovInfo MODS states about the hearing.
        "witnesses_json": (
            "Every witness the package's GovInfo MODS states, as a JSON array of its `<witness>` strings verbatim "
            "in document order -- name, position and organization as GPO wrote them, unsplit, because the record "
            "joins them in one string and spells them differently by chamber.  NULL where the MODS states none, "
            "never `[]`: MODS has no element for an empty witness list, so its silence is absence.  The "
            "Congress.gov meeting record lists no Senate witness at all, while the MODS lists them for 63 of 85 "
            "published Senate transcripts (2026-10-03)."
        ),
        "held_date": (
            "The day the hearing was held, as the package's MODS states it in `<heldDate>`; NULL where the MODS "
            "states none.  A compiled volume states several (2 of 185 published transcripts, 2026-10-03; "
            "CHRG-117shrg56721 states eleven) and this is the first: it dates the package, as date_issued does, "
            "so there it is when the series began, not each session's date.  hearing_bill_links.held_date is NULL "
            "on the same volume for a different reason: a link pairs a date with a bill, and the volume pairs none."
        ),
        "mods_event_id": (
            "The committee-meeting event id the package's GovInfo MODS states in `<eventId>` (the first, where it "
            "states several), which committee_meetings.event_id joins on with congress and chamber.  A second "
            "publisher's statement beside event_id, never overriding it: a consumer may fall back to it where "
            "event_id is NULL.  43 of 185 published transcripts state one, 22 where Congress.gov names none, 21 "
            "of them Senate; where both state one they agree 21 of 21 (2026-10-03), including a misassignment "
            "both make (CHRG-118hhrg63377 names 116369, another subcommittee's hearing that day), so agreement "
            "is not independent confirmation."
        ),
        "committee_system_codes_json": (
            "The committees the package's GovInfo MODS names as holding the hearing: each `congCommittee` "
            "`authorityId`, the system code committees.system_code and committee_meetings.committee_system_code key "
            "on (`hswm00`), lower-cased the way they key it, once each in the order the MODS first states it, as a "
            "JSON array. Read from the record and then each of its granules, because a hearing published as several "
            "states its committee only there (15 of 185 published transcripts, 2026-10-03); a joint hearing names "
            "two (3 of 185). `[]` where the MODS names none (1 of 185); NULL on a row not read since the column was "
            "added."
        ),
    },
)

REPORT_SECTIONS = table_contract(
    "report_sections",
    references=(
        Reference(
            ("package_id", "part_id", "last_modified"), "committee_reports", ("package_id", "part_id", "last_modified")
        ),
    ),
    grain="One row per heading block of one report part at one package revision.",
    identity=("package_id", "part_id", "last_modified", "seq"),
    version_column="last_modified",
    columns={
        "package_id": "The report package this block was parsed from.",
        "seq": "Zero-based position of this block in its part, in reading order.",
        "agency_label": (
            "NULL because heading recognition does not establish agency identity; the source heading "
            "is retained separately in heading."
        ),
        "agency_key": "NULL because this reader does not resolve headings to agency identities.",
        "body": "The block's text, trimmed the way the original trimmed it.",
        "pattern": (
            "Which header pattern fired to start this block; this table's provenance column.  Two values "
            "are not pattern names: `preamble` for the text before the first header, and `full_report` "
            "for a report where no header matched at all."
        ),
        "char_start": "Start offset of this block's span in the flattened report text.",
        "char_end": "End offset, exclusive; spans partition the whole input with no gap and no overlap.",
        "page_start": "First page the span touches, where the input carried page boundaries.",
        "page_end": "Last page the span touches, where the input carried page boundaries.",
        "body_chars": "Character length of body, which can be shorter than the span it sits in.",
        "last_modified": (
            "The parent report's last_modified, carried so this table versions with the package it came from."
        ),
        "heading": (
            "The source heading as spelled and trimmed, including actual agency names and generic titles; "
            "NULL for preamble or full_report blocks, which have no source heading."
        ),
        "part_id": (
            "The report part this block was parsed from, spelled as `committee_reports.part_id`, so "
            "(package_id, part_id, last_modified) is the parent row.  Appended last."
        ),
    },
)


def _package_row(
    body: object,
    *,
    type_column: str,
    number_column: str,
    bill_id: str | None,
    page_count: int | None,
    text_sha256: str | None,
) -> Row:
    """The row a committee report and a hearing transcript share, in publish order.

    The two tables differ in exactly two column names -- what the package's
    document-type code and its number are called -- so those are named by the
    caller and everything else is written once.
    """
    identity = body.identity
    capture = body.body_capture
    summary = body.summary
    return {
        "package_id": text(identity.package_id),
        "collection": text(identity.collection),
        "congress": text(identity.congress),
        type_column: text(identity.document_type),
        number_column: text(identity.number),
        "chamber": text(CHAMBER_BY_DOCUMENT_TYPE.get(identity.document_type or "")),
        "title": text(summary.title),
        "date_issued": text(summary.date_issued),
        "last_modified": text(summary.last_modified),
        "bill_id": text(bill_id),
        "format": text(body.format),
        "media_type": text(body.body.media_type),
        "requested_url": text(capture.requested_url),
        "resolved_url": text(capture.resolved_url),
        "byte_size": text(capture.byte_size),
        "sha256": text(capture.sha256),
        "observed_at": text(capture.observed_at),
        "page_count": text(page_count),
        "text_sha256": text(text_sha256),
    }


def shape_committee_report(
    body: object,
    *,
    bill_id: str | None = None,
    page_count: int | None = None,
    text_sha256: str | None = None,
    estimate: object = None,
    recital_bill_id: str | None = None,
    body_completeness: str | None = None,
    text_derivation: str | None = None,
) -> Row:
    """One ``committee_reports`` row from one acquired part of a CRPT package.

    ``body`` is one result of ``GovInfoBodyAcquirer.acquire_parts``; its ``part`` names the row's part, and a body
    naming none is refused: a NULL ``part_id`` is half an identity, which a merge keeping only whole identities would
    drop without a word.  ``estimate`` is the
    ``interpretation.cbo_estimates.CboEstimateFinding`` read over this part's text, or ``None`` where no rule was run --
    which lands NULL throughout rather than as ``false``, because "not read" and "the cover declares no estimate" are
    different answers.  ``recital_bill_id`` is passed in rather than derived here because reading a printed designator
    into a bill key is the ``interpretation`` package's vocabulary.
    """
    part = getattr(body, "part", None)
    if part is None:
        raise ValueError(
            f"{body.identity.package_id} names no report part; shape committee_reports rows from acquire_parts results"
        )
    row = _package_row(
        body,
        type_column="report_type",
        number_column="report_number",
        bill_id=bill_id,
        page_count=page_count,
        text_sha256=text_sha256,
    )
    row |= {
        "estimate_rule": text(None if estimate is None else estimate.rule),
        "estimate_rule_version": text(None if estimate is None else estimate.rule_version),
        "report_states_estimate": flag(None if estimate is None else estimate.report_states_estimate),
        "recital_bill_id": text(recital_bill_id),
        "estimate_heading": text(None if estimate is None else estimate.heading),
        "estimate_heading_rule": text(None if estimate is None else estimate.heading_rule),
        "estimate_absence_reason": text(None if estimate is None else estimate.absence_reason),
        "estimate_absence_rule": text(None if estimate is None else estimate.absence_rule),
        "part_id": text(part.part_id),
        "part_number": text(part.part_number),
        "body_completeness": text(body_completeness),
        "text_derivation": text(text_derivation),
        "cbo_letter_count": text(None if estimate is None else len(estimate.letters)),
    }
    return row


def shape_committee_report_cbo_letter(
    letter: object,
    *,
    package_id: str,
    part_id: str,
    seq: int,
    last_modified: str | None = None,
) -> Row:
    """One ``committee_report_cbo_letters`` row from one ``CboEstimateFinding.letters`` entry of one report part.

    ``seq`` is the letter's index in ``letters``, which is document order; ``part_id`` is the parent row's.
    """
    start, end = letter.span
    return {
        "package_id": text(package_id),
        "part_id": text(part_id),
        "letter_seq": text(seq),
        "estimate_heading": text(letter.heading),
        "estimate_heading_rule": text(letter.heading_rule),
        "letter_span_start": text(start),
        "letter_span_end": text(end),
        "letter_text_sha256": text(letter.sha256),
        "letter_end_rule": text(letter.end_rule),
        "letter_signatory": text(letter.signatory),
        "letter_date": text(letter.letter_date),
        "last_modified": text(last_modified),
    }


def shape_hearing_transcript(
    body: object,
    *,
    page_count: int | None = None,
    text_sha256: str | None = None,
    event_id: str | None = None,
    body_completeness: str | None = None,
    text_derivation: str | None = None,
) -> Row:
    """One ``hearing_transcripts`` row from one acquired CHRG package.

    There is deliberately no ``bill_id`` argument: that relationship is one-to-many and ``hearing_bill_links`` hosts it,
    so this shaper cannot fill a scalar the contract says is always NULL.  ``event_id`` is the
    ``associatedMeeting.eventId`` of the Congress.gov hearing detail record; the package's own MODS statements
    (``body.mods``: its event ids, held dates, witnesses and committee codes) fill their own columns beside it and
    never replace it.
    """
    row = _package_row(
        body,
        type_column="hearing_type",
        number_column="jacket_number",
        bill_id=None,
        page_count=page_count,
        text_sha256=text_sha256,
    )
    mods = body.mods
    row["event_id"] = text(event_id)
    row["body_completeness"] = text(body_completeness)
    row["text_derivation"] = text(text_derivation)
    row["witnesses_json"] = json_column(list(mods.witnesses)) if mods.witnesses else None
    row["held_date"] = text(mods.first_held_date)
    row["mods_event_id"] = text(next(iter(mods.event_ids), None))
    row["committee_system_codes_json"] = json_column(list(dict.fromkeys(code.lower() for code in mods.committee_codes)))
    return row


def shape_report_section(
    block: object,
    *,
    package_id: str,
    part_id: str,
    seq: int,
    last_modified: str | None = None,
) -> Row:
    """One ``report_sections`` row from one observed heading block of one report part.

    ``part_id`` is the parent row's (``ReportPart.part_id``) and ``seq`` counts within that part.  ``last_modified`` is
    a column so a merge can read the version column the design names, and ``heading`` stays NULL for
    ``preamble``/``full_report`` blocks, whose ``agency`` is a text shape rather than an agency assertion.
    """
    start, end = block.char_span
    pages = block.page_span
    return {
        "package_id": text(package_id),
        "seq": text(seq),
        "agency_label": None,
        "agency_key": None,
        "body": text(block.body),
        "pattern": text(block.pattern),
        "char_start": text(start),
        "char_end": text(end),
        "page_start": text(None if pages is None else pages[0]),
        "page_end": text(None if pages is None else pages[1]),
        "body_chars": text(len(block.body)),
        "last_modified": text(last_modified),
        "heading": None if block.pattern in {"preamble", "full_report"} else text(block.agency),
        "part_id": text(part_id),
    }


__all__ = [
    "CHAMBER_BY_DOCUMENT_TYPE",
    "COMMITTEE_REPORTS",
    "COMMITTEE_REPORT_CBO_LETTERS",
    "HEARING_TRANSCRIPTS",
    "REPORT_SECTIONS",
    "REPORT_SECTION_READER_VERSION",
    "shape_committee_report",
    "shape_committee_report_cbo_letter",
    "shape_hearing_transcript",
    "shape_report_section",
]
