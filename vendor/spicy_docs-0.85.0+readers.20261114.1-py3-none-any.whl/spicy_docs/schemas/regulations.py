"""The regulations.gov docket, document and comment record types, and the contracts of the tables published from them.

Each :class:`RecordType` pairs an S3 path pattern, Parquet schema, dedup key and extract function; ``RECORD_TYPES`` keys
them by name, and its order drives the default set of data types the pipeline processes.  ``DOCKETS``, ``DOCUMENTS``
and ``COMMENTS`` state the tables the host publishes, each keyed on its dedup key spelled ``value/1``: the extract's
columns in its order, then on documents and comments the host's ``pdf_extraction_results_json``; on comments the
extract's ``subtype`` and ``duplicate_comments``, added later, are appended after that host column.
"""

from collections.abc import Mapping
from json import dumps as json_dumps

from spicy_docs.schemas.base import RecordType
from spicy_docs.schemas.tables import INTEGER, VALUE_KEY, Reference, table_contract

#: ``duplicateComments`` is published as INTEGER (32-bit); the count is never negative.
_COUNT_BOUND = 2**31


def is_count(value: object) -> bool:
    """Whether ``value`` is a count a 32-bit INTEGER column publishes: an int that is not a bool, 0 <= n < 2**31.

    The one spelling of the rule, for the extract and for the Regulations.gov comment validator.
    """
    return isinstance(value, int) and not isinstance(value, bool) and 0 <= value < _COUNT_BOUND


def _stated_count(value: object) -> int | None:
    """A stated ``duplicateComments`` as published: NULL, or a count (:func:`is_count`).

    Invalid values raise before they can be coerced to an integer.
    """
    if value is None:
        return None
    if not is_count(value):
        raise ValueError(f"duplicateComments must be an integer from 0 to 2**31 - 1, not {value!r}")
    return value


#: Publisher key, published field name, and scalar or collection type. Insertion order preserves
#: the historical JSON spelling after title, renditions, restrictions, and identity.
COMMENT_ATTACHMENT_METADATA = {
    "agencyNote": ("agency_note", "text"),
    "authors": ("authors", "text array"),
    "description": ("description", "text"),
    "docAbstract": ("doc_abstract", "text"),
    "docOrder": ("doc_order", "integer"),
    "modifyDate": ("modify_date", "text"),
    "publication": ("publication", "text"),
}
ATTACHMENT_RESTRICTIONS = {"restrictReasonType": "restrict_reason_type", "restrictReason": "restrict_reason"}
ATTACHMENT_ID = "attachment_id"


def attachment_attribute_type(name: str) -> str:
    """The type of a publisher attachment attribute other than the file list."""
    return COMMENT_ATTACHMENT_METADATA.get(name, (name, "text"))[1]


def is_attachment_attribute(name: str, value: object) -> bool:
    """Whether the value can be carried without changing its type."""
    if value is None:
        return True
    kind = attachment_attribute_type(name)
    if kind == "text array":
        return isinstance(value, list) and all(isinstance(author, str) for author in value)
    if kind == "integer":
        return type(value) is int and -(2**63) <= value < 2**63
    return isinstance(value, str)


def comment_rendition_size(value: object) -> int | None:
    """Interpret a byte count; the observed integer -1 carries no usable size.

    Retained HHS-OASH-2022-0006-0002 and FWS-R4-ES-2020-0109-0210 originals
    state this value. It is not a negative byte count or evidence of zero bytes.
    The extract keeps the literal value; native consumers retain it in their
    processing evidence and record the reason when representing it as unknown.
    """
    if value is None or type(value) is int and value == -1:
        return None
    if isinstance(value, str) and value.isdecimal() and len(value.lstrip("0")) <= 19:
        value = int(value.lstrip("0") or "0")
    if type(value) is not int or not 0 <= value < 2**63:
        raise ValueError("attachment.fileFormats.size must state a nonnegative 64-bit byte count or integer -1")
    return value


def _comment_rendition(value: object) -> dict | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError("attachment.fileFormats entries must be objects or null")  # noqa: TRY004
    for field in ("fileUrl", "format"):
        if not is_attachment_attribute(field, value.get(field)):
            raise ValueError(f"attachment.fileFormats.{field} must be text or null")
    comment_rendition_size(value.get("size"))
    return {"url": value.get("fileUrl") or None, "format": value.get("format"), "size": value.get("size")}


def _comment_attachment(record: Mapping) -> dict:
    attrs = record.get("attributes")
    if attrs is None:
        attrs = {}
    if not isinstance(attrs, Mapping):
        raise ValueError("attachment.attributes must be an object or null")  # noqa: TRY004
    formats = attrs.get("fileFormats")
    if formats is not None and not isinstance(formats, list):
        raise ValueError("attachment.fileFormats must be an array or null")
    for name in ("title", *ATTACHMENT_RESTRICTIONS, *COMMENT_ATTACHMENT_METADATA):
        if not is_attachment_attribute(name, attrs.get(name)):
            raise ValueError(f"attachment.{name} must be {attachment_attribute_type(name)} or null")
    identity = record.get("id")
    entry = {
        "title": attrs.get("title", ""),
        "formats": None if formats is None else [_comment_rendition(value) for value in formats],
    }
    entry.update({name: attrs[name] for name in ATTACHMENT_RESTRICTIONS if attrs.get(name) is not None})
    entry[ATTACHMENT_ID] = identity if isinstance(identity, str) and identity.strip() else None
    entry.update({name: attrs[name] for name in COMMENT_ATTACHMENT_METADATA if attrs.get(name) is not None})
    return entry


def comment_attachments(included: object) -> list[dict] | None:
    """Keep the ordered attachment list and distinguish an empty list from an unstated one."""
    if included is None:
        return None
    if not isinstance(included, list):
        raise ValueError("included must be an array or null")  # noqa: TRY004
    result = []
    for item in included:
        if not isinstance(item, Mapping):
            raise ValueError("included entries must be objects")  # noqa: TRY004
        if item.get("type") == "attachments":
            result.append(_comment_attachment(item))
    return result


def _extract_comment(d: dict) -> dict:
    data = d.get("data", {})
    attrs = data.get("attributes", {}) if isinstance(data, Mapping) else None
    if not isinstance(attrs, Mapping):
        raise ValueError("comment data.attributes must be an object")  # noqa: TRY004
    if (docket_id := attrs.get("docketId")) is not None and not isinstance(docket_id, str):
        raise ValueError("comment docketId must be text or null")
    attachments = comment_attachments(d.get("included"))

    return {
        "comment_id": data.get("id"),
        "docket_id": docket_id.strip('"') if docket_id else docket_id,
        "comment_on_document_id": attrs.get("commentOnDocumentId"),
        "comment_on_object_id": attrs.get("commentOn"),
        "original_document_id": attrs.get("originalDocumentId"),
        "comment_reference_values_json": json_dumps(
            {key: attrs[key] for key in ("commentOnDocumentId", "commentOn", "originalDocumentId") if key in attrs}
        ),
        "agency_code": attrs.get("agencyId"),
        "first_name": attrs.get("firstName"),
        "last_name": attrs.get("lastName"),
        "organization": attrs.get("organization"),
        "category": attrs.get("category"),
        "title": attrs.get("title"),
        "comment": attrs.get("comment"),
        "document_type": attrs.get("documentType"),
        "posted_date": attrs.get("postedDate"),
        "modify_date": attrs.get("modifyDate"),
        "receive_date": attrs.get("receiveDate"),
        "attachments_json": None if attachments is None else json_dumps(attachments),
        # Left None here; filled downstream. The run-pipeline ETL (which stays in
        # spicy-regs) fills it inline from Mirrulations' pre-extracted text
        # (transforms.EnrichCommentText), with the PDF text-extraction step
        # (spicy_regs.enrich_pdf) as the backfill for attachments not yet
        # extracted upstream.
        "text_content": None,
        "text_extraction_status": None,
        # Appended (docs/tables.md): as stated, so NULL means the record did not state it and 0 a stated zero.
        "subtype": attrs.get("subtype"),
        "duplicate_comments": _stated_count(attrs.get("duplicateComments")),
    }


def _extract_document(d: dict, *, attachment_records_json: str | None = None) -> dict:
    """``attachment_records_json`` is the caller's already-validated value, NULL when no relationship was read.

    Validation stays in ``sources``: ``sources.regulations_gov.attachment_records.attachment_records_json`` checks a
    read ``AttachmentRelationship`` against this document and returns the string passed here, so this layer imports
    nothing from ``sources``.
    """
    attrs = d.get("data", {}).get("attributes", {})

    # Each fileFormats entry is one downloadable rendition of the document
    # (e.g. content.pdf), carrying its own URL, format, and byte size. Keep the
    # full list — the single file_url below is retained for backward compat.
    attachments = [
        {"url": f["fileUrl"], "format": f.get("format"), "size": f.get("size")}
        for f in attrs.get("fileFormats") or []
        if f.get("fileUrl")
    ]

    return {
        "document_id": d.get("data", {}).get("id"),
        "docket_id": (v.strip('"') if (v := attrs.get("docketId")) else v),
        "agency_code": attrs.get("agencyId"),
        "title": attrs.get("title"),
        "document_type": attrs.get("documentType"),
        "posted_date": attrs.get("postedDate"),
        "modify_date": attrs.get("modifyDate"),
        "comment_start_date": attrs.get("commentStartDate"),
        "comment_end_date": attrs.get("commentEndDate"),
        "file_url": attachments[0]["url"] if attachments else None,
        "attachments_json": json_dumps(attachments) if attachments else None,
        "attachment_records_json": attachment_records_json,
        "fr_doc_num": attrs.get("frDocNum"),
        "withdrawn": attrs.get("withdrawn"),
        "reason_withdrawn": attrs.get("reasonWithdrawn"),
        "additional_rins": (json_dumps(rins) if (rins := attrs.get("additionalRins")) else None),
        # Populated out-of-band by the PDF text-extraction step
        # (spicy_regs.enrich_pdf, which stays in spicy-regs); the raw JSON has
        # no text layer.
        "text_content": None,
        "text_extraction_status": None,
    }


DOCKET = RecordType(
    name="dockets",
    path_pattern="/docket/",
    schema={
        "docket_id": str,
        "agency_code": str,
        "title": str,
        "docket_type": str,
        "modify_date": str,
        "abstract": str,
        "rin": str,
    },
    dedup_key="docket_id",
    extract=lambda d: {
        "docket_id": (v.strip('"') if (v := d.get("data", {}).get("id")) else v),
        "agency_code": d.get("data", {}).get("attributes", {}).get("agencyId"),
        "title": d.get("data", {}).get("attributes", {}).get("title"),
        "docket_type": d.get("data", {}).get("attributes", {}).get("docketType"),
        "modify_date": d.get("data", {}).get("attributes", {}).get("modifyDate"),
        "abstract": d.get("data", {}).get("attributes", {}).get("dkAbstract"),
        "rin": d.get("data", {}).get("attributes", {}).get("rin"),
    },
)


DOCUMENT = RecordType(
    name="documents",
    path_pattern="/documents/",
    schema={
        "document_id": str,
        "docket_id": str,
        "agency_code": str,
        "title": str,
        "document_type": str,
        "posted_date": str,
        "modify_date": str,
        "comment_start_date": str,
        "comment_end_date": str,
        "file_url": str,
        "attachments_json": str,
        "attachment_records_json": str,
        "fr_doc_num": str,
        "withdrawn": str,
        "reason_withdrawn": str,
        "additional_rins": str,
        # Text extracted from the document's PDF rendition, plus the outcome
        # of that extraction ("ok"/"empty"/"encrypted"/"error"/None if not yet run).
        "text_content": str,
        "text_extraction_status": str,
    },
    dedup_key="document_id",
    extract=_extract_document,
)


COMMENT = RecordType(
    name="comments",
    path_pattern="/comments/",
    schema={
        "comment_id": str,
        "docket_id": str,
        "comment_on_document_id": str,
        "comment_on_object_id": str,
        "original_document_id": str,
        "comment_reference_values_json": str,
        "agency_code": str,
        "first_name": str,
        "last_name": str,
        "organization": str,
        "category": str,
        "title": str,
        "comment": str,
        "document_type": str,
        "posted_date": str,
        "modify_date": str,
        "receive_date": str,
        "attachments_json": str,
        # Text extracted from the comment's PDF attachment(s), plus the outcome
        # ("ok"/"empty"/"encrypted"/"error"/None if not yet run).
        "text_content": str,
        "text_extraction_status": str,
        "subtype": str,
        "duplicate_comments": int,
    },
    dedup_key="comment_id",
    extract=_extract_comment,
)


# Registry keyed by record-type name. Order matters: it drives the default
# set of data types the pipeline processes.
RECORD_TYPES: dict[str, RecordType] = {
    "dockets": DOCKET,
    "documents": DOCUMENT,
    "comments": COMMENT,
}


# The published tables.  Each key is the publisher's own id, which DocSpec
# decision 0004 keeps as the identity even for a document filed under two
# agencies.  ``modify_date`` versions only the publisher's fields: the host's
# text columns change without it (``docs/tables.md``).
DOCKETS = table_contract(
    "dockets",
    grain="One row per Regulations.gov docket, the folder an agency opens for one rulemaking or other action.",
    identity=(DOCKET.dedup_key,),
    version_column="modify_date",
    key_spelling=VALUE_KEY,
    columns={
        "docket_id": "The publisher's docket id, such as `ACF-2007-0125`.",
        "agency_code": "The publisher's code for the agency that owns the docket (`agencyId`).",
        "title": "The docket's title as the publisher states it.",
        "docket_type": "The publisher's docket category: `Rulemaking` or `Nonrulemaking`.",
        "modify_date": "When the publisher last modified the docket, an ISO 8601 UTC instant that sorts as it reads.",
        "abstract": "The agency's summary of the docket (`dkAbstract`), often NULL.",
        "rin": "The Regulation Identifier Number the publisher ties the docket to, often NULL or `Not Assigned`.",
    },
)

DOCUMENTS = table_contract(
    "documents",
    references=(Reference(("docket_id",), "dockets", ("docket_id",)),),
    grain="One row per document an agency posted on Regulations.gov: a rule, notice or supporting material.",
    identity=(DOCUMENT.dedup_key,),
    version_column="modify_date",
    key_spelling=VALUE_KEY,
    columns={
        "document_id": "The publisher's document id, usually its docket id and a sequence (`FAA-2016-6907-0001`).",
        "docket_id": "The docket the publisher files the document under (`docketId`); NULL when it names none.",
        "agency_code": "The publisher's code for the posting agency (`agencyId`).",
        "title": "The document's title as the publisher states it.",
        "document_type": (
            "The publisher's category: `Rule`, `Proposed Rule`, `Notice`, `Supporting & Related Material`, `Other` "
            "or `Public Submission`."
        ),
        "posted_date": "When the document was posted, an ISO 8601 UTC instant kept as stated, year 0000 included.",
        "modify_date": "When the publisher last modified the document, an ISO 8601 UTC instant.",
        "comment_start_date": "When the comment period this document opens begins; NULL when it opens none.",
        "comment_end_date": (
            "When that period closes, almost always 23:59:59 Eastern spelled in UTC, so its UTC date is the day after "
            "the deadline."
        ),
        "file_url": "The first rendition the publisher lists, kept for older readers; `attachments_json` has them all.",
        "attachments_json": (
            "Every rendition the publisher lists, a JSON array of `url`, `format` and `size` objects in its order; "
            "NULL when it lists none."
        ),
        "attachment_records_json": "Literal records from an explicitly read document attachment relationship; NULL means unread, [] means read empty. Restrictions and alternative file formats remain native.",
        "fr_doc_num": "The Federal Register document number the publisher states (`frDocNum`), often NULL.",
        "withdrawn": "The publisher's withdrawal flag, `true` or `false`; NULL when the record states none.",
        "reason_withdrawn": "The publisher's reason for a withdrawal, spelled as stated; NULL when it states none.",
        "additional_rins": "Further Regulation Identifier Numbers the publisher lists, a JSON array; NULL when none.",
        "text_content": "Text the host extracted from the document's PDF renditions; NULL until one produced text.",
        "text_extraction_status": "The outcome of the host's PDF extraction, in its vocabulary; NULL before one.",
        "pdf_extraction_results_json": (
            "The host's latest PDF attempt, a JSON array with each selected URL's outcome and the SHA-256 of the "
            "bytes read; NULL when none is recorded."
        ),
    },
)

COMMENTS = table_contract(
    "comments",
    references=(Reference(("docket_id",), "dockets", ("docket_id",)),),
    grain="One row per public comment posted on Regulations.gov.",
    identity=(COMMENT.dedup_key,),
    version_column="modify_date",
    key_spelling=VALUE_KEY,
    types={"duplicate_comments": INTEGER},
    columns={
        "comment_id": "The publisher's comment id, usually its docket id and a sequence (`APHIS-2004-0018-0031`).",
        "docket_id": "The docket the publisher files the comment under (`docketId`); NULL when it names none.",
        "comment_on_document_id": (
            "The explicit parent document ID (`commentOnDocumentId`), independently nullable from the docket."
        ),
        "comment_on_object_id": "Literal `commentOn` object reference; not the public document ID namespace.",
        "original_document_id": "Literal `originalDocumentId`; unresolved legacy source reference, not a current key.",
        "comment_reference_values_json": (
            "Only present native reference fields as a JSON object, preserving null and empty values. "
            "An empty object means read with no fields; SQL NULL means not retained by an older projection."
        ),
        "agency_code": "The publisher's code for the agency that received the comment (`agencyId`).",
        "first_name": "The submitter's first name, when given.",
        "last_name": "The submitter's last name, when given.",
        "organization": "The organization the submitter names, when given.",
        "category": "The submitter category the publisher assigns, often NULL.",
        "title": "The comment's title as the publisher states it.",
        "comment": "The comment's body as the publisher states it, markup included.",
        "document_type": "The publisher's category, `Public Submission` for almost every comment.",
        "posted_date": "When the comment was posted, an ISO 8601 UTC instant.",
        "modify_date": "When the publisher last modified the comment, an ISO 8601 UTC instant.",
        "receive_date": "When the agency received the comment, an ISO 8601 UTC instant.",
        "attachments_json": (
            "Every attachment the record lists, in its order, as a JSON array of objects: `title`, `formats` (each "
            "rendition's `url`, `format` and `size`; `url` NULL where the record gives no fileUrl, `formats` NULL "
            "where it states no fileFormats) and, only where stated, `restrictReasonType` and `restrictReason`: a "
            "Copyrighted attachment offers no file but is listed. Then `attachment_id`: the attachment's own `id`, "
            "NULL where the record states none or one that is not a non-blank string. Then, only where stated with "
            "the type the publisher's schema gives it and under the publisher's keys, `agencyNote`, `authors` (a "
            "text array), `description`, `docAbstract`, `docOrder` (an integer), `modifyDate` and `publication`.  "
            "NULL where the record states no attachment set, `[]` where it states an empty one.  A row read before "
            "spicy-docs 0.85.0 lacks `attachment_id`, one read before this change lacks the seven attributes, and "
            "one read before 2026-10-03 lacks the attachments with no file (58 on 16 records of EPA-HQ-OW-2022-0114) "
            "and is NULL where only those were listed, until re-read."
        ),
        "text_content": (
            "Text of the attachments, from Mirrulations' own extraction where it has one, else the host's PDF step; "
            "NULL when neither produced text."
        ),
        "text_extraction_status": (
            "Where `text_content` came from: `derived` for Mirrulations' extraction, else the outcome of the host's "
            "PDF step in its vocabulary; NULL before either."
        ),
        "pdf_extraction_results_json": (
            "Provenance of `text_content` as JSON: for `derived` text the Mirrulations objects it was read from, else "
            "the host's latest PDF attempts; NULL when neither is recorded."
        ),
        "subtype": (
            "The agency's own class for the submission (`subtype`), spelled as stated. It is agency-specific: a "
            "submitter class such as a mass-mail campaign or an organization at EPA, a generic label at many agencies. "
            "NULL when the record states none or the host has not read it."
        ),
        "duplicate_comments": (
            "How many received submissions the agency says this posted record stands for (`duplicateComments`), as "
            "stated. Agencies that do not count state 0; EPA states 1 for a single comment and the campaign's size on "
            "a mass-mail record. NULL when the record states none or the host has not read it."
        ),
    },
)
