"""One text derivation per fetched rendition, so every caller reads one text.

Five renditions (``xml``, ``uslm``, ``htm``, ``txt``, ``pdf``): the markup and
text branches share ``normalize_gpo_glyphs``' glyph rules, while the PDF branch
is ``DocumentExtractor`` with ``NativeText`` plus ``normalize_gpo_pages``, which
is why this module lives in ``extraction`` and imports no ``sources`` module
(the fetched body is read structurally as a :class:`FetchedBody`). A BILLS
``xml`` body declares an external DOCTYPE, allowed explicitly here -- the reader
still loads no resource and refuses every entity declaration; ``htm`` whitespace
inside ``<pre>`` is the document's layout, so its text is taken verbatim and no
blank line is dropped, while only PDF text carries ``[[Page N]]`` markers, form
feeds and ``VerDate`` footers. Every branch is O(B) time and O(B + T) space,
one pass per rule; no network request and no file write.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, replace
from typing import Protocol

from spicy_docs.reading.markup import MAX_EVENTS, MarkupEvent, MarkupRead, read_html_events, read_xml_events

from .font_glyphs import FontGlyphCount, page_counts
from .gpo_normalize import GpoCleanupRecord, normalize_gpo_glyphs, normalize_gpo_pages
from .model import PageResult

#: The derivation each rendition gets. Keys are
#: ``sources.govinfo.bodies.PACKAGE_BODY_FORMATS``'s own names.
RENDITION_DERIVATIONS: dict[str, str] = {
    "xml": "markup-reader",
    "uslm": "markup-reader",
    "htm": "markup-reader",
    "txt": "text-rendition-cleanup",
    "pdf": "pdf-extraction-gpo-normalized",
}

#: The media types each rendition may arrive as, restated from
#: ``PACKAGE_BODY_FORMATS`` rather than imported (see the module docstring).
RENDITION_MEDIA_TYPES: dict[str, tuple[str, ...]] = {
    "htm": ("text/html",),
    "xml": ("application/xml", "text/xml"),
    "uslm": ("application/xml", "text/xml"),
    "txt": ("text/plain",),
    "pdf": ("application/pdf",),
}

#: HTML elements whose text is document metadata, not body text. Measured:
#: ``<title>`` is present in all four GovInfo ``htm`` bodies and restates the
#: report's own printed title (591, 703, 80 and 77 characters); keeping it
#: would put a second, differently-wrapped copy of the heading above the
#: document's first line.
METADATA_ELEMENTS = frozenset({"title"})

#: Every HTML element whose content the ``htm`` branch leaves out: the metadata
#: above, and four a browser does not show as text -- code, CSS, the
#: ``<noscript>`` fallback and ``<template>`` markup. Without them a committee
#: web page's text opened on its JSON-LD and CSS (ct-chc4); the GovInfo bodies
#: measured carry at most one empty ``<script>``. HTML names only: an XML
#: vocabulary may give ``<style>`` a meaning of its own. The measurements, and
#: the cases where this walk and a browser part ways, are in
#: ``docs/decisions.md``: "An HTML body's script, CSS, ``<noscript>`` and
#: ``<template>`` content is not body text".
HTM_DROPPED_ELEMENTS = METADATA_ELEMENTS | {"script", "style", "noscript", "template"}

#: HTML elements :func:`marked_events` breaks a line for: the long-standing
#: block-level list (``address`` to ``ul``) with ``<br>``, ``<tr>``, ``<td>``,
#: ``<th>`` and ``<option>``. Inline elements are absent on purpose. Why these,
#: and what they cost: ``docs/decisions.md``, "An HTML block element between
#: two texts breaks the line".
HTM_BLOCK_ELEMENTS = frozenset(
    {
        "address",
        "article",
        "aside",
        "blockquote",
        "br",
        "dd",
        "details",
        "dialog",
        "div",
        "dl",
        "dt",
        "fieldset",
        "figcaption",
        "figure",
        "footer",
        "form",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "header",
        "hgroup",
        "hr",
        "li",
        "main",
        "nav",
        "ol",
        "option",
        "p",
        "pre",
        "section",
        "table",
        "td",
        "th",
        "tr",
        "ul",
    }
)
_VERBATIM_ELEMENTS = frozenset({"pre"})
#: A character of visible text: not whitespace, and not the end-of-text marker ``_cleanup`` deletes.
_VISIBLE = re.compile(r"[^\s\x1a]")

_PDF_MEDIA_TYPE = "application/pdf"


class BodyTextError(ValueError):
    """A rendition cannot be turned into text under its own derivation."""


@dataclass(frozen=True, slots=True)
class RenditionCleanupRule:
    """One named rule, the artifact it removes and the renditions it runs on."""

    name: str
    artifact: str
    renditions: tuple[str, ...]


#: Every rule the non-PDF branches apply, each measured above zero on a real
#: publisher response (module docstring). The PDF branch's own rules are
#: ``gpo_normalize.METADATA_RULES``; nothing is duplicated between the two.
RENDITION_CLEANUP_RULES: tuple[RenditionCleanupRule, ...] = (
    RenditionCleanupRule(
        "metadata_element",
        "HTML <title> (document metadata restating the printed heading) and <script>, <style>, "
        "<noscript> and <template> (code, CSS and markup a browser does not show as text)",
        ("htm",),
    ),
    RenditionCleanupRule(
        "element_line_break",
        "An element boundary, kept as a line break so text from two elements never runs together: "
        "every XML element; in htm, a block-level element or <br> outside <pre> with visible text on both sides",
        ("xml", "uslm", "htm"),
    ),
    RenditionCleanupRule(
        "whitespace_only_line",
        "XML pretty-print indentation between elements, which is formatting and not content; "
        "never applied to htm, whose blank lines are the document's own layout",
        ("xml", "uslm"),
    ),
    RenditionCleanupRule(
        "line_ending",
        "CRLF/CR line endings (27,717 in CDIR-2026-02-20.txt)",
        ("xml", "htm", "txt"),
    ),
    RenditionCleanupRule(
        "end_of_text_marker",
        "GPO's trailing U+001A SUB terminator (1 each in the CRPT-113hrpt135 and -113srpt77 htm bodies)",
        ("xml", "htm", "txt"),
    ),
    RenditionCleanupRule(
        "gpo_quote_pair",
        "GPO's ``/'' typewriter quote pairs, collapsed to one double quote so the htm and PDF "
        "renditions of one document spell a quotation the same way",
        ("xml", "htm", "txt"),
    ),
    RenditionCleanupRule(
        "trailing_space",
        "Trailing spaces left by GPO's fixed-width columns (19,077 lines in CDIR-2026-02-20.txt); "
        "leading spaces are the layout and are kept",
        ("xml", "htm", "txt"),
    ),
)


@dataclass(frozen=True, slots=True)
class RenditionCleanup:
    """What the markup and text branches read and removed, rule by rule.

    Markup counts are zero for a ``txt`` body; ``whitespace_only_lines`` is
    zero outside the XML branch, and ``metadata_element_chars`` outside the HTML
    branch, where it counts what ``HTM_DROPPED_ELEMENTS`` left out.
    ``element_line_breaks`` counts the line breaks either markup branch added.
    ``quote_pairs_collapsed`` counts only GPO's backtick/apostrophe typewriter
    pairs; a PDF's curly-doubled spelling is collapsed by the same shared rule
    but counted by the PDF branch's ``GpoCleanupRecord`` instead.
    """

    markup_events: int
    markup_elements: int
    text_events: int
    metadata_element_chars: int
    element_line_breaks: int
    whitespace_only_lines: int
    line_endings_normalized: int
    end_of_text_markers: int
    quote_pairs_collapsed: int
    trailing_space_lines: int


@dataclass(frozen=True, slots=True)
class BodyText:
    """One rendition's parser-ready text and the account of how it was made.

    ``pages`` is the per-page text for a PDF, in reading order, and ``None``
    for every other rendition: a GovInfo ``htm``, ``xml`` or ``txt`` body
    states no page boundary (measured: no form feed and no ``[[Page N]]``
    marker in any of the eight bodies sampled), so page attribution would be
    invented. ``record`` is a :class:`RenditionCleanup` for the markup and
    text branches and a ``GpoCleanupRecord`` for the PDF branch.
    """

    text: str
    pages: tuple[str, ...] | None
    rendition: str
    media_type: str
    byte_size: int
    derivation: str
    record: GpoCleanupRecord | RenditionCleanup


class _BodyIdentity(Protocol):
    media_type: str
    byte_size: int


class _BodyCapture(Protocol):
    body: bytes


class FetchedBody(Protocol):
    """The three facts ``body_text`` needs from a fetched body.

    ``sources.govinfo.body_acquisition.GovInfoPackageBody`` satisfies this, and
    so would a bill-text body that states the same three things, which is why
    it is structural rather than an import: ``extraction`` stays below
    ``sources``.
    """

    format: str
    body: _BodyIdentity
    body_capture: _BodyCapture


class _Extractor(Protocol):
    def extract(self, source: bytes, *, media_type: str) -> Iterator[PageResult]: ...


def _checked_rendition(rendition: object) -> str:
    """The rendition name, or a refusal naming the ones supported."""
    if not isinstance(rendition, str) or rendition not in RENDITION_DERIVATIONS:
        supported = ", ".join(RENDITION_DERIVATIONS)
        raise BodyTextError(f"rendition must be one of {supported}")
    return rendition


def _checked_media_type(rendition: str, media_type: str | None) -> str:
    """Return the normalized media type, or refuse a body whose type contradicts its rendition.

    A missing type defaults to the rendition's first accepted type; a mismatch is
    the publisher answering with something else, which the acquirer already refuses
    and this refuses again for a caller holding bytes from elsewhere.
    """
    allowed = RENDITION_MEDIA_TYPES[rendition]
    if media_type is None:
        return allowed[0]
    exact = media_type.partition(";")[0].strip().casefold()
    if exact not in allowed:
        raise BodyTextError(f"{rendition} body media type is {exact or 'absent'}, not one of {', '.join(allowed)}")
    return exact


def _cleanup(raw: str) -> tuple[str, dict[str, int]]:
    """The rules every non-PDF rendition shares, with what each one found.

    Each rule is counted against the text as that rule sees it, so two rules never
    claim the same character: trailing spaces are counted after line-ending
    normalization, or every CRLF line would also read as one.
    """
    text = normalize_gpo_glyphs(raw)
    counts = {
        "line_endings_normalized": raw.count("\r"),
        "end_of_text_markers": text.count("\x1a"),
        # One pair is one collapsed quotation mark, whichever way GPO spelled
        # it; normalize_gpo_glyphs has already collapsed them, so they are
        # counted on the way in.
        "quote_pairs_collapsed": raw.count("``") + raw.count("''"),
        "trailing_space_lines": sum(1 for line in text.split("\n") if line.strip() and line != line.rstrip()),
    }
    text = text.replace("\x1a", "")
    return "\n".join(line.rstrip() for line in text.split("\n")), counts


def _open_depth(depth: int, event: MarkupEvent, names: frozenset[str]) -> int:
    """How many ``names`` elements are open once ``event`` is read."""
    if event.name in names:
        if event.kind == "start":
            return depth + 1
        if event.kind == "end":
            return max(depth - 1, 0)
    return depth


def marked_events(
    events: Iterable[MarkupEvent], *, dropped: frozenset[str] = frozenset(), blocks: frozenset[str] = frozenset()
) -> Iterator[tuple[MarkupEvent, bool, bool]]:
    """Each event with two marks for a text event: its text is left out, and a line break belongs before it.

    Left out: the text is inside a ``dropped`` element. Only a container
    swallows text: the reader reports a self-closing ``<title/>`` or
    ``<script/>`` as ``empty``, with no end tag, so counting it open would
    swallow the whole body. One never closed does swallow the rest, and
    ``metadata_element_chars`` says how much.

    Line break: a ``blocks`` element started or ended since visible text was
    put on the current line, and this text would continue that line. The break
    is all this adds. It does not collapse or move source whitespace, and where
    that already breaks the line it adds nothing, so it makes no blank line
    and no leading or trailing newline. (``_cleanup`` then strips the spaces a
    break leaves at a line's end, as it does any other.) Inside ``<pre>``
    nothing is a boundary: its text is the layout. Neither is anything inside a
    ``dropped`` element.

    Shared with ``reconstruction.evidence`` so its blocks are this text's
    lines; not exported, and not a contract for a host.
    """
    depth = verbatim = 0
    line_has_text = pending = False
    for event in events:
        if event.kind != "text" or event.text is None:
            was_verbatim = verbatim
            depth = _open_depth(depth, event, dropped)
            verbatim = _open_depth(verbatim, event, _VERBATIM_ELEMENTS)
            if line_has_text and not depth and event.name in blocks and not (was_verbatim and verbatim):
                pending = True
            yield event, False, False
            continue
        if depth or not blocks:
            yield event, bool(depth), False
            continue
        text = event.text
        first = _VISIBLE.search(text)
        lead = len(text) if first is None else first.start()
        source_break = "\n" in text[:lead] or "\r" in text[:lead]
        line_break = pending and lead < len(text) and not source_break
        if source_break or line_break:
            pending = False
        last = max(text.rfind("\n"), text.rfind("\r"))
        visible = _VISIBLE.search(text, last + 1) is not None
        line_has_text = visible if last >= 0 or line_break else line_has_text or visible
        yield event, False, line_break


# Native legislative XML uses these containers for non-body bibliographic facts.
XML_DROPPED_ELEMENTS = frozenset({"metadata", "dublinCore", "meta"})
XML_BLOCK_ELEMENTS = HTM_BLOCK_ELEMENTS | frozenset(
    {
        "title",
        "subtitle",
        "chapter",
        "subchapter",
        "part",
        "subpart",
        "subsection",
        "paragraph",
        "subparagraph",
        "clause",
        "subclause",
        "heading",
        "header",
        "num",
        "enum",
        "text",
        "congress",
        "session",
        "legis-num",
        "docNumber",
        "preface",
        "action",
        "enrolledDateline",
        "longTitle",
        "docTitle",
        "resolvingClause",
        "signature",
        "notation",
        "role",
        "quoted-block",
        "legis-body",
        "form",
        "doc",
    }
)
_NAVIGATION_ELEMENTS = frozenset({"nav", "menu"})
_HTML_SPACE = re.compile(r"[ \t\r\n\f]+")


def _markup_text(read: MarkupRead, *, xml: bool) -> tuple[str, dict[str, int]]:
    """Read body prose with structural breaks, preserving HTML preformatted layout."""
    if not xml and any(event.name == "pre" for event in read.events):
        return _verbatim_markup_text(read, xml=False)
    parts: list[str] = []
    text_events = metadata_chars = breaks = 0
    depth = verbatim = navigation = 0
    boundary = False
    adjacent_control = False
    dropped = XML_DROPPED_ELEMENTS if xml else HTM_DROPPED_ELEMENTS
    blocks = XML_BLOCK_ELEMENTS if xml else HTM_BLOCK_ELEMENTS
    for event in read.events:
        if event.kind != "text" or event.text is None:
            was_verbatim = verbatim
            depth = _open_depth(depth, event, dropped)
            if not xml:
                verbatim = _open_depth(verbatim, event, _VERBATIM_ELEMENTS)
                navigation = _open_depth(navigation, event, _NAVIGATION_ELEMENTS)
            if not depth and not (was_verbatim and verbatim):
                if event.name in blocks:
                    boundary = True
                # Anchors in prose can mark only part of a word. Their tags
                # do not supply whitespace. Navigation labels and actual
                # buttons are controls, so their boundaries may separate words.
                if not xml and (event.name == "button" or (navigation and event.name == "a")):
                    adjacent_control = True
            continue
        if depth:
            metadata_chars += len(event.text)
            continue
        text_events += 1
        value = event.text if verbatim else _HTML_SPACE.sub(" ", event.text)
        if not verbatim and not value.strip():
            if parts and not parts[-1].endswith((" ", "\n")):
                parts.append(" ")
            continue
        if boundary and parts and not parts[-1].endswith("\n"):
            # Source whitespace outside pre is a separator, not document layout.
            parts.append("\n")
            breaks += 1
        elif adjacent_control and parts and value and value[0].isalnum() and parts[-1][-1:].isalnum():
            parts.append(" ")
        if not verbatim and (not parts or parts[-1].endswith("\n")):
            value = value.lstrip(" ")
        parts.append(value)
        boundary = adjacent_control = False
    text, counts = _cleanup("".join(parts))
    # Do not strip an HTML pre's original leading/trailing layout.
    if not any(event.name == "pre" for event in read.events) or xml:
        text = text.strip()
    counts |= {
        "markup_events": len(read.events),
        "markup_elements": read.element_count,
        "text_events": text_events,
        "metadata_element_chars": metadata_chars,
        "element_line_breaks": breaks,
        "whitespace_only_lines": 0,
    }
    return text, counts


def _verbatim_markup_text(read: MarkupRead, *, xml: bool) -> tuple[str, dict[str, int]]:
    """Walk one markup read's text in document order.

    For XML an element boundary closes the current line, so text from two elements
    never runs together and pretty-print whitespace-only lines are dropped; for
    HTML the text is taken verbatim, because a GovInfo body is a ``<pre>`` block
    whose whitespace is the layout, and a line is broken only where
    :func:`marked_events` says a block-level element would glue two texts.
    """
    parts: list[str] = []
    text_events = metadata_chars = breaks = 0
    marks = {} if xml else {"dropped": HTM_DROPPED_ELEMENTS, "blocks": HTM_BLOCK_ELEMENTS}
    for event, left_out, line_break in marked_events(read.events, **marks):
        if event.kind == "text" and event.text is not None:
            if left_out:
                metadata_chars += len(event.text)
                continue
            if line_break:
                parts.append("\n")
                breaks += 1
            text_events += 1
            parts.append(event.text)
        elif xml and event.kind in {"start", "empty", "end"} and parts and not parts[-1].endswith("\n"):
            parts.append("\n")
            breaks += 1
    text, counts = _cleanup("".join(parts))
    blank = 0
    if xml:
        lines = text.split("\n")
        kept = [line for line in lines if line]
        blank = len(lines) - len(kept)
        text = "\n".join(kept)
    counts |= {
        "markup_events": len(read.events),
        "markup_elements": read.element_count,
        "text_events": text_events,
        "metadata_element_chars": metadata_chars,
        "element_line_breaks": breaks,
        "whitespace_only_lines": blank,
    }
    return text, counts


def _pdf_text(data: bytes, extractor: _Extractor | None) -> tuple[str, tuple[str, ...], GpoCleanupRecord]:
    """Extract, then normalize; refuses a PDF that yields no page, and joins pages with one ``\\n``."""
    if extractor is None:
        from .api import DocumentExtractor, NativeText

        extractor = DocumentExtractor(NativeText())
    raw: list[str] = []
    glyphs: list[FontGlyphCount] = []
    for number, result in enumerate(extractor.extract(data, media_type=_PDF_MEDIA_TYPE), start=1):
        raw.append(result.text)
        # Recounted from the retained PyMuPDF spans rather than parsed from issue prose; per page,
        # so no page's raw output outlives its turn.
        for observation in result.content.observations:
            if observation.id == "native" and observation.configuration.get("backend") == "pymupdf":
                glyphs.extend(page_counts(number, observation.raw))
    if not raw:
        raise BodyTextError("pdf body yielded no page")
    pages, record = normalize_gpo_pages(raw)
    record = replace(record, font_glyphs=tuple(glyphs))
    # One "\n" per page boundary, the same join report_blocks._flatten uses,
    # so a caller that passes `text` and one that passes `pages` agree.
    return "\n".join(pages), pages, record


def rendition_text(
    data: bytes,
    *,
    rendition: str,
    media_type: str | None = None,
    byte_size: int | None = None,
    extractor: _Extractor | None = None,
) -> BodyText:
    """Derive parser-ready text from one rendition's exact bytes.

    ``rendition`` is one of ``xml``, ``uslm``, ``htm``, ``txt`` or ``pdf``; the
    derivation it gets is ``RENDITION_DERIVATIONS[rendition]`` and is never
    inferred from the bytes. ``media_type`` is checked against the rendition
    when given. ``byte_size`` defaults to ``len(data)`` and exists so a caller
    holding the publisher's own stated size can record that instead.

    ``extractor`` replaces the PDF branch's default
    ``DocumentExtractor(NativeText())`` -- for a test, or for a document whose
    pages need another strategy. It is imported only when a PDF arrives, so
    reading a text rendition loads no PDF library.
    """
    if not isinstance(data, bytes) or not data:
        raise BodyTextError("body must be nonempty bytes")
    name = _checked_rendition(rendition)
    exact_media_type = _checked_media_type(name, media_type)
    size = len(data) if byte_size is None else byte_size
    if name == "pdf":
        text, pages, gpo_record = _pdf_text(data, extractor)
        return BodyText(
            text=text,
            pages=pages,
            rendition=name,
            media_type=exact_media_type,
            byte_size=size,
            derivation=RENDITION_DERIVATIONS[name],
            record=gpo_record,
        )
    if name == "txt":
        try:
            raw = data.decode("utf-8")
        except UnicodeDecodeError as error:
            raise BodyTextError("txt body must be UTF-8") from error
        text, counts = _cleanup(raw)
        counts |= {
            "markup_events": 0,
            "markup_elements": 0,
            "text_events": 0,
            "metadata_element_chars": 0,
            "element_line_breaks": 0,
            "whitespace_only_lines": 0,
        }
    else:
        # uslm takes the same branch as xml: both are well-formed XML read by
        # the same generic markup reader, whatever vocabulary each declares
        # (module docstring).
        xml = name in {"xml", "uslm"}
        # A BILLS XML body declares an external DOCTYPE; allowing it is a
        # statement that the declaration is inert, not a fetch: the reader
        # never loads the resource and still refuses every entity.
        # HTML depth is bounded by the event bound alone: this walk builds no
        # tree, and an unclosed tag is not nesting. GPO prints literal
        # ``<bullet>`` tags it never closes inside a body's ``<pre>`` -- 297 in
        # CRPT-112hrpt747, 308 in CRPT-118hrpt963 -- which the generic depth
        # of 256 refused. XML keeps its depth: its tags are balanced.
        read = (
            read_xml_events(data, allow_external_doctype=True) if xml else read_html_events(data, max_depth=MAX_EVENTS)
        )
        text, counts = _markup_text(read, xml=xml)
    return BodyText(
        text=text,
        pages=None,
        rendition=name,
        media_type=exact_media_type,
        byte_size=size,
        derivation=RENDITION_DERIVATIONS[name],
        record=RenditionCleanup(**counts),
    )


def body_text(body: FetchedBody, *, extractor: _Extractor | None = None) -> BodyText:
    """Derive text from a fetched body, reading its rendition off the body itself.

    Takes anything that states the three facts :class:`FetchedBody` names --
    ``GovInfoPackageBody`` does -- so the chosen format, its media type and
    its exact bytes come from the fetch that proved them rather than from a
    caller's guess. All the work is :func:`rendition_text`'s.
    """
    for attribute in ("format", "body", "body_capture"):
        if not hasattr(body, attribute):
            raise BodyTextError(f"body must state {attribute}; see FetchedBody")
    return rendition_text(
        body.body_capture.body,
        rendition=body.format,
        media_type=body.body.media_type,
        byte_size=body.body.byte_size,
        extractor=extractor,
    )


__all__ = [
    "HTM_BLOCK_ELEMENTS",
    "HTM_DROPPED_ELEMENTS",
    "METADATA_ELEMENTS",
    "RENDITION_CLEANUP_RULES",
    "RENDITION_DERIVATIONS",
    "RENDITION_MEDIA_TYPES",
    "BodyText",
    "BodyTextError",
    "FetchedBody",
    "RenditionCleanup",
    "RenditionCleanupRule",
    "body_text",
    "rendition_text",
]
