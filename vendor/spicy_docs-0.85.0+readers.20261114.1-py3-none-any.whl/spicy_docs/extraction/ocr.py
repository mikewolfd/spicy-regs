"""Optional local recognition providers; engines load once on first use."""

from __future__ import annotations

import ctypes
import ctypes.util
import functools
import hashlib
import io
import math
import os
import platform
import plistlib
import threading
import weakref
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, cast

# The Docling adapter is separate so importing OCR providers does not load Docling.
from .docling import Docling, DoclingSettings, DoclingVlmSettings  # noqa: F401
from .model import RAW_RGB, Box, ExtractionError, Raster, Recognition, TextBlock


def _version(package):
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def _box(x0, y0, x1, y1):
    # Providers can put edges just outside an image. Preserve original coordinates in raw.
    return Box(max(0, x0), max(0, y0), min(1, x1), min(1, y1))


class RapidOCR:
    def __init__(self, *, engine=None, **options: Any):
        self.engine = engine
        self._injected = engine is not None
        if self._injected and options:
            raise ValueError("configure an injected RapidOCR engine before passing it")
        self.options: dict[str, Any] = {"intra_op_num_threads": 4, "inter_op_num_threads": 1, **options}

    def recognize(self, image: Raster) -> Recognition:
        if self.engine is None:
            from rapidocr_onnxruntime import RapidOCR as Engine

            self.engine = Engine(**self.options)
        result, elapsed = self.engine(image.data)
        detections, blocks = [], []
        for points, text, confidence in result or []:
            points = [[float(x), float(y)] for x, y in points]
            xs, ys = zip(*points, strict=True)
            box = _box(min(xs) / image.width, min(ys) / image.height, max(xs) / image.width, max(ys) / image.height)
            blocks.append(TextBlock(text, box, float(confidence)))
            detections.append({"points": points, "text": text, "confidence": float(confidence)})
        return Recognition(
            "\n".join(b.text for b in blocks),
            {
                "backend": "rapidocr",
                "version": _version("rapidocr-onnxruntime"),
                "engine_injected": self._injected,
                "options": None if self._injected else self.options,
            },
            {"detections": detections, "engine_elapsed": elapsed, "coordinates": "image pixels; top-left origin"},
            tuple(blocks),
        )


@functools.cache
def _vision_host() -> dict[str, str | None]:
    """The PyObjC binding and the running macOS version and build (``ProductBuildVersion``), read once a process."""
    try:
        with open("/System/Library/CoreServices/SystemVersion.plist", "rb") as plist:
            build = plistlib.load(plist).get("ProductBuildVersion")
    except (OSError, plistlib.InvalidFileException):
        build = None
    return {"version": _version("pyobjc-framework-Vision"), "macos": platform.mac_ver()[0], "macos_build": build}


class _Vision:
    """One ``VNRecognizeTextRequest``, configured once and performed per raster.

    An encoded raster goes to Vision as bytes (Vision decodes it); ``RAW_RGB`` samples go as a ``CGImage``, so no
    image is encoded or decoded. Detections keep ocrmac's shape, so output matches the ocrmac path it replaced.
    """

    def __init__(self, level: str, languages: tuple[str, ...], language_correction: bool):
        if platform.system() != "Darwin":
            raise ExtractionError("Apple Vision requires macOS")
        import Foundation
        import Quartz
        import Vision

        self.foundation, self.quartz, self.vision = Foundation, Quartz, Vision
        self.request = request = Vision.VNRecognizeTextRequest.alloc().init()
        request.setRecognitionLevel_(1 if level == "fast" else 0)
        supported = request.supportedRecognitionLanguagesAndReturnError_(None)[0]
        if not set(languages) <= set(supported):
            raise ValueError(f"languages must be among Vision's {sorted(supported)}")
        request.setRecognitionLanguages_(list(languages))
        request.setUsesLanguageCorrection_(language_correction)
        self.revision = int(request.revision())

    def __call__(self, image: Raster) -> list[tuple[str, float, list[float]]]:
        import objc

        with objc.autorelease_pool():
            handler = self.vision.VNImageRequestHandler.alloc()
            if image.media_type == RAW_RGB:
                handler = handler.initWithCGImage_options_(self._cgimage(image), None)
            else:
                handler = handler.initWithData_options_(image.data, None)
            done = handler.performRequests_error_([self.request], None)
            ok, error = done if isinstance(done, tuple) else (bool(done), None)
            if not ok or error is not None:
                raise ExtractionError("Apple Vision recognition failed", details={"error": str(error)})
            detections = []
            for result in self.request.results() or ():
                box = result.boundingBox()
                detections.append(
                    (
                        str(result.text()),
                        float(result.confidence()),
                        [box.origin.x, box.origin.y, box.size.width, box.size.height],
                    )
                )
            return detections

    def _cgimage(self, image: Raster):
        # CGDataProviderCreateWithData(None, data, ...) leaks the whole buffer under PyObjC, with or without a release
        # callback: 10.2 MB a 200-DPI page (congressional-tech pdf-text-census-20261108, leak/). An NSData copy is
        # Objective-C's to free with the autorelease pool: 0.2 MB a page, the same text and speed.
        q = self.quartz
        provider = q.CGDataProviderCreateWithCFData(
            self.foundation.NSData.dataWithBytes_length_(image.data, len(image.data))
        )
        return q.CGImageCreate(
            image.width,
            image.height,
            8,
            24,
            image.width * 3,
            q.CGColorSpaceCreateDeviceRGB(),
            q.kCGBitmapByteOrderDefault | q.kCGImageAlphaNone,
            provider,
            None,
            False,
            q.kCGRenderingIntentDefault,
        )


#: Each band reaches this share of the page height past its boundaries, as the census's band probe did.
_BAND_OVERLAP = 0.02
#: A detection this close (share of page height) to a band's inner edge may be a line the edge cut.
_BAND_EDGE = 0.005


def _rgb_samples(image: Raster) -> bytes:
    """The raster's unencoded RGB samples, decoding an encoded image once.

    An encoded image must have the pixel size the raster claims: its readers (a band's strip, libtesseract) take the
    claimed size, so a larger claim reads past the samples and a smaller one misreads them, both without an error.
    ``Raster`` checks ``RAW_RGB`` samples' length itself.
    """
    if image.media_type == RAW_RGB:
        return image.data
    from PIL import Image

    with Image.open(io.BytesIO(image.data)) as source:
        if source.size != (image.width, image.height):
            raise ValueError(
                f"raster claims {image.width}x{image.height} pixels, its image is {'x'.join(map(str, source.size))}"
            )
        return source.convert("RGB").tobytes()


def _same_line(a, b) -> bool:
    """Two detections' boxes overlap by more than half the smaller box in each direction."""
    (ax, ay, aw, ah), (bx, by, bw, bh) = a[2], b[2]
    across = min(ax + aw, bx + bw) - max(ax, bx)
    down = min(ay + ah, by + bh) - max(ay, by)
    return across > min(aw, bw) / 2 and down > min(ah, bh) / 2


def _banded(engine, image: Raster, bands: int):
    """Recognize ``bands`` horizontal strips of ``image``, keeping one copy of each line in strip order.

    Each strip reaches ``_BAND_OVERLAP`` of the height past its core rows, so a line on a boundary is whole in both
    strips. A strip's detections whose centre lies in its core are taken first, then the rest; a detection is
    dropped if a strip beside it already kept the same line (boxes overlapping by more than half), or if it lies
    outside its core and touches the strip's inner edge, where a cut line would. Returns the kept detections and
    the dropped ones in whole-image coordinates, and each strip's pixel rows. Each detection is compared with the
    lines kept so far: quadratic in a page's lines, a few thousand box tests beside seconds of recognition.
    """
    height, row, reach = image.height, image.width * 3, math.ceil(image.height * _BAND_OVERLAP)
    samples, strips, own, other = _rgb_samples(image), [], [], []
    for i in range(bands):
        start, end = height * i / bands, height * (i + 1) / bands
        top, bottom = max(0, math.floor(start) - reach), min(height, math.ceil(end) + reach)
        strip = Raster(samples[top * row : bottom * row], image.width, bottom - top, media_type=RAW_RGB)
        found = []
        for text, confidence, (x, y, w, h) in engine(strip):
            upper, lower = top + (1 - y - h) * (bottom - top), top + (1 - y) * (bottom - top)
            middle, j = (upper + lower) / 2, len(found)
            found.append((text, confidence, [x, 1 - lower / height, w, (lower - upper) / height]))
            cut = (top > 0 and upper - top < height * _BAND_EDGE) or (
                bottom < height and bottom - lower < height * _BAND_EDGE
            )
            if start <= middle < end or (i == bands - 1 and middle == end):
                own.append((i, j))
            elif not cut:
                other.append((i, j))
        strips.append(([top, bottom], found))
    kept: set[tuple[int, int]] = set()
    for i, j in own + other:
        line = strips[i][1][j]
        if not any(abs(k - i) == 1 and _same_line(line, strips[k][1][m]) for k, m in kept):
            kept.add((i, j))
    ordered = [(i, j) for i, (_, found) in enumerate(strips) for j in range(len(found))]
    return (
        [strips[i][1][j] for i, j in ordered if (i, j) in kept],
        [strips[i][1][j] for i, j in ordered if (i, j) not in kept],
        [rows for rows, _ in strips],
    )


class AppleVision:
    """Apple Vision text recognition through PyObjC, one request per instance reused for every page.

    Takes an encoded raster or, from ``DefaultReader(raw_rgb=True)``, raw RGB samples without any PNG step.
    ``language_correction`` sets Vision's ``usesLanguageCorrection``; the default, on, reproduces the earlier
    ocrmac output byte for byte. Off, a 200-DPI page took 0.19 s instead of 0.36 s at the same agreement with
    the native text layer (congressional-tech investigation ``pdf-text-vision-path-20261108``). An injected
    ``engine`` is called with each raster and returns ``(text, confidence, [x, y, width, height])`` detections
    in Vision's normalized bottom-left coordinates. The request is not shared across threads: one instance
    per serial worker.

    ``bands > 1`` recognizes that many horizontal strips, each 2% of the page taller at a shared boundary, and
    keeps one copy of a line both read (:func:`_banded`); the engine then sees raw RGB strips. Whole-page accurate
    Vision drops lines of tightly set type: on two born-digital GPO hearing pages it read 32% of the native layer,
    three bands 86-101%, and on 1,000 OCR-flagged pages three bands read at least 25% more on 18.8%
    (congressional-tech ``pdf-text-census-20261108``).
    """

    def __init__(
        self,
        *,
        recognition_level="accurate",
        languages=("en-US",),
        language_correction=True,
        bands=1,
        engine=None,
    ):
        if recognition_level not in {"accurate", "fast"}:
            raise ValueError("recognition_level must be accurate or fast")
        if type(bands) is not int or bands < 1:
            raise ValueError("bands must be a positive integer")
        self.level, self.languages, self.language_correction = recognition_level, tuple(languages), language_correction
        self.bands, self.engine, self._injected = bands, engine, engine is not None

    def configuration(self) -> dict[str, Any]:
        """Effective settings and the macOS build, which names Vision's models; the request revision once built."""
        return {
            "backend": "apple-vision",
            **_vision_host(),
            "recognition_level": self.level,
            "languages": list(self.languages),
            "language_correction": self.language_correction,
            "bands": self.bands,
            "engine_injected": self._injected,
            "request_revision": getattr(self.engine, "revision", None) if not self._injected else None,
        }

    def require_reproducible_identity(self) -> dict[str, Any]:
        """The configuration a host keys a re-read on; refuses an injected engine, whose model is unknown."""
        if self._injected:
            raise ValueError("an injected Apple Vision engine has no reproducible identity")
        self._engine()
        return self.configuration()

    def _engine(self):
        if self.engine is None:
            self.engine = _Vision(self.level, self.languages, self.language_correction)
        return self.engine

    def recognize(self, image: Raster) -> Recognition:
        raw: dict[str, Any] = {"coordinates": "normalized x/y/width/height; bottom-left origin"}
        if self.bands == 1:
            detections = self._engine()(image)
        else:
            detections, raw["overlap_duplicates"], raw["band_rows"] = _banded(self._engine(), image, self.bands)
        blocks = tuple(
            TextBlock(text, _box(x, 1 - y - h, x + w, 1 - y), float(conf)) for text, conf, (x, y, w, h) in detections
        )
        return Recognition(
            "\n".join(b.text for b in blocks), self.configuration(), {"detections": detections, **raw}, blocks
        )


#: Pinned models, ``(language, variant)`` to the SHA-256 and size of upstream's ``<language>.traineddata``. ``fast`` is
#: tessdata_fast 4.1.0, which Homebrew's tesseract formula installs and pins by this digest. ``best`` is tessdata_best's
#: file as copies on the measuring Mac hash it (congressional-tech ``pdf-text-configs-20261108`` measured the same
#: file); no package pins it, so check it against github.com/tesseract-ocr/tessdata_best when a download is allowed.
_TESSDATA = {
    ("eng", "best"): ("8280aed0782fe27257a68ea10fe7ef324ca0f8d85bd2fd145d1c2b560bcb66ba", 15_400_601),
    ("eng", "fast"): ("7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2", 4_113_088),
}
#: Page segmentation modes that return text from one loaded model: 0, 1 and 12 also need ``osd``; 2 only segments.
_TESSERACT_PSM = frozenset({3, 4, 5, 6, 7, 8, 9, 10, 11, 13})
_TEXTLINE, _LSTM_ONLY = 2, 1  # RIL_TEXTLINE; OEM_LSTM_ONLY, as both variants hold only LSTM networks
_P, _I = ctypes.c_void_p, ctypes.c_int
#: The C API calls used, as ``capi.h`` declares them: (argument types, return type).
_TESS_API = {
    "TessVersion": ([], ctypes.c_char_p),
    "TessBaseAPICreate": ([], _P),
    "TessBaseAPIDelete": ([_P], None),
    "TessBaseAPISetVariable": ([_P, ctypes.c_char_p, ctypes.c_char_p], _I),
    "TessBaseAPIInit5": ([_P, ctypes.c_char_p, _I, ctypes.c_char_p, _I, _P, _I, _P, _P, ctypes.c_size_t, _I], _I),
    "TessBaseAPISetPageSegMode": ([_P, _I], None),
    "TessBaseAPISetImage": ([_P, ctypes.c_char_p, _I, _I, _I, _I], None),
    "TessBaseAPIRecognize": ([_P, _P], _I),
    "TessBaseAPIClear": ([_P], None),
    "TessBaseAPIGetIterator": ([_P], _P),
    "TessResultIteratorGetPageIterator": ([_P], _P),
    "TessPageIteratorBoundingBox": ([_P, _I, *[ctypes.POINTER(_I)] * 4], _I),
    "TessResultIteratorGetUTF8Text": ([_P, _I], _P),
    "TessResultIteratorConfidence": ([_P, _I], ctypes.c_float),
    "TessResultIteratorNext": ([_P, _I], _I),
    "TessResultIteratorDelete": ([_P], None),
    "TessDeleteText": ([_P], None),
}


_TESS_LOCK = threading.Lock()


@functools.cache
def _load_libtesseract() -> tuple[ctypes.CDLL, dict[str, str | None]] | dict[str, str]:
    """The first candidate with every call in ``_TESS_API`` and its versions, else why each candidate failed.

    Candidates: the loader's search, Debian's soname, then Homebrew's ``/opt/homebrew``, which macOS's
    ``find_library`` skips. ``TessBaseAPIInit5`` (a model from memory) arrived in Tesseract 5, so a 4.x library is
    passed over. Cached, a failure included, and called under ``_TESS_LOCK``.
    """
    reasons = {}
    for name in dict.fromkeys(
        filter(
            None, (ctypes.util.find_library("tesseract"), "libtesseract.so.5", "/opt/homebrew/lib/libtesseract.dylib")
        )
    ):
        try:
            lib = ctypes.CDLL(name)
            for symbol, (arguments, result) in _TESS_API.items():
                function = getattr(lib, symbol)
                function.argtypes, function.restype = arguments, result
        except (OSError, AttributeError) as error:
            reasons[name] = str(error)
            continue
        # debug_file is one variable for the whole process: set once, tprintf notes (a resolution estimate, an empty
        # page) go nowhere instead of to stderr once a page.
        handle = lib.TessBaseAPICreate()
        lib.TessBaseAPISetVariable(handle, b"debug_file", os.devnull.encode())
        lib.TessBaseAPIDelete(handle)
        return lib, {"version": lib.TessVersion().decode(), "leptonica": _leptonica_version(lib)}
    return reasons


def _leptonica_version(lib) -> str | None:
    """Leptonica's own version call, reached through libtesseract's dependencies; it does the image processing."""
    try:
        read, free = lib.getLeptonicaVersion, lib.lept_free
    except AttributeError:
        return None
    read.restype, free.argtypes = _P, [_P]
    text = read()
    try:
        return ctypes.string_at(text).decode()
    finally:
        free(text)


def _libtesseract() -> tuple[ctypes.CDLL, dict[str, str | None]]:
    with _TESS_LOCK:
        found = _load_libtesseract()
    if isinstance(found, dict):
        raise ExtractionError(
            "Tesseract requires libtesseract 5 (Homebrew tesseract; Debian and Ubuntu libtesseract5)",
            details={"tried": found},
        )
    return found


def _tessdata(language: str, variant: str, directory: str | os.PathLike | None) -> tuple[bytes, dict[str, Any]]:
    """The pinned model's bytes, read once, and their identity; refuses a missing file or any other model."""
    directory = directory if directory is not None else os.environ.get("TESSDATA_PREFIX")
    name, origin = f"{language}.traineddata", f"github.com/tesseract-ocr/tessdata_{variant}"
    if not directory:
        raise ExtractionError(f"Tesseract {variant} needs {origin}'s {name}: pass tessdata_dir or set TESSDATA_PREFIX")
    path = Path(directory) / name
    try:
        data = path.read_bytes()
    except OSError as error:
        raise ExtractionError(
            f"Tesseract {variant} model {path} is unreadable ({error.strerror}); get {name} from {origin}",
            details={"path": str(path)},
        ) from None
    found = hashlib.sha256(data).hexdigest(), len(data)
    if found != _TESSDATA[language, variant]:
        other = [v for (lang, v), pin in _TESSDATA.items() if lang == language and pin == found]
        raise ExtractionError(
            f"{path} is not {origin}'s {name}" + (f" but tessdata_{other[0]}'s" if other else ""),
            details={
                "path": str(path),
                "sha256": found[0],
                "bytes": found[1],
                "expected": _TESSDATA[language, variant],
            },
        )
    return data, {"sha256": found[0], "bytes": found[1], "source": origin}


class _Tesseract:
    """One ``TessBaseAPI`` through libtesseract's C API, initialized once from the model's bytes, reused per raster.

    The bytes handed to ``TessBaseAPIInit5`` are the ones hashed, so the identity names exactly what was loaded.
    libtesseract allows one instance per thread, never one shared; ctypes releases the GIL during each call.
    """

    def __init__(self, lib, data: bytes, language: str, psm: int):
        self.lib, self.handle = lib, (handle := lib.TessBaseAPICreate())
        self.close = weakref.finalize(self, lib.TessBaseAPIDelete, handle)
        if lib.TessBaseAPIInit5(handle, data, len(data), language.encode(), _LSTM_ONLY, None, 0, None, None, 0, 0):
            self.close()
            raise ExtractionError("libtesseract refused the model", details={"language": language})
        lib.TessBaseAPISetPageSegMode(handle, psm)

    def __call__(self, image: Raster) -> list[tuple[str, float, list[int]]]:
        """Each text line as libtesseract gives it: text with its line ending, confidence 0-100, pixel box."""
        lib, handle, detections = self.lib, self.handle, []
        lib.TessBaseAPISetImage(handle, _rgb_samples(image), image.width, image.height, 3, image.width * 3)
        try:
            if lib.TessBaseAPIRecognize(handle, None):
                raise ExtractionError(
                    "Tesseract recognition failed", details={"width": image.width, "height": image.height}
                )
            if not (lines := lib.TessBaseAPIGetIterator(handle)):  # A page without text has no iterator.
                return detections
            try:
                page, edges = lib.TessResultIteratorGetPageIterator(lines), [ctypes.c_int() for _ in range(4)]
                while True:
                    if lib.TessPageIteratorBoundingBox(page, _TEXTLINE, *map(ctypes.byref, edges)):
                        text = lib.TessResultIteratorGetUTF8Text(lines, _TEXTLINE)
                        try:
                            decoded = ctypes.string_at(text).decode() if text else ""
                        finally:
                            lib.TessDeleteText(text)
                        confidence = lib.TessResultIteratorConfidence(lines, _TEXTLINE)
                        detections.append((decoded, confidence, [edge.value for edge in edges]))
                    if not lib.TessResultIteratorNext(lines, _TEXTLINE):
                        return detections
            finally:
                lib.TessResultIteratorDelete(lines)
        finally:
            lib.TessBaseAPIClear(handle)


class Tesseract:
    """Tesseract LSTM recognition in process through libtesseract's C API, one engine per instance reused per page.

    ``model`` names a pinned upstream model: ``fast`` (tessdata_fast, the default) or ``best`` (tessdata_best). It is
    ``<tessdata_dir>/<language>.traineddata``, with ``tessdata_dir`` defaulting to ``$TESSDATA_PREFIX`` (the directory
    holding the file, as Tesseract 4 and later read it); no other directory is searched, as installed models share the
    file name. The file is read once and must match the pin's SHA-256 and size, or the backend refuses with the path
    and the upstream repository; one variant never stands in for the other. The engine runs LSTM only, on the
    raster's RGB samples (an encoded raster is decoded once). ``fast`` is the default because ``best`` took 2.2 times
    as long on the pages below for no measured gain.

    Detections are text lines in image pixels, top-left origin, with libtesseract's 0-100 confidence; blocks carry
    normalized boxes and confidence divided by 100, as the other backends do. An injected ``engine`` is called with
    each raster and returns those detections. The identity adds the libtesseract and Leptonica versions, the host
    architecture and the model file's digest. It is a host's identity, not a portable one: libtesseract picks a SIMD
    dot-product kernel per CPU and does not say which (its ``dotproduct`` variable reads ``auto`` after init), and
    ``best`` is a float model, so compare a sample before treating two hosts' readings as one version.

    One instance per serial worker or thread; ``close()`` releases the engine, which a later page rebuilds. A
    libtesseract built with OpenMP, as Debian's usually is, adds threads inside each instance: set
    ``OMP_THREAD_LIMIT=1`` when running an instance per thread or process. Only macOS (Homebrew 5.5.4, no OpenMP)
    has been measured.

    There are no bands: whole-page Tesseract read 94% and 96% of the native characters on the two dense GPO pages
    where whole-page Vision read 32%. The resolution is libtesseract's estimate from the text; stating 200 dpi changed
    a few words on 2 of 10 pages, neither way closer to the native layer. Measured with ``fast`` on 30 archive pages
    (congressional-tech ``.cache/archive-release/investigations/tesseract-backend-20261111``). On forms, PSM 3 lost
    decimals and checkboxes in an earlier qualification (``docs/extraction/pdf-extraction-choices.md``).
    """

    def __init__(self, *, language="eng", model="fast", tessdata_dir=None, page_segmentation_mode=3, engine=None):
        if (language, model) not in _TESSDATA:
            raise ValueError(f"no pinned Tesseract model {model!r} for {language!r}; pinned: {sorted(_TESSDATA)}")
        if type(page_segmentation_mode) is not int or page_segmentation_mode not in _TESSERACT_PSM:
            raise ValueError(f"page_segmentation_mode must be one of {sorted(_TESSERACT_PSM)}")
        self.language, self.model, self.tessdata_dir, self.psm = language, model, tessdata_dir, page_segmentation_mode
        self.engine, self._injected, self._model_file, self._versions = engine, engine is not None, None, {}

    def configuration(self) -> dict[str, Any]:
        """Effective settings; library versions and the model file's identity once the engine is built."""
        return {
            "backend": "tesseract",
            "version": self._versions.get("version"),
            "leptonica": self._versions.get("leptonica"),
            "machine": platform.machine(),
            "language": self.language,
            "model": self.model,
            "model_file": self._model_file,
            "page_segmentation_mode": self.psm,
            "engine_mode": "lstm-only",
            "engine_injected": self._injected,
        }

    def require_reproducible_identity(self) -> dict[str, Any]:
        """The configuration a host keys a re-read on; refuses an injected engine, whose model is unknown."""
        if self._injected:
            raise ValueError("an injected Tesseract engine has no reproducible identity")
        self._engine()
        return self.configuration()

    def _engine(self):
        if self.engine is None:
            lib, versions = _libtesseract()  # A host without it is told so before any model is read.
            data, model_file = _tessdata(self.language, self.model, self.tessdata_dir)
            self.engine = _Tesseract(lib, data, self.language, self.psm)
            self._versions, self._model_file = versions, model_file
        return self.engine

    def recognize(self, image: Raster) -> Recognition:
        detections, width, height = self._engine()(image), image.width, image.height
        blocks = tuple(
            TextBlock(text.rstrip("\n"), _box(left / width, top / height, right / width, bottom / height), conf / 100)
            for text, conf, (left, top, right, bottom) in detections
            if text.strip()
        )
        raw = {"detections": detections, "coordinates": "image pixels; top-left origin; left, top, right, bottom"}
        return Recognition("\n".join(b.text for b in blocks), self.configuration(), raw, blocks)

    def close(self):
        if not self._injected and self.engine is not None:
            self.engine.close()
            self.engine, self._model_file, self._versions = None, None, {}


class MLX:
    """MLX-VLM with explicit model, revision and prompt; reusable across pages.

    Hugging Face identifiers require a revision. Local directories are caller-pinned.
    This object and MLX's generator are intended for serial use in one worker.
    """

    def __init__(
        self,
        model: str,
        *,
        revision: str | None = None,
        prompt: str = "",
        max_tokens: int = 8192,
        temperature: float = 0,
        seed: int = 0,
        text_format: str = "plain",
    ):
        if max_tokens < 1 or temperature < 0:
            raise ValueError("max_tokens must be positive and temperature nonnegative")
        if not Path(model).is_dir() and not revision:
            raise ValueError("a remote model identifier requires an explicit revision")
        self.model, self.revision, self.prompt = model, revision, prompt
        self.max_tokens, self.temperature, self.seed = max_tokens, temperature, seed
        if text_format not in {"plain", "markdown", "html"}:
            raise ValueError("text_format must be plain, markdown or html")
        self.text_format = text_format
        self._loaded: tuple[Any, Any, dict, str] | None = None

    @classmethod
    def lighton(
        cls,
        *,
        model="mlx-community/LightOnOCR-2-1B-bf16",
        revision="16e06849ba5c689f782473651914d6613d25d884",
        **options: Any,
    ):
        return cls(model, revision=revision, **options)

    @classmethod
    def glm(
        cls,
        *,
        task="text",
        model="mlx-community/GLM-OCR-bf16",
        revision="24f15402e83baa0a80eeeaecf5480e172abc6f2e",
        **options: Any,
    ):
        prompts = {"text": "Text Recognition:", "table": "Table Recognition:", "formula": "Formula Recognition:"}
        if task not in prompts:
            raise ValueError("GLM task must be text, table or formula")
        options.setdefault("prompt", prompts[task])
        options.setdefault("text_format", "html" if task == "table" else "plain")
        return cls(model, revision=revision, **options)

    def recognize(self, image: Raster) -> Recognition:
        import mlx.core as mx
        from mlx_vlm import load, stream_generate
        from mlx_vlm.prompt_utils import apply_chat_template
        from mlx_vlm.utils import load_config

        if self._loaded is None:
            path = self.model
            if not Path(path).is_dir():
                from huggingface_hub import snapshot_download

                path = snapshot_download(path, revision=self.revision)
            model, processor = load(path)
            self._loaded = model, processor, load_config(path), path
        model, processor, config, path = self._loaded
        # MLX-VLM's loader annotation omits the detokenizer it installs at runtime.
        processor = cast(Any, processor)
        formatted = apply_chat_template(processor, config, self.prompt, num_images=1)
        if not isinstance(formatted, str):
            raise ExtractionError("selected MLX model requires an unsupported prompt template", details=formatted)
        settings = {
            "backend": "mlx-vlm",
            "version": _version("mlx-vlm"),
            "model": self.model,
            "revision": self.revision,
            "resolved_path": path,
            "prompt": self.prompt,
            "formatted_prompt": formatted,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "seed": self.seed,
            "text_format": self.text_format,
        }
        mx.random.seed(self.seed)
        parts, last = [], None
        # Use MLX-VLM's supported path input, as in the qualified experiment.
        with TemporaryDirectory(prefix="spicy-docs-mlx-") as directory:
            source = Path(directory) / "page.png"
            source.write_bytes(image.data)
            for item in stream_generate(
                model, processor, formatted, image=str(source), max_tokens=self.max_tokens, temperature=self.temperature
            ):
                parts.append(item.text)
                last = item
        text = "".join(parts)
        raw = {
            "text": text,
            "finish_reason": getattr(last, "finish_reason", None),
            "prompt_tokens": getattr(last, "prompt_tokens", None),
            "generation_tokens": getattr(last, "generation_tokens", None),
        }
        if last is None or raw["finish_reason"] != "stop" or (raw["generation_tokens"] or 0) >= self.max_tokens:
            raise ExtractionError("MLX generation did not complete", details={"configuration": settings, "raw": raw})
        return Recognition(text, settings, raw, text_format=self.text_format)

    def close(self):
        self._loaded = None
