"""Congress.gov bill child routes and their source observations."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from urllib.parse import parse_qsl, urlsplit

from spicy_docs.reading.paged_json import JsonPage, PagedJsonSourceError, query_value, with_query
from spicy_docs.sources.congress.bill_status import (
    ActionCommittee,
    BillAction,
    BillChildWitness,
    BillIdentity,
    BillSummary,
    CalendarNumber,
    RecordedVote,
)
from spicy_docs.sources.congress.listing import CONGRESS_GOV, MAX_LIMIT, CongressListingReader
from spicy_docs.transport.captured import attach_capture

# Cosponsor totals may exclude withdrawn members. The older-bill ingest
# intentionally leaves all optional routes to a later, separately qualified pass.
BILL_CHILD_ROUTES = {
    "summaries": "summaries",
    "actions": "actions",
    "titles": "titles",
    "committees": "committees",
    "relatedBills": "relatedbills",
    "cosponsors": "cosponsors",
    "textVersions": "text",
}
_READABLE_ROUTES = frozenset({"actions", "summaries", "titles"})
CONGRESS_API_SUMMARY_FORMAT = "congress-api-v3"


def _path(identity: BillIdentity, suffix: str = "") -> str:
    return f"/v3/bill/{identity.congress}/{identity.bill_type}/{identity.number}{suffix}"


def _check_locator(url: str, path: str) -> str:
    parts = urlsplit(CONGRESS_GOV.check_url(url))
    keys = [key for key, _ in parse_qsl(parts.query, keep_blank_values=True)]
    if parts.netloc != "api.congress.gov" or parts.path != path or set(keys) - {"format", "limit", "offset"}:
        raise PagedJsonSourceError("Congress.gov bill child locator differs from the selected bill or route")
    if len(keys) != len(set(keys)) or query_value(parts.geturl(), "format") not in (None, "json"):
        raise PagedJsonSourceError("Congress.gov bill child locator has unsupported query parameters")
    return parts.geturl()


def bill_child_url(identity: BillIdentity, route: str, advertised_url: str, *, limit: int = MAX_LIMIT) -> str:
    """Verify the parent-advertised route and start at its first page."""
    if route not in _READABLE_ROUTES or type(limit) is not int or not 1 <= limit <= MAX_LIMIT:
        raise PagedJsonSourceError("Congress.gov bill child route or page size is unsupported")
    url = _check_locator(advertised_url, _path(identity, "/" + BILL_CHILD_ROUTES[route]))
    if query_value(url, "offset") not in (None, "0"):
        raise PagedJsonSourceError("Congress.gov bill child locator starts after the first page")
    return with_query(with_query(url, "format", "json"), "limit", str(limit))


def bill_child_pages(
    reader: CongressListingReader, identity: BillIdentity, route: str, url: str, *, max_pages: int
) -> Iterator[JsonPage]:
    """Walk exact ordered occurrences on one bill and route or refuse the incomplete result."""
    if route not in _READABLE_ROUTES:
        raise PagedJsonSourceError("Congress.gov bill child route is outside the qualified shape")
    path = _path(identity, "/" + BILL_CHILD_ROUTES[route])
    url = _check_locator(url, path)
    limit = query_value(url, "limit")
    if not limit or not limit.isdecimal() or not 1 <= int(limit) <= MAX_LIMIT:
        raise PagedJsonSourceError("Congress.gov bill child page requires an explicit supported limit")
    if query_value(url, "offset") not in (None, "0"):
        raise PagedJsonSourceError("Congress.gov bill child walk must start at the first page")
    walk = reader.pages(url, records_key=route, max_pages=max_pages)
    offset = 0
    for page in walk:
        try:
            request = page.request_metadata
            if not isinstance(request, Mapping) or (
                str(request.get("congress")),
                str(request.get("billType")),
                str(request.get("billNumber")),
            ) != (str(identity.congress), identity.bill_type, str(identity.number)):
                raise PagedJsonSourceError("Congress.gov bill child response names a different or missing parent")
            bill_url = request.get("billUrl")
            if bill_url is not None:
                _check_locator(bill_url, _path(identity))
            if page.declared_count is None or len(page.records) > int(limit):
                raise PagedJsonSourceError("Congress.gov bill child response lacks a count or exceeds its page size")
            offset += len(page.records)
            if page.next_url is not None:
                continuation = _check_locator(page.next_url, path)
                if (
                    not page.records
                    or offset >= page.declared_count
                    or query_value(continuation, "offset") != str(offset)
                    or query_value(continuation, "limit") != limit
                ):
                    raise PagedJsonSourceError("Congress.gov bill child continuation skips or repeats membership")
            else:
                # Finish the maintained walk's terminal count check before a
                # caller can commit this page to an interrupted-run checkpoint.
                next(walk, None)
        except PagedJsonSourceError as error:
            attach_capture(error, page.capture)
            raise
        yield page


def _literal(record: Mapping, name: str) -> str | None:
    value = record.get(name)
    if value is None or isinstance(value, str):
        return value
    if type(value) is int:
        return str(value)
    raise PagedJsonSourceError(f"Congress.gov bill child {name} has an unsupported literal type")


def _object(value: object, name: str) -> Mapping:
    if isinstance(value, Mapping):
        return value
    raise PagedJsonSourceError(f"Congress.gov bill child {name} is not an object")


def _objects(record: Mapping, name: str) -> tuple[Mapping, ...] | None:
    values = record.get(name)
    if values is None:
        return None
    if not isinstance(values, list):
        raise PagedJsonSourceError(f"Congress.gov bill child {name} is not a list")
    return tuple(_object(value, name) for value in values)


def _vote(row: Mapping) -> RecordedVote:
    return RecordedVote(
        chamber=_literal(row, "chamber"),
        congress=_literal(row, "congress"),
        date=_literal(row, "date"),
        full_action_name=_literal(row, "fullActionName"),
        roll_number=_literal(row, "rollNumber"),
        session_number=_literal(row, "sessionNumber"),
        url=_literal(row, "url"),
    )


def api_action(row: Mapping, witness: BillChildWitness | None = None) -> BillAction:
    """Read the action and only the relationships stated on that action."""
    source = row.get("sourceSystem")
    system = {} if source is None else _object(source, "sourceSystem")
    committees = _objects(row, "committees")
    calendar = row.get("calendarNumber")
    calendar = None if calendar is None else _object(calendar, "calendarNumber")
    votes = _objects(row, "recordedVotes")
    return BillAction(
        text=_literal(row, "text"),
        action_date=_literal(row, "actionDate"),
        action_time=_literal(row, "actionTime"),
        action_code=_literal(row, "actionCode"),
        action_type=_literal(row, "type"),
        source_system_code=_literal(system, "code"),
        source_system_name=_literal(system, "name"),
        recorded_votes=tuple(_vote(vote) for vote in votes or ()),
        committees=None
        if committees is None
        else tuple(
            ActionCommittee(_literal(item, "systemCode"), _literal(item, "name"), _literal(item, "url"))
            for item in committees
        ),
        calendar_numbers=None
        if calendar is None
        else (CalendarNumber(_literal(calendar, "calendar"), _literal(calendar, "number")),),
        child_witness=witness,
        recorded_votes_present=votes is not None,
    )


def api_summary(row: Mapping, witness: BillChildWitness) -> BillSummary:
    """Read a CRS summary using its own update clock and revision identity."""
    body = row.get("text")
    if not isinstance(body, str):
        raise PagedJsonSourceError("Congress.gov bill summary did not state a text string")
    version = _literal(row, "versionCode")
    action_date = _literal(row, "actionDate")
    update_date = _literal(row, "updateDate")
    if not all((version, action_date, update_date)):
        raise PagedJsonSourceError("Congress.gov bill summary did not state its revision identity")
    return BillSummary(
        text=body,
        version_code=version,
        action_date=action_date,
        action_desc=_literal(row, "actionDesc"),
        update_date=update_date,
        source_schema_version=CONGRESS_API_SUMMARY_FORMAT,
        child_witness=witness,
    )
