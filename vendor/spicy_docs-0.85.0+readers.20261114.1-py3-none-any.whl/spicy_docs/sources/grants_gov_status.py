"""Literal, bounded Grants.gov search2 status observations; independent of daily XML."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime

from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.reading.paged_json import JsonPageFamily, PagedJsonBudget, PagedJsonReader, PagedJsonSourceError
from spicy_docs.transport.captured import CapturedBodyResponse

API = "https://api.grants.gov/v1/api/search2"
MAX_BYTES = 2 * 1024**2
MAX_PAGES = 32
StatusError = PagedJsonSourceError
FAMILY = JsonPageFamily(
    name="grants-gov-status",
    label="Grants.gov status",
    host="api.grants.gov",
    method="POST",
    count_path=("data", "hitCount"),
    next_kind="page-number",
    next_path=("next",),
    page_field="startRecordNum",
    credential_header=None,
    requires_credential=False,
)


@dataclass(frozen=True)
class StatusSelection:
    """An explicit opportunity-number population, optionally narrowed by agency/eligibility."""

    opportunity_number: str
    agencies: str = ""
    eligibilities: str = ""
    statuses: str = "forecasted|posted|closed|archived"
    page_size: int = 10

    def __post_init__(self):
        for value in (self.opportunity_number, self.agencies, self.eligibilities, self.statuses):
            if not isinstance(value, str) or len(value) > 255 or value != value.strip():
                raise StatusError("Grants status selection requires bounded literal filters")
        if not self.opportunity_number or not self.statuses:
            raise StatusError("Grants status requires an explicit opportunity number and status population")
        if type(self.page_size) is not int or not 1 <= self.page_size <= 100:
            raise StatusError("Grants status page size must be from 1 to 100")

    def body(self, offset=0):
        if type(offset) is not int or offset < 0 or offset % self.page_size:
            raise StatusError("Grants status offset must follow the selected page size")
        return {
            "oppNum": self.opportunity_number,
            "agencies": self.agencies,
            "eligibilities": self.eligibilities,
            "oppStatuses": self.statuses,
            "rows": self.page_size,
            "startRecordNum": offset,
        }


def selected_body(body):
    if not isinstance(body, dict) or set(body) != {
        "oppNum",
        "agencies",
        "eligibilities",
        "oppStatuses",
        "rows",
        "startRecordNum",
    }:
        raise StatusError("Grants status request fields differ")
    selected = StatusSelection(
        body["oppNum"], body["agencies"], body["eligibilities"], body["oppStatuses"], body["rows"]
    )
    if selected.body(body["startRecordNum"]) != body:
        raise StatusError("Grants status request differs from selection")
    return selected


class StatusReader(PagedJsonReader):
    """Use the shared POST transport and traversal; validate publisher-specific paging witnesses."""

    def __init__(self, *, budget: PagedJsonBudget, **kwargs):
        if budget.max_page_bytes > MAX_BYTES or budget.max_requests > MAX_PAGES:
            raise StatusError("Grants status exceeds its bounded request budget")
        super().__init__(family=FAMILY, budget=budget, **kwargs)

    def page(self, url, *, body=None, **kwargs):
        if url != API:
            raise StatusError("Grants status requires the official search2 route")
        selected_body(body)
        return super().page(url, body=body, **kwargs)

    def read(self, selection, *, max_pages=MAX_PAGES):
        if type(max_pages) is not int or not 1 <= max_pages <= MAX_PAGES:
            raise StatusError("Grants status page bound differs")
        return self.pages(API, records_key=("data", "oppHits"), body=selection.body(), max_pages=max_pages)

    def _continuation(self, value, *, url, body, rows):
        selected = selected_body(body)
        data = value.get("data")
        if type(value.get("errorcode")) is not int or value["errorcode"] != 0 or not isinstance(data, dict):
            raise StatusError("Grants status response reports no successful search")
        params = data.get("searchParams")
        total, start = data.get("hitCount"), data.get("startRecord")
        offset = body["startRecordNum"]
        if (
            not isinstance(params, dict)
            or any(params.get(key) != val for key, val in body.items())
            or type(total) is not int
            or total < 0
            or type(start) is not int
            or start != offset
            or data.get("errorMsgs") != []
            or (offset and offset >= total)
            or len(rows) != min(selected.page_size, max(0, total - offset))
        ):
            raise StatusError("Grants status echoed filters, offset, count or page membership differ")
        identities = set()
        for row in rows:
            native = row.get("id")
            if not isinstance(native, str) or re.fullmatch(r"[0-9]{1,20}", native) is None or native in identities:
                raise StatusError("Grants status native identity is missing or repeated")
            identities.add(native)
            # A search may use publisher matching rules rather than exact equality
            # for oppNum/agency filters. Preserve the echoed query and each actual hit.
            for key in ("oppStatus", "docType", "openDate", "closeDate"):
                if key in row and row[key] is not None and not isinstance(row[key], str):
                    raise StatusError("Grants status/date field is not a literal string or null")
        next_offset = offset + len(rows) if offset + len(rows) < total else None
        return super()._continuation({"next": next_offset}, url=url, body=body, rows=rows)


def capture_descriptor(capture):
    if (
        not isinstance(capture, CapturedBodyResponse)
        or capture.requested_url != API
        or capture.resolved_url != API
        or capture.method != "POST"
        or capture.status_code != 200
        or capture.content_encoding != "identity"
        or (capture.content_type or "").split(";", 1)[0].strip().lower() != "application/json"
        or not 0 < capture.byte_size <= MAX_BYTES
        or capture.request_body is None
    ):
        raise StatusError("Grants status capture route, method, representation or size differs")
    body = load_integer_json(capture.request_body, source="Grants status request", error_type=StatusError)
    selected_body(body)
    try:
        instant = datetime.fromisoformat(capture.observed_at)
        if instant.utcoffset() is None:
            raise ValueError
    except (TypeError, ValueError) as error:
        raise StatusError("Grants status observation requires a timezone") from error
    return {
        "request_url": API,
        "request_body": body,
        "response_sha256": capture.sha256,
        "observed_at": capture.observed_at,
        "byte_size": capture.byte_size,
    }


def read_capture(capture):
    """Offline replay uses exactly the same page checks as acquisition."""
    descriptor = capture_descriptor(capture)
    body = descriptor["request_body"]
    selected = selected_body(body)
    with StatusReader(budget=PagedJsonBudget(1, MAX_BYTES, 30, 0)) as reader:
        page = reader._read_page(
            capture,
            url=API,
            body=body,
            records_key=("data", "oppHits"),
            page_index=body["startRecordNum"] // selected.page_size,
            single_record=False,
        )
    value = load_integer_json(capture.body, source="Grants status", error_type=StatusError)
    data = value.get("data") if isinstance(value, dict) else None
    rows = data.get("oppHits") if isinstance(data, dict) else None
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        raise StatusError("Grants status response omitted its literal hit list")
    return {
        "offset": body["startRecordNum"],
        "capture": descriptor,
        "count": page.declared_count,
        "next_offset": page.next_body["startRecordNum"] if page.next_body else None,
        "results": [
            {
                "selection": asdict(selected),
                "raw": row,
                "source_locator": descriptor | {"json_pointer": f"/data/oppHits/{index}"},
            }
            for index, row in enumerate(rows)
        ],
    }
