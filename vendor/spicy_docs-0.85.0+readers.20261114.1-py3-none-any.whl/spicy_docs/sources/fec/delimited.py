"""One FEC original or selected ZIP member, decoded and split into literal delimited rows with byte coordinates.

The positional-row release profile and the committee-master reader both read through here, so the bounded ZIP
selection and the row split exist once.
"""

from __future__ import annotations

import csv
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from contextvars import ContextVar
from tempfile import TemporaryFile
from zipfile import ZipFile

from spicy_docs.reading.zip_archive import inspect_archive_stream, seekable_stream
from spicy_docs.sources.fec.bulk_profile import MAX_INVENTORY_BYTES
from spicy_docs.sources.fec.filings import _Lines
from spicy_docs.storage.blobs import iter_verified_blob

_ARCHIVE_SESSION = ContextVar("fec_verified_archive_session", default=None)


class _Session:
    def __init__(self):
        self.inventories = {}
        self.held = None  # ((digest, size), spool) for the one held original

    def release(self):
        if self.held is not None:
            self.held[1].close()
            self.held = None

    def holds(self, stream, capture) -> bool:
        key = (capture["responseSha256"], capture["byteSize"])
        return self.held is not None and self.held[0] == key and self.held[1] is stream


@contextmanager
def verified_archive_session():
    """Reuse complete ZIP inspections within one operation, checking every opened original.

    The bounded cache stores only verified member metadata. Every use of a caller's
    stream hashes the complete opened bytes before and after parsing, so a claimed
    digest or a mutable path cannot grant trust. The one exception is the session's
    own spool from ``held_original``. Outside the context nothing is cached or held.
    """
    session = _Session()
    token = _ARCHIVE_SESSION.set(session)
    try:
        yield
    finally:
        _ARCHIVE_SESSION.reset(token)
        session.release()


def held_original(blob_source, blob_ref: str, byte_size: int):
    """Return the session's private spool of one stored original, hashed once as it is written.

    Consecutive selections from the same original (the members of one ZIP) reuse the
    spool, so a ZIP is read and hashed once per contiguous run instead of once per
    member plus twice in ``selected_stream``. Another original replaces it: the session
    holds at most one. ``selected_stream`` trusts this spool without rehashing because
    SpicyDocs wrote it from bytes it verified, and an anonymous temporary file has no
    path another writer could open. Requires an open ``verified_archive_session``.
    """
    session = _ARCHIVE_SESSION.get()
    if session is None:
        raise RuntimeError("a held original requires a verified archive session")
    key = (blob_ref, byte_size)
    if session.held is None or session.held[0] != key:
        session.release()
        spool = TemporaryFile()  # noqa: SIM115 - held past this call; release() closes it
        try:
            for chunk in iter_verified_blob(blob_source, blob_ref, byte_size):
                spool.write(chunk)
        except BaseException:
            spool.close()
            raise
        session.held = (key, spool)
    spool = session.held[1]
    spool.seek(0)
    return spool


class _BorrowedOriginal:
    def __init__(self, stream):
        self.stream = stream

    @contextmanager
    def open(self, blob_ref):
        self.stream.seek(0)
        yield self.stream


def _verify_original(stream, capture):
    for _ in iter_verified_blob(_BorrowedOriginal(stream), capture["responseSha256"], capture["byteSize"]):
        pass
    stream.seek(0)


@contextmanager
def selected_stream(stream, *, capture: Mapping, member: Mapping | None, max_members: int, max_decoded_bytes: int):
    """Yield ``(decoded stream, member, sha256)`` for an opaque original, or for the one ZIP member ``member`` selects.

    ``capture`` is a validated original capture. For a ZIP the whole archive's bounded inventory is decoded first,
    so every member is verified before a row is read; a missing ordinal, a differing name or a directory refuses.
    ``sha256`` is the original's digest, or the selected member's.
    """
    if member is None:
        if capture["byteSize"] > max_decoded_bytes:
            raise ValueError("FEC original exceeds its decoded byte bound")
        yield stream, None, capture["responseSha256"]
        return
    with seekable_stream(stream, byte_size=capture["byteSize"]) as original:
        session = _ARCHIVE_SESSION.get()
        key = (capture["responseSha256"], capture["byteSize"], max_members, max_decoded_bytes)
        recheck = session is not None and not session.holds(original, capture)
        if recheck:
            _verify_original(original, capture)
        inventory = None if session is None else session.inventories.get(key)
        if inventory is None:
            inventory = inspect_archive_stream(
                original,
                byte_size=capture["byteSize"],
                max_entries=max_members,
                max_decoded_bytes=max_decoded_bytes,
                max_metadata_bytes=MAX_INVENTORY_BYTES,
            )
            if session is not None:
                if len(session.inventories) == 8:
                    session.inventories.pop(next(iter(session.inventories)))
                session.inventories[key] = inventory
        ordinal = member["ordinal"]
        if ordinal >= len(inventory["members"]):
            raise ValueError("FEC selected ZIP member is missing")
        selected = inventory["members"][ordinal]
        if selected["name"] != member["name"] or selected["isDirectory"]:
            raise ValueError("FEC selected ZIP member identity differs or is a directory")
        # The complete bounded decoder has verified every member. Reuse the same
        # original for standard streaming reads; never reopen it for each row/page.
        with ZipFile(original) as archive, archive.open(archive.infolist()[ordinal]) as decoded:
            try:
                yield decoded, member, selected["sha256"]
            finally:
                if recheck:
                    _verify_original(original, capture)


def delimited_rows(
    stream, *, sha256: str, encoding: str, delimiter: str, quoting: str, max_record_bytes: int
) -> Iterator[dict]:
    """Split a decoded stream into rows of literal fields, each with its byte offset and length in that stream.

    ``quoting`` ``"csv"`` follows Python's CSV syntax; ``"literal"`` keeps quote characters as data. A row longer
    than ``max_record_bytes`` refuses.
    """
    lines = _Lines(stream, encoding, max_record_bytes)
    while True:
        lines.start = lines.end
        fields = lines.record(
            csv.reader(
                lines,
                delimiter=delimiter,
                quoting=csv.QUOTE_MINIMAL if quoting == "csv" else csv.QUOTE_NONE,
                strict=True,
            )
        )
        if fields is None:
            return
        yield {
            "kind": "row",
            "fields": fields,
            "source": {
                "sha256": sha256,
                "byte_offset": lines.start,
                "byte_length": lines.end - lines.start,
                "encoding": encoding,
            },
        }
