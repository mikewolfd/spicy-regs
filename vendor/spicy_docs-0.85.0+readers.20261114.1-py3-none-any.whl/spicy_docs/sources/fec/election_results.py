"""Literal rows of the FEC's Federal Elections workbook, with no contest filters.

Use the existing bounded OOXML reader. State certification, ballot-line fusion,
round selection and financial candidate identity remain downstream decisions.
"""

import hashlib
import re
from collections import defaultdict
from dataclasses import asdict

from spicy_docs.sources.scorecards.workbooks import literal_sheets

READER_VERSION = "fec-election-workbook/1"
SENATE_2022 = "7. US Senate Results by State"
TITLE_2022 = "FEDERAL ELECTIONS 2022:  ELECTION RESULTS FOR THE U.S. SENATE AND THE U.S. HOUSE OF REPRESENTATIVES"


def workbook_rows(body: bytes, *, sha256: str, cycle: int):
    """Yield every physical row and literal cell of one supported result edition.

    The digest identifies the original, not a cached conversion. Null cells,
    formulas, zero votes, totals, notes and appendix observations all survive.
    A ballot roster or changed layout refuses before yielding anything.
    """
    if "sha256:" + hashlib.sha256(body).hexdigest() != sha256:
        raise ValueError("Election workbook differs from its selected original digest")
    if cycle != 2022:
        raise ValueError("Only the reviewed Federal Elections 2022 layout is supported")
    sheets = literal_sheets(body)
    information = sheets.get("1. 2022 Publication Information", {})
    if information.get("A15") is None or information["A15"].value != TITLE_2022:
        raise ValueError("Expected Federal Elections results, not a ballot roster")
    senate = sheets.get(SENATE_2022, {})
    headers = {
        "B1": "STATE ABBREVIATION",
        "D1": "DISTRICT",
        "E1": "FEC ID",
        "I1": "CANDIDATE NAME",
        "L1": "PRIMARY VOTES",
        "P1": "GENERAL VOTES ",
        "T1": "COMBINED GE PARTY TOTALS (when applicable)",
        "AC1": "3RD ROUND RCV VOTES",
    }
    if any(senate.get(cell) is None or senate[cell].value != text for cell, text in headers.items()):
        raise ValueError("Federal Elections Senate result columns changed")
    for sheet, cells in sheets.items():
        rows = defaultdict(dict)
        for coordinate, cell in cells.items():
            match = re.fullmatch(r"([A-Z]+)([1-9][0-9]*)", coordinate)
            facts = asdict(cell)
            facts["date_value"] = cell.date_value.isoformat() if cell.date_value is not None else None
            rows[int(match[2])][match[1]] = facts
        for number, row in sorted(rows.items()):
            yield {
                "sheet": sheet,
                "row": number,
                "cells": row,
                "source_sha256": sha256,
                "cycle": cycle,
                "reader_version": READER_VERSION,
            }
