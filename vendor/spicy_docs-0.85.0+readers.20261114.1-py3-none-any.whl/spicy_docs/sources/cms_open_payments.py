"""Literal, release-bound Open Payments DKAN summary rows; no payment-level joins.

The maintained bounded transport and JSON decoder own HTTP and syntax. This
adapter owns the publisher's year filter, summary identity and complete walk.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from urllib.parse import urlencode, urlsplit

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.transport.captured import CapturedBodyResponse

CATALOG_URL = "https://openpaymentsdata.cms.gov/data.json"
BASE = "https://openpaymentsdata.cms.gov/api/1"
MAX_PAGE_BYTES = 8 * 1024**2
MAX_PAGE_SIZE = 500
TITLES = {
    "entities": "Payments grouped by reporting entities",
    "recipients": "Payments grouped by physician (distinct) for all years",
    "hospitals": "Payments grouped by Teaching Hospital",
    "states": "State level payment total and averages for all years",
    "national": "National level payment total and averages for all years",
}
IDENTITIES = {
    "entities": ("amgpo_making_payment_id",),
    "recipients": ("covered_recipient_profile_id",),
    "hospitals": ("teaching_hospital_ccn",),
    "states": ("country_code", "state_code", "payment_type", "recipient_type"),
    "national": ("metric_level", "payment_type", "recipient_type"),
}


class OpenPaymentsError(ValueError):
    """An unavailable, ambiguous or changed summary is never an empty population."""


def decode(raw, *, max_bytes=MAX_PAGE_BYTES):
    return load_bounded_json(
        raw,
        source="CMS Open Payments",
        error_type=OpenPaymentsError,
        number_policy="integer",
        max_bytes=max_bytes,
        max_nodes=200_000,
    )


def validate_url(url):
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.hostname != "openpaymentsdata.cms.gov" or parsed.username or parsed.password:
        raise OpenPaymentsError("Unexpected Open Payments publisher URL")
    return url


@dataclass(frozen=True)
class SummarySelection:
    aggregation_level: str
    program_year: int
    dataset_id: str
    release: str
    download_url: str
    catalog_sha256: str
    modified: str

    def as_dict(self):
        return asdict(self)


def select_summary(catalog: CapturedBodyResponse, *, aggregation_level: str, program_year: int):
    if catalog.status_code != 200 or catalog.requested_url != CATALOG_URL:
        raise OpenPaymentsError("Select the official Open Payments catalog capture")
    if aggregation_level not in TITLES or type(program_year) is not int or not 2019 <= program_year <= 2025:
        raise OpenPaymentsError("Unsupported summary level or program year; qualify a new year explicitly")
    data = decode(catalog.body)
    matches = [d for d in data.get("dataset", []) if d.get("title") == TITLES[aggregation_level]]
    if len(matches) != 1:
        raise OpenPaymentsError("Summary dataset identity is missing or ambiguous")
    dataset = matches[0]
    distributions = dataset.get("distribution", [])
    if len(distributions) != 1 or "Summary" not in dataset.get("theme", []):
        raise OpenPaymentsError("Summary distribution differs")
    url = distributions[0].get("downloadURL", "")
    match = re.fullmatch(r"https://download\.cms\.gov/openpayments/SMRY_RPTS_(P\d{8}_\d{8})/[^/]+\.csv", url)
    if match is None or not re.fullmatch(r"[0-9a-f-]{36}", dataset.get("identifier", "")):
        raise OpenPaymentsError("Summary lacks its declared publication identity")
    return SummarySelection(
        aggregation_level, program_year, dataset["identifier"], match[1], url, catalog.sha256, dataset["modified"]
    )


def page_url(selection: SummarySelection, *, offset=0, size=MAX_PAGE_SIZE):
    if type(offset) is not int or offset < 0 or type(size) is not int or not 1 <= size <= MAX_PAGE_SIZE:
        raise OpenPaymentsError("Invalid bounded summary page")
    query = {
        "limit": size,
        "offset": offset,
        "count": "true",
        "schema": "true",
        "keys": "true",
        "rowIds": "true",
        "conditions[0][property]": "program_year",
        "conditions[0][value]": str(selection.program_year),
        "conditions[0][operator]": "=",
    }
    # Native record_number supplies a unique datastore occurrence, including
    # repeated recipient associations. Never deduplicate by name or NPI.
    query.update({"sorts[0][property]": "record_number", "sorts[0][order]": "asc"})
    return f"{BASE}/datastore/query/{selection.dataset_id}/0?{urlencode(query)}"


def read_page(capture: CapturedBodyResponse, selection: SummarySelection, *, offset=0, size=MAX_PAGE_SIZE):
    expected = page_url(selection, offset=offset, size=size)
    if (
        capture.status_code != 200
        or capture.requested_url != expected
        or capture.resolved_url != expected
        or (capture.content_type or "").split(";")[0] != "application/json"
    ):
        raise OpenPaymentsError("Open Payments response/request identity or success shape differs")
    data = decode(capture.body)
    if not isinstance(data, dict) or not isinstance(data.get("results"), list) or type(data.get("count")) is not int:
        raise OpenPaymentsError("DKAN summary requires literal results and count")
    count, rows, schema = data["count"], data["results"], data.get("schema")
    if count < 0 or len(rows) != min(size, max(0, count - offset)) or offset > count:
        raise OpenPaymentsError("DKAN summary page is incomplete or outside its count")
    if not isinstance(schema, dict) or len(schema) != 1:
        raise OpenPaymentsError("DKAN summary schema/resource identity differs")
    fields = next(iter(schema.values())).get("fields", {})
    if not {"program_year", *IDENTITIES[selection.aggregation_level]} <= fields.keys():
        raise OpenPaymentsError("DKAN summary schema lacks native identity fields")
    for row in rows:
        if not isinstance(row, dict) or any(v is not None and not isinstance(v, str) for v in row.values()):
            raise OpenPaymentsError("DKAN cells must remain literal strings or null")
        if row.get("program_year") != str(selection.program_year):
            raise OpenPaymentsError("Open Payments program year mismatch")
        if not all(
            isinstance(row.get(k), str) and (row[k] or k in {"country_code", "state_code"})
            for k in IDENTITIES[selection.aggregation_level]
        ):
            raise OpenPaymentsError("Open Payments native summary identity is missing")
        if not re.fullmatch(r"[1-9][0-9]*", row.get("record_number", "")):
            raise OpenPaymentsError("DKAN row occurrence identity is missing")
        if not set(fields) <= row.keys():
            raise OpenPaymentsError("DKAN row omitted declared fields")
    return data


class SummaryWalk:
    """One page decode per step, shared by acquisition/resume and offline replay."""

    def __init__(self, selection, *, size=MAX_PAGE_SIZE):
        self.selection, self.size = selection, size
        self.count = self.schema = None
        self.observed = self.previous = self.pages = 0

    def add(self, capture):
        if self.count is not None and self.observed >= self.count:
            raise OpenPaymentsError("Unexpected extra DKAN summary page")
        data = read_page(capture, self.selection, offset=self.observed, size=self.size)
        if self.count is None:
            self.count, self.schema = data["count"], data["schema"]
        if self.count != data["count"] or self.schema != data["schema"]:
            raise OpenPaymentsError("DKAN count or schema changed during the summary walk")
        for position, raw in enumerate(data["results"]):
            native_number = int(raw["record_number"])
            if native_number <= self.previous:
                raise OpenPaymentsError("Repeated or unordered DKAN record_number")
            self.previous = native_number
            pointer = f"/results/{position}"
            yield {
                "raw": raw,
                "selection": self.selection.as_dict(),
                "source_locator": {
                    "request_url": capture.requested_url,
                    "response_sha256": capture.sha256,
                    "observed_at": capture.observed_at,
                    "json_pointer": pointer,
                    "record_number": raw["record_number"],
                    "ordinal": self.observed + position,
                    "source_record_id": "sha256:"
                    + hashlib.sha256(
                        f"{self.selection.dataset_id}|{self.selection.release}|{capture.sha256}|{pointer}".encode()
                    ).hexdigest(),
                },
            }
        self.observed += len(data["results"])
        self.pages += 1

    def finish(self):
        if not self.pages or self.observed != self.count:
            raise OpenPaymentsError("Open Payments summary walk did not complete its declared count")


def iter_summary(selection: SummarySelection, captures, *, size=MAX_PAGE_SIZE):
    """Read one complete ordered observed cohort; partial consumption proves nothing.

    Count and schema must agree on every page. A caller retains originals and
    rechecks the selected release. This is not a frozen publisher snapshot and
    absence from a later partial selection never establishes deletion.
    """
    walk = SummaryWalk(selection, size=size)
    for capture in captures:
        yield from walk.add(capture)
    walk.finish()


def csv_url(selection, *, resource_id, offset, count):
    """The documented DKAN CSV download query for an exact missing suffix."""
    if (
        not re.fullmatch(r"[0-9a-f-]{36}", resource_id)
        or type(offset) is not int
        or offset < 0
        or type(count) is not int
        or count <= 0
    ):
        raise OpenPaymentsError("Invalid Open Payments CSV resource or suffix")
    query = {
        "format": "csv",
        "limit": count,
        "offset": offset,
        "rowIds": "true",
        "conditions[0][property]": "program_year",
        "conditions[0][value]": str(selection.program_year),
        "conditions[0][operator]": "=",
        "sorts[0][property]": "record_number",
        "sorts[0][order]": "asc",
    }
    return f"{BASE}/datastore/query/{resource_id}/download?{urlencode(query)}"


def iter_csv_summary(stream, selection, descriptor, *, schema, total_count, offset, previous_number=0, count=None):
    """Stream a caller-verified CSV suffix using the maintained positional CSV reader.

    Source bytes/coordinates remain literal. CSV empty cells remain empty; this
    format cannot establish whether a publisher database value was JSON null.
    Full exhaustion validates count. One blank trailing physical record is a
    publisher CSV terminator, not a summary record.
    """
    from spicy_docs.sources.fec.delimited import delimited_rows

    if len(schema) != 1 or total_count <= offset:
        raise OpenPaymentsError("CSV suffix lacks its DKAN count/schema control")
    resource_id = next(iter(schema))
    expected_rows = total_count - offset if count is None else count
    if type(expected_rows) is not int or not 0 < expected_rows <= total_count - offset:
        raise OpenPaymentsError("CSV range exceeds its declared cohort")
    expected = csv_url(selection, resource_id=resource_id, offset=offset, count=expected_rows)
    if descriptor["request_url"] != expected or not 0 < descriptor["byte_size"] <= 512 * 1024**2:
        raise OpenPaymentsError("CSV suffix release/category/request identity differs")
    records = iter(
        delimited_rows(
            stream,
            sha256=descriptor["sha256"],
            encoding="utf-8",
            delimiter=",",
            quoting="csv",
            max_record_bytes=64 * 1024,
        )
    )
    header = next(records, None)
    if header is None:
        raise OpenPaymentsError("Open Payments CSV header is missing")
    names = header["fields"]
    required = set(schema[resource_id]["fields"]) | {"record_number"}
    if len(names) != len(set(names)) or not required <= set(names):
        raise OpenPaymentsError("Open Payments CSV header differs from its selected schema")
    observed, previous, trailers = 0, previous_number, 0
    for record in records:
        fields = record["fields"]
        if not fields and observed == expected_rows and trailers == 0:
            trailers += 1
            continue
        if trailers or len(fields) != len(names) or observed >= expected_rows:
            raise OpenPaymentsError("Open Payments CSV row width/count/trailer differs")
        raw = dict(zip(names, fields, strict=True))
        if raw["program_year"] != str(selection.program_year):
            raise OpenPaymentsError("Open Payments CSV program year mismatch")
        if not re.fullmatch(r"[1-9][0-9]*", raw["record_number"]) or int(raw["record_number"]) <= previous:
            raise OpenPaymentsError("Repeated or unordered Open Payments CSV record_number")
        if not all(raw.get(k) or k in {"country_code", "state_code"} for k in IDENTITIES[selection.aggregation_level]):
            raise OpenPaymentsError("Open Payments CSV native identity is missing")
        previous = int(raw["record_number"])
        source = record["source"]
        yield {
            "raw": raw,
            "selection": selection.as_dict(),
            "source_locator": {
                "request_url": expected,
                "response_sha256": descriptor["sha256"],
                "observed_at": descriptor["observed_at"],
                "source_format": "csv",
                "csv_record": observed + 2,
                "byte_offset": source["byte_offset"],
                "byte_length": source["byte_length"],
                "record_number": raw["record_number"],
                "ordinal": offset + observed,
                "source_record_id": "sha256:"
                + hashlib.sha256(
                    f"{selection.dataset_id}|{selection.release}|{descriptor['sha256']}|{source['byte_offset']}".encode()
                ).hexdigest(),
            },
        }
        observed += 1
    if observed != expected_rows:
        raise OpenPaymentsError("Open Payments CSV did not complete its declared suffix count")
