"""Retain and independently replay one exact Census geography lookup."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from functools import cache
from io import BytesIO
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.reading.evidence_zip import deterministic_zip_entry, has_deterministic_zip_metadata
from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.releases.profile import SourceNativeProfile
from spicy_docs.sources.census_geocoder import (
    API,
    MAX_BYTES,
    OUTCOMES,
    GeocoderError,
    GeocoderSelection,
    descriptor,
    lookup_record,
    selection_id,
)
from spicy_docs.transport.captured import CapturedBodyResponse

SCHEMA_NAME = "census-geography-lookup"
SCHEMA_VERSION = "1.0"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-{SCHEMA_VERSION}.json"
MAX_BUNDLE_BYTES = 2 * MAX_BYTES
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "urn:spicy-docs:schema:census-geography-lookup:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["selection", "capture", "response_json", "outcome", "reason", "candidates"],
    "properties": {
        "selection": {"type": "object"},
        "capture": {"type": "object"},
        "response_json": {"type": "string"},
        "outcome": {"enum": list(OUTCOMES)},
        "reason": {"type": ["string", "null"]},
        "candidates": {"type": "array"},
    },
    "x-spicy-record-order": [
        {
            "fieldPath": "/capture/request_url",
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
    ],
}


def geocoder_scope(selection, capture):
    lookup_record(selection, capture)
    return {"selection": asdict(selection), "capture": descriptor(capture)}


def _scope(value):
    if not isinstance(value, dict) or set(value) != {"selection", "capture"}:
        raise GeocoderError("lookup release scope fields differ")
    try:
        selection = GeocoderSelection(**value["selection"])
        c = value["capture"]
        if c["request_url"] != selection.url or c["resolved_url"] != selection.url:
            raise GeocoderError("lookup scope URL differs")
        if type(c["byte_size"]) is not int or not 0 < c["byte_size"] <= MAX_BYTES:
            raise GeocoderError("lookup capture byte bound differs")
        from datetime import datetime

        if datetime.fromisoformat(c["observed_at"]).utcoffset() is None:
            raise GeocoderError("lookup capture timestamp lacks timezone")
    except (TypeError, KeyError, ValueError) as error:
        raise GeocoderError("lookup release scope is invalid") from error
    return value


@dataclass(frozen=True, slots=True)
class RetainedGeocoderPage:
    request_key: str
    response_bytes: bytes
    page_index: int = 0
    traversal_index: int = 0
    window_index: int = 0
    window_page_index: int = 0
    source_cursor: None = None
    evidence_media_type: str = "application/zip"


def retained_page(selection, capture):
    scope = geocoder_scope(selection, capture)
    output = BytesIO()
    with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr(deterministic_zip_entry("manifest.json"), canonical_json_bytes(scope))
        archive.writestr(deterministic_zip_entry("response.json"), capture.body)
    body = output.getvalue()
    if len(body) > MAX_BUNDLE_BYTES:
        raise GeocoderError("lookup evidence bundle exceeds byte bound")
    return RetainedGeocoderPage(selection.url, body)


def _parse_bundle(body):
    if not isinstance(body, bytes) or len(body) > MAX_BUNDLE_BYTES:
        raise GeocoderError("lookup evidence exceeds byte bound")
    try:
        with ZipFile(BytesIO(body)) as archive:
            infos = archive.infolist()
            if len(infos) != 2 or any(
                not has_deterministic_zip_metadata(i, name=n)
                for i, n in zip(infos, ("manifest.json", "response.json"), strict=True)
            ):
                raise GeocoderError("lookup evidence ZIP members differ")
            if infos[0].file_size > 16384 or infos[1].file_size > MAX_BYTES:
                raise GeocoderError("lookup ZIP expanded size exceeds bound")
            scope = _scope(
                load_integer_json(archive.read(infos[0]), source="geocoder manifest", error_type=GeocoderError)
            )
            c, raw = scope["capture"], archive.read(infos[1])
            capture = CapturedBodyResponse(
                c["request_url"], c["resolved_url"], c["status_code"], c["content_type"], c["observed_at"], raw
            )
            if descriptor(capture) != c:
                raise GeocoderError("lookup retained response identity differs")
    except BadZipFile as error:
        raise GeocoderError("invalid lookup evidence ZIP") from error
    return {"scope": scope, "results": [lookup_record(GeocoderSelection(**scope["selection"]), capture)]}


def _included(response, *, query_scope, page_window):
    if response["scope"] != query_scope or page_window != GeocoderSelection(**query_scope["selection"]).url:
        raise GeocoderError("lookup evidence differs from selected release scope")
    return True


@dataclass
class _Traversal:
    pages: int = 0

    def add(self, response, *, page_index):
        if page_index != 0 or self.pages:
            raise GeocoderError("lookup release requires one retained response")
        self.pages += 1

    def finish(self):
        if self.pages != 1:
            raise GeocoderError("lookup release omitted response")


@dataclass
class _Acquisition:
    windows: int = 0

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if not records_included:
            raise GeocoderError("lookup release omitted outcome")
        self.windows += 1

    def finish(self, *, query_scope):
        if self.windows != 1:
            raise GeocoderError("lookup release requires one response window")


def _record_scope(record, *, query_scope, page_window):
    if record["selection"] != query_scope["selection"] or record["capture"] != query_scope["capture"]:
        raise GeocoderError("lookup record differs from captured selection")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


GEOCODER_PROFILE = SourceNativeProfile(
    name="Retained Census geography lookup",
    source_system_id=API,
    source_system_version="geographies/Census2020",
    acquisition_policy_id="urn:spicy-docs:acquisition:census-geocoder",
    acquisition_policy_version="1.0",
    scope_id="census-geocoder",
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="census-geography-lookup",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "strategy": "retained-single-record-lookup",
        "coverageLimits": [
            "One explicit Census2020 address or coordinate lookup; no ACS estimates or ZIP centroids.",
            "Refused, ambiguous and conversion-failed outcomes establish no unique assignment.",
        ],
    },
    validate_query_scope=_scope,
    parse_page_response=_parse_bundle,
    next_page=lambda response, *, seen_urls: None,
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda record, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": SCHEMA_VERSION,
        "scopeId": "census-geocoder",
        "sourceRecordId": selection_id(GeocoderSelection(**record["selection"])),
    },
    record_digest=lambda record: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(record))).hexdigest(),
    rendition_rows=lambda record: (),
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": SCHEMA_VERSION,
    },
    source_schema_digest=_schema_digest,
    validate_record_scope=_record_scope,
    records_included=_included,
    acquisition_check=_Acquisition,
    page_window=lambda url: url,
)
