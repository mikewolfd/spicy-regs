"""Read pinned NPPES CSV cohorts without losing literal cells or repeated sidecar rows.

This is an offline reader, not an archive downloader or a current directory.
The caller supplies the exact decoded member pin, reviewed header and RefSpec's
``validate_npi`` callable. No NPI validator or bulk excerpt parser is copied.
Weekly sidecar removal semantics remain unqualified; observations never imply
that a missing relationship was deleted. See docs/sources/nppes.md.
"""

from __future__ import annotations

import csv
import hashlib
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date

from spicy_docs.sources.fec.delimited import delimited_rows

KINDS = frozenset({"main", "othername", "practice_location", "endpoint"})
MAIN_COLUMNS = ("NPI", "Entity Type Code", "NPI Deactivation Date", "NPI Reactivation Date")


class NppesSourceError(ValueError):
    """A pinned input cannot establish the declared cohort observations."""


@dataclass(frozen=True, slots=True)
class NppesRow:
    npi: str
    record_number: int
    byte_offset: int
    byte_length: int
    values: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class NppesCsv:
    kind: str
    scope: str
    source_url: str
    member_name: str
    sha256: str
    byte_size: int
    columns: tuple[str, ...]
    cohort: tuple[str, ...]
    scanned_rows: int
    rows: tuple[NppesRow, ...]


class _PinnedLines:
    """Hash during the maintained CSV reader's bounded line reads."""

    def __init__(self, stream, byte_size):
        self.stream, self.byte_size = stream, byte_size
        self.size, self.digest = 0, hashlib.sha256()

    def readline(self, size):
        raw = self.stream.readline(min(size, self.byte_size - self.size + 1))
        if not isinstance(raw, bytes):
            raise NppesSourceError("NPPES needs a binary stream")
        self.size += len(raw)
        if self.size > self.byte_size:
            raise NppesSourceError("NPPES input exceeds its pinned byte size")
        self.digest.update(raw)
        return raw


def literal_npi(value: str, validate_npi: Callable[[str], str]) -> str:
    """Use the identifier owner while refusing silent whitespace/Unicode changes."""
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{10}", value) or validate_npi(value) != value:
        raise NppesSourceError("NPPES NPI must be literal ASCII digits accepted by RefSpec")
    return value


def main_state(fields: dict[str, str]) -> str:
    """Read disclosed main-row lifecycle facts, refusing ambiguous combined dates.

    The retained CMS dissemination page says a deactivated row discloses only
    NPI and deactivation date. Both lifecycle dates together need the missing V2
    README; their relative dates are not an invented resolution rule.
    """
    for key in ("NPI Deactivation Date", "NPI Reactivation Date"):
        value = fields[key]
        if value:
            try:
                if not re.fullmatch(r"[0-9]{2}/[0-9]{2}/[0-9]{4}", value):
                    raise ValueError
                date(int(value[6:]), int(value[:2]), int(value[3:5]))
            except ValueError as error:
                raise NppesSourceError(f"NPPES {key} is not a literal MM/DD/YYYY date") from error
    if fields["NPI Deactivation Date"]:
        if fields["NPI Reactivation Date"]:
            raise NppesSourceError("Combined deactivation/reactivation dates need qualified V2 semantics")
        if any(value for key, value in fields.items() if key not in {"NPI", "NPI Deactivation Date"}):
            raise NppesSourceError("Deactivated NPI discloses fields beyond NPI and deactivation date")
        return "deactivated"
    if fields["Entity Type Code"] not in {"1", "2"}:
        raise NppesSourceError("Active NPPES row needs individual or organization Entity Type Code")
    return "reactivated" if fields["NPI Reactivation Date"] else "active"


def read_csv_cohort(
    stream,
    *,
    kind: str,
    scope: str,
    source_url: str,
    member_name: str,
    expected_sha256: str,
    expected_bytes: int,
    columns: tuple[str, ...],
    cohort: tuple[str, ...],
    validate_npi: Callable[[str], str],
    max_scanned_rows: int,
    max_selected_rows: int,
    max_record_bytes: int = 1024 * 1024,
) -> NppesCsv:
    """Consume and hash one CSV fully before returning a bounded cohort.

    ``scope`` is ``member`` or ``excerpt``. A fully read excerpt is still an
    excerpt. Header, width, UTF-8, row/byte bounds and selected main NPI uniqueness
    are checked. Duplicate checks cover the declared cohort, not nationwide data.
    Sidecar occurrences retain source order, including identical repeated rows.
    Empty cells remain empty strings; missing columns and rows of wrong width
    refuse rather than manufacture nulls. No partial result escapes on failure.
    """
    for bound in (expected_bytes, max_scanned_rows, max_selected_rows, max_record_bytes):
        if type(bound) is not int or bound < 1:
            raise NppesSourceError("NPPES byte/row bounds must be positive integers")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", expected_sha256):
        raise NppesSourceError("NPPES requires an exact SHA-256 pin")
    if kind not in KINDS or scope not in {"member", "excerpt"} or not source_url or not member_name:
        raise NppesSourceError("Declare NPPES kind, member/excerpt scope, URL and member identity")
    if not columns or len(set(columns)) != len(columns) or any(not c for c in columns) or "NPI" not in columns:
        raise NppesSourceError("NPPES needs unique nonempty reviewed columns including NPI")
    if kind == "main" and not set(MAIN_COLUMNS) <= set(columns):
        raise NppesSourceError("NPPES main header is missing lifecycle columns")
    if not cohort or len(set(cohort)) != len(cohort):
        raise NppesSourceError("Declare a nonempty NPPES cohort without duplicates")
    for npi in cohort:
        literal_npi(npi, validate_npi)
    selected, seen, rows, scanned = set(cohort), set(), [], 0
    pinned = _PinnedLines(stream, expected_bytes)
    records = delimited_rows(
        pinned,
        sha256=expected_sha256,
        encoding="utf-8",
        delimiter=",",
        quoting="csv",
        max_record_bytes=max_record_bytes,
    )
    try:
        header = next(records, None)
        if header is None or tuple(header["fields"]) != columns:
            raise NppesSourceError("NPPES CSV header differs from reviewed columns")
        index = columns.index("NPI")
        for record_number, row in enumerate(records, 2):
            scanned += 1
            if scanned > max_scanned_rows:
                raise NppesSourceError("NPPES scan exceeds max_scanned_rows")
            values = row["fields"]
            if len(values) != len(columns):
                raise NppesSourceError(f"NPPES record {record_number} has a malformed field count")
            npi = literal_npi(values[index], validate_npi)
            if npi not in selected:
                continue
            if kind == "main":
                if npi in seen:
                    raise NppesSourceError("NPPES main CSV repeats a cohort NPI")
                seen.add(npi)
                main_state(dict(zip(columns, values, strict=True)))
            if len(rows) == max_selected_rows:
                raise NppesSourceError("NPPES cohort exceeds max_selected_rows")
            source = row["source"]
            rows.append(NppesRow(npi, record_number, source["byte_offset"], source["byte_length"], tuple(values)))
    except (csv.Error, UnicodeDecodeError) as error:
        raise NppesSourceError("NPPES CSV has malformed quotes or UTF-8") from error
    if pinned.size != expected_bytes or "sha256:" + pinned.digest.hexdigest() != expected_sha256:
        raise NppesSourceError("NPPES CSV differs from its byte/digest pin")
    return NppesCsv(
        kind, scope, source_url, member_name, expected_sha256, expected_bytes, columns, cohort, scanned, tuple(rows)
    )
