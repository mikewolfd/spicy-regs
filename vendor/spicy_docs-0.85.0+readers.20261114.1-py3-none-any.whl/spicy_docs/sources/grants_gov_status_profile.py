"""Admit/replay one bounded, pinned Grants.gov search2 population with the shared publisher."""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.grants_gov_status import (
    API,
    MAX_BYTES,
    MAX_PAGES,
    StatusError,
    StatusSelection,
    capture_descriptor,
    read_capture,
)
from spicy_docs.transport.captured import CapturedBodyResponse

SCOPE_ID = "grants-gov-status-observation-v1"
SCHEMA_NAME = "grants-gov-status-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["selection", "raw", "source_locator"],
    "properties": {
        "selection": {"type": "object"},
        "raw": {"type": "object", "required": ["id"]},
        "source_locator": {"type": "object"},
    },
}


def status_scope(selection, captures):
    return validate_scope({"selection": asdict(selection), "captures": [capture_descriptor(c) for c in captures]})


def validate_scope(value):
    if not isinstance(value, dict) or set(value) != {"selection", "captures"}:
        raise StatusError("Grants status scope differs")
    if not isinstance(value["selection"], dict) or set(value["selection"]) != set(asdict(StatusSelection("example"))):
        raise StatusError("Grants status selection fields differ")
    selected = StatusSelection(**value["selection"])
    captures = value["captures"]
    if not isinstance(captures, list) or not 1 <= len(captures) <= MAX_PAGES:
        raise StatusError("Grants status requires bounded retained page captures")
    for index, capture in enumerate(captures):
        if (
            not isinstance(capture, dict)
            or set(capture) != {"request_url", "request_body", "response_sha256", "observed_at", "byte_size"}
            or capture["request_url"] != API
            or capture["request_body"] != selected.body(index * selected.page_size)
            or not isinstance(capture["response_sha256"], str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
            or type(capture["byte_size"]) is not int
            or not 0 < capture["byte_size"] <= MAX_BYTES
        ):
            raise StatusError("Grants status capture inventory differs")
        # Reuse the source owner's timestamp and method checks without reading a body.
        from datetime import datetime

        try:
            if datetime.fromisoformat(capture["observed_at"]).utcoffset() is None:
                raise ValueError
        except (TypeError, ValueError) as error:
            raise StatusError("Grants status capture timestamp requires a timezone") from error
    return value


def _key(offset):
    return f"grants-gov://status/offset/{offset}"


def iter_retained_pages(scope, *, blob_source):
    for index, capture in enumerate(validate_scope(scope)["captures"]):
        key = _key(capture["request_body"]["startRecordNum"])
        yield SourceNativeBlobPage(
            page_index=index,
            window_index=0,
            window_page_index=index,
            request_key=key,
            source_cursor=key if index else None,
            blob_ref=capture["response_sha256"],
            byte_size=capture["byte_size"],
            blob_source=blob_source,
            evidence_media_type="application/json",
        )


def _parse_stream(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    matches = [c for c in query_scope["captures"] if _key(c["request_body"]["startRecordNum"]) == request_key]
    if len(matches) != 1:
        raise StatusError("Grants status page is outside the selected capture inventory")
    capture = matches[0]
    if (evidence_ref, byte_size, media_type) != (capture["response_sha256"], capture["byte_size"], "application/json"):
        raise StatusError("Grants status evidence binding differs")
    raw = stream.read(MAX_BYTES + 1)
    if len(raw) != byte_size or "sha256:" + hashlib.sha256(raw).hexdigest() != evidence_ref:
        raise StatusError("Grants status retained bytes differ")
    return read_capture(
        CapturedBodyResponse(
            API,
            API,
            200,
            "application/json",
            capture["observed_at"],
            raw,
            method="POST",
            request_body=canonical_json_bytes(capture["request_body"]),
        )
    )


def _included(response, *, query_scope, page_window):
    captures = query_scope["captures"]
    index = response["offset"] // query_scope["selection"]["page_size"]
    expected_next = captures[index + 1]["request_body"]["startRecordNum"] if index + 1 < len(captures) else None
    if response["capture"] != captures[index] or page_window != 0 or response["next_offset"] != expected_next:
        raise StatusError("Grants status selected pages are missing, extra or inconsistent")
    return True


@dataclass
class _Traversal:
    count: int | None = None
    observed: int = 0

    def add(self, response, *, page_index):
        if response["offset"] != self.observed:
            raise StatusError("Grants status offsets are not contiguous")
        if self.count is None:
            self.count = response["count"]
        if response["count"] != self.count:
            raise StatusError("Grants status count changed during traversal")
        self.observed += len(response["results"])

    def finish(self):
        if self.count is None or self.observed != self.count:
            raise StatusError("Grants status membership differs from the declared count")


@dataclass
class _Acquisition:
    windows: int = 0

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if response["offset"] != 0 or not records_included:
            raise StatusError("Grants status requires a complete selected query")
        self.windows += 1

    def finish(self, *, query_scope):
        if self.windows != 1:
            raise StatusError("Grants status query is missing or repeated")


def _record_scope(record, *, query_scope, page_window):
    locator = record["source_locator"]
    index = locator["request_body"]["startRecordNum"] // query_scope["selection"]["page_size"]
    if record["selection"] != query_scope["selection"] or any(
        locator.get(key) != value for key, value in query_scope["captures"][index].items()
    ):
        raise StatusError("Grants status record differs from its selected query")


def _byte_parser(_raw):
    raise StatusError("Grants status requires captured request and response metadata")


def _classify(record):
    if not isinstance(record, dict):
        raise StatusError("Grants status record must be a literal object")
    return record


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


GRANTS_GOV_STATUS_PROFILE = SourceNativeProfile(
    name="Retained Grants.gov lifecycle status query",
    source_system_id=API,
    source_system_version="search2-v1",
    acquisition_policy_id="urn:spicy-docs:acquisition:grants-gov-status",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="grants-gov-status",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "strategy": "retained-exact-count-query",
        "coverageLimits": [
            "One explicit search2 query with echoed filters, contiguous offsets, stable count and unique native IDs.",
            "Observed crawl, not a frozen publisher snapshot; each page has its own observation time.",
            "Literal oppStatus is separate from docType and daily XML; no inferred withdrawal from missing membership.",
            "Earlier observations require explicit cumulative release selection; this is not complete status history.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_page_stream=_parse_stream,
    max_evidence_bytes=MAX_BYTES,
    next_page=lambda response, *, seen_urls: (
        _key(response["next_offset"]) if response["next_offset"] is not None else None
    ),
    traversal_check=_Traversal,
    classify_record=_classify,
    wrap_record=lambda record, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": f"grants-gov-status:{record['raw']['id']}",
    },
    record_digest=lambda record: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(record))).hexdigest(),
    rendition_rows=lambda record: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=_included,
    acquisition_check=_Acquisition,
    page_window=lambda _: 0,
)
