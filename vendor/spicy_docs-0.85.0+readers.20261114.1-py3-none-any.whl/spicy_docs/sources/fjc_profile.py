"""One pinned FJC Article III flat export through the maintained source-release file stream."""

import hashlib
import re
from contextlib import closing
from dataclasses import dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.fjc import EXPORT_URL, MAX_BYTES, FjcError, fjc_scope, snapshot_records, validate_scope

SCOPE_ID = "fjc-article-iii-flat-snapshot-v1"
SCHEMA_NAME = "fjc-biography-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
MAX_PAGE_BYTES = 1024**2
MAX_PAGE_RECORDS = 100
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["id", "nid", "ordinal", "fields", "source_locator"],
    "properties": {
        "id": {"type": "string"},
        "nid": {"type": "string", "pattern": "^[0-9]+$"},
        "ordinal": {"type": "integer", "minimum": 0},
        "fields": {"type": "object", "additionalProperties": {"type": "string"}},
        "source_locator": {"type": "object"},
    },
    "x-spicy-record-order": [
        {
            "fieldPath": "/id",
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
    ],
}


def _key(index):
    return f"fjc://snapshot/page/{index}"


def iter_retained_pages(scope, *, blob_source):
    """Hand the selected CSV to the publisher as its original opaque bytes."""
    capture = validate_scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, _key(0), capture["response_sha256"], capture["byte_size"], blob_source, "application/octet-stream"
    )


def _page(index, rows, terminal):
    return {"requestKey": _key(index), "page": index, "results": rows, "terminal": terminal}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = validate_scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["response_sha256"],
        capture["byte_size"],
        "application/octet-stream",
    ):
        raise FjcError("FJC original differs from the selected capture")
    page, rows, size = 0, [], 0
    overhead = len(canonical_json_bytes(_page(page, [], False)))
    with closing(snapshot_records(stream, scope=scope)) as records:
        for record in records:
            record_size = len(canonical_json_bytes(record))
            if rows and (len(rows) == MAX_PAGE_RECORDS or overhead + size + record_size + len(rows) > MAX_PAGE_BYTES):
                yield _page(page, rows, False)
                page, rows, size = page + 1, [], 0
                overhead = len(canonical_json_bytes(_page(page, [], False)))
            if overhead + record_size > MAX_PAGE_BYTES:
                raise FjcError("FJC record exceeds the source page bound")
            rows.append(record)
            size += record_size
    yield _page(page, rows, True)


@dataclass
class _Traversal:
    pages: int = 0
    records: int = 0
    terminal: bool = False

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise FjcError("FJC pages are not contiguous")
        for row in response["results"]:
            if row["ordinal"] != self.records:
                raise FjcError("FJC CSV record ordering differs")
            self.records += 1
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if not self.pages or not self.terminal:
            raise FjcError("FJC export did not finish")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise FjcError("FJC requires one selected original")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise FjcError("FJC selected original is missing")


def _window(key):
    if not isinstance(key, str) or re.fullmatch(r"fjc://snapshot/page/(0|[1-9][0-9]*)", key) is None:
        raise FjcError("FJC page key differs")
    return 0


def _record_scope(record, *, query_scope, page_window):
    capture = query_scope["capture"]
    locator = record["source_locator"]
    if (
        record["nid"] != record["fields"].get("nid")
        or record["id"] != f"fjc:{capture['response_sha256']}:{record['ordinal']:020d}"
        or any(locator.get(key) != capture[key] for key in capture)
        or locator.get("csv_record_number") != record["ordinal"] + 2
        or locator.get("sha256") != capture["response_sha256"]
        or type(locator.get("byte_offset")) is not int
        or type(locator.get("byte_length")) is not int
        or not 0 < locator["byte_offset"] < capture["byte_size"]
        or not 0 < locator["byte_length"] <= capture["byte_size"] - locator["byte_offset"]
    ):
        raise FjcError("FJC record coordinates differ from its selected source")


def _byte_parser(_raw):
    raise FjcError("FJC requires its captured original stream")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


def _records_included(response, **kwargs):
    """An empty snapshot legitimately yields zero records; refuse nothing per page."""
    return True


FJC_PROFILE = SourceNativeProfile(
    name="Retained FJC Article III biography flat export",
    source_system_id=EXPORT_URL,
    source_system_version="article-iii-flat-csv",
    acquisition_policy_id="urn:spicy-docs:acquisition:fjc-article-iii-flat-export",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="fjc",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "One observed complete FJC Article III flat export, including its listed historical courts and recess appointees.",
            "Acquisition time and byte digest identify this observation; the publisher supplies no frozen revision or row count.",
            "Every literal cell survives, including empty strings, whitespace, unknown columns and repeated service groups.",
            "Full-file parsing proves selected-file coverage, not all federal judges or current vacancies.",
            "Native nid, legacy jid, court labels and Seat ID remain distinct; cross-source identities are unresolved.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": row["id"],
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=_records_included,
    acquisition_check=_Acquisition,
    page_window=_window,
)

__all__ = ["FJC_PROFILE", "fjc_scope", "iter_retained_pages"]
