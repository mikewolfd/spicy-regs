"""House filing index facts and bounded, explicitly selected original captures.

Index parsing is an attributed port of austin-starks/congressional-disclosures
at 2965e8796bd4cb9423a83b964a1f9dbd076a0ad6 (MIT; see NOTICE). Unlike the
upstream PTR selector, this reader retains every filing category and literal cell.
PDF transaction interpretation is separate from deterministic index discovery.
"""

# House index parser
#
# The deterministic index reader in src/spicy_docs/sources/house_disclosures.py adapts
# parseHouseIndexTsv and parseHouseIndexZip from austin-starks/congressional-disclosures
# at 2965e8796bd4cb9423a83b964a1f9dbd076a0ad6.
#
# MIT License
#
# Copyright (c) 2026 Austin Starks
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from io import BytesIO
from zipfile import BadZipFile, ZipFile

from spicy_docs.reading.pdf_bytes import check_pdf_bytes, terminal_xref_offset
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_final_url

ORIGIN = "https://disclosures-clerk.house.gov"
PARSER_VERSION = "house-disclosures-index-v1"
MAX_BYTES = 32 * 1024**2
_COLUMNS = ("prefix", "last", "first", "suffix", "filingtype", "statedst", "year", "filingdate", "docid")


class HouseDisclosureError(ValueError):
    """A selected House input cannot establish the requested source facts."""


def _year(year: int) -> int:
    if type(year) is not int or not 2008 <= year <= 2100:
        raise HouseDisclosureError("House index year must be an integer from 2008 to 2100")
    return year


def index_url(year: int) -> str:
    return f"{ORIGIN}/public_disc/financial-pdfs/{_year(year)}FD.zip"


def report_url(year: int, doc_id: str, *, ptr: bool) -> str:
    """Construct the publisher's route; an index row does not prove the PDF is held."""
    if not isinstance(doc_id, str) or re.fullmatch(r"[0-9]+", doc_id) is None:
        raise HouseDisclosureError("House DocID must contain only ASCII digits")
    directory = "ptr-pdfs" if ptr else "financial-pdfs"
    return f"{ORIGIN}/public_disc/{directory}/{_year(year)}/{doc_id}.pdf"


@dataclass(frozen=True)
class HouseIndexRow:
    index_year: int
    source_line: int
    doc_id: str
    filing_type: str
    filing_date_raw: str
    prefix: str
    first: str
    last: str
    suffix: str
    state_district: str
    year_raw: str
    raw_cells: tuple[tuple[str, str], ...]

    @property
    def url(self) -> str:
        return report_url(self.index_year, self.doc_id, ptr=self.filing_type == "P")


def parse_index_tsv(body: bytes, *, year: int) -> tuple[HouseIndexRow, ...]:
    """Read all categories, retaining original cells and physical TSV line locators.

    A header-only index is an observed empty input. Missing columns, inconsistent
    row widths/years refuse. Repeated DocIDs remain distinct line observations;
    a downstream report selection must resolve any ambiguous index identity.
    """
    _year(year)
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House index exceeds the byte bound or is not bytes")
    try:
        lines = body.decode("utf-8-sig").splitlines()
    except UnicodeDecodeError as error:
        raise HouseDisclosureError("House index is not UTF-8") from error
    header = lines[0].split("\t") if lines else []
    keys = [name.strip().lower() for name in header]
    if len(keys) != len(set(keys)) or not set(_COLUMNS).issubset(keys):
        raise HouseDisclosureError("House index has duplicate or missing required columns")
    result = []
    for number, line in enumerate(lines[1:], 2):
        if not line.strip():
            continue
        values = line.split("\t")
        if len(values) != len(header):
            raise HouseDisclosureError(f"House index line {number} has an inconsistent column count")
        row = dict(zip(keys, values, strict=True))
        cell = {key: value.strip() for key, value in row.items()}
        doc_id = cell["docid"]
        report_url(year, doc_id, ptr=cell["filingtype"].upper() == "P")
        if cell["year"] != str(year) or not cell["filingtype"]:
            raise HouseDisclosureError(f"House index line {number} has a wrong year or blank category")
        result.append(
            HouseIndexRow(
                year,
                number,
                doc_id,
                cell["filingtype"].upper(),
                row["filingdate"],
                row["prefix"],
                row["first"],
                row["last"],
                row["suffix"],
                row["statedst"],
                row["year"],
                tuple(zip(header, values, strict=True)),
            )
        )
    return tuple(result)


def parse_index_zip(body: bytes, *, year: int) -> tuple[HouseIndexRow, ...]:
    """Read the exact named text member, leaving the original ZIP authoritative."""
    _year(year)
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House ZIP exceeds the byte bound or is not bytes")
    member = f"{year}FD.txt"
    try:
        with ZipFile(BytesIO(body)) as archive:
            matches = [info for info in archive.infolist() if info.filename == member]
            if len(matches) != 1 or matches[0].file_size > MAX_BYTES or matches[0].flag_bits & 1:
                raise HouseDisclosureError("House ZIP lacks one bounded unencrypted year index")
            return parse_index_tsv(archive.read(matches[0]), year=year)
    except (BadZipFile, RuntimeError, OSError) as error:
        raise HouseDisclosureError("House index ZIP cannot be read") from error


def validate_pdf(body: bytes) -> str:
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House PDF exceeds the byte bound or is not bytes")
    check_pdf_bytes(body, error_type=HouseDisclosureError, label="House disclosure PDF")
    if terminal_xref_offset(body) is None:
        raise HouseDisclosureError("House disclosure PDF lacks a terminal cross-reference")
    return "sha256:" + hashlib.sha256(body).hexdigest()


class HouseDisclosureAcquirer(SourceAcquirer):
    """Direct public file capture only; no search acknowledgement or access bypass."""

    def __init__(self, *, transport=None):
        super().__init__(
            max_requests=2,
            timeout_seconds=45,
            min_request_interval_seconds=0.5,
            user_agent="spicy-docs-house-disclosures/1.0",
            label="House disclosures",
            error_type=HouseDisclosureError,
            context_key="house_disclosure_acquisition",
            keyless=True,
            transport=transport,
        )

    def _acquire(self, url, parse, media_types):
        def checked(capture, _limit):
            if capture.status_code != 200:
                raise HouseDisclosureError(f"House source answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                url,
                error_type=HouseDisclosureError,
                message="House final URL differs from the selected file",
            )
            return parse(capture.body)

        return self.capture_validated(
            url,
            media_types=media_types,
            parse=checked,
            max_bytes=MAX_BYTES,
            unavailable=lambda capture: HouseDisclosureError(f"House source unavailable (HTTP {capture.status_code})"),
            context={"url": url},
            max_attempts=1,
        )

    def acquire_index(self, *, year: int):
        return self._acquire(
            index_url(year),
            lambda body: parse_index_zip(body, year=year),
            ("application/zip", "application/x-zip-compressed", "application/octet-stream"),
        )

    def acquire_ptr(self, *, year: int, doc_id: str):
        return self._acquire(
            report_url(year, doc_id, ptr=True), validate_pdf, ("application/pdf", "application/octet-stream")
        )
