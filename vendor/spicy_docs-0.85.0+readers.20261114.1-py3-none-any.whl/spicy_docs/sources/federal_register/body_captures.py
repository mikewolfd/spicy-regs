"""Durable per-document body results using the maintained acquisition and blob owners.

A successful local read replays only that document's verified responses through
FederalRegisterBodyAcquirer. It cannot use the network. Failed attempts retain
exact available refusal evidence and require an explicit acquisition retry.
Callers hold exclusive ownership of each result path while writing it.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path

import httpx

from spicy_docs.reading.refusals import RefusedResponse, retain_refused_response
from spicy_docs.sources.federal_register.body_acquisition import (
    FederalRegisterBodyAcquirer,
    FederalRegisterBodyAcquisition,
    FederalRegisterBodyBudget,
)
from spicy_docs.sources.federal_register.body_sources import FederalRegisterBodySourceError
from spicy_docs.sources.federal_register.native import federal_register_source_record_id
from spicy_docs.storage.blobs import LocalSourceNativeBlobStore, iter_verified_blob
from spicy_docs.transport.captured import CapturedBodyResponse, attached_capture
from spicy_docs.transport.credentials import CredentialRefusedError, scrub_credential
from spicy_docs.transport.resume import write_json_atomic


@dataclass(frozen=True)
class RetainedBodyResult:
    outcome: str
    acquisition: FederalRegisterBodyAcquisition | None
    captures: tuple[CapturedBodyResponse, ...]
    refused_response: RefusedResponse | None
    manifest: dict
    manifest_bytes: bytes | None = field(default=None, repr=False, compare=False)


def _capture_receipt(capture, store):
    store.put_blob(capture.sha256, capture.byte_size, [capture.body])
    return {
        **{
            key: getattr(capture, key)
            for key in (
                "requested_url",
                "resolved_url",
                "status_code",
                "content_type",
                "observed_at",
                "content_encoding",
                "method",
            )
        },
        "sha256": capture.sha256,
        "byte_size": capture.byte_size,
    }


def _read_capture(item, store, bound):
    size = item["byte_size"]
    if type(size) is not int or not 0 <= size <= bound:
        raise ValueError("Retained body exceeds its acquisition bound")
    if item["method"] != "GET" or item["content_encoding"] != "identity":
        raise ValueError("Retained body requires an identity-encoded GET")
    body = b"".join(iter_verified_blob(store, item["sha256"], size))
    return CapturedBodyResponse(
        **{
            key: item[key]
            for key in (
                "requested_url",
                "resolved_url",
                "status_code",
                "content_type",
                "observed_at",
                "content_encoding",
                "method",
            )
        },
        body=body,
    )


def load_body_capture(path: Path, *, record: dict) -> RetainedBodyResult:
    """Validate a saved result offline and return the exact bytes used to parse its manifest."""
    path = Path(path)
    with path.open("rb") as source:
        raw = source.read(64 * 1024 + 1)
    if len(raw) > 64 * 1024:
        raise ValueError("Body result metadata exceeds its bound")
    manifest = json.loads(raw)
    if not isinstance(manifest, dict):
        raise TypeError("Body result is not a manifest")
    request = manifest.get("request")
    budget_manifest = manifest.get("budget")
    if (
        manifest.get("version") != 1
        or manifest.get("source_record_id") != federal_register_source_record_id(record)
        or not isinstance(request, dict)
        or request.get("document_number") != record["document_number"]
        or request.get("publication_date") != record["publication_date"]
        or manifest.get("outcome") not in {"acquired", "source_failed"}
        or not isinstance(budget_manifest, dict)
    ):
        raise ValueError("Body result differs from its selected source record")
    budget = FederalRegisterBodyBudget(**budget_manifest)
    bound = max(budget.max_body_bytes, budget.max_mods_bytes)
    receipts = manifest["captures"]
    if not isinstance(receipts, list) or len(receipts) > 3:
        raise ValueError("Body result has an invalid response population")
    store = LocalSourceNativeBlobStore(path.parent / "blobs", create=False)
    captures = tuple(_read_capture(item, store, bound) for item in receipts)
    refusal = manifest.get("refusal")
    refused = None
    if refusal is not None:
        body = None
        if "sha256" in refusal:
            size = refusal["bytes"]
            if type(size) is not int or not 0 <= size <= bound:
                raise ValueError("Retained refusal exceeds its acquisition bound")
            body = b"".join(iter_verified_blob(store, refusal["sha256"], size))
        refused = RefusedResponse(
            **{
                key: refusal.get(key)
                for key in (
                    "request_key",
                    "stage",
                    "media_type",
                    "unavailable_reason",
                    "observed_byte_size",
                    "stated_byte_size",
                )
            },
            response_bytes=body,
        )
    if manifest["outcome"] == "source_failed":
        if not isinstance(manifest.get("failure"), dict):
            raise ValueError("Failed body result lacks its explicit reason")
        return RetainedBodyResult("source_failed", None, captures, refused, manifest, manifest_bytes=raw)
    if refused is not None or not captures:
        raise ValueError("Successful body result has inconsistent refusal evidence")
    pending = iter(captures)

    def replay(request):
        capture = next(pending, None)
        if (
            capture is None
            or request.method != "GET"
            or str(request.url) != capture.requested_url
            or capture.resolved_url != capture.requested_url
        ):
            raise ValueError("Body replay differs from its recorded request sequence")
        headers = {"Content-Encoding": "identity"}
        if capture.content_type is not None:
            headers["Content-Type"] = capture.content_type
        return httpx.Response(
            capture.status_code,
            headers=headers,
            stream=httpx.ByteStream(capture.body),
            request=request,
            extensions={"spicy_docs_retained_observed_at": capture.observed_at},
        )

    with FederalRegisterBodyAcquirer(
        budget=replace(budget, min_request_interval_seconds=0), transport=httpx.MockTransport(replay)
    ) as client:
        acquisition = client.acquire(**manifest["request"])
    if next(pending, None) is not None or acquisition.format != manifest["format"]:
        raise ValueError("Body replay did not consume exactly the selected successful responses")
    return RetainedBodyResult("acquired", acquisition, captures, None, manifest, manifest_bytes=raw)


def capture_body(
    path: Path,
    *,
    record: dict,
    source_pin: dict,
    acquirer: FederalRegisterBodyAcquirer,
    retry_failed: bool = False,
    format: str = "prefer-xml",
    html_route: str = "granule",
    start_page: int | None = None,
) -> RetainedBodyResult:
    """Acquire one missing result or explicitly retry a failure; reuse verified successes.

    ``source_pin`` records the admitted metadata release used by this attempt.
    A later source release may reuse the same dated document's original capture;
    that reuse does not claim a new observation or refresh its time.
    """
    path = Path(path)
    request = {
        "document_number": record["document_number"],
        "publication_date": record["publication_date"],
        "format": format,
        "html_route": html_route,
        "start_page": start_page,
    }
    previous = None
    if path.exists():
        previous = load_body_capture(path, record=record)
        if previous.manifest["request"] != request:
            raise ValueError("Body acquisition selection changed; use a different result path")
        if previous.outcome == "acquired" or not retry_failed:
            if previous.manifest.get("failure", {}).get("credential_refused"):
                raise CredentialRefusedError("Retained source access refusal; explicit retry is required")
            return previous
    if not source_pin.get("logicalId") or not source_pin.get("artifactDigest"):
        raise ValueError("Body acquisition requires its metadata source release identity")
    path.parent.mkdir(parents=True, exist_ok=True)
    store = LocalSourceNativeBlobStore(path.parent / "blobs")
    manifest = {
        "version": 1,
        "source_record_id": federal_register_source_record_id(record),
        "source_pin": source_pin,
        "request": request,
        "budget": asdict(acquirer.budget),
    }
    acquisition, refused, abort = None, None, None
    try:
        acquisition = acquirer.acquire(**request)
    except CredentialRefusedError as error:
        abort = error
        captures = ()
        manifest.update(
            outcome="source_failed",
            captures=[],
            failure={
                "type": type(error).__name__,
                "reason": scrub_credential(str(error)),
                "credential_refused": True,
                "status_code": next((code for code in (401, 403) if f"HTTP {code}" in str(error)), None),
            },
        )
    except (FederalRegisterBodySourceError, ConnectionError, httpx.HTTPError) as error:
        refused = getattr(error, "refused_response", None)
        context = getattr(error, "body_acquisition", {})
        captures = tuple(
            value for value in (context.get("unavailableXml"), attached_capture(error)) if value is not None
        )
        manifest.update(
            outcome="source_failed",
            captures=[_capture_receipt(value, store) for value in captures],
            refusal=retain_refused_response(
                error, store=store.root, max_bytes=max(acquirer.budget.max_body_bytes, acquirer.budget.max_mods_bytes)
            ),
            failure={"type": type(error).__name__, "reason": scrub_credential(str(error))},
            request_count=context.get("requestCount"),
        )
    else:
        captures = tuple(
            value for value in (acquisition.unavailable_xml, acquisition.mods, acquisition.body) if value is not None
        )
        manifest.update(
            outcome="acquired",
            format=acquisition.format,
            captures=[_capture_receipt(value, store) for value in captures],
            request_count=acquisition.request_count,
        )
    manifest["completed_at"] = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    if previous is not None:
        # Preserve the exact unsuccessful attempt before selecting its replacement.
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        history = path.parent / ("previous-" + digest + ".json")
        if not history.exists():
            write_json_atomic(history, previous.manifest)
    write_json_atomic(path, manifest)
    if abort is not None:
        raise abort
    return RetainedBodyResult(manifest["outcome"], acquisition, captures, refused, manifest)
