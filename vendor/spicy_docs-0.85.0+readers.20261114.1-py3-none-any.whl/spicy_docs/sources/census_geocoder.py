"""Bounded Census geography lookups over the maintained capture transport.

Single-record official JSON mapping; no censusgeocode code or dependency.
Exact source bytes and decimal spellings remain authoritative.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from urllib.parse import urlencode

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.transport.captured import attached_capture
from spicy_docs.transport.source_acquirer import SourceAcquirer, utc_now

API = "https://geocoding.geo.census.gov/geocoder"
MAX_BYTES = 1024 * 1024
BENCHMARK = "Public_AR_Census2020"
VINTAGE = "Census2020_Census2020"
OUTCOMES = ("matched", "unmatched", "ambiguous", "refused", "conversion_failed")


class GeocoderError(ValueError):
    """The lookup cannot establish a supported geography assignment."""


def coordinate(value, bound):
    """Validate a literal coordinate without rounding or changing its spelling."""
    if not isinstance(value, str) or len(value) > 80 or not re.fullmatch(r"[+-]?[0-9]+(?:\.[0-9]+)?", value):
        raise GeocoderError("coordinate must be a literal decimal string")
    try:
        number = Decimal(value)
        if not number.is_finite() or number.copy_abs() > bound:
            raise GeocoderError("coordinate is outside longitude/latitude bounds")
    except InvalidOperation as error:
        raise GeocoderError("coordinate conversion failed") from error
    return value


@dataclass(frozen=True, slots=True)
class GeocoderSelection:
    kind: str
    benchmark: str
    vintage: str
    address: str | None = None
    x: str | None = None
    y: str | None = None

    def __post_init__(self):
        # Fixed named versions avoid silently moving Current aliases. Other
        # versions require their own source qualification, not an implicit default.
        if (self.benchmark, self.vintage) != (BENCHMARK, VINTAGE):
            raise GeocoderError("only the explicit Census2020 benchmark/vintage pair is supported")
        if self.kind == "onelineaddress":
            if (
                not isinstance(self.address, str)
                or not self.address.strip()
                or len(self.address) > 1000
                or self.x is not None
                or self.y is not None
            ):
                raise GeocoderError("address lookup requires one bounded original address only")
            if not re.match(r"\s*[0-9]+\s+\S+", self.address):
                raise GeocoderError("a structure address is required; ZIP-only assignment is unsupported")
        elif self.kind == "coordinates":
            if self.address is not None:
                raise GeocoderError("coordinate lookup cannot also contain an address")
            coordinate(self.x, 180)
            coordinate(self.y, 90)
        else:
            raise GeocoderError("only onelineaddress and coordinates geography lookups are supported")

    @property
    def url(self):
        fields = {"benchmark": self.benchmark, "vintage": self.vintage, "format": "json"}
        fields.update({"address": self.address} if self.kind == "onelineaddress" else {"x": self.x, "y": self.y})
        return f"{API}/geographies/{self.kind}?" + urlencode(fields)


def descriptor(capture):
    return {
        "request_url": capture.requested_url,
        "resolved_url": capture.resolved_url,
        "status_code": capture.status_code,
        "content_type": capture.content_type,
        "observed_at": capture.observed_at,
        "response_sha256": capture.sha256,
        "byte_size": len(capture.body),
    }


def _identity(actual, expected, name):
    if not isinstance(actual, dict) or actual.get(name + "Name") != expected:
        raise GeocoderError("response benchmark/vintage differs from the exact selection")


def _geographies(value):
    if not isinstance(value, dict) or any(not isinstance(v, list) for v in value.values()):
        raise GeocoderError("geographies must contain native layer arrays")
    for layer, rows in value.items():
        for row in rows:
            if (
                not isinstance(row, dict)
                or not isinstance(row.get("GEOID"), str)
                or not re.fullmatch(r"[0-9]+", row["GEOID"])
            ):
                raise GeocoderError("geography lacks a literal native GEOID")
            if "NAME" in row and row["NAME"] is not None and not isinstance(row["NAME"], str):
                raise GeocoderError("geography NAME must remain a native string or null")
            for key, width in (("STATE", 2), ("COUNTY", 3), ("TRACT", 6), ("BLOCK", 4)):
                if key in row and (not isinstance(row[key], str) or not re.fullmatch(rf"[0-9]{{{width}}}", row[key])):
                    raise GeocoderError("geography code type or width differs; leading zeros must survive")
            fields = {
                "States": ("STATE",),
                "Counties": ("STATE", "COUNTY"),
                "Census Tracts": ("STATE", "COUNTY", "TRACT"),
                "Census Blocks": ("STATE", "COUNTY", "TRACT", "BLOCK"),
            }.get(layer)
            if fields and (
                any(key not in row for key in fields) or row["GEOID"] != "".join(row[key] for key in fields)
            ):
                raise GeocoderError("native GEOID differs from its geography code components")
    return value


def _territorial_ambiguity(geographies):
    return any(
        len(geographies.get(layer, [])) > 1 for layer in ("States", "Counties", "Census Tracts", "Census Blocks")
    )


def lookup_record(selection, capture):
    """Return one observed outcome; refusals never manufacture an assignment.

    All response fields, unknown extensions, nulls and original number spellings
    survive in response_json. The candidates field uses exact decimal strings
    for queryable derived values; pointers locate their native source objects.
    """
    if capture.requested_url != selection.url or capture.resolved_url != selection.url:
        raise GeocoderError("capture URL differs from the selected official request")
    if not isinstance(capture.body, bytes) or not 0 < len(capture.body) <= MAX_BYTES:
        raise GeocoderError("lookup requires complete response bytes within the source bound")
    record = {
        "selection": asdict(selection),
        "capture": descriptor(capture),
        "response_json": capture.body.decode("utf-8"),
        "outcome": "refused",
        "reason": None,
        "candidates": [],
    }
    if capture.status_code != 200:
        record["reason"] = "http_status_" + str(capture.status_code)
        return record
    try:
        if capture.content_type.split(";")[0].strip().lower() != "application/json":
            raise GeocoderError("response media type differs from supported JSON")
        data = load_bounded_json(
            capture.body,
            source="Census geocoder",
            error_type=GeocoderError,
            number_policy="decimal",
            max_bytes=MAX_BYTES,
        )
        if not isinstance(data, dict) or not isinstance(data.get("result"), dict):
            raise GeocoderError("response lacks the supported result object")
        result = data["result"]
        original = result.get("input")
        if not isinstance(original, dict):
            raise GeocoderError("response lacks echoed input")
        _identity(original.get("benchmark"), selection.benchmark, "benchmark")
        _identity(original.get("vintage"), selection.vintage, "vintage")
        ambiguous = False
        if selection.kind == "onelineaddress":
            if original.get("address") != {"address": selection.address}:
                raise GeocoderError("echoed address differs from original input")
            matches = result.get("addressMatches")
            if not isinstance(matches, list) or len(matches) > 100:
                raise GeocoderError("response lacks a bounded addressMatches array")
            if not matches:
                record["outcome"] = "unmatched"
                return record
            candidates = []
            for index, match in enumerate(matches):
                if (
                    not isinstance(match, dict)
                    or not isinstance(match.get("matchedAddress"), str)
                    or not match["matchedAddress"].strip()
                ):
                    raise GeocoderError("address candidate lacks matchedAddress")
                coords = match.get("coordinates")
                if not isinstance(coords, dict):
                    raise GeocoderError("address candidate lacks coordinates")
                try:
                    x, y = (_source_coordinate(coords.get(k), bound) for k, bound in (("x", 180), ("y", 90)))
                except GeocoderError as error:
                    record.update(outcome="conversion_failed", reason=str(error))
                    return record
                geographies = _geographies(match.get("geographies"))
                ambiguous |= _territorial_ambiguity(geographies)
                if not any(geographies.values()):
                    raise GeocoderError("address candidate has no geography assignment")
                candidates.append(
                    {
                        "pointer": f"/result/addressMatches/{index}",
                        "matched_address": match["matchedAddress"],
                        "x": x,
                        "y": y,
                    }
                )
        else:
            coords = original.get("location")
            if not isinstance(coords, dict):
                raise GeocoderError("coordinate response lacks echoed location")
            for key in ("x", "y"):
                actual = coords.get(key)
                if (
                    isinstance(actual, bool)
                    or not isinstance(actual, (int, Decimal))
                    or actual != Decimal(getattr(selection, key))
                ):
                    raise GeocoderError("echoed coordinate differs from exact original input")
            geographies = _geographies(result.get("geographies"))
            ambiguous |= _territorial_ambiguity(geographies)
            if not any(geographies.values()):
                record["outcome"] = "unmatched"
                return record
            candidates = [{"pointer": "/result", "matched_address": None, "x": selection.x, "y": selection.y}]
        record.update(outcome="ambiguous" if len(candidates) > 1 or ambiguous else "matched", candidates=candidates)
    except GeocoderError as error:
        record["reason"] = str(error)
    return record


def _source_coordinate(value, bound):
    if isinstance(value, bool) or not isinstance(value, (int, Decimal)):
        raise GeocoderError("source coordinate is not a native JSON number")
    text = str(value)
    # Decimal exponent notation remains exact; conversion does not use float.
    if isinstance(value, Decimal) and not value.is_finite():
        raise GeocoderError("source coordinate is not finite")
    if (value.copy_abs() if isinstance(value, Decimal) else abs(value)) > bound:
        raise GeocoderError("source coordinate is outside longitude/latitude bounds")
    return text


class GeocoderAcquirer(SourceAcquirer):
    """One keyless geography request; transport/refusal evidence is retained first."""

    def __init__(self, *, transport=None, clock=utc_now):
        super().__init__(
            max_requests=1,
            timeout_seconds=30,
            min_request_interval_seconds=0.2,
            user_agent="spicy-docs-census-geocoder/1",
            label="Census geocoder",
            error_type=GeocoderError,
            context_key="census_geocoder_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def acquire(self, selection, *, retain):
        try:
            record, capture = self.capture_validated(
                selection.url,
                media_types=("application/json",),
                max_bytes=MAX_BYTES,
                parse=lambda c, limit: lookup_record(selection, c),
                unavailable=lambda c: GeocoderError("selected geocoder resource unavailable"),
                context={"selection": asdict(selection)},
                max_attempts=1,
            )
        except Exception as error:
            capture = attached_capture(error)
            if capture is not None:
                retain(capture)
            raise
        retain(capture)
        return record, capture


def selection_id(selection):
    return hashlib.sha256(selection.url.encode()).hexdigest()
