"""SAM's public file service and literal opportunities/exclusions CSV observations.

These keyless public files are independent of the SAM entity API. The caller
retains originals and chooses scope. A listed link is not a captured file.
CSV rows remain observations: notice amendments and repeated exclusion IDs are
never collapsed. Empty strings stay empty; CSV supplies no native NULL token.
"""

from __future__ import annotations

import csv
import io
import re
from datetime import date, timedelta
from urllib.parse import parse_qs, quote, urlencode, urlsplit
from zipfile import ZipFile

from spicy_docs.reading.zip_archive import inspect_archive_stream, seekable_stream

BASE = "https://sam.gov/api/prod/fileextractservices/v1/api/"
NOTICE_FILE = "ContractOpportunitiesFullCSV.csv"
MAX_ZIP_BYTES = 64 * 1024**2
MAX_CSV_BYTES = 512 * 1024**2
MAX_ROWS = 1_000_000
DOMAINS = {"exclusions": "Exclusions/Public V2", "opportunities": "Contract Opportunities/datagov"}
REQUIRED = {
    "exclusions": {
        "Classification",
        "Name",
        "Unique Entity ID",
        "Exclusion Program",
        "Excluding Agency",
        "Exclusion Type",
        "Additional Comments",
        "Active Date",
        "Termination Date",
        "SAM Number",
    },
    "opportunities": {
        "NoticeId",
        "Title",
        "Sol#",
        "Department/Ind.Agency",
        "CGAC",
        "Office",
        "PostedDate",
        "Type",
        "ResponseDeadLine",
        "NaicsCode",
        "ClassificationCode",
        "Active",
        "Link",
    },
}


class SamPublicError(ValueError):
    """The selected public original cannot establish the declared observations."""


def file_date(filename):
    """An exclusions filename states a Julian day, independently of capture time."""
    match = re.fullmatch(r"SAM_Exclusions_Public_Extract_V2_([0-9]{5})\.(?:ZIP|CSV)", filename, re.IGNORECASE)
    if not match:
        raise SamPublicError("Unsupported SAM public exclusions filename")
    token = match[1]
    value = date(2000 + int(token[:2]), 1, 1) + timedelta(days=int(token[2:]) - 1)
    if value.strftime("%y%j") != token:
        raise SamPublicError("SAM filename has an invalid Julian day")
    return value.isoformat()


def download_url(kind, filename):
    if kind == "exclusions":
        file_date(filename)
        if not filename.lower().endswith(".zip"):
            raise SamPublicError("Exclusions download requires a ZIP")
    elif kind != "opportunities" or filename != NOTICE_FILE:
        raise SamPublicError("Unsupported SAM public file")
    return BASE + "download/" + quote(DOMAINS[kind], safe="/") + "/" + quote(filename) + "?privacy=Public"


def validate_public_url(url):
    """Allow the public SAM route and its exact public S3 destinations only.

    SAM returns a GET-presigned redirect. The query is a temporary credential,
    never a durable locator; the evidence transport scrubs it.
    """
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.username or parts.password or parts.fragment or parts.port not in (None, 443):
        raise SamPublicError("SAM public URL must be HTTPS without user information")
    paths = (
        "/Exclusions/Public%20V2/SAM_Exclusions_Public_Extract_V2_",
        "/Contract%20Opportunities/datagov/ContractOpportunitiesFullCSV.csv",
    )
    if parts.hostname == "sam.gov" and parts.path.startswith("/api/prod/fileextractservices/v1/api/"):
        if parse_qs(parts.query).get("privacy") != ["Public"]:
            raise SamPublicError("SAM file request must explicitly select Public")
        if parts.path == "/api/prod/fileextractservices/v1/api/listfiles":
            if parse_qs(parts.query).get("domain") not in [[value] for value in DOMAINS.values()]:
                raise SamPublicError("SAM listing domain differs")
            return url
        path = parts.path.removeprefix("/api/prod/fileextractservices/v1/api/download")
    elif parts.hostname == "falextracts.s3.amazonaws.com":
        path = parts.path
    elif parts.hostname == "s3.amazonaws.com" and parts.path.startswith("/falextracts/"):
        path = parts.path.removeprefix("/falextracts")
    else:
        raise SamPublicError("SAM public URL host or route differs")
    if path == paths[1] or re.fullmatch(re.escape(paths[0]) + r"[0-9]{5}\.ZIP", path):
        return url
    raise SamPublicError("SAM public file path differs")


def listing_url(kind):
    if kind not in DOMAINS:
        raise SamPublicError("Unsupported SAM listing domain")
    return BASE + "listfiles?" + urlencode({"domain": DOMAINS[kind], "privacy": "Public"})


def exclusions_listing(payload):
    """Read the actual public listing shape; an unknown shape refuses."""
    rows = payload.get("_embedded", {}).get("customS3ObjectSummaryList") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise SamPublicError("SAM public listing shape differs")
    result = []
    for row in rows:
        if not isinstance(row, dict) or row.get("privacy") != "Public":
            raise SamPublicError("SAM listing includes a non-public or malformed entry")
        name = row.get("displayKey")
        result.append(
            {"filename": name, "snapshot_date": file_date(name), "url": download_url("exclusions", name), "raw": row}
        )
    if len({row["filename"] for row in result}) != len(result):
        raise SamPublicError("SAM public listing repeats a filename")
    return sorted(result, key=lambda row: row["snapshot_date"])


def csv_records(stream, *, kind, max_rows=MAX_ROWS, encoding="utf-8-sig"):
    """Stream literal cells and physical line ranges; never guess or repair text.

    The caller supplies a pinned, byte-bounded stream. Only explicit encoding is
    used; undecodable bytes and overlong fields refuse. The stdlib field bound
    remains in force, rather than changing process-global CSV settings.
    """
    if kind not in REQUIRED or type(max_rows) is not int or not 0 < max_rows <= MAX_ROWS:
        raise SamPublicError("Unsupported SAM CSV kind or row bound")
    text = io.TextIOWrapper(stream, encoding=encoding, newline="", errors="strict")
    try:
        rows = csv.reader(text, strict=True)
        header = next(rows, None)
        if (
            not header
            or len(header) != len(set(header))
            or any(not name for name in header)
            or not REQUIRED[kind] <= set(header)
        ):
            raise SamPublicError("SAM CSV required columns are missing or duplicated")
        previous_line = rows.line_num
        for ordinal, cells in enumerate(rows):
            first_line = previous_line + 1
            previous_line = rows.line_num
            if len(cells) != len(header):
                raise SamPublicError("SAM CSV row width differs from its header")
            if ordinal >= max_rows:
                raise SamPublicError("SAM CSV exceeds max_rows")
            fields = dict(zip(header, cells, strict=True))
            identity = fields["SAM Number" if kind == "exclusions" else "NoticeId"]
            if not identity.strip():
                raise SamPublicError("SAM CSV native record identity is blank")
            yield {
                "native_id": identity,
                "ordinal": ordinal,
                "line_start": first_line,
                "line_end": rows.line_num,
                "fields": fields,
            }
    except (csv.Error, UnicodeError) as error:
        raise SamPublicError("SAM CSV is malformed or not in the selected encoding") from error
    finally:
        text.detach()


def exclusion_records(stream, *, filename, byte_size, max_rows=MAX_ROWS):
    """Check ZIP integrity/bounds, then read its one exact dated CSV in batches."""
    snapshot = file_date(filename)
    if not filename.lower().endswith(".zip") or type(byte_size) is not int or not 0 < byte_size <= MAX_ZIP_BYTES:
        raise SamPublicError("SAM exclusions original exceeds its ZIP bound or has the wrong filename")
    expected = filename[:-4] + ".CSV"
    with seekable_stream(stream, byte_size=byte_size) as original:
        inventory = inspect_archive_stream(
            original, byte_size=byte_size, max_entries=1, max_decoded_bytes=MAX_CSV_BYTES, max_metadata_bytes=128 * 1024
        )
        members = inventory["members"]
        if len(members) != 1 or members[0]["name"] != expected or members[0]["isDirectory"]:
            raise SamPublicError("SAM exclusions ZIP member differs from its dated filename")
        member = members[0]
        with ZipFile(original) as archive, archive.open(archive.infolist()[member["ordinal"]]) as decoded:
            for row in csv_records(decoded, kind="exclusions", max_rows=max_rows):
                yield {**row, "snapshot_date": snapshot, "member_name": expected, "member_sha256": member["sha256"]}
