"""Publisher-stated budget workbook and CSV files, with positional source cells."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from io import StringIO
from pathlib import PurePosixPath
from urllib.parse import urlsplit

from spicy_docs.sources.govinfo.bodies import GovInfoBodySourceError, parse_granule_identity, parse_package_id
from spicy_docs.sources.govinfo.mods import ModsRecord
from spicy_docs.sources.govinfo.preservation import GovInfoPreservation
from spicy_docs.sources.scorecards.common import ScorecardSourceError
from spicy_docs.sources.scorecards.workbooks import WorkbookSheet, literal_worksheets
from spicy_docs.transport.captured import CapturedBodyResponse

_NATIVE_SUFFIXES = {".csv", ".xlsx", ".xls"}


@dataclass(frozen=True, slots=True)
class BudgetTableOffer:
    package_id: str
    granule_id: str | None
    title: str | None
    format: str
    url: str
    metadata_sha256: str
    element_path: tuple[int, ...]

    def __post_init__(self) -> None:
        package = parse_package_id(self.package_id)
        if package.collection != "BUDGET":
            raise GovInfoBodySourceError("Native budget file requires a BUDGET package")
        if self.granule_id is not None:
            parse_granule_identity(package, self.granule_id)
        url = urlsplit(self.url)
        path = PurePosixPath(url.path)
        suffix = path.suffix.lower()
        if (
            url.scheme != "https"
            or url.netloc != "www.govinfo.gov"
            or url.query
            or url.fragment
            or not re.fullmatch(r"/[A-Za-z0-9._/-]+", url.path)
            or {".", "..", ""}.intersection(url.path[1:].split("/"))
            or path.parts[:4] != ("/", "content", "pkg", package.package_id)
            or suffix not in _NATIVE_SUFFIXES
            or suffix != f".{self.format}"
        ):
            raise GovInfoBodySourceError("Native budget file URL is outside its stated package")


def budget_table_offers(observation: GovInfoPreservation) -> tuple[BudgetTableOffer, ...]:
    """Package-root and constituent links as stated by validated MODS, in source order.

    Granule membership comes from the record itself. A package can offer a
    workbook even when the separate granule listing is observed empty.
    """
    mods = observation.mods
    if observation.identity.collection != "BUDGET" or mods is None:
        raise GovInfoBodySourceError("Native budget offers require complete budget MODS")
    package = observation.identity.package_id
    offers = []

    def add(record: ModsRecord, *, constituent: bool = False) -> None:
        title = next((el.text for el in record.fields("titleInfo", "title")), None)
        for element in record.urls:
            url = element.text
            suffix = PurePosixPath(urlsplit(url).path).suffix.lower()
            if element.attribute("access") == "raw object" and suffix in _NATIVE_SUFFIXES:
                granule_id = None
                if constituent:
                    ids = set(record.access_ids)
                    if len(ids) != 1:
                        raise GovInfoBodySourceError("Native budget offer has an ambiguous MODS constituent identity")
                    (granule_id,) = ids
                offers.append(
                    BudgetTableOffer(package, granule_id, title, suffix[1:], url, mods.source_sha256, element.path)
                )

    add(mods.package)
    for record in mods.constituents:
        add(record, constituent=True)
    return tuple(offers)


def read_budget_table(
    offer: BudgetTableOffer,
    capture: CapturedBodyResponse,
    *,
    sheets: tuple[str, ...] = (),
    max_rows: int = 5000,
    max_cells: int = 100_000,
    max_bytes: int = 16 * 1024**2,
) -> dict[str, WorkbookSheet] | tuple[tuple[str, ...], ...]:
    """Read explicitly selected worksheets or ordered CSV rows from an offered file.

    Workbook locations, blanks, cached values and formats remain literal.
    CSV row width and empty fields stay as written. No headers are promoted
    and no amount is assigned a financial meaning.
    """
    if any(type(value) is not int or value <= 0 for value in (max_rows, max_cells, max_bytes)):
        raise ValueError("Native budget table bounds must be positive integers")
    if (
        capture.requested_url != offer.url
        or capture.resolved_url != offer.url
        or capture.status_code != 200
        or capture.method != "GET"
        or capture.content_encoding != "identity"
        or capture.request_body is not None
        or not 0 < capture.byte_size <= max_bytes
    ):
        raise GovInfoBodySourceError("Native budget file capture differs from the offered file or byte bound")
    if offer.format == "xlsx":
        try:
            return literal_worksheets(capture.body, sheet_names=sheets, max_rows=max_rows, max_cells=max_cells)
        except ScorecardSourceError as error:
            raise GovInfoBodySourceError(f"Native budget workbook is unreadable: {error}") from error
    if offer.format != "csv":
        raise GovInfoBodySourceError("Legacy binary XLS is advertised but has no qualified literal reader")
    if sheets:
        raise ValueError("CSV does not have workbook sheets")
    try:
        text = capture.body.decode("utf-8-sig")
        if "\x00" in text or text.lstrip().startswith("<"):
            raise GovInfoBodySourceError("Native budget CSV contains non-CSV response content")
        rows = []
        cells = 0
        for row in csv.reader(StringIO(text, newline=""), strict=True):
            cells += len(row)
            if len(rows) >= max_rows or cells > max_cells:
                raise GovInfoBodySourceError("Native budget CSV exceeds selected row or cell bound")
            rows.append(tuple(row))
        return tuple(rows)
    except (UnicodeError, csv.Error) as error:
        raise GovInfoBodySourceError("Native budget CSV is unreadable") from error
