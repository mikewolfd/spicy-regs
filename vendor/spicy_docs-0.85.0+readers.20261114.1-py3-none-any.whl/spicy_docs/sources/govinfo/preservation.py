"""Package preservation observations and exact historical-file comparison."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Literal
from urllib.parse import urlsplit

from spicy_docs.releases.format import MAX_EVIDENCE_BYTES
from spicy_docs.sources.govinfo.bodies import (
    GovInfoBodySourceError,
    PackageIdentity,
    PackageModsIdentity,
    PackageSummary,
    package_mods_locator,
    package_summary_locator,
    parse_package_id,
    read_package_mods,
    validate_package_summary,
)
from spicy_docs.sources.govinfo.mods import GovInfoModsPackage
from spicy_docs.sources.govinfo.premis import GovInfoPremisRead, compare_govinfo_premis, read_govinfo_premis
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import check_byte_bound

PRESERVATION_COLLECTIONS = frozenset({"CRPT", "CHRG", "BUDGET"})
_INSTANT = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2})")
_SHA256 = re.compile(r"sha256:[0-9a-f]{64}")
_CONTENT_PATH = re.compile(r"/content/pkg/([^/]+)/[A-Za-z0-9._/-]+")


def package_premis_locator(package_id: str) -> str:
    """The keyed package PREMIS endpoint."""
    return package_summary_locator(package_id).removesuffix("/summary") + "/premis"


def _instant(value: str) -> datetime:
    if not isinstance(value, str) or _INSTANT.fullmatch(value) is None:
        raise GovInfoBodySourceError("GovInfo preservation observation requires an explicit timestamp and timezone")
    try:
        return datetime.fromisoformat(value)
    except ValueError as error:
        raise GovInfoBodySourceError("GovInfo preservation observation has an invalid timestamp") from error


def _check(capture: CapturedBodyResponse, locator: str) -> datetime:
    if (
        capture.requested_url != locator
        or capture.resolved_url != locator
        or capture.method != "GET"
        or capture.content_encoding != "identity"
        or capture.request_body is not None
    ):
        raise GovInfoBodySourceError("GovInfo preservation capture differs from its requested resource")
    return _instant(capture.observed_at)


@dataclass(frozen=True, slots=True)
class GovInfoPreservation:
    """One observed group of metadata responses, with their original captures."""

    identity: PackageIdentity
    summary: PackageSummary | None
    mods_identity: PackageModsIdentity | None
    mods: GovInfoModsPackage | None
    premis: GovInfoPremisRead | None
    bracket: Literal["stable-summary", "summary-changed", "summary-unavailable", "unbracketed"]
    summary_capture: CapturedBodyResponse | None
    mods_capture: CapturedBodyResponse | None
    premis_capture: CapturedBodyResponse | None
    closing_summary_capture: CapturedBodyResponse | None

    @property
    def last_modified(self) -> str | None:
        """The opening SUMMARY's usable publisher revision time, when stated."""
        value = self.summary.last_modified if self.summary else None
        if value is None:
            return None
        try:
            _instant(value)
        except GovInfoBodySourceError:
            return None
        return value

    def historical_metadata(self, *, summary_sha256: str, mods_sha256: str) -> str:
        """Classify a fresh observation against the selected historical metadata bytes."""
        if any(not isinstance(pin, str) or not _SHA256.fullmatch(pin) for pin in (summary_sha256, mods_sha256)):
            raise ValueError("Historical GovInfo metadata requires both prefixed SHA-256 digests")
        if self.bracket != "stable-summary" or self.last_modified is None or not self.summary_capture or not self.mods:
            return "unproved"
        if self.summary_capture.sha256 == summary_sha256 and self.mods.source_sha256 == mods_sha256:
            return "exact-metadata-refetch"
        return "current-only"

    def compare_file(self, capture: CapturedBodyResponse) -> dict:
        """Compare one retained file without extracting its contents."""
        url = urlsplit(capture.requested_url)
        path = _CONTENT_PATH.fullmatch(url.path)
        if (
            url.scheme != "https"
            or url.netloc != "www.govinfo.gov"
            or url.query
            or url.fragment
            or not path
            or path[1] != self.identity.package_id
            or {"..", ".", ""}.intersection(url.path[1:].split("/"))
        ):
            raise GovInfoBodySourceError("GovInfo preservation file URL is outside its requested package")
        _check(capture, capture.requested_url)
        if self.premis is None:
            return {"status": "unavailable", "reason": "premis-unavailable"}
        return asdict(compare_govinfo_premis(capture, self.premis))

    def brackets(self, capture: CapturedBodyResponse) -> bool:
        """Whether a separate capture fell within the unchanged SUMMARY observations."""
        observed_at = _instant(capture.observed_at)
        return (
            self.bracket == "stable-summary"
            and self.summary_capture is not None
            and self.closing_summary_capture is not None
            and _instant(self.summary_capture.observed_at)
            <= observed_at
            <= _instant(self.closing_summary_capture.observed_at)
        )


def read_package_preservation(
    package_id: str,
    *,
    summary: CapturedBodyResponse | None,
    mods: CapturedBodyResponse | None,
    premis: CapturedBodyResponse | None,
    closing_summary: CapturedBodyResponse | None = None,
    max_metadata_bytes: int = 4 * 1024**2,
) -> GovInfoPreservation:
    """Read complete metadata for one CRPT, CHRG or BUDGET observation.

    A stable byte-exact SUMMARY bracket only rules out an observed SUMMARY
    change. It does not make these separate requests an atomic snapshot.
    Missing responses stay missing. Unreadable successful responses refuse.
    """
    check_byte_bound(max_metadata_bytes, "max_metadata_bytes", MAX_EVIDENCE_BYTES)
    identity = parse_package_id(package_id)
    if identity.collection not in PRESERVATION_COLLECTIONS:
        raise GovInfoBodySourceError("Preservation requires a CRPT, CHRG or BUDGET package")
    captures = (summary, mods, premis, closing_summary)
    summary_url = package_summary_locator(identity)
    locators = (summary_url, package_mods_locator(identity), package_premis_locator(package_id), summary_url)
    observed = []
    for capture, locator in zip(captures, locators, strict=True):
        if capture is None:
            continue
        observed.append(_check(capture, locator))
        if capture.byte_size > max_metadata_bytes:
            raise GovInfoBodySourceError("GovInfo preservation response exceeds metadata byte bound")
    if observed != sorted(observed):
        raise GovInfoBodySourceError("GovInfo preservation observations are out of request order")

    def read_summary(capture: CapturedBodyResponse | None) -> PackageSummary | None:
        if capture is None or capture.status_code != 200:
            return None
        return validate_package_summary(
            capture.body, package=identity, final_url=capture.resolved_url, max_bytes=max_metadata_bytes
        )

    first = read_summary(summary)
    last = read_summary(closing_summary)
    bracket = (
        "summary-unavailable" if first is None or (closing_summary is not None and last is None) else "unbracketed"
    )
    if first is not None and last is not None and summary is not None and closing_summary is not None:
        bracket = "stable-summary" if summary.sha256 == closing_summary.sha256 else "summary-changed"
    checked_mods, full_mods = (
        read_package_mods(mods.body, package=identity, final_url=mods.resolved_url, max_bytes=max_metadata_bytes)
        if mods is not None and mods.status_code == 200
        else (None, None)
    )
    full_premis = (
        read_govinfo_premis(premis.body, max_bytes=max_metadata_bytes)
        if premis is not None and premis.status_code == 200
        else None
    )
    return GovInfoPreservation(identity, first, checked_mods, full_mods, full_premis, bracket, *captures)
