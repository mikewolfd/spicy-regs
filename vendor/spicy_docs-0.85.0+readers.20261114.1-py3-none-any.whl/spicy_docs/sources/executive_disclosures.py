"""Selected publicly posted OGE filings and a bounded ruled Form 278e Part 6 reader.

Only archive-posted PDFs are acquired here. Form 201, agency requests and identity
attestations remain human access steps. Layout parsing reuses PyMuPDF's table
reader, already supported by spicy-docs[pdf]; it performs no OCR or profile joins.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

from spicy_docs.reading.pdf_bytes import check_pdf_bytes
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_final_url

if TYPE_CHECKING:
    import httpx

    from spicy_docs.transport.captured import CapturedBodyResponse

PARSER_REVISION = "oge-278e-ruled-part6/2"
MAX_BYTES = 8 * 1024**2
MAX_PAGES = 64
SECTION = "Part 6: Other Assets and Income"
HEADER = ("#", "Description", "EIF", "Value", "Income Type", "Income Amount")
FIELDS = ("row_number_raw", "description_raw", "eif_raw", "value_raw", "income_type_raw", "income_amount_raw")


class ExecutiveDisclosureError(ValueError):
    """The selected response does not prove the requested filing or section."""


class UnsupportedDisclosure(ExecutiveDisclosureError):
    """The format, section or amendment needs separate qualification."""


class DisclosureUnavailable(ExecutiveDisclosureError):
    """HTTP absence at this locator, never proof that the report does not exist."""

    def __init__(self, capture: CapturedBodyResponse):
        super().__init__(f"public filing locator answered HTTP {capture.status_code}")
        self.capture = capture


def public_filing_url(url: str) -> str:
    """Allow the qualified public archive route; never reach an attestation form."""
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or parsed.netloc != "bidenwhitehouse.archives.gov"
        or parsed.query
        or parsed.fragment
        or not re.fullmatch(r"/wp-content/uploads/[0-9]{4}/[0-9]{2}/[A-Za-z0-9_.-]+\.pdf", parsed.path)
        or ".." in parsed.path
    ):
        raise ExecutiveDisclosureError("only explicit publicly posted archived White House PDFs are qualified")
    return url


class ExecutiveDisclosureAcquirer(SourceAcquirer):
    """Acquire one public PDF with a byte/request bound and no access submission."""

    def __init__(self, *, transport: httpx.BaseTransport | None = None):
        super().__init__(
            max_requests=1,
            timeout_seconds=30,
            min_request_interval_seconds=0.3,
            user_agent="spicy-docs-public-executive-disclosures/1.0",
            label="public executive filing",
            error_type=ExecutiveDisclosureError,
            context_key="executive_disclosure_acquisition",
            transport=transport,
            keyless=True,
        )

    def acquire_pdf(self, url: str) -> CapturedBodyResponse:
        url = public_filing_url(url)

        def parse(capture, _limit):
            check_final_url(
                capture.resolved_url,
                url,
                error_type=ExecutiveDisclosureError,
                message="public filing response left its selected URL",
            )
            return check_pdf_bytes(capture.body, error_type=ExecutiveDisclosureError, label="public OGE filing")

        _, capture = self.capture_validated(
            url,
            media_types=("application/pdf", "application/octet-stream"),
            parse=parse,
            max_bytes=MAX_BYTES,
            unavailable=DisclosureUnavailable,
            context={"operation": "public-posted-pdf", "url": url},
            max_attempts=1,
        )
        return capture


@dataclass(frozen=True)
class Part6Result:
    source_sha256: str
    parser_revision: str
    backend_version: str
    pages: tuple[dict, ...]
    rows: tuple[dict, ...]


def _name_spacing(value: str) -> str:
    """Ignore surrounding/repeated Unicode whitespace only; keep spelling, case and punctuation."""
    return " ".join(value.split())


def _cover_filer_identity(page) -> dict:
    """Read the labeled cover cells, in their native order, without names from surrounding text."""
    labels = ("Last Name", "First Name", "MI")
    matches = []
    for table in page.find_tables().tables:
        cells = table.extract()
        for index, row in enumerate(cells[:-1]):
            normalized = [_name_spacing(value) if isinstance(value, str) else None for value in row]
            if not all(label in normalized for label in labels):
                continue
            if any(normalized.count(label) != 1 for label in labels):
                raise ExecutiveDisclosureError("cover filer identity labels are ambiguous")
            values = cells[index + 1]
            fields = []
            for column, label in enumerate(normalized):
                if label not in labels:
                    continue
                if column >= len(values) or not isinstance(values[column], str):
                    raise ExecutiveDisclosureError("cover filer identity value is missing")
                fields.append({"label_raw": row[column], "value_raw": values[column]})
            by_label = {_name_spacing(field["label_raw"]): field["value_raw"] for field in fields}
            if not all(_name_spacing(by_label[label]) for label in ("First Name", "Last Name")):
                raise ExecutiveDisclosureError("cover filer identity value is empty")
            matches.append(
                {
                    "page": 1,
                    "fields": fields,
                    "name": " ".join(
                        _name_spacing(by_label[label])
                        for label in ("First Name", "MI", "Last Name")
                        if _name_spacing(by_label[label])
                    ),
                }
            )
    if len(matches) != 1:
        raise ExecutiveDisclosureError("cover filer identity labels are missing or ambiguous")
    return matches[0]


def _section_filer_identity(table, cells: list, header: int, page: int) -> dict:
    """Read the value immediately below the native Filer's Name label in the qualified table."""
    labels = [
        index
        for index, row in enumerate(cells[:header])
        if row and isinstance(row[0], str) and _name_spacing(row[0]) == "Filer's Name"
    ]
    if len(labels) != 1 or labels[0] + 1 >= header:
        raise ExecutiveDisclosureError("Part 6 Filer's Name field is missing or ambiguous")
    index = labels[0]
    value = cells[index + 1][0]
    if not isinstance(value, str) or not _name_spacing(value):
        raise ExecutiveDisclosureError("Part 6 Filer's Name value is missing or empty")
    return {
        "page": page,
        "label_raw": cells[index][0],
        "value_raw": value,
        "label_bbox": table.rows[index].cells[0],
        "value_bbox": table.rows[index + 1].cells[0],
    }


def read_part6(body: bytes, *, filer_name: str, report_year: int, section: str = SECTION) -> Part6Result:
    """Read all ruled Part 6 pages, keeping empty slots and raw cells separate.

    Qualified format: Nov. 2021 Form 278e annual reports with readable identity,
    report year and a complete ruled Part 6. Other forms, unreadable cover pages,
    amendments and changed table shapes refuse. Page text retains footnotes;
    these are literal observations, not reconciled interpretations of footnotes.
    """
    if section != SECTION:
        raise UnsupportedDisclosure("only Form 278e Part 6 is qualified; other sections and 278-T are unsupported")
    if not isinstance(body, bytes) or not body or len(body) > MAX_BYTES:
        raise ExecutiveDisclosureError("filing must be nonempty PDF bytes within the selected byte bound")
    if not isinstance(filer_name, str) or not filer_name.strip() or type(report_year) is not int:
        raise ExecutiveDisclosureError("select an explicit filer name and native annual report year")
    check_pdf_bytes(body, error_type=ExecutiveDisclosureError, label="public OGE filing")
    import pymupdf

    rows, pages = [], []
    with pymupdf.open(stream=body, filetype="pdf") as document:
        if document.is_encrypted or not 1 <= len(document) <= MAX_PAGES:
            raise UnsupportedDisclosure("encrypted or over-budget filing")
        texts = [page.get_text() for page in document]
        if any(re.search(r"\b(amendment|amended|correction to part)\b", text, re.IGNORECASE) for text in texts):
            raise UnsupportedDisclosure("amendment requires explicit source review and reconciliation before facts")
        cover = " ".join(texts[0].split())
        if not re.search(r"Report Type:\s*Annual\b", cover):
            raise UnsupportedDisclosure("readable annual Form 278e cover required; scanned/other forms unsupported")
        year = re.search(r"Year \(Annual Report only\):\s*([0-9]{4})\b", cover)
        if year is None or int(year[1]) != report_year:
            raise ExecutiveDisclosureError("native report year differs from selection; filename year is not a period")
        cover_identity = _cover_filer_identity(document[0])
        for number, (page, text) in enumerate(zip(document, texts, strict=True), 1):
            if SECTION not in text:
                continue
            if "OGE Form 278e (Updated Nov. 2021)" not in text:
                raise UnsupportedDisclosure("Part 6 form revision differs from selection")
            found = page.find_tables().tables
            matches = []
            for table in found:
                cells = table.extract()
                headers = [i for i, row in enumerate(cells) if tuple(row[:6]) == HEADER]
                if headers:
                    if len(headers) != 1:
                        raise UnsupportedDisclosure("ambiguous Part 6 table header")
                    matches.append((table, cells, headers[0]))
            if len(matches) != 1:
                raise UnsupportedDisclosure("complete ruled Part 6 table required; no inferred columns")
            table, cells, header = matches[0]
            section_identity = _section_filer_identity(table, cells, header, number)
            native_name = _name_spacing(section_identity["value_raw"])
            if native_name != cover_identity["name"]:
                raise ExecutiveDisclosureError(
                    f"cover/Part 6 filer identity differs: cover name={cover_identity['name']!r}; "
                    f"native Filer's Name={section_identity['value_raw']!r}"
                )
            if native_name != _name_spacing(filer_name):
                raise ExecutiveDisclosureError(
                    f"Part 6 filer identity differs from selection: declared={filer_name!r}; "
                    f"native Filer's Name={section_identity['value_raw']!r}"
                )
            identity_json = json.dumps(
                {
                    "section": section_identity,
                    "cover": cover_identity,
                    "comparison_rule": "whitespace-only; cover order First Name MI Last Name",
                },
                ensure_ascii=False,
            )
            page_rows = cells[header + 1 :]
            if not page_rows:
                raise UnsupportedDisclosure("Part 6 table has no source slots")
            for offset, raw in enumerate(page_rows, header + 1):
                if len(raw) < 6 or any(value is not None for value in raw[6:]):
                    raise UnsupportedDisclosure("unclassified Part 6 columns")
                if any(not isinstance(cell, str) for cell in raw[:6]):
                    raise UnsupportedDisclosure("merged or missing Part 6 cells require review")
                if not re.fullmatch(r"[1-9][0-9]*(?:\.[0-9]+)?\.?", raw[0]):
                    raise UnsupportedDisclosure("unrecognized Part 6 row label")
                record = dict(zip(FIELDS, raw[:6], strict=True))
                record.update(
                    page=number,
                    source_locator=f"#page={number}",
                    blank_slot=all(cell == "" for cell in raw[1:6]),
                    raw_cells_json=json.dumps(raw, ensure_ascii=False),
                    cell_boxes_json=json.dumps(table.rows[offset].cells),
                )
                rows.append(record)
            pages.append(
                {
                    "page": number,
                    "page_text": text,
                    "filer_identity_json": identity_json,
                    "source_locator": f"#page={number}",
                    "table_bbox_json": json.dumps(table.bbox),
                    "source_slot_count": len(page_rows),
                }
            )
        if not pages:
            raise UnsupportedDisclosure("no readable qualified Part 6; absence is not an empty disclosure")
    labels = [row["row_number_raw"].rstrip(".") for row in rows]
    if len(labels) != len(set(labels)):
        raise UnsupportedDisclosure("duplicate Part 6 row labels require review")
    return Part6Result(
        "sha256:" + hashlib.sha256(body).hexdigest(), PARSER_REVISION, pymupdf.VersionBind, tuple(pages), tuple(rows)
    )
