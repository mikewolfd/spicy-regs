"""Literal ForeignAssistance.gov country-summary CSV and retained identity.

Use Python's maintained CSV reader, the shared bounded transport, and ordinary
source releases. No transaction download, country-code inference or inflation
conversion belongs here. See docs/sources/foreign-assistance.md.
"""

from __future__ import annotations

import csv
import hashlib
import io
import re
from datetime import datetime

BASE = "https://s3.amazonaws.com/files.explorer.devtechlab.com/"
SUMMARY_URL = BASE + "us_foreign_aid_country.csv"
DICTIONARY_URL = BASE + "DataDictionary_ForeignAssistancegov.pdf"
MAX_BYTES = 8 * 1024**2
MAX_ROWS = 100_000
COLUMNS = (
    "Country Code",
    "Country Name",
    "Region ID",
    "Region Name",
    "Income Group Acronym",
    "Income Group Name",
    "Transaction Type ID",
    "Transaction Type Name",
    "Fiscal Year",
    "current_amount",
    "constant_amount",
)
MEASURES = {
    "1": "Appropriated and Planned",
    "2": "Obligations",
    "3": "Disbursements",
    "18": "President's Budget Requests",
}


class ForeignAssistanceError(ValueError):
    """The selected original cannot establish the requested summary."""


def descriptor(value, *, url):
    """Require the complete original's identity, separately from its capture clock."""
    if (
        not isinstance(value, dict)
        or set(value) != {"request_url", "response_sha256", "observed_at", "byte_size"}
        or value["request_url"] != url
        or not isinstance(value["response_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", value["response_sha256"]) is None
        or type(value["byte_size"]) is not int
        or not 0 < value["byte_size"] <= MAX_BYTES
    ):
        raise ForeignAssistanceError("Foreign assistance capture identity or bound differs")
    try:
        if datetime.fromisoformat(value["observed_at"]).utcoffset() is None:
            raise ValueError
    except (TypeError, ValueError) as error:
        raise ForeignAssistanceError("Foreign assistance capture needs a timezone-aware instant") from error
    return dict(value)


def validate_scope(value):
    if not isinstance(value, dict) or set(value) != {"capture", "dictionary_capture"}:
        raise ForeignAssistanceError("Foreign assistance scope fields differ")
    return {
        "capture": descriptor(value["capture"], url=SUMMARY_URL),
        "dictionary_capture": descriptor(value["dictionary_capture"], url=DICTIONARY_URL),
    }


def summary_records(body: bytes, *, scope):
    """Read a complete bounded original; retain every cell and physical coordinate.

    A header-only file is an observed empty summary. A cut row, duplicate native
    identity, changed schema or unknown measure refuses the whole release.
    """
    scope = validate_scope(scope)
    capture = scope["capture"]
    if len(body) != capture["byte_size"] or "sha256:" + hashlib.sha256(body).hexdigest() != capture["response_sha256"]:
        raise ForeignAssistanceError("Foreign assistance original size or digest differs")
    try:
        text = body.decode("utf-8-sig", errors="strict")
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        header = next(reader)
        if tuple(header) != COLUMNS:
            raise ForeignAssistanceError("Foreign assistance country-summary header differs")
        seen, end = set(), reader.line_num
        for ordinal, cells in enumerate(reader):
            if ordinal >= MAX_ROWS or len(cells) != len(COLUMNS):
                raise ForeignAssistanceError("Foreign assistance row width or population bound differs")
            if sum(len(cell.encode("utf-8")) for cell in cells) > 8192:
                raise ForeignAssistanceError("Foreign assistance record exceeds its byte bound")
            raw = dict(zip(COLUMNS, cells, strict=True))
            if (
                not raw["Country Code"]
                or len(raw["Country Code"]) > 64
                or not raw["Country Name"]
                or not re.fullmatch(r"(?:19|20)[0-9]{2}|1976[tT][qQ]", raw["Fiscal Year"])
                or MEASURES.get(raw["Transaction Type ID"]) != raw["Transaction Type Name"]
            ):
                raise ForeignAssistanceError("Foreign assistance recipient, fiscal period or measure differs")
            identity = tuple(raw[key] for key in ("Country Code", "Country Name", "Fiscal Year", "Transaction Type ID"))
            if identity in seen:
                raise ForeignAssistanceError("Foreign assistance native identity repeats")
            seen.add(identity)
            yield {
                "ordinal": ordinal,
                "raw": raw,
                "source_locator": {
                    **capture,
                    "record_number": ordinal + 2,
                    "line_start": end + 1,
                    "line_end": reader.line_num,
                },
            }
            end = reader.line_num
    except (UnicodeDecodeError, csv.Error, StopIteration) as error:
        raise ForeignAssistanceError("Foreign assistance original is not a complete UTF-8 CSV") from error


def read_dictionary(body: bytes, capture):
    """Check the selected PDF's bytes; semantic unit rules require original review."""
    from spicy_docs.reading.pdf_bytes import check_pdf_bytes

    descriptor(capture, url=DICTIONARY_URL)
    if len(body) != capture["byte_size"] or "sha256:" + hashlib.sha256(body).hexdigest() != capture["response_sha256"]:
        raise ForeignAssistanceError("Foreign assistance dictionary size or digest differs")
    check_pdf_bytes(body, error_type=ForeignAssistanceError, label="Foreign assistance dictionary")
