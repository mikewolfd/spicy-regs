"""Capture an explicitly selected disbursement PDF through shared source transport.

The caller retains the index or library evidence that selected the URL and
its full/part role. These facts prove the requested locator and PDF byte
structure, not report semantics, digital-signature validity or period coverage.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Literal
from urllib.parse import parse_qsl, unquote, urlsplit

from spicy_docs.reading.pdf_bytes import check_pdf_bytes, linearized_length, terminal_xref_offset
from spicy_docs.sources.govinfo.bodies import GovInfoBodySourceError, parse_package_id
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_payload,
    check_request_count,
    check_timing,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

# Historical library scans are larger than born-digital reports. This is a
# per-file runaway bound; it is not a claim about publisher file sizes.
MAX_REPORT_BYTES = 128 * 1024 * 1024
PDF_MEDIA_TYPES = ("application/pdf", "application/octet-stream")
_LABEL = "Congressional disbursements report PDF"


class DisbursementsReportSourceError(ValueError):
    """The selected locator or captured PDF does not satisfy the byte checks."""


class DisbursementsReportUnavailableError(DisbursementsReportSourceError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"{_LABEL} is unavailable (HTTP {capture.status_code})")
        self.capture = capture


@dataclass(frozen=True, slots=True)
class DisbursementsReportLocator:
    url: str
    source_host: str
    chamber: Literal["house", "senate"] | None
    package_id: str | None


def disbursements_report_locator(url: str) -> DisbursementsReportLocator:
    """Validate one actual official or library-copy URL; never construct one.

    Historical library routes accept selected Internet Archive files or a
    Google Books PDF download with its book id. Their URLs do not state a
    chamber; library metadata stays with the caller's selection. An allowed
    host/path does not itself classify a PDF as a disbursements report.
    """
    if not isinstance(url, str) or any(character.isspace() or ord(character) < 32 for character in url):
        raise DisbursementsReportSourceError(f"{_LABEL} URL must be encoded")
    try:
        parts = urlsplit(url)
    except ValueError as error:
        raise DisbursementsReportSourceError(f"{_LABEL} URL is malformed") from error
    path = unquote(parts.path)
    if (
        parts.scheme != "https"
        or parts.fragment
        or any(part in {".", ".."} for part in path.split("/"))
        or "\\" in path
        or any(ord(character) < 32 for character in path)
        or not path.lower().endswith(".pdf")
    ):
        raise DisbursementsReportSourceError(f"{_LABEL} requires an exact HTTPS PDF file URL")
    if parts.netloc == "books.google.com" and re.fullmatch(r"/books/download/[^/]+\.pdf", path):
        # An ordinary browser download may supply a retained original. Admit
        # its stable book locator, never credentials or transient signed URLs.
        try:
            query = dict(parse_qsl(parts.query, keep_blank_values=True, strict_parsing=True, max_num_fields=2))
        except ValueError as error:
            raise DisbursementsReportSourceError(f"{_LABEL} has an invalid Google Books query") from error
        if (
            set(query) == {"id", "output"}
            and re.fullmatch(r"[A-Za-z0-9_-]{12}", query["id"])
            and query["output"] == "pdf"
            and "#" not in url
        ):
            return DisbursementsReportLocator(url, parts.netloc, None, None)
        raise DisbursementsReportSourceError(f"{_LABEL} requires a Google Books id and PDF output")
    if parts.query:
        raise DisbursementsReportSourceError(f"{_LABEL} requires an exact HTTPS PDF file URL")
    if parts.netloc == "www.house.gov" and path.startswith("/sites/default/files/"):
        return DisbursementsReportLocator(url, parts.netloc, "house", None)
    if parts.netloc == "www.govinfo.gov":
        match = re.fullmatch(r"/content/pkg/([^/]+)/pdf/([^/]+)\.pdf", parts.path)
        if match:
            try:
                package = parse_package_id(match[1])
            except GovInfoBodySourceError as error:
                raise DisbursementsReportSourceError(f"{_LABEL} has an invalid GovInfo package") from error
            if (
                package.collection in {"CDOC", "GPO-CDOC"}
                and package.document_type in {"hdoc", "sdoc"}
                and re.fullmatch(re.escape(package.package_id) + r"(?:-\d+)?", match[2])
            ):
                chamber = "house" if package.document_type == "hdoc" else "senate"
                return DisbursementsReportLocator(url, parts.netloc, chamber, package.package_id)
    if parts.netloc == "archive.org" and re.fullmatch(r"/download/[^/]+/[^/]+\.pdf", parts.path):
        return DisbursementsReportLocator(url, parts.netloc, None, None)
    raise DisbursementsReportSourceError(f"{_LABEL} URL is not a supported official or library file")


@dataclass(frozen=True, slots=True)
class DisbursementsReport:
    locator: DisbursementsReportLocator
    source_sha256: str
    byte_size: int
    pdf_version: str
    linearized_byte_size: int | None
    terminal_xref_offset: int
    bytes_after_linearized_revision: int


def parse_disbursements_report(body: bytes, *, url: str, max_bytes: int = MAX_REPORT_BYTES) -> DisbursementsReport:
    """Validate retained PDF bytes without inferring a period or full/part role."""
    locator = disbursements_report_locator(url)
    check_byte_bound(max_bytes, "max_bytes", MAX_REPORT_BYTES)
    check_payload(body, max_bytes=max_bytes, error_type=DisbursementsReportSourceError, label=_LABEL)
    version = check_pdf_bytes(body, error_type=DisbursementsReportSourceError, label=_LABEL)
    declared = linearized_length(body)
    if declared is not None and declared > len(body):
        raise DisbursementsReportSourceError(f"{_LABEL} is shorter than its declared linearized byte length")
    xref = terminal_xref_offset(body)
    if xref is None:
        raise DisbursementsReportSourceError(f"{_LABEL} lacks a terminal cross-reference inside its captured bytes")
    appended = len(body) - declared if declared is not None else 0
    # Original House PDFs retain /L for the earlier linearized revision, then
    # append a later revision. ISO 32000-1 G.7 explicitly permits this layout;
    # equality would falsely refuse intact signed originals. Require the old
    # EOF at its stated boundary and a final xref in the appended bytes.
    if appended and (xref < declared or re.search(rb"%%EOF\s*\Z", body[max(0, declared - 1024) : declared]) is None):
        raise DisbursementsReportSourceError(f"{_LABEL} has an unproved append after its linearized byte length")
    return DisbursementsReport(
        locator,
        "sha256:" + hashlib.sha256(body).hexdigest(),
        len(body),
        version,
        declared,
        xref,
        appended,
    )


@dataclass(frozen=True, slots=True)
class DisbursementsReportBudget:
    max_bytes: int = MAX_REPORT_BYTES
    max_requests: int = 3
    timeout_seconds: float = 90.0
    min_request_interval_seconds: float = 0.5

    def __post_init__(self) -> None:
        check_byte_bound(self.max_bytes, "max_bytes", MAX_REPORT_BYTES)
        check_request_count(self.max_requests)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


_DEFAULT_BUDGET = DisbursementsReportBudget()


class DisbursementsReportAcquirer(SourceAcquirer):
    """One bounded source capture; selection, custody and resume remain with the caller."""

    def __init__(
        self,
        *,
        budget: DisbursementsReportBudget = _DEFAULT_BUDGET,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, DisbursementsReportBudget):
            raise TypeError("budget must be a DisbursementsReportBudget")
        self.budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-disbursements-reports/1.0",
            label=_LABEL,
            error_type=DisbursementsReportSourceError,
            context_key="disbursements_report_acquisition",
            keyless=True,
            transport=transport,
            clock=clock,
        )

    def acquire_report(self, url: str) -> tuple[DisbursementsReport, CapturedBodyResponse]:
        """Fetch exactly the selected URL and retain full/part identity in caller metadata."""
        locator = disbursements_report_locator(url)

        def parse(capture: CapturedBodyResponse, limit: int) -> DisbursementsReport:
            if capture.status_code != 200:
                raise DisbursementsReportSourceError(f"{_LABEL} answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                locator.url,
                error_type=DisbursementsReportSourceError,
                message="Disbursements report final URL differs from the selected file",
            )
            return parse_disbursements_report(capture.body, url=locator.url, max_bytes=limit)

        return self.capture_validated(
            locator.url,
            media_types=PDF_MEDIA_TYPES,
            parse=parse,
            max_bytes=self.budget.max_bytes,
            unavailable=DisbursementsReportUnavailableError,
            context={"operation": "report-pdf", "url": locator.url},
        )
