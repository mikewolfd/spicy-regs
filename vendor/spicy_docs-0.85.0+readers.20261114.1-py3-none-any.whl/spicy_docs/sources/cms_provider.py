"""Literal provider CSV rows bound to the maintained CMS release resolver.

CSV has empty cells but no distinct JSON-null representation. No null or
suppression reason is inferred here; the application interprets dictionary rules.
"""

import csv
import hashlib
import re

from spicy_docs.sources.cms import PROVIDER_SERIES, CmsError, cms_selection, read_control, validate_selection

MAX_CSV_BYTES = 1024**3
MAX_LINE_BYTES = 1024**2


def provider_scope(catalog, dictionary, stats, capture, *, release_date=None):
    """Select the exact CSV distribution, with original metadata and count pins."""
    selection = cms_selection(catalog, dictionary, stats, series_title=PROVIDER_SERIES, release_date=release_date)
    value = read_control(catalog.body, "catalog", selection)
    dataset = next(d for d in value["dataset"] if d["@id"] == selection["dataset_id"])
    urls = [d.get("downloadURL") for d in dataset["distribution"] if d.get("format") == "CSV"]
    scope = {"selection": selection, "csv": dict(capture)}
    validate_scope(scope)
    if urls != [capture["request_url"]]:
        raise CmsError("CMS provider CSV differs from its selected catalog distribution")
    return scope


def validate_scope(scope):
    if not isinstance(scope, dict) or set(scope) != {"selection", "csv"}:
        raise CmsError("CMS provider scope differs")
    selection = validate_selection(scope["selection"])
    c = scope["csv"]
    if (
        selection["series_title"] != PROVIDER_SERIES
        or not isinstance(c, dict)
        or set(c) != {"request_url", "response_sha256", "byte_size", "observed_at"}
    ):
        raise CmsError("CMS provider capture differs")
    if (
        not isinstance(c["request_url"], str)
        or re.fullmatch(r"https://data\.cms\.gov/sites/default/files/[^?#]+\.csv", c["request_url"]) is None
        or not isinstance(c["response_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", c["response_sha256"]) is None
        or type(c["byte_size"]) is not int
        or not 0 < c["byte_size"] <= MAX_CSV_BYTES
    ):
        raise CmsError("CMS provider CSV identity or bounds differ")
    from datetime import datetime

    if datetime.fromisoformat(c["observed_at"]).utcoffset() is None:
        raise CmsError("CMS provider capture needs a timezone")
    return scope


def provider_records(stream, *, scope, dictionary):
    """Stream literal rows; count, header and full-body hash must pass at exhaustion.

    Callers must exhaust into an atomic destination. A failure at EOF invalidates
    the whole candidate, including rows already yielded. Memory holds one CSV row.
    """
    scope = validate_scope(scope)
    selection, capture = scope["selection"], scope["csv"]
    if "sha256:" + hashlib.sha256(dictionary).hexdigest() != selection["dictionary_sha256"]:
        raise CmsError("CMS provider dictionary bytes differ")
    fields = read_control(dictionary, "dictionary", selection)["data"]["fields"]
    digest, size = hashlib.sha256(), 0

    def lines():
        nonlocal size
        while line := stream.readline(MAX_LINE_BYTES + 1):
            size += len(line)
            if len(line) > MAX_LINE_BYTES or size > capture["byte_size"]:
                raise CmsError("CMS provider CSV exceeds its selected byte bound")
            digest.update(line)
            yield line.decode("utf-8-sig" if size == len(line) else "utf-8")

    try:
        rows = csv.reader(lines(), strict=True)
        header = next(rows, [])
        if not header or len(header) != len(set(header)) or not {f["name"] for f in fields} <= set(header):
            raise CmsError("CMS provider CSV header differs from its dictionary")
        count = 0
        for ordinal, cells in enumerate(rows):
            if len(cells) != len(header) or ordinal >= selection["total_rows"]:
                raise CmsError("CMS provider CSV row width or count differs")
            count += 1
            yield {
                "raw": dict(zip(header, cells, strict=True)),
                "selection": selection,
                "source_locator": {
                    **capture,
                    "ordinal": ordinal,
                    "csv_record": ordinal + 2,
                    "physical_line_end": rows.line_num,
                },
            }
    except (csv.Error, UnicodeError) as error:
        raise CmsError("CMS provider CSV syntax or encoding differs") from error
    if (
        count != selection["total_rows"]
        or size != capture["byte_size"]
        or "sha256:" + digest.hexdigest() != capture["response_sha256"]
    ):
        raise CmsError("CMS provider CSV population or full-body digest differs")
