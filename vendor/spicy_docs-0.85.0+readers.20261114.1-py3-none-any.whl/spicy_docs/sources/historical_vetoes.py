"""Literal Senate veto-summary cells and footnotes from one dated HTML capture.

The shared HTML reader owns decoding and original-byte coordinates. This
adapter checks the publisher's table grammar; numeric interpretation and
administration comparisons belong to the consumer.
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime

from spicy_docs.reading.html_index import HtmlIndexReader, children, descendants, literal_text

SOURCE_URL = "https://www.senate.gov/legislative/vetoes/vetoCounts.htm"
# The qualified 2026-11-13 original is 31,888 bytes. Leave headroom for navigation
# changes without accepting an unbounded page or another collection.
MAX_BYTES = 1024 * 1024


class VetoTableError(ValueError):
    """The capture does not prove the supported Senate summary-table shape."""


_HTML = HtmlIndexReader("Senate veto summary", VetoTableError, max_bytes=MAX_BYTES)


def _cell(node, body):
    return {
        "text": literal_text(node),
        "html": body[node.byte_start : node.byte_end].decode("utf-8"),
        "attributes": node.attributes,
        "locator": node.path,
        "byte_start": node.byte_start,
        "byte_end": node.byte_end,
    }


def read_veto_table(body: bytes, *, source_url: str, observed_at: str) -> dict:
    """Read one complete native table; refuse changed headers or missing notes.

    Locators are rooted at the selected ``table``, ``special_note`` or ``h1``
    elements; byte coordinates address the full original. Linked per-president
    documents are retained as links, never implied to have been acquired.
    """
    if source_url != SOURCE_URL:
        raise VetoTableError("Not the selected Senate veto-summary URL")
    instant = datetime.fromisoformat(observed_at)
    if instant.tzinfo is None or instant.utcoffset() is None:
        raise VetoTableError("Capture observation must state its timezone")
    tree = _HTML.tree(body, MAX_BYTES, scopes=frozenset({"table", "special_note", "h1"}))
    titles = [_HTML.normal(literal_text(n)) for n in descendants(tree, "h1")]
    if titles != ["Vetoes, 1789 to Present"]:
        raise VetoTableError("Senate veto-summary title is missing or changed")
    table = _HTML.only(list(descendants(tree, "table")), "summary table")
    head = _HTML.only(children(table, "thead"), "table header")
    header_rows = children(head, "tr")
    if len(header_rows) != 2 or any(children(row, "td") for row in header_rows):
        raise VetoTableError("Unsupported merged header rows")
    headers = [children(row, "th") for row in header_rows]
    if [[_HTML.normal(literal_text(c)) for c in row] for row in headers] != [
        ["President (Years)", "Coinciding Congresses", "Vetoes"],
        ["Regular", "Pocket", "Total", "Overridden"],
    ]:
        raise VetoTableError("Unsupported veto categories or header text")
    if (
        [c.attributes.get("rowspan") for c in headers[0]] != ["2", "2", None]
        or [c.attributes.get("colspan") for c in headers[0]] != [None, None, "4"]
        or any(c.attributes.get(key) not in (None, "1") for c in headers[1] for key in ("rowspan", "colspan"))
    ):
        raise VetoTableError("Unsupported merged header spans")
    notes = {}
    for node in descendants(tree, "special_note"):
        match = re.match(r"\s*(\d+)\.", literal_text(node))
        if not match or match[1] in notes:
            raise VetoTableError("Missing or duplicate footnote number")
        notes[match[1]] = _cell(node, body)

    def row(node):
        cells = children(node, "td")
        if (
            len(cells) != 6
            or children(node, "th")
            or any(c.attributes.get(key) not in (None, "1") for c in cells for key in ("rowspan", "colspan"))
        ):
            raise VetoTableError("Unsupported body row width or merged cell")
        refs = [
            a.attributes["href"][1:] for a in descendants(node, "a") if (a.attributes.get("href") or "").startswith("#")
        ]
        if any(ref not in notes for ref in refs):
            raise VetoTableError("A table footnote has no retained definition")
        return {
            "locator": node.path,
            "byte_start": node.byte_start,
            "byte_end": node.byte_end,
            "cells": [_cell(c, body) for c in cells],
            "footnote_refs": refs,
        }

    tbody = _HTML.only(children(table, "tbody"), "table body")
    rows = [row(node) for node in children(tbody, "tr")]
    if not rows:
        raise VetoTableError("An empty summary is not a zero-veto history")
    footer = _HTML.only(children(table, "tfoot"), "table total")
    total = row(_HTML.only(children(footer, "tr"), "total row"))
    return {
        "source_url": source_url,
        "source_sha256": "sha256:" + hashlib.sha256(body).hexdigest(),
        "observed_at": observed_at,
        "title": titles[0],
        "table": _cell(table, body),
        "headers": [[_cell(c, body) for c in group] for group in headers],
        "footnotes": notes,
        "rows": rows,
        "total": total,
    }
