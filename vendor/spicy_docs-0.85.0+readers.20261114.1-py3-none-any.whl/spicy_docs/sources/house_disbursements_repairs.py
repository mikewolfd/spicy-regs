"""Exact-input House CSV corrections supported by independent source review.

Like the Unified Agenda historical repair, these rules require the full original
hash, size, row bytes and position. Originals remain unchanged. An excerpt or
later revision cannot inherit a correction just because its text looks similar.
Evidence may be a signed PDF or a pattern of matching correction transactions
and recurring invoices. Agreement between CSV and PDF does not establish that
a date is correct. Receipts distinguish these evidence types and name the
supporting records. The source guide describes the retained review.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from importlib.resources import files
from typing import Literal

type EvidenceKind = Literal[
    "pdf",
    "correction-pair",
    "recurring-bill",
    "balanced-transfer",
    "recurring-period",
    "trip-context",
    "payroll-reconciliation",
    "cohort-period",
    "historical-invoice",
    "maintenance-proration",
    "external-event",
]


@dataclass(frozen=True, slots=True)
class HouseDisbursementsEvidenceRecord:
    """A supporting original record, which may belong to a different quarter."""

    source_sha256: str
    url: str
    record_number: int
    row_sha256: str


@dataclass(frozen=True, slots=True)
class HouseDisbursementsEvidenceDocument:
    """Additional source context, such as an issuer notice or office succession record."""

    url: str
    sha256: str | None
    locator: str
    reason: str


@dataclass(frozen=True, slots=True)
class HouseDisbursementsDateReview:
    """An unresolved source-qualified finding; a proposal never changes a value."""

    record_number: int
    row_sha256: str
    reason: str
    proposal: dict[str, object] | None = None


@dataclass(frozen=True, slots=True)
class HouseDisbursementsRepair:
    rule: str
    record_number: int
    byte_offset: int
    original_record: str
    corrected_record: str
    evidence_url: str
    evidence_sha256: str
    pdf_page: int | None
    printed_page: int | None
    evidence_kind: EvidenceKind
    evidence_records: tuple[HouseDisbursementsEvidenceRecord, ...]
    reason: str
    confidence: str
    supporting_documents: tuple[HouseDisbursementsEvidenceDocument, ...]
    depends_on_records: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class _Rule:
    record_number: int
    byte_offset: int
    row_sha256: str
    before: bytes
    after: bytes
    append_empty_field: bool
    evidence_url: str
    evidence_sha256: str
    pdf_page: int | None
    printed_page: int | None
    name: str
    evidence_kind: EvidenceKind = "pdf"
    evidence_records: tuple[HouseDisbursementsEvidenceRecord, ...] = ()
    reason: str = "The signed PDF shows the corrected value for the same transaction."
    confidence: str = "high"
    supporting_documents: tuple[HouseDisbursementsEvidenceDocument, ...] = ()
    depends_on_records: tuple[int, ...] = ()


def _load_repairs() -> tuple[
    dict[str, tuple[int, tuple[_Rule, ...]]], dict[str, dict[int, HouseDisbursementsDateReview]]
]:
    # Source-owned declarations ship in the wheel, as the FEC route catalog does.
    # Keeping reviewed cases in data avoids repeating repair mechanics per file.
    sources = json.loads(files("spicy_docs.sources").joinpath("house_disbursements_corrections.json").read_text())
    repairs = {
        source["source_sha256"]: (
            source["byte_size"],
            tuple(
                _Rule(
                    record_number=rule["record_number"],
                    byte_offset=rule["byte_offset"],
                    row_sha256=rule["row_sha256"],
                    before=rule["before"].encode("ascii"),
                    after=rule["after"].encode("ascii"),
                    append_empty_field=rule["append_empty_field"],
                    evidence_url=rule["evidence_url"],
                    evidence_sha256=rule["evidence_sha256"],
                    pdf_page=rule["pdf_page"],
                    printed_page=rule["printed_page"],
                    name=rule["name"],
                    evidence_kind=rule["evidence_kind"],
                    evidence_records=tuple(
                        HouseDisbursementsEvidenceRecord(**record) for record in rule["evidence_records"]
                    ),
                    reason=rule["reason"],
                    confidence=rule["confidence"],
                    supporting_documents=tuple(
                        HouseDisbursementsEvidenceDocument(**document) for document in rule["supporting_documents"]
                    ),
                    depends_on_records=tuple(rule["depends_on_records"]),
                )
                for rule in source["corrections"]
            ),
        )
        for source in sources
    }
    reviews = {
        source["source_sha256"]: {
            review["record_number"]: HouseDisbursementsDateReview(**review) for review in source.get("date_reviews", [])
        }
        for source in sources
    }
    return repairs, reviews


_REPAIRS, _DATE_REVIEWS = _load_repairs()


def reviewed_house_disbursements_dates(source_sha256: str) -> dict[int, HouseDisbursementsDateReview]:
    """Return known unresolved findings only for the exact independently reviewed original."""
    return dict(_DATE_REVIEWS.get(source_sha256, {}))


def prepare_house_disbursements_csv(
    body: bytes, *, encoding: str = "utf-8-sig"
) -> tuple[bytes, str, str, tuple[HouseDisbursementsRepair, ...]]:
    """Return readable bytes, original/parsed SHA-256 and exact correction receipts."""
    source_sha256 = "sha256:" + hashlib.sha256(body).hexdigest()
    approved = _REPAIRS.get(source_sha256)
    if approved is None:
        return body, source_sha256, source_sha256, ()
    size, rules = approved
    if len(body) != size:
        raise ValueError("House CSV correction input size differs from the approved original")
    pieces: list[bytes] = []
    receipts: list[HouseDisbursementsRepair] = []
    cursor = 0
    applied: set[int] = set()
    for rule in rules:
        if not applied.issuperset(rule.depends_on_records):
            raise ValueError("House CSV aggregate correction requires its reviewed allocation corrections first")
        # The reviewed 2019 originals use LF; later originals use CRLF.
        # The row hash includes whichever terminator the publisher supplied.
        end = body.find(b"\n", rule.byte_offset) + 1
        original = body[rule.byte_offset : end]
        if (
            rule.byte_offset < cursor
            or hashlib.sha256(original).hexdigest() != rule.row_sha256
            or original.count(rule.before) != 1
            or body.count(b"\n", 0, rule.byte_offset) + 1 != rule.record_number
        ):
            raise ValueError("House CSV correction row differs from its approved source coordinates")
        corrected = original.replace(rule.before, rule.after, 1)
        if rule.append_empty_field:
            ending = b"\r\n" if corrected.endswith(b"\r\n") else b"\n"
            corrected = corrected[: -len(ending)] + b"," + ending
        pieces.extend((body[cursor : rule.byte_offset], corrected))
        cursor = end
        receipts.append(
            HouseDisbursementsRepair(
                rule.name,
                rule.record_number,
                rule.byte_offset,
                original.decode(encoding),
                corrected.decode(encoding),
                rule.evidence_url,
                rule.evidence_sha256,
                rule.pdf_page,
                rule.printed_page,
                rule.evidence_kind,
                rule.evidence_records,
                rule.reason,
                rule.confidence,
                rule.supporting_documents,
                rule.depends_on_records,
            )
        )
        applied.add(rule.record_number)
    pieces.append(body[cursor:])
    readable = b"".join(pieces)
    return readable, source_sha256, "sha256:" + hashlib.sha256(readable).hexdigest(), tuple(receipts)
