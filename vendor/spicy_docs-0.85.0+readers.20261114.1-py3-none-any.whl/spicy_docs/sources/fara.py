"""Read selected registrations from DOJ's production FARA bulk originals.

The publisher supplies no foreign-principal entity ID in this export. Record
coordinates identify observations, never an inferred principal identity.
"""

from __future__ import annotations

import csv
import hashlib
import io
import re
from datetime import datetime
from urllib.parse import urlsplit

from spicy_docs.reading.xml import scan_xml
from spicy_docs.reading.zip_archive import open_archive

BASE = "https://efile.fara.gov/bulk/zip/"
MAX_ZIP_BYTES = 16 * 1024**2
MAX_CSV_BYTES = 64 * 1024**2
MAX_ROWS = 500_000
HEADERS = {
    "Registrants": (
        "Registration Number",
        "Registration Date",
        "Termination Date",
        "Name",
        "Business Name",
        "Address 1",
        "Address 2",
        "City",
        "State",
        "Zip",
    ),
    "ForeignPrincipals": (
        "Foreign Principal Termination Date",
        "Foreign Principal",
        "Foreign Principal Registration Date",
        "Country/Location Represented",
        "Registration Number",
        "Registrant Date",
        "Registrant Name",
        "Address 1",
        "Address 2",
        "City",
        "State",
        "Zip",
    ),
    "RegistrantDocs": (
        "Date Stamped",
        "Registrant Name",
        "Registration Number",
        "Document Type",
        "Short Form Name",
        "Foreign Principal Name",
        "Foreign Principal Country",
        "URL",
    ),
}
XML_ROOTS = {"Registrants": "REGISTRANTS", "ForeignPrincipals": "FOREIGNPRINCIPALS", "RegistrantDocs": "REGISTRANTDOCS"}
XML_FIELDS = {
    "Registrants": dict(
        zip(
            HEADERS["Registrants"],
            (
                "Registration_Number",
                "Registration_Date",
                "Termination_Date",
                "Name",
                "Business_Name",
                "Address_1",
                "Address_2",
                "City",
                "State",
                "Zip",
            ),
            strict=True,
        )
    ),
    "ForeignPrincipals": dict(
        zip(
            HEADERS["ForeignPrincipals"],
            (
                "FP_termination_date",
                "Foreign_principal",
                "FP_registration_date",
                "Country_location_represented",
                "Registration_number",
                "Registration_date",
                "Registrant_name",
                "Address_1",
                "Address_2",
                "City",
                "State",
                "Zip",
            ),
            strict=True,
        )
    ),
    "RegistrantDocs": dict(
        zip(
            HEADERS["RegistrantDocs"],
            (
                "CDATE_STAMPED",
                "REGISTRANT_NAME",
                "REGISTRATION_NUMBER",
                "DOCUMENT_TYPE",
                "SHORT_FORM_NAME",
                "FOREIGN_PRINCIPAL_NAME",
                "FOREIGN_PRINCIPAL_COUNTRY",
                "URL",
            ),
            strict=True,
        )
    ),
}


class FaraError(ValueError):
    """An original cannot establish the selected FARA observations."""


def export_url(kind, format="xml"):
    if kind not in HEADERS:
        raise FaraError("Unsupported FARA export")
    if format not in {"csv", "xml"}:
        raise FaraError("Unsupported FARA export format")
    return BASE + f"FARA_All_{kind}.{format}.zip"


def document_url(url, registration_number=None):
    """Admit only the production PDF locator, optionally held to its registrant."""
    if not isinstance(url, str):
        raise FaraError("FARA document needs a URL")
    parsed = urlsplit(url)
    match = re.fullmatch(r"/docs/([0-9]+)-[A-Za-z0-9._-]+\.pdf", parsed.path)
    if (
        parsed.scheme != "https"
        or parsed.netloc != "efile.fara.gov"
        or parsed.query
        or parsed.fragment
        or not match
        or (registration_number is not None and match[1] != registration_number)
    ):
        raise FaraError("FARA document URL differs from its production registrant locator")
    return url


def validate_cohort(registration_numbers):
    """Require a bounded explicit cohort before acquisition or replay."""
    numbers = list(registration_numbers)
    if (
        not 1 <= len(numbers) <= 100
        or len(set(numbers)) != len(numbers)
        or any(not isinstance(n, str) or not re.fullmatch(r"[0-9]{1,20}", n) for n in numbers)
    ):
        raise FaraError("Declare unique native registration numbers within the cohort bound")
    return numbers


def fara_scope(capture, kind, registration_numbers):
    """Pin one original and a bounded caller-selected cohort; dates are not a release ID."""
    numbers = validate_cohort(registration_numbers)
    if (
        not isinstance(capture, dict)
        or set(capture) != {"request_url", "response_sha256", "byte_size", "observed_at"}
        or capture["request_url"] not in {export_url(kind), export_url(kind, "csv")}
        or not isinstance(capture["response_sha256"], str)
        or not re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"])
        or type(capture["byte_size"]) is not int
        or not 0 < capture["byte_size"] <= MAX_ZIP_BYTES
    ):
        raise FaraError("FARA capture identity differs")
    try:
        if datetime.fromisoformat(capture["observed_at"]).utcoffset() is None:
            raise ValueError
    except (TypeError, ValueError) as error:
        raise FaraError("FARA capture needs a timestamp with timezone") from error
    return {"capture": dict(capture), "kind": kind, "registration_numbers": numbers}


def validate_scope(scope):
    if not isinstance(scope, dict) or set(scope) != {"capture", "kind", "registration_numbers"}:
        raise FaraError("FARA scope fields differ")
    return fara_scope(**scope)


def acquire_export(acquirer, kind, *, store):
    """Use the maintained bounded downloader; callers retain responses and choose scope."""
    return acquirer.download(export_url(kind), store=store, max_bytes=MAX_ZIP_BYTES)


def read_export(body, *, scope):
    """Validate every row before returning selected rows and whole-member accounting.

    Windows ANSI (cp1252), explicitly offered by the publisher, preserves its
    smart punctuation. XML omissions and empty elements remain distinct. CSV
    empty cells mean literal empty text; malformed quoting refuses. Originals preserve spelling.
    Duplicate records survive with distinct original ordinal/line coordinates.
    """
    scope = validate_scope(scope)
    capture, kind = scope["capture"], scope["kind"]
    if len(body) != capture["byte_size"] or "sha256:" + hashlib.sha256(body).hexdigest() != capture["response_sha256"]:
        raise FaraError("FARA original differs from its selected digest/size")
    with open_archive(
        body,
        max_bytes=MAX_ZIP_BYTES,
        max_entries=1,
        max_entry_bytes=MAX_CSV_BYTES,
        error_type=FaraError,
        label="FARA export",
    ) as archive:
        members = archive.infolist()
        format = "xml" if capture["request_url"].endswith(".xml.zip") else "csv"
        if len(members) != 1 or members[0].filename != f"FARA_All_{kind}.{format}":
            raise FaraError("FARA export member differs")
        member = archive.read(members[0])
    if format == "xml":
        return _read_xml(member, scope=scope, member_name=members[0].filename)
    try:
        text = member.decode("cp1252")
    except UnicodeDecodeError as error:
        raise FaraError("FARA export is not supported Windows ANSI text") from error
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    member_digest = "sha256:" + hashlib.sha256(member).hexdigest()
    rows, scanned, line = [], 0, 0
    try:
        if tuple(next(reader, ())) != HEADERS[kind]:
            raise FaraError("FARA CSV headers changed or success shape differs")
        line = reader.line_num
        for ordinal, cells in enumerate(reader):
            start = line + 1
            line = reader.line_num
            if ordinal >= MAX_ROWS or len(cells) != len(HEADERS[kind]):
                raise FaraError("FARA CSV row width or population bound differs")
            fields = dict(zip(HEADERS[kind], cells, strict=True))
            number = fields["Registration Number"]
            if not re.fullmatch(r"[0-9]{1,20}", number):
                raise FaraError("FARA row has no supported native registration number")
            scanned += 1
            if number in scope["registration_numbers"]:
                if kind == "RegistrantDocs":
                    document_url(fields["URL"], number)
                rows.append(
                    {
                        "kind": kind,
                        "ordinal": ordinal,
                        "fields": fields,
                        "native_fields": dict(fields),
                        "source_locator": {
                            **capture,
                            "member_name": members[0].filename,
                            "member_sha256": member_digest,
                            "encoding": "cp1252",
                            "csv_record_ordinal": ordinal,
                            "line_start": start,
                            "line_end": line,
                        },
                    }
                )
    except csv.Error as error:
        raise FaraError("FARA CSV syntax differs") from error
    return {"rows": rows, "scanned": scanned, "selected": len(rows), "omitted": scanned - len(rows)}


def _read_xml(member, *, scope, member_name):
    """Use the shared entity-safe XML scanner; retain absent, empty and literal native fields."""
    kind, capture = scope["kind"], scope["capture"]
    # DOJ advertises Windows ANSI for all bulk files. These XML files omit an
    # encoding declaration despite containing cp1252 bytes, so Expat's UTF-8
    # default refuses them. Decode the advertised code page explicitly; retain
    # the untouched original hash and XPath, never claim transformed byte offsets.
    if not member.startswith(b'<?xml version="1.0"?>'):
        raise FaraError("FARA XML encoding declaration changed")
    try:
        parser_input = member.decode("cp1252").encode("utf-8")
    except UnicodeDecodeError as error:
        raise FaraError("FARA XML is not supported Windows ANSI text") from error
    digest = "sha256:" + hashlib.sha256(member).hexdigest()
    stack, text, native, rows = [], [], {}, []
    scanned = 0

    def start(tag, attributes):
        nonlocal text, native
        stack.append(tag)
        if attributes or len(stack) > 3:
            raise FaraError("FARA XML nesting or attributes changed")
        if (len(stack) == 1 and tag != XML_ROOTS[kind]) or (len(stack) == 2 and tag != "ROW"):
            raise FaraError("FARA XML root or record shape differs")
        if len(stack) == 2:
            native = {}
        if len(stack) == 3:
            if tag in native or len(native) >= 100:
                raise FaraError("FARA XML field repeats or exceeds its bound")
            text = []

    def data(value):
        if len(stack) == 3:
            text.append(value)
        elif value.strip():
            raise FaraError("FARA XML has text outside a field")

    def end(tag):
        nonlocal scanned
        if len(stack) == 3:
            native[tag] = "".join(text)
        elif len(stack) == 2:
            if scanned >= MAX_ROWS:
                raise FaraError("FARA XML exceeds the population bound")
            fields = {label: native.get(key) for label, key in XML_FIELDS[kind].items()}
            number = fields["Registration Number"]
            if not isinstance(number, str) or not re.fullmatch(r"[0-9]{1,20}", number):
                raise FaraError("FARA XML has no supported native registration number")
            if number in scope["registration_numbers"]:
                if kind == "RegistrantDocs":
                    document_url(fields["URL"], number)
                rows.append(
                    {
                        "kind": kind,
                        "ordinal": scanned,
                        "fields": fields,
                        "native_fields": dict(native),
                        "source_locator": {
                            **capture,
                            "member_name": member_name,
                            "member_sha256": digest,
                            "source_xpath": f"/*[1]/*[{scanned + 1}]",
                            "encoding": "cp1252",
                            "parser_encoding": "utf-8",
                            "encoding_evidence": "https://efile.fara.gov/ords/fara/r/fara_ws/api/bulkdata",
                        },
                    }
                )
            scanned += 1
        stack.pop()

    scan_xml(
        parser_input,
        start=start,
        end=end,
        data=data,
        max_bytes=MAX_CSV_BYTES * 3,
        max_depth=3,
        error_type=FaraError,
        label="FARA XML export",
    )
    return {"rows": rows, "scanned": scanned, "selected": len(rows), "omitted": scanned - len(rows)}
