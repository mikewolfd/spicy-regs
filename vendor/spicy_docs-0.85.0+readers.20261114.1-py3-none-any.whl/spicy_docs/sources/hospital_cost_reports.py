"""Literal CMS-2552-10 HCRIS report and worksheet rows from a pinned fiscal-year ZIP.

The caller selects the form/year, retains the original, and exhausts each iterator.
Interpretation, units and preferred-report policies belong to the application.
"""

from __future__ import annotations

import hashlib
import re
from contextlib import contextmanager
from pathlib import Path
from zipfile import ZipFile

from spicy_docs.reading.zip_archive import inspect_archive_stream
from spicy_docs.sources.fec.delimited import delimited_rows

FORM = "CMS-2552-10"
PARSER_REVISION = "hospital-cost-reports/1"
RPT_COLUMNS = (
    "rpt_rec_num",
    "prvdr_ctrl_type_cd",
    "prvdr_num",
    "npi",
    "rpt_stus_cd",
    "fy_bgn_dt",
    "fy_end_dt",
    "proc_dt",
    "initl_rpt_sw",
    "last_rpt_sw",
    "trnsmtl_num",
    "fi_num",
    "adr_vndr_cd",
    "fi_creat_dt",
    "util_cd",
    "npr_dt",
    "spec_ind",
    "fi_rcpt_dt",
)
CELL_COLUMNS = ("rpt_rec_num", "wksht_cd", "line_num", "clmn_num", "value_raw")
# Caller admission bounds for one annual file; no CSV is extracted to disk.
MAX_ARCHIVE_BYTES = 128 * 1024 * 1024
MAX_DECODED_BYTES = 1024 * 1024 * 1024
MAX_RECORD_BYTES = 16 * 1024


class HospitalCostReportError(ValueError):
    """A selected original, table layout or native row cannot be proved."""


def _digest(stream):
    stream.seek(0)
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    stream.seek(0)
    return "sha256:" + digest.hexdigest()


class HospitalCostReportArchive:
    """One open, checksum-verified original; every ZIP member is CRC/SHA-256 checked.

    Only the headerless CMS layout is accepted. Numeric and alpha observations
    retain their literal values and occurrence coordinates, including duplicates.
    The iterator never chooses a revision or drops an unknown worksheet.
    """

    def __init__(self, stream, *, sha256: str, byte_size: int, form: str, year: int):
        if form != FORM:
            raise HospitalCostReportError("Unsupported hospital form/layout; select CMS-2552-10")
        if type(year) is not int or year != 2010:
            raise HospitalCostReportError("Only the qualified fiscal-year-start 2010 cohort is supported")
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", sha256):
            raise HospitalCostReportError("An exact original SHA-256 is required")
        if type(byte_size) is not int or not 0 < byte_size <= MAX_ARCHIVE_BYTES:
            raise HospitalCostReportError("Hospital original exceeds its archive byte bound")
        self.stream, self.sha256, self.byte_size = stream, sha256, byte_size
        self.form, self.year = form, year
        stream.seek(0, 2)
        if stream.tell() != byte_size or _digest(stream) != sha256:
            raise HospitalCostReportError("Hospital original differs from its selected size or SHA-256")
        self.inventory = inspect_archive_stream(
            stream,
            byte_size=byte_size,
            max_entries=3,
            max_decoded_bytes=MAX_DECODED_BYTES,
            max_metadata_bytes=128 * 1024,
        )
        self.members = {}
        for member in self.inventory["members"]:
            match = re.fullmatch(r"hosp10_2010_(rpt|nmrc|alpha)\.csv", member["name"], re.IGNORECASE)
            table = None if match is None else {"alpha": "alphnmrc"}.get(match[1].lower(), match[1].lower())
            if member["isDirectory"] or table is None or table in self.members:
                raise HospitalCostReportError("Hospital archive has an unsupported or repeated table layout")
            self.members[table] = member
        if set(self.members) != {"rpt", "nmrc", "alphnmrc"}:
            raise HospitalCostReportError("Hospital archive lacks a required native table")

    def verify_unchanged(self):
        if _digest(self.stream) != self.sha256:
            raise HospitalCostReportError("Hospital original changed during reading")

    def rows(self, table: str):
        if table not in self.members:
            raise HospitalCostReportError("Unsupported hospital native table")
        member = self.members[table]
        columns = RPT_COLUMNS if table == "rpt" else CELL_COLUMNS
        count = 0
        with ZipFile(self.stream) as archive, archive.open(archive.infolist()[member["ordinal"]]) as decoded:
            for count, item in enumerate(
                delimited_rows(
                    decoded,
                    sha256=member["sha256"],
                    encoding="cp1252",
                    delimiter=",",
                    quoting="csv",
                    max_record_bytes=MAX_RECORD_BYTES,
                ),
                1,
            ):
                fields = item["fields"]
                if len(fields) != len(columns):
                    raise HospitalCostReportError(f"Hospital {table} row {count} changed field count")
                raw = dict(zip(columns, fields, strict=True))
                if not re.fullmatch(r"[0-9]+", raw["rpt_rec_num"]):
                    raise HospitalCostReportError(f"Hospital {table} row {count} lacks a report identity")
                # The native schema declares CHAR widths, not a numeric grammar.
                # CMS uses lettered columns (04A00) and starred ALPHA worksheets
                # (B10000*). Preserve these literal identities without coercion.
                if table != "rpt" and any(
                    len(raw[field]) != width
                    or not raw[field].isascii()
                    or not raw[field].isprintable()
                    or not raw[field].strip()
                    for field, width in (("wksht_cd", 7), ("line_num", 5), ("clmn_num", 5))
                ):
                    raise HospitalCostReportError(f"Hospital {table} row {count} changed worksheet coordinates")
                yield {
                    "table": table,
                    "raw": raw,
                    "source_locator": {
                        "archive_sha256": self.sha256,
                        "member": member["name"],
                        "member_sha256": member["sha256"],
                        "record_number": count,
                        **item["source"],
                    },
                }
        if not count:
            raise HospitalCostReportError(f"Hospital {table} table is unexpectedly empty")


@contextmanager
def open_hospital_archive(path: Path, **selection):
    """Open a retained local original without acquisition or source mutation."""
    with Path(path).open("rb") as stream:
        reader = HospitalCostReportArchive(stream, **selection)
        try:
            yield reader
        finally:
            reader.verify_unchanged()
