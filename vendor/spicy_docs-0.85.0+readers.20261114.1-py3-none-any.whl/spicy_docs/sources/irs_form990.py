"""Selected IRS filing-index rows and original return XML, without financial interpretation."""

from __future__ import annotations

import csv
import hashlib
import io
import re
from datetime import date
from pathlib import PurePosixPath
from zipfile import BadZipFile, ZipFile

from spicy_docs.reading.xml import parse_xml

BASE_URL = "https://apps.irs.gov/pub/epostcard/990/xml/"
NAMESPACE = "http://www.irs.gov/efile"
MAX_INDEX_BYTES = 256 * 1024**2
MAX_ARCHIVE_BYTES = 256 * 1024**2
MAX_RETURN_BYTES = 16 * 1024**2
MAX_INDEX_ROWS = 2_000_000
MAX_SELECTED = 100
REQUIRED_COLUMNS = {
    "RETURN_ID",
    "FILING_TYPE",
    "EIN",
    "TAX_PERIOD",
    "SUB_DATE",
    "TAXPAYER_NAME",
    "RETURN_TYPE",
    "DLN",
    "OBJECT_ID",
}


class IRS990Error(ValueError):
    """The selected IRS original cannot establish the requested filing identity."""


def validate_url(url):
    if (
        not isinstance(url, str)
        or re.fullmatch(re.escape(BASE_URL) + r"(20\d{2})/(?:index_20\d{2}\.csv|20\d{2}_TEOS_XML_\d{2}[A-Z]\.zip)", url)
        is None
    ):
        raise IRS990Error("IRS URL must select an official annual index or monthly XML archive")
    year, filename = url.removeprefix(BASE_URL).split("/")
    if year not in filename:
        raise IRS990Error("IRS URL year differs from its file")
    return url


def acquire_original(acquirer, url, *, store, expected_size, etag):
    """Capture one caller-selected official original through the shared downloader."""
    validate_url(url)
    bound = MAX_INDEX_BYTES if url.endswith(".csv") else MAX_ARCHIVE_BYTES
    if type(expected_size) is not int or not 0 < expected_size <= bound or not etag:
        raise IRS990Error("IRS acquisition requires a bounded size and selected ETag")
    return acquirer.download(url, store=store, max_bytes=bound, expected_size=expected_size, etag=etag)


def _object_ids(values):
    values = tuple(values)
    if (
        not 0 < len(values) <= MAX_SELECTED
        or len(set(values)) != len(values)
        or any(not isinstance(value, str) or re.fullmatch(r"\d{18}", value) is None for value in values)
    ):
        raise IRS990Error("Select unique IRS object IDs within the filing bound")
    return values


class _BoundedIndex(io.RawIOBase):
    def __init__(self, stream):
        self.stream, self.size = stream, 0

    def readable(self):
        return True

    def readinto(self, buffer):
        chunk = self.stream.read(min(len(buffer), MAX_INDEX_BYTES - self.size + 1))
        self.size += len(chunk)
        if self.size > MAX_INDEX_BYTES:
            raise IRS990Error("IRS index exceeds its byte bound")
        buffer[: len(chunk)] = chunk
        return len(chunk)


def read_index(stream, *, submission_year, object_ids):
    """Scan the whole retained annual index once, proving selected membership and uniqueness.

    Unknown columns and literal values survive in ``native_index``. This proves
    selected membership, never completeness of the publisher's filing population.
    """
    object_ids = _object_ids(object_ids)
    selected = set(object_ids)
    if type(submission_year) is not int or not 2011 <= submission_year <= 2099:
        raise IRS990Error("IRS index requires its explicit submission year")
    text = io.TextIOWrapper(io.BufferedReader(_BoundedIndex(stream)), encoding="utf-8-sig", newline="")
    rows = csv.DictReader(text, strict=True)
    if (
        not rows.fieldnames
        or len(set(rows.fieldnames)) != len(rows.fieldnames)
        or not REQUIRED_COLUMNS <= set(rows.fieldnames)
    ):
        raise IRS990Error("IRS filing-index header changed")
    found = {}
    try:
        for ordinal, row in enumerate(rows, 1):
            if ordinal > MAX_INDEX_ROWS or None in row or any(value is None for value in row.values()):
                raise IRS990Error("IRS filing-index row shape or population bound differs")
            oid = row["OBJECT_ID"]
            if oid not in selected:
                continue
            if oid in found:
                raise IRS990Error("IRS selected object ID is duplicated in the index")
            if re.fullmatch(r"\d{9}", row["EIN"]) is None or re.fullmatch(r"\d{6}", row["TAX_PERIOD"]) is None:
                raise IRS990Error("IRS selected EIN or tax period is malformed")
            found[oid] = {
                "object_id": oid,
                "submission_year": submission_year,
                "index_row": ordinal,
                "native_index": dict(row),
            }
    except (UnicodeError, csv.Error) as error:
        raise IRS990Error("IRS filing index is malformed") from error
    if set(found) != selected:
        raise IRS990Error("IRS selected object ID is missing from the retained index")
    return [found[oid] for oid in object_ids]


def _node(element, xpath):
    return {
        "tag": element.tag,
        "attributes": dict(element.attrib),
        "text": element.text,
        "source_xpath": xpath,
        "tail": element.tail,
        "children": [_node(child, f"{xpath}/*[{i}]") for i, child in enumerate(element, 1)],
    }


def child(node, name):
    """One immediate IRS-namespace child; ambiguous repeats refuse rather than choose a value."""
    matches = [entry for entry in node["children"] if entry["tag"] == f"{{{NAMESPACE}}}{name}"]
    if len(matches) > 1:
        raise IRS990Error(f"IRS singleton element repeats: {name}")
    return matches[0] if matches else None


def text_at(node, *path):
    for name in path:
        node = child(node, name) if node is not None else None
    return node["text"] if node is not None else None


def parse_return(body, *, filing, locator):
    """Keep native XML fields and positional paths; prove EIN/form/period against the selected index row."""
    root = parse_xml(body, max_bytes=MAX_RETURN_BYTES, error_type=IRS990Error, label="IRS return XML", max_depth=64)
    if root.tag != f"{{{NAMESPACE}}}Return" or not root.get("returnVersion"):
        raise IRS990Error("IRS XML root, namespace or returnVersion differs")
    native = _node(root, "/*[1]")
    header, data = child(native, "ReturnHeader"), child(native, "ReturnData")
    if header is None or data is None:
        raise IRS990Error("IRS return header or data is missing")
    declared = data["attributes"].get("documentCnt")
    if declared is not None and (not declared.isdigit() or int(declared) != len(data["children"])):
        raise IRS990Error("IRS declared return document count differs from observed XML")
    index = filing["native_index"]
    form = text_at(header, "ReturnTypeCd")
    form_nodes = {"990": "IRS990", "990EZ": "IRS990EZ", "990PF": "IRS990PF"}
    end = text_at(header, "TaxPeriodEndDt")
    if (
        text_at(header, "Filer", "EIN") != index["EIN"]
        or form != index["RETURN_TYPE"]
        or not end
        or re.fullmatch(r"\d{4}-\d{2}-\d{2}", end) is None
        or end[:7].replace("-", "") != index["TAX_PERIOD"]
    ):
        raise IRS990Error("IRS XML EIN, return type or tax period differs from the index")
    try:
        date.fromisoformat(end)
    except ValueError as error:
        raise IRS990Error("IRS XML tax period end is not a calendar date") from error
    if form not in form_nodes or child(data, form_nodes[form]) is None:
        raise IRS990Error("IRS form body differs from its return type")
    if sum(child(data, name) is not None for name in form_nodes.values()) != 1:
        raise IRS990Error("IRS XML has conflicting main return forms")
    return {
        **filing,
        "return_version": root.get("returnVersion"),
        "native_xml": native,
        "source_locator": {**locator, "member_sha256": "sha256:" + hashlib.sha256(body).hexdigest()},
    }


def read_selected_returns(stream, *, filings, archive_sha256):
    """Read only explicitly selected XML members; no archive extraction or unrelated return parsing."""
    filings = list(filings)
    ids = set(_object_ids(row["object_id"] for row in filings))
    try:
        with ZipFile(stream) as archive:
            entries = archive.infolist()
            if len(entries) > 100_000:
                raise IRS990Error("IRS archive exceeds its member bound")
            selected = {}
            for entry in entries:
                basename = PurePosixPath(entry.filename).name
                oid = basename.removesuffix("_public.xml")
                if oid in ids and basename == oid + "_public.xml":
                    if oid in selected or entry.is_dir() or entry.flag_bits & 1 or entry.file_size > MAX_RETURN_BYTES:
                        raise IRS990Error("IRS selected XML member is ambiguous, encrypted or oversized")
                    selected[oid] = entry
            if set(selected) != ids:
                raise IRS990Error("IRS selected XML member is missing from the archive")
            result = []
            for filing in filings:
                entry = selected[filing["object_id"]]
                with archive.open(entry) as original:
                    body = original.read(MAX_RETURN_BYTES + 1)
                result.append(
                    parse_return(
                        body,
                        filing=filing,
                        locator={
                            "archive_sha256": archive_sha256,
                            "member_name": entry.filename,
                            "index_row": filing["index_row"],
                        },
                    )
                )
            return result
    except (BadZipFile, OSError) as error:
        raise IRS990Error("IRS archive is malformed or incomplete") from error
