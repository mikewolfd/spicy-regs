"""Latest active SAM notices, with page-index offsets and complete-walk checks.

The API's ``offset`` is a page index, not a number of records. The shared
reader owns capture, credentials and byte/request limits; this adapter owns
SAM's paging semantics. A refused or changing query never becomes empty data.
"""

import json
from dataclasses import replace
from datetime import date, datetime
from urllib.parse import urlencode

from spicy_docs.reading.paged_json import (
    JsonPageFamily,
    PagedJsonReader,
    PagedJsonSourceError,
    query_value,
    with_query,
)
from spicy_docs.sources.sam import SAM

API = "https://api.sam.gov/opportunities/v2/search"
NOTICES = JsonPageFamily(
    name="sam-opportunities",
    label="SAM opportunities",
    host="api.sam.gov",
    count_path=("totalRecords",),
    next_kind="offset",
)
EXCLUSIONS = replace(SAM, name="sam-exclusions", label="SAM exclusions", window_hint="exclusions partition")


def opportunities_url(*, posted_from, posted_to, organization_code, limit=100, offset=0):
    if any(not isinstance(day, date) or isinstance(day, datetime) for day in (posted_from, posted_to)):
        raise PagedJsonSourceError("SAM notice window requires dates")
    if posted_to < posted_from or (posted_to - posted_from).days > 365:
        raise PagedJsonSourceError("SAM notice window must be ordered and at most 365 days")
    if not isinstance(organization_code, str) or not organization_code.strip():
        raise PagedJsonSourceError("SAM notice selection requires an organization code")
    if type(limit) is not int or not 1 <= limit <= 1000 or type(offset) is not int or offset < 0:
        raise PagedJsonSourceError("SAM notice limit or offset is invalid")
    return (
        API
        + "?"
        + urlencode(
            {
                "postedFrom": posted_from.strftime("%m/%d/%Y"),
                "postedTo": posted_to.strftime("%m/%d/%Y"),
                "organizationCode": organization_code,
                "limit": limit,
                "offset": offset,
            }
        )
    )


class SamOpportunitiesReader(PagedJsonReader):
    def __init__(self, *, budget, api_key, transport=None, **kwargs):
        super().__init__(family=NOTICES, budget=budget, api_key=api_key, transport=transport, **kwargs)

    def opportunities(self, url, *, max_pages=10):
        """Yield only an exactly counted walk, refusing repeated IDs or changed totals.

        Consumers must exhaust the iterator before committing output. Count
        agreement is an observed crawl, not a frozen publisher snapshot.
        """
        if type(max_pages) is not int or max_pages < 1 or query_value(url, "offset") != "0":
            raise PagedJsonSourceError("SAM notice walk requires offset zero and a positive page bound")
        limit = int(query_value(url, "limit") or "0")
        if not 1 <= limit <= 1000:
            raise PagedJsonSourceError("SAM notice page limit is invalid")
        seen, declared = set(), None
        for index in range(max_pages):
            page = self.page(with_query(url, "offset", str(index)), records_key="opportunitiesData", page_index=index)
            metadata = json.loads(page.capture.body)
            if metadata.get("offset") != index or metadata.get("limit") != limit:
                raise PagedJsonSourceError("SAM notice response page index or limit differs")
            if page.declared_count is None or (declared is not None and page.declared_count != declared):
                raise PagedJsonSourceError("SAM notice declared total missing or changed")
            declared = page.declared_count
            if declared > limit * max_pages:
                raise PagedJsonSourceError("SAM notice selection exceeds page budget; narrow the window")
            if len(page.records) > limit:
                raise PagedJsonSourceError("SAM notice response exceeds its page limit")
            for record in page.records:
                identity = record.get("noticeId")
                if not isinstance(identity, str) or not identity.strip() or identity in seen:
                    raise PagedJsonSourceError("SAM notice identity missing or repeated within a walk")
                seen.add(identity)
            if len(seen) > declared:
                raise PagedJsonSourceError("SAM notice count exceeds declared total")
            yield page
            if len(seen) == declared:
                return
            if len(page.records) < limit:
                raise PagedJsonSourceError("SAM notice short page before declared total")
        raise PagedJsonSourceError("SAM notice page budget reached before completion")


class SamExclusionsReader(PagedJsonReader):
    def __init__(self, *, budget, api_key, transport=None, **kwargs):
        super().__init__(family=EXCLUSIONS, budget=budget, api_key=api_key, transport=transport, **kwargs)

    def exclusions(self, url, *, max_pages=100):
        """Public API partitions; total over 10,000 refuses on the first page."""
        return self.pages(url, records_key="excludedEntity", max_pages=max_pages)
