"""Seal and replay a bounded FARA cohort from one exact production bulk original."""

import hashlib
from dataclasses import dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.fara import MAX_ZIP_BYTES, FaraError, read_export, validate_scope

SCOPE_ID = "fara-bulk-cohort-v1"
SCHEMA_NAME = "fara-bulk-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["kind", "ordinal", "fields", "native_fields", "source_locator"],
    "properties": {
        "kind": {"enum": ["Registrants", "ForeignPrincipals", "RegistrantDocs"]},
        "ordinal": {"type": "integer", "minimum": 0},
        "fields": {"type": "object", "additionalProperties": {"type": ["string", "null"]}},
        "native_fields": {"type": "object", "additionalProperties": {"type": "string"}},
        "source_locator": {"type": "object"},
    },
    "x-spicy-record-order": [{"fieldPath": "/ordinal", "nullOrder": "forbidden", "valueType": "integer"}],
}


def _key(index):
    return f"fara://bulk/page/{index}"


def iter_retained_pages(scope, *, blob_source):
    capture = validate_scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, _key(0), capture["response_sha256"], capture["byte_size"], blob_source, "application/zip"
    )


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    capture = validate_scope(query_scope)["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["response_sha256"],
        capture["byte_size"],
        "application/zip",
    ):
        raise FaraError("FARA evidence binding differs")
    result = read_export(stream.read(MAX_ZIP_BYTES + 1), scope=query_scope)
    rows = result.pop("rows")
    for index, start in enumerate(range(0, max(1, len(rows)), 50)):
        yield {
            "requestKey": _key(index),
            "page": index,
            "results": rows[start : start + 50],
            "terminal": start + 50 >= len(rows),
            "population": result,
        }


@dataclass
class _Traversal:
    pages: int = 0
    observed: int = 0
    last: int = -1
    terminal: bool = False
    population: dict | None = None

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise FaraError("FARA page order differs")
        if self.population is None:
            self.population = response["population"]
        if self.population != response["population"]:
            raise FaraError("FARA population changed")
        for row in response["results"]:
            if row["ordinal"] <= self.last:
                raise FaraError("FARA source coordinates repeat or reverse")
            self.last = row["ordinal"]
            self.observed += 1
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if (
            not self.terminal
            or self.population is None
            or self.observed != self.population["selected"]
            or self.population["scanned"] != self.population["selected"] + self.population["omitted"]
        ):
            raise FaraError("FARA original/cohort accounting differs")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise FaraError("FARA requires one selected original")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise FaraError("FARA selected original is missing")


def _record_scope(record, *, query_scope, page_window):
    row = record
    locator = row["source_locator"]
    if (
        row["kind"] != query_scope["kind"]
        or row["fields"]["Registration Number"] not in query_scope["registration_numbers"]
        or any(locator[key] != value for key, value in query_scope["capture"].items())
        or (locator.get("csv_record_ordinal", row["ordinal"]) != row["ordinal"])
    ):
        raise FaraError("FARA record differs from its original/cohort")


def _byte_parser(_raw):
    raise FaraError("FARA requires its captured original stream")


def _classify_record(record: object):
    if not isinstance(record, dict):
        raise FaraError("FARA observation is not an object")
    return dict(record)


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


FARA_PROFILE = SourceNativeProfile(
    name="Retained FARA bulk cohort",
    source_system_id="https://efile.fara.gov/",
    source_system_version="production-bulk-v1",
    acquisition_policy_id="urn:spicy-docs:acquisition:fara-bulk",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="fara",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "coverageLimits": [
            "Selected registration numbers in one exact production export; originals are not an atomic publisher release.",
            "Active and terminated observations and duplicate rows survive. Empty selection means observed-empty.",
            "Principal IDs are not supplied in this export; observation coordinates are not entity IDs.",
            "Document locators do not prove downloaded PDFs, principal identity, activities or financial facts.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_ZIP_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=_classify_record,
    wrap_record=lambda record, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(record),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": f"fara:{record['kind']}:{record['source_locator']['response_sha256']}:{record['ordinal']}",
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=lambda response, **kwargs: True,
    acquisition_check=_Acquisition,
    page_window=lambda key: 0,
)
