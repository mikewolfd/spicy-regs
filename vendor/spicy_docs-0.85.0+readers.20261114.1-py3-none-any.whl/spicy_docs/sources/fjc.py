"""Literal Federal Judicial Center Article III flat-export rows with exact CSV coordinates."""

from __future__ import annotations

import csv
import re
from datetime import datetime

from spicy_docs.sources.fec.delimited import delimited_rows

EXPORT_URL = "https://www.fjc.gov/sites/default/files/history/judges.csv"
NOTES_URL = "https://www.fjc.gov/history/judges/biographical-directory-article-iii-federal-judges-export"
# The qualified 2026-11-13 export is 5,456,258 bytes; bound growth rather than silently truncating it.
MAX_BYTES = 16 * 1024**2
MAX_RECORD_BYTES = 128 * 1024
MAX_RECORDS = 20_000
PERSON_FIELDS = (
    "nid",
    "jid",
    "Last Name",
    "First Name",
    "Middle Name",
    "Suffix",
    "Birth Month",
    "Birth Day",
    "Birth Year",
    "Birth City",
    "Birth State",
    "Death Month",
    "Death Day",
    "Death Year",
    "Death City",
    "Death State",
    "Gender",
    "Race or Ethnicity",
)
SERVICE_FIELDS = (
    "Court Type",
    "Court Name",
    "Appointment Title",
    "Appointing President",
    "Party of Appointing President",
    "Reappointing President",
    "Party of Reappointing President",
    "ABA Rating",
    "Seat ID",
    "Statute Authorizing New Seat",
    "Recess Appointment Date",
    "Nomination Date",
    "Committee Referral Date",
    "Hearing Date",
    "Judiciary Committee Action",
    "Committee Action Date",
    "Senate Vote Type",
    "Ayes/Nays",
    "Confirmation Date",
    "Commission Date",
    "Service as Chief Judge, Begin",
    "Service as Chief Judge, End",
    "2nd Service as Chief Judge, Begin",
    "2nd Service as Chief Judge, End",
    "Senior Status Date",
    "Termination",
    "Termination Date",
)
OTHER_FIELDS = (
    *(f"Other Federal Judicial Service ({i})" for i in range(1, 5)),
    *(f"{field} ({i})" for i in range(1, 6) for field in ("School", "Degree", "Degree Year")),
    "Professional Career",
    "Other Nominations/Recess Appointments",
)
REQUIRED_HEADERS = (
    *PERSON_FIELDS,
    *(f"{field} ({i})" for i in range(1, 7) for field in SERVICE_FIELDS),
    *OTHER_FIELDS,
)


class FjcError(ValueError):
    """The selected FJC export cannot establish a complete literal reading."""


def validate_download_url(url):
    """The selected export has one official HTTPS location; unexpected redirects refuse."""
    if url != EXPORT_URL:
        raise FjcError("FJC URL differs from the selected official flat export")
    return url


def acquire_snapshot(acquirer, *, store):
    """Acquire the CSV with the maintained BoundedAcquirer and its configured URL validator."""
    return acquirer.download(EXPORT_URL, store=store, max_bytes=MAX_BYTES)


def fjc_scope(capture):
    """An observed complete flat file; acquisition time is not a publisher revision date."""
    if (
        not isinstance(capture, dict)
        or set(capture) != {"request_url", "response_sha256", "observed_at", "byte_size"}
        or capture["request_url"] != EXPORT_URL
        or not isinstance(capture["response_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
        or type(capture["byte_size"]) is not int
        or not 0 < capture["byte_size"] <= MAX_BYTES
    ):
        raise FjcError("FJC capture identity differs")
    try:
        if datetime.fromisoformat(capture["observed_at"]).utcoffset() is None:
            raise ValueError
    except (ValueError, TypeError) as error:
        raise FjcError("FJC capture requires an observation timestamp with timezone") from error
    return {"dataset": "article-iii-flat-export", "capture": dict(capture)}


def validate_scope(scope):
    if not isinstance(scope, dict) or set(scope) != {"dataset", "capture"} or fjc_scope(scope["capture"]) != scope:
        raise FjcError("FJC requires one declared Article III flat export")
    return scope


def snapshot_records(stream, *, scope):
    """Reuse the maintained literal CSV splitter, preserving every column and byte span.

    CSV blanks remain empty strings, whitespace remains whitespace, and unknown added columns survive.
    Missing/duplicate headers, ragged rows, repeated native IDs and malformed CSV refuse the whole reading.
    The release publisher verifies the selected original digest; this reader also checks its complete size.
    """
    capture = validate_scope(scope)["capture"]
    rows = delimited_rows(
        stream,
        sha256=capture["response_sha256"],
        encoding="utf-8",
        delimiter=",",
        quoting="csv",
        max_record_bytes=MAX_RECORD_BYTES,
    )
    try:
        header = next(rows, None)
        if header is None:
            raise FjcError("FJC CSV has no header")
        headers = header["fields"]
        if not all(headers) or len(set(headers)) != len(headers) or not set(REQUIRED_HEADERS) <= set(headers):
            raise FjcError("FJC CSV required header missing, empty or repeated")
        # New service groups must never disappear behind the currently qualified groups.
        if any(re.fullmatch(r".+ \(([7-9]|[1-9][0-9]+)\)", field) for field in headers):
            raise FjcError("FJC CSV has an unqualified repeated group")
        seen, end = set(), header["source"]["byte_length"]
        for ordinal, row in enumerate(rows):
            if ordinal >= MAX_RECORDS or len(row["fields"]) != len(headers):
                raise FjcError("FJC CSV row count or field count differs from its bound/header")
            fields = dict(zip(headers, row["fields"], strict=True))
            nid = fields["nid"]
            if not re.fullmatch(r"[0-9]+", nid) or nid in seen:
                raise FjcError("FJC native nid is missing, invalid or repeated")
            seen.add(nid)
            source = row["source"]
            end = source["byte_offset"] + source["byte_length"]
            yield {
                "id": f"fjc:{capture['response_sha256']}:{ordinal:020d}",
                "nid": nid,
                "ordinal": ordinal,
                "fields": fields,
                "source_locator": {**capture, **source, "csv_record_number": ordinal + 2},
            }
        if end != capture["byte_size"]:
            raise FjcError("FJC CSV byte coverage differs from the selected capture")
    except (csv.Error, UnicodeError) as error:
        raise FjcError("FJC CSV syntax or UTF-8 decoding failed") from error
