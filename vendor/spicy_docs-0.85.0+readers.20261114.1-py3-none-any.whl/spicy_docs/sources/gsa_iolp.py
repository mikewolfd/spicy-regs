"""Literal GSA IOLP catalog selections and workbook rows; property meaning belongs downstream.

The catalog currently distributes XLSX, despite describing CSV exports. Reuse the maintained bounded
OOXML cell reader. No formula evaluation, geographic repair or inference from a missing row occurs here.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import date
from typing import Any, cast
from urllib.parse import urlsplit

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.sources.scorecards.workbooks import literal_sheets

DATASET_ID = "GSA-4495"
MAX_CATALOG_BYTES = 1024**2
MAX_WORKBOOK_BYTES = 16 * 1024**2
HEADERS = {
    "buildings": (
        "Location Code",
        "Real Property Asset Name",
        "Installation Name",
        "Owned or Leased",
        "GSA Region",
        "Street Address",
        "City",
        "State",
        "Zip Code",
        "Latitude",
        "Longitude",
        "Building Rentable Square Feet",
        "Available Square Feet",
        "Construction Date",
        "Congressional District",
        "Congressional District Representative Name",
        "Building Status",
        "Real Property Asset Type",
    ),
    "leases": (
        "Location Code",
        "Real Property Asset Name",
        "Installation Name",
        "Federal Leased Code",
        "GSA Region",
        "Street Address",
        "City",
        "State",
        "Zip Code",
        "Latitude",
        "Longitude",
        "Building Rentable Square Feet",
        "Available Square Feet",
        "Congressional District",
        "Congressional District Representative",
        "Lease Number",
        "Lease Effective Date",
        "Lease Expiration Date",
        "Real Property Asset type",
    ),
}


def official_url(url: str) -> str:
    """Bound requests to Data.gov catalog records and their official inventory/S3 distributions.

    S3 query parameters may hold temporary signed access; callers must use the maintained credential scrubber
    for receipts and keep the catalog downloadURL as the durable locator.
    """
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.username or parts.password or parts.port or parts.fragment:
        raise ValueError("IOLP requires an official HTTPS URL")
    allowed = (
        parts.hostname == "catalog.data.gov"
        and re.fullmatch(r"/harvest_record/[0-9a-f-]+/raw", parts.path)
        or parts.hostname == "inventory.data.gov"
        and parts.path.startswith("/dataset/9a9e946e-124e-46f5-a934-e458a6c1c2b2/resource/")
        or parts.hostname == "s3-us-gov-west-1.amazonaws.com"
        and parts.path.startswith("/cg-ae4ac6ad-c789-4bb7-b830-7f1ebeebfd41/datagov/inventory-next/resources/")
    )
    if not allowed:
        raise ValueError("IOLP request left the official catalog/distribution locations")
    return url


def select_snapshot(body: bytes, snapshot_date: str) -> dict:
    """Select exactly the buildings/leases pair whose filenames state the caller's date.

    That date is a distribution label, not an inferred effective/as-of time. The older XML remains advertised
    metadata, outside this pair. Unknown catalog fields survive unchanged.
    """
    selected_date = date.fromisoformat(snapshot_date)
    raw_metadata = load_bounded_json(
        body,
        source="GSA IOLP catalog",
        error_type=ValueError,
        number_policy="finite-float",
        max_bytes=MAX_CATALOG_BYTES,
    )
    if not isinstance(raw_metadata, dict):
        raise ValueError("IOLP catalog record must be an object")  # noqa: TRY004 - malformed publisher JSON
    metadata = cast(dict[str, Any], raw_metadata)
    if (
        metadata.get("identifier") != DATASET_ID
        or not isinstance(metadata.get("publisher"), dict)
        or metadata.get("publisher", {}).get("name") != "General Services Administration"
        or not isinstance(metadata.get("distribution"), list)
    ):
        raise ValueError("Catalog does not identify the GSA IOLP dataset and distributions")
    distributions = {}
    for item in metadata["distribution"]:
        if not isinstance(item, dict):
            raise ValueError("IOLP distribution is not an object")  # noqa: TRY004 - malformed publisher JSON
        url = item.get("downloadURL", "")
        match = re.fullmatch(r"/(?:.*/)?(\d{4})-(\d{1,2})-(\d{1,2})-iolp-(buildings|leases)\.xlsx", urlsplit(url).path)
        if match is None:
            continue
        year, month, day, kind = match.groups()
        if date(int(year), int(month), int(day)) != selected_date:
            continue
        official_url(url)
        if urlsplit(url).query or kind in distributions:
            raise ValueError("IOLP snapshot repeats a distribution or uses a temporary download locator")
        if item.get("mediaType") != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            raise ValueError("IOLP selected distribution is not declared XLSX")
        distributions[kind] = item
    if set(distributions) != set(HEADERS):
        raise ValueError("Catalog does not state a complete buildings/leases pair for the selected snapshot date")
    return {
        "dataset_id": DATASET_ID,
        "snapshot_date": snapshot_date,
        "catalog": metadata,
        "distributions": distributions,
    }


@dataclass(frozen=True)
class Inventory:
    kind: str
    sheet: str
    headers: tuple[str, ...]
    rows: tuple[dict, ...]


def read_inventory(body: bytes, kind: str) -> Inventory:
    """Read every literal row, retaining coordinates, cell presence, formula facts and unknown columns.

    Missing/renamed required headers, duplicate headers/keys, unsupported sheets, formula/error cells and
    malformed row identities refuse the entire input. Header-only input is an observed empty snapshot.
    """
    if kind not in HEADERS or len(body) > MAX_WORKBOOK_BYTES:
        raise ValueError("Unsupported IOLP workbook kind or byte bound")
    sheets = literal_sheets(body)
    if len(sheets) != 1:
        raise ValueError("IOLP workbook requires one complete data worksheet")
    sheet, cells = next(iter(sheets.items()))
    by_row: dict[int, dict] = {}
    for coordinate, cell in cells.items():
        if cell.formula_attributes is not None or cell.kind == "e":
            raise ValueError("IOLP formula/error cell requires explicit source review")
        match = re.fullmatch(r"([A-Z]+)([0-9]+)", coordinate)
        if match is None:
            raise ValueError("IOLP cell has an invalid source coordinate")
        col, row = match.groups()
        by_row.setdefault(int(row), {})[col] = (coordinate, cell)
    header_cells = by_row.pop(1, {})
    headers = {col: cell.value for col, (_, cell) in header_cells.items()}
    if (
        not headers
        or any(not isinstance(value, str) or not value for value in headers.values())
        or len(set(headers.values())) != len(headers)
        or not set(HEADERS[kind]) <= set(headers.values())
    ):
        raise ValueError("IOLP schema changed: missing, blank or repeated required header")
    rows, seen = [], set()
    for row_number, raw in sorted(by_row.items()):
        if set(raw) - headers.keys():
            raise ValueError("IOLP row has a cell outside the declared headers")
        fields = {name: raw[col][1].value if col in raw else None for col, name in headers.items()}
        key = fields["Location Code"] if kind == "buildings" else fields["Lease Number"]
        if not isinstance(key, str) or not key.strip() or key in seen or not fields["Location Code"]:
            raise ValueError("IOLP native key is missing or repeated")
        seen.add(key)
        rows.append(
            {
                "native_id": key,
                "row_number": row_number,
                "fields": fields,
                "cells": {
                    headers[col]: {"coordinate": coordinate, **asdict(cell)} for col, (coordinate, cell) in raw.items()
                },
            }
        )
    return Inventory(kind, sheet, tuple(headers.values()), tuple(rows))


def acquire_snapshot(catalog_url: str, snapshot_date: str, *, transport=None):
    """Capture the selected metadata and complete pair through the maintained bounded redirect client.

    The caller may wrap ``transport`` with CaptureEvidence to retain originals before parsing. This reader
    does not schedule refreshes, choose a newer date, or write a publication pointer.
    """
    from spicy_docs.transport.download import BoundedAcquirer

    official_url(catalog_url)
    if urlsplit(catalog_url).hostname != "catalog.data.gov":
        raise ValueError("Select an official Data.gov harvest record for IOLP metadata")
    with BoundedAcquirer(validate_url=official_url, transport=transport, max_requests=16, timeout=30) as client:
        catalog = client.capture(catalog_url, max_bytes=MAX_CATALOG_BYTES)
        scope = select_snapshot(catalog.body, snapshot_date)
        captures = {}
        for kind, distribution in scope["distributions"].items():
            captured = client.capture(distribution["downloadURL"], max_bytes=MAX_WORKBOOK_BYTES)
            read_inventory(captured.body, kind)
            captures[kind] = captured
    return scope, catalog, captures
