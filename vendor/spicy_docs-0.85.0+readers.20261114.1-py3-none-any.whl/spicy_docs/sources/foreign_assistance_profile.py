"""Replay the exact country-summary original through the maintained release reader."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.foreign_assistance import (
    COLUMNS,
    MAX_BYTES,
    ForeignAssistanceError,
    summary_records,
    validate_scope,
)

SCOPE_ID = "foreign-assistance-country-summary-v1"
SCHEMA_NAME = "foreign-assistance-country-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
MAX_PAGE_RECORDS = 100
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["ordinal", "record_key", "raw", "source_locator"],
    "properties": {
        "ordinal": {"type": "integer", "minimum": 0},
        "record_key": {"type": "string"},
        "raw": {
            "type": "object",
            "required": list(COLUMNS),
            "properties": {key: {"type": "string"} for key in COLUMNS},
            "additionalProperties": False,
        },
        "source_locator": {"type": "object"},
    },
    "x-spicy-record-order": [
        {
            "fieldPath": "/record_key",
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
    ],
}


def _key(index):
    return f"foreign-assistance://country-summary/page/{index}"


def iter_retained_pages(scope, *, blob_source):
    capture = validate_scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, _key(0), capture["response_sha256"], capture["byte_size"], blob_source, "application/octet-stream"
    )


def _page(index, rows, terminal):
    return {"requestKey": _key(index), "page": index, "results": rows, "terminal": terminal}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = validate_scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["response_sha256"],
        capture["byte_size"],
        "application/octet-stream",
    ):
        raise ForeignAssistanceError("Foreign assistance evidence differs from the selected original")
    # The entire original is capped at MAX_BYTES; derived pages stay bounded too.
    body = stream.read(MAX_BYTES + 1)
    page, rows = 0, []
    for record in summary_records(body, scope=scope):
        if len(rows) == MAX_PAGE_RECORDS:
            yield _page(page, rows, False)
            page, rows = page + 1, []
        rows.append({**record, "record_key": f"{record['ordinal']:08d}"})
    yield _page(page, rows, True)


@dataclass
class _Traversal:
    pages: int = 0
    records: int = 0
    terminal: bool = False

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise ForeignAssistanceError("Foreign assistance pages are not contiguous")
        for row in response["results"]:
            if row["ordinal"] != self.records:
                raise ForeignAssistanceError("Foreign assistance original ordering differs")
            self.records += 1
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if not self.pages or not self.terminal:
            raise ForeignAssistanceError("Foreign assistance original did not finish")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise ForeignAssistanceError("Foreign assistance requires one complete original")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise ForeignAssistanceError("Foreign assistance original is unobserved")


def _window(key):
    if (
        not isinstance(key, str)
        or re.fullmatch(r"foreign-assistance://country-summary/page/(0|[1-9][0-9]*)", key) is None
    ):
        raise ForeignAssistanceError("Foreign assistance page key differs")
    return 0


def _record_scope(record, *, query_scope, page_window):
    capture = query_scope["capture"]
    locator = record["source_locator"]
    if (
        any(locator.get(key) != capture[key] for key in capture)
        or locator.get("record_number") != record["ordinal"] + 2
        or record["record_key"] != f"{record['ordinal']:08d}"
    ):
        raise ForeignAssistanceError("Foreign assistance record coordinates differ")


def _identity(row):
    raw = row["raw"]
    dimensions = [raw[key] for key in ("Country Code", "Country Name", "Fiscal Year", "Transaction Type ID")]
    return "foreign-assistance:" + hashlib.sha256(canonical_json_bytes(dimensions)).hexdigest()


def _byte_parser(_raw):
    raise ForeignAssistanceError("Foreign assistance requires its retained original stream")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


FOREIGN_ASSISTANCE_PROFILE = SourceNativeProfile(
    name="Retained ForeignAssistance.gov country summary",
    source_system_id="https://foreignassistance.gov/data",
    source_system_version="country-summary-csv",
    acquisition_policy_id="urn:spicy-docs:acquisition:foreign-assistance-country-summary",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="foreign-assistance",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "coverageLimits": [
            "Every row of the selected complete country-summary CSV; no transaction or agency/program drill-down.",
            "Capture time is not a publisher release date. Finality, completeness and constant-dollar base are unstated.",
            "The separately retained dictionary is pinned in scope and checked by the consumer build.",
            "An empty summary is observed-empty; an absent key in a later snapshot is unobserved, never deleted.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": _identity(row),
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=lambda response, **kwargs: True,
    acquisition_check=_Acquisition,
    page_window=_window,
)
