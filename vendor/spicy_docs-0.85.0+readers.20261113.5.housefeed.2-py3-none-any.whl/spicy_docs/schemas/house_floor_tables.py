"""House floor feed observations, entry revisions and literal link occurrences.

Capture time is separate from the publisher's entry dates. No row asserts that
a scheduled item passed, received a vote, or was enacted. A later snapshot adds
observations; it does not delete earlier entries missing from that snapshot.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import TYPE_CHECKING

from spicy_docs.schemas.tables import AT_JOINED_KEY, VALUE_KEY, Reference, digest, table_contract

if TYPE_CHECKING:
    from spicy_docs.sources.congress.house_floor import HouseFloorFeed

HOUSE_FLOOR_FEEDS = table_contract(
    "house_floor_feeds",
    grain="One explicitly observed complete House floor Atom capture, including a valid empty feed.",
    identity=("capture_id",),
    key_spelling=VALUE_KEY,
    version_column=None,
    columns={
        "capture_id": "Digest of source URI, capture time and original body digest; not the Atom feed ID.",
        "feed_id": "Publisher's Atom feed ID, kept literally.",
        "source_uri": "URI of the retained original; does not establish present availability.",
        "source_sha256": "SHA-256 of the complete original feed bytes.",
        "source_bytes": "Original byte size, as decimal text.",
        "observed_at": "Capture timestamp supplied by the retained receipt, separate from feed update time.",
        "title": "Publisher's feed title.",
        "subtitle": "Publisher's feed subtitle, or null when unstated.",
        "updated": "Literal Atom feed update time; not proof of current freshness.",
        "author": "Publisher's stated feed author name, or null when unstated.",
        "links_json": "All feed-level links, with literal href and resolution basis, as JSON.",
        "entry_count": "Observed direct entry occurrences, as decimal text; zero does not prove no House activity.",
        "parser_version": "Shared source reader identity.",
    },
)

HOUSE_FLOOR_ENTRIES = table_contract(
    "house_floor_entries",
    grain="One entry occurrence in one captured feed; repeated IDs and weekly-page URLs remain separate.",
    identity=("capture_id", "entry_index"),
    key_spelling=AT_JOINED_KEY,
    version_column=None,
    references=(Reference(("capture_id",), "house_floor_feeds", ("capture_id",)),),
    columns={
        "capture_id": "Owning complete feed observation.",
        "entry_index": "Zero-based entry position in this original, as decimal text.",
        "entry_id": "Publisher's Atom entry ID; never replaced with its weekly-page URL.",
        "entry_sha256": "Digest of the exact original entry XML slice, including its fields and extensions.",
        "title": "Publisher's entry title, including any update label.",
        "published": "Literal publisher entry publication time, or null when unstated.",
        "updated": "Literal publisher entry update time.",
        "weekly_url": "Publisher-stated weekly alternate page, resolved against explicit XML bases.",
        "week_date": "ISO date explicitly present in the weekly page's date query; a scheduled week, not a vote date.",
        "content_html": "Complete XML-decoded inline HTML, without sanitization, truncation or execution.",
        "content_sha256": "Digest of content_html encoded as UTF-8; original XML escaping remains in the entry slice.",
        "source_start": "Inclusive zero-based entry byte offset in the original feed, as decimal text.",
        "source_end": "Exclusive entry byte offset in the original feed, as decimal text.",
    },
)

HOUSE_FLOOR_LINKS = table_contract(
    "house_floor_links",
    grain="One literal link occurrence in one entry; repeated targets and revision history are retained.",
    identity=("capture_id", "entry_index", "link_index"),
    key_spelling=AT_JOINED_KEY,
    version_column=None,
    references=(Reference(("capture_id", "entry_index"), "house_floor_entries", ("capture_id", "entry_index")),),
    columns={
        "capture_id": "Owning complete feed observation.",
        "entry_index": "Owning zero-based entry occurrence, as decimal text.",
        "link_index": "Zero-based position: Atom links then HTML anchors in source order, as decimal text.",
        "href": "Literal publisher href, including relative spellings.",
        "resolved_url": "HTTP(S) URL resolved with base_url, or null for unsupported/invalid addresses; never fetched here.",
        "text": "Atom link title or anchor label with whitespace folded; surrounding HTML remains on the entry.",
        "rel": "Stated link relation, with Atom's absent-rel default alternate; empty for an unstated HTML relation.",
        "media_type": "Publisher-stated type, or null when unstated; not a verified response media type.",
        "basis": "atom_link or content_anchor, distinguishing the native field from the embedded HTML.",
        "base_url": "Resolution base: inherited XML base, or the House weekly page for its copied HTML fragment.",
        "repair_url": "Optional repaired target: one leading slash removed only when the exact absolute URL is stated elsewhere in this same feed. Original href and resolved_url stay unchanged.",
        "repair_basis": "Reason supporting repair_url, or null. This is parser interpretation, not proof of retrieval.",
    },
)

HOUSE_FLOOR_TABLES = {table.name: table for table in (HOUSE_FLOOR_FEEDS, HOUSE_FLOOR_ENTRIES, HOUSE_FLOOR_LINKS)}


def shape_house_floor_feed(feed: HouseFloorFeed, *, source_uri: str, observed_at: str) -> dict[str, list[dict]]:
    """Shape one complete read without choosing a latest revision or fetching its links."""
    from spicy_docs.sources.congress.house_floor import PARSER_VERSION

    if not source_uri or not observed_at:
        raise ValueError("House floor observation requires a retained source URI and capture timestamp")
    capture_id = digest(
        json.dumps([source_uri, observed_at, feed.source_sha256], ensure_ascii=False, separators=(",", ":"))
    )
    tables = {name: [] for name in HOUSE_FLOOR_TABLES}
    tables["house_floor_feeds"].append(
        {
            "capture_id": capture_id,
            "feed_id": feed.feed_id,
            "source_uri": source_uri,
            "source_sha256": feed.source_sha256,
            "source_bytes": str(feed.source_bytes),
            "observed_at": observed_at,
            "title": feed.title,
            "subtitle": feed.subtitle,
            "updated": feed.updated,
            "author": feed.author,
            "links_json": json.dumps([asdict(link) for link in feed.links], ensure_ascii=False, separators=(",", ":")),
            "entry_count": str(len(feed.entries)),
            "parser_version": PARSER_VERSION,
        }
    )
    for entry in feed.entries:
        row = {
            name: getattr(entry, name)
            for name in HOUSE_FLOOR_ENTRIES.columns
            if name not in {"capture_id", "entry_index"}
        }
        row.update(
            capture_id=capture_id,
            entry_index=str(entry.index),
            source_start=str(entry.source_start),
            source_end=str(entry.source_end),
        )
        tables["house_floor_entries"].append(row)
        for link in entry.links:
            row = asdict(link)
            row.update(capture_id=capture_id, entry_index=str(entry.index), link_index=str(row.pop("index")))
            tables["house_floor_links"].append(row)
    return tables
