"""Shared data shapes that flow between sources and transforms.

``base`` holds the generic :class:`RecordType` contract, the sibling modules hold the
domain record shapes and every published table's :class:`~spicy_docs.schemas.tables.TableContract`,
and the whole package is a stdlib-only leaf -- no pyarrow, no DeltaTrack, no ``sources.*``
or ``interpretation.*`` imports -- so spicy-regs can import a column tuple without pulling
an HTTP client or a model client.  See ``docs/tables.md``.
"""

from collections.abc import Mapping
from types import MappingProxyType

from spicy_docs.schemas.activity_events import PUBLIC_ACTIVITY_EVENTS
from spicy_docs.schemas.base import RecordType
from spicy_docs.schemas.bill_action_tables import BILL_COMMITTEE_ACTIONS
from spicy_docs.schemas.bill_diff_tables import (
    FINANCIAL_CHANGES,
    SECTION_DIFF_ITEMS,
    SECTION_DIFFS,
)
from spicy_docs.schemas.bill_model_tables import (
    BILL_SUMMARIES,
    DIFF_SUMMARIES,
    SECTION_CLASSIFICATIONS,
)
from spicy_docs.schemas.bill_tables import (
    BILL_ACTIONS,
    BILL_COMMITTEE_ACTIVITIES,
    BILL_COMMITTEES,
    BILL_COSPONSORS,
    BILL_PUBLISHER_SUMMARIES,
    CONGRESS_BILLS,
)
from spicy_docs.schemas.bill_version_tables import BILL_SECTIONS, BILL_VERSIONS
from spicy_docs.schemas.budget_volume_tables import BUDGET_VOLUMES
from spicy_docs.schemas.committee_report_tables import (
    COMMITTEE_REPORT_CBO_LETTERS,
    COMMITTEE_REPORTS,
    HEARING_TRANSCRIPTS,
    REPORT_SECTION_READER_VERSION,
    REPORT_SECTIONS,
)
from spicy_docs.schemas.congress_activity_tables import (
    AMENDMENTS,
    MEMBER_VOTES,
    PRESS_RELEASES,
    ROLL_CALL_VOTES,
)
from spicy_docs.schemas.congress_index_tables import (
    COMMITTEE_MEETINGS,
    HOUSE_COMMUNICATIONS,
    NOMINATIONS,
    RECORD_ISSUES,
    TREATIES,
)
from spicy_docs.schemas.cost_estimate_tables import CBO_COST_ESTIMATES, CBO_FEED_ITEMS
from spicy_docs.schemas.document_citation_tables import (
    DOCUMENT_CITATIONS,
    HOUSE_ACTIVITY_REPORTS,
)
from spicy_docs.schemas.fec_candidate_history import FEC_CANDIDATE_HISTORY
from spicy_docs.schemas.fec_committee_history import FEC_COMMITTEE_HISTORY
from spicy_docs.schemas.federal_register import FEDERAL_REGISTER
from spicy_docs.schemas.gao_decision_tables import GAO_DECISIONS
from spicy_docs.schemas.gao_recommendation_tables import GAO_RECOMMENDATIONS
from spicy_docs.schemas.hearing_bill_link_tables import HEARING_BILL_LINKS
from spicy_docs.schemas.law_tables import LAW_CODE_SECTIONS, LAW_SECTIONS, LAWS, TABLE3_RECORDS
from spicy_docs.schemas.legislator_tables import MEMBER_PARTY_AFFILIATIONS, MEMBER_TERMS, MEMBERS
from spicy_docs.schemas.native_reference_rows import NATIVE_LEGAL_REFERENCE_READS, NATIVE_LEGAL_REFERENCES
from spicy_docs.schemas.regulations import (
    COMMENT,
    COMMENTS,
    DOCKET,
    DOCKETS,
    DOCUMENT,
    DOCUMENTS,
    RECORD_TYPES,
)
from spicy_docs.schemas.regulations_attribute_tables import (
    COMMENT_ATTRIBUTES,
    DOCKET_ATTRIBUTES,
    DOCUMENT_ATTRIBUTES,
)
from spicy_docs.schemas.roster_tables import COMMITTEE_ASSIGNMENTS, COMMITTEES
from spicy_docs.schemas.scorecard_tables import SCORECARD_TABLES
from spicy_docs.schemas.senate_expenditure_tables import SENATE_EXPENDITURES
from spicy_docs.schemas.tables import COLUMN_TYPES, Reference, Row, TableContract, TableContractError

_REGISTERED: tuple[TableContract, ...] = (
    *SCORECARD_TABLES.values(),
    CONGRESS_BILLS,
    BILL_ACTIONS,
    BILL_COMMITTEES,
    # What each committee did and when, from the same document's committee list.
    BILL_COMMITTEE_ACTIVITIES,
    BILL_COSPONSORS,
    BILL_PUBLISHER_SUMMARIES,
    # The fifth table the same BILLSTATUS document fills (B4): the CBO
    # cost-estimate index, keyless where CBO's own site is walled.
    CBO_COST_ESTIMATES,
    # CBO's per-Congress feed itself, every item, read in the same pass as the
    # feed's estimate rows: what names no bill has no estimate row to hold it.
    CBO_FEED_ITEMS,
    BILL_VERSIONS,
    BILL_SECTIONS,
    SECTION_DIFFS,
    SECTION_DIFF_ITEMS,
    FINANCIAL_CHANGES,
    SECTION_CLASSIFICATIONS,
    BILL_SUMMARIES,
    DIFF_SUMMARIES,
    PUBLIC_ACTIVITY_EVENTS,
    AMENDMENTS,
    PRESS_RELEASES,
    ROLL_CALL_VOTES,
    MEMBER_VOTES,
    MEMBERS,
    MEMBER_TERMS,
    MEMBER_PARTY_AFFILIATIONS,
    COMMITTEE_REPORTS,
    COMMITTEE_REPORT_CBO_LETTERS,
    REPORT_SECTIONS,
    HEARING_TRANSCRIPTS,
    # Wave 2, gaps A5, A7 and A10: the Congress.gov index tables.
    HOUSE_COMMUNICATIONS,
    COMMITTEE_MEETINGS,
    RECORD_ISSUES,
    TREATIES,
    NOMINATIONS,
    # --- A8 laws and A9 rosters (law_tables, roster_tables) ---
    LAWS,
    LAW_SECTIONS,
    LAW_CODE_SECTIONS,
    TABLE3_RECORDS,
    COMMITTEES,
    COMMITTEE_ASSIGNMENTS,
    # The first PDF-only family contract and the shared link table it is built
    # on (the rollup's build order, step 1).
    DOCUMENT_CITATIONS,
    HOUSE_ACTIVITY_REPORTS,
    # The revised build order's first family: the budget volumes, whose print
    # names 504 public laws their own MODS does not (B4).
    BUDGET_VOLUMES,
    # The build order's step 4: the one PDF-only family whose value is a ruled
    # table and not a citation.
    SENATE_EXPENDITURES,
    # What the print states that no index does: the bill-action relationship,
    # hosted with its measured attachment reliability per row.
    BILL_COMMITTEE_ACTIONS,
    # A2 reopened: a hearing is held on a list, so the linkage is a table and
    # not a column, keyed on the source that stated each pair.
    HEARING_BILL_LINKS,
    # The Regulations.gov tables, keyed on the publisher's id so DocSpec can
    # admit a generation by reference (its decision 0007).
    DOCKETS,
    DOCUMENTS,
    COMMENTS,
    # What each document's, docket's and comment's detail record states beyond those thin tables, typed natively.
    DOCUMENT_ATTRIBUTES,
    DOCKET_ATTRIBUTES,
    COMMENT_ATTRIBUTES,
    # The Federal Register's own table: the dated records the Regulations.gov tables cite by number.
    FEDERAL_REGISTER,
    # The FEC committee master, one row per committee per cycle, from the bulk files.
    FEC_COMMITTEE_HISTORY,
    # The FEC candidate master, one row per candidate per cycle, from the bulk files.
    FEC_CANDIDATE_HISTORY,
    # Literal U.S. Code and eCFR reference observations, and each complete read of an input that produced them.
    NATIVE_LEGAL_REFERENCES,
    NATIVE_LEGAL_REFERENCE_READS,
    # GAO's open recommendations, one row per recommendation per agency, kept once they close.
    GAO_RECOMMENDATIONS,
    GAO_DECISIONS,
)

if len({contract.name for contract in _REGISTERED}) != len(_REGISTERED):
    raise AssertionError("TABLE_CONTRACTS has a duplicate table name")

#: Every published table by name.  spicy-regs reads this to build its Arrow
#: schemas, its merge calls, its data-dictionary entries and its MCP view list,
#: so a table added here reaches all four without a second declaration.
TABLE_CONTRACTS: Mapping[str, TableContract] = MappingProxyType({c.name: c for c in _REGISTERED})

# A reference names a row of another published table, so it must name a
# registered table by exactly that table's identity.
for _contract in _REGISTERED:
    for _reference in _contract.references:
        _parent = TABLE_CONTRACTS.get(_reference.parent_table)
        if _parent is None or _reference.parent_columns != _parent.identity:
            raise TableContractError(
                f"{_contract.name}: a reference must name a registered table by its identity, "
                f"not {_reference.parent_table}{_reference.parent_columns}"
            )

__all__ = [
    "AMENDMENTS",
    "BILL_ACTIONS",
    "BILL_COMMITTEES",
    "BILL_COMMITTEE_ACTIONS",
    "BILL_COMMITTEE_ACTIVITIES",
    "BILL_COSPONSORS",
    "BILL_PUBLISHER_SUMMARIES",
    "BILL_SECTIONS",
    "BILL_SUMMARIES",
    "BILL_VERSIONS",
    "BUDGET_VOLUMES",
    "CBO_COST_ESTIMATES",
    "CBO_FEED_ITEMS",
    "COLUMN_TYPES",
    "COMMENT",
    "COMMENTS",
    "COMMENT_ATTRIBUTES",
    "COMMITTEES",
    "COMMITTEE_ASSIGNMENTS",
    "COMMITTEE_MEETINGS",
    "COMMITTEE_REPORTS",
    "COMMITTEE_REPORT_CBO_LETTERS",
    "CONGRESS_BILLS",
    "DIFF_SUMMARIES",
    "DOCKET",
    "DOCKETS",
    "DOCKET_ATTRIBUTES",
    "DOCUMENT",
    "DOCUMENTS",
    "DOCUMENT_ATTRIBUTES",
    "DOCUMENT_CITATIONS",
    "FEC_COMMITTEE_HISTORY",
    "FEDERAL_REGISTER",
    "FINANCIAL_CHANGES",
    "GAO_DECISIONS",
    "GAO_RECOMMENDATIONS",
    "HEARING_BILL_LINKS",
    "HEARING_TRANSCRIPTS",
    "HOUSE_ACTIVITY_REPORTS",
    "HOUSE_COMMUNICATIONS",
    "LAWS",
    "LAW_CODE_SECTIONS",
    "LAW_SECTIONS",
    "MEMBERS",
    "MEMBER_PARTY_AFFILIATIONS",
    "MEMBER_TERMS",
    "MEMBER_VOTES",
    "NATIVE_LEGAL_REFERENCES",
    "NATIVE_LEGAL_REFERENCE_READS",
    "NOMINATIONS",
    "PRESS_RELEASES",
    "PUBLIC_ACTIVITY_EVENTS",
    "RECORD_ISSUES",
    "RECORD_TYPES",
    "REPORT_SECTIONS",
    "REPORT_SECTION_READER_VERSION",
    "ROLL_CALL_VOTES",
    "SECTION_CLASSIFICATIONS",
    "SECTION_DIFFS",
    "SECTION_DIFF_ITEMS",
    "SENATE_EXPENDITURES",
    "TABLE3_RECORDS",
    "TABLE_CONTRACTS",
    "TREATIES",
    "RecordType",
    "Reference",
    "Row",
    "TableContract",
    "TableContractError",
]
