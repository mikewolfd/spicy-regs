"""Whether a committee report reprints CBO cost-estimate letters, where each one is, and why there is none.

Reads the normalized text of one GovInfo ``CRPT`` body and returns one
:class:`CboEstimateFinding` naming the rule and its version, what the report's
cover declared, every reprinted letter's span and digest, and -- where there is
none -- the publisher's own paragraph saying why. The gate is the cover recital
``[Including cost estimate of the Congressional Budget Office]`` (Rule XIII cl.
3(a)(1)(B)), never a heading: measured reports print a CBO heading over a
section saying the estimate was not received, and one writes an estimate under
a heading no pattern knows. Each letter is anchored on its close -- the
signature CBO printed -- and opens at the last heading or CBO letterhead above
it, so an omnibus report's letters are each found (CRPT-105hrpt149 has 11).
A letter's date is its letterhead's dateline (``Washington, DC, June 16,
1997.``); a 118th-Congress letter prints none, and its date is CBO's own
``pubDate``, already published, so ``letter_date`` is NULL there rather than
guessed. Absence reasons are read whether or not a heading precedes them.
"""

from __future__ import annotations

import json
import re
from bisect import bisect_left, bisect_right
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from datetime import date

from spicy_docs.interpretation.citations import bill_type_and_number
from spicy_docs.schemas.tables import digest, natural_key

#: This rule's name, published on every row it fills.
CBO_ESTIMATE_RULE = "cbo_cost_estimate_letter"


class CboEstimateError(ValueError):
    """The text handed to the rule is not one document's text."""


@dataclass(frozen=True, slots=True)
class LetterPattern:
    """One named pattern, and the reason it exists.

    ``rejects`` are the lookalikes the pattern must not match, asserted in
    ``tests/test_cbo_estimates.py`` so a pattern that widened into prose fails
    a check rather than raising a hit rate.
    """

    name: str
    pattern: str
    reason: str
    rejects: tuple[str, ...] = ()
    flags: int = 0

    def compiled(self, flags: int = 0) -> re.Pattern[str]:
        return re.compile(self.pattern, self.flags | flags)


#: The statutory cover recital, matched as a whole printed line.  Structural
#: rather than positional: prose that quotes the phrase runs inline, and the
#: cover prints it alone between blank lines.  Measured: exactly one
#: occurrence in each of the 7 bodies that carry it, always on the cover.
COVER_RECITAL = LetterPattern(
    "cover_recital",
    r"^[ \t]*\[Including cost estimate of the Congressional Budget Office\][ \t]*$",
    "Rule XIII cl. 3(a)(1)(B): the one statement, identical in both chambers, that the report contains "
    "the estimate. The only gate; a heading is never one.",
    rejects=(
        "  the cost estimate of the Congressional Budget Office was not available",
        "  [Including cost estimate of the Joint Committee on Taxation]",
    ),
    flags=re.MULTILINE,
)

#: The cover's own statement of which measure the report accompanies, printed
#: the same way and two lines above the recital.  This is the print's side of
#: the report-to-bill join the estimate index needs; see ``recital_bill_id``.
ACCOMPANIES = LetterPattern(
    "accompanies",
    r"^[ \t]*\[To accompany ([^\]\n]+)\][ \t]*$",
    "Rule XIII cl. 3(a)(1)(A): the measure the report accompanies, which is what joins a report row to "
    "cbo_cost_estimates.bill_id.",
    rejects=("The report [To accompany H.R. 801] is on the calendar.",),
    flags=re.MULTILINE,
)

#: Where a declared letter *starts*.  A floor by construction and used only
#: after the recital has already decided the report states an estimate: these
#: are committee-specific section titles, and CRPT-118hrpt111 proves the set
#: can miss one.  Matched against a heading block's collapsed text, so a
#: heading GPO wrapped across two centered lines -- CRPT-118hrpt951's
#: ``V. COST ESTIMATE PREPARED BY THE CONGRESSIONAL`` / ``BUDGET OFFICE`` --
#: is one heading and not two lines of nothing.
HEADINGS: tuple[LetterPattern, ...] = (
    LetterPattern(
        "cbo_cost_estimate",
        r"congressional budget office cost estimates?",
        "the commonest spelling; measured on CRPT-118hrpt276, -118hrpt780, -118hrpt930, -118srpt289 and -118srpt298; "
        "CRPT-105hrpt149 prints the plural over its Banking letter",
    ),
    LetterPattern(
        "cbo_estimate",
        r"congressional budget office estimate",
        "the shorter spelling; measured on CRPT-118hrpt53, and on -118hrpt18 and -118hrpt21 over a section "
        "that says the estimate was not received",
    ),
    LetterPattern(
        "cost_estimate_prepared_by_cbo",
        r"cost estimate prepared by the congressional budget office",
        "the spelling the five-pattern set in the routes measurement missed; measured on CRPT-118hrpt111 and, "
        "wrapped across two lines, on -118hrpt951",
    ),
    LetterPattern(
        "committee_cost_estimate",
        r"committee cost estimate",
        "Rule XIII cl. 3(d)(1)'s heading, under which a committee adopts CBO's estimate as its own; measured "
        "on CRPT-118hrpt18 and -118hrpt21",
    ),
    LetterPattern(
        "estimated_costs",
        r"estimated costs?",
        "an older committee spelling recorded by the routes measurement's heading census",
    ),
    LetterPattern(
        "cost_of_legislation",
        r"cost of legislation and the congressional budget act",
        "the numbered-section spelling recorded by the same census",
    ),
    LetterPattern(
        "statement_of_cbo_cost_estimate",
        r"statement of cbo cost estimate",
        "CRPT-105hrpt149's Government Reform title: the numbered ``VII. STATEMENT OF CBO COST ESTIMATE``",
    ),
)

#: A signatory's name: two to five tokens, each a capitalised word, a
#: single-letter initial or a surname particle (``Paul Van de Water``), after
#: an optional honorific.  The apostrophe may be ASCII or U+2019: the
#: pipeline's PDF text of CRPT-105hrpt149 prints ``O'NEILL`` while
#: ``pdftotext`` of the same page prints ``O’NEILL``.  A word may not *end* in
#: a period -- the sentence before the House signature block closes
#: ``...Deputy Director of Budget Analysis.``, and a looser token read that
#: back as part of the name on 3 of the 5 measured signatures.
_NAME = (
    r"(?:(?:Mrs?|Ms|Dr)\.[ \t]+)?(?:[A-Z]\.|[A-Z][A-Za-z'’-]*)"
    r"(?:[ \t]+(?:[A-Z]\.|[A-Z][A-Za-z'’-]*|de|van)){1,4}"
)

#: Where a declared letter *ends*: the attribution CBO signs it with.  One
#: pattern covers both measured 118th-Congress styles -- the House letter's
#: ``Phillip L. Swagel,`` / ``Director, Congressional Budget Office.``
#: signature block, the parenthesised ``(For Phillip L. Swagel, Director,
#: Congressional Budget Office).`` of CRPT-118hrpt780, and the newer
#: ``Estimate approved by:`` attribution of CRPT-118hrpt930 and -118srpt289 --
#: because all three end in the same comma-then-Director phrase.  The comma is
#: what separates it from the prose ``the Director of the Congressional Budget
#: Office``; the end of line is what separates it from an addressee block,
#: which continues ``..., U.S. Congress, Washington,`` (CRPT-105hrpt148's Joint
#: Committee on Taxation letter *to* the Director).
DIRECTOR_ATTRIBUTION = LetterPattern(
    "director_attribution",
    r"Director,[ \t]*\n?[ \t]*Congressional(?:[ \t]+|[ \t]*\n[ \t]*)Budget Office\)?\.?[ \t]*$",
    "the letter's own close; PDF CRPT-118hrpt930 and -118srpt289 wrap after Congressional; "
    "6 of the 7 recital-declared HTM bodies end here",
    rejects=(
        "the estimate prepared by the Director of the Congressional Budget Office",
        "an estimate and comparison prepared by the Director of the Congressional\nBudget Office",
        "Director, CongressionalBudget Office.",
        "Director, Congressional\n\nBudget Office.",
        "Mrs. JUNE O'NEILL,\nDirector, Congressional Budget Office, U.S. Congress, Washington,",
    ),
    flags=re.MULTILINE,
)

#: The 1997-2009 delegated close: a deputy signs for the Director, who is the
#: name the letter states.  Measured on CRPT-105hrpt149 (``PAUL VAN DE WATER``
#: / ``(For June E. O'Neill, Director).``) and CRPT-111hrpt385-pt1 (``(For
#: Douglas W. Elmendorf, Director).``).
FOR_DIRECTOR = LetterPattern(
    "for_director",
    r"\([Ff]or (?P<name>" + _NAME + r"), Director(?:\)\.|\.\))",
    "the delegated close of 1997-2009 letters, which the 118th-Congress attribution cannot match; "
    "CRPT-105hrpt537 prints ``(for``, CRPT-105hrpt625-pt2 ``Director.)``",
    rejects=(
        "(For Phillip L. Swagel, Director, Congressional Budget Office).",
        "(for the Director).",
    ),
)

#: The same delegated close without the title, measured once: CRPT-105hrpt149's
#: Government Reform letter, ``PAUL VAN DE WATER,`` / ``(for June E.
#: O'Neill).``.  A whole line, and accepted only under a CBO letterhead.
FOR_DIRECTOR_UNNAMED_TITLE = LetterPattern(
    "for_director_unnamed_title",
    r"^[ \t]*\([Ff]or (?P<name>" + _NAME + r")\)\.[ \t]*$",
    "the delegated close that states the Director's name and no title; CRPT-105hrpt149 letter 7",
    rejects=(
        "(for June E. O'Neill, Director).",
        "    (for June E. O'Neill). Sincerely,",
    ),
    flags=re.MULTILINE,
)

#: The Director's own close of 1997-2009 letters, ``JUNE E. O'NEILL,
#: Director.`` (9 letters in CRPT-105hrpt149) or ``DOUGLAS HOLTZ-EAKIN,`` /
#: ``Director.`` (CRPT-109hrpt151).  Every agency head signs this way, so it is
#: accepted only under a CBO letterhead: CRPT-105hrpt149 also reprints an OMB
#: letter closing ``FRANKLIN D. RAINES, Director.``.
NAMED_DIRECTOR = LetterPattern(
    "named_director",
    r"^[ \t]*(?P<name>" + _NAME + r"),[ \t]*\n?[ \t]*Director\.[ \t]*$",
    "the 1997-2009 Director's own close, which names no office and so needs the CBO letterhead",
    rejects=(
        "the Deputy Director.",
        "Hon. JUNE O'NEILL,\nDirector, Congressional Budget Office.",
    ),
    flags=re.MULTILINE,
)

#: The Director's close with no title at all, ``Sincerely,`` / ``DOUGLAS W.
#: ELMENDORF.`` (CRPT-112hrpt80, -81, -83 and -85).  The ``Sincerely,`` line
#: is part of the pattern, and it too is accepted only under a CBO letterhead:
#: CRPT-106hrpt238 reprints an IRS letter closing ``CHARLES O. ROSSOTTI.``.
NAMED_SIGNATURE = LetterPattern(
    "named_signature",
    r"^[ \t]*Sincerely,[ \t]*\n[ \t]*(?P<name>" + _NAME + r")\.[ \t]*$",
    "the 2011 Director's close, which states only a name and so needs the CBO letterhead",
    rejects=(
        "Sincerely,\nHENRY J. HYDE,\nChairman.",
        "Sincerely,\n\nDOUGLAS W. ELMENDORF.",
    ),
    flags=re.MULTILINE,
)

#: A transmittal is followed by ``Enclosure.`` -- the estimate itself -- in
#: every 1997-2009 letter that has one; up to three blank or page-number
#: lines may fall between.  Matched at the close's end, never searched.
#: Tracked count (2026-10-31, 202 retained PDF bodies): 5 of 117 letters print
#: ``Enclosure.`` after a close but neither an approval line nor a heading of
#: their opening series before the next letter, so they stay the bare
#: transmittal and say so in their end rule (one in CRPT-105hrpt149,
#: -105hrpt272, -105hrpt332, -105hrpt467-pt3, -107hrpt262-pt2).
ENCLOSURE = LetterPattern(
    "enclosure",
    r"[ \t]*\n(?:[ \t]*[0-9]*[ \t]*\n){0,3}[ \t]*Enclosures?\.?[ \t]*$",
    "the transmittal's own statement that the estimate follows it; bridges a transmittal to the estimate's approval",
    rejects=("\n    The enclosed estimate shows",),
    flags=re.MULTILINE,
)

#: Where an enclosed estimate ends: its approval line, ``Estimate approved by:
#: Paul N. Van de Water, Assistant Director`` / ``for Budget Analysis.``, or
#: CRPT-105hrpt149's ``Estimate approved by.—Joseph Antos, Assistant Director
#: for`` / ``Health and Human Resources.``, or the prose ``This es-`` /
#: ``timate was approved by`` of CRPT-105hrpt23-pt1 and -109hrpt151, or
#: CRPT-106hrpt467-pt1's misprinted ``Estimated approved by:``, or ``Estimate
#: Approved by:``, or ``This estimate was prepared by NAME and approved by``,
#: or CRPT-105hrpt738's ``This estimate was ap-`` / ``proved by``, or
#: CRPT-106hrpt673-pt1, -106hrpt862-pt1 and -112hrpt80's ``This esti-`` /
#: ``mate was approved by``.  Measured over the 202 retained PDF and 199
#: committee-reports HTM bodies with a pattern that knows no ``estimate``
#: spelling (any ``ap-?proved by`` followed by a Director title): every CBO
#: approval line matches but the 118th Director's own and one HTM
#: ``Estiamte approved by`` on a report whose cover declares no estimate,
#: which therefore bounds no letter.  The title is not a closed set
#: (``Budget``, ``Tax``, ``Health and Human Resources``, ``Budget and
#: Analysis``), so the line ends at the first period that ends a printed line,
#: without crossing a blank line.  It may never cross ``Congressional``: the
#: 118th-Congress ``Estimate approved by: Phillip L. Swagel, Director,
#: Congressional Budget Office.`` is ``director_attribution``'s.  Only an end
#: when it follows a bridged transmittal; it never opens a letter.
ESTIMATE_APPROVAL = LetterPattern(
    "estimate_approval",
    r"(?:^[ \t]*Estimated? [Aa]pproved by|(?:This|The)\s+es-?\s*ti-?\s*mate\s+was\s+(?:prepared\s+by[^.\n]{1,80}?\s+and\s+)?ap-?\s*proved\s+by)"
    r"(?:(?!Congressional)[^\n.]|\.(?![ \t]*$)|\n(?![ \t]*\n)){1,400}?\.[ \t]*$",
    "the enclosed estimate's own close, so a 1997-2009 letter's span holds the estimate and not only its transmittal",
    rejects=(
        "Estimate approved by: Phillip L. Swagel, Director, Congressional\nBudget Office.",
        "The estimate approved by the Committee differs.",
        "Estimate approved by:\n\nPeter H. Fontaine.",
    ),
    flags=re.MULTILINE,
)

#: A CBO letterhead: ``U.S. CONGRESS,`` / ``CONGRESSIONAL BUDGET OFFICE,`` /
#: ``Washington, DC, June 16, 1997.``, flush in PDF text and centered in HTM.
#: Where a 1997-2009 letter starts when no heading precedes it, and what a
#: bare ``NAME, Director.`` close must sit under.
LETTERHEAD = LetterPattern(
    "letterhead",
    r"^[ \t]*(?:U\.S\. Congress,[ \t]*\n[ \t]*)?Congressional Budget Office,[ \t]*\n[ \t]*Washington,? ?D\.? ?C\.?,",
    "the CBO letter's own opening; 11 in CRPT-105hrpt149, one per letter",
    rejects=(
        "Director, Congressional Budget Office, U.S. Congress, Washington, DC.",
        "EXECUTIVE OFFICE OF THE PRESIDENT,\nOFFICE OF MANAGEMENT AND BUDGET,\nWashington, DC, June 10, 1997.",
    ),
    flags=re.MULTILINE | re.IGNORECASE,
)

_MONTHS = (
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
)  # fmt: skip

#: The date a CBO letterhead's dateline prints, read at the letterhead's end:
#: ``June 16, 1997.`` in every one of the 202 retained PDF and 199 HTM bodies
#: but CRPT-105hrpt149's ``June 16. 1997.``.  A dateline that does not read as
#: a calendar date publishes a NULL ``letter_date`` rather than a repaired one.
LETTER_DATE = LetterPattern(
    "letter_date",
    r"[ \t]*(?P<month>" + "|".join(_MONTHS) + r")"
    r"[ \t]+(?P<day>[0-9]{1,2})[,.][ \t]*(?P<year>[0-9]{4})\.",
    "the letter's own date, which a 1997-2011 letterhead prints and a 118th-Congress letter does not",
    rejects=("June 1997.", "June 16 1997.", "Junior 16, 1997."),
)

#: Any letter's dateline.  A ``NAME, Director.`` close belongs to the letter
#: whose dateline is the nearest one above it, so it is CBO's only when that
#: dateline is a CBO letterhead's.
DATELINE = LetterPattern(
    "dateline",
    r"^[ \t]*Washington,? ?D\.? ?C\.?,",
    "the dateline every reprinted letter prints; the OMB letter in CRPT-105hrpt149 has one, under no CBO letterhead",
    rejects=("cent to Washington, D.C., Union Station at fair market value",),
    flags=re.MULTILINE,
)

#: The closes that count only under a CBO letterhead.
_NEEDS_LETTERHEAD = frozenset({FOR_DIRECTOR_UNNAMED_TITLE.name, NAMED_DIRECTOR.name, NAMED_SIGNATURE.name})

#: Who signed, read out of the 118th-Congress attribution.  ``(For `` is
#: consumed rather than captured.  The 1997-2009 closes carry their own
#: ``name`` group.
SIGNATORY = LetterPattern(
    "signatory",
    r"(?:\(For )?(?P<name>" + _NAME + r"), Director, Congressional Budget Office",
    "the Director as the letter names them; NULL where the attribution states no name",
)

#: The publisher's own reason, where the cover declares nothing.  Each pattern
#: is a phrase the report writes about CBO; the paragraph around it is what is
#: returned, because the publisher's unit is the paragraph and a sentence
#: splitter over GPO's fixed-width text invents boundaries.
ABSENCE_REASONS: tuple[LetterPattern, ...] = (
    LetterPattern(
        "not_available",
        r"was not available",
        "CRPT-118hrpt18 and -118hrpt21: the estimate had not arrived when the report was filed",
        rejects=("[GRAPHIC(S) NOT AVAILABLE IN TIFF FORMAT]",),
        flags=re.IGNORECASE,
    ),
    LetterPattern(
        "not_received",
        r"requested but not received",
        "CRPT-118hrpt58 and -118hrpt111: the committee asked and CBO had not answered",
        flags=re.IGNORECASE,
    ),
)

#: A reason paragraph must also name CBO.  Without it ``was not available``
#: reads a dropped graphic, an absent witness or an unavailable document as a
#: missing cost estimate; all four measured reasons name the office.
_REASON_REQUIRES = re.compile(r"Congressional\s+Budget\s+Office", re.IGNORECASE)

#: A heading block's optional numbering token, and the series it belongs to.
#: The series is what the end fallback matches on: a letter whose heading is
#: ``VI.`` ends at the next roman-numbered heading, never at a stray indented
#: line.
_NUMBERING = re.compile(r"^(?:(?P<roman>[IVXL]+)|(?P<letter>[A-Z])|(?P<arabic>[0-9]+))\.\s+")

#: A heading block: consecutive lines, every one indented, none carrying the
#: dot leaders a table of contents prints.  Four spaces is GPO's paragraph
#: indent, and a paragraph's continuation lines start at column zero, so
#: requiring *every* line to be indented separates a centered heading from
#: body text without guessing a centering width.
_MIN_HEADING_INDENT = 4
_MAX_HEADING_LINES = 3
_MAX_HEADING_CHARS = 120
_DOT_LEADER = re.compile(r"\.{4,}")
_WHITESPACE = re.compile(r"\s+")
_PARAGRAPH_BREAK = re.compile(r"\n{2,}")
_HEADING_TRAILING_CHARS = "."
# Bump for control-flow changes not represented by the patterns/thresholds.
_RULE_REVISION = 3


@dataclass(frozen=True, slots=True)
class HeadingBlock:
    """One centered heading, collapsed to a single line, with its span and numbering series."""

    text: str
    span: tuple[int, int]
    series: str | None


def heading_blocks(text: str) -> Iterator[HeadingBlock]:
    """Indented heading blocks and flush uppercase lines, in document order."""
    start = 0
    block: list[str] = []
    block_start = 0
    for line in text.split("\n"):
        end = start + len(line)
        indented = line.strip() and len(line) - len(line.lstrip(" \t")) >= _MIN_HEADING_INDENT
        if indented and not _DOT_LEADER.search(line):
            if not block:
                block_start = start
            block.append(line.strip())
        else:
            if block:
                yield from _heading(block, block_start, start - 1)
            block = []
            # Native PDF text loses indentation and blank paragraph lines.
            # Its four retained section titles are whole uppercase lines;
            # prose and contents entries must still fail the exact vocabulary.
            if line == line.lstrip() and line.isupper() and not _DOT_LEADER.search(line):
                yield from _heading([line], start, end)
        start = end + 1
    if block:
        yield from _heading(block, block_start, len(text))


def _heading(lines: Sequence[str], start: int, end: int) -> Iterator[HeadingBlock]:
    if len(lines) > _MAX_HEADING_LINES:
        return
    collapsed = " ".join(lines)
    if len(collapsed) > _MAX_HEADING_CHARS:
        return
    numbering = _NUMBERING.match(collapsed)
    series = None
    if numbering is not None:
        series = next(name for name, value in numbering.groupdict().items() if value)
        collapsed = collapsed[numbering.end() :]
    yield HeadingBlock(collapsed, (start, end), series)


@dataclass(frozen=True, slots=True)
class CboLetter:
    """One reprinted CBO letter: where it is, what opened and closed it, and who signed it.

    ``heading_rule`` is a ``HEADINGS`` name, or ``letterhead`` where the letter
    opens on its CBO letterhead because no heading precedes it.  ``end_rule``
    is the close's pattern name; ``<close>+estimate_approval`` where a
    transmittal's enclosed estimate runs on to its approval line, or
    ``<close>+next_heading_in_series`` where it prints none, so a span ending
    at a bare transmittal close is visibly one without the estimate.
    """

    span: tuple[int, int]
    sha256: str
    heading: str | None
    heading_rule: str
    end_rule: str
    signatory: str | None
    letter_date: str | None = None


@dataclass(frozen=True, slots=True)
class CboEstimateFinding:
    """What one committee report says about its CBO cost estimate.

    ``report_states_estimate`` is the report's own cover declaration and
    nothing else; ``letters`` holds every reprinted letter located, in
    document order, and is empty unless that declaration was made *and* both
    ends of a reprint were located, so a declared letter whose end could not be
    found returns the declaration with no span rather than an invented
    boundary; ``absence_reason`` is the publisher's paragraph, verbatim, read
    whether or not a heading precedes it.

    ``heading`` is the part's first vocabulary heading where no located letter
    opens on it -- a part-level fact, read whether or not the cover declares an
    estimate, so a report with no located letter still names where an estimate
    was announced (110 undeclared and 5 declared parts of live generation
    670476640e83 publish one), and a committee's own ``COMMITTEE COST
    ESTIMATE`` section printed before a letter that opens elsewhere keeps it
    (CRPT-108hrpt437).  ``None`` where that first heading opens a letter: it is
    then that letter's fact, on its :class:`CboLetter` only, the one row per
    letter ``committee_report_cbo_letters`` publishes.
    """

    rule: str
    rule_version: str
    report_states_estimate: bool
    recital_span: tuple[int, int] | None
    accompanies: str | None
    heading: str | None
    heading_rule: str | None
    absence_reason: str | None
    absence_span: tuple[int, int] | None
    absence_rule: str | None
    letters: tuple[CboLetter, ...] = ()


def _rule_version(patterns: Sequence[LetterPattern] | None = None) -> str:
    """Digest all pattern text, flags, rejects, heading thresholds and rule revision.

    Derived, not written, for the reason ``citations._rule_set_version`` is:
    editing a pattern moves this even when nobody remembers to. The rejects are
    in the input because a reject that is no longer asserted cannot fail, so
    deleting one changes the rule.
    """
    rules = _letter_patterns() if patterns is None else patterns
    payload = {
        "patterns": [(p.name, p.pattern, p.flags, p.rejects) for p in rules],
        "guards": [
            (p.pattern, p.flags) for p in (_REASON_REQUIRES, _NUMBERING, _DOT_LEADER, _WHITESPACE, _PARAGRAPH_BREAK)
        ],
        "heading_limits": (_MIN_HEADING_INDENT, _MAX_HEADING_LINES, _MAX_HEADING_CHARS),
        "heading_trailing_chars": _HEADING_TRAILING_CHARS,
        "revision": _RULE_REVISION,
    }
    return digest(json.dumps(payload, sort_keys=True))[7:19]


def _transmittals() -> tuple[LetterPattern, ...]:
    """Transmittal closes, in precedence order where two overlap."""
    return (DIRECTOR_ATTRIBUTION, FOR_DIRECTOR, FOR_DIRECTOR_UNNAMED_TITLE, NAMED_DIRECTOR, NAMED_SIGNATURE)


def _letter_patterns() -> tuple[LetterPattern, ...]:
    return (
        COVER_RECITAL,
        ACCOMPANIES,
        *HEADINGS,
        *_transmittals(),
        ENCLOSURE,
        ESTIMATE_APPROVAL,
        LETTERHEAD,
        LETTER_DATE,
        DATELINE,
        SIGNATORY,
        *ABSENCE_REASONS,
    )


#: Every pattern this rule runs, in the order it runs them.
LETTER_PATTERNS: tuple[LetterPattern, ...] = _letter_patterns()

#: The identity of the whole rule, published beside every span it produced.
CBO_ESTIMATE_RULE_VERSION = _rule_version(LETTER_PATTERNS)


def _match_heading(block: HeadingBlock) -> str | None:
    folded = block.text.casefold().rstrip(_HEADING_TRAILING_CHARS)
    return next((p.name for p in HEADINGS if p.compiled().fullmatch(folded)), None)


def _paragraphs(text: str) -> Iterator[tuple[int, int]]:
    """Scan blank-line-bounded paragraphs once, preserving their exact spans.

    The publisher's own unit: a sentence splitter over GPO's fixed-width text
    would have to guess where a line break ends a sentence, and these reasons
    run to four printed lines.
    """
    start = 0
    for boundary in _PARAGRAPH_BREAK.finditer(text):
        yield start, boundary.start()
        start = boundary.end()
    yield start, len(text)


def _absence(text: str) -> tuple[str | None, tuple[int, int] | None, str | None]:
    patterns = [p.compiled() for p in ABSENCE_REASONS]
    found: dict[int, tuple[str, tuple[int, int], str]] = {}
    for start, end in _paragraphs(text):
        paragraph = text[start:end]
        if not _REASON_REQUIRES.search(paragraph):
            continue
        for index, pattern in enumerate(patterns):
            if index not in found and pattern.search(paragraph):
                found[index] = (paragraph.strip(), (start, end), ABSENCE_REASONS[index].name)
    if found:
        # Rule priority precedes document order, as in the original reader.
        return found[min(found)]
    return None, None, None


#: The end rule of a span bounded by the next heading of its opening heading's numbering series.
_NEXT_HEADING_IN_SERIES = "next_heading_in_series"


def _letter_end(heading: HeadingBlock, blocks: Sequence[HeadingBlock]) -> tuple[int, str] | None:
    """Where a heading-opened letter with no recognized close ends: the next heading in the same series.

    The fallback for a declared report in which no close was found at all.
    Measured once: CRPT-118srpt298's estimate is a summary table rather than a
    letter under a numbered heading, so it ends at the next heading of that
    same series. An *unnumbered* heading gets no fallback: nothing measured
    needs one and a stray indented line is not a boundary worth guessing.
    """
    if heading.series is None:
        return None
    for block in blocks:
        if block.span[0] > heading.span[1] and block.series == heading.series:
            return block.span[0], _NEXT_HEADING_IN_SERIES
    return None


@dataclass(frozen=True, slots=True)
class _Close:
    start: int
    end: int
    rule: str
    name: str | None


def _closes(text: str, after: int, letterheads: Sequence[re.Match[str]], datelines: Sequence[int]) -> list[_Close]:
    """Every transmittal close after the recital, in document order, overlaps resolved by precedence.

    A ``NAME, Director.`` or ``(for NAME).`` close is kept only where the
    nearest dateline above it is a CBO letterhead's.  The caller scans the
    letterheads and datelines once and passes them in; closes look them up
    by bisection, so this is linear in the text plus ``k log k`` in the closes.
    """
    dateline = DATELINE.compiled()
    letterhead_datelines: set[int] = set()
    for head in letterheads:
        found = dateline.search(text, text.rfind("\n", 0, head.end()) + 1, head.end())
        if found is not None:
            letterhead_datelines.add(found.start())
    found_closes: list[tuple[int, int, int, _Close]] = []
    for precedence, pattern in enumerate(_transmittals()):
        for match in pattern.compiled().finditer(text, after):
            if pattern.name in _NEEDS_LETTERHEAD:
                index = bisect_right(datelines, match.start()) - 1
                if index < 0 or datelines[index] not in letterhead_datelines:
                    continue
            name = match.groupdict().get("name")
            found_closes.append(
                (match.start(), precedence, -match.end(), _Close(match.start(), match.end(), pattern.name, name))
            )
    closes: list[_Close] = []
    for _, _, _, close in sorted(found_closes, key=lambda item: item[:3]):
        if closes and close.start < closes[-1].end:
            continue
        closes.append(close)
    return closes


def _letter_date(text: str, letterhead_end: int | None) -> str | None:
    """The ISO date a letterhead's dateline prints, or ``None`` where there is no letterhead or no calendar date."""
    if letterhead_end is None:
        return None
    found = LETTER_DATE.compiled().match(text, letterhead_end)
    if found is None:
        return None
    try:
        return date(int(found["year"]), _MONTHS.index(found["month"]) + 1, int(found["day"])).isoformat()
    except ValueError:
        return None


def _attributed_signatory(text: str, span: tuple[int, int]) -> str | None:
    """The Director the 118th-Congress attribution names inside a span, read over collapsed whitespace."""
    found = SIGNATORY.compiled().search(_WHITESPACE.sub(" ", text[span[0] : span[1]]))
    return None if found is None else found["name"]


def _locate_letters(
    text: str, recital_end: int, blocks: Sequence[HeadingBlock], headings: Sequence[tuple[HeadingBlock, str]]
) -> tuple[CboLetter, ...]:
    """Every letter after the recital, each anchored on its close.

    A close ends one letter.  A transmittal close followed by ``Enclosure.``
    runs on through the enclosed estimates' approval lines, up to the next
    close, letterhead or dateline -- a dateline bounds the bridge so an
    unrecognized next letter is not absorbed (none prints after an
    ``Enclosure.`` inside a measured letter).  Where the enclosed estimate
    prints no approval line and the letter opened on a numbered heading, it
    runs to the next heading of that series instead (CRPT-106hrpt262), as the
    close-less fallback does.  The letter starts at the last vocabulary heading
    between the previous letter's end and this letter's letterhead (or close,
    where it prints none), else at the letterhead itself; with neither, no
    letter is emitted rather than a start invented.  Headings, letterheads,
    datelines and approvals are sorted offsets looked up by bisection: linear in the text.
    """
    letterhead_matches = list(LETTERHEAD.compiled().finditer(text, recital_end))
    datelines = [m.start() for m in DATELINE.compiled().finditer(text, recital_end)]
    closes = _closes(text, recital_end, letterhead_matches, datelines)
    if not closes:
        return ()
    headings = [(block, rule) for block, rule in headings if block.span[0] >= recital_end]
    heading_starts = [block.span[0] for block, _ in headings]
    letterheads = [m.start() for m in letterhead_matches]
    letterhead_ends = [m.end() for m in letterhead_matches]
    series_starts: dict[str, list[int]] = {}
    for block in blocks:
        if block.series is not None and block.span[0] >= recital_end:
            series_starts.setdefault(block.series, []).append(block.span[0])
    approvals = [(m.start(), m.end()) for m in ESTIMATE_APPROVAL.compiled().finditer(text, recital_end)]
    approval_starts = [start for start, _ in approvals]
    enclosure = ENCLOSURE.compiled()
    letters: list[CboLetter] = []
    previous_end = recital_end
    for index, close in enumerate(closes):
        if close.start < previous_end:
            continue
        # The letterhead this close signs is the last one above it, if it is past the previous letter.
        head_index = bisect_right(letterheads, close.start) - 1
        own_head = head_index >= 0 and letterheads[head_index] >= previous_end
        letterhead = letterheads[head_index] if own_head else None
        cutoff = close.start if letterhead is None else letterhead
        heading_index = bisect_left(heading_starts, cutoff) - 1
        if heading_index >= 0 and heading_starts[heading_index] >= previous_end:
            opening, heading_rule = headings[heading_index]
            start, heading = opening.span[0], opening.text
        elif letterhead is not None:
            opening, start, heading, heading_rule = None, letterhead, None, LETTERHEAD.name
        else:
            continue
        end, end_rule = close.end, close.rule
        if close.rule != DIRECTOR_ATTRIBUTION.name and enclosure.match(text, close.end):
            limit = closes[index + 1].start if index + 1 < len(closes) else len(text)
            for bounds in (letterheads, datelines):
                following = bisect_right(bounds, close.end)
                if following < len(bounds):
                    limit = min(limit, bounds[following])
            last = bisect_left(approval_starts, limit) - 1
            if last >= 0 and approval_starts[last] >= close.end:
                end, end_rule = approvals[last][1], f"{close.rule}+{ESTIMATE_APPROVAL.name}"
            elif opening is not None and opening.series is not None:
                series = series_starts[opening.series]
                following = bisect_right(series, close.end)
                if following < len(series) and series[following] < limit:
                    end, end_rule = series[following], f"{close.rule}+{_NEXT_HEADING_IN_SERIES}"
        signatory = _attributed_signatory(text, (start, end)) if close.name is None else close.name
        letter_date = _letter_date(text, letterhead_ends[head_index] if own_head else None)
        letters.append(
            CboLetter((start, end), digest(text[start:end]), heading, heading_rule, end_rule, signatory, letter_date)
        )
        previous_end = end
    return tuple(letters)


def read_cbo_estimate(text: str) -> CboEstimateFinding:
    """What one CRPT body states about its CBO cost estimate.

    ``text`` is the normalized text of one report -- ``BodyText.text`` -- and
    every span is an offset into exactly that string, so a consumer holding it
    can re-read the span and see what the rule saw.
    """
    if not isinstance(text, str):
        raise CboEstimateError(f"text must be a string, not {type(text).__name__}")
    recital = COVER_RECITAL.compiled().search(text)
    accompanies = ACCOMPANIES.compiled().search(text)
    blocks = tuple(heading_blocks(text))
    headings = [(block, rule) for block in blocks if (rule := _match_heading(block)) is not None]
    heading, heading_rule = headings[0] if headings else (None, None)
    letters: tuple[CboLetter, ...] = ()
    if recital is not None:
        letters = _locate_letters(text, recital.end(), blocks, headings)
        located = None if letters or heading is None else _letter_end(heading, blocks)
        if heading is not None and heading_rule is not None and located is not None:
            span = (heading.span[0], located[0])
            letters = (
                CboLetter(
                    span,
                    digest(text[span[0] : span[1]]),
                    heading.text,
                    heading_rule,
                    located[1],
                    _attributed_signatory(text, span),
                ),
            )
    if heading is not None and any(letter.span[0] == heading.span[0] for letter in letters):
        heading, heading_rule = None, None
    reason, reason_span, reason_rule = (None, None, None) if recital is not None else _absence(text)
    return CboEstimateFinding(
        rule=CBO_ESTIMATE_RULE,
        rule_version=CBO_ESTIMATE_RULE_VERSION,
        report_states_estimate=recital is not None,
        recital_span=None if recital is None else (recital.start(), recital.end()),
        accompanies=None if accompanies is None else accompanies.group(1).strip(),
        heading=None if heading is None else heading.text,
        heading_rule=heading_rule,
        absence_reason=reason,
        absence_span=reason_span,
        absence_rule=reason_rule,
        letters=letters,
    )


def recital_bill_id(finding: CboEstimateFinding, congress: object) -> str | None:
    """``[To accompany H.R. 801]`` in a 118th report is ``118-hr-801``.

    **The Congress is the package's, not the print's** -- the cover writes
    ``H.R. 801`` and never a Congress -- so the caller supplies the one its own
    package identity states; ``None`` where the cover names no measure or names
    something outside the eight bill types, which is the honest answer rather
    than a key nothing addresses.
    """
    if finding.accompanies is None or congress is None:
        return None
    parts = bill_type_and_number(finding.accompanies)
    return None if parts is None else natural_key(congress, *parts)


__all__ = [
    "ABSENCE_REASONS",
    "ACCOMPANIES",
    "CBO_ESTIMATE_RULE",
    "CBO_ESTIMATE_RULE_VERSION",
    "COVER_RECITAL",
    "DATELINE",
    "DIRECTOR_ATTRIBUTION",
    "ENCLOSURE",
    "ESTIMATE_APPROVAL",
    "FOR_DIRECTOR",
    "FOR_DIRECTOR_UNNAMED_TITLE",
    "HEADINGS",
    "LETTERHEAD",
    "LETTER_DATE",
    "LETTER_PATTERNS",
    "NAMED_DIRECTOR",
    "NAMED_SIGNATURE",
    "SIGNATORY",
    "CboEstimateError",
    "CboEstimateFinding",
    "CboLetter",
    "HeadingBlock",
    "LetterPattern",
    "heading_blocks",
    "read_cbo_estimate",
    "recital_bill_id",
]
