"""Archived copies of publisher pages, found and fetched from public web archives and never from the publisher.

A publisher that walls its own pages (cbo.gov behind DataDome, ``sources/cbo.py``)
can still be read where a public archive captured it: Common Crawl's per-crawl
URL index names every capture's WARC file, offset and length, and one ranged GET
on ``data.commoncrawl.org`` returns that capture's gzip member -- the archive's
own bytes, retained as the original. The Wayback Machine is not read here:
its CDX answered ``503 Temporarily Offline`` on every attempt (2026-09-20,
2026-10-30), so no answer of it has ever been seen, parsed or reviewed. Its
host stays off the allowlist until one is, and its CDX and ``id_`` replay
helpers are written against a retained answer then, not guessed now.

:class:`WebArchiveAcquirer` owns the archive-host allowlist, a fixed project
user agent and **one** request budget for its whole life: every capture chains
onto it (``reset_budget=False``), so ``max_requests`` bounds a run, not a call,
and retries are capped per call so a 503 cannot spend the rest of it.

Index reads are one prefix query per crawl (``www.cbo.gov/publication/*``),
never one per publication; a caller joins the rows to its own identities in
memory. ``cdx_toolkit`` was considered and not used: it issues its own
``requests`` calls, so its index responses would escape this budget, its
pacing and the retained index bytes a receipt's ``index_sha256`` names.
``warcio`` parses the WARC member. The payload's SHA-1 is recomputed here over
the stored payload bytes -- the bytes Common Crawl hashed, measured on
publications 62589 and 62720 -- and must equal both the record's
``WARC-Payload-Digest`` and the index row's ``digest``; those two are the
archive's statements about itself, so the recomputation (stdlib ``hashlib``,
not warcio) is the one independent check and their agreement is not a second.
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING
from urllib.parse import urlencode, urlsplit

from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_byte_bound, check_timing, utc_now

if TYPE_CHECKING:
    import httpx

COMMON_CRAWL = "Common Crawl"
CC_INDEX_HOST = "index.commoncrawl.org"
CC_DATA_HOST = "data.commoncrawl.org"
#: Every host this module may request. A locator naming any other host refuses before a request is made.
ARCHIVE_HOSTS = frozenset({CC_INDEX_HOST, CC_DATA_HOST})
ARCHIVE_USER_AGENT = "spicy-docs-web-archive/1.0 (+https://github.com/civictechdc/spicy-docs)"

#: One crawl's index of www.cbo.gov/publication/* was 993,125 bytes on 2026-10-30; 32 MiB bounds any page.
MAX_INDEX_BYTES = 32 * 1024 * 1024
#: A WARC record is one capture; the largest CBO PDF records are a few MiB.
MAX_RECORD_BYTES = 64 * 1024 * 1024

INDEX_MEDIA_TYPES = ("text/x-ndjson", "application/x-ndjson", "application/json", "text/plain")
RECORD_MEDIA_TYPES = ("application/octet-stream", "binary/octet-stream", "application/gzip", "application/x-gzip")

_CRAWL_ID = re.compile(r"CC-MAIN-[0-9]{4}-[0-9]{2}")
_TIMESTAMP = re.compile(r"[0-9]{14}")
_DIGEST = re.compile(r"(?:sha1:)?([A-Z2-7]{32})")
_WARC_FILENAME = re.compile(r"crawl-data/CC-MAIN-[0-9]{4}-[0-9]{2}/[A-Za-z0-9._/-]+\.warc\.gz")


class WebArchiveError(ValueError):
    """An archive's answer cannot establish an archived capture."""


class WebArchiveUnavailableError(WebArchiveError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"web archive answered HTTP {capture.status_code}")
        self.capture = capture


@dataclass(frozen=True, slots=True)
class ArchiveCandidate:
    """One archived capture as an archive's index lists it, every value as the index spelled it.

    ``digest`` is the index's base32 SHA-1 of the payload; ``filename``,
    ``offset`` and ``length`` locate the record in its WARC file.
    """

    operator: str
    original_url: str
    timestamp: str
    status: int | None
    mime: str | None
    digest: str | None
    crawl_id: str | None = None
    filename: str | None = None
    offset: int | None = None
    length: int | None = None
    record_id: str | None = None

    @property
    def byte_range(self) -> tuple[int, int]:
        if self.offset is None or self.length is None:
            raise WebArchiveError("only a Common Crawl candidate has a byte range")
        return self.offset, self.offset + self.length - 1


def _archive_url(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.hostname not in ARCHIVE_HOSTS or parts.port is not None:
        raise WebArchiveError(f"refusing a request outside the web archives: {parts.hostname}")
    return url


def cc_index_locator(crawl_id: str, url_pattern: str, *, page: int | None = None, num_pages: bool = False) -> str:
    """One crawl's URL index for a prefix pattern (``www.cbo.gov/publication/*``), JSON lines."""
    if not _CRAWL_ID.fullmatch(crawl_id):
        raise WebArchiveError("crawl_id must be CC-MAIN-YYYY-WW")
    query: dict[str, str] = {"url": url_pattern, "output": "json"}
    if num_pages:
        query["showNumPages"] = "true"
    elif page is not None:
        if isinstance(page, bool) or not isinstance(page, int) or page < 0:
            raise WebArchiveError("page must be a nonnegative integer")
        query["page"] = str(page)
    return f"https://{CC_INDEX_HOST}/{crawl_id}-index?" + urlencode(query, safe="/*:")


def cc_record_locator(filename: str) -> str:
    if not isinstance(filename, str) or not _WARC_FILENAME.fullmatch(filename) or ".." in filename:
        raise WebArchiveError("Common Crawl filename is not a crawl-data WARC path")
    return f"https://{CC_DATA_HOST}/{filename}"


def _int(value: object) -> int | None:
    return int(value) if isinstance(value, str) and value.isascii() and value.isdecimal() else None


def parse_cc_num_pages(body: bytes) -> int:
    try:
        pages = json.loads(body)["pages"]
    except (ValueError, KeyError, TypeError) as error:
        raise WebArchiveError("Common Crawl showNumPages answer is not {'pages': N}") from error
    if isinstance(pages, bool) or not isinstance(pages, int) or pages < 0:
        raise WebArchiveError("Common Crawl showNumPages answer is not a page count")
    return pages


def parse_cc_index(body: bytes, *, crawl_id: str) -> tuple[ArchiveCandidate, ...]:
    """Every row of one Common Crawl index answer, in index order; a row without a WARC location refuses."""
    rows: list[ArchiveCandidate] = []
    for number, line in enumerate(body.splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except ValueError as error:
            raise WebArchiveError(f"Common Crawl index line {number} is not JSON") from error
        if not isinstance(row, dict):
            raise WebArchiveError(f"Common Crawl index line {number} is not an object")
        filename, offset, length = row.get("filename"), _int(row.get("offset")), _int(row.get("length"))
        if not isinstance(filename, str) or offset is None or not length:
            raise WebArchiveError(f"Common Crawl index line {number} states no WARC location")
        if not isinstance(row.get("url"), str) or not _TIMESTAMP.fullmatch(str(row.get("timestamp"))):
            raise WebArchiveError(f"Common Crawl index line {number} states no URL and timestamp")
        rows.append(
            ArchiveCandidate(
                operator=COMMON_CRAWL,
                original_url=row["url"],
                timestamp=row["timestamp"],
                status=_int(row.get("status")),
                mime=row.get("mime"),
                digest=row.get("digest"),
                crawl_id=crawl_id,
                filename=filename,
                offset=offset,
                length=length,
                record_id=row.get("recordid"),
            )
        )
    return tuple(rows)


@dataclass(frozen=True, slots=True)
class WarcResponse:
    """The one ``response`` record a Common Crawl gzip member holds, its payload exactly as stored."""

    record_id: str
    target_uri: str
    warc_date: str
    payload_digest: str
    http_status: int
    publisher_headers: tuple[tuple[str, str], ...]
    payload: bytes


def payload_sha1(payload: bytes) -> str:
    """The base32 SHA-1 web archives state as a payload digest."""
    return base64.b32encode(hashlib.sha1(payload).digest()).decode("ascii")


def _bare_digest(value: str | None, label: str) -> str:
    match = _DIGEST.fullmatch(value or "")
    if match is None:
        raise WebArchiveError(f"{label} is not a base32 SHA-1")
    return match[1]


def read_warc_response(member: bytes) -> WarcResponse:
    """Parse one gzip WARC member with warcio; its recomputed payload SHA-1 must equal ``WARC-Payload-Digest``.

    The payload is the stored HTTP entity, before any content decoding: the
    bytes the archive hashed, and so the bytes a recomputation can check.
    """
    from warcio.archiveiterator import ArchiveIterator

    records = []
    try:
        for record in ArchiveIterator(io.BytesIO(member), check_digests=False):
            if record.rec_type != "response":
                raise WebArchiveError(f"WARC record is a {record.rec_type}, not a response")
            if record.rec_headers.get_header("WARC-Truncated"):
                # Common Crawl cuts payloads at its fetch limit; a cut PDF is not the publisher's document.
                raise WebArchiveError("WARC record payload is truncated")
            headers = record.http_headers
            records.append(
                WarcResponse(
                    record_id=record.rec_headers.get_header("WARC-Record-ID") or "",
                    target_uri=record.rec_headers.get_header("WARC-Target-URI") or "",
                    warc_date=record.rec_headers.get_header("WARC-Date") or "",
                    payload_digest=_bare_digest(
                        record.rec_headers.get_header("WARC-Payload-Digest"), "WARC-Payload-Digest"
                    ),
                    http_status=int(headers.get_statuscode()),
                    publisher_headers=tuple((name, value) for name, value in headers.headers),
                    payload=record.raw_stream.read(),
                )
            )
    except WebArchiveError:
        raise
    except Exception as error:  # warcio raises its own and stdlib errors on a malformed member
        raise WebArchiveError("Common Crawl record is not a readable WARC member") from error
    if len(records) != 1:
        raise WebArchiveError(f"Common Crawl record holds {len(records)} response records, not one")
    response = records[0]
    if payload_sha1(response.payload) != response.payload_digest:
        raise WebArchiveError("WARC payload SHA-1 differs from WARC-Payload-Digest")
    return response


@dataclass(frozen=True, slots=True)
class IndexRead:
    """One index answer: its rows and the retained capture a receipt's ``index_sha256`` names."""

    candidates: tuple[ArchiveCandidate, ...]
    capture: CapturedBodyResponse


@dataclass(frozen=True, slots=True)
class ArchivedRecord:
    """One archived capture fetched and verified: the archive's own bytes and the publisher response inside them."""

    candidate: ArchiveCandidate
    capture: CapturedBodyResponse
    response: WarcResponse

    def receipt_fields(self, index: CapturedBodyResponse | None) -> dict[str, object]:
        """What every archived capture's receipt records (ticket ss-7ovu's receipt rule).

        The requested and resolved URLs are the archive's, on the capture; the
        publisher's URL is ``original_publisher_url``. ``index`` is the retained
        index answer that listed this candidate.
        """
        candidate = self.candidate
        return {
            "authority": "archive",
            "archive_operator": candidate.operator,
            "original_publisher_url": self.response.target_uri or candidate.original_url,
            "archive_timestamp": candidate.timestamp,
            "index_url": None if index is None else index.requested_url,
            "index_sha256": None if index is None else index.sha256,
            "index_digest": candidate.digest,
            "payload_sha1": payload_sha1(self.response.payload),
            "crawl_id": candidate.crawl_id,
            "warc_filename": candidate.filename,
            "warc_offset": candidate.offset,
            "warc_length": candidate.length,
            "warc_record_id": self.response.record_id,
            "archived_http_status": self.response.http_status,
            "archived_publisher_headers": [list(pair) for pair in self.response.publisher_headers],
        }


class WebArchiveAcquirer(SourceAcquirer):
    """Keyless reads of the archives only, under one budget for the acquirer's whole life."""

    def __init__(
        self,
        *,
        max_requests: int,
        timeout_seconds: float = 120.0,
        min_request_interval_seconds: float = 2.0,
        max_index_bytes: int = MAX_INDEX_BYTES,
        max_record_bytes: int = MAX_RECORD_BYTES,
        index_attempts: int = 2,
        user_agent: str = ARCHIVE_USER_AGENT,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        check_timing(timeout_seconds, min_request_interval_seconds)
        check_byte_bound(max_index_bytes, "max_index_bytes", MAX_INDEX_BYTES)
        check_byte_bound(max_record_bytes, "max_record_bytes", MAX_RECORD_BYTES)
        self.max_index_bytes, self.max_record_bytes, self.index_attempts = (
            max_index_bytes,
            max_record_bytes,
            index_attempts,
        )
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=timeout_seconds,
            min_request_interval_seconds=min_request_interval_seconds,
            user_agent=user_agent,
            label="web archive",
            error_type=WebArchiveError,
            context_key="web_archive_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def _get[Result](
        self,
        url: str,
        *,
        media_types: tuple[str, ...],
        parse: Callable[[CapturedBodyResponse, int], Result],
        max_bytes: int,
        operation: str,
        max_attempts: int,
        byte_range: tuple[int, int] | None = None,
    ) -> tuple[Result, CapturedBodyResponse]:
        return self.capture_validated(
            _archive_url(url),
            media_types=media_types,
            parse=parse,
            max_bytes=max_bytes,
            unavailable=WebArchiveUnavailableError,
            context={"operation": operation, "url": url},
            reset_budget=False,
            max_attempts=max_attempts,
            byte_range=byte_range,
        )

    def acquire_cc_num_pages(self, crawl_id: str, url_pattern: str) -> tuple[int, CapturedBodyResponse]:
        return self._get(
            cc_index_locator(crawl_id, url_pattern, num_pages=True),
            media_types=INDEX_MEDIA_TYPES,
            parse=lambda response, _: parse_cc_num_pages(response.body),
            max_bytes=self.max_index_bytes,
            operation="cc-index-pages",
            max_attempts=self.index_attempts,
        )

    def acquire_cc_index(self, crawl_id: str, url_pattern: str, *, page: int | None = None) -> IndexRead:
        candidates, capture = self._get(
            cc_index_locator(crawl_id, url_pattern, page=page),
            media_types=INDEX_MEDIA_TYPES,
            parse=lambda response, _: parse_cc_index(response.body, crawl_id=crawl_id),
            max_bytes=self.max_index_bytes,
            operation="cc-index",
            max_attempts=self.index_attempts,
        )
        return IndexRead(candidates, capture)

    def acquire_cc_record(self, candidate: ArchiveCandidate) -> ArchivedRecord:
        """One ranged GET of a Common Crawl record; its recomputed payload SHA-1 must equal the index's digest."""
        if candidate.operator != COMMON_CRAWL or candidate.filename is None:
            raise WebArchiveError("only a Common Crawl candidate is fetched as a record")
        expected = _bare_digest(candidate.digest, "Common Crawl index digest")

        def parse(response: CapturedBodyResponse, _: int) -> WarcResponse:
            record = read_warc_response(response.body)
            if record.payload_digest != expected:
                raise WebArchiveError("WARC payload digest differs from the index row's digest")
            return record

        record, capture = self._get(
            cc_record_locator(candidate.filename),
            media_types=RECORD_MEDIA_TYPES,
            parse=parse,
            max_bytes=self.max_record_bytes,
            operation="cc-record",
            max_attempts=2,
            byte_range=candidate.byte_range,
        )
        return ArchivedRecord(candidate, capture, record)


__all__ = [
    "ARCHIVE_HOSTS",
    "ARCHIVE_USER_AGENT",
    "COMMON_CRAWL",
    "ArchiveCandidate",
    "ArchivedRecord",
    "IndexRead",
    "WarcResponse",
    "WebArchiveAcquirer",
    "WebArchiveError",
    "WebArchiveUnavailableError",
    "cc_index_locator",
    "cc_record_locator",
    "parse_cc_index",
    "parse_cc_num_pages",
    "payload_sha1",
    "read_warc_response",
]
