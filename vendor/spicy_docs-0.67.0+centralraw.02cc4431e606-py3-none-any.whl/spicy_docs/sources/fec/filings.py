"""Offline positional filing records, separate from financial field mappings."""

from __future__ import annotations

import codecs
import csv
import io
import re
from collections.abc import Iterator
from pathlib import Path

from rulespec_artifacts import LocalBlobSource

BEGIN_TEXT = {"[BEGINTEXT]", "[BEGIN TEXT]"}
END_TEXT = {"[ENDTEXT]", "[END TEXT]"}
# Publisher "e-filing headers all versions", TEXT rows 11–14:
# v5.0–5.3 TEXT4000 is field 4 (zero-based 3). FEC-91256 independently
# qualifies literal 5.00 at that position; version labels are never rounded.
CSV_TEXT_FIELDS = dict.fromkeys(("5.0", "5.00", "5.1", "5.2", "5.3"), 3)


def _cp1252_undefined(byte: int) -> bool:
    try:
        bytes([byte]).decode("cp1252")
    except UnicodeDecodeError:
        return True
    return False


# Derived from Python's codec, never copied, so the policy cannot agree with itself.
_CP1252_UNDEFINED = re.compile(
    b"[" + b"".join(re.escape(bytes([b])) for b in range(256) if _cp1252_undefined(b)) + b"]"
)
_C1_BYTES = re.compile(b"[\\x80-\\x9f]")


class FilingEncodingError(ValueError):
    """A filing's bytes refuse every automatic encoding, or a declared encoding would read different text.

    ``utf8_offset`` and ``cp1252_offset`` are the first byte each strict decoder refused (None when it decoded).
    """

    def __init__(self, message: str, *, declared: str | None, utf8_offset: int | None, cp1252_offset: int | None):
        super().__init__(
            f"{message} (declared {declared}; utf-8 refused at {utf8_offset}; cp1252 refused at {cp1252_offset})"
        )
        self.declared, self.utf8_offset, self.cp1252_offset = declared, utf8_offset, cp1252_offset


class TruncatedRecordError(csv.Error, ValueError):
    """The stream ended inside an unterminated quoted record, at ``byte_offset`` for ``byte_length`` bytes."""

    def __init__(self, byte_offset: int, byte_length: int):
        super().__init__(f"FEC stream ends inside an unterminated record at byte {byte_offset} ({byte_length} bytes)")
        self.byte_offset, self.byte_length = byte_offset, byte_length


class _ByteEvidence:
    """One pass of byte evidence that owns the filing encoding decision: strict UTF-8, then strict cp1252.

    Latin-1 is never chosen automatically; it is accepted only as a declared override where cp1252 refuses, or
    where it reads the same text as the decided encoding (see ``_same_text``).
    """

    def __init__(self):
        self._utf8 = codecs.getincrementaldecoder("utf-8")("strict")
        self.size = 0
        self.utf8_offset: int | None = None
        self.cp1252_offset: int | None = None
        self.non_ascii = self.c1 = False

    def update(self, raw: bytes) -> None:
        if not raw.isascii():
            self.non_ascii = True
            self.c1 = self.c1 or _C1_BYTES.search(raw) is not None
            if self.cp1252_offset is None and (match := _CP1252_UNDEFINED.search(raw)):
                self.cp1252_offset = self.size + match.start()
        if self.utf8_offset is None:
            pending = len(self._utf8.getstate()[0])
            try:
                self._utf8.decode(raw)
            except UnicodeDecodeError as error:
                self.utf8_offset = self.size - pending + error.start
        self.size += len(raw)

    def _finish(self) -> None:
        if self.utf8_offset is None:
            pending = len(self._utf8.getstate()[0])
            try:
                self._utf8.decode(b"", final=True)
            except UnicodeDecodeError:
                self.utf8_offset = self.size - pending

    def _same_text(self, declared: str, decided: str) -> bool:
        # Owner decision 2026-10-31: a declaration that reads the same text as the decided encoding agrees, so the
        # retained senate 64/72/82.fec latin-1 declarations (only non-ASCII byte 0xA0) keep their record_ids. ASCII
        # reads alike everywhere; latin-1 and cp1252 differ only on 0x80-0x9F, which a cp1252 decision defines.
        return not self.non_ascii or ({declared, decided} == {"latin-1", "cp1252"} and not self.c1)

    def decided(self) -> str | None:
        """The automatic decision at end of input: utf-8, then cp1252, or None when both refuse."""
        self._finish()
        return "utf-8" if self.utf8_offset is None else "cp1252" if self.cp1252_offset is None else None

    def encoding(self, declared: str | None = None) -> str:
        """Return the encoding these bytes support, or ``declared`` when it agrees; otherwise refuse."""
        decided = self.decided()
        if declared is None:
            if decided is not None:
                return decided
        elif decided is None:
            if declared == "latin-1":
                return declared
        elif declared == decided or self._same_text(declared, decided):
            return declared
        raise FilingEncodingError(
            "FEC filing bytes refuse strict UTF-8 and cp1252; only a recorded latin-1 override reads them"
            if decided is None
            else f"FEC filing declares {declared}, but its bytes read as {decided} and the text would differ",
            declared=declared,
            utf8_offset=self.utf8_offset,
            cp1252_offset=self.cp1252_offset,
        )


def filing_encoding(stream, *, override: str | None = None, chunk_bytes: int = 1024**2) -> str:
    """Choose a whole filing's encoding: strict UTF-8, then strict cp1252, else refuse with FilingEncodingError.

    ``override="latin-1"`` reads bytes cp1252 refuses and must be recorded with the choice. It applies only there:
    on bytes UTF-8 or cp1252 decide it refuses, so an unneeded override cannot be recorded. Record its reason in the
    qualification entry's ``encoding_basis``; the scope carries only the encoding. A latin-1 *declaration* already on
    record is checked by ``_Lines`` for text equivalence instead. One pass in bounded chunks from the stream's current
    position; the caller owns seeking back.
    """
    if override not in {None, "latin-1"}:
        raise ValueError("only a latin-1 override is supported")
    evidence = _ByteEvidence()
    while chunk := stream.read(chunk_bytes):
        evidence.update(chunk)
    if override is not None and (decided := evidence.decided()) is not None:
        raise FilingEncodingError(
            f"FEC filing bytes read as {decided}; a latin-1 override applies only where cp1252 refuses",
            declared=override,
            utf8_offset=evidence.utf8_offset,
            cp1252_offset=evidence.cp1252_offset,
        )
    return evidence.encoding(override)


class _Lines:
    def __init__(self, stream, encoding: str, limit: int):
        self.stream, self.encoding, self.limit = stream, encoding, limit
        self.start = self.end = 0
        self.exhausted = False
        # A UTF-8 declaration is checked by its own strict decode; any other declaration must agree with the bytes.
        self._evidence = None if encoding == "utf-8" else _ByteEvidence()

    def __iter__(self):
        return self

    def __next__(self) -> str:
        raw = self.stream.readline(self.limit - (self.end - self.start) + 1)
        if not raw:
            self.exhausted = True
            if self._evidence is not None:
                self._evidence.encoding(self.encoding)
            raise StopIteration
        self.end += len(raw)
        if self.end - self.start > self.limit:
            raise ValueError("FEC record exceeds its byte bound")
        if self._evidence is not None:
            self._evidence.update(raw)
        return raw.decode(self.encoding)

    def record(self, reader):
        """The reader's next record, or None at the end; a stream ending inside a quoted record is typed."""
        try:
            return next(reader, None)
        except csv.Error as error:
            if self.exhausted:
                raise TruncatedRecordError(self.start, self.end - self.start) from error
            raise


def _validate_options(encoding, max_record_bytes):
    if type(max_record_bytes) is not int or max_record_bytes <= 0:
        raise ValueError("max_record_bytes must be a positive integer")
    if encoding not in {"utf-8", "latin-1", "cp1252"}:
        raise ValueError("select utf-8, latin-1 or cp1252 for the complete filing")


def filing_records(
    *, store: Path, sha256: str, encoding: str = "utf-8", max_record_bytes: int = 1024**2
) -> Iterator[dict]:
    """Read verified originals with source byte ranges and literal positional fields.

    ASCII-FS values retain quotes; CSV values follow Python's CSV syntax. No
    financial names, types, amendments or unknown record types are inferred.
    Select a whole-file encoding explicitly; decoding never restarts the stream.
    Memory is bounded by one record. Bracketed free text is counted, not joined.
    Only natural exhaustion establishes a completed parse of the selected file.
    """
    _validate_options(encoding, max_record_bytes)
    with LocalBlobSource(store).open(sha256) as stream:
        yield from filing_records_from_stream(
            stream, sha256=sha256, encoding=encoding, max_record_bytes=max_record_bytes
        )


def filing_records_from_stream(stream, *, sha256, encoding="utf-8", max_record_bytes=1024**2):
    """Parse a caller-owned verified binary stream from offset zero without reopening it.

    The caller owns verification and closure; source ranges refer to this decoded
    stream. For ZIP members retain the container pin and member ordinal separately.
    A non-UTF-8 declaration is checked against the whole stream only at natural
    exhaustion, after every row is yielded: a refusal there invalidates the rows
    already yielded, so a caller writing while streaming must abort on it, and a
    caller that stops early never gets the check.
    """
    _validate_options(encoding, max_record_bytes)
    lines = _Lines(stream, encoding, max_record_bytes)

    def reference(start: int, end: int) -> dict:
        return {"sha256": sha256, "byte_offset": start, "byte_length": end - start, "encoding": encoding}

    first = next(lines, "")
    if first.startswith("/*"):
        header = [first.rstrip("\r\n")]
        for line in lines:
            header.append(line.rstrip("\r\n"))
            if line.startswith("/*"):
                break
        else:
            raise ValueError("FEC legacy header is unterminated")
        versions = [line.partition("=")[2].strip() for line in header if line.lower().startswith("fec_ver_#")]
        if len(versions) != 1 or not versions[0]:
            raise ValueError("FEC legacy header omitted a unique version")
        version, delimiter = versions[0], ","
    else:
        delimiter = "\x1c" if "\x1c" in first else ","
        header = first.rstrip("\r\n").split(delimiter) if delimiter == "\x1c" else next(csv.reader([first]))
        if len(header) < 3 or header[0] != "HDR":
            raise ValueError("FEC original omitted its filing header")
        version = header[2] if header[1] == "FEC" else header[1]
        if not version:
            raise ValueError("FEC header omitted its version")
    yield {"kind": "header", "format_version": version, "fields": header, "source": reference(0, lines.end)}
    while True:
        lines.start = lines.end
        line = next(lines, None)
        if line is None:
            return
        if line.strip().upper() in BEGIN_TEXT:
            body_start = lines.end
            while True:
                lines.start = lines.end
                line = next(lines, None)
                if line is None:
                    raise ValueError("FEC text block is unterminated")
                if line.strip().upper() in END_TEXT:
                    yield {"kind": "text", "embedded_bodies": [reference(body_start, lines.start)]}
                    break
            continue
        if line.strip().upper() in END_TEXT:
            raise ValueError("FEC text block has no opening marker")
        if delimiter == "\x1c":
            fields = line.rstrip("\r\n").split(delimiter)
        else:
            # The shared CSV reader consumes quoted multiline records from
            # the same byte-counted iterator, under one total record bound.
            def csv_lines(initial=line):
                yield initial
                yield from lines

            fields = lines.record(csv.reader(csv_lines(), strict=True))
        row_source = reference(lines.start, lines.end)
        body_index = 5 if delimiter == "\x1c" else CSV_TEXT_FIELDS.get(version)
        body_fields = (
            [body_index]
            if fields and fields[0] == "TEXT" and body_index is not None and len(fields) > body_index
            else []
        )
        yield {
            "kind": "record",
            "record_type": fields[0] if fields else "",
            "field_count": len(fields),
            "fields": {str(i): value for i, value in enumerate(fields) if i not in body_fields},
            "embedded_bodies": [{**row_source, "field_index": i, "delimiter": delimiter} for i in body_fields],
            "source": row_source,
        }


def filing_body(*, store: Path, body: dict, max_bytes: int = 8 * 1024**2) -> str:
    """Resolve one body, preserving whitespace and verifying the original anew.

    For many references, open the original once with LocalBlobSource and read
    their byte ranges; calling this helper per body repeats whole-file hashing.
    The declared encoding is checked against the range's own bytes (see _ByteEvidence), not against the whole
    file's decision: a cp1252 file whose range alone is valid non-ASCII UTF-8 refuses here, and so does a latin-1
    range over a byte cp1252 defines in 0x80-0x9F. A latin-1 range over a byte cp1252 leaves undefined (0x81, 0x8D,
    0x8F, 0x90, 0x9D) is the recorded override's case and reads that byte as its C1 control; consumers refuse C1
    text at release (spicy-regs fec_native_subjects).
    """
    start, length = body["byte_offset"], body["byte_length"]
    if any(type(value) is not int or value < 0 for value in (start, length)):
        raise ValueError("FEC body needs nonnegative integer byte coordinates")
    if type(max_bytes) is not int or max_bytes <= 0 or length > max_bytes:
        raise ValueError("FEC body exceeds its selected byte bound")
    with LocalBlobSource(store).open(body["sha256"]) as stream:
        if start + length > stream.seek(0, 2):
            raise ValueError("FEC body extends beyond its retained original")
        stream.seek(start)
        raw = stream.read(length)
    if len(raw) != length:
        raise ValueError("FEC body extends beyond its retained original")
    # The range must read the same text under its declaration as under the decision for these bytes, so a latin-1
    # reference over a cp1252-defined 0x80-0x9F byte or a cp1252 reference over valid UTF-8 refuses here.
    evidence = _ByteEvidence()
    evidence.update(raw)
    text = raw.decode(evidence.encoding(body["encoding"]))
    if "field_index" in body:
        if type(body["field_index"]) is not int or body["field_index"] < 0:
            raise ValueError("FEC body field index must be a nonnegative integer")
        if body["delimiter"] == "\x1c":
            fields = text.rstrip("\r\n").split("\x1c")
        elif body["delimiter"] == ",":
            records = csv.reader(io.StringIO(text, newline=""), strict=True)
            fields = next(records, None)
            if fields is None or next(records, None) is not None:
                raise ValueError("FEC CSV body reference must contain exactly one record")
        else:
            raise ValueError("FEC body field reference requires ASCII FS or CSV")
        if body["field_index"] >= len(fields):
            raise ValueError("FEC body field index is outside its retained record")
        return fields[body["field_index"]]
    return text
