"""Resolve CMS DCAT-US 3 releases and retain literal, bounded API pages.

CMS's API FAQ 1.7 defines datasetSeries.last, versioned API distributions,
dictionary links, /data/stats counts and size/offset pagination. The API emits
string values; source capture does not interpret amounts or manufacturer totals.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from urllib.parse import parse_qsl, urlencode, urlsplit

from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.reading.paged_json import (
    JsonPage,
    JsonPageFamily,
    PagedJsonBudget,
    PagedJsonReader,
    PagedJsonSourceError,
)

CATALOG_URL = "https://data.cms.gov/data.json"
API = "https://data.cms.gov/data-api/v1/dataset/"
SERIES = ("Medicare Part D Spending by Drug", "Medicaid Spending by Drug", "Medicare Part B Spending by Drug")
MAX_CATALOG_BYTES = 64 * 1024 * 1024
MAX_PAGE_BYTES = 16 * 1024 * 1024
MAX_BYTES = MAX_CATALOG_BYTES  # Largest original evidence member, including the shared catalog.
MAX_PAGES = 64
CmsError = PagedJsonSourceError
CMS = JsonPageFamily(
    name="cms-drug-spending",
    label="CMS drug spending",
    host="data.cms.gov",
    next_kind="offset",
    limit_field="size",
    credential_header=None,
    requires_credential=False,
)
_UUID = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
_SELECTION_KEYS = {
    "series_title",
    "series_id",
    "dataset_id",
    "release_date",
    "modified",
    "api_url",
    "dictionary_url",
    "catalog_sha256",
    "dictionary_sha256",
    "total_rows",
}


def _one(values, label):
    if len(values) != 1:
        raise CmsError(f"CMS {label} is missing or ambiguous")
    return values[0]


def resolve_release(catalog, *, series_title, release_date=None):
    """Select one series release and its versioned API, never the mutable alias."""
    if series_title not in SERIES or not isinstance(catalog, dict):
        raise CmsError("unsupported CMS series or catalog")
    standard = catalog.get("conformsTo", {})
    if not isinstance(standard, dict) or standard.get("identifier") != "https://resources.data.gov/dcat-us/3.0.0":
        raise CmsError("CMS catalog is not DCAT-US 3")
    series = _one([s for s in catalog.get("datasetSeries", []) if s.get("title") == series_title], "series")
    releases = [
        d for d in catalog.get("dataset", []) if any(s.get("@id") == series.get("@id") for s in d.get("inSeries", []))
    ]
    if release_date is None:
        releases = [d for d in releases if d.get("@id") == series.get("last", {}).get("@id")]
    else:
        date.fromisoformat(release_date)
        releases = [d for d in releases if any(t.get("startDate") == release_date for t in d.get("temporal", []))]
    dataset = _one(releases, "release")
    distribution = _one(
        [
            d
            for d in dataset.get("distribution", [])
            if d.get("format") == "API" and d.get("description") != "latest" and d.get("accessURL") != series.get("@id")
        ],
        "versioned API distribution",
    )
    temporal = _one(dataset.get("temporal", []), "release period")
    api_url = distribution.get("accessURL")
    dictionary = distribution.get("describedBy", {}).get("downloadURL")
    if not isinstance(api_url, str) or re.fullmatch(re.escape(API) + _UUID + "/data", api_url) is None:
        raise CmsError("CMS versioned API route differs")
    if dictionary != api_url.removesuffix("/data") + "/dictionary":
        raise CmsError("CMS dictionary is not bound to the selected distribution")
    return {
        "series_title": series_title,
        "series_id": series["@id"],
        "dataset_id": dataset["@id"],
        "release_date": temporal["startDate"],
        "modified": dataset["modified"],
        "api_url": api_url,
        "dictionary_url": dictionary,
    }


def validate_selection(selection):
    if not isinstance(selection, dict) or set(selection) != _SELECTION_KEYS:
        raise CmsError("CMS selection fields differ")
    if selection["series_title"] not in SERIES:
        raise CmsError("unsupported CMS series")
    for key, suffix in (("api_url", "data"), ("series_id", "data"), ("dataset_id", "data-viewer")):
        if (
            not isinstance(selection[key], str)
            or re.fullmatch(re.escape(API) + _UUID + "/" + suffix, selection[key]) is None
        ):
            raise CmsError("CMS selected endpoint differs")
    if selection["dictionary_url"] != selection["api_url"].removesuffix("/data") + "/dictionary":
        raise CmsError("CMS selected dictionary differs")
    for key in ("release_date", "modified"):
        date.fromisoformat(selection[key])
    for key in ("catalog_sha256", "dictionary_sha256"):
        if not isinstance(selection[key], str) or re.fullmatch(r"sha256:[0-9a-f]{64}", selection[key]) is None:
            raise CmsError("CMS metadata pin differs")
    if type(selection["total_rows"]) is not int or not 0 <= selection["total_rows"] <= MAX_PAGES * 5000:
        raise CmsError("CMS selected row count exceeds the bounded traversal")
    return selection


def capture_descriptor(capture, role):
    bound = MAX_CATALOG_BYTES if role == "catalog" else MAX_PAGE_BYTES
    if (
        capture.requested_url != capture.resolved_url
        or capture.status_code != 200
        or capture.method != "GET"
        or capture.request_body is not None
        or capture.content_encoding != "identity"
        or (capture.content_type or "").split(";", 1)[0].strip().lower() != "application/json"
        or not 0 < capture.byte_size <= bound
    ):
        raise CmsError("CMS capture representation or bound differs")
    instant = datetime.fromisoformat(capture.observed_at)
    if instant.utcoffset() is None:
        raise CmsError("CMS observation timestamp needs a timezone")
    return {
        "request_url": capture.requested_url,
        "response_sha256": capture.sha256,
        "observed_at": capture.observed_at,
        "byte_size": capture.byte_size,
        "role": role,
    }


def read_control(raw, role, selection):
    """Validate original metadata without equating dictionary fields with all data keys."""
    value = load_integer_json(raw, source="CMS", error_type=CmsError)
    if role == "catalog":
        expected = resolve_release(
            value, series_title=selection["series_title"], release_date=selection["release_date"]
        )
        if expected != {key: selection[key] for key in expected}:
            raise CmsError("CMS selected release differs from its retained catalog")
    elif role == "dictionary":
        fields = value.get("data", {}).get("fields") if isinstance(value, dict) else None
        if (
            not isinstance(fields, list)
            or not fields
            or any(not isinstance(f, dict) or not isinstance(f.get("name"), str) for f in fields)
        ):
            raise CmsError("CMS dictionary fields are missing")
        names = [f["name"] for f in fields]
        identity = (
            {"HCPCS_Cd", "HCPCS_Desc", "Brnd_Name", "Gnrc_Name"}
            if selection["series_title"] == "Medicare Part B Spending by Drug"
            else {"Brnd_Name", "Gnrc_Name", "Tot_Mftr", "Mftr_Name"}
        )
        if len(names) != len(set(names)) or not identity <= set(names):
            raise CmsError("CMS dictionary identity fields differ")
    elif role == "stats":
        if not isinstance(value, dict) or any(
            type(value.get(k)) is not int or value[k] != selection["total_rows"] for k in ("found_rows", "total_rows")
        ):
            raise CmsError("CMS declared population differs")
    else:
        raise CmsError("unknown CMS control")
    return value


def cms_selection(catalog, dictionary, stats, *, series_title, release_date=None):
    """Bind the selected version to original catalog, dictionary and count captures."""
    controls = [
        capture_descriptor(c, role)
        for c, role in zip((catalog, dictionary, stats), ("catalog", "dictionary", "stats"), strict=True)
    ]
    selected = resolve_release(
        load_integer_json(catalog.body, source="CMS", error_type=CmsError),
        series_title=series_title,
        release_date=release_date,
    )
    value = load_integer_json(stats.body, source="CMS stats", error_type=CmsError)
    selected.update(
        catalog_sha256=catalog.sha256, dictionary_sha256=dictionary.sha256, total_rows=value.get("total_rows")
    )
    validate_selection(selected)
    if [c["request_url"] for c in controls] != [
        CATALOG_URL,
        selected["dictionary_url"],
        selected["api_url"] + "/stats",
    ]:
        raise CmsError("CMS control routes differ from the selected release")
    for capture, role in ((dictionary, "dictionary"), (stats, "stats")):
        read_control(capture.body, role, selected)
    return selected


def page_url(selection, *, size=5000, offset=0):
    return selection["api_url"] + "?" + urlencode({"size": size, "offset": offset})


def selected_page(url, selection):
    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    values = dict(pairs)
    if (
        url.split("?", 1)[0] != selection["api_url"]
        or parts.fragment
        or len(pairs) != 2
        or set(values) != {"size", "offset"}
        or any(not v.isascii() or not v.isdigit() for v in values.values())
    ):
        raise CmsError("CMS request changes the selected route or query")
    size, offset = int(values["size"]), int(values["offset"])
    if not 1 <= size <= 5000 or offset % size or offset > selection["total_rows"]:
        raise CmsError("CMS page size or offset differs")
    return size, offset


class CmsReader(PagedJsonReader):
    """Adapt the CMS root array; retain the existing offset and traversal authority."""

    def __init__(self, selection, *, budget: PagedJsonBudget, **kwargs):
        self.selection = validate_selection(selection)
        if budget.max_requests > MAX_PAGES or budget.max_page_bytes > MAX_PAGE_BYTES:
            raise CmsError("CMS acquisition exceeds its bounded selection")
        super().__init__(family=CMS, budget=budget, **kwargs)

    def page(self, url, **kwargs):
        selected_page(url, self.selection)
        return super().page(url, **kwargs)

    def read(self, *, size=5000, max_pages=MAX_PAGES):
        if type(max_pages) is not int or not 1 <= max_pages <= MAX_PAGES:
            raise CmsError("CMS page bound is invalid")
        return self.pages(page_url(self.selection, size=size), records_key="data", max_pages=max_pages)

    def _read_page(self, capture, *, url, body, records_key, page_index, single_record):
        capture_descriptor(capture, "data")
        size, offset = selected_page(url, self.selection)
        rows = load_integer_json(capture.body, source="CMS data", error_type=CmsError)
        expected = min(size, self.selection["total_rows"] - offset)
        if (
            body is not None
            or single_record
            or not isinstance(rows, list)
            or len(rows) != expected
            or any(
                not isinstance(row, dict)
                or not row
                or any(not isinstance(v, str) and v is not None for v in row.values())
                for row in rows
            )
        ):
            raise CmsError("CMS literal rows or selected page count differ")
        next_url, next_body = super()._continuation({}, url=url, body=body, rows=rows)
        # /stats is the selected count authority. Do not request an extra empty
        # page when a complete final page ends exactly at that count.
        if offset + len(rows) == self.selection["total_rows"]:
            next_url = None
        return JsonPage(
            page_index, records_key, capture, tuple(rows), self.selection["total_rows"], next_url, body, next_body
        )


def read_capture(capture, selection):
    with CmsReader(selection, budget=PagedJsonBudget(1, MAX_PAGE_BYTES, 30, 0)) as reader:
        return reader._read_page(
            capture, url=capture.requested_url, body=None, records_key="data", page_index=0, single_record=False
        )
