"""GAO's Month in Review and Annual Index: the publisher's own list of the products it issued, by month and year.

GAO states the listing on its Month in Review page: "GAO makes monthly and annual lists of our reports, grouped by
topic". Probed 2026-09-28 (``corpora/mcp-chaos-2026-09-28/gao-sitemap/``), month pages
(``/reports-testimonies/month-in-review/2026/August``) and year pages (``.../2025``; ``.../2009`` answers though the
landing page links only 2015 on) are one Drupal view of 25 teasers a page, paged with ``?page=N`` and grouped under
GAO's topic headings, then its legal-product headings. A year page is a calendar year of releases, although its
title says "(FY2025)". A product sits under every topic it carries, so it can appear on several pages. Each teaser
states the product number, its product link, a label and a heading (GAO's title is ``label: heading``), and
"Published" and "Publicly Released" dates. A month's list can hold a product released in the month before, so no date
is checked against the scope.

``www.gao.gov`` refuses plain clients, so pages come through Zyte, as product pages do. ``robots.txt`` disallows
``/reports-testimonies`` by prefix and asks for a 420-second ``Crawl-delay``. The walk and re-read, shared with the
major-rule listing, are ``listing.py``'s: its default honours that delay, one worker, one request every 420 seconds,
under a hard Zyte budget, resuming from its own receipts. For the backfill of 2009-2025 and January-August 2026
(2026-09-28) the owner overrode it with run flags; see ``docs/decisions.md``.

The number decides the class: ``GAO-`` is a product, ``B-`` a legal decision (its numbers split, one teaser can name
several), anything else is kept apart. One named exception, the owner's: every Federal Agency Major Rule Report is a
product, GAO-numbered up to February 2017 and B-numbered from April 2017, keyed on its page.
"""

from __future__ import annotations

import argparse
import re
from collections.abc import Iterable
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Final
from urllib.parse import unquote

from spicy_docs.reading.markup import HTML_VOID_TAGS, decode_html_page, feed_html
from spicy_docs.sources.gao.listing import (
    CRAWL_DELAY_SECONDS,
    DEFAULT_MAX_LAST_PAGE_INDEX,
    DEFAULT_MAX_PAGE_BYTES,
    MAX_BACKOFF_SECONDS,
    MAX_CONCURRENCY,
    MAX_PAGE_BYTES,
    MAX_SCOPE_RESTARTS,
    TRAILING_DUPLICATE_PATH,
    GaoListingAcquirer,
    GaoListingBudget,
    GaoListingMovedError,
    GaoListingSourceError,
    GaoListingUnavailableError,
    RetainedListingPage,
    add_read_arguments,
    add_walk_arguments,
    listing_date,
    listing_text,
    names_page,
    read_retained_pages,
    spelled,
    walk_command,
    walk_listing,
    write_items,
)
from spicy_docs.sources.gao.native import GaoProductSourceError, gao_product_id

LISTING_URL: Final = "https://www.gao.gov/reports-testimonies/month-in-review"
MONTHS: Final = (
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
)
#: GAO's label and heading for a major-rule report. Every one of the 1,655 on the 2009-2026 walk carries both.
MAJOR_RULE_REPORT: Final = "Federal Agency Major Rule Report"
_LABEL: Final = "GAO listing page"
_PAGE_HREF = re.compile(r"\?page=(\d+)")
#: One B-number as GAO states it: its file number, then whatever suffix older decisions carry (``B-235577.2-O.M.``).
#: Decisions are kept apart and keyed on their whole stated number, so each part need only be a B-number, not a
#: checked one.
_DECISION_NUMBER = re.compile(r"B-\d+[A-Z0-9.\-]*")
#: Older decisions list their numbers with commas or semicolons, with stray spaces.
_DECISION_SEPARATOR = re.compile(r"[,;]")
#: The lengths at which GAO's listing number field is full: 64 characters for decisions released 2009-2011, 252 from
#: 2012. On the retained walk of 2026-09-28 (1,212 pages, 7,544 distinct B-numbered fields) no field before 2012 is
#: longer than 64, and all four at 64 end cut, in a separator or mid-number; from 2012 three fields reach 252 and none
#: lies between 203 and 252, two of the three ending "et al" (round 6, 2026-10-03). A full field may have lost numbers.
LISTING_NUMBER_LIMITS: Final = frozenset({64, 252})
#: A whole B-number's file number: six digits, as every number on that walk has but two GAO typos inside a list.
_WHOLE_FILE_NUMBER = re.compile(r"B-\d{6}(?!\d)")
#: A file number and a bare full stop is a number cut before its suffix: 2017's listing states ``B-414056.`` where the
#: decision's File line states B-414056.3.
_DANGLING_STOP = re.compile(r"B-\d+\.")
_PRERELEASE = re.compile(r"/prerelease/[a-z0-9]+")
#: Every field class a teaser states. The status (a decision's outcome sentence, "We deny the protest.") is the fourth:
#: across a retained walk of 1,212 pages and 29,996 teasers these four are the only field classes, and the status was
#: the one not read (5,936 teasers carry it; round 5, scout C, 2026-10-03).
_FIELD_CLASSES: Final = {
    "field--name-field-product-number": "number",
    "field--name-field-issue-date": "published",
    "field--name-field-docdate": "released",
    "field--name-field-legal-prod-decision-status": "status",
}
_DATE_PREFIXES: Final = {"published": "Published:", "released": "Publicly Released:"}
_CAPTURED: Final = frozenset({"label", "heading", "number", "published", "released", "status"})


@dataclass(frozen=True, slots=True)
class GaoListingScope:
    """One year's Annual Index (``month`` None) or one month's Month in Review."""

    year: int
    month: int | None = None

    def __post_init__(self) -> None:
        if isinstance(self.year, bool) or not isinstance(self.year, int) or not 1900 <= self.year <= 2999:
            raise GaoListingSourceError("GAO listing year must be a four-digit year")
        if self.month is not None and (
            isinstance(self.month, bool) or not isinstance(self.month, int) or not 1 <= self.month <= 12
        ):
            raise GaoListingSourceError("GAO listing month must be 1 to 12")

    @classmethod
    def parse(cls, value: str) -> GaoListingScope:
        """``YYYY`` names a year's index, ``YYYY-MM`` a month's review."""
        match = re.fullmatch(r"(\d{4})(?:-(\d{2}))?", value)
        if match is None:
            raise GaoListingSourceError(f"GAO listing scope must be YYYY or YYYY-MM, not {value!r}")
        return cls(int(match[1]), None if match[2] is None else int(match[2]))

    @property
    def key(self) -> str:
        return f"{self.year}" if self.month is None else f"{self.year}-{self.month:02d}"

    @property
    def url(self) -> str:
        """The page's own canonical URL; GAO spells the month by name."""
        return f"{LISTING_URL}/{self.year}" + ("" if self.month is None else f"/{MONTHS[self.month - 1]}")

    def page_url(self, page_index: int) -> str:
        """The first page is the bare URL GAO links; later pages add the pager's ``?page=N``."""
        return self.url if page_index == 0 else f"{self.url}?page={page_index}"

    @property
    def title(self) -> str:
        if self.month is None:
            return f"U.S. GAO - Annual Index of Reports, Testimony and Correspondence (FY{self.year})"
        return f"U.S. GAO - Month in Review, {MONTHS[self.month - 1]} {self.year}"

    def parse_page(
        self,
        body: bytes,
        *,
        page_index: int,
        max_bytes: int,
        max_last_page_index: int,
        expected_last_page_index: int | None,
        expected_page_size: int | None,
    ) -> GaoListingPage:
        """One of this scope's pages, as :func:`parse_listing_page` reads it; the walk's hook."""
        return parse_listing_page(
            body,
            scope=self,
            page_index=page_index,
            max_bytes=max_bytes,
            max_last_page_index=max_last_page_index,
            expected_last_page_index=expected_last_page_index,
            expected_page_size=expected_page_size,
        )


@dataclass(frozen=True, slots=True)
class GaoListingEntry:
    """One teaser as GAO spelled it: a product (``product_id``), a decision (``decision_numbers``), or neither, for a
    number of another form or none (``product_number`` None)."""

    position: int
    topic: str
    product_number: str | None
    link: str
    label: str
    heading: str
    published: str | None
    released: str | None
    product_id: str | None
    decision_numbers: tuple[str, ...]
    #: GAO's outcome sentence for a decision, as written (``We deny the protest.``); None where the teaser states none.
    status: str | None = None
    #: True where GAO's listing cut the decision's number list (:func:`decision_numbers`).
    decision_numbers_cut: bool = False


@dataclass(frozen=True, slots=True)
class GaoListingPage:
    scope: GaoListingScope
    page_index: int
    last_page_index: int
    entries: tuple[GaoListingEntry, ...]


class _ListingHtml(HTMLParser):
    """The head's title and canonical link; inside ``<main>``, headings, teasers and pager links."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.titles: list[list[str]] = []
        self.canonicals: list[str] = []
        self.pagers = 0
        self.pager_links: list[tuple[str, str | None, str | None]] = []
        self.teasers: list[dict] = []
        self._head = self._main = 0
        self._title: list[str] | None = None
        self._heading: list[str] | None = None
        self._topic: str | None = None
        self._in_pager = False
        self._teaser: dict | None = None
        #: Open elements inside the current teaser, each with the role its text takes, if any.
        self._stack: list[tuple[str, str | None]] = []

    @property
    def unclosed(self) -> bool:
        return self._title is not None or self._heading is not None or self._teaser is not None or self._in_pager

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").split())
        if tag == "head":
            self._head += 1
        elif tag == "title" and self._head:
            self._title = []
        elif tag == "link" and (attributes.get("rel") or "").casefold() == "canonical":
            self.canonicals.append(attributes.get("href") or "")
        elif tag == "main":
            self._main += 1
        if not self._main or tag in HTML_VOID_TAGS:
            return
        if self._teaser is not None:
            self._teaser_start(tag, attributes, classes)
        elif tag == "article":
            if "node--type-product" not in classes:
                raise GaoListingSourceError(f"{_LABEL} lists a teaser that is not a product")
            self._teaser = {"topic": self._topic, "fields": {}, "links": {}}
        elif tag == "h2":
            self._heading = []
        elif tag == "nav" and attributes.get("aria-label") == "Pagination":
            self.pagers += 1
            self._in_pager = True
        elif tag == "a" and self._in_pager:
            self.pager_links.append(
                (attributes.get("href") or "", attributes.get("aria-label"), attributes.get("aria-current"))
            )

    def _teaser_start(self, tag: str, attributes: dict[str, str | None], classes: set[str]) -> None:
        if tag == "article":
            raise GaoListingSourceError(f"{_LABEL} nests one teaser inside another")
        assert self._teaser is not None
        parent = next((role for _, role in reversed(self._stack) if role), None)
        role = None
        if tag == "div" and "teaser-search--bookmark" in classes:
            role = "bookmark"
        elif tag == "h3" and "heading" in classes:
            role = "headline"
        elif tag == "a" and parent in ("bookmark", "headline"):
            role = "label" if parent == "bookmark" else "heading"
            self._teaser["links"][role] = attributes.get("href") or ""
        elif tag == "div":
            role = next((name for css, name in _FIELD_CLASSES.items() if css in classes), None)
        if role in _CAPTURED:
            if role in self._teaser["fields"]:
                raise GaoListingSourceError(f"{_LABEL} teaser repeats its {role}")
            self._teaser["fields"][role] = []
        self._stack.append((tag, role))

    def handle_endtag(self, tag: str) -> None:
        if tag == "head" and self._head:
            self._head -= 1
        elif tag == "title" and self._title is not None:
            self.titles.append(self._title)
            self._title = None
        elif tag == "main" and self._main:
            self._main -= 1
        if self._teaser is not None:
            if tag == "article":
                self.teasers.append(self._teaser)
                self._teaser, self._stack = None, []
                return
            for index in range(len(self._stack) - 1, -1, -1):
                if self._stack[index][0] == tag:
                    del self._stack[index:]
                    break
        elif tag == "h2" and self._heading is not None:
            self._topic = _spelled(self._heading, "topic heading")
            self._heading = None
        elif tag == "nav" and self._in_pager:
            self._in_pager = False

    def handle_data(self, data: str) -> None:
        if self._title is not None:
            self._title.append(data)
        if self._teaser is not None:
            role = next((role for _, role in reversed(self._stack) if role in _CAPTURED), None)
            if role is not None:
                self._teaser["fields"][role].append(data)
        elif self._heading is not None:
            self._heading.append(data)


def _text(parts: list[str] | None, name: str) -> str:
    return listing_text(parts, name, label=_LABEL)


def _spelled(parts: list[str] | None, name: str) -> str:
    return spelled(parts, name, label=_LABEL)


def _date(parts: list[str] | None, name: str) -> str | None:
    return listing_date(parts, name, _DATE_PREFIXES[name], label=_LABEL)


def _is_b_number(part: str) -> bool:
    return _DECISION_NUMBER.fullmatch(part) is not None and _DANGLING_STOP.fullmatch(part) is None


def _classed(parts: Iterable[str]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    stated = [part for part in parts if part]
    return tuple(filter(_is_b_number, stated)), tuple(part for part in stated if not _is_b_number(part))


def _parts(text: str) -> list[str]:
    return [part.strip() for part in _DECISION_SEPARATOR.split(text)]


def stated_b_numbers(text: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """A list of decision numbers split on commas and semicolons: its B-numbers, and the other parts it states."""
    return _classed(_parts(text))


def decision_numbers(number: str) -> tuple[tuple[str, ...], bool]:
    """The B-numbers a decision's listed number states, and whether GAO's listing cut the list.

    The list is cut where it ends ``et al`` or in a separator, holds a part that is not a B-number (a cut-off ``B``,
    ``B-414056.`` cut before its suffix), or fills the field (:data:`LISTING_NUMBER_LIMITS`). A full field can end mid-number, so its last part is kept only
    when it is a whole B-number: 2010's ``...,B-401062.6,B-4010`` names no ``B-4010``. The decision page's "File:" line
    states the whole list (:mod:`spicy_docs.sources.gao.decision_pages`).
    """
    parts = _parts(number)
    full = len(number) in LISTING_NUMBER_LIMITS
    open_ended = not parts[-1]
    if full and _WHOLE_FILE_NUMBER.match(parts[-1]) is None:
        parts.pop()
    numbers, others = _classed(parts)
    return numbers, full or open_ended or bool(others)


def _entry(position: int, teaser: dict) -> GaoListingEntry:
    """One teaser, classed by its number, with the owner's one exception for major-rule reports.

    ``GAO-`` is a product and ``B-`` a decision wherever GAO files it: major-rule reports numbered ``GAO-14-253R``
    sit under a legal heading (2009 to February 2017), and three B-numbered decisions sit under topic headings
    (B-310950.2 in 2009, B-318897 in 2010, B-333501 in 2021). Any other number (a Contract Appeals Board docket,
    ``2020-02``; a ``P`` number) or none is set apart. The exception: a teaser labelled Federal Agency Major Rule
    Report is a product whatever its number, so the B-numbered ones from April 2017 on are products too, keyed on
    their page like the others.
    """
    fields, links = teaser["fields"], teaser["links"]
    label, heading = _spelled(fields.get("label"), "label"), _spelled(fields.get("heading"), "heading")
    number = _text(fields.get("number"), "number") or None
    if not (label and heading):
        raise GaoListingSourceError(f"{_LABEL} teaser {position} lacks a label or heading")
    if not teaser["topic"]:
        raise GaoListingSourceError(f"{_LABEL} lists a teaser before any heading")
    link = links.get("label", "")
    gao_numbered = number is not None and number.upper().startswith("GAO-")
    b_numbered = number is not None and number.startswith("B-")
    major_rule = label == MAJOR_RULE_REPORT and (gao_numbered or b_numbered)
    # 2020-2023 link some products by their prerelease path (``/prerelease/3mpz``); the product's page is still
    # ``/products/`` and its number lowercased, checked for GAO-21-584 on 2026-09-28.
    prerelease = gao_numbered and _PRERELEASE.fullmatch(link) is not None
    if link != links.get("heading") or not (link.startswith("/products/") or prerelease):
        raise GaoListingSourceError(f"{_LABEL} teaser {position} does not link one product page")
    slug = number.lower() if prerelease and number is not None else unquote(link.removeprefix("/products/"))
    # A GAO number's link is the number lowercased, or that with Drupal's duplicate-path suffix. Any other number's
    # link need only agree with it token for token: older decisions link ``b-402003-b-402003.2`` for
    # ``B-402003; B-402003.2``, and a docket's second page is ``2020-02-0``.
    if number is not None and not names_page(slug, number, exact=gao_numbered):
        raise GaoListingSourceError(f"{_LABEL} teaser {position} links a page other than its product number")
    product_id: str | None = None
    decisions: tuple[str, ...] = ()
    cut = False
    if gao_numbered or major_rule:
        try:
            gao_product_id(slug)
        except GaoProductSourceError as error:
            raise GaoListingSourceError(f"{_LABEL} teaser {position} names no product id") from error
        product_id = slug
    elif b_numbered and number is not None:
        # The whole stated number keys a decision; its parts are what of it reads as B-numbers.
        decisions, cut = decision_numbers(number)
        if not decisions:
            raise GaoListingSourceError(f"{_LABEL} teaser {position} names no B-number")
    return GaoListingEntry(
        position,
        teaser["topic"],
        number,
        link,
        label,
        heading,
        _date(fields.get("published"), "published"),
        _date(fields.get("released"), "released"),
        product_id,
        decisions,
        _spelled(fields.get("status"), "status") or None,
        cut,
    )


def _last_page_index(reader: _ListingHtml, page_index: int) -> int:
    """The pager's last page; its current page must be the one requested, and every link a ``?page=N``."""
    if not reader.pagers:
        if page_index:
            raise GaoListingSourceError(f"{_LABEL} {page_index} has no pager")
        return 0
    if reader.pagers > 1:
        raise GaoListingSourceError(f"{_LABEL} has more than one pager")
    numbered, current, last = [], [], []
    for href, label, marker in reader.pager_links:
        match = _PAGE_HREF.fullmatch(href)
        if match is None:
            raise GaoListingSourceError(f"{_LABEL} pager links something other than a page")
        index = int(match[1])
        if label is not None and label.startswith("Page "):
            if label != f"Page {index + 1}":
                raise GaoListingSourceError(f"{_LABEL} pager numbers a page inconsistently")
            numbered.append(index)
        if marker == "page":
            current.append(index)
        if label == "Last page":
            last.append(index)
    if current != [page_index]:
        raise GaoListingSourceError(f"{_LABEL} pager does not mark page {page_index} as current")
    if last:
        if len(last) != 1 or last[0] <= page_index:
            raise GaoListingSourceError(f"{_LABEL} pager states an impossible last page")
        return last[0]
    if not numbered or max(numbered) != page_index:
        raise GaoListingSourceError(f"{_LABEL} pager has no last page and page {page_index} is not the last")
    return page_index


def parse_listing_page(
    body: bytes,
    *,
    scope: GaoListingScope,
    page_index: int,
    max_bytes: int = DEFAULT_MAX_PAGE_BYTES,
    max_last_page_index: int = DEFAULT_MAX_LAST_PAGE_INDEX,
    expected_last_page_index: int | None = None,
    expected_page_size: int | None = None,
) -> GaoListingPage:
    """One page, refused unless it is its scope's page ``page_index`` and agrees with the pages already read.

    ``expected_last_page_index`` and ``expected_page_size`` come from the scope's first page: a pager that
    changes its last page, or a page before the last holding a different number of teasers, means the listing
    moved while it was read.
    """
    if isinstance(page_index, bool) or not isinstance(page_index, int) or page_index < 0:
        raise GaoListingSourceError("page_index must be a nonnegative integer")
    text = decode_html_page(body, max_bytes, label=_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoListingSourceError)
    reader = _ListingHtml()
    feed_html(reader, text, label=_LABEL, error_type=GaoListingSourceError)
    if reader.unclosed:
        raise GaoListingSourceError(f"{_LABEL} markup is incomplete")
    if [_text(parts, "title") for parts in reader.titles] != [scope.title]:
        raise GaoListingSourceError(f"{_LABEL} is not titled {scope.title!r}")
    if reader.canonicals != [scope.url]:
        raise GaoListingSourceError(f"{_LABEL} does not name {scope.url} as its canonical URL")
    entries = tuple(_entry(position, teaser) for position, teaser in enumerate(reader.teasers))
    if not entries:
        # An empty page is not an empty listing: nothing on it establishes that GAO listed nothing.
        raise GaoListingSourceError(f"{_LABEL} lists no teaser")
    last = _last_page_index(reader, page_index)
    if last > max_last_page_index:
        raise GaoListingSourceError(f"{_LABEL} pager runs past page index {max_last_page_index}")
    if expected_last_page_index is not None and last != expected_last_page_index:
        raise GaoListingMovedError(
            f"{_LABEL} pager changed shape: last page {last}, not {expected_last_page_index}; the listing moved"
        )
    if expected_page_size is not None and (
        len(entries) > expected_page_size or (page_index < last and len(entries) != expected_page_size)
    ):
        raise GaoListingMovedError(
            f"{_LABEL} {page_index} holds {len(entries)} teasers where the first page held {expected_page_size}"
        )
    return GaoListingPage(scope, page_index, last, entries)


@dataclass(frozen=True, slots=True)
class GaoListedProduct:
    """One product, once, with every topic heading it sat under and every scope that listed it."""

    product_id: str
    product_number: str
    #: The teaser's label; None only for a product another listing adds that names none (the major-rule listing's
    #: AIMD- and GGD- pages, ``major_rule_reports.merge_with_month_in_review``). This listing always states one.
    label: str | None
    heading: str
    published: str | None
    released: str | None
    topics: tuple[str, ...]
    scopes: tuple[str, ...]
    #: A status on a product's teaser is rare (GAO-20-220SP, an annual bid-protest report) but kept, not dropped.
    status: str | None = None

    @property
    def title(self) -> str:
        """GAO's title for the product, ``label: heading``, as its product page and feed spell it; the heading alone
        where no label is stated."""
        return self.heading if self.label is None else f"{self.label}: {self.heading}"


@dataclass(frozen=True, slots=True)
class GaoListedDecision:
    """One B-numbered legal decision's page, its numbers split; outside the product listing.

    Keyed on its page, not its number: 2019-2021 give one B-number two pages (``b-331093`` and ``b-331093-0``),
    released months apart, and B-333110's second is an update with its own heading.
    """

    product_number: str
    decision_numbers: tuple[str, ...]
    link: str
    label: str
    heading: str
    published: str | None
    released: str | None
    topics: tuple[str, ...]
    scopes: tuple[str, ...]
    #: GAO's outcome sentence, word for word; None where the listing states none.
    status: str | None = None
    #: The first listing page (its URL, as requested) that listed this page: the evidence a reader can open.
    listing_page: str | None = None
    #: True where GAO's listing cut the number list, so ``decision_numbers`` holds only what it names.
    decision_numbers_cut: bool = False


@dataclass(frozen=True, slots=True)
class GaoListedOther:
    """One page listed with no product or B-number, by its link: a docket-numbered Contract Appeals Board decision,
    a ``P`` number, or no number at all (an Antideficiency Act report, forum materials); outside the products."""

    product_number: str | None
    link: str
    label: str
    heading: str
    published: str | None
    released: str | None
    topics: tuple[str, ...]
    scopes: tuple[str, ...]
    #: GAO's outcome sentence, word for word; None where the listing states none.
    status: str | None = None
    #: The first listing page (its URL, as requested) that listed this page: the evidence a reader can open.
    listing_page: str | None = None


@dataclass(frozen=True, slots=True)
class GaoListingRun:
    """The verified pages of every complete scope, and the products and decisions they list."""

    pages: tuple[RetainedListingPage, ...]
    products: tuple[GaoListedProduct, ...]
    decisions: tuple[GaoListedDecision, ...]
    others: tuple[GaoListedOther, ...]
    complete_scopes: tuple[str, ...]
    incomplete_scopes: tuple[str, ...]


def collect_listing(
    pages: Iterable[GaoListingPage],
) -> tuple[tuple[GaoListedProduct, ...], tuple[GaoListedDecision, ...], tuple[GaoListedOther, ...]]:
    """Each product once by its id, each decision and other page once by its page, in first-listed order.

    One listed twice with differing fields refuses. A product's link is not among them: 2020-2023 link one product
    by its prerelease path in one place and its page in another. A product listed on a suffixed twin page too
    (``gao-16-75sp`` and ``gao-16-75sp-0``) is one product, on the base page, when every other field agrees; a twin
    that differs (``gao-14-280r-0``, a VA major-rule report beside Defense's ``gao-14-280r``) is its own product.
    """
    found: dict[tuple[str, str], tuple[GaoListingEntry, list[str], list[str], str]] = {}
    for page in pages:
        for entry in page.entries:
            key = ("product", entry.product_id) if entry.product_id else ("page", unquote(entry.link))
            held = found.setdefault(key, (entry, [], [], page.scope.page_url(page.page_index)))
            if _fixed(held[0]) != _fixed(entry):
                raise GaoListingSourceError(
                    f"GAO listing states {entry.product_number or entry.link} with differing fields"
                )
            for values, value in ((held[1], entry.topic), (held[2], page.scope.key)):
                if value not in values:
                    values.append(value)
    for key in [key for key in found if key[0] == "product"]:
        suffix = TRAILING_DUPLICATE_PATH.search(key[1])
        base = ("product", key[1][: suffix.start()]) if suffix else None
        if base in found and _same_product(found[base][0], found[key][0]):
            _, topics, scopes, _ = found.pop(key)
            for held, values in ((found[base][1], topics), (found[base][2], scopes)):
                held.extend(value for value in values if value not in held)
    products, decisions, others = [], [], []
    for entry, topics, scopes, first_page in found.values():
        seen = (entry.published, entry.released, tuple(topics), tuple(scopes))
        if entry.product_id is not None:
            products.append(
                GaoListedProduct(
                    entry.product_id, entry.product_number or "", entry.label, entry.heading, *seen, status=entry.status
                )
            )
        elif entry.decision_numbers:
            decisions.append(
                GaoListedDecision(
                    entry.product_number or "",
                    entry.decision_numbers,
                    entry.link,
                    entry.label,
                    entry.heading,
                    *seen,
                    status=entry.status,
                    listing_page=first_page,
                    decision_numbers_cut=entry.decision_numbers_cut,
                )
            )
        else:
            others.append(
                GaoListedOther(
                    entry.product_number,
                    entry.link,
                    entry.label,
                    entry.heading,
                    *seen,
                    status=entry.status,
                    listing_page=first_page,
                )
            )
    return tuple(products), tuple(decisions), tuple(others)


def _same_product(base: GaoListingEntry, twin: GaoListingEntry) -> bool:
    """A suffixed twin states its base page's product: every fixed field but the page agrees."""
    return _fixed(base)[1:] == _fixed(twin)[1:]


def _fixed(entry: GaoListingEntry) -> tuple:
    """What must agree wherever GAO lists the same teaser; its topic, position and a product's link may differ."""
    return (
        entry.product_id,
        entry.product_number,
        None if entry.product_id else entry.link,
        entry.decision_numbers,
        entry.label,
        entry.heading,
        entry.published,
        entry.released,
        entry.status,
    )


def read_listing_run(
    receipts: Path,
    store: Path,
    *,
    max_page_bytes: int = MAX_PAGE_BYTES,
    max_last_page_index: int = DEFAULT_MAX_LAST_PAGE_INDEX,
) -> GaoListingRun:
    """Re-read a walk's retained pages: each digest re-checked, each page re-parsed against its scope's first page.

    Only a scope whose every page is retained counts; the others are named in ``incomplete_scopes`` and read
    nothing. Bytes come from ``store`` and must equal what ``receipts`` recorded.
    """
    retained = read_retained_pages(
        receipts,
        store,
        scope_of=GaoListingScope.parse,
        max_page_bytes=max_page_bytes,
        max_last_page_index=max_last_page_index,
    )
    products, decisions, others = collect_listing(page.page for page in retained.pages)  # type: ignore[misc]
    return GaoListingRun(
        retained.pages, products, decisions, others, retained.complete_scopes, retained.incomplete_scopes
    )


def _read(args: argparse.Namespace) -> int:
    run = read_listing_run(args.receipts, args.store)
    kinds = {GaoListedProduct: "product", GaoListedDecision: "decision"}
    write_items(
        ((kinds.get(type(item), "other"), item) for item in (*run.products, *run.decisions, *run.others)),
        {
            "pages": len(run.pages),
            "products": len(run.products),
            "decisions": len(run.decisions),
            "others": len(run.others),
            "complete_scopes": run.complete_scopes,
            "incomplete_scopes": run.incomplete_scopes,
        },
        args.output,
    )
    return 0


def parser() -> argparse.ArgumentParser:
    """The command's arguments; its defaults are the polite walk, one worker 420 seconds apart."""
    parser = argparse.ArgumentParser(description="Walk or read GAO's Month in Review and Annual Index pages")
    commands = parser.add_subparsers(dest="command", required=True)
    walk = commands.add_parser("walk", help="Capture listing pages through Zyte, resuming from the receipts")
    walk.add_argument("--scope", action="append", required=True, help="YYYY for a year's index, YYYY-MM for a month")
    add_walk_arguments(walk)
    read = commands.add_parser("read", help="Verify retained pages offline and print products and decisions as JSONL")
    add_read_arguments(read)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.command == "read":
        return _read(args)
    return walk_command(
        args,
        lambda: [GaoListingScope.parse(value) for value in args.scope],
        max_last_page_index=DEFAULT_MAX_LAST_PAGE_INDEX,
    )


__all__ = [
    "CRAWL_DELAY_SECONDS",
    "DEFAULT_MAX_LAST_PAGE_INDEX",
    "DEFAULT_MAX_PAGE_BYTES",
    "LISTING_NUMBER_LIMITS",
    "LISTING_URL",
    "MAJOR_RULE_REPORT",
    "MAX_BACKOFF_SECONDS",
    "MAX_CONCURRENCY",
    "MAX_PAGE_BYTES",
    "MAX_SCOPE_RESTARTS",
    "GaoListedDecision",
    "GaoListedOther",
    "GaoListedProduct",
    "GaoListingAcquirer",
    "GaoListingBudget",
    "GaoListingEntry",
    "GaoListingMovedError",
    "GaoListingPage",
    "GaoListingRun",
    "GaoListingScope",
    "GaoListingSourceError",
    "GaoListingUnavailableError",
    "RetainedListingPage",
    "collect_listing",
    "decision_numbers",
    "parse_listing_page",
    "parser",
    "read_listing_run",
    "stated_b_numbers",
    "walk_listing",
]


if __name__ == "__main__":
    raise SystemExit(main())
