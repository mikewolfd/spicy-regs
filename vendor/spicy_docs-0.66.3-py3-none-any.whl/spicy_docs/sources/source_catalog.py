"""Replay bounded publisher metadata as facts, without selecting data or routes.

The exact capture remains the authority for original JSON spelling and XML.
Normalized records preserve parsed unknown fields and report defective entries.
An observed page never establishes collection-wide enumeration or availability.
"""

from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict
from decimal import Decimal
from typing import Any
from urllib.parse import parse_qsl, urlsplit
from xml.etree.ElementTree import tostring

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.reading.paged_json import JsonPage, query_value
from spicy_docs.reading.s3_listing import parse_s3_listing
from spicy_docs.reading.xml import parse_xml
from spicy_docs.sources.courtlistener.listing import BulkObject, parse_listing_page
from spicy_docs.sources.govinfo.discovery import GOVINFO, GRANULES_KEY, package_granules_url, validate_identified_page
from spicy_docs.sources.usaspending import (
    MONTHLY_FILES_PARSER_VERSION,
    MONTHLY_FILES_URL,
    monthly_files_body,
    validate_monthly_files_capture,
)
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.credentials import CredentialRefusedError, failure_reason, scrub_record

MAX_METADATA_BYTES = 8 * 1024**2
KINDS = (
    "dcat",
    "datagov-v4",
    "govinfo-bulk",
    "sitemap",
    "s3",
    "courtlistener",
    "ecfr-titles",
    "usaspending-monthly-files",
)
# Pilot guards, not claims about the publisher's population or API limits.
DATAGOV_MAX_BYTES = 1024**2
DATAGOV_MAX_PAGE_SIZE = 100
DATAGOV_SEARCH_URL = "https://api.gsa.gov/technology/datagov/v4/search"


def datagov_scope(url: str) -> dict[str, Any]:
    """Validate one explicit federal search; never follow a response locator."""
    parts = urlsplit(url)
    if len(url) > 16 * 1024 or parts._replace(query="").geturl() != DATAGOV_SEARCH_URL:
        raise ValueError("Data.gov requires the exact v4 HTTPS search endpoint")
    pairs = parse_qsl(parts.query, keep_blank_values=True, max_num_fields=8)
    query = dict(pairs)
    if len(query) != len(pairs) or set(query) - {"q", "org_slug", "org_type", "per_page", "sort", "after"}:
        raise ValueError("Data.gov query has repeated or unsupported parameters")
    if query.get("org_type") != "Federal Government" or not (
        query.get("q", "").strip() or query.get("org_slug", "").strip()
    ):
        raise ValueError("Data.gov requires a selected query or organization and federal organization type")
    size = query.get("per_page", "")
    if not size.isascii() or not size.isdigit() or not 1 <= int(size) <= DATAGOV_MAX_PAGE_SIZE:
        raise ValueError("Data.gov requires per_page within the bounded pilot range")
    if "after" in query and (not query["after"] or len(query["after"]) > 8192):
        raise ValueError("Data.gov request cursor is empty or exceeds its bound")
    if query.get("sort", "relevance") not in {"relevance", "popularity", "distance", "last_harvested_date"}:
        raise ValueError("Data.gov query sort is unsupported")
    return {"selected_url": url, "query": query, "per_page": int(size), "request_cursor": query.get("after")}


def stable_id(namespace: str, kind: str, native_id: str) -> str:
    """Unambiguous source-scoped identity; capture versions have separate IDs."""
    value = f"{namespace}\0{kind}\0{native_id}".encode()
    return f"{kind}:{hashlib.sha256(value).hexdigest()}"


def usaspending_monthly_files_metadata(
    capture: CapturedBodyResponse, *, namespace: str, request_body: dict[str, Any]
) -> dict[str, Any]:
    """Map one exactly bound POST capture; malformed pages admit no items."""
    if namespace != "usaspending:award-data-archive":
        raise ValueError("monthly files namespace must be usaspending:award-data-archive")
    selected = monthly_files_body(request_body)
    data = validate_monthly_files_capture(capture, selected)
    query = json.dumps(selected, sort_keys=True, separators=(",", ":"))
    scope = {"query": selected, "parser_version": MONTHLY_FILES_PARSER_VERSION}
    cid = stable_id(namespace, "collection", "award-data-archive")
    rid = stable_id(namespace, "route", f"POST\0{MONTHLY_FILES_URL}")
    oid = stable_id(
        namespace,
        "observation",
        f"POST\0{MONTHLY_FILES_URL}\0{query}\0{MONTHLY_FILES_PARSER_VERSION}\0{capture.sha256}\0{capture.observed_at}",
    )
    return scrub_record(
        {
            "format": "spicy-source-discovery",
            "version": 1,
            "collections": [
                {"id": cid, "namespace": namespace, "native_id": "award-data-archive", "observation_ids": [oid]}
            ],
            "routes": [
                {
                    "id": rid,
                    "collection_id": cid,
                    "access_url": MONTHLY_FILES_URL,
                    "method": "POST",
                    "delivery_method": "api",
                }
            ],
            "observations": [
                {
                    "id": oid,
                    "capture_url": MONTHLY_FILES_URL,
                    "method": "POST",
                    "scope": scope,
                    "observed_at": capture.observed_at,
                    "sha256": capture.sha256,
                    "bytes": capture.byte_size,
                    "request_body_sha256": "sha256:" + hashlib.sha256(capture.request_body).hexdigest(),
                    "content_type": capture.content_type,
                    "metadata_kind": "usaspending-monthly-files",
                    "status": "observed-page" if data["monthly_files"] else "requested-empty",
                    "page_terminal": True,
                    "enumeration_complete": False,
                    "inventory_stable": False,
                    "removal_eligible": False,
                    "expected_count": None,
                    "collection_ids": [cid],
                    "raw": data,
                }
            ],
            "items": [
                {
                    "id": stable_id(namespace, "item", f"{query}\0{row['file_name']}"),
                    "native_id": row["file_name"],
                    "name": row["file_name"],
                    "collection_id": cid,
                    "route_id": rid,
                    "access_url": row["url"],
                    "status": "advertised",
                    "raw": row,
                    "source_position": index,
                    "observation_id": oid,
                    "version_id": stable_id(namespace, "item-version", f"{oid}\0{row['file_name']}"),
                    "requested_fiscal_year": selected["fiscal_year"],
                    "publisher_fiscal_year": row["fiscal_year"],
                    "publisher_period_scope": "unspecified" if row["fiscal_year"] is None else "fiscal-year",
                }
                for index, row in enumerate(data["monthly_files"])
            ],
            "periods": [],
            "errors": [],
        }
    )


def govinfo_granule_metadata(
    page: JsonPage, *, namespace: str, package_id: str, secrets: tuple[str, ...] = ()
) -> dict[str, Any]:
    """Convert one retained GovInfo granule page without transport or traversal.

    Refuse forged page fields and fractional numbers rather than rounding raw
    metadata. Integral Decimal values retain their numeric meaning as integers.
    Capture bytes remain the authority; external selection pins belong to callers.
    """
    capture = page.capture
    expected_path = urlsplit(package_granules_url(package_id)).path
    if namespace != f"govinfo:package-granules:{package_id}" or page.records_key != GRANULES_KEY:
        raise ValueError("granule page must identify the selected package and native records key")

    def selected_url(url: str) -> str:
        normalized = GOVINFO.check_url(url)
        parts = urlsplit(url)
        if parts.netloc != GOVINFO.host or parts.path != expected_path or parts.fragment:
            raise ValueError("granule URL differs from the selected package route")
        if scrub_record(url, *secrets) != url:
            raise ValueError("granule URL must not carry credentials")
        return normalized

    requested = selected_url(capture.requested_url)
    page_size = query_value(requested, "pageSize")
    offset_mark = query_value(requested, "offsetMark")
    if page_size is None or not page_size.isdigit() or not offset_mark:
        raise ValueError("granule request must state pageSize and offsetMark")
    package_granules_url(package_id, page_size=int(page_size))
    if selected_url(capture.resolved_url) != requested:
        raise ValueError("resolved granule URL differs from the selected request")
    media = (capture.content_type or "").split(";", 1)[0].strip().lower()
    if (
        capture.status_code != 200
        or capture.method != "GET"
        or capture.request_body is not None
        or page.request_body is not None
        or page.next_body is not None
        or capture.content_encoding != "identity"
        or media not in GOVINFO.media_types
        or not capture.observed_at
    ):
        raise ValueError("granule conversion requires a successful retained JSON GET capture")
    digest = "sha256:" + hashlib.sha256(capture.body).hexdigest()
    if capture.sha256 != digest:
        raise ValueError("granule capture digest differs from its bytes")
    data = load_bounded_json(
        capture.body,
        source="GovInfo granule metadata",
        error_type=ValueError,
        number_policy="decimal",
        max_bytes=MAX_METADATA_BYTES,
    )
    if not isinstance(data, dict):
        raise ValueError("granule metadata root must be an object")  # noqa: TRY004 - defective source JSON
    rows, count = data.get(GRANULES_KEY), data.get("count")
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        raise ValueError("granule metadata must state a granules object array")
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise ValueError("granule metadata must state a nonnegative integer count")
    if count < len(rows):
        raise ValueError("granule response contains more rows than its declared count")
    if (
        isinstance(page.declared_count, bool)
        or not isinstance(page.declared_count, int)
        or count != page.declared_count
        or tuple(rows) != page.records
    ):
        raise ValueError("granule page rows or count differ from the retained response")
    next_url = data.get("nextPage")
    if next_url is not None:
        if not isinstance(next_url, str) or not next_url:
            raise ValueError("granule continuation is invalid")
        next_url = selected_url(next_url)
        if next_url == requested:
            raise ValueError("granule response repeats its continuation")
    if next_url != page.next_url:
        raise ValueError("granule continuation differs from the retained response")
    validate_identified_page(page, "granuleId", set())

    def integer_number(value: Any) -> int:
        if not isinstance(value, Decimal):
            raise TypeError("metadata contains an unsupported JSON value")
        # A short exponent can encode an enormous integer. Bound its expanded
        # digits before conversion using Python's default JSON integer limit.
        if value.adjusted() >= sys.int_info.default_max_str_digits:
            raise ValueError("granule integer expansion exceeds the serialization digit bound")
        if value != value.to_integral_value():
            raise ValueError("fractional granule metadata requires lossless serialization; page refused")
        return int(value)

    # Ordinary discovery JSON has no exact fractional-number encoder. Refuse
    # before admitting items; integral decimal spellings retain numeric meaning.
    data = json.loads(json.dumps(data, default=integer_number))
    rows = data[GRANULES_KEY]
    cid = stable_id(namespace, "collection", package_id)
    rid = stable_id(namespace, "route", capture.requested_url)
    oid = stable_id(namespace, "observation", f"{capture.requested_url}\0{digest}\0{capture.observed_at}")
    out = {
        "format": "spicy-source-discovery",
        "version": 1,
        "collections": [{"id": cid, "namespace": namespace, "native_id": package_id, "observation_ids": [oid]}],
        "routes": [{"id": rid, "collection_id": cid, "access_url": capture.requested_url, "delivery_method": "api"}],
        "observations": [
            {
                "id": oid,
                "capture_url": capture.requested_url,
                "observed_at": capture.observed_at,
                "sha256": digest,
                "bytes": len(capture.body),
                "content_type": capture.content_type,
                "scope": {
                    "package_id": package_id,
                    "selected_url": capture.requested_url,
                    "page_size": int(page_size),
                    "offset_mark": offset_mark,
                },
                "metadata_kind": "govinfo-package-granules",
                "status": "observed-page",
                "enumeration_complete": False,
                "inventory_stable": False,
                "removal_eligible": False,
                "collection_ids": [cid],
                "raw": data,
            }
        ],
        "items": [
            {
                "id": stable_id(namespace, "item", f"{rid}\0{row['granuleId']}"),
                "collection_id": cid,
                "route_id": rid,
                "native_id": row["granuleId"],
                "name": row.get("title", row["granuleId"]),
                "access_url": row.get("granuleLink"),
                "status": "advertised",
                "raw": row,
                "observation_id": oid,
                "version_id": stable_id(namespace, "item-version", f"{row['granuleId']}\0{digest}"),
            }
            for row in rows
        ],
        "periods": [],
        "errors": [],
    }
    return scrub_record(out, *secrets)


def parse_metadata(
    payload: bytes,
    *,
    kind: str,
    namespace: str,
    capture_url: str,
    observed_at: str,
    sha256: str | None = None,
    content_type: str | None = None,
    scope: dict[str, Any] | None = None,
    bucket: str | None = None,
    prefix: str | None = None,
    secrets: tuple[str, ...] = (),
    retained_capture: CapturedBodyResponse | None = None,
    request_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Read one caller-selected capture; no requests, implicit traversal or policy.

    ``sha256`` pins decoded payload bytes. A mismatched digest refuses parsing.
    ``scope`` names the caller's query, not the collection's covered period.
    Snapshot, modification and filename dates remain raw metadata, not periods.
    Credential values are removed from normalized records; exact originals must
    be held privately by the caller. Unknown fields otherwise remain intact.
    """
    if kind not in KINDS or not namespace or not observed_at:
        raise ValueError("kind, namespace and observed_at must identify the selected metadata")
    if kind == "usaspending-monthly-files":
        if retained_capture is None or request_body is None or sha256 is None:
            raise ValueError("monthly files replay requires retained POST capture, request body and response pin")
        if (
            payload != retained_capture.body
            or capture_url != retained_capture.requested_url
            or observed_at != retained_capture.observed_at
            or sha256 != retained_capture.sha256
            or content_type != retained_capture.content_type
        ):
            raise ValueError("monthly files replay selection differs from its retained capture")
        return usaspending_monthly_files_metadata(retained_capture, namespace=namespace, request_body=request_body)
    digest = "sha256:" + hashlib.sha256(payload).hexdigest()
    out: dict[str, Any] = {"format": "spicy-source-discovery", "version": 1}
    out.update({name: [] for name in ("collections", "routes", "observations", "items", "periods", "errors")})
    obs: dict[str, Any] = {
        "id": stable_id(namespace, "observation", f"{capture_url}\0{digest}\0{observed_at}"),
        "capture_url": capture_url,
        "observed_at": observed_at,
        "sha256": digest,
        "bytes": len(payload),
        "content_type": content_type,
        "scope": scope or {"selected_url": capture_url},
        "status": "observed-page",
        "enumeration_complete": False,
        "metadata_kind": kind,
        "collection_ids": [],
    }
    out["observations"].append(obs)
    if kind == "datagov-v4":
        obs.update(inventory_stable=False, removal_eligible=False)

    def error(path: str, message: str, raw: Any = None) -> None:
        out["errors"].append({"observation_id": obs["id"], "path": path, "message": message, "raw": raw})
        obs["status"] = "partial" if out["collections"] else "parse-error"

    def collection(native: str, title: str, raw: Any, *, identity: str | None = None) -> str:
        cid = stable_id(namespace, "collection", native if identity is None else identity)
        obs["collection_ids"].append(cid)
        out["collections"].append(
            {
                "id": cid,
                "namespace": namespace,
                "native_id": native,
                "title": title,
                "raw": raw,
                "observation_ids": [obs["id"]],
            }
        )
        temporal = raw.get("temporal") if isinstance(raw, dict) else None
        out["periods"].append(
            {
                "collection_id": cid,
                "kind": "publisher_temporal" if temporal else "unknown",
                "label": temporal if isinstance(temporal, str) else "Unknown",
                "basis": "publisher-metadata" if temporal else "metadata-does-not-state-covered-period",
                "raw": temporal,
            }
        )
        return cid

    def route(cid: str, native: str, url: str, raw: Any, method: str = "unknown") -> str:
        rid = stable_id(namespace, "route", f"{cid}\0{native}")
        out["routes"].append(
            {
                "id": rid,
                "collection_id": cid,
                "label": native,
                "access_url": url,
                "delivery_method": method,
                "lifecycle": "unknown",
                "custodian": "unknown",
                "content_behavior": "unknown",
                "raw": raw,
            }
        )
        return rid

    def item(cid: str, rid: str, native: str, url: str | None, raw: Any) -> None:
        out["items"].append(
            {
                "id": stable_id(namespace, "item", f"{rid}\0{native}"),
                "collection_id": cid,
                "route_id": rid,
                "native_id": native,
                "name": native,
                "access_url": url,
                "status": "advertised",
                "raw": raw,
                "observation_id": obs["id"],
                "version_id": stable_id(namespace, "item-version", f"{rid}\0{native}\0{digest}"),
            }
        )

    try:
        byte_limit = DATAGOV_MAX_BYTES if kind == "datagov-v4" else MAX_METADATA_BYTES
        if len(payload) > byte_limit:
            raise ValueError("metadata exceeds its byte bound")
        if kind == "datagov-v4" and (
            not isinstance(sha256, str)
            or len(sha256.removeprefix("sha256:")) != 64
            or any(char not in "0123456789abcdef" for char in sha256.removeprefix("sha256:"))
        ):
            raise ValueError("Data.gov replay requires a nonempty SHA-256 input pin")
        if sha256 and sha256.removeprefix("sha256:") != digest.removeprefix("sha256:"):
            raise ValueError("metadata digest differs from its input pin")
        if kind == "datagov-v4":
            obs["scope"] = datagov_scope(capture_url)
            if scope is not None:
                obs["scope"]["caller_scope"] = scope
            if sha256 is None or retained_capture is None:
                raise ValueError("Data.gov replay requires a response pin and retained HTTP capture")
            capture = retained_capture
            obs["http_status"] = capture.status_code
            if (
                capture.body != payload
                or capture.requested_url != capture_url
                or capture.resolved_url != capture_url
                or capture.observed_at != observed_at
                or capture.content_type != content_type
                or capture.method != "GET"
                or capture.request_body is not None
                or capture.content_encoding != "identity"
            ):
                raise ValueError("Data.gov selection differs from its retained JSON GET capture")
            if capture.status_code != 200:
                raise ValueError(f"Data.gov response HTTP {capture.status_code} does not establish inventory facts")
            if not content_type:
                raise ValueError("Data.gov capture must state its JSON media type")
        media = (content_type or "").split(";", 1)[0].lower().strip()
        json_kind = kind in {"dcat", "datagov-v4", "govinfo-bulk", "ecfr-titles"}
        if media and not (
            media == "application/json" or media.endswith("+json")
            if json_kind
            else media in {"text/xml", "application/xml"} or media.endswith("+xml")
        ):
            raise ValueError("metadata media type differs from the selected parser")
        if json_kind:
            data = load_bounded_json(
                payload,
                source="publisher metadata",
                error_type=ValueError,
                number_policy="finite-float",
                max_bytes=byte_limit,
            )
            if not isinstance(data, dict):
                raise ValueError("metadata root must be an object")
            obs["raw"] = data
            key = {"dcat": "dataset", "datagov-v4": "results", "govinfo-bulk": "files", "ecfr-titles": "titles"}[kind]
            rows = data.get(key)
            if kind == "dcat":
                groups = [data[field] for field in ("dataset", "datasetSeries", "service") if field in data]
                if not groups or any(not isinstance(group, list) for group in groups):
                    raise ValueError("catalog must state dataset, datasetSeries or service arrays")
                rows = [row for group in groups for row in group]
            if not isinstance(rows, list):
                raise ValueError(f"metadata must state a {key} array")
            if kind == "datagov-v4":
                cursor = data.get("after")
                if cursor is not None and (not isinstance(cursor, str) or not cursor or len(cursor) > 8192):
                    raise ValueError("Data.gov response cursor is invalid")
                if cursor is not None and cursor == obs["scope"]["request_cursor"]:
                    raise ValueError("Data.gov response repeats the requested cursor")
                if len(rows) > obs["scope"]["per_page"] or (not rows and cursor is not None):
                    raise ValueError("Data.gov response exceeds page size or has an empty continuing page")
                if data.get("sort") != obs["scope"]["query"].get("sort", "relevance"):
                    raise ValueError("Data.gov response sort differs from the selected query")
                obs.update(continuation_token=cursor, page_terminal=cursor is None)
            if kind in {"dcat", "datagov-v4"}:
                seen: set[str] = set()
                for index, row in enumerate(rows):
                    path = f"dataset[{index}]"
                    identity = None
                    catalog_record = None
                    if kind == "datagov-v4":
                        path = f"results[{index}].dcat"
                        catalog_record = row
                        organization = row.get("organization") if isinstance(row, dict) else None
                        dcat = row.get("dcat") if isinstance(row, dict) else None
                        if (
                            not isinstance(organization, dict)
                            or not isinstance(organization.get("id"), str)
                            or not organization["id"].strip()
                            or not isinstance(dcat, dict)
                            or organization.get("organization_type") != "Federal Government"
                            or (
                                obs["scope"]["query"].get("org_slug")
                                and organization.get("slug") != obs["scope"]["query"]["org_slug"]
                            )
                        ):
                            error(
                                f"results[{index}]", "result must state DCAT and the selected federal organization", row
                            )
                            continue
                        row = dcat
                        # A native identifier is unique only within its catalog organization.
                        # JSON tuple encoding cannot collide on embedded separators.
                        identity = json.dumps([organization["id"], row.get("identifier")], separators=(",", ":"))
                    if not isinstance(row, dict) or not isinstance(row.get("identifier"), str) or not row["identifier"]:
                        error(path, "dataset must state a nonempty string identifier", row)
                        continue
                    native_identity = row["identifier"] if identity is None else identity
                    if native_identity in seen:
                        error(path, "dataset repeats native identifier", row)
                        continue
                    seen.add(native_identity)
                    cid = collection(
                        row["identifier"], str(row.get("title") or row["identifier"]), row, identity=identity
                    )
                    if catalog_record is not None:
                        out["collections"][-1].update(catalog_record=catalog_record, source_path=path)
                    out["collections"][-1].update(
                        {
                            "publisher": row.get("publisher"),
                            "description": row.get("description"),
                            "native_type": row.get("@type"),
                            "relationships": [
                                {"relation": field, "raw": row[field]}
                                for field in ("inSeries", "seriesMember", "isPartOf", "hasPart", "servesDataset")
                                if field in row
                            ],
                        }
                    )
                    if row.get("endpointURL"):
                        endpoints = row["endpointURL"] if isinstance(row["endpointURL"], list) else [row["endpointURL"]]
                        for endpoint in endpoints:
                            if not isinstance(endpoint, str):
                                error(path + ".endpointURL", "service endpoint URL must be a string", endpoint)
                            else:
                                route(cid, endpoint, endpoint, row, "api")
                    distributions = row.get("distribution", [])
                    if not isinstance(distributions, list):
                        error(path + ".distribution", "distribution must be an array", distributions)
                        continue
                    seen_routes: dict[str, dict[str, Any]] = {}
                    for pos, dist in enumerate(distributions):
                        if not isinstance(dist, dict):
                            error(f"{path}.distribution[{pos}]", "distribution must be an object", dist)
                            continue
                        urls = [(field, dist[field]) for field in ("accessURL", "downloadURL") if dist.get(field)]
                        if not urls:
                            error(f"{path}.distribution[{pos}]", "distribution does not state a URL", dist)
                        for field, url in urls:
                            if not isinstance(url, str):
                                error(f"{path}.distribution[{pos}].{field}", "URL must be a string", url)
                                continue
                            # Only explicit publisher format names classify a route.
                            method = "api" if str(dist.get("format", "")).upper() == "API" else "unknown"
                            distribution_id = dist.get("identifier") or dist.get("@id")
                            if not isinstance(distribution_id, str):
                                distribution_id = hashlib.sha256(
                                    json.dumps(dist, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
                                ).hexdigest()
                            native_route = f"{distribution_id}\0{url}\0{field}"
                            if native_route in seen_routes:
                                seen_routes[native_route]["distribution_positions"].append(pos)
                                continue
                            rid = route(cid, native_route, url, dist, method)
                            seen_routes[native_route] = out["routes"][-1]
                            out["routes"][-1]["distribution_id"] = distribution_id
                            out["routes"][-1]["distribution_positions"] = [pos]
                            out["routes"][-1]["label"] = str(dist.get("title") or field)
                            out["routes"][-1]["url_role"] = field
                            out["routes"][-1]["media_type"] = dist.get("mediaType")
                            out["routes"][-1]["access_service"] = dist.get("accessService")
                            item(cid, rid, row["identifier"], url, dist)
            else:
                cid = collection(capture_url, namespace, {"metadata_kind": kind})
                rid = route(cid, capture_url, capture_url, {}, "bulk" if kind == "govinfo-bulk" else "api")
                if kind == "govinfo-bulk":
                    out["routes"][-1]["required_accept"] = "application/json"
                for index, row in enumerate(rows):
                    native_key = "name" if kind == "govinfo-bulk" else "number"
                    if not isinstance(row, dict) or row.get(native_key) is None:
                        error(f"{key}[{index}]", f"entry must state {native_key}", row)
                        continue
                    item(cid, rid, str(row[native_key]), row.get("link"), row)
        else:
            root = parse_xml(payload, max_bytes=MAX_METADATA_BYTES, error_type=ValueError, label="publisher metadata")
            obs["raw_xml"] = payload.decode("utf-8")
            listing_url = urlsplit(capture_url)._replace(query="", fragment="").geturl()
            native_scope = (
                f"{bucket}\0{prefix}"
                if kind == "s3"
                else (
                    f"com-courtlistener-storage\0{prefix or 'bulk-data/'}" if kind == "courtlistener" else listing_url
                )
            )
            cid = collection(native_scope, namespace, {"metadata_kind": kind})
            rid = route(cid, native_scope, listing_url, {}, "bulk" if kind != "sitemap" else "sitemap")
            if kind in {"courtlistener", "s3"}:
                if kind == "courtlistener":
                    objects, token = parse_listing_page(payload, prefix=prefix or "bulk-data/")
                else:
                    if not bucket or prefix is None:
                        raise ValueError("S3 metadata requires selected bucket and prefix")
                    objects, token = parse_s3_listing(payload, bucket=bucket, prefix=prefix)
                obs["continuation_token"] = token
                obs["page_terminal"] = token is None
                if token:
                    obs["status"] = "partial"
                for obj in objects:
                    url = obj.url if isinstance(obj, BulkObject) else None
                    item(cid, rid, obj.key, url, asdict(obj))
                    if isinstance(obj, BulkObject):
                        out["items"][-1]["snapshot_date"] = obj.dump_date.isoformat() if obj.dump_date else None
            else:
                ns = "{http://www.sitemaps.org/schemas/sitemap/0.9}"
                if root.tag not in {ns + "sitemapindex", ns + "urlset"}:
                    raise ValueError("metadata is not a sitemap index or URL set")
                entry_tag = ns + ("sitemap" if root.tag == ns + "sitemapindex" else "url")
                for index, node in enumerate(root):
                    loc = node.findtext(ns + "loc")
                    raw = tostring(node, encoding="unicode")
                    if node.tag != entry_tag or not loc:
                        error(f"entry[{index}]", "sitemap entry must state loc", raw)
                        continue
                    item(cid, rid, loc, loc, {"xml": raw, "lastmod": node.findtext(ns + "lastmod")})
        obs["item_count"] = len(out["items"])
        if not out["errors"] and not out["collections"] and not out["items"]:
            obs["status"] = "requested-empty"
        if out["errors"]:
            obs["status"] = "partial" if out["items"] or out["collections"] else "parse-error"
        elif kind == "datagov-v4" and obs.get("continuation_token") is not None:
            obs["status"] = "partial"
    except ValueError as exc:
        error("$", str(exc))
        obs["status"] = "parse-error"
    return scrub_record(out, *secrets)


def refresh_metadata(
    client: Any, url: str, *, kind: str, namespace: str, api_key: str | None = None, **options: Any
) -> tuple[Any, dict[str, Any]]:
    """Capture one selected public endpoint through an existing bounded client.

    No crawling or retries beyond the client's own budget; caller retains capture
    before admitting facts. GovInfo's required Accept is always explicit.
    """
    if kind == "usaspending-monthly-files":
        raise ValueError("monthly files is replay-only here; use its explicit POST source reader")
    if (
        not urlsplit(url).hostname
        or urlsplit(url).scheme != "https"
        or urlsplit(url).username
        or urlsplit(url).password
    ):
        raise ValueError("metadata refresh requires a public HTTPS URL")
    secrets = (*options.get("secrets", ()), *((api_key,) if api_key else ()))
    if scrub_record(url, *secrets) != url:
        raise ValueError("metadata refresh URL must not carry credentials")
    headers = (
        {"Accept": "application/json"}
        if kind in {"dcat", "datagov-v4", "govinfo-bulk", "ecfr-titles"}
        else {"Accept": "application/xml"}
    )
    if kind == "datagov-v4":
        datagov_scope(url)
        if (
            not isinstance(api_key, str)
            or len(api_key) < 8
            or not api_key.isascii()
            or any(char.isspace() for char in api_key)
        ):
            raise ValueError("Data.gov refresh requires an API key supplied separately from the URL")
        if client.retain_refusal_bodies:
            raise ValueError("Data.gov keyed refresh requires refusal-body retention disabled")
        headers["X-Api-Key"] = api_key
        try:
            capture = client.capture(url, max_bytes=DATAGOV_MAX_BYTES, request_headers=headers, max_attempts=1)
        except Exception as exc:  # noqa: BLE001 - scrub every keyed client failure before it can escape
            # Keyed error bodies and HTTP request objects can echo credentials.
            # Keep a scrubbed reason, never forward their attached raw evidence.
            refused = CredentialRefusedError if isinstance(exc, CredentialRefusedError) else ValueError
            raise refused(failure_reason(exc, api_key)) from None
        if api_key.encode() in capture.body:
            raise CredentialRefusedError("Data.gov response echoed the API key; capture was not retained")
        options.update(retained_capture=capture, secrets=secrets)
    else:
        capture = client.capture(url, max_bytes=MAX_METADATA_BYTES, request_headers=headers)
    result = parse_metadata(
        capture.body,
        kind=kind,
        namespace=namespace,
        capture_url=capture.requested_url,
        observed_at=capture.observed_at,
        sha256=capture.sha256,
        content_type=capture.content_type,
        **options,
    )
    return capture, result
