"""USAspending recipients: a keyless POST list whose page metadata names the next page.

``/api/v2/recipient/`` takes a JSON body and answers ``results`` with a
``page_metadata`` envelope carrying ``total``, ``hasNext`` and the next page
number. The reader records each request body beside its exact response. The
recipient universe is large (over eighteen million on 2026-09-14); callers
bound a walk with ``max_pages`` and narrow it with ``award_type`` or a keyword.
"""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Iterator, Mapping
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.reading.paged_json import (
    DEFAULT_MAX_PAGES,
    JsonPage,
    JsonPageFamily,
    PagedJsonBudget,
    PagedJsonReader,
    PagedJsonSourceError,
    encode_body,
)
from spicy_docs.transport.captured import CapturedBodyResponse, attach_capture
from spicy_docs.transport.credentials import scrub_record
from spicy_docs.transport.source_acquirer import SourceAcquirer, utc_now

if TYPE_CHECKING:
    import httpx

API = "https://api.usaspending.gov/api/v2"
RECIPIENTS_URL = f"{API}/recipient/"
MONTHLY_FILES_URL = f"{API}/bulk_download/list_monthly_files/"
MONTHLY_FILES_MAX_BYTES = 256 * 1024
# A literal null publisher year is unspecified, rather than the requested year.
# Keep this admission change separate in inventory-comparison scope.
MONTHLY_FILES_PARSER_VERSION = 2
RESULTS_KEY = "results"
MAX_LIMIT = 100
AWARD_TYPES = ("all", "contracts", "grants", "loans", "direct_payments", "other")
type AwardType = Literal["all", "contracts", "grants", "loans", "direct_payments", "other"]
USASPENDING = JsonPageFamily(
    name="usaspending",
    label="USAspending",
    host="api.usaspending.gov",
    method="POST",
    next_kind="page-number",
    next_path=("page_metadata", "next"),
    count_path=("page_metadata", "total"),
    credential_header=None,
    requires_credential=False,
)


def recipients_request(
    *,
    limit: int = MAX_LIMIT,
    page: int = 1,
    sort: Literal["amount", "name", "duns"] = "amount",
    order: Literal["asc", "desc"] = "desc",
    award_type: AwardType = "all",
    keyword: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """The first request of a recipient list: its URL and JSON body."""
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_LIMIT:
        raise PagedJsonSourceError(f"limit must be an integer from 1 to {MAX_LIMIT}")
    if isinstance(page, bool) or not isinstance(page, int) or page < 1:
        raise PagedJsonSourceError("page must be a positive integer")
    if sort not in ("amount", "name", "duns") or order not in ("asc", "desc"):
        raise PagedJsonSourceError("sort must be amount, name or duns and order asc or desc")
    if award_type not in AWARD_TYPES:
        raise PagedJsonSourceError(f"award_type must be one of {', '.join(AWARD_TYPES)}")
    body: dict[str, Any] = {"limit": limit, "page": page, "order": order, "sort": sort, "award_type": award_type}
    if keyword is not None:
        if not isinstance(keyword, str) or not keyword.strip() or len(keyword) > 256:
            raise PagedJsonSourceError("keyword must be a nonempty string of at most 256 characters")
        body["keyword"] = keyword
    return RECIPIENTS_URL, body


class UsaspendingRecipientsReader(PagedJsonReader):
    def __init__(
        self,
        *,
        budget: PagedJsonBudget,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        super().__init__(family=USASPENDING, budget=budget, transport=transport, clock=clock)

    def recipients(self, body: Mapping[str, Any], *, max_pages: int = DEFAULT_MAX_PAGES) -> Iterator[JsonPage]:
        """Walk recipient pages for one request body under the family's shared budget."""
        return self.pages(RECIPIENTS_URL, records_key=RESULTS_KEY, max_pages=max_pages, body=body)


def monthly_files_request(*, agency: str | int, fiscal_year: int, type: str) -> tuple[str, dict[str, Any]]:
    """Select one archive inventory query; agency numbers are database IDs."""
    if agency != "all" and (isinstance(agency, bool) or not isinstance(agency, int) or agency <= 0):
        raise PagedJsonSourceError("agency must be all or a positive integer database ID")
    if isinstance(fiscal_year, bool) or not isinstance(fiscal_year, int) or fiscal_year <= 0:
        raise PagedJsonSourceError("fiscal_year must be a positive integer")
    if type not in {"contracts", "assistance"}:
        raise PagedJsonSourceError("type must be contracts or assistance")
    return MONTHLY_FILES_URL, {"agency": agency, "fiscal_year": fiscal_year, "type": type}


def monthly_files_body(body: Mapping[str, Any]) -> dict[str, Any]:
    """Reject undeclared filters instead of silently widening a query."""
    if not isinstance(body, Mapping) or set(body) != {"agency", "fiscal_year", "type"}:
        raise PagedJsonSourceError("monthly files request must state exactly agency, fiscal_year and type")
    return monthly_files_request(**body)[1]


def validate_monthly_files_capture(capture: CapturedBodyResponse, body: Mapping[str, Any]) -> dict[str, Any]:
    """Atomically admit a bounded response bound to its exact canonical POST."""
    request = encode_body(monthly_files_body(body))
    media = (capture.content_type or "").split(";", 1)[0].strip().lower()
    if (
        capture.method != "POST"
        or capture.requested_url != MONTHLY_FILES_URL
        or capture.resolved_url != MONTHLY_FILES_URL
        or capture.request_body != request
        or capture.status_code != 200
        or capture.content_encoding != "identity"
        or media != "application/json"
        or not capture.observed_at
    ):
        raise PagedJsonSourceError("monthly files requires an exact successful retained JSON POST capture")
    if capture.sha256 != "sha256:" + hashlib.sha256(capture.body).hexdigest():
        raise PagedJsonSourceError("monthly files capture digest differs from its bytes")
    data = load_bounded_json(
        capture.body,
        source="USAspending monthly files",
        error_type=PagedJsonSourceError,
        number_policy="integer",
        max_bytes=MONTHLY_FILES_MAX_BYTES,
    )
    if not isinstance(data, dict) or not isinstance(data.get("monthly_files"), list):
        raise PagedJsonSourceError("monthly files response must state a monthly_files array")
    if any(
        key in data
        for key in (
            "next",
            "nextPage",
            "next_page",
            "next_url",
            "hasNext",
            "has_next",
            "page_metadata",
            "pagination",
            "cursor",
            "continuation_token",
            "continuationToken",
        )
    ):
        raise PagedJsonSourceError("monthly files response introduces undocumented pagination")
    seen = set()
    for row in data["monthly_files"]:
        if not isinstance(row, dict):
            raise PagedJsonSourceError("monthly file must be an object")
        for key in ("agency_name", "file_name", "updated_date", "url"):
            if not isinstance(row.get(key), str) or not row[key].strip():
                raise PagedJsonSourceError(f"monthly file must state a nonempty {key}")
        if "agency_acronym" not in row or (
            row["agency_acronym"] is not None and not isinstance(row["agency_acronym"], str)
        ):
            raise PagedJsonSourceError("monthly file must state a string or null agency_acronym")
        if (
            "fiscal_year" not in row
            or (
                row["fiscal_year"] is not None
                and (
                    isinstance(row["fiscal_year"], bool)
                    or not isinstance(row["fiscal_year"], int)
                    or row["fiscal_year"] != body["fiscal_year"]
                )
            )
            or row.get("type") != body["type"]
        ):
            raise PagedJsonSourceError("monthly file year or type differs from the selected query")
        from urllib.parse import urlsplit

        url = urlsplit(row["url"])
        if (
            url.scheme != "https"
            or not url.hostname
            or url.username is not None
            or url.password is not None
            or scrub_record(row["url"]) != row["url"]
        ):
            raise PagedJsonSourceError("monthly file must offer a public HTTPS URL without credentials")
        if row["file_name"] in seen:
            raise PagedJsonSourceError("monthly files repeats a native filename")
        seen.add(row["file_name"])
    return data


class UsaspendingMonthlyFilesReader(SourceAcquirer):
    """One bounded archive inventory POST; never follows advertised file URLs."""

    def __init__(
        self,
        *,
        budget: PagedJsonBudget,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if budget.max_requests != 1 or budget.max_page_bytes > MONTHLY_FILES_MAX_BYTES or budget.timeout_seconds > 30:
            raise ValueError("monthly files budget requires one request, at most 256 KiB and 30 seconds")
        self._max_bytes = budget.max_page_bytes
        super().__init__(
            max_requests=1,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-usaspending-monthly-files/1.0",
            label="USAspending monthly files",
            error_type=PagedJsonSourceError,
            context_key="monthly_files_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def monthly_files(self, body: Mapping[str, Any]) -> CapturedBodyResponse:
        """Return exact admitted capture; callers retain it before catalog admission."""
        selected = monthly_files_body(body)

        def unavailable(capture: CapturedBodyResponse) -> Exception:
            error = PagedJsonSourceError("monthly files API operation answered 404/410")
            attach_capture(error, capture)
            return error

        _, capture = self.capture_validated(
            MONTHLY_FILES_URL,
            media_types=("application/json",),
            parse=lambda capture, _limit: validate_monthly_files_capture(capture, selected),
            max_bytes=self._max_bytes,
            unavailable=unavailable,
            context={"request_body": selected},
            method="POST",
            content=encode_body(selected),
            request_headers={"Content-Type": "application/json"},
        )
        return capture
