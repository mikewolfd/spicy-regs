"""Literal Treasury debt and MTS pages through the maintained bounded JSON reader.

Endpoint mapping: fedspendingtransparency/fiscal-data at
43be46fa6479de64f8a1a577cd761679a2f5cf7e (MIT; see treasury_fiscal.LICENSE).
Amounts, null markers, hierarchy and report dates are source facts; interpreting
budget periods, signs and units belongs to the downstream application.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import date, datetime
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.reading.paged_json import (
    JsonPageFamily,
    PagedJsonBudget,
    PagedJsonReader,
    PagedJsonSourceError,
    normalize_url,
    query_value,
)
from spicy_docs.transport.captured import CapturedBodyResponse

API = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
ENDPOINTS = {
    "debt_to_penny": f"{API}/v2/accounting/od/debt_to_penny",
    "mts_table_1": f"{API}/v1/accounting/mts/mts_table_1",
    "mts_table_2": f"{API}/v1/accounting/mts/mts_table_2",
}
DEBT_FIELDS = ("record_date", "tot_pub_debt_out_amt", "debt_held_public_amt", "intragov_hold_amt")
MAX_BYTES = 2 * 1024 * 1024
MAX_PAGES = 64
FISCAL_DATA = JsonPageFamily(
    name="treasury-fiscal-data",
    label="Treasury Fiscal Data",
    host="api.fiscaldata.treasury.gov",
    next_path=("next_number",),
    count_path=("meta", "total-count"),
    next_kind="page-number",
    page_field="page[number]",
    requires_credential=False,
    credential_header=None,
)
FiscalDataError = PagedJsonSourceError


@dataclass(frozen=True, slots=True)
class FiscalDataSelection:
    dataset: str
    record_date: str
    page_size: int = 100

    def __post_init__(self):
        if self.dataset not in ENDPOINTS:
            raise FiscalDataError("unsupported Treasury endpoint")
        if not isinstance(self.record_date, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", self.record_date):
            raise FiscalDataError("Treasury selection requires an explicit YYYY-MM-DD")
        try:
            date.fromisoformat(self.record_date)
        except ValueError as error:
            raise FiscalDataError("Treasury selection date is invalid") from error
        if type(self.page_size) is not int or not 1 <= self.page_size <= 1000:
            raise FiscalDataError("Treasury page size must be from 1 to 1000")

    def url(self, page=1):
        pairs = {"filter": f"record_date:eq:{self.record_date}", "page[size]": str(self.page_size)}
        if self.dataset == "debt_to_penny":
            pairs["fields"] = ",".join(DEBT_FIELDS)
        else:
            pairs["sort"] = "src_line_nbr"
        pairs["page[number]"] = str(page)
        return ENDPOINTS[self.dataset] + "?" + urlencode(pairs)


def selected_request(url):
    """One exact endpoint/date query, allowing the publisher's implicit first page."""
    parts = urlsplit(url)
    endpoint = urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))
    dataset = next((key for key, value in ENDPOINTS.items() if value == endpoint), None)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    values = dict(pairs)
    if dataset is None or parts.fragment or len(values) != len(pairs):
        raise FiscalDataError("Treasury request endpoint or query identity differs")
    requested = values.get("filter", "")
    if not requested.startswith("record_date:eq:"):
        raise FiscalDataError("Treasury request requires one explicit record date")
    size, page = values.get("page[size]", ""), values.get("page[number]", "1")
    if not size.isascii() or not size.isdigit() or not page.isascii() or not page.isdigit() or int(page) < 1:
        raise FiscalDataError("Treasury request page controls are invalid")
    selection = FiscalDataSelection(dataset, requested.removeprefix("record_date:eq:"), int(size))
    expected = dict(parse_qsl(urlsplit(selection.url(int(page))).query))
    if values | {"page[number]": page} != expected:
        raise FiscalDataError("Treasury request fields, filters or sorting differ")
    return selection, int(page)


class FiscalDataReader(PagedJsonReader):
    """Translate Fiscal Data's page fragment into the existing numbered-page policy."""

    def __init__(self, *, budget: PagedJsonBudget, transport=None, **kwargs):
        if budget.max_page_bytes > MAX_BYTES or budget.max_requests > MAX_PAGES:
            raise FiscalDataError("Treasury acquisition exceeds its bounded selection")
        super().__init__(family=FISCAL_DATA, budget=budget, transport=transport, **kwargs)

    def page(self, url, **kwargs):
        selected_request(url)  # refuse a foreign route before dispatch
        return super().page(url, **kwargs)

    def read(self, selection: FiscalDataSelection, *, max_pages=MAX_PAGES):
        if type(max_pages) is not int or not 1 <= max_pages <= MAX_PAGES:
            raise FiscalDataError("Treasury traversal page bound is invalid")
        return self.pages(selection.url(), records_key="data", max_pages=max_pages)

    def _continuation(self, value, *, url, body, rows):
        selection, current = selected_request(url)
        meta, links = value.get("meta"), value.get("links")
        if not isinstance(meta, dict) or not isinstance(links, dict) or "next" not in links:
            raise FiscalDataError("Treasury page omitted metadata or continuation")
        for key in ("count", "total-count", "total-pages"):
            if type(meta.get(key)) is not int or meta[key] < 0:
                raise FiscalDataError("Treasury page count is invalid")
        total = meta["total-count"]
        pages = (total + selection.page_size - 1) // selection.page_size
        expected_rows = min(selection.page_size, max(0, total - (current - 1) * selection.page_size))
        if (
            meta["count"] != len(rows)
            or len(rows) != expected_rows
            or current > max(pages, 1)
            or meta["total-pages"] not in ({0, 1} if not total else {pages})
        ):
            raise FiscalDataError("Treasury page membership differs from its count")
        for key in ("labels", "dataTypes", "dataFormats"):
            if not isinstance(meta.get(key), dict) or not meta[key]:
                raise FiscalDataError("Treasury field metadata is missing")
        identities = set()
        for row in rows:
            if (
                row.get("record_date") != selection.record_date
                or any(not isinstance(v, str) and v is not None for v in row.values())
                or any(not set(row) <= set(meta[key]) for key in ("labels", "dataTypes", "dataFormats"))
            ):
                raise FiscalDataError("Treasury row scope, literal cells or metadata differ")
            if selection.dataset == "debt_to_penny":
                identity = row["record_date"]
                if set(row) != set(DEBT_FIELDS):
                    raise FiscalDataError("Treasury debt fields differ")
            else:
                identity = row.get("classification_id")
                if (
                    not isinstance(identity, str)
                    or not identity.isascii()
                    or not identity.isdigit()
                    or row.get("table_nbr") != selection.dataset[-1]
                    or not {"parent_id", "classification_desc", "sequence_number_cd", "src_line_nbr"} <= set(row)
                    or not isinstance(row["src_line_nbr"], str)
                    or not row["src_line_nbr"].isascii()
                    or not row["src_line_nbr"].isdigit()
                ):
                    raise FiscalDataError("Treasury statement identity or hierarchy is missing")
            if identity in identities:
                raise FiscalDataError("Treasury page repeats a native identity")
            identities.add(identity)
        fragment = links["next"]
        next_number = None
        if fragment is not None:
            if not isinstance(fragment, str) or not fragment.startswith("&"):
                raise FiscalDataError("Treasury continuation must be a page fragment")
            pairs = parse_qsl(fragment[1:], keep_blank_values=True, strict_parsing=True)
            parts = dict(pairs)
            if (
                len(pairs) != 2
                or set(parts) != {"page[number]", "page[size]"}
                or parts["page[size]"] != query_value(url, "page[size]")
                or not parts["page[number]"].isascii()
                or not parts["page[number]"].isdigit()
                or int(parts["page[number]"]) != current + 1
            ):
                raise FiscalDataError("Treasury continuation changes or repeats the selected query")
            next_number = int(parts["page[number]"])
        if (next_number is not None) != (current < pages):
            raise FiscalDataError("Treasury continuation differs from declared pages")
        return super()._continuation({"next_number": next_number}, url=url, body=body, rows=rows)


def capture_descriptor(capture: CapturedBodyResponse):
    """Describe a successful literal response without rewriting its request identity."""
    selected_request(capture.requested_url)
    if (
        normalize_url(capture.resolved_url) != normalize_url(capture.requested_url)
        or capture.status_code != 200
        or capture.method != "GET"
        or capture.request_body is not None
        or capture.content_encoding != "identity"
        or (capture.content_type or "").split(";", 1)[0].strip().lower() != "application/json"
        or not 0 < capture.byte_size <= MAX_BYTES
    ):
        raise FiscalDataError("Treasury capture status, representation or size differs")
    try:
        instant = datetime.fromisoformat(capture.observed_at)
    except (TypeError, ValueError) as error:
        raise FiscalDataError("Treasury observation timestamp is invalid") from error
    if instant.utcoffset() is None:
        raise FiscalDataError("Treasury observation timestamp needs a timezone")
    return {
        "request_url": capture.requested_url,
        "response_sha256": capture.sha256,
        "observed_at": capture.observed_at,
        "byte_size": capture.byte_size,
    }


def read_capture(capture: CapturedBodyResponse):
    """Read one retained response through the same page interpretation, without dispatch."""
    descriptor = capture_descriptor(capture)
    selection, number = selected_request(capture.requested_url)
    with FiscalDataReader(budget=PagedJsonBudget(1, MAX_BYTES, 30, 0)) as reader:
        page = reader._read_page(
            capture,
            url=capture.requested_url,
            body=None,
            records_key="data",
            page_index=number - 1,
            single_record=False,
        )
    value = load_integer_json(capture.body, source="Treasury", error_type=FiscalDataError)
    metadata = {key: value["meta"][key] for key in ("labels", "dataTypes", "dataFormats")}
    records = [
        {
            "dataset": selection.dataset,
            "selection": asdict(selection),
            "raw": dict(row),
            "field_metadata": metadata,
            "source_locator": descriptor | {"json_pointer": f"/data/{index}"},
        }
        for index, row in enumerate(page.records)
    ]
    return {
        "page": number,
        "capture": descriptor,
        "count": page.declared_count,
        "next_url": page.next_url,
        "results": records,
    }
