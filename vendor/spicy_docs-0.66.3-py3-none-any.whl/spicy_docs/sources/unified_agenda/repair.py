"""Exact, original-byte-qualified historical Unified Agenda XML repair.

Only the two retained full editions identified below may replace their one
publisher control byte with U+2019. Other XML stays strict. Original bytes are
never changed; the receipt identifies both the original and parsed copy.
Evidence: corpora/spicyregs/metadata/historical-rebuilds/20261010/agenda/.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .records import UnifiedAgendaSourceError

MANGLED_APOSTROPHE_EDITIONS = ("200404", "200410")
_REPAIRS = {
    "200404": ("df0cc8d24c544b3a2d9a0b025cb91973cf598e7cfa9181efa6af4494bbc24562", 17865654, 7120218, "1084-AA00"),
    "200410": ("8f780d499359754ed24dc9aca9f954d7ea4e0df4f772b4e26e59d8a766a48cb5", 17349457, 6095969, "1010-AD16"),
}


@dataclass(frozen=True, slots=True)
class UnifiedAgendaRepair:
    """One approved byte substitution, with hashes before and after parsing repair."""

    publication_id: str
    input_sha256: str
    input_bytes: int
    byte_offset: int
    rin: str
    parsed_sha256: str
    parsed_bytes: int
    original_hex: str = "19"
    replacement_hex: str = "e28099"
    rule: str = "exact-retained-2004-apostrophe-v1"


def prepare_unified_agenda_xml(body: bytes, *, publication_id: str) -> tuple[bytes, UnifiedAgendaRepair | None]:
    """Return an in-memory readable copy only for the exact approved original.

    A well-formed later revision needs no repair. A changed malformed edition,
    excerpt, extra control byte or unexpected byte position is not approved.
    The strict XML scanner continues to reject every other illegal character.
    """
    if not isinstance(body, bytes):
        raise UnifiedAgendaSourceError("Unified Agenda XML must be bytes")
    count = body.count(b"\x19")
    if not count or publication_id not in _REPAIRS:
        return body, None
    if count != 1:
        raise UnifiedAgendaSourceError("Unified Agenda 2004 edition carries more than its one measured 0x19 byte")
    expected, size, offset, rin = _REPAIRS[publication_id]
    digest = hashlib.sha256(body).hexdigest()
    if digest != expected or len(body) != size or body[offset : offset + 1] != b"\x19":
        raise UnifiedAgendaSourceError(
            "Unified Agenda control-byte repair requires the exact approved original edition"
        )
    readable = body[:offset] + "\u2019".encode() + body[offset + 1 :]
    return readable, UnifiedAgendaRepair(
        publication_id, digest, len(body), offset, rin, hashlib.sha256(readable).hexdigest(), len(readable)
    )
