"""IPAA's captured 119th-period browser tables and separate native lifetime values."""

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from hashlib import sha256
from typing import Any, ClassVar

from bs4 import BeautifulSoup

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import ipaa_momentum as native
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "ipaa-119-captured-rendered-session-and-native-lifetime-20261019/1"
INDEX = native.INDEX
CLIENT = "https://ipaagrassroots.org/_next/static/chunks/0aud8rv9lffs0.js"
LIFETIME = "https://admin.mplatform.io/api/v1/ipaa1/vr/legislators/lifetime-scores/batch"
PINS = {
    INDEX: "9ec2eb81349f1c7a6f6130cb0a65685d823e13e3381beba96e758e13c7ea6419",
    CLIENT: "79d6bb3ead1d1276180f307e2c2c2da45d014baae0ff4783dcce9084cb5f688d",
    native.CATALOG: "47512ab6ea3e2672c7b4b970ed50fb36eb476aa6bc9bcef094ab49cabab6872a",
}
# Measured complete captures, retained under corpora/spicyregs/scorecards/ipaa/
# 20261019-rendered/manifest.json; these bounds are not a live roster census.
SCOPES: dict[str, dict[str, Any]] = {
    "FH": {
        "rows": (100, 100, 100, 100, 40),
        "votes": {2267: 432, 2270: 433, 2271: 433, 2273: 431},
        "pages": (
            "dfe8969d40c800cd558b5642ebd39b79967ed5647af911b9454d52c38bdaf626",
            "cb130629f083b0432b0ef1bd60e6c9c47ddf3924fc615fc2359914e86312ba6b",
            "c4eb8b8a44d56bbbfad3ffc0f826d4cd9631abcb83bcdf4e84353e03059a740c",
            "4f76cda88868be75b5c49ede3580cdb1488328d832996a02c41a360cfc85923c",
            "8e45416ae37ff4d54f7b99eaa877d7bfe03c080ddf7e930215665ee543300e38",
        ),
        "request": "b46f0b722e3f5c208550a965bed5d5948dd4c87fc14ebcd9991e108d6820fd3a",
        "lifetime": "5e0e6507958e134a73104a0c057a06683db077f0621dcea27877a79947811705",
    },
    "FS": {
        "rows": (100,),
        "votes": {2266: 100, 2269: 100},
        "pages": ("a6a2019dd9d4cb8e1f80241af2bfd831374f106cbbd2056fc44b0b58661f351f",),
        "request": "cbff64512db024053d4744d0e529bbfac77405c2e4b25601408cd189d901e348",
        "lifetime": "6e6b4258b88815e999bc3514323f5e600ed333120436395bcf79c6ca833ec49b",
    },
}
EDITIONS = tuple(
    ScorecardEdition(
        "ipaa",
        f"119th-{chamber}-rendered-20261019",
        INDEX,
        f"119th Congress Key Votes - {chamber}",
        congress="119th Congress",
        chamber=chamber,
        is_current=False,
    )
    for chamber in SCOPES
)


@dataclass(frozen=True, slots=True)
class IpaaRenderedReader:
    parser_version: ClassVar[str] = parser_version
    rendered_pages: dict[str, bytes] = field(repr=False)
    lifetime_request: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            rendered_pages=self.rendered_pages,
            lifetime_request=self.lifetime_request,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context):
    """Select named frozen captures; never claim live discovery or refresh."""
    return EDITIONS


def _read(context, url, media, *, content=None, pin=None):
    document = context.read_request(
        url,
        method="GET" if content is None else "POST",
        content=content,
        stage="ipaa-rendered:source",
        hosts=native.HOSTS,
    )
    if (
        document.url != url
        or document.response.sha256 != "sha256:" + (pin or PINS[url])
        or (document.response.content_type or "").split(";", 1)[0] not in media
    ):
        raise ScorecardSourceError("IPAA rendered capture source identity, bytes or media type changed")
    return document


def _one(root, selector):
    found = root.select(selector)
    if len(found) != 1:
        raise ScorecardSourceError("IPAA rendered field is missing or repeated: " + selector)
    return found[0]


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _require(condition):
    if not condition:
        raise ScorecardSourceError("IPAA captured source shape changed")


def _page(body, edition, number, spec, headers):
    try:
        data = json.loads(body)
        _require(set(data) == {"observed_at", "url", "html", "selected", "filters", "rows", "navigation"})
        _require(data["url"] == INDEX)
        _require(datetime.fromisoformat(data["observed_at"]).utcoffset() is not None)
        _require(
            data["selected"]
            == [
                {"value": f"119th Congress Key Votes -  {edition.chamber}", "text": edition.title},
                {"value": "100", "text": "100"},
            ]
        )
        _require(data["filters"] == [{"placeholder": "Search by legistator...", "value": ""}])
        _require(
            isinstance(data["html"], str) and data["html"].startswith("<main") and data["html"].endswith("</main>")
        )
        root = BeautifulSoup(data["html"], "html.parser")
        _require([_text(n) for n in root.select("thead th")] == headers)
        _require(re.search(r"\bTotal " + str(sum(spec["rows"])) + r" legislators\b", _text(root)))
        _require("Loading results" not in _text(root))
        _require(_one(root, f'[aria-label="pagination item {number} active"]'))
        _require((_one(root, '[aria-label="previous page button"]').get("aria-disabled") == "true") == (number == 1))
        _require(
            (_one(root, '[aria-label="next page button"]').get("aria-disabled") == "true")
            == (number == len(spec["rows"]))
        )
        rows = root.select("tbody tr")
        _require(len(rows) == spec["rows"][number - 1] == len(data["rows"]))
        result = []
        for node, original in zip(rows, data["rows"], strict=True):
            identity = node.get("data-key")
            if not isinstance(identity, str):
                raise ScorecardSourceError("IPAA rendered member lacks a literal source identity")
            _require(re.fullmatch(r"\d+", identity))
            _require(set(original) == {"key", "text", "html"} and original["key"] == identity)
            _require(str(BeautifulSoup(original["html"], "html.parser")) == str(node))
            cells = node.find_all(["td", "th"], recursive=False)
            _require(len(cells) == len(headers))
            values = [_text(c) for c in cells]
            _require(_one(cells[0], "a[href]")["href"] == "/my-government/my-officials/results/" + identity)
            _require(all(values[:3]) and re.fullmatch(r"-?\d+(?:\.\d+)?%|N/A", values[-1]))
            _require(all(v in {"Yea", "Nay", "Did Not Vote"} for v in values[3:-1]))
            result.append((identity, values))
        return data["observed_at"], result
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        raise ScorecardSourceError("IPAA rendered page, controls, headers or complete rows changed") from error


def acquire_scorecard(edition, context, *, rendered_pages=None, lifetime_request=None, retain_observations=None):
    if edition not in EDITIONS:
        raise ScorecardSourceError("IPAA rendered reader requires a named captured 119th edition")
    spec = SCOPES[edition.chamber]
    if (
        not isinstance(rendered_pages, dict)
        or set(rendered_pages) != {f"page_{n}" for n in range(1, len(spec["pages"]) + 1)}
        or not callable(retain_observations)
        or not isinstance(lifetime_request, bytes)
        or len(lifetime_request) > context.max_bytes
        or sha256(lifetime_request).hexdigest() != spec["request"]
        or any(
            not isinstance(v, bytes) or len(v) > min(context.max_bytes, 4 * 1024**2) for v in rendered_pages.values()
        )
    ):
        raise ScorecardSourceError("IPAA rendered reader needs exact bounded private pages, request and retention")
    source = _read(context, INDEX, {"text/html"})
    client = _read(context, CLIENT, {"text/javascript", "application/javascript"})
    catalog = _read(context, native.CATALOG, {"application/json"})
    selected = [
        (bi, bill, vi, vote)
        for bi, bill in enumerate(native.parse_catalog(catalog))
        if bill["Session"] == edition.congress
        for vi, vote in enumerate(bill["vote_records"])
        if vote["Chamber"] == edition.chamber
    ]
    if {v["id"]: len(v["legislators"]) for _, _, _, v in selected} != spec["votes"] or any(
        v["disabled"] != "0" for _, _, _, v in selected
    ):
        raise ScorecardSourceError("IPAA rendered selected native votes or occurrences changed")
    headers = (
        ["Name Preferred Position:", "Party", "State"]
        + [f"Position {bill['StateBillID']} ? {vote['mbr_position']}" for _, bill, _, vote in selected]
        + ["Session Score"]
    )
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="Independent Petroleum Association of America",
        parser_version=parser_version,
        rendition_rule="Exact private 2026-10-19 browser observations; rendered session cells and separately captured native lifetime values; no score reconstruction",
        homepage=native.HOME,
    )
    bundle.use(client, "publisher-client-context")
    bundle.use(catalog, "native-member-and-vote-reconciliation")
    occurrences = {}
    for bi, bill, vi, vote in selected:
        path = f"$[{bi}].vote_records[{vi}]"
        item = key("ipaa1", "vote", str(vote["id"]))
        bundle.add(
            "scorecard_items",
            catalog,
            path,
            item_id=item,
            publisher_item_id=str(vote["VoteID"]),
            title=vote["Motion"],
            bill_citation_text=bill["StateBillID"],
            item_date_text=vote["VoteDate"],
            congress_text=edition.congress,
            chamber_text=edition.chamber,
            publisher_position_text=vote["mbr_position"],
            position_basis="explicit",
            position_source_path=path + ".mbr_position",
        )
        bundle.add(
            "scorecard_methodologies",
            catalog,
            path,
            methodology_id=item,
            methodology_text=json_column(
                {
                    "bill": {k: v for k, v in bill.items() if k != "vote_records"},
                    "vote": {k: v for k, v in vote.items() if k != "legislators"},
                }
            ),
            disclosure_status="Native context; no weighted formula or official-action inference",
        )
        for mi, member in enumerate(vote["legislators"]):
            occurrences.setdefault(str(member["KnowWhoPersonID"]), []).append(
                {"source_path": f"{path}.legislators[{mi}]", "value": member}
            )
    members = {}
    observation_ids = set()
    for number, pin in enumerate(spec["pages"], 1):
        body = rendered_pages[f"page_{number}"]
        observation = retain_qualified(
            source,
            body,
            retain_observations,
            source_sha256=PINS[INDEX],
            observations_sha256=pin,
            stage=f"ipaa-rendered:{edition.chamber}:page-{number}",
        )
        if observation in observation_ids:
            raise ScorecardSourceError("IPAA rendered pages require distinct private observation identities")
        observation_ids.add(observation)
        captured_at, rows = _page(body, edition, number, spec, headers)
        page_path = f"/observation[{observation}]/html/main"
        if number == 1:
            bundle.add(
                "scorecard_metrics",
                source,
                page_path + "/thead/Session Score",
                metric_id="session",
                name="Session Score",
                chamber_text=edition.chamber,
                period_text=edition.congress,
                value_unit_text="%",
                is_primary="true",
            )
            bundle.tables["scorecards"][0]["observed_at"] = captured_at
        for ordinal, (identity, cells) in enumerate(rows, 1):
            if identity in members or identity not in occurrences:
                raise ScorecardSourceError("IPAA rendered pages overlap or add an unbound member")
            member_key = key("ipaa1", "KnowWhoPersonID", identity)
            members[identity] = member_key
            path = page_path + f"/tbody/tr[{ordinal}]"
            bundle.add(
                "scorecard_members",
                source,
                path,
                publisher_member_key=member_key,
                publisher_member_id=identity,
                identifiers_json=json_column([{"scheme": "KnowWhoPersonID", "value": identity}]),
                member_name=cells[0],
                party=cells[1],
                state=cells[2],
                chamber_text=edition.chamber,
                period_text=edition.congress,
                notes_text=json_column(
                    {
                        "rendered_at": captured_at,
                        "native_member_occurrences": occurrences[identity],
                        "identity_rule": "Displayed period-specific KnowWho row; native identity variants remain separate original occurrences",
                    }
                ),
            )
            bundle.add(
                "scorecard_member_ratings",
                source,
                path + "/td[last()]",
                metric_id="session",
                publisher_member_key=member_key,
                value_text=cells[-1],
                value_number=decimal_text(cells[-1]),
                notes_text="Reviewer interpretation: negative display retained literally; meaning unknown"
                if cells[-1].startswith("-")
                else None,
            )
            for column, (_, _, _, vote) in enumerate(selected, 3):
                bundle.add(
                    "scorecard_member_item_results",
                    source,
                    path + f"/td[{column + 1}]",
                    item_id=key("ipaa1", "vote", str(vote["id"])),
                    publisher_member_key=member_key,
                    result_id="rendered-cell",
                    result_text=cells[column],
                )
    try:
        requested = json.loads(lifetime_request)
        _require(set(requested) == {"legislator_ids"} and isinstance(requested["legislator_ids"], list))
        _require(all(type(i) is int for i in requested["legislator_ids"]))
        ids = list(map(str, requested["legislator_ids"]))
        _require(len(ids) == len(set(ids)) == sum(spec["rows"]))
        _require(set(ids) == set(members) == set(occurrences))
    except (ValueError, TypeError, KeyError) as error:
        raise ScorecardSourceError("IPAA lifetime request and complete rendered/native member sets differ") from error
    lifetime = _read(context, LIFETIME, {"application/json"}, content=lifetime_request, pin=spec["lifetime"])
    values = json_data(lifetime)
    if (
        not isinstance(values, dict)
        or set(values) != set(members)
        or any(
            isinstance(v, bool) or not isinstance(v, (str, int)) or decimal_text(str(v)) is None
            for v in values.values()
        )
    ):
        raise ScorecardSourceError("IPAA successful lifetime response lacks exact numeric member values")
    bundle.use(lifetime, "native-lifetime-values")
    bundle.add(
        "scorecard_metrics",
        lifetime,
        "$",
        metric_id="lifetime",
        name="Lifetime Score",
        chamber_text=edition.chamber,
        period_text="Lifetime",
        is_primary="false",
    )
    for identity, value in values.items():
        bundle.add(
            "scorecard_member_ratings",
            lifetime,
            "$[" + json.dumps(identity) + "]",
            metric_id="lifetime",
            publisher_member_key=members[identity],
            value_text=str(value),
            value_number=str(value),
            notes_text="Native lifetime endpoint value for this captured member cohort; no rendered lifetime column, stated endpoint dates or inferred 119th-period lifetime window",
        )
    return bundle.finish(
        "Frozen 2026-10-19 rendered 119th-period capture: exact page/client/native/DOM/request/response pins; all selected pages, headers, unfiltered totals and terminal controls agree. Rendered, native KnowWho, lifetime request and response member sets are identical. Native variants and literal negative scores are preserved. Lifetime is a separate native metric with unstated endpoint dates. No score formula, live refresh, historical completeness or cross-period identity claim.",
        declared={"rendered_total_legislators": sum(spec["rows"]), "rows_per_page": 100},
    )
