"""The New American's named July 2006 Conservative Index Senate section."""

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key
from .qualified_observations import RetainObservations, require_reviewed_pdf, retain_qualified

parser_version = "new-american-conservative-109-3-senate/1"
SOURCE_URL = "https://thenewamerican.com/assets/sites/10/TNA-Jul-10-2006-Vol.-22-No.-14.pdf"
SOURCE_SHA256 = "c15a81fd377f49508383a4e2ee235be1fdf50487503f06a459c9fbbd8e1286a6"
FACTS_SHA256 = "70e8f97e4b390ada4445194f34f3a0255c16a8303130d2803be8d7c63bde5691"
EDITION = ScorecardEdition(
    "new_american",
    "conservative-index-109-3-senate-print",
    SOURCE_URL,
    "The Conservative Index",
    "2006",
    "109",
    "Senate",
    False,
)
ITEMS = tuple(map(str, range(21, 31)))
PAGE_COUNTS = {32: 72, 33: 28}
LINE = re.compile(r"PDF/page\[(32|33)\]/line\[(\d+)\]")
PART = re.compile(r"PDF/page\[(31|33)\]/lines\[(\d+):(\d+)\]")


def _field_parts(item):
    """Keep a continued action's date, numeric roll and position on their own pages."""
    fields = {
        "date": re.escape(item["date"]),
        "roll": r"Roll\s+Call\s+" + re.escape(item["roll"]) + r"\b",
        "position": re.escape(item["position"]),
    }
    paths = {}
    for name, pattern in fields.items():
        matches = [p["source_path"] for p in item["description_parts"] if re.search(pattern, p["text"])]
        if len(matches) != 1:
            raise ValueError
        paths[name] = matches[0]
    return paths


def _facts(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != FACTS_SHA256:
        raise ScorecardSourceError("Conservative Index requires its exact private reviewed native facts")
    try:
        data = json.loads(body)
        if (
            data["source_sha256"] != SOURCE_SHA256
            or data["title"] != EDITION.title
            or data["publication_date_text"] != "July 10, 2006"
            or data["congress_text"] != "109"
            or data["session_text"] is not None
            or len(data["members"]) != sum(PAGE_COUNTS.values())
            or [i["ordinal"] for i in data["items"]] != list(ITEMS)
        ):
            raise ValueError
        locations, pages, states = set(), Counter(), Counter()
        for member in data["members"]:
            location = LINE.fullmatch(member["source_path"])
            state_location = LINE.fullmatch(member["state_source_path"])
            if (
                location is None
                or state_location is None
                or location[1] != state_location[1]
                or int(state_location[2]) >= int(location[2])
                or member["source_path"] in locations
                or member["party"] not in {"R", "D", "I"}
                or not member["member_name"]
                or member["member_label"] != f"{member['member_name']} ({member['party']})"
                or not re.fullmatch(r"[A-Z]+(?: [A-Z]+)*", member["state"])
                or len(member["results"]) != 10
                or any(v not in {"+", "-", "?"} for v in member["results"])
                or len(member["ratings"]) != 2
                or any(not re.fullmatch(r"\d+%?", v) for v in member["ratings"])
            ):
                raise ValueError
            locations.add(member["source_path"])
            pages[int(location[1])] += 1
            states[member["state"]] += 1
        if pages != PAGE_COUNTS or len(states) != 50 or set(states.values()) != {2}:
            raise ValueError
        for item in data["items"]:
            description, parts = item["description"], item["description_parts"]
            if (
                not parts
                or not item["title"]
                or not description.startswith(item["title"])
                or "".join(p["text"] for p in parts) != description
                or any(not p["text"] or not PART.fullmatch(p["source_path"]) for p in parts)
                or re.findall(r"Roll\s+Call\s+(\d+)", description) != [item["roll"]]
                or re.findall(r"(?:November|March|May)\s+\d{1,2},\s+200[56]", description) != [item["date"]]
                or re.findall(r"(?:pluses|minuses)\s+to\s+the\s+“(?:nays|yeas)”", description) != [item["position"]]
                or re.findall(r"House\s+vote\s+#\d+", description) != item["references"]
                or re.findall(r"\b(?:H\.R\.|S\.)\s+\d+|\bHouse Joint Resolution\s+\d+", description) != item["bills"]
            ):
                raise ValueError
            _field_parts(item)
        if (
            [c["source_path"] for c in data["contexts"]]
            != ["PDF/page[7]/imprint", "PDF/page[24]/index-context", "PDF/page[33]/legend"]
            or any(not c["text"] or not c["kind"] for c in data["contexts"])
            or "wholly owned subsidiary of The John" not in data["contexts"][0]["text"]
            or "Birch Society." not in data["contexts"][0]["text"]
            or "Our third look at the 109th Congress" not in data["contexts"][1]["text"]
            or "clipped" not in data["contexts"][2]["kind"]
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, AttributeError, IndexError):
        raise ScorecardSourceError(
            "Conservative Index facts do not establish the complete named Senate scope"
        ) from None


def _source(document):
    require_reviewed_pdf(
        document,
        source_url=SOURCE_URL,
        source_sha256=SOURCE_SHA256,
        message="Conservative Index original differs from its reviewed PDF",
    )
    if document.response.content_type != "application/pdf":
        raise ScorecardSourceError("Conservative Index PDF content type changed")


def list_scorecards(context):
    return (EDITION,)


@dataclass(frozen=True, slots=True)
class ConservativeSenateReader:
    """One named original and private reviewed observations; no extraction at acquisition."""

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        _facts(self.qualified_observations)
        return (EDITION,)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Conservative Index requires the named Senate edition and privately retained facts")
    data = _facts(qualified_observations)
    source = context.read(SOURCE_URL, stage="new-american-conservative:original", hosts=("thenewamerican.com",))
    _source(source)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=FACTS_SHA256,
        stage="new-american-conservative:reviewed-native-facts",
    )
    reread = context.read(SOURCE_URL, stage="new-american-conservative:reread", hosts=("thenewamerican.com",))
    _source(reread)
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="The New American",
        parser_version=parser_version,
        homepage="https://thenewamerican.com/",
        rendition_rule="named 109-3 printed Senate section/1",
    )
    bundle.use(source, "members", "ratings", "items", "results", "context")
    bundle.use(reread, "members", "ratings", "items", "results", "context", role="corroboration")

    def path(original):
        page = original.split("[")[1].split("]")[0]
        return f"pdf:page={page};observation={observation};{original}"

    bundle.tables["scorecards"][0].update(
        series_id="new_american:printed-conservative-index",
        edition_label_text=EDITION.title,
        publisher_edition_key=None,
        published_at_text=data["publication_date_text"],
        methodology_url=SOURCE_URL,
    )
    for n, record in enumerate(data["contexts"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            path(record["source_path"]),
            methodology_id=key("print-context", str(n)),
            methodology_text=record["text"],
            methodology_url=SOURCE_URL,
            disclosure_status=record["kind"],
        )
    metrics = [key("Senate", "printed-score", p) for p in ("21-30", "1-30")]
    for period, metric in zip(("21-30", "1-30"), metrics, strict=True):
        bundle.metric(
            source, metric, period, path=path("PDF/page[32]/header/" + period), chamber="Senate", unit="percent"
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = period
    for item in data["items"]:
        item_id = key("print", "Senate", item["ordinal"])
        item_path = path(item["description_parts"][0]["source_path"])
        field_parts = _field_parts(item)
        # The negative wording for item 22 is literal, not inferred support for nays.
        position_path = path(field_parts["position"])
        bundle.add(
            "scorecard_items",
            source,
            item_path,
            item_id=item_id,
            publisher_item_id=item["ordinal"],
            item_kind_text="roll_call",
            title=item["title"],
            congress_text="109",
            chamber_text="Senate",
            item_date_text=item["date"],
            roll_number_text=item["roll"],
            publisher_position_text=item["position"],
            position_basis="explicit",
            position_source_path=position_path,
            references_json=json_column(
                [
                    {
                        "occurrence_id": str(i),
                        "kind": kind,
                        "citation_text": text,
                        "source_path": next(
                            path(p["source_path"]) for p in item["description_parts"] if text in p["text"]
                        ),
                    }
                    for i, (kind, text) in enumerate(
                        [("publisher_item_citation", t) for t in item["references"]]
                        + [("bill_citation", t) for t in item["bills"]]
                    )
                ]
            ),
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            item_path,
            methodology_id=item_id,
            chamber_text="Senate",
            methodology_text=item["description"],
            methodology_url=SOURCE_URL,
            disclosure_status=json_column(
                {
                    "literal_native_parts": item["description_parts"],
                    "literal_date_source_path": field_parts["date"],
                    "literal_roll_source_path": field_parts["roll"],
                    "literal_position_source_path": field_parts["position"],
                }
            ),
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            item_path,
            metric_id=metrics[0],
            item_id=item_id,
            participation_id="printed-votes-21-30",
            publisher_position_text=item["position"],
            position_basis="explicit",
            counts_toward_metric="true",
        )
    for member in data["members"]:
        member_key = key("print-occurrence", "Senate", member["source_path"])
        member_path = path(member["source_path"])
        bundle.add(
            "scorecard_members",
            source,
            member_path,
            publisher_member_key=member_key,
            member_name=member["member_name"],
            chamber_text="Senate",
            state=member["state"],
            party=member["party"],
            notes_text=json_column(
                {
                    "original_combined_label": member["member_label"],
                    "state_heading_source_path": member["state_source_path"],
                }
            ),
        )
        for i, (metric, value) in enumerate(zip(metrics, member["ratings"], strict=True)):
            bundle.add(
                "scorecard_member_ratings",
                source,
                member_path + "/score/" + str(i),
                metric_id=metric,
                publisher_member_key=member_key,
                value_text=value,
                value_number=decimal_text(value),
            )
        for ordinal, mark in zip(ITEMS, member["results"], strict=True):
            bundle.add(
                "scorecard_member_item_results",
                source,
                member_path + "/vote/" + ordinal,
                publisher_member_key=member_key,
                item_id=key("print", "Senate", ordinal),
                result_id="printed-mark",
                metric_id=metrics[0],
                participation_id="printed-votes-21-30",
                result_text=mark,
                reason_text="Literal publisher mark; no official vote, member identity or cumulative actions inferred.",
            )
    return bundle.finish(
        "Complete named Senate section: all printed state/member rows, both score columns and votes 21-30; "
        "all ten Senate narratives and source-time imprint retained. Original reread is byte-identical. "
        "The final legend sentence is visibly clipped in the original and remains incomplete. "
        "House rows and cumulative votes 1-20 are outside this scope."
    )
