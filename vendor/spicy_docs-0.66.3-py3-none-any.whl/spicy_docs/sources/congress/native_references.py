"""Literal references in retained bill XML, with bounded positional ancestry.

DTD ``external-xref`` attributes and USLM hrefs remain distinct native forms.
Callbacks are provisional until the entire XML parses; this reader establishes
neither bill identity nor acquisition provenance and makes no requests.
"""

from collections.abc import Callable
from dataclasses import dataclass

from spicy_docs.reading.xml import scan_xml
from spicy_docs.reading.xml_observations import XmlElement, XmlObservationScan


@dataclass(frozen=True, slots=True)
class BillReference:
    """One native reference element; every attribute and expanded name survives."""

    element: XmlElement
    ancestors: tuple[XmlElement, ...]

    @property
    def href(self) -> str | None:
        return self.element.attributes.get("href")


@dataclass(frozen=True, slots=True)
class BillReferenceScan:
    elements: int
    references: int


class _BillScan(XmlObservationScan):
    def __init__(self, callback, maximum, depth):
        super().__init__(error_type=ValueError, label="Bill reference XML", max_depth=depth)
        self.callback, self.maximum = callback, maximum
        self.elements = self.references = 0

    def observe_start(self, tag: str, attributes: dict[str, str]) -> None:
        self.elements += 1
        if "href" in attributes or tag.rsplit("}", 1)[-1] in {"ref", "external-xref"}:
            self.references += 1
            if self.references > self.maximum:
                raise ValueError("Bill reference XML exceeds max_observations")
            if self.callback is not None:
                ancestry = self.snapshot()
                self.callback(BillReference(ancestry[-1], ancestry[:-1]))


def scan_bill_references(
    xml: bytes,
    *,
    on_reference: Callable[[BillReference], object] | None = None,
    max_bytes: int = 16 * 1024 * 1024,
    max_observations: int = 10_000,
    max_depth: int = 256,
) -> BillReferenceScan:
    """Scan href/ref/external-xref occurrences without filtering unknown forms.

    No text is buffered. Missing and empty hrefs remain different, and DTD
    ``parsable-cite`` stays an attribute rather than a fabricated USLM href.
    """
    if type(max_observations) is not int or max_observations <= 0:
        raise ValueError("max_observations must be a positive integer")
    scan = _BillScan(on_reference, max_observations, max_depth)
    # Bill DTD declarations name external schemas. The shared parser accepts
    # those inertly here, never fetching them, and refuses internal entities.
    scan_xml(
        xml,
        start=scan.start,
        end=scan.end,
        data=scan.data,
        max_bytes=max_bytes,
        max_depth=max_depth,
        error_type=ValueError,
        label="Bill reference XML",
        allow_external_doctype=True,
    )
    return BillReferenceScan(scan.elements, scan.references)
