"""Literal section content from retained annual XHTML and USLM members.

Annual statutory fields and XML main-body children remain distinct from notes.
Callbacks are provisional until the complete input succeeds. Originals retain
markup; annual spans are bytes and XML paths count element children.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from html.parser import HTMLParser

from spicy_docs.reading.xml_observations import XmlElement, XmlObservationScan

from . import annual
from .core import DEFAULT_MAX_XML_BYTES, USLM_NAMESPACE, UsCodeSourceError, _body, _limit

_PREFIX = "{" + USLM_NAMESPACE + "}"
_FIELD = re.compile(rb"\s*field-(start|end):([^\s>]+)\s*\Z")
MAX_SECTION_CHARACTERS = 8 * 1024**2
_BODY_TAGS = {
    _PREFIX + name
    for name in (
        "content",
        "subsection",
        "paragraph",
        "subparagraph",
        "clause",
        "subclause",
        "item",
        "subitem",
        "chapeau",
        "continuation",
        "table",
    )
} | {"{http://www.w3.org/1999/xhtml}table"}
_NONBODY_TAGS = {_PREFIX + name for name in ("notes", "note", "quotedContent", "sourceCredit")}


@dataclass(frozen=True, slots=True)
class SectionField:
    name: str
    text: str
    byte_span: tuple[int, int] | None = None
    element: XmlElement | None = None
    depth: int = 0


@dataclass(frozen=True, slots=True)
class AnnualSectionBody:
    structure: annual.AnnualSectionObservation
    fields: tuple[SectionField, ...]
    body_text: str | None
    issues: tuple[str, ...]


class _HtmlText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"p", "div", "tr", "li", "h1", "h2", "h3", "h4", "h5", "h6"}:
            self.parts.append("\n")

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag == "br":
            self.parts.append("\n")
        elif tag in {"td", "th"}:
            self.parts.append("\t")


def _annual_fields(body: bytes, start: int, stop: int) -> tuple[tuple[SectionField, ...], tuple[str, ...]]:
    stack, fields, issues = [], [], []
    for comment in annual._comments(body[start:stop]):
        marker = _FIELD.fullmatch(comment["value"])
        if marker is None:
            continue
        name = marker[2].decode("ascii")
        if marker[1] == b"start":
            if len(stack) >= 256:
                raise UsCodeSourceError("U.S. Code annual fields exceed nesting bound")
            stack.append((name, start + comment.end(), len(stack)))
        else:
            if not stack or stack[-1][0] != name:
                raise UsCodeSourceError("U.S. Code annual field markers are unbalanced")
            _, begin, depth = stack.pop()
            end = start + comment.start()
            if end - begin > MAX_SECTION_CHARACTERS:
                raise UsCodeSourceError("U.S. Code annual field exceeds content bound")
            html = annual._decode(body[begin:end], issues)
            reader = _HtmlText()
            reader.feed(html)
            reader.close()
            fields.append(SectionField(name, "".join(reader.parts), (begin, end), depth=depth))
    if stack:
        raise UsCodeSourceError("U.S. Code annual field markers are unclosed")
    fields.sort(key=lambda value: value.byte_span)
    return tuple(fields), tuple(issues)


def scan_annual_section_bodies(
    body: bytes, *, on_section: Callable[[AnnualSectionBody], None], max_bytes: int = DEFAULT_MAX_XML_BYTES
) -> int:
    """Emit literal section itempaths; absent statute fields yield null body text.

    All named fields, including nested notes and unknown fields, keep their
    exact byte ranges. Ranges and bracketed stubs are never expanded. Encoding
    replacement is explicit in issues and does not change byte positions.
    """
    if not callable(on_section):
        raise UsCodeSourceError("U.S. Code annual body callback must be callable")
    _limit(max_bytes)
    _body(body, max_bytes, "U.S. Code annual XHTML")
    document = item = item_document = None
    count = 0

    def emit(stop: int) -> None:
        nonlocal count
        value = annual._observation(body, item, item_document, stop)
        if value.section_label is not None:
            fields, issues = _annual_fields(body, item.end(), stop)
            statutes = [f for f in fields if f.name == "statute" and f.depth == 0]
            text = "\n".join(f.text for f in statutes) if statutes else None
            on_section(AnnualSectionBody(value, fields, text, tuple(dict.fromkeys((*value.issues, *issues)))))
            count += 1

    for comment in annual._comments(body):
        marker = annual._MARKER.fullmatch(comment["value"])
        if marker is None:
            continue
        if item is not None:
            emit(comment.start())
            item = None
        if marker["kind"] == b"documentid":
            document = comment
        else:
            item, item_document = comment, document
            document = None
    if item is not None:
        emit(len(body))
    return count


@dataclass(frozen=True, slots=True)
class XmlSectionBody:
    element: XmlElement
    ancestors: tuple[XmlElement, ...]
    fields: tuple[SectionField, ...]
    body_text: str | None
    native_text: str
    context: str
    issues: tuple[str, ...]


@dataclass(slots=True)
class _Capture:
    elements: tuple[XmlElement, ...]
    text: list[str] = field(default_factory=list)
    fields: list[SectionField] = field(default_factory=list)
    child: XmlElement | None = None
    child_text: list[str] = field(default_factory=list)
    body_text: list[str] = field(default_factory=list)
    characters: int = 0


class _Bodies(XmlObservationScan):
    def __init__(self, callback: Callable[[XmlSectionBody], None]) -> None:
        super().__init__(error_type=UsCodeSourceError, label="U.S. Code section XML")
        self.callback = callback
        self.active: list[_Capture] = []
        self.count = 0

    def observe_start(self, tag: str, attributes: dict[str, str]) -> None:
        for capture in self.active:
            if len(self.stack) == len(capture.elements) + 1:
                capture.child = self.current_element()
        if tag == _PREFIX + "section":
            self.active.append(_Capture(self.snapshot()))

    def observe_text(self, text: str) -> None:
        for capture in self.active:
            capture.characters += len(text)
            if capture.characters > MAX_SECTION_CHARACTERS:
                raise UsCodeSourceError("U.S. Code section exceeds content bound")
            capture.text.append(text)
            if capture.child is not None:
                capture.child_text.append(text)
                descendants = self.stack[len(capture.elements) :]
                if capture.child.tag in _BODY_TAGS and not any(f.tag in _NONBODY_TAGS for f in descendants):
                    capture.body_text.append(text)

    def observe_end(self, tag: str) -> None:
        for capture in self.active:
            if capture.child is not None and len(self.stack) == len(capture.elements) + 1:
                capture.fields.append(
                    SectionField(capture.child.tag, "".join(capture.child_text), element=capture.child)
                )
                if capture.child.tag in _BODY_TAGS:
                    capture.body_text.append("\n")
                capture.child = None
                capture.child_text.clear()
        if self.active and len(self.stack) == len(self.active[-1].elements):
            capture = self.active.pop()
            excluded = {_PREFIX + name for name in ("num", "heading", "sourceCredit", "notes")}
            body_fields = [f for f in capture.fields if f.name in _BODY_TAGS]
            unknown = tuple(
                f"unclassified-child:{f.name}"
                for f in capture.fields
                if f.name not in excluded | _BODY_TAGS | _NONBODY_TAGS
            )
            context = "main-body-candidate"
            if any(
                e.tag in {_PREFIX + "notes", _PREFIX + "note", _PREFIX + "quotedContent"} for e in capture.elements[:-1]
            ):
                context = "notes-or-quoted-content"
            self.emit(
                self.callback,
                XmlSectionBody(
                    capture.elements[-1],
                    capture.elements[:-1],
                    tuple(capture.fields),
                    "".join(capture.body_text).removesuffix("\n") if body_fields else None,
                    "".join(capture.text),
                    context,
                    unknown,
                ),
            )
            self.count += 1


def scan_xml_section_bodies(
    body: bytes, *, on_section: Callable[[XmlSectionBody], None], max_bytes: int = DEFAULT_MAX_XML_BYTES
) -> int:
    """Keep native section occurrences, direct-child fields and main/notes context.

    ``body_text`` joins recognized body children; unknown children retain fields
    and explicit issues. Absent body children yield null, distinct from empty. Nested subdivision labels and foreign table text survive.
    ``native_text`` is the exact decoded descendant character data; XPath and
    original member hashes provide markup access. Neither field interprets law.
    """
    if not callable(on_section):
        raise UsCodeSourceError("U.S. Code XML body callback must be callable")
    _limit(max_bytes)
    scanner = _Bodies(on_section)
    scanner.read(body, max_bytes=max_bytes)
    return scanner.count
