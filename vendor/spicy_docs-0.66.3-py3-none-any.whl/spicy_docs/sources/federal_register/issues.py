"""Issue-level GovInfo facts, without inferring Federal Register documents."""

from __future__ import annotations

import re
from datetime import date

from spicy_docs.sources.govinfo.mods import GovInfoModsError, parse_govinfo_mods


def read_fr_issue(body: bytes, *, package_id: str, max_bytes: int = 16 * 1024 * 1024) -> dict:
    """Require native package/date agreement; page coordinates remain literal.

    MODS can describe an issue whose PDF is only advertised. No rendition is
    acquired here, and an issue's page span establishes no document boundaries.
    The complete MODS tree and lexical details remain in the original bytes.
    """
    if not isinstance(package_id, str) or re.fullmatch(r"FR-\d{4}-\d{2}-\d{2}", package_id) is None:
        raise GovInfoModsError("Federal Register issue requires a dated package id")
    date.fromisoformat(package_id[3:])
    mapped = parse_govinfo_mods(body, max_bytes=max_bytes)
    record = mapped.package
    if record.access_ids != (package_id,):
        raise GovInfoModsError("Federal Register issue MODS native package differs")
    if tuple(v.text.strip() for v in record.fields("extension", "collectionCode")) != ("FR",):
        raise GovInfoModsError("Federal Register issue MODS requires FR collection")
    dates = tuple(v.text for v in record.fields("originInfo", "dateIssued"))
    if dates != (package_id[3:],):
        raise GovInfoModsError("Federal Register issue MODS date differs from package")
    return {
        "package_id": package_id,
        "publication_date": dates[0],
        "source_sha256": mapped.source_sha256,
        "source_bytes": mapped.source_byte_size,
        "titles": [v.text for v in record.fields("titleInfo", "title")],
        "volume": [v.text for v in record.fields("extension", "volume")],
        "issue": [v.text for v in record.fields("extension", "issue")],
        "page_ranges": [dict(v.attributes) for v in record.fields("extension", "printPageRange")],
        "physical_extent": [v.text for v in record.fields("physicalDescription", "extent")],
        "renditions": [{"url": v.text, "attributes": dict(v.attributes)} for v in record.urls],
    }
