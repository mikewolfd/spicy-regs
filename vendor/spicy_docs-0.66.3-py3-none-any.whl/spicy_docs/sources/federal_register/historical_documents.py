"""Read explicitly selected historical issue PDF regions with page evidence.

This reader consumes a retained PDF and a caller's document boundary selection.
It does not discover documents, verify printed identifiers, or infer text
accuracy from a PDF text layer. Independent qualification remains separate.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import date

from spicy_docs.extraction import Box, DocumentExtractor, NativeText, PageResult, TextBlock
from spicy_docs.reading.pdf_bytes import check_pdf_bytes


class HistoricalFrDocumentError(ValueError):
    """The selected source or page regions could not be read completely."""


@dataclass(frozen=True, slots=True)
class HistoricalFrRegion:
    pdf_page: int
    printed_page: str
    box: Box

    def __post_init__(self) -> None:
        if type(self.pdf_page) is not int or self.pdf_page < 1:
            raise HistoricalFrDocumentError("PDF page must be a positive one-based integer")
        if not isinstance(self.printed_page, str) or not self.printed_page.strip():
            raise HistoricalFrDocumentError("a literal printed-page witness is required")
        if not isinstance(self.box, Box):
            raise HistoricalFrDocumentError("region requires normalized displayed-page Box coordinates")


@dataclass(frozen=True, slots=True)
class HistoricalFrSelection:
    issue_package_id: str
    document_number: str | None
    regions: tuple[HistoricalFrRegion, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.issue_package_id, str) or not re.fullmatch(
            r"FR-\d{4}-\d{2}-\d{2}", self.issue_package_id
        ):
            raise HistoricalFrDocumentError("select a dated Federal Register issue package")
        date.fromisoformat(self.issue_package_id[3:])
        if not isinstance(self.regions, tuple) or not 1 <= len(self.regions) <= 64:
            raise HistoricalFrDocumentError("select a bounded nonempty tuple of page regions")
        if any(not isinstance(region, HistoricalFrRegion) for region in self.regions):
            raise HistoricalFrDocumentError("selection regions must be HistoricalFrRegion values")
        if self.document_number is not None and (
            not isinstance(self.document_number, str) or not self.document_number.strip()
        ):
            raise HistoricalFrDocumentError("declared document number must be nonempty or null")
        for index, region in enumerate(self.regions):
            for previous in self.regions[:index]:
                if previous.pdf_page == region.pdf_page and previous.box.intersects(region.box):
                    raise HistoricalFrDocumentError("selected document regions overlap")


@dataclass(frozen=True, slots=True)
class HistoricalFrRegionText:
    selection: HistoricalFrRegion
    blocks: tuple[TextBlock, ...]
    page_evidence: PageResult

    @property
    def text(self) -> str:
        return "\n".join(block.text for block in self.blocks)


@dataclass(frozen=True, slots=True)
class HistoricalFrDocumentText:
    source_sha256: str
    source_bytes: int
    selection: HistoricalFrSelection
    regions: tuple[HistoricalFrRegionText, ...]
    text: str
    qualification: str = "selected-regions-only; printed identity, boundaries and text accuracy require review"


def read_historical_fr_document(
    body: bytes,
    *,
    expected_sha256: str,
    selection: HistoricalFrSelection,
    extractor=None,
    max_bytes: int = 64 * 1024**2,
    max_characters: int = 8 * 1024**2,
) -> HistoricalFrDocumentText:
    """Return a complete selected document observation or refuse the whole read.

    Selection order defines reading order across columns/pages. Intersecting
    lines must fit entirely inside a region; missing coordinates, missing pages,
    mismatched source metadata and empty selected text refuse. Full page results
    retain backend configuration, raw observations and limitations, separately
    from selected text. Use injected ``DocumentExtractor`` strategies for OCR;
    the default explicitly reads existing PDF text and downloads no models.
    Printed page/document/issue identifiers remain caller declarations.
    """
    if type(max_bytes) is not int or max_bytes < 1 or type(max_characters) is not int or max_characters < 1:
        raise HistoricalFrDocumentError("input and text bounds must be positive integers")
    if not isinstance(body, bytes) or not body or len(body) > max_bytes:
        raise HistoricalFrDocumentError("historical issue PDF exceeds input byte bound")
    if not isinstance(selection, HistoricalFrSelection):
        raise HistoricalFrDocumentError("explicit historical document selection is required")
    digest = "sha256:" + hashlib.sha256(body).hexdigest()
    if digest != expected_sha256:
        raise HistoricalFrDocumentError("historical issue original digest differs")
    check_pdf_bytes(body, error_type=HistoricalFrDocumentError, label="historical Federal Register issue")
    if extractor is None:
        extractor = DocumentExtractor(NativeText(), max_input_bytes=max_bytes)
    pages = tuple(dict.fromkeys(region.pdf_page for region in selection.regions))
    results = {}
    for result in extractor.extract(body, media_type="application/pdf", pages=pages):
        number = result.metadata.get("page")
        if type(number) is not int or number not in pages or number in results:
            raise HistoricalFrDocumentError("extractor returned an unexpected or repeated page")
        if result.metadata.get("source_sha256") != digest.removeprefix("sha256:"):
            raise HistoricalFrDocumentError("page evidence belongs to different source bytes")
        if result.metadata.get("source_size_bytes") != len(body):
            raise HistoricalFrDocumentError("page evidence source size differs")
        results[number] = result
    if set(results) != set(pages):
        raise HistoricalFrDocumentError("extractor did not return every selected page")
    observed, characters = [], 0
    for region in selection.regions:
        result = results[region.pdf_page]
        blocks = []
        for block in result.content.blocks:
            if not block.text.strip():
                continue
            if block.box is None:
                raise HistoricalFrDocumentError("page text lacks coordinates; document boundaries remain unresolved")
            if not region.box.intersects(block.box):
                continue
            if not region.box.contains(block.box):
                raise HistoricalFrDocumentError("selected document boundary clips a text block")
            blocks.append(block)
            characters += len(block.text) + 1
            if characters > max_characters:
                raise HistoricalFrDocumentError("selected historical document exceeds text bound")
        if not blocks:
            raise HistoricalFrDocumentError("selected region has no text; select a reviewed OCR strategy")
        observed.append(HistoricalFrRegionText(region, tuple(blocks), result))
    text = "\n".join(region.text for region in observed)
    return HistoricalFrDocumentText(digest, len(body), selection, tuple(observed), text)
