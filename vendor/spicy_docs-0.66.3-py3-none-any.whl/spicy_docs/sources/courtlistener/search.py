"""CourtListener v4 search: RECAP dockets and opinion clusters, page by page with exact evidence.

The public ``/search/`` endpoint answers ``count``, ``next`` and ``results`` with an opaque cursor,
and cursor pagination requires ``dateFiled`` ordering; ``type=r`` lists RECAP dockets (with a
``document_count`` beside ``count``) and ``type=o`` lists indexed opinion clusters. Live requests
require ``Authorization: Token <token>``; verified retained replay and public bulk reads do not.
Opinion status selection is explicit when requested; an omitted selection retains the publisher's
published-only default, including for historical replay. Search never establishes bulk coverage.

Docket counts (``type=r`` and ``type=d``) above 2,000 may be cardinality
estimates; their explicit terminal cursor establishes traversal completion.
Smaller docket counts and opinion counts retain exact-count checks. Publisher explanation: https://wiki.free.law/c/courtlistener/help/api/rest/v4/search#result-counts
"""

from __future__ import annotations

import math
import re
from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import date as Date
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal
from urllib.parse import parse_qsl, urlencode, urlsplit

from spicy_docs.reading.paged_json import (
    DEFAULT_MAX_PAGES,
    JsonPage,
    JsonPageFamily,
    PagedJsonBudget,
    PagedJsonReader,
    PagedJsonSourceError,
    query_value,
)
from spicy_docs.transport.source_acquirer import check_request_count, utc_now

if TYPE_CHECKING:
    import httpx

API = "https://www.courtlistener.com/api/rest/v4"
RESULTS_KEY = "results"
type SearchKind = Literal["r", "o"]
type SearchOrder = Literal["dateFiled asc", "dateFiled desc"]
# Publisher-defined Search statuses, not the REST API's abbreviated field values.
OPINION_STATUSES = ("Published", "Unpublished", "Errata", "Separate", "In-chambers", "Relating-to", "Unknown")


class _SearchFamily(JsonPageFamily):
    def check_url(self, url: str) -> str:
        normalized = super().check_url(url)
        parts = urlsplit(normalized)
        try:
            port = parts.port
        except ValueError as error:
            raise PagedJsonSourceError("CourtListener search URL has an invalid port") from error
        if (
            port not in (None, 443)
            or parts.username is not None
            or parts.password is not None
            or parts.path != "/api/rest/v4/search/"
        ):
            raise PagedJsonSourceError("CourtListener search must stay on its HTTPS origin and Search route")
        names = [name for name, _ in parse_qsl(parts.query, keep_blank_values=True)]
        if len(names) != len(set(names)):
            raise PagedJsonSourceError("CourtListener search repeats a query parameter")
        return normalized


COURTLISTENER = _SearchFamily(
    name="courtlistener",
    label="CourtListener",
    host="www.courtlistener.com",
    next_path=("next",),
    count_path=("count",),
    credential_header="Authorization",
    credential_format="Token {key}",
    requires_credential=False,  # Verified replay is public; the transport guards every live dispatch.
)
_COURT = re.compile(r"[a-z0-9]{1,32}")


@dataclass(frozen=True, slots=True)
class CourtListenerTraversalBudget:
    """Caller allocation for one search: all attempts and all pacing/retry waits, across pages.

    This states what the caller permits, not the publisher's remaining quota.
    The existing page budget still limits attempts and response bytes per page.
    """

    max_requests: int
    max_wait_seconds: float

    def __post_init__(self) -> None:
        check_request_count(self.max_requests)
        value = self.max_wait_seconds
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("max_wait_seconds must be finite and nonnegative")


def is_exact_count(kind: str | None, declared_count: int | None) -> bool:
    """Keep small-count checks; the publisher documents docket estimates above 2,000."""
    return kind not in ("r", "d") or declared_count is None or declared_count <= 2_000


def _filed(value: str | None, name: str) -> str | None:
    """The search endpoint takes MM/DD/YYYY; callers pass ISO dates."""
    if value is None:
        return None
    if not isinstance(value, str) or re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value) is None:
        raise PagedJsonSourceError(f"{name} must use YYYY-MM-DD")
    try:
        parsed = Date.fromisoformat(value)
    except ValueError as error:
        raise PagedJsonSourceError(f"{name} must be a valid calendar date") from error
    return parsed.strftime("%m/%d/%Y")


def search_url(
    *,
    kind: SearchKind,
    filed_after: str | None = None,
    filed_before: str | None = None,
    order_by: SearchOrder = "dateFiled asc",
    court: str | None = None,
    nature_of_suit: str | None = None,
    q: str | None = None,
    opinion_statuses: Sequence[str] | None = None,
) -> str:
    """Build one canonical search URL, refusing a bad kind, non-``dateFiled`` ordering, an invalid
    court identifier and query values over 512 characters.
    """
    if kind not in ("r", "o"):
        raise PagedJsonSourceError("kind must be 'r' (RECAP dockets) or 'o' (opinion clusters)")
    if order_by not in ("dateFiled asc", "dateFiled desc"):
        raise PagedJsonSourceError("cursor pagination requires dateFiled ordering")
    if court is not None and (not isinstance(court, str) or _COURT.fullmatch(court) is None):
        raise PagedJsonSourceError("court must be a lowercase CourtListener court identifier")
    query: list[tuple[str, str]] = [("type", kind), ("order_by", order_by)]
    for name, value in (
        ("filed_after", _filed(filed_after, "filed_after")),
        ("filed_before", _filed(filed_before, "filed_before")),
    ):
        if value is not None:
            query.append((name, value))
    for name, value in (("court", court), ("nature_of_suit", nature_of_suit), ("q", q)):
        if value is not None:
            if not isinstance(value, str) or not value.strip() or len(value) > 512:
                raise PagedJsonSourceError(f"{name} must be a nonempty string of at most 512 characters")
            query.append((name, value))
    if opinion_statuses is not None:
        if (
            kind != "o"
            or isinstance(opinion_statuses, str)
            or not opinion_statuses
            or any(status not in OPINION_STATUSES for status in opinion_statuses)
            or len(set(opinion_statuses)) != len(opinion_statuses)
        ):
            raise PagedJsonSourceError("opinion_statuses must select distinct supported opinion statuses")
        query.extend(("stat_" + status, "on") for status in OPINION_STATUSES if status in opinion_statuses)
    return f"{API}/search/?{urlencode(query)}"


def _authenticated_transport(transport: httpx.BaseTransport | None, api_key: str | None) -> httpx.BaseTransport:
    """Keep verified replay local; require a token before any delegated live attempt."""
    import httpx

    class AuthenticatedTransport(httpx.BaseTransport):
        def __init__(self):
            self.delegate = transport

        def replay_response(self, request):
            replay = getattr(self.delegate, "replay_response", None)
            return replay(request) if replay is not None else None

        def handle_request(self, request):
            if not api_key:
                raise PagedJsonSourceError("CourtListener live API acquisition requires an API token")
            if self.delegate is None:
                self.delegate = httpx.HTTPTransport(trust_env=False)
            return self.delegate.handle_request(request)

        def close(self):
            if self.delegate is not None:
                self.delegate.close()

    return AuthenticatedTransport()


class CourtListenerSearchReader(PagedJsonReader):
    """Read one CourtListener search URL through the shared paged-JSON reader."""

    def __init__(
        self,
        *,
        budget: PagedJsonBudget,
        api_key: str | None = None,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
        traversal_budget: CourtListenerTraversalBudget | None = None,
    ) -> None:
        if traversal_budget is not None and not isinstance(traversal_budget, CourtListenerTraversalBudget):
            raise TypeError("traversal_budget must be a CourtListenerTraversalBudget")
        self.traversal_budget = traversal_budget
        super().__init__(
            family=COURTLISTENER,
            budget=budget,
            api_key=api_key,
            transport=_authenticated_transport(transport, api_key),
            clock=clock,
        )

    def _count_is_exact(self, url: str, declared_count: int | None) -> bool:
        return is_exact_count(query_value(url, "type"), declared_count)

    def _continuation(
        self, value: Mapping[str, Any], *, url: str, body: Mapping[str, Any] | None, rows: list
    ) -> tuple[str | None, Mapping[str, Any] | None]:
        if "next" not in value:
            raise PagedJsonSourceError("CourtListener search omitted its next cursor")
        next_url, next_body = super()._continuation(value, url=url, body=body, rows=rows)
        if next_url is not None:

            def selection(locator):
                return {
                    name: value
                    for name, value in parse_qsl(urlsplit(locator).query, keep_blank_values=True)
                    if name != "cursor"
                }

            if selection(next_url) != selection(url):
                raise PagedJsonSourceError("CourtListener continuation changed its search selection")
        return next_url, next_body

    def search(self, url: str, *, max_pages: int = DEFAULT_MAX_PAGES) -> Iterator[JsonPage]:
        """Yield exact page captures; only normal exhaustion establishes a complete walk.

        A deferred walk retains its already yielded captures and adds bounded
        query/cursor diagnostics to the error. The caller owns their persistence.
        """
        url = self.family.check_url(url)
        observed = 0
        completed_pages = 0
        next_url: str | None = url
        budget = self.traversal_budget
        allocation = (
            self._http.traversal_budget(max_requests=budget.max_requests, max_wait_seconds=budget.max_wait_seconds)
            if budget is not None
            else nullcontext()
        )
        with allocation:
            try:
                for page in self.pages(url, records_key=RESULTS_KEY, max_pages=max_pages):
                    if page.declared_count is None:
                        raise PagedJsonSourceError("CourtListener search omitted its declared count")
                    observed += len(page.records)
                    if page.next_url is None and not observed and page.declared_count:
                        raise PagedJsonSourceError("CourtListener empty search has a positive declared count")
                    completed_pages += 1
                    next_url = page.next_url
                    yield page
            except Exception as error:
                error.__dict__["courtlistener_traversal"] = {
                    "url": url,
                    "nextUrl": next_url,
                    "completedPages": completed_pages,
                    "observedCount": observed,
                }
                raise
