"""Bounded HTTP retry timing shared by acquisition commands and tools."""

from __future__ import annotations

import random
import sys
import time
from collections.abc import Callable
from datetime import datetime
from email.utils import parsedate_to_datetime

from spicy_docs.transport.credentials import failure_reason

# Allow temporary network congestion ~542s of total sleep across 13 retries.
# Callers classify errors; terminal refusals still fail on the first attempt.
MAX_HTTP_ATTEMPTS = 14
RETRY_BACKOFF_CEILING_SECONDS = 60.0


def retry_after_seconds(value: str | None, *, now: datetime) -> float | None:
    """Read a Retry-After delay or HTTP-date; malformed values do not invent a quota window."""
    value = (value or "").strip()
    if value.isascii() and value.isdecimal():
        try:
            return float(value)
        except OverflowError:
            return float("inf")
    try:
        instant = parsedate_to_datetime(value)
        if instant.tzinfo is not None:
            return max(0.0, (instant - now).total_seconds())
    except (TypeError, ValueError, OverflowError):
        pass
    return None


def retry_http[FetchResult](
    operation: Callable[[], FetchResult],
    *,
    retryable: tuple[type[Exception], ...],
    max_attempts: int | None = None,
    api_key: str = "",
    wait: Callable[[Exception, float], None] | None = None,
) -> FetchResult:
    """Run operation with capped exponential backoff and full jitter.

    max_attempts includes the initial attempt and defaults to MAX_HTTP_ATTEMPTS.
    A uniform delay from zero to the ceiling separates concurrent fetchers' retries,
    and each retry logs its attempt, delay and scrubbed exception to stderr.
    Callers using credentials must supply api_key unless they already replace or
    scrub exception text; keyless callers still get query-parameter scrubbing.
    ``wait`` lets a bounded caller honor server timing and charge the delay to
    its allocation; without it, the ordinary jittered sleep stays unchanged.
    """

    attempts = MAX_HTTP_ATTEMPTS if max_attempts is None else max_attempts
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts <= 0:
        raise ValueError("max_attempts must be a positive integer")
    for attempt in range(1, attempts + 1):
        try:
            return operation()
        except retryable as error:
            if attempt == attempts:
                raise
            ceiling = min(2**attempt, RETRY_BACKOFF_CEILING_SECONDS)
            delay = random.uniform(0.0, ceiling)
            # A later success bypasses the caller's error-row scrub. Scrub here,
            # before truncation can leave a partial credential in the log.
            reason = failure_reason(error, api_key)
            timing = f"in {delay:.1f}s (cap {ceiling:.0f}s)" if wait is None else "with caller-owned wait"
            print(
                f"source-native fetch: retry {attempt}/{attempts - 1} {timing} after {reason}",
                file=sys.stderr,
            )
            if wait is None:
                time.sleep(delay)
            else:
                wait(error, delay)
    raise AssertionError("unreachable")
